package com.bancoazteca.canales.terceros.apitelefonia;

public class RestApiServiceIdClientTemplate {

}
