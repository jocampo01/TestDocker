package com.bancoazteca.canales.terceros.apitelefonia;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXB;
import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.storm.shade.org.json.simple.JSONObject;
import org.json.JSONException;
import org.springframework.web.client.RestClientException;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.core.MediaType;

public class RestServiceClient {

// http://localhost:8080/RESTfulExample/json/product/get
	public static void main(String[] args) throws ParserConfigurationException, SAXException {

		try {

			URL url = new URL("http://localhost:8080/CustomerDB/webresources/co.com.mazf.ciudad");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/xml");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;

			Ciudades ciudades = new Ciudades();
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				System.out.println("12132312");
				System.err.println(output);

				DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(output));

				Document doc = db.parse(is);
				NodeList nodes = ((org.w3c.dom.Document) doc).getElementsByTagName("ciudad");

				for (int i = 0; i < nodes.getLength(); i++) {
					Ciudad ciudad = new Ciudad();
					Element element = (Element) nodes.item(i);

					NodeList name = element.getElementsByTagName("idCiudad");
					Element element2 = (Element) name.item(0);

					ciudad.setIdCiudad(Integer.valueOf(getCharacterDataFromElement(element2)));

					NodeList title = element.getElementsByTagName("nomCiudad");
					element2 = (Element) title.item(0);

					ciudad.setNombre(getCharacterDataFromElement(element2));

					ciudades.getPartnerAccount().add(ciudad);
				}
			}

			for (Ciudad ciudad1 : ciudades.getPartnerAccount()) {
				System.out.println(ciudad1.getIdCiudad());
				System.out.println(ciudad1.getNombre());
			}

			conn.disconnect();

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public JSONObject getAllTypes() throws JSONException, IOException {
        String url = "/api/atlas/types";
        String authString = "USER" + ":" + "PASSWORD";
        String authStringEnc = new BASE64Encoder().encode(authString.getBytes());
        javax.ws.rs.client.Client client = ClientBuilder.newClient();
        WebTarget webTarget = client.target("" + url);
        Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_JSON).header("Authorization", "Basic " + authStringEnc);

        Response response = invocationBuilder.get();
        String output = response.readEntity(String.class
        );

        System.out.println(response.toString());
        JSONObject obj = new JSONObject();

        return obj;
    }

	public void consumirAPITelefonia() {
		
		String url = "http://localhost:8080/mgm/country";
		List<MediaType> mediaTypes = new ArrayList<MediaType>();
		mediaTypes.add(MediaType.APPLICATION_JSON);
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(mediaTypes);
		HttpEntity<Country> httpEntity = new HttpEntity<Country>(null, headers);
		try {
		    ResponseEntity<Country[]> responseEntity = restTemplate.exchange(url, HttpMethod.GET, httpEntity, Country[].class);
		    Country[] countries = responseEntity.getBody();
		    System.out.println(countries[0].getName());

		} catch (RestClientException exception) {
		    exception.printStackTrace();
		}
		
	}
	
	
	public static String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
			CharacterData cd = (CharacterData) child;
			return cd.getData();
		}
		return "";
	}
	
	public static MyApiService getApiService() {

        // Creamos un interceptor y le indicamos el log level a usar
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

        // Asociamos el interceptor a las peticiones
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.addInterceptor(logging);

        String baseUrl = "https://mi-pagina.com/api/";

        if (API_SERVICE == null) {
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(httpClient.build()) // <-- usamos el log level
                    .build();
            API_SERVICE = retrofit.create(MyApiService.class);
        }

        return API_SERVICE;
    }
	
	public static ArrayList<FileInformation> httpGet(String url, String function) {

		
		Client cliente = ClientBuilder.newClient();
		Factura f = cliente.target("http://localhost:3000/mifactura")
		.request(MediaType.APPLICATION_JSON_TYPE).get(Factura.class);
		System.out.println(f.getId());
		System.out.println(f.getConcepto());
		System.out.println(f.getImporte());

		Client c = Client.create();
	      c.addFilter(new HTTPBasicAuthFilter("weblogic", "weblogic1"));
	      WebResource resource = c.resource("http://localhost:7001/management/tenant-monitoring/datasources/JDBC%20Data%20Source-0");
	      String response = resource.accept("application/json").get(String.class); //application/xml
	      // resource.accept(MediaType.APPLICATION_JSON_TYPE).get(String.class);
	      System.out.println(response);
		
	      
	      Client c = Client.create();
			c.getProperties().put(ClientConfig.PROPERTY_FOLLOW_REDIRECTS, true);
			System.out.println("Client created, going to create a webresource") ;
			WebResource r = c.resource("http://localhost:9998/helloworld");
			System.out.println("WebResource created, getting the answer");
			String response = r.accept(
				        MediaType.APPLICATION_JSON_TYPE,
				        MediaType.APPLICATION_XML_TYPE).
				        header("X-FOO", "BAR").get(String.class); 
			System.out.println("Response is :" + response ) ;
		
	    ArrayList<FileInformation> dataFromService = new ArrayList<FileInformation>();
	    try (CloseableHttpClient httpClient = HttpClientBuilder.create().build()) {
	        HttpGet request = new HttpGet(url+function);   
	        request.addHeader("content-type", "application/json");
	        HttpResponse result = httpClient.execute(request);
	        String json = EntityUtils.toString(result.getEntity(), "UTF-8");  

	        com.google.gson.Gson gson = new com.google.gson.Gson();                       
	        FileInformation[] response = gson.fromJson(json, FileInformation[].class);

	        System.out.println(response.length);   
	        for(FileInformation file : response)
	        {
	            dataFromService.add(file);
	             System.out.println(file.toString());
	        }

	    } catch (IOException ex) {
	    }
	    return dataFromService;
	}
}