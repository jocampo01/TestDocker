package com.journaldev.spring.controller;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Base64;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;

public class ConsumirAPIClasificacionTelefonia {

	private static final Charset UTF8_CHARSET = Charset.forName("UTF-8");
	static String str_response = "";
	static String line = "";

	public static void main(String args[]) throws Exception {

		CredentialsProvider credentialsPovider = new BasicCredentialsProvider();
		String client_id = "tUJeAyc6iUflGDRmO9ClRT5BCcXRc2II";
		String client_secret = "hja8mrbnKWwlugbV";

		AuthScope scope = new AuthScope(
				"https://10.82.57.113:8084/TipoCliente/credito_cobranza/credito/v1/TipoCliente/ObtenerClasificacion",
				80);

		Credentials credentials = new UsernamePasswordCredentials("tUJeAyc6iUflGDRmO9ClRT5BCcXRc2II",
				"hja8mrbnKWwlugbV");
		credentialsPovider.setCredentials(scope, credentials);

		HttpClientBuilder clientbuilder = HttpClients.custom();

		clientbuilder = clientbuilder.setDefaultCredentialsProvider(credentialsPovider);
		SSLContextBuilder builder = new SSLContextBuilder();
		builder.loadTrustMaterial(null, new TrustSelfSignedStrategy());
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(builder.build());
		Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
				.register("http", new PlainConnectionSocketFactory()).register("https", sslsf).build();
		PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry);
		cm.setMaxTotal(2000);

		CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).setConnectionManager(cm).build();

		HttpPost httpPost = new HttpPost("https://10.82.57.113:8084/TipoCliente/credito_cobranza/credito/v1/TipoCliente/ObtenerClasificacion");
		String base64Credentials = Base64.getEncoder().encodeToString((client_id + ":" + client_secret).getBytes());

		httpPost.addHeader("Authorization", "Basic " + base64Credentials);
		StringEntity StringEntity = new StringEntity(
				"{\"idProducto\": 23, \"idPais\": 1,\"idCanal\": 1,\"idSucursal\": 2244, \"folio\": 2801}");

		String jsonRequest = "{\"idProducto\": 23, \"idPais\": 1,\"idCanal\": 1,\"idSucursal\": 2244, \"folio\": 2801}";
		httpPost.addHeader("content-type","application/json");
		

		httpPost.setEntity(new StringEntity(jsonRequest, UTF8_CHARSET));
		System.out.println(httpPost.getMethod());

		HttpResponse response = httpclient.execute(httpPost);
		System.out.println(response.getParams());
		StringWriter writer = new StringWriter();
		IOUtils.copy(response.getEntity().getContent(), writer);
		System.out.println(">>>>>>>>>>>>>>>>>>>> IOUtils.copy " + writer.toString());

		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			@Override
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			@Override
			public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
				// TODO Auto-generated method stub

			}

			@Override
			public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
				// TODO Auto-generated method stub

			}
		} };

		// Create all-trusting host name verifier
		HostnameVerifier allHostsValid = new HostnameVerifier() {
			@Override
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		};

		try {
			// Install the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			// Install the all-trusting host verifier
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		/*
		 * 
		 * SSLContext sslctx = SSLContext.getInstance("SSL"); sslctx.init(null, new
		 * X509TrustManager[] { new MyTrustManager()}, null);
		 * HttpsURLConnection.setDefaultSSLSocketFactory(sslctx.getSocketFactory());
		 * 
		 * 
		 * SSLContext ctx = SSLContext.getInstance("TLS"); ctx.init(null, new
		 * TrustManager[] { new TrustManager() }, null); SSLContext.setDefault(ctx);
		 * 
		 */
		String body = "{\"idProducto\": 23, \"idPais\": 1,\"idCanal\": 1,\"idSucursal\": 2244, \"folio\": 2801}";

		URL url = new URL(
				"https://10.82.57.113:8084/TipoCliente/credito_cobranza/credito/v1/TipoCliente/ObtenerClasificacion");
		HttpURLConnection connection = (HttpsURLConnection) url.openConnection();
		/*
		 * Authenticator au = new Authenticator() {
		 * 
		 * @Override protected PasswordAuthentication getPasswordAuthentication() {
		 * return new PasswordAuthentication ("TMwmAkVuwmGTrcq5gYNxEvIojIAUBpfA",
		 * "c73AAiy6G0CG7KZV".toCharArray()); } }; Authenticator.setDefault(au);
		 */
		connection.setRequestMethod("POST");
		connection.setDoOutput(true);
		connection.setRequestProperty("content-type", "application/json");
		connection.setRequestProperty("x-ip", "10.53.37.252");
		connection.setRequestProperty("x-usuario", "MSOMOC");
		connection.setRequestProperty("x-contrasenia", "U2VndXJpZGFkTU9DTVNPNjk5Ni4=");
		connection.addRequestProperty("Authorization", "Basic " + base64Credentials);
		// connection.setAuthenticator(auth);
		// connection.setRequestProperty("Authorization", "Basic " + base64Credentials);

		/*	DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
			wr.writeBytes(body);
			wr.flush();
			wr.close();*/
			
			OutputStream os = connection.getOutputStream();
			os.write(body.getBytes("UTF-8"));
			os.flush();
			connection.connect();
			
			// Convert the response into a String object.
		     String responseContent = parseResponse(connection.getInputStream());


		     org.json.JSONObject parsedObject = new org.json.JSONObject(responseContent);
		     System.out.println(parsedObject);
			InputStream is = connection.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			BufferedReader rd = new BufferedReader(isr);
			while ((line = rd.readLine()) != null)
				str_response += line + '\r';
			rd.close();
			System.out.println("str_response:" + str_response);

			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
			}
			int statusCode = response.getStatusLine().getStatusCode();
			System.out.println(statusCode);
			System.out.println(response.getEntity().getContent());
			response.getAllHeaders();

	}
	
	static String parseResponse(InputStream in) throws Exception
	{
	     InputStreamReader inputStream = new InputStreamReader(in, "UTF-8" );
	     BufferedReader buff = new BufferedReader(inputStream);

	     StringBuilder sb = new StringBuilder();
	     String line = buff.readLine();
	     while (line != null )
	     {
	       sb.append(line);
	       line = buff.readLine();
	     }

	     return sb.toString();
	}

}