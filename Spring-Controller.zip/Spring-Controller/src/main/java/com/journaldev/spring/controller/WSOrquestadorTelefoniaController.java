package com.journaldev.spring.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.journaldev.spring.model.Person;

@RestController
public class WSOrquestadorTelefoniaController {

	@RequestMapping(value="/test")
	public String healthCheck() {
		return "OK";
	}

	@RequestMapping("/buscarClientesCDT")
	public @ResponseBody Person consultarLCR(
			@RequestParam(name = "idproducto") String idproducto,
			@RequestParam(name = "pais") String pais,
			@RequestParam(name = "canal") String canal,
			@RequestParam(name = "sucursal") String sucursal,
			@RequestParam(name = "folio") String folio
			) {
		Person person = new Person();
		person.setIdproducto(idproducto);
		person.setPais(pais);
		person.setCanal(canal);
		person.setSucursal(sucursal);
		person.setFolio(folio);
		
		return person;
	}

}