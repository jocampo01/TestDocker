package com.bancoazteca.canales.terceros.web.servicios;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Base64;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.stereotype.Component;

@SuppressWarnings("deprecation")
@Component
public class ConsumirAPICotizadorTelefonia {

	private static final Charset UTF8_CHARSET = Charset.forName("UTF-8");
	static String str_response = "";
	static String line = "";
	static String jsonRequest="";
	public String obtenerCotizacionTelefonia() throws Exception {

		CredentialsProvider credentialsPovider = new BasicCredentialsProvider();
		String client_id = "tUJeAyc6iUflGDRmO9ClRT5BCcXRc2II";
		String client_secret = "hja8mrbnKWwlugbV";

		AuthScope scope = new AuthScope("https://10.53.37.252:8543/CotizadorConsumoTel/credito_cobranza/credito/v1/Cotizador/Cotizar",80);

		Credentials credentials = new UsernamePasswordCredentials("tUJeAyc6iUflGDRmO9ClRT5BCcXRc2II","hja8mrbnKWwlugbV");
		credentialsPovider.setCredentials(scope, credentials);

		HttpClientBuilder clientbuilder = HttpClients.custom();

		clientbuilder = clientbuilder.setDefaultCredentialsProvider(credentialsPovider);
		SSLContextBuilder builder = new SSLContextBuilder();
		builder.loadTrustMaterial(null, new TrustSelfSignedStrategy());
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(builder.build());
		Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
				.register("http", new PlainConnectionSocketFactory()).register("https", sslsf).build();
		PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry);
		cm.setMaxTotal(2000);

		CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).setConnectionManager(cm).build();

		HttpPost httpPost = new HttpPost("https://10.53.37.252:8543/CotizadorConsumoTel/credito_cobranza/credito/v1/Cotizador/Cotizar");
		String base64Credentials = Base64.getEncoder().encodeToString((client_id + ":" + client_secret).getBytes());
		jsonRequest = "{ \"tienda\": {   \"idPais\": 1, \"idCanal\": 1,\"idSucursal\": 100 }, \"idModalidad\": \"TL\", \"clienteUnico\": { \"idPais\": 1, \"idCanal\": 1,\"idSucursal\": 2244,   \"folio\": 107147 }, \"productos\": [   {     \"sku\": 151515,     \"montoEnganche\": 50,     \"cantidad\": 1,     \"precio\": 2000,     \"descuentoEkt\": 100,     \"descuentoBaz\": 0,     \"idCategoria\": 1,     \"enganche\": true,     \"plan\": false   } ], \"pedidosRenovacion\": [ ], \"lineaCredito\": \"N6bzSlYYyu\\/zXSTa6DlOJ0T9sDMo61wi+cJFni6nFASZwfEtSioeLlsmSI8N4A6ELS1Ygc0JQ\\/dQUuTGJy5tr45HU5XxB+Y3QfTzfxGbB6gS+vJN98BPqMtcJlYoIbKL4t5JckiX5CdgG9ihFqWouCDMDA\\/SU7sd53irscO2+fsZBQmDoysRmS+863YZ\\/sOQ\\/0A\\/9Go8FrwfRd+dBm+ZNEjNco97JpK17vGY423ps0EgjhfQFFTh9HjHcWiAAGhLO0nQ27Zh65VN06NPuyfV7rOSq9TuAd7hKrIDEYCCSh5rxlzJ3KUVOXr+fHvjv9xxitYACf0kscOj7j\\/I+eJA\\/PTLw3R\\/DgREPmJrjx90xllC43pC6pWOF9uuU99DFMeqFknVTu4ot8\\/cf4U3FSAzqmvmafHIVqp9OyrO7Ag17U7PoQgP8qJRi2wEYHqZ3WmY6Vk59PEl0XPDuBMztBQZTlCm3BB6FgPouaoBqF9Mmha2O55rqfhl6VBSErHneYLfsMWMTDGX7vYptXFC\\/jf9QRtzm8SP\\/fdhG8RxUMLKPveRmkaASnuKInsAhHB7xbs8HTB9PtKn\\/kq1PsRHB3OPvVM4PYXMTnMsF8L\\/1NDGmmtqJofVKqBO+CGnwjqlxhauHdzneb4hJ1oPSlsXwQPH3RUCs6m24jxQcwyyWNp3aLleFkJS4UrHShyb2G1cRfD6SbHQwg+TOOtaDkhSBQh\\/JmFKlRP+pWrWfCHG7l0UNX\\/FVupJknKSRxwexseAFH2vtUq\\/OP\\/Jsdoco5K9QLHHhr7DgwMrrxcjlX5rKLSvJCM2HKS+Tae0Gd3wK9ayVf7R5ogdqso6BTb\\/QNNwV8O2fbjSwVXBB4t1V428seZhn7qcXFCUD8EJzkukNSHL9PigjpaRWFd8wGIhlvRyOhHIoLdEcMm7lTV3HNu6MPFo4QooNHL0Z5Z\\/YUYpe\\/gZM2hxuhbc9lleBxGP5TGRVGHw6r7+7asNFG4igwJ7wxpFuqN6neqg\\/jtA1QwE1MdNOuxXYGTn\\/aYtp83QlnGjGOA89RehZ3GBJfSEm+Q16lsgfRYiA8JBG4kz81vgKZHDZcWfyXnzmwqQrE5+RQ4u5gmc7xXP+yMbwtMrUDGuYzR49TGe+VHi7lZhPRQ1kPZEi3ceCryOE2LHjz7T2LqaAdBoh3LwgT4DjYTV8vUEQ\\/xauJfzOcUT4H5xaACEKK2NEEv71yRykJLv6vcgXoUkqrV1fujC8P9SJbxLGeivGqetLVde1LYAUtAm6PrcgU3UBbCcuRRNctKTL5DPvU1vHv3ZZhMqKsyd+XD8ddbKExGWCFDa29TPdXf+UTrWnQgft3l1StHtQgTAAE2Fw3gpqoa11UxWV5fNcTAfNPT5WkLPPpqk5TpaXbAwoMu9KJZhgYQB7auV86fAaygy7MtGrBHZMbfDvLDhDIswVmNQ1KrfJ5JscG0\\/foUJIT\\/c420HUmLiIWjcG6EuCr26PBSMhxQ9+fL8Usj2A\\/cKjx1ysl5Q9BWlrN0hrLqx5cfhj2EGgGyUqf8l3ZT\\/H+s2QoNEkTa\\/yOj7x5Qaz9byi6CSESwZjFFKpXQIo1sIOu8g+9lgllPasA9jwNfrqS9eYR67p6AZSw==\"}";
		httpPost.addHeader("content-type", "application/json");
		httpPost.addHeader("x-ip", "10.53.37.252");
		httpPost.addHeader("x-usuario", "MSOMOC");
		httpPost.addHeader("x-contrasenia", "U2VndXJpZGFkTU9DTVNPNjk5Ni4=");
		httpPost.addHeader("x-idPlataforma","B");
		httpPost.addHeader("Authorization", "Basic " + base64Credentials);
		httpPost.setEntity(new StringEntity(jsonRequest, UTF8_CHARSET));
		System.out.println(httpPost.getMethod());

		HttpResponse response = httpclient.execute(httpPost);
		System.out.println(response.getParams().toString());
		StringWriter writer = new StringWriter();
		IOUtils.copy(response.getEntity().getContent(), writer);
		System.out.println(">>>>>>>>>>>>>>>>>>>> IOUtils.copy " + writer.toString());

		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			@Override
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			@Override
			public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {

			}

			@Override
			public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {

			}
		} };

		// Create all-trusting host name verifier
		HostnameVerifier allHostsValid = new HostnameVerifier() {
			@Override
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		};

		try {
			// Install the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			// Install the all-trusting host verifier
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		} catch (Exception ex) {
			ex.printStackTrace();
		}


		URL url = new URL("https://10.53.37.252:8543/CotizadorConsumoTel/credito_cobranza/credito/v1/Cotizador/Cotizar");
		HttpURLConnection connection = (HttpsURLConnection) url.openConnection();
		connection.setRequestMethod("POST");
		connection.setDoOutput(true);
		connection.setRequestProperty("content-type", "application/json");
		connection.setRequestProperty("x-ip", "10.53.37.252");
		connection.setRequestProperty("x-usuario", "MSOMOC");
		connection.setRequestProperty("x-contrasenia", "U2VndXJpZGFkTU9DTVNPNjk5Ni4=");
		connection.setRequestProperty("x-idPlataforma","B");
		connection.addRequestProperty("Authorization", "Basic " + base64Credentials);

		OutputStream os = connection.getOutputStream();
		os.write(jsonRequest.getBytes("UTF-8"));
		os.flush();
		connection.connect();

		// Convert the response into a String object.
		String responseContent = parseResponse(connection.getInputStream());

		org.json.JSONObject parsedObject = new org.json.JSONObject(responseContent);
		System.out.println(parsedObject);
		
		return writer.toString();
	}

	static String parseResponse(InputStream in) throws Exception {
		InputStreamReader inputStream = new InputStreamReader(in, "UTF-8");
		BufferedReader buff = new BufferedReader(inputStream);

		StringBuilder sb = new StringBuilder();
		String line = buff.readLine();
		while (line != null) {
			sb.append(line);
			line = buff.readLine();
		}

		return sb.toString();
	}

}