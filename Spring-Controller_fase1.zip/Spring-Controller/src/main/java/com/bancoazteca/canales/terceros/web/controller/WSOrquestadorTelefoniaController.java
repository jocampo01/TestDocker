package com.bancoazteca.canales.terceros.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.JsonViewRequestBodyAdvice;

import com.bancoazteca.canales.terceros.web.model.ClasificacionTipoCliente;
import com.bancoazteca.canales.terceros.web.servicios.ConsumirAPIClasificacionTelefonia;
import com.bancoazteca.canales.terceros.web.servicios.ConsumirAPICotizadorTelefonia;
import com.bancoazteca.canales.terceros.web.servicios.ConsumirAPIObtenerDatosLCR;
import com.bancoazteca.canales.terceros.web.servicios.ConsumirAPIPresupuesto;

import javax.ws.rs.core.MediaType;

@RestController
public class WSOrquestadorTelefoniaController {


	@Autowired
	ConsumirAPIClasificacionTelefonia consumirAPIClasificacionTelefonia;
	@Autowired
	ConsumirAPICotizadorTelefonia consumirAPICotizadorTelefonia;
	@Autowired
	ConsumirAPIObtenerDatosLCR consumirAPIObtenerDatosLCR;
	@Autowired
	ConsumirAPIPresupuesto consumirAPIPresupuesto;
	
	@RequestMapping(value="/test", method=RequestMethod.GET)
	public @ResponseBody String healthCheck() {
		return "OK";
	}
	
	@RequestMapping(value="/obtenerClasificacionTelefonia",method=RequestMethod.POST,produces = { MediaType.APPLICATION_JSON })
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<String> obtenerClasificacionTelefonia(@Validated @RequestBody ClasificacionTipoCliente clasificacionTipoCliente) {
		String jsonResponse  = null;
		try {
			jsonResponse = consumirAPIClasificacionTelefonia.obtenerClasificacionTipoCliente();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok().body(jsonResponse);
	}

	@RequestMapping(value="/obtenerDatosLCR",method=RequestMethod.POST,produces = { MediaType.APPLICATION_JSON })
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<String>  obtenerDatosLCR(@Validated @RequestBody ClasificacionTipoCliente clasificacionTipoCliente) {
		String jsonResponse = null;
		try {
			jsonResponse = consumirAPIObtenerDatosLCR.obtenerDatosLCR();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok().body(jsonResponse);
	}

	@RequestMapping(value="/obtenerCotizacionTelefonia",method=RequestMethod.POST,produces = { MediaType.APPLICATION_JSON })
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<String>  obtenerCotizacionTelefonia(@Validated @RequestBody ClasificacionTipoCliente clasificacionTipoCliente) {
		String jsonResponse = null;
		try {
			jsonResponse = consumirAPICotizadorTelefonia.obtenerCotizacionTelefonia();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok().body(jsonResponse);
	}
	
	@RequestMapping(value="/obtenerPresupuestoTelefonia",method=RequestMethod.POST,produces = { MediaType.APPLICATION_JSON })
	@ResponseStatus(HttpStatus.OK)
	@ResponseBody
	public ResponseEntity<String>  obtenerPresupuestoTelefonia(@Validated @RequestBody ClasificacionTipoCliente clasificacionTipoCliente) {
		String jsonResponse = null;
		try {
			jsonResponse = consumirAPIPresupuesto.obtenerPresupuestoTelefonia();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ResponseEntity.ok().body(jsonResponse);
	}

}