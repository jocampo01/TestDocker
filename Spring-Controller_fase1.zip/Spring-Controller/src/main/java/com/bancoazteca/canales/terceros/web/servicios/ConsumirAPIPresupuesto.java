package com.bancoazteca.canales.terceros.web.servicios;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Base64;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.stereotype.Component;

@SuppressWarnings("deprecation")
@Component
public class ConsumirAPIPresupuesto {

	private static final Charset UTF8_CHARSET = Charset.forName("UTF-8");
	static String str_response = "";
	static String line = "";
	static String jsonRequest="";
	
	public String obtenerPresupuestoTelefonia() throws Exception {

		CredentialsProvider credentialsPovider = new BasicCredentialsProvider();
		String client_id = "tUJeAyc6iUflGDRmO9ClRT5BCcXRc2II";
		String client_secret = "hja8mrbnKWwlugbV";

		AuthScope scope = new AuthScope("https://10.82.57.113:8084/PresupuestoConsumo/credito_cobranza/credito/v1/Presupuestar",80);

		Credentials credentials = new UsernamePasswordCredentials("tUJeAyc6iUflGDRmO9ClRT5BCcXRc2II","hja8mrbnKWwlugbV");
		credentialsPovider.setCredentials(scope, credentials);

		HttpClientBuilder clientbuilder = HttpClients.custom();

		clientbuilder = clientbuilder.setDefaultCredentialsProvider(credentialsPovider);
		SSLContextBuilder builder = new SSLContextBuilder();
		builder.loadTrustMaterial(null, new TrustSelfSignedStrategy());
		SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(builder.build());
		Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create().register("http", new PlainConnectionSocketFactory()).register("https", sslsf).build();
		PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry);
		cm.setMaxTotal(2000);

		CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(sslsf).setConnectionManager(cm).build();

		HttpPost httpPost = new HttpPost("https://10.82.57.113:8084/PresupuestoConsumo/credito_cobranza/credito/v1/Presupuestar");
		String base64Credentials = Base64.getEncoder().encodeToString((client_id + ":" + client_secret).getBytes());
		jsonRequest = "{\"venta\": {\"idPais\": 1,   \"idCanal\": 1,    \"idSucursal\": 100  },  \"idModalidad\": \"TL\", \"clienteUnico\": {\"idPais\": 1,\"idCanal\": 1, \"idSucursal\": 2244,\"folio\": 107147 }, \"idTipoCliente\": 9,  \"opcionPagos\": {    \"idPeriodicidad\": 1,    \"idOferta\": 3,    \"plazo\": 48,    \"abonoPuntual\": 56,    \"abonoNormal\": 66,    \"ultimoAbono\": 48,    \"montoEnganche\": 0,    \"abonoPlan\": 0,    \"disponible\": true  },  \"productos\": [    { \"sku\": 151515,      \"idPromocion\": 3,      \"enganche\": 0,      \"cantidad\": 1,      \"precio\": 2000,      \"descuentoEkt\": 100,      \"descuentoBaz\": 0,      \"idCategoria\": 1,      \"plan\": false    }  ],  \"pedidosRenovacion\": [    {      \"idCanal\": 1,      \"idSucursal\": 4856,      \"idPedido\": 48756,      \"abonoPuntual\": 125,      \"liquidacion\": 1000    }  ],  \"lineaCredito\": \"8bGB4s+k2nLWJh/V5hPVs1oE63ke1D9RS12ubyu0LKQXufF49TZqa+/K6DR1yItYCPV2Wq7gPS8G30IZa4vJECyUTK4QoBR6FYgA6+8UfegYCDkzat7JuclNJ+drarJE7broKQUvrbfflZo9cVKiOe/FinwYqA7OIBkCfZ1QOWQ5wpsTvd0eV46ZPNSclyYNsbA/VO+xhfznaAUM0swTyTaBpJLFXPzi+ihJSAeowjweX0W1Zj5FbzpnkrLU796kTo05bak51ds20W+jXiOkVUW2n2516QYvUtjlYL6PmjcgoPmzkRBPDccYfi1hAU4btUWGNTy8CpaXJ+XJ0YK/5H/+2unD3YlOB+KvmxxLU8TvvnPxFD1AAmX6773B2kSy0F22ErAEqkiWP9c4elsxB92s3yixNNZyctE8gKwNZVTHC/wkxk88yCkBwR7kxeanMWs8jHSoeVFxVBqIwry1/yu5fJIjWs7cfu9jvkt+bt8cK7+CE1v3VfeX/FutbeuEA81XWRyvQui9iYXMelDFWCZyS6QwvSEcZzth44qNdKjNAx12LeuuhBfKEyfKo4RjOJs8h0iaartVUqA6bXZZ9e53JDgAnffgpcvM/7fvw33ahP1+sMhohCGZxDyud0YHCIeClouTfokRJNapuWXnLeFAlLIfhvPpErjfBEyZ8vmzzjcBAEYzm8KowxjzYuPk3yuZtF3+En07All2rNfhnyi9o+9iu+qrQi0b/ocexUAYO46Fj1RoTWPAdITLos4gyIvNymHJCPJi9E917aAmDonJP0VGlkoLmEn/kBa337q/uL2yrERlOT9pcY7mydXCWEpEiTH0fJNBhfSJqqlNLkLwcE4UFT162TxcMwyBQqVi9T16B8Ll90rsPOqJpqB7BUzxrrB2mcuOng2/1TxwhXhT09/1n7GBQwKzqOM0Pzjysjb5Uo5ZE8gPFViCo0UbDEAebN0VPVbk/exwRJuyPHfYvFLqUYo9D8fiHOzaW5EL7Ruq1aHW3di0rxiC3rddPn6KWfsLibU4EQMyrjSmtCOFhDzI7zNASZPFy8gcxmBW1nGm68r0M6EI7LsrdGTxcCKraa0Q1IVqkJz6CghkJ4yb4mAffAbF3H86g5d9IzYv631lNGoDR1w3KiqfGUiKnKk9KvvfgUHK/LfXiWeFUqPtjqGC04jNUNSBaebLzNzjc17q5HcW+FxvhUuWAcAJH85hMOUrvCC6vrnT0BsIv5GnlxyilZMlu2Car3mV5MSBUTZ9oRfkL8kllIU5qysM3yVLYyZFYsvpMhJfX+VZ1BJ12JetXwBJZvdvreSNkzy2pv3xdUNp4PXfy5HnaeQNGt7/yirwk9ADslPio3uSeQK1tvOpeJ3RhNj7W+jZvk2mk4WKgjowFYvOPyigHkOBYNjry/pbxhC/AX9Gl19pkh2pGrntJVQPTz7TYtph5cvQ5lmNN5s0s5VPBjHkcOmtSQJDy/Re9MGA/KX8PmAm5fLaaBfawgy/9TO4pK7Amq/ysSawYZSOax7ho+bVeDIzo1y5kUQLdzE18b1YKiTQfQ4PydObq34p0Z5MgFYUtfIj88LnDqcVrH9uQenq1ftUTFW7DMvUfXA6t0NDE1UssrWrb/5gZfHaUWr1V9j2k/3nddznYYO6CBG+atLp7IxKGyZjkwLTY0/opRaA01r4XcGjf56fzXFyeo69AWN9zWR9xyaaLuF+Q9u3lRNKdCx4VpKcrypkVcjHbQXkDSVwBnFYCzvGPMqo2rMzECdxt1RhS9xH/qUgfXwppk8Vv4Ikt2EZSurc3mM6qUOeVSL3UIqEB4h4GCrlr1e8nJ0VwuGEKat+bKKofu9A1H5IoI2YJ0+rH7VB7gXvPH0WZNv40cy8E7TmEPyhVHDW6Ce91mUEtnlIL7CzcXWjZktN0DaOLlzEpm2odFpSUrMCOFatOYSwMwixo6XLcXIZ0wdOWQNNzqm97YOX3qA2mTaSpbUJDRP9dJFzpCTJg0DNBnJ8FJ9GikPbWqBCxzTNioJ3uit6cgza56FW0lQ94SyMgFe6oE9bkwgr8g0CkWFTgue8N/TQqwcvKbBOscJOPNWAFgn1BW/EmRdqhTHykBaS6649XcyxQz0GoKAbG09pk1QV26KwMODyEk9HArsdH9JIzR53VTlLF4WylqL2nHy4IrUQHK4UCGpG/y0J6cucMR9zWF2I4mUejtfTv18PG9nR5DKkTJlc8B0uu3H33BzpDuP9jxVq/QxM697yPqRRMSo5X7Cvq1h7fEMY4Zje/wy0JSKCq5JBJGesG0aGljuNJ0KgupueXrJmUQDk0LMEpCopOA9B0V5cDCCrmtdZLzeDFR4zxXZcyS12EcpsHNaE2h414O8tGuSm4oet/l27CKgG3CKd5Kv64HfU+Bi1lnFJgI2VoMfSYvREU6YQ9wmTeivITGXkWiqMI7pkBqbv+cN3ZbErrX7UHM/Cresi++9Mbz51BDXRn20L7EdJPAISSaXUGmpXQgFoFndc4pPNWgPhFKuOiriA2jm6Lf7gquppmuRBgjCGQEvu4boUyMJDq7XX1ksugGRdQXOQ9Qzql33H3uaNq+5ZZlIu/6NWcyipM4jwFHJYLJPc4HAHJ1CrzbfDyQmdYCAMfOpCYU0j5hgFxZq+5s/uFcUnZAEUJz1Xo/jBEFykqU9pYkZs7swNiYnPLzoPuQxL4NtONzx9Vq8QtaN2jDjgmaRGp7DGSxtVtTLx74OZgbKCQDVvsM7+Q7KlWiJKl5G6l5PBR8pmv2jmEbfoZEqcFpVPr25LT7vHZoFOjtZndkrdyhzFa5URQqw0AxLSKQNlhCwa8AAoqE8MaFmknm7M1RmaBZu6EagVxN7i66+XruHuOd1Lk/iUZHdi\"}";
		httpPost.addHeader("content-type", "application/json");
		httpPost.addHeader("x-ip", "10.53.37.252");
		httpPost.addHeader("x-usuario", "MSOMOC");
		httpPost.addHeader("x-contrasenia", "U2VndXJpZGFkTU9DTVNPNjk5Ni4=");
		httpPost.addHeader("x-idPlataforma","B");
		httpPost.addHeader("Authorization", "Basic " + base64Credentials);
		httpPost.setEntity(new StringEntity(jsonRequest, UTF8_CHARSET));
		System.out.println(httpPost.getMethod());

		HttpResponse response = httpclient.execute(httpPost);
		System.out.println(response.getParams().toString());
		StringWriter writer = new StringWriter();
		IOUtils.copy(response.getEntity().getContent(), writer);
		System.out.println(">>>>>>>>>>>>>>>>>>>> IOUtils.copy " + writer.toString());

		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			@Override
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			@Override
			public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {

			}

			@Override
			public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {

			}
		} };

		// Create all-trusting host name verifier
		HostnameVerifier allHostsValid = new HostnameVerifier() {
			@Override
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		};

		try {
			// Install the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			// Install the all-trusting host verifier
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		} catch (Exception ex) {
			ex.printStackTrace();
		}


		URL url = new URL("https://10.82.57.113:8084/PresupuestoConsumo/credito_cobranza/credito/v1/Presupuestar");
		HttpURLConnection connection = (HttpsURLConnection) url.openConnection();
		connection.setRequestMethod("POST");
		connection.setDoOutput(true);
		connection.setRequestProperty("content-type", "application/json");
		connection.setRequestProperty("x-ip", "10.53.37.252");
		connection.setRequestProperty("x-usuario", "MSOMOC");
		connection.setRequestProperty("x-contrasenia", "U2VndXJpZGFkTU9DTVNPNjk5Ni4=");
		connection.setRequestProperty("x-idPlataforma","B");
		connection.addRequestProperty("Authorization", "Basic " + base64Credentials);

		OutputStream os = connection.getOutputStream();
		os.write(jsonRequest.getBytes("UTF-8"));
		os.flush();
		connection.connect();

		// Convert the response into a String object.
		String responseContent = parseResponse(connection.getInputStream());

		org.json.JSONObject parsedObject = new org.json.JSONObject(responseContent);
		System.out.println(parsedObject);
		
		return writer.toString();
	}

	static String parseResponse(InputStream in) throws Exception {
		InputStreamReader inputStream = new InputStreamReader(in, "UTF-8");
		BufferedReader buff = new BufferedReader(inputStream);

		StringBuilder sb = new StringBuilder();
		String line = buff.readLine();
		while (line != null) {
			sb.append(line);
			line = buff.readLine();
		}

		return sb.toString();
	}

}