package com.bancoazteca.canales.terceros.web.servicios;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:config.properties")
public class UserProperties {

	@Value("${name}")
	private String name;
	@Value("${age}")
	private int age;
	@Value("${jobTitle}")
	private String jobTitle;
	@Value("${company}")
	private String company;
	@Value("${location}")
	private String location;

	// Generate Getters and Setters...

	@Override
	public String toString() {
		return "UserProperties [name=" + name + ", age=" + age + ", jobTitle=" + jobTitle + ", company=" + company
				+ ", location=" + location + "]";
	}
}