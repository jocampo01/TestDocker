﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WSCargaClienteSurtimiento.Modelo;
using Banco.PD3.Persistence;
using Banco.PD3.Persistence.Entities;
using System.Data.SqlClient;
using WSCargaClienteSurtimiento.Implementacion;

namespace WSCargaClienteSurtimiento.Controllers
{
    public class WSCargaClienteSurtimientoController : ApiController
    {

        CargaClienteSurtimientoImpl CargaClienteSurtimiento = new CargaClienteSurtimientoImpl();

        [HttpPost]
        public HttpResponseMessage cargaPresupuestosValidos([FromBody] DatosEntrada datosDeEntrada)
        {
            var respuesta = CargaClienteSurtimiento.consultaPresupuestosValidos(datosDeEntrada);
            return Request.CreateResponse((HttpStatusCode)(Convert.ToInt64(respuesta.codigo.Split('.')[0])), respuesta);

        }

        [HttpPost]
        public HttpResponseMessage cargaDetallePresupuesto([FromBody] string datosEntradaDetalle)
        {
            var respuesta = CargaClienteSurtimiento.consultaDetalleClientePresupuesto(datosEntradaDetalle);
            return Request.CreateResponse((HttpStatusCode)(Convert.ToInt64(respuesta.codigo.Split('.')[0])), respuesta);

        }



        [HttpGet]
        public string test()
        {
            return "Graba Presupuesto y validacion del recompras";

        }

    }
}