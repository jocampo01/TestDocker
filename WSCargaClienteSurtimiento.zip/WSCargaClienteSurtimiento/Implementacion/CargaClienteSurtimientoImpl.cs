﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Banco.PD3.Persistence;
using Banco.PD3.Persistence.Entities;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;

using System.Text;
using System.IO;

using Banco.PD3.Persistence.Enums;
using PD3.Utilities;
using System.Data;
using WSCargaClienteSurtimiento.Modelo;
using System.Collections;
using System.Globalization;
using WSCargaClienteSurtimiento.Interfaz;

namespace WSCargaClienteSurtimiento.Implementacion
{
    public class CargaClienteSurtimientoImpl : CargaClienteSurtimientoIT
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger("BackLogs");
        Resultado resultado = new Resultado();

        public Respuesta consultaPresupuestosValidos(DatosEntrada datosEntrada)
        {
            Respuesta Respuesta = new Respuesta();
            ConexionPD3 conexionPD3 = new ConexionPD3();
            PD3Connection conexion = new PD3Connection();
            conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
            SqlPersister persistence = new SqlPersister(conexion);
            conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
            persistence = new SqlPersister(conexion);

            List<DBParameter> dbparameterList = new List<DBParameter>();

            dbparameterList.Add(new DBParameter()
            {
                Name = "@piPais",
                ParamDbType = ParamDbType.Int,
                ParamDirection = ParamDirection.Input,
                Value = datosEntrada.paisClienteUnico
            });


            dbparameterList.Add(new DBParameter()
            {
                Name = "@piCanal",
                ParamDbType = ParamDbType.Int,
                ParamDirection = ParamDirection.Input,
                Value = datosEntrada.canalClienteUnico
            });

            dbparameterList.Add(new DBParameter()
            {
                Name = "@piSucursal",
                ParamDbType = ParamDbType.Int,
                ParamDirection = ParamDirection.Input,
                Value = datosEntrada.sucursalClienteUnico
            });

            dbparameterList.Add(new DBParameter()
            {
                Name = "@piFolio",
                ParamDbType = ParamDbType.Int,
                ParamDirection = ParamDirection.Input,
                Value = datosEntrada.folioClienteUnico
            });

            dbparameterList.Add(new DBParameter()
            {
                Name = "@piSucuGes",
                ParamDbType = ParamDbType.Int,
                ParamDirection = ParamDirection.Input,
                Value = datosEntrada.sucursalGestora
            });

            SqlDataReader sql = persistence.StoredProcedureToDataReader("PACRLLPresupCU", dbparameterList);

            while (sql.Read())
            {
                resultado.folioPreparametrico = Convert.ToString(sql.GetValue(0));
                resultado.negocioID = Convert.ToString(sql.GetValue(1));
                resultado.numeroTienda = Convert.ToString(sql.GetValue(2));
                resultado.clienteID = Convert.ToString(sql.GetValue(3));
                resultado.digitoVerificador = Convert.ToString(sql.GetValue(4));
                resultado.tipoVenta = Convert.ToString(sql.GetValue(5));
                resultado.numeroEmpleado = Convert.ToString(sql.GetValue(6));
                resultado.numeroPlazo = Convert.ToString(sql.GetValue(7));
                resultado.periodo = Convert.ToString(sql.GetValue(8));
                resultado.pagoAbonoNormal = Convert.ToString(sql.GetValue(9));
                resultado.pagoUltimoAbono = Convert.ToString(sql.GetValue(10));
                resultado.fechaPresupuesto = Convert.ToString(sql.GetValue(11));
            }

            return new Respuesta()
            {
                codigo = "200.WSCargaClienteSurtimiento",
                folio = "200",
                mensaje = "Presupuestos Validos -- ",
                resultado = resultado
            };
        }



        public Respuesta consultaDetalleClientePresupuesto(string folioPreparametrico)
        {
            Respuesta Respuesta = new Respuesta();
            ConexionPD3 conexionPD3 = new ConexionPD3();
            PD3Connection conexion = new PD3Connection();
            conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
            SqlPersister persistence = new SqlPersister(conexion);
            conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
            persistence = new SqlPersister(conexion);



            List<DBParameter> dbparameterList = new List<DBParameter>();
            List<TransactionalEntity> transactionalentityList = new List<TransactionalEntity>();
            dbparameterList.Add(new DBParameter()
            {
                Name = "@piPresup",
                ParamDbType = ParamDbType.Int,
                ParamDirection = ParamDirection.Input,
                Value = 170267
            });

            //transactionalentityList.Add(new TransactionalEntity(persistence)
            //{
            //    ExecutionType = ExecutionType.StoredProcedure,
            //    Script = "PACRLLPresupDetCU",
            //    DbParameters = dbparameterList
            //});

            //TransactionalManager transactionalmanager = new TransactionalManager(false);
            //TransactionalResultSet transactionalresultset;
            //transactionalresultset = transactionalmanager.TransactionalFlow(transactionalentityList);
            //DataSet ds1 = transactionalresultset.ResultSetColleccion[0].ResultDataSet;

            //DataSet ds2 = transactionalresultset.ResultSetColleccion[1].ResultDataSet;

            DataSet dSet = null;
            dSet = persistence.StoredProcedureToDataSet("PACRLLPresupDetCU", dbparameterList);
            DataTable[] dataTables = new DataTable[3];
            DataTable tabla1 = new DataTable("preparametrico");
            DataTable tabla2 = new DataTable("detalle_preparametrico");
            DataTable tabla3 = new DataTable("TACRLPromocionProntoPago");
            dataTables[0] = tabla1;
            dataTables[1] = tabla2;
            dataTables[2] = tabla3;

            DataTableReader sql = dSet.CreateDataReader(dataTables);
            DataTable dataTableReader = sql.GetSchemaTable();
            dataTableReader.CreateDataReader();

            //  Datos preparametrico
            var NofolioPreparametrico = dSet.Tables[0].Rows[0][0];
            var negocioID = dSet.Tables[0].Rows[0][1];
            var numeroTienda = dSet.Tables[0].Rows[0][2];
            var noClienteID = dSet.Tables[0].Rows[0][3];
            var digitoVerificador = dSet.Tables[0].Rows[0][4];
            var tipoDeVenta = dSet.Tables[0].Rows[0][5];
            var numEmpleado = dSet.Tables[0].Rows[0][6];
            var noPlazo = dSet.Tables[0].Rows[0][7];
            var periodicidad = dSet.Tables[0].Rows[0][8];
            var abonoNormal = dSet.Tables[0].Rows[0][9];
            var fechaPresupuesto = dSet.Tables[0].Rows[0][10];

            //  Datos promocionProntoPago
            var fechapromocion = dSet.Tables[2].Rows[0][1];
            var abonoPagoPuntual = dSet.Tables[2].Rows[0][2];
            var porcentajeDescuento = dSet.Tables[2].Rows[0][3];

            //  Datos promocionProntoPago
            var paisClienteUnico = dSet.Tables[2].Rows[0][1];
            var canalClienteUnico = dSet.Tables[2].Rows[0][2];
            var porcentajeDescuento = dSet.Tables[2].Rows[0][3];


            while (sql.Read())
            {
                resultado.folioPreparametrico = Convert.ToString(sql.GetValue(0));
                resultado.negocioID = Convert.ToString(sql.GetValue(1));
                resultado.folioPreparametrico = Convert.ToString(sql.GetValue(0));
                resultado.negocioID = Convert.ToString(sql.GetValue(1));
                resultado.numeroTienda = Convert.ToString(sql.GetValue(2));
                resultado.clienteID = Convert.ToString(sql.GetValue(3));
                resultado.digitoVerificador = Convert.ToString(sql.GetValue(4));
                resultado.tipoVenta = Convert.ToString(sql.GetValue(5));
                resultado.numeroEmpleado = Convert.ToString(sql.GetValue(6));
                resultado.numeroPlazo = Convert.ToString(sql.GetValue(7));
                resultado.periodo = Convert.ToString(sql.GetValue(8));
                resultado.pagoAbonoNormal = Convert.ToString(sql.GetValue(9));
                resultado.pagoUltimoAbono = Convert.ToString(sql.GetValue(10));
                resultado.fechaPresupuesto = Convert.ToString(sql.GetValue(11));

            }

            return new Respuesta()
            {
                codigo = "200.WSCargaClienteSurtimiento",
                folio = "200",
                mensaje = "Presupuestos Validos -- ",
                resultado = resultado
            };
        }


        public Respuesta consultaDetalleClientePresupuesto(DatosEntrada DatosEntrada)
        {
            throw new NotImplementedException();
        }
    }
}