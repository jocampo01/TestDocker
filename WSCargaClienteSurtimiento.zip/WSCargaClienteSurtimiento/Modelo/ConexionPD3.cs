﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSCargaClienteSurtimiento.Modelo
{
    public class ConexionPD3
    {

        //TODO: obtener id entorno de otra parte, pude ser del web config
        /// <summary>
        /// 0 es desarrollo, 1 es QA y 2 es produccion. cambiar este valor cuando ya no este en desarrollo
        /// </summary>
        private int entorno = 0;

        public readonly int Desarrollo = 0;
        public readonly int QA = 1;
        public readonly int Produccion = 2;

        //private String pathCerts = "E:\\ADN\\NET64_BAZ\\Certs";
        /// <summary>
        /// certificados para desarrollo.
        /// </summary>
        private String pathCerts = "E:\\ADN\\NET64_BAZ\\Certs";

        private String fileName = "ekt-5de08474-aa2a-4341-aff3-ec9c3b37dec4.pd3";

        public String getPathCerts()
        {

            ConexionPD3 conexionPD3 = new ConexionPD3();

            if (conexionPD3.getEntorno() == Desarrollo)
            {
                return this.pathCerts;
            }
            else
            {
                String str = "201910311804-certificados de qa y desarrollo";
                throw new InvalidOperationException(str);
            }

        }

        public String getFileName()
        {
            return fileName;
        }

        public int getEntorno()
        {
            return entorno;
        }

    }
}