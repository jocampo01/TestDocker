﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSCargaClienteSurtimiento.Modelo
{
    public class DatosEntrada
    {
        public int paisClienteUnico { get; set; }
        public int canalClienteUnico { get; set; }
        public int sucursalClienteUnico { get; set; }
        public int folioClienteUnico { get; set; }
        public int sucursalGestora { get; set; }

    }
}

