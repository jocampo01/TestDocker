﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSCargaClienteSurtimiento.Modelo
{
    public class Resultado
    {
        public string folioPreparametrico { get; set; }

        public string negocioID { get; set; }

        public string numeroTienda { get; set; }

        public string clienteID { get; set; }

        public string digitoVerificador { get; set; }

        public string tipoVenta { get; set; }

        public string numeroEmpleado { get; set; }

        public string numeroPlazo { get; set; }

        public string periodo { get; set; }

        public string pagoAbonoNormal { get; set; }

        public string pagoUltimoAbono { get; set; }

        public string fechaPresupuesto { get; set; }
    }
}