﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WSGeneraCodigoBarras.Modelo;
using Banco.PD3.Persistence;
using Banco.PD3.Persistence.Entities;
using System.Data.SqlClient;


namespace WSCargaClienteSurtimiento.Controllers
{
    public class WSGeneraCodigoBarrasController : ApiController
    {

        GeneraCodigoBarrasImpl generaCodigoBarrasImpl = new GeneraCodigoBarrasImpl();

        [HttpPost]
        public HttpResponseMessage GenerarCodigoBarras([FromBody]DatosEntrada DatosEntrada)
        {
            var Respuesta = generaCodigoBarrasImpl.generaCodigoBarras(DatosEntrada);
            int codigohttp = Convert.ToUInt16(Respuesta.codigo.Split('.')[0]);
            return Request.CreateResponse((HttpStatusCode)codigohttp, Respuesta);
        }

        [HttpGet]
        public string test()
        {
            return "Carga Datos Cliente";

        }

    }
}
