﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Banco.PD3.Persistence;
using Banco.PD3.Persistence.Entities;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;

using System.Text;
using System.IO;

using Banco.PD3.Persistence.Enums;
using PD3.Utilities;
using System.Data;
using WSCargaClienteSurtimiento.Modelo;
using System.Collections;
using System.Globalization;
using WSCargaClienteSurtimiento.Interfaz;

namespace WSCargaClienteSurtimiento.Implementacion
{
    public class CargaClienteSurtimientoImpl : CargaClienteSurtimientoIT
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger("BackLogs");


        public Respuesta consultaPresupuestosValidos(DatosEntrada datosEntrada)
        {
            Respuesta Respuesta = new Respuesta();
            ConexionPD3 conexionPD3 = new ConexionPD3();
            PD3Connection conexion = new PD3Connection();
            conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
            SqlPersister persistence = new SqlPersister(conexion);
            conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
            persistence = new SqlPersister(conexion);
            Resultado resultado = new Resultado();
            List<DBParameter> dbparameterList = new List<DBParameter>();

            dbparameterList.Add(new DBParameter()
            {
                Name = "@piPais",
                ParamDbType = ParamDbType.Int,
                ParamDirection = ParamDirection.Input,
                Value = datosEntrada.paisClienteUnico
            });


            dbparameterList.Add(new DBParameter()
            {
                Name = "@piCanal",
                ParamDbType = ParamDbType.Int,
                ParamDirection = ParamDirection.Input,
                Value = datosEntrada.canalClienteUnico
            });

            dbparameterList.Add(new DBParameter()
            {
                Name = "@piSucursal",
                ParamDbType = ParamDbType.Int,
                ParamDirection = ParamDirection.Input,
                Value = datosEntrada.sucursalClienteUnico
            });

            dbparameterList.Add(new DBParameter()
            {
                Name = "@piFolio",
                ParamDbType = ParamDbType.Int,
                ParamDirection = ParamDirection.Input,
                Value = datosEntrada.folioClienteUnico
            });

            dbparameterList.Add(new DBParameter()
            {
                Name = "@piSucuGes",
                ParamDbType = ParamDbType.Int,
                ParamDirection = ParamDirection.Input,
                Value = datosEntrada.sucursalGestora
            });

            SqlDataReader sql = persistence.StoredProcedureToDataReader("PACRLLPresupCU", dbparameterList);
            DatosPreparametrico datosPreparametrico = new DatosPreparametrico();
            while (sql.Read())
            {
                datosPreparametrico.folioPreparametrico = Convert.ToString(sql.GetValue(0));
                datosPreparametrico.negocioID = Convert.ToString(sql.GetValue(1));
                datosPreparametrico.numeroTienda = Convert.ToString(sql.GetValue(2));
                datosPreparametrico.clienteID = Convert.ToString(sql.GetValue(3));
                datosPreparametrico.digitoVerificador = Convert.ToString(sql.GetValue(4));
                datosPreparametrico.tipoVenta = Convert.ToString(sql.GetValue(5));
                datosPreparametrico.numeroEmpleado = Convert.ToString(sql.GetValue(6));
                datosPreparametrico.numeroPlazo = Convert.ToString(sql.GetValue(7));
                datosPreparametrico.periodo = Convert.ToString(sql.GetValue(8));
                datosPreparametrico.pagoAbonoNormal = Convert.ToString(sql.GetValue(9));
                datosPreparametrico.pagoUltimoAbono = Convert.ToString(sql.GetValue(10));
                datosPreparametrico.fechaPresupuesto = Convert.ToString(sql.GetValue(11));
            }

            return new Respuesta()
            {
                codigo = "200.WSCargaClienteSurtimiento",
                folio = "200",
                mensaje = "Presupuestos Validos -- ",
                resultado = resultado
            };
        }



        public Respuesta consultaDetalleClientePresupuesto(ConsultaFolioPreparametrico consultaFolioPreparametrico)
        {
            Respuesta Respuesta = new Respuesta();
            ConexionPD3 conexionPD3 = new ConexionPD3();
            PD3Connection conexion = new PD3Connection();
            conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
            SqlPersister persistence = new SqlPersister(conexion);
            conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
            persistence = new SqlPersister(conexion);


            Resultado resultado = new Resultado();
            List<DBParameter> dbparameterList = new List<DBParameter>();
            List<TransactionalEntity> transactionalentityList = new List<TransactionalEntity>();
            dbparameterList.Add(new DBParameter()
            {
                Name = "@piPresup",
                ParamDbType = ParamDbType.Int,
                ParamDirection = ParamDirection.Input,
                Value = consultaFolioPreparametrico.folioPreparametrico
            }); ;



            DataSet datasetDetallePreparametrico = null;
            datasetDetallePreparametrico = persistence.StoredProcedureToDataSet("PACRLLPresupDetCU", dbparameterList);


            /*Consulta la tabla de preparametrico*/
            DataTable dataTablePreparametrico = datasetDetallePreparametrico.Tables[0];

            DataTableReader dataReaderPreparametrico = dataTablePreparametrico.CreateDataReader();
            DatosPreparametrico datosPreparametrico = new DatosPreparametrico();
            while (dataReaderPreparametrico.Read())
            {
                datosPreparametrico.folioPreparametrico = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosPreparametrico.negocioID = Convert.ToString(dataReaderPreparametrico.GetValue(1));
                datosPreparametrico.numeroTienda = Convert.ToString(dataReaderPreparametrico.GetValue(2));
                datosPreparametrico.clienteID = Convert.ToString(dataReaderPreparametrico.GetValue(3));
                datosPreparametrico.digitoVerificador = Convert.ToString(dataReaderPreparametrico.GetValue(4));
                datosPreparametrico.tipoVenta = Convert.ToString(dataReaderPreparametrico.GetValue(5));
                datosPreparametrico.numeroEmpleado = Convert.ToString(dataReaderPreparametrico.GetValue(6));
                datosPreparametrico.numeroPlazo = Convert.ToString(dataReaderPreparametrico.GetValue(7));
                datosPreparametrico.periodo = Convert.ToString(dataReaderPreparametrico.GetValue(8));
                datosPreparametrico.pagoAbonoNormal = Convert.ToString(dataReaderPreparametrico.GetValue(9));
                datosPreparametrico.pagoUltimoAbono = Convert.ToString(dataReaderPreparametrico.GetValue(10));
                datosPreparametrico.fechaPresupuesto = Convert.ToString(dataReaderPreparametrico.GetValue(11));

            }
            resultado.datosPreparametrico = datosPreparametrico;


            /*Consulta la tabla detalle preparametrico*/
            DataTable dataTableDetallePreparametrico = datasetDetallePreparametrico.Tables[1];

            DataTableReader dataReaderDetallePreparametrico = dataTablePreparametrico.CreateDataReader();
            DatosDetallePreparametrico datosDetallePreparametrico = null;
            List<DatosDetallePreparametrico> detallePreparametricoList = new List<DatosDetallePreparametrico>();
            while (dataReaderDetallePreparametrico.Read())
            {
                datosDetallePreparametrico = new DatosDetallePreparametrico();
                datosDetallePreparametrico.FolioParametrico = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.productoSkuBAZ = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.precioProducto = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.cantidadProducto = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.descuentoProducto = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.descuentoEspecial = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.sobreprecio = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.porcentajeIVA = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.descuentoMarket = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.costoProducto = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.statusPresupuesto = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.interesesProducto = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.engancheProducto = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.clavePromProducto = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.comisionV = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                datosDetallePreparametrico.comisionG = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detallePreparametricoList.Add(datosDetallePreparametrico);
            }
            resultado.datosDetallePreparametrico = detallePreparametricoList;
            /*Consulta la tabla promocion pronto pago*/
            DataTable dataTableProntoPago = datasetDetallePreparametrico.Tables[2];

            DataTableReader dataReaderProntoPago = dataTablePreparametrico.CreateDataReader();
            DetalleProntoPago detalleProntoPago = new DetalleProntoPago();
            while (dataReaderProntoPago.Read())
            {

                detalleProntoPago.folioPreparametrico = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleProntoPago.fechaPromocion = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleProntoPago.abonoPuntual = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleProntoPago.porcentajeDescuento = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleProntoPago.statusPromocion = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleProntoPago.numeroDePedido = Convert.ToString(dataReaderPreparametrico.GetValue(0));
            }

            resultado.detalleProntoPago = detalleProntoPago;

            /*Consulta la tabla liga Cliente LCR o Foraneo*/
            DataTable dataTableLigaClienteLCR = datasetDetallePreparametrico.Tables[2];

            DataTableReader dataReaderLigaClienteLCR = dataTablePreparametrico.CreateDataReader();
            DetalleLigaClienteLCR detalleLigaClienteLCR = new DetalleLigaClienteLCR();
            while (dataReaderLigaClienteLCR.Read())
            {

                detalleLigaClienteLCR.folioPresupuestoLCR = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiPaisCteU = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiCanalCteU = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiSucursalCteU = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiFolioCteU = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiNgcioIdEktGest = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiNoTiendaGest = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiCteIdGest = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiDigitoVerGest = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiNgcioIdEkt = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiNoTiendaEkt = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiCteIdEkt = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiDigitoVerEkt = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fcTarjeta = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fcHuella1 = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fcHuella1 = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fcHuella2 = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fcHuella3 = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fcHuella4 = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fcHuella5 = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.Nombre = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.EstaConxion = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.finocomprascredito = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiDomiciliacion = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiPaisAdicional = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiCanalAdicional = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiSucursalAdicional = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fiFolioAdicional = Convert.ToString(dataReaderPreparametrico.GetValue(0));
                detalleLigaClienteLCR.fcTarjetaAdicional = Convert.ToString(dataReaderPreparametrico.GetValue(0));
            }


            resultado.detalleLigaClienteLCR = detalleLigaClienteLCR;

            return new Respuesta()
            {
                codigo = "200.WSCargaClienteSurtimiento",
                folio = "200",
                mensaje = "Presupuestos Validos -- ",
                resultado = resultado
            };
        }


        public Respuesta consultaDetalleClientePresupuesto(DatosEntrada DatosEntrada)
        {
            throw new NotImplementedException();
        }
    }
}