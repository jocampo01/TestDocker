﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using WSCargaClienteSurtimiento.Modelo;
using Banco.PD3.Persistence;
using Banco.PD3.Persistence.Entities;
using System.Data.SqlClient;

namespace WSCargaClienteSurtimiento.Interfaz
{
    public interface CargaClienteSurtimientoIT
    {
        Respuesta consultaDetalleClientePresupuesto(DatosEntrada DatosEntrada);

        Respuesta consultaDetalleClientePresupuesto(ConsultaFolioPreparametrico consultaFolioPreparametrico);

    }
}