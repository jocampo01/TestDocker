﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSCargaClienteSurtimiento.Modelo
{
    public class ConsultaFolioPreparametrico
    {
      public  int folioPreparametrico { get; set; }
    }
}