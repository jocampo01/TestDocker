﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSCargaClienteSurtimiento.Modelo
{
    public class DatosDetallePreparametrico
    {
        public string FolioParametrico { get; set; }
        public string productoSkuBAZ { get; set; }
        public string precioProducto { get; set; }
        public string cantidadProducto { get; set; }
        public string descuentoProducto { get; set; }

        public string descuentoEspecial { get; set; }
        public string sobreprecio { get; set; }

        public string porcentajeIVA { get; set; }
        public string descuentoMarket { get; set; }
        public string costoProducto { get; set; }
        public string statusPresupuesto { get; set; }
        public string interesesProducto { get; set; }

        public string engancheProducto { get; set; }
        public string clavePromProducto { get; set; }
        public string comisionV { get; set; }
        public string comisionG { get; set; }


    }
}