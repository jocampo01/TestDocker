﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSCargaClienteSurtimiento.Modelo
{
    public class DetalleLigaClienteLCR
    {
        public string folioPresupuestoLCR { get; set; }
        public string fiPaisCteU { get; set; }

        public string fiCanalCteU { get; set; }

        public string fiSucursalCteU { get; set; }

        public string fiFolioCteU { get; set; }
        public string fiNgcioIdEktGest { get; set; }
        public string fiNoTiendaGest { get; set; }

        public string fiCteIdGest { get; set; }
        public string fiDigitoVerGest { get; set; }

        public string fiNgcioIdEkt { get; set; }

        public string fiNoTiendaEkt { get; set; }
        public string fiCteIdEkt { get; set; }

        public string fiDigitoVerEkt { get; set; }
        public string fcTarjeta { get; set; }
        public string fcHuella1 { get; set; }
        public string fcHuella2 { get; set; }
        public string fcHuella3 { get; set; }

        public string fcHuella4 { get; set; }

        public string fcHuella5 { get; set; }
        public string Nombre { get; set; }
        public string EstaConxion { get; set; }

        public string finocomprascredito { get; set; }
        public string fiDomiciliacion { get; set; }
        public string fiPaisAdicional { get; set; }

        public string fiCanalAdicional { get; set; }
        public string fiSucursalAdicional { get; set; }

        public string fiFolioAdicional { get; set; }
        public string fcTarjetaAdicional { get; set; }



    }
}