﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSCargaClienteSurtimiento.Modelo
{
    public class DetalleProntoPago
    {
        public string folioPreparametrico { get; set; }
        public string fechaPromocion { get; set; }

        public string abonoPuntual { get; set; }

        public string porcentajeDescuento { get; set; }

        public string statusPromocion { get; set; }
        public string numeroDePedido { get; set; }


    }
}