﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSCargaClienteSurtimiento.Modelo
{
    public class Resultado
    {

        public DatosPreparametrico datosPreparametrico { get; set; }

        public List<DatosDetallePreparametrico> datosDetallePreparametrico { get; set; }

        public DetalleProntoPago detalleProntoPago { get; set; }

        public DetalleLigaClienteLCR detalleLigaClienteLCR { get; set; }
    }
}