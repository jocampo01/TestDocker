﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WSGrabarPresupuesto.Modelo;
using Banco.PD3.Persistence;
using Banco.PD3.Persistence.Entities;
using System.Data.SqlClient;

namespace WSGrabarPresupuesto.Controllers
{
    public class GrabaPresupuestoController : ApiController
    {

        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        GrabaPresupuestoImpl grabaPresupuestoImpl = new GrabaPresupuestoImpl();
        //[HttpPost]
        //public dynamic GrabarTransaccion([FromBody] SPBDInsTransac SPBDInsTransac)
        //{
        //    Error err = null;
        //     long NoTransaccion = 0;
        //    try
        //    {
        //        NoTransaccion = grabaPresupuestoImpl.GrabarTransaccion(SPBDInsTransac);
        //        log.Info("Fin metodo grabarPresupuesto.");

        //        return NoTransaccion;
        //    }
        //    catch (Exception e)
        //    {
        //        err = new Error { codError = 2, descError = "Ocurrio un error en el proceso: " + e.Message };
        //        log.Error("Ocurrio un error en el proceso: " + e.Message);
        //        return err;
        //    }
        //}

        // [HttpPost]
        //public dynamic GrabarPreparametrico([FromBody]SPADN2InsPreparametrico SPADN2InsPreparametrico)
        //{
        //    Error err = null;
        //    string fcFolioParam = "";
        //    try
        //    {
        //        fcFolioParam = grabaPresupuestoImpl.GrabarPreparametrico(SPADN2InsPreparametrico);
        //        log.Info("Fin metodo grabarPresupuesto.");


        //    }
        //    catch (Exception e)
        //    {
        //        err = new Error { codError = 2, descError = "Ocurrio un error en el proceso: " + e.Message };
        //        log.Error("Ocurrio un error en el proceso: " + e.Message);
        //        return err;
        //    }
        //    return fcFolioParam;
        //}

        // [HttpPost]
        //public dynamic GrabarDetalle_preparametrico([FromBody]SPADN2InsDetallePreparametrico SPADN2InsDetallePreparametrico)
        //{
        //    Error err = null;
        //    long NoTransaccion = 0;
        //    try
        //    {
        //        NoTransaccion = grabaPresupuestoImpl.GrabarDetalle_preparametrico(SPADN2InsDetallePreparametrico);
        //        log.Info("Fin metodo grabarPresupuesto.");

           
        //    }
        //    catch (Exception e)
        //    {
        //        err = new Error { codError = 2, descError = "Ocurrio un error en el proceso: " + e.Message };
        //        log.Error("Ocurrio un error en el proceso: " + e.Message);
        //        return err;
        //    }
        //    return NoTransaccion;
        //}

        // [HttpPost]
        //public dynamic GrabarAbonoPuntual([FromBody]PACRLLIPromPagoPuntual PACRLLIPromPagoPuntual)
        //{
        //    Error err = null;
        //    string guardoAbonoPuntual = "";
        //    try
        //    {
        //        guardoAbonoPuntual = grabaPresupuestoImpl.GrabarAbonoPuntual(PACRLLIPromPagoPuntual);
        //        log.Info("Fin metodo GrabarAbonoPuntual.");
        //    }
        //    catch (Exception e)
        //    {
        //        err = new Error { codError = 2, descError = "Ocurrio un error en el proceso: " + e.Message };
        //        log.Error("Ocurrio un error en el proceso: " + e.Message);
        //    }
        //    return guardoAbonoPuntual;
        //}

         [HttpPost]
        public dynamic GrabarPresupuestoGenerico([FromBody]GrabarPresupuestoGenerico GrabarPresupuestoGenerico)
         {
             Error err = null;
             string fcfolioparam = "";
             try
             {
                 fcfolioparam = grabaPresupuestoImpl.GrabarPresupuestoGenerico(GrabarPresupuestoGenerico);
                 log.Info("Fin metodo Grabar Presupuesto");
             }
             catch (Exception e)
             {
                 err = new Error { codError = 2, descError = "Ocurrio un error en el proceso: " + e.Message };
                 log.Error("Ocurrio un error en el proceso: " + e.Message);
             }
             return fcfolioparam;
         }


    }
}