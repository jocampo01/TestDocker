﻿using Banco.PD3.Persistence;
using Banco.PD3.Persistence.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using WSPresupuestoTelefoniaCDT.Models;
using WSPresupuestoTelefoniaCDT.Resourse;

namespace WSPresupuestoTelefoniaCDT.Controllers
{
    public class PresupuestoTelefoniaController : ApiController
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
 
        public dynamic grabarPresupuesto(ParametrosEntradaModels parametros)
        {
            Error err = null;
            try
            {
                ConexionPD3 pdp = new ConexionPD3();
                PresupuestoTelefoniaModels qf = new PresupuestoTelefoniaModels();
                SqlDataReader rdr;
                if (pdp.getEntorno() == pdp.Desarrollo)
                {
                    PD3Connection conn1 = new PD3Connection();
                    SqlPersister persistence;

                    conn1 = Certificater.GetPD3Connection(pdp.getPathCerts(), pdp.getFileName(), true);
                    persistence = new SqlPersister(conn1);

                    rdr = persistence.ScriptToDataReader(qf.getQryGrabarTransaccion(parametros.transaccion.worckStation, parametros.transaccion.noEmpleado));

                    while (rdr.Read())
                    {
                        log.Info(rdr);
             
                        HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, rdr);
                    }

                }
                log.Info("Fin metodo buscarProducto.");
               
                
                //return response;
                return "Exito";
            }
            catch (Exception e)
            {
                err = new Error { codError = 2, descError = "Ocurrio un error en el proceso: " + e.Message };
                log.Error("Ocurrio un error en el proceso: " + e.Message);
                return err;
            }
        }

    }
}
