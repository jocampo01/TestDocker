﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WSGrabarPresupuesto.Modelo;
using Banco.PD3.Persistence;
using Banco.PD3.Persistence.Entities;
using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft;
using Newtonsoft.Json.Linq;
using System.Text;
using System.IO;
using Newtonsoft.Json;  

public class GrabaPresupuestoImpl : GrabaPresupuestoIT
{
    private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    public long GrabarTransaccion(SPBDInsTransac SPBDInsTransac)
    {
        Error err = null;
        ConexionPD3 conexionPD3 = new ConexionPD3();
        long NoTransaccion = 0;
        SqlDataReader SqlDataReader;
        PD3Connection conexion = new PD3Connection();
        SqlPersister persistence;
        try
        {
            log.Info("----------------------Inicia Grabar Transaccion--------------------- ");
            log.Info("---Inicia validación ConsultaGrabarTransaccion--- ");

            if (SPBDInsTransac.noEmpleado <= 0 || string.IsNullOrEmpty(SPBDInsTransac.worckStation))
            {
                throw new InvalidOperationException("uno de los valores no son validos");
            }

            String strSqlTransaccion = "exec spBDInsTransac '" + SPBDInsTransac.worckStation + "'," + SPBDInsTransac.noEmpleado + "," + 2010 + "," + 0;
            log.Info("----------------Validación spBDInsTransac---------------------- " + strSqlTransaccion);
            log.Info("---Validación spBDInsTransac--- " + strSqlTransaccion);


            if (conexionPD3.getEntorno() == conexionPD3.Desarrollo)
            {
   
                conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
                persistence = new SqlPersister(conexion);

                SqlDataReader = persistence.ScriptToDataReader(strSqlTransaccion);

                while (SqlDataReader.Read())
                {
                    NoTransaccion = Convert.ToInt64(SqlDataReader.GetInt32(1));
                }

            }

        }
        catch (Exception ex)
        {
            err = new Error { codError = 2, descError = "Ocurrio un error en el proceso: " + ex.Message };
            log.Error("spBDInsTransac Ocurrio un error en el proceso: " + ex.Message);
 
        }
        return NoTransaccion;
    }

    public string GrabarPreparametrico(SPADN2InsPreparametrico SPADN2InsPreparametrico)
    {
        Error err = null;
        ConexionPD3 conexionPD3 = new ConexionPD3();
        SqlDataReader SqlDataReader;
        PD3Connection conexion = new PD3Connection();
        SqlPersister persistence;
        string pfcFolioParam = "";
        try
        {

          
            log.Info("----------------------Inicia Grabar Preparametrico--------------------- ");
            String strSqlInsPreparametrico = "exec SPADN2InsPreparametrico " + SPADN2InsPreparametrico.pfiNgcioID + "," + SPADN2InsPreparametrico.pfiNoTiENDa + "," + SPADN2InsPreparametrico.pfiCteID + "," + SPADN2InsPreparametrico.pfIDigitoVer + "," + SPADN2InsPreparametrico.pfiTipoVenta + ",'" + SPADN2InsPreparametrico.pfcEmpNo + "'," + SPADN2InsPreparametrico.pfiPlazo +
                "," + SPADN2InsPreparametrico.pfiPeriodo + "," + SPADN2InsPreparametrico.pfnPAbo + "," + SPADN2InsPreparametrico.pfnUAbo + "," + 0 + "," + null;
            log.Info("----------------Validación SPADN2InsPreparametrico---------------------- " + strSqlInsPreparametrico);
            log.Info("---Validación SPADN2InsPreparametrico--- " + strSqlInsPreparametrico);

            if (conexionPD3.getEntorno() == conexionPD3.Desarrollo)
            {
             
                conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
                persistence = new SqlPersister(conexion);

                SqlDataReader = persistence.ScriptToDataReader(strSqlInsPreparametrico);

                while (SqlDataReader.Read())
                {
                    log.Info(SqlDataReader.GetValue(1));
                }

            }

        }
        catch (Exception ex)
        {
            err = new Error { codError = 2, descError = "Ocurrio un error en el proceso: " + ex.Message };
            log.Error("SPADN2InsPreparametrico Ocurrio un error en el proceso: " + ex.Message);
        }
        return pfcFolioParam;
    }

    public long GrabarDetalle_preparametrico(SPADN2InsDetallePreparametrico SPADN2InsDetallePreparametrico)
    {
        Error err = null;
        ConexionPD3 conexionPD3 = new ConexionPD3();
        SqlDataReader SqlDataReader;
        PD3Connection conexion = new PD3Connection();
        SqlPersister persistence;
        long noDetallePreparametrico = 0;
    
        try
        {
            log.Info("----------------------Inicia Grabar Detalle_preparametrico--------------------- "); ;
            String strSqlInsDetallePreparametrico = "exec SPADN2InsDetallePreparametrico " + SPADN2InsDetallePreparametrico.pfcFolioParam + "," + SPADN2InsDetallePreparametrico.pfiProdId + "," + SPADN2InsDetallePreparametrico.pfnProdPrecioD + "," + SPADN2InsDetallePreparametrico.pficant + "," + SPADN2InsDetallePreparametrico.pfnDescto + "," + 0 + "," + SPADN2InsDetallePreparametrico.pfnSobreprecio
                + "," + 0 + "," + SPADN2InsDetallePreparametrico.pfnCostoPdcto + "," + 1 + "," + SPADN2InsDetallePreparametrico.pfnINTereses + "," + SPADN2InsDetallePreparametrico.pfnEnganche + ",'" + SPADN2InsDetallePreparametrico.pfiCveProm + "'," + 0 + "," + 0 + "," + SPADN2InsDetallePreparametrico.pfiTranNo
                + "," + SPADN2InsDetallePreparametrico.pfnSobrePreEsp + "," + SPADN2InsDetallePreparametrico.pfnDesctoTda + "," + 0 + "," + 0 + "," + SPADN2InsDetallePreparametrico.pfnPrecioEtiq + "," + 0;
            log.Info("----------------Validación SPADN2InsDetallePreparametrico---------------------- " + strSqlInsDetallePreparametrico);
            log.Info("---Validación SPADN2InsDetallePreparametrico--- " + strSqlInsDetallePreparametrico);

            if (conexionPD3.getEntorno() == conexionPD3.Desarrollo)
            {

                conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
                persistence = new SqlPersister(conexion);

                SqlDataReader = persistence.ScriptToDataReader(strSqlInsDetallePreparametrico);

                while (SqlDataReader.Read())
                {
                    log.Info(SqlDataReader.GetValue(1));
                }

            }

        }
        catch (Exception ex)
        {
            err = new Error { codError = 2, descError = "Ocurrio un error en el proceso: " + ex.Message };
            log.Error("SPADN2InsDetallePreparametrico Ocurrio un error en el proceso: " + ex.Message);
        
        }

        return noDetallePreparametrico;
    }

    public string GrabarAbonoPuntual(PACRLLIPromPagoPuntual PACRLLIPromPagoPuntual)
    {
        Error err = null;
        ConexionPD3 conexionPD3 = new ConexionPD3();
        SqlDataReader SqlDataReader;
        PD3Connection conexion = new PD3Connection();
        SqlPersister persistence;
        string guardoAbonoPuntual = "";

        return guardoAbonoPuntual;
    }

    public string GrabarPresupuestoGenerico(GrabarPresupuestoGenerico GrabarPresupuestoGenerico)
    {
        string fcfolioparam = "";

        Error err = null;
        ConexionPD3 conexionPD3 = new ConexionPD3();
        long NoTransaccion = 0;
        SqlDataReader SqlDataReader;
        PD3Connection conexion = new PD3Connection();
        SqlPersister persistence;
        string pfcFolioParam = "";
        log.Info("============================================================================================ Inicia Grabar Transaccion============================================================================================ ");
        Boolean validaPagoPuntual=false;
        string StrURLValidaPresupuesto = "";
        string strURLRecompras = "";
        string JSONArmandoValidaPresupuesto="";
        try
        {
            log.Info("---Inicia validación ConsultaGrabarTransaccion--- ");

            if (GrabarPresupuestoGenerico.noEmpleado <= 0 || string.IsNullOrEmpty(GrabarPresupuestoGenerico.worckStation))
            {
                throw new InvalidOperationException("uno de los valores no son validos");
            }

            String strSqlTransaccion = "exec spBDInsTransac '" + GrabarPresupuestoGenerico.worckStation + "'," + GrabarPresupuestoGenerico.noEmpleado + "," + 2010 + "," + 0;
            log.Info("----------------Validación spBDInsTransac---------------------- " + strSqlTransaccion);
            log.Info("---Validación spBDInsTransac--- " + strSqlTransaccion);


            if (conexionPD3.getEntorno() == conexionPD3.Desarrollo)
            {

                conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
                persistence = new SqlPersister(conexion);

                SqlDataReader = persistence.ScriptToDataReader(strSqlTransaccion);

                while (SqlDataReader.Read())
                {
                    NoTransaccion = Convert.ToInt64(SqlDataReader.GetInt32(1));
                }

            }

        }
        catch (Exception ex)
        {
            err = new Error { codError = 2, descError = "Ocurrio un error en el proceso: " + ex.Message };
            log.Error("spBDInsTransac Ocurrio un error en el proceso: " + ex.Message);

        }

       log.Info("============================================================================================ Inicia la Invocacion del Recompras ============================================================================================ ");

          GrabarPresupuestoGenerico.sucursalVendedora = "0832";
       strURLRecompras= consultaParametroValidaPresupuesto();
       StrURLValidaPresupuesto = "http://NT" + GrabarPresupuestoGenerico.sucursalVendedora + strURLRecompras;

       JSONArmandoValidaPresupuesto = "{\"PaisCU\":" + GrabarPresupuestoGenerico.paisClienteUnico + ",\" CanalCU\":\"" + GrabarPresupuestoGenerico.canalClienteUnico + ",\" SucursalCU\":\"" + GrabarPresupuestoGenerico.sucursalClienteUnico
      + ",\" FolioCU\":\"" + GrabarPresupuestoGenerico.folioClienteUnico + ",\" SKUs\":\"" + GrabarPresupuestoGenerico.pfiProdId + ",\" CanalVend\":\"" + GrabarPresupuestoGenerico.canalVendedor + ",\" SucursalVend\":\"" 
      + GrabarPresupuestoGenerico.sucursalVendedora + ",\" TotalPresup\":\"" + GrabarPresupuestoGenerico.pfnSobreprecio + ",\" EnganchePresup\":\"" + GrabarPresupuestoGenerico.pfnEnganche + ",\" AbonoSemanal\":\"" + GrabarPresupuestoGenerico.pfnUAbo
      + ",\" AbonoPuntual\":\"" + GrabarPresupuestoGenerico.pfnPAbo + ",\" Plazo\":\"" + GrabarPresupuestoGenerico.pfiPlazo
      + ",\" EsForaneo\":\"" + false + ",\" EsquemaTelPres\":\"" + 2 + ",IngresosAComprobar\":\"" + 0 + ",\" Ws\":\"" + GrabarPresupuestoGenerico.worckStation +
      ",\" App\":\"" + "PresupuestoConsumo" + ",\" EsRenovacion\":\"" + false + ",\" CapacidadALiberar\":\"" + "0" + "\"}";




       string json = JsonConvert.SerializeObject(GrabarPresupuestoGenerico, Formatting.Indented);

        ConsumoApi parametros = new ConsumoApi();
        parametros.urlApi = StrURLValidaPresupuesto;
        parametros.json=JSONArmandoValidaPresupuesto;
        parametros.method= "POST";
        parametros.ContentType = "application/application/json";

              //Evitamos la validacion ssl/tls
              System.Net.ServicePointManager.ServerCertificateValidationCallback += (se, cert, chain, sslerror) => { return true; };
               //Creamos un webrequest para consumo por medio de http
               //Creamos un webrequest para consumo por medio de http
               HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(parametros.urlApi);
               //Agregamos Metodo post a la peticion 
               httpWebRequest.Method = parametros.method.ToUpper();
               httpWebRequest.ContentType = parametros.ContentType;
               byte[] byteArrayData = Encoding.ASCII.GetBytes(Convert.ToString(parametros.json));
               httpWebRequest.ContentLength = byteArrayData.Length;

                //agregamos datos al body de la peticion
                Stream dataStream = httpWebRequest.GetRequestStream();
                dataStream.Write(byteArrayData, 0, byteArrayData.Length);
                dataStream.Close();

                //Hacemos Peticion
                HttpWebResponse httpWebesponse = (HttpWebResponse)httpWebRequest.GetResponse();

                //obtenemos la respuesta y guardamos en un string
                dataStream = httpWebesponse.GetResponseStream();
                StreamReader streamreader = new StreamReader(dataStream);
                string response = streamreader.ReadToEnd();
                streamreader.Close();


        log.Info("============================================================================================ Inicia Grabar Preparametrico ============================================================================================ ");


        String strSqlInsPreparametrico = "exec SPADN2InsPreparametrico " + GrabarPresupuestoGenerico.pfiNgcioID + ","
              + GrabarPresupuestoGenerico.pfiNoTiENDa + "," + GrabarPresupuestoGenerico.pfiCteID + "," + GrabarPresupuestoGenerico.pfIDigitoVer +
              "," + GrabarPresupuestoGenerico.pfiTipoVenta + ",'" + GrabarPresupuestoGenerico.pfcEmpNo + "'," + GrabarPresupuestoGenerico.pfiPlazo +
            "," + GrabarPresupuestoGenerico.pfiPeriodo + "," + GrabarPresupuestoGenerico.pfnPAbo + "," + GrabarPresupuestoGenerico.pfnUAbo + ","
            + 0 + "," + NoTransaccion + "," + null;
        log.Info("----------------Validación SPADN2InsPreparametrico---------------------- " + strSqlInsPreparametrico);
        log.Info("---Validación SPADN2InsPreparametrico--- " + strSqlInsPreparametrico);

        if (conexionPD3.getEntorno() == conexionPD3.Desarrollo)
        {

            conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
            persistence = new SqlPersister(conexion);

            SqlDataReader = persistence.ScriptToDataReader(strSqlInsPreparametrico);

            while (SqlDataReader.Read())
            {
                pfcFolioParam = SqlDataReader.GetString(1);

            }

        }


        log.Info("============================================================================================ Inicia Grabar Detalle_preparametrico ============================================================================================ ");


        try
        {
            String strSqlInsDetallePreparametrico = "exec SPADN2InsDetallePreparametrico " + pfcFolioParam + "," + GrabarPresupuestoGenerico.pfiProdId + ","
                + GrabarPresupuestoGenerico.pfnProdPrecioD + "," + GrabarPresupuestoGenerico.pficant + "," + GrabarPresupuestoGenerico.pfnDescto + ","
                + 0 + "," + GrabarPresupuestoGenerico.pfnSobreprecio
                + "," + 0 + "," + GrabarPresupuestoGenerico.pfnCostoPdcto + "," + 1 + "," + GrabarPresupuestoGenerico.pfnINTereses + ","
                + GrabarPresupuestoGenerico.pfnEnganche + ",'" + GrabarPresupuestoGenerico.pfiCveProm + "'," + 0 + "," + 0 + ","
                + NoTransaccion
                + "," + GrabarPresupuestoGenerico.pfnSobrePreEsp + "," + GrabarPresupuestoGenerico.pfnDesctoTda + "," + 0 + "," + 0 + ","
                + GrabarPresupuestoGenerico.pfnPrecioEtiq + "," + 0;

            log.Info("----------------Validación SPADN2InsDetallePreparametrico---------------------- " + strSqlInsDetallePreparametrico);
            log.Info("---Validación SPADN2InsDetallePreparametrico--- " + strSqlInsDetallePreparametrico);

            if (conexionPD3.getEntorno() == conexionPD3.Desarrollo)
            {

                conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
                persistence = new SqlPersister(conexion);

                SqlDataReader = persistence.ScriptToDataReader(strSqlInsDetallePreparametrico);

                while (SqlDataReader.Read())
                {
                    log.Info(SqlDataReader.GetValue(1));
                }

            }

        }
        catch (Exception ex)
        {
            err = new Error { codError = 2, descError = "Ocurrio un error en el proceso: " + ex.Message };
            log.Error("SPADN2InsDetallePreparametrico Ocurrio un error en el proceso: " + ex.Message);

        }

        log.Info("============================================================================================ Inicia Grabar AbonoPuntual ============================================================================================ ");
        try
        {

            String strSqlPagoPuntual = "exec PACRLLIPromPagoPuntual " + pfcFolioParam + "," + GrabarPresupuestoGenerico.pfnPAbo + "," + GrabarPresupuestoGenerico.pfnPorcDscto;
            log.Info("---Validación PACRLLIPromPagoPuntual --- " + strSqlPagoPuntual);

            if (conexionPD3.getEntorno() == conexionPD3.Desarrollo)
            {

                conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
                persistence = new SqlPersister(conexion);

                SqlDataReader = persistence.ScriptToDataReader(strSqlPagoPuntual);

                while (SqlDataReader.Read())
                {
                   SqlDataReader.GetValue(1);
                }

            }

        }
        catch (Exception ex)
        {
            err = new Error { codError = 2, descError = "Ocurrio un error en el proceso: " + ex.Message };
            log.Error("PACRLLIPromPagoPuntual Ocurrio un error en el proceso: " + ex.Message);
        }


        return fcfolioparam;
    }


    public string consultaParametroValidaPresupuesto()
    {

        Error err = null;
        ConexionPD3 conexionPD3 = new ConexionPD3();
        long NoTransaccion = 0;
        SqlDataReader SqlDataReader;
        PD3Connection conexion = new PD3Connection();
        SqlPersister persistence;
        string URLRecompras="";
         String strSqlRecompras = "SELECT fcCatDesc FROM CATALOGO_GENERICO WITH(NOLOCK) WHERE fiItemId = 1665 AND fiSubItemId = 45 AND fiSubItemStat=1";
         log.Info("---Consulta Parametros Recompras --- " + strSqlRecompras);
        try{
            if (conexionPD3.getEntorno() == conexionPD3.Desarrollo)
            {

                conexion = Certificater.GetPD3Connection(conexionPD3.getPathCerts(), conexionPD3.getFileName(), true);
                persistence = new SqlPersister(conexion);

                SqlDataReader = persistence.ScriptToDataReader(strSqlRecompras);

                while (SqlDataReader.Read())
                {
                    URLRecompras = SqlDataReader.GetString(0);
                }

            }

        }
        catch (Exception ex)
        {
            err = new Error { codError = 2, descError = "Ocurrio un error en el proceso: " + ex.Message };
            log.Error("consultaParametroValidaPresupuesto Ocurrio un error en el proceso: " + ex.Message);
        }
      return URLRecompras;

    }
}