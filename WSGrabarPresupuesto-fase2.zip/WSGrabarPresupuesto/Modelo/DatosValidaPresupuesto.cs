﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSGrabarPresupuesto.Modelo
{
    public class DatosValidaPresupuesto
    {

        //Valida Presupuersto


        public string paisClienteUnico { get; set; }
        public string canalClienteUnico { get; set; }
        public string sucursalClienteUnico { get; set; }
        public string folioClienteUnico { get; set; }
        public List<string> listaSkusBaz { get; set; }
        public string canalVendedor { get; set; }
        public string sucursalVendedora { get; set; }

        public decimal totalPresupuesto { get; set; }

        public decimal enganchePresupuesto { get; set; }

        public Boolean EsForaneo { get; set; }

        public decimal ingresosAComprobar { get; set; }
    }
}