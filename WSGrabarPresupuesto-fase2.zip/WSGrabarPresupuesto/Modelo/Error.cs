﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WSGrabarPresupuesto.Modelo
{
    public class Error
    {
        public int codError { get; set; }
        public string descError { get; set; }

        override
        public string ToString()
        {
            return "{\"codError\":" + codError + "\n,\"Descripcion\":\"" + descError + "\"}";
        }
    }
}
