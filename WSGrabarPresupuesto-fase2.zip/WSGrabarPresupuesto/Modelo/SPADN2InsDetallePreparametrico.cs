﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSGrabarPresupuesto.Modelo
{
    public class SPADN2InsDetallePreparametrico
    {
        public int pfcFolioParam { get; set; }
        public int pfiProdId { get; set; }
        public decimal pfnProdPrecioD { get; set; }
        public int pficant { get; set; }
        public decimal pfnDescto { get; set; }
        public decimal pfnSobreprecio { get; set; }
        public decimal pfnCostoPdcto { get; set; }
        public decimal pfnINTereses { get; set; }
        public decimal pfnEnganche { get; set; }
        public int pfiCveProm { get; set; }
        public int pfiTranNo { get; set; }
        public decimal pfnSobrePreEsp { get; set; }
        public decimal pfnDesctoTda { get; set; }
        public decimal pfnPrecioEtiq { get; set; }

    }
}