﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WSGrabarPresupuesto.Modelo;
using Banco.PD3.Persistence;
using Banco.PD3.Persistence.Entities;
using System.Data.SqlClient;

public interface GrabaPresupuestoIT
{

    long GrabarTransaccion(SPBDInsTransac SPBDInsTransac);

    string GrabarPreparametrico(SPADN2InsPreparametrico SPADN2InsPreparametrico);

     long GrabarDetalle_preparametrico(SPADN2InsDetallePreparametrico SPADN2InsDetallePreparametrico);

     string GrabarAbonoPuntual(PACRLLIPromPagoPuntual PACRLLIPromPagoPuntual);

    string GrabarPresupuestoGenerico(GrabarPresupuestoGenerico GrabarPresupuestoGenerico);

}