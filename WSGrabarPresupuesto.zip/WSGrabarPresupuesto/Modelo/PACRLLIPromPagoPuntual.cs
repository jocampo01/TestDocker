﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSGrabarPresupuesto.Modelo
{
    public class PACRLLIPromPagoPuntual
    {
        public int pfcFolioParam { get; set; }
        public decimal pfnAbonoPromo { get; set; }
        public decimal pfnPorcDscto { get; set; }

    }
}