﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WSGrabarPresupuesto.Modelo;

namespace WSGrabarPresupuesto.Modelo
{
    public class PresupuestoConsultaUtils
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);


        public string ConsultaGrabarLigaClienteLCR(int fcFolioParam, int fiPaisCteU, int fiCanalCteU, int fiSucursalCteU, int fiFolioCteU, int fiNgcioIdEktGest, int fiNoTiendaGest, int fiCteIdGest, int fiDigitoVerGest,
            int fiNgcioIdEkt, int fiNoTiendaEkt, int fiCteIdEkt, int fiDigitoVerEkt, string fcTarjeta, string fcHuella1, string fcHuella2, string fcHuella3, string fcHuella4, string fcHuella5, string Nombre,
            int EstaConxion, int fiPaisGestor, int fiCanalGestor, int fiSucursalGestora, int fiComprasCredito, int piTir)
        {
            ConexionPD3 conexionPD3 = new ConexionPD3();

            try
            {
                log.Info("----------------------Inicia Grabar Liga de Cliente LCR--------------------- ");
                String qry = "exec spInsLigaClienteLCR " + fcFolioParam + "," + fiPaisCteU + "," + fiCanalCteU + "," + fiSucursalCteU + "," + fiFolioCteU + "," + fiNgcioIdEktGest + "," + fiNoTiendaGest +
                    "," + fiCteIdGest + "," + fiDigitoVerGest + "," + fiNgcioIdEkt + "," + fiNoTiendaEkt + "," + fiCteIdEkt + "," + fiDigitoVerEkt + ",'" + fcTarjeta + "','" + fcHuella1 +
                    "','" + fcHuella2 + "','" + fcHuella3 + "','" + fcHuella4 + "','" + fcHuella5 + "','" + Nombre + "'," + EstaConxion + "," + fiPaisGestor + "," + fiCanalGestor +
                    "," + fiSucursalGestora + "," + fiComprasCredito + "," + piTir;
                log.Info("---Validación spInsLigaClienteLCR --- " + qry);
                return qry;
            }
            catch (Exception ex)
            {
                log.Error("Error spInsLigaClienteLCR: " + ex);
                return "Error spInsLigaClienteLCR: " + ex;
            }
        }
    }
}
