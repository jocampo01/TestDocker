﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSGrabarPresupuesto.Modelo
{
    public class SPADN2InsPreparametrico
    {
        public int pfiNgcioID { get; set; }
        public int pfiNoTiENDa { get; set; }
        public int pfiCteID { get; set; }
        public int pfIDigitoVer { get; set; }
        public int pfiTipoVenta { get; set; }
        public string pfcEmpNo { get; set; }
        public int pfiPlazo { get; set; }
        public int pfiPeriodo { get; set; }
        public decimal pfnPAbo { get; set; }
        public decimal pfnUAbo { get; set; }
    }
}