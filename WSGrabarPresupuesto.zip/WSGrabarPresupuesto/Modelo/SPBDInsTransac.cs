﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSGrabarPresupuesto.Modelo
{
    public class SPBDInsTransac
    {
        public string worckStation { get; set; }
        public int noEmpleado { get; set; }
    }
}