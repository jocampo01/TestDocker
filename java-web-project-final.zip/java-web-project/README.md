# Maven - PUENTE PARA INVOCAR EL SERVICIO DEL API DEL ORQUESTADOR DE TELEFONIA
Maven 3, Spring 5 MVC, JUnit 5, Logback and Jetty web server. A simple web project to display a current date.

Project Link - https://10.82.57.113:8084/TipoCliente/credito_cobranza/credito/v1/TipoCliente/ObtenerClasificacion


## 1. How to run this project?

### 1.1 Test it with Jetty web server.
```
Access http://localhost:8080/java-web-project/ConsultaOrquestadorTelefonia/buscadorClientesTelefonia


### 1.2 Create a WAR file for deployment :
```
$ mvn package or mvn war:war
```
A WAR is generated at 'target/finalName'
