package com.bancoazteca.canales.terceros.telefonia.constantes;

public class ConstantsWS {

	/*
	 * Datos de la versi�n del aplicativo
	 * 
	 * @Versi�n
	 * 
	 * @Carpeta Virtual *
	 */

}