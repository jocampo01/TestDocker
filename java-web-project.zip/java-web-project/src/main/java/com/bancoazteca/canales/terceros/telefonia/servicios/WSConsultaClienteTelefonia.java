package com.bancoazteca.canales.terceros.telefonia.servicios;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bancoazteca.canales.terceros.telefonia.constantes.ConstantsWS;
import com.bancoazteca.canales.terceros.telefonia.utilerias.UtileriasHelper;

@Component
public class WSConsultaClienteTelefonia {
	final static Logger logger = Logger.getLogger(WSConsultaClienteTelefonia.class);

	@Autowired
	private UtileriasHelper utileriasHelper;

	public String transaccionConsultaCUTelefonia(Integer pais,Integer canal,Integer sucursal,Integer folio) {
		StringBuffer response = new StringBuffer();
		String line;
		String URL = null;
		String parameters = null;
		logger.debug(URL + "[URL CONSULTA CU CON AUTORIZACION] " + URL);
		logger.debug(URL + "[PARAMETROS CU CON AUTORIZACION] " + parameters);
		try {
			String dir="";
	        StringBuilder urlPaths = new StringBuilder(dir);
	        URL url;
	        String linea = "";
	        String texto = "";
	        try {
	            logger.debug(URL + "Conectando con la URL: " + dir);
	            url = new URL(urlPaths.toString());
	            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
	            httpURLConnection.setRequestMethod("GET");
	            httpURLConnection.setRequestProperty("Content-Type", "text/xml");
	            //httpURLConnection.setDoInput(false);
	            //httpURLConnection.setDoOutput(false);
	            //OutputStream os = httpURLConnection.getOutputStream();
	            BufferedReader br = new BufferedReader(new InputStreamReader((httpURLConnection.getInputStream()), "UTF-8"));
	            while ((linea = br.readLine()) != null) {
	                texto += linea + "\n";
	            }
	        } catch (Exception e) {
	            logger.error(URL + "Error al realizar la consulta");
	            logger.error(URL + e);
	            return null;

	        }
			
			
			URL urlServicio = new URL(URL);
			HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
			conexion.setConnectTimeout(90000);
			conexion.setReadTimeout(90000);
			conexion.setRequestMethod("POST");
			conexion.setDoOutput(true);
			DataOutputStream data = new DataOutputStream(conexion.getOutputStream());
			data.writeBytes(parameters); // MANDAMOS PARAMETROS
			data.flush();
			data.close();
			// logger.debug(ws + "HTTP Response Code: " + conexion.getResponseCode());
			if (conexion.getResponseCode() == HttpURLConnection.HTTP_UNAUTHORIZED) {
				logger.info("Acceso Denegado, credenciales invalidas o ip no esta autorizada.");
				return "401";
			}
			if (conexion.getResponseCode() == HttpURLConnection.HTTP_BAD_REQUEST) {
				logger.info("No se encontro algun cliente unico, Codigo de Respuesta: 400. ");
				return "400";
			}
			if (conexion.getResponseCode() == HttpURLConnection.HTTP_INTERNAL_ERROR) {
				logger.info("Hubo un problema interno del servidor, Codigo de Respuesta: 500. ");
				return "500";
			}
			if (conexion.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("HTTP codigo: " + conexion.getResponseCode());
			} else {
				BufferedReader buffer = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
				while ((line = buffer.readLine()) != null) {
					response.append(line);
				}
				buffer.close();
			}

			logger.debug("Transaccion exitosa para Alta de Cliente Unico Total Play : " + parameters);
		} catch (Exception e) {
			logger.error(utileriasHelper.getDetalleInconveniente("CLIENTE 360", "", URL, parameters,
					utileriasHelper.getDetailTraceFromExcepcion(e)));
		}
		return response.toString();
	}

	
    public String consumirServicio(String url, String method, String credentials) throws Exception {

        StringBuilder sbr = new StringBuilder();
        try {
            if (url.contains(" ")) {
                url = url.replaceAll(" ", "%20");
            }
            
            byte[] base64ClientCredentials = null;
            try {
            	base64ClientCredentials = credentials.getBytes("UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            
            URLConnection urlconec = new URL(url).openConnection();
            HttpURLConnection httpUrlconec = (HttpURLConnection) urlconec;

            httpUrlconec.setRequestMethod(method);
            httpUrlconec.setConnectTimeout(200000);
            httpUrlconec.setDoInput(true);
            httpUrlconec.setDoOutput(true);
            
            httpUrlconec.addRequestProperty("Authorization", "Basic " + DatatypeConverter.printBase64Binary(base64ClientCredentials));

            if (httpUrlconec.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new Exception("Error: " + httpUrlconec.getResponseCode() + " - " + httpUrlconec.getResponseMessage());
            } else {
                String line = "";
                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (httpUrlconec.getInputStream()), "UTF-8"));
                while ((line = br.readLine()) != null) {
                    sbr.append(line);
                }
            }
        } catch (Exception e) {
        	logger.error("Error al Conectarse con el Servicio: ".concat(utileriasHelper.getTraceFromExcepcion(e)));
        }
        logger.debug("[DATOS OBTENIDOS DE SERVICIO]:"+sbr.toString());
        return sbr.toString();
    }
	
	public String clientePOSTDigitalizacion(String urlPath,String objectRequest){
		StringBuilder xmlDigitalizacion = new StringBuilder();
		try{
			URL url = new URL(urlPath);
			logger.debug("url servicio cliente Post Digitalizacion: "+url);
			HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.setRequestMethod("POST");
			httpURLConnection.setRequestProperty("Content-Type", "application/json");
			httpURLConnection.setDoInput(true);
			httpURLConnection.setDoOutput(true);
			OutputStream os = httpURLConnection.getOutputStream();
			logger.debug("String Request enviado: "+objectRequest);
			os.write(objectRequest.getBytes("UTF-8"));
			os.flush();
			
			if (httpURLConnection.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ httpURLConnection.getResponseCode());
			}
			
			BufferedReader br = new BufferedReader(new InputStreamReader(
					(httpURLConnection.getInputStream()),"UTF-8"));
			String line = "";
			while ((line = br.readLine()) != null) {
				xmlDigitalizacion.append(line);
			}
		}catch(Exception e){
			logger.error(utileriasHelper.getTraceFromExcepcion(e));
			return null;
		}
		
		return xmlDigitalizacion.toString();
	}
	
	@SuppressWarnings("deprecation")
	public String getZonificacion(String metodo, String URL, String objectRequest) {

		StringBuffer response = new StringBuffer();
		String line;
		logger.debug(URL + "[URL CONSULTA CU CON AUTORIZACION] " + URL);
		logger.debug(URL + "[PARAMETROS CU CON AUTORIZACION] " + objectRequest);
		try {
		
			
			URL url = new URL(URL);
			HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
			conexion.setConnectTimeout(90000);
			conexion.setReadTimeout(90000);
			conexion.setRequestMethod(metodo);
			conexion.setDoOutput(true);
			conexion.setRequestProperty("Accept", "application/json");
			conexion.setRequestProperty("Content-Type","application/json");

			DataOutputStream data = new DataOutputStream(conexion.getOutputStream());
			data.writeBytes(objectRequest); // MANDAMOS PARAMETROS
			data.flush();
			data.close();
			// logger.debug(ws + "HTTP Response Code: " + conexion.getResponseCode());
			if (conexion.getResponseCode() == HttpURLConnection.HTTP_UNAUTHORIZED) {
				logger.info("Acceso Denegado, credenciales invalidas o ip no esta autorizada.");
				return "401";
			}
			if (conexion.getResponseCode() == HttpURLConnection.HTTP_BAD_REQUEST) {
				logger.info("Error en zonificaci�n, Codigo de Respuesta: 400. ");
				return "400";
			}
			if (conexion.getResponseCode() == HttpURLConnection.HTTP_INTERNAL_ERROR) {
				logger.info("Hubo un problema interno del servidor, Codigo de Respuesta: 500. ");
				return "500";
			}
			if (conexion.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("HTTP codigo: " + conexion.getResponseCode());
			} else {
				BufferedReader buffer = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
				while ((line = buffer.readLine()) != null) {
					response.append(line);
				}
				buffer.close();
			}
			logger.debug("Transaccion exitosa para al obtener los datos de zonificacion " + objectRequest);
		} catch (Exception e) {
			logger.error(utileriasHelper.getDetalleInconveniente("GetZonificacion ", "", URL, objectRequest,
					utileriasHelper.getDetailTraceFromExcepcion(e)));
		}
		return response.toString();

	}

}
