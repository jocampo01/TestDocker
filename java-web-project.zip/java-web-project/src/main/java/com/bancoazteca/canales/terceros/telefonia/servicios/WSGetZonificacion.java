package com.bancoazteca.canales.terceros.telefonia.servicios;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bancoazteca.canales.terceros.telefonia.constantes.ConstantsWS;
import com.bancoazteca.canales.terceros.telefonia.utilerias.UtileriasHelper;

@SuppressWarnings("deprecation")
@Component
public class WSGetZonificacion {

	final static Logger logger = Logger.getLogger(WSGetZonificacion.class);

	@Autowired
	private UtileriasHelper utils;

	
}
