package com.bancoazteca.canales.terceros.telefonia.utilerias;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.bancoazteca.canales.terceros.telefonia.constantes.StatusPeticion;


@Component
public class UtileriasHelper {
	static final Logger logger = Logger.getLogger(UtileriasHelper.class);
	
	

	
	public String getDetailTraceFromExcepcion(Exception e) {
		StringWriter sWriter = new StringWriter();
		PrintWriter pWriter = new PrintWriter(sWriter);
		e.printStackTrace(pWriter);
		String cadenaEx = sWriter.toString();
		cadenaEx = convertTextFail(cadenaEx);
		return cadenaEx;
	}
	
	
	public String getTraceFromExcepcion(Exception e) {
		StringWriter sWriter = new StringWriter();
		PrintWriter pWriter = new PrintWriter(sWriter);
		e.printStackTrace(pWriter);
		String cadenaEx = sWriter.toString();
		cadenaEx = convertTextFail(cadenaEx);
		return cadenaEx;
	}
	
	public String convertTextFail(String cadenaRespuesta) {
		if(cadenaRespuesta!=null && !cadenaRespuesta.isEmpty()){
			cadenaRespuesta = cadenaRespuesta.replaceAll("error", "ISSUE");
			cadenaRespuesta = cadenaRespuesta.replaceAll("Error", "ISSUE");
			cadenaRespuesta = cadenaRespuesta.replaceAll("ERROR", "ISSUE");
			cadenaRespuesta = cadenaRespuesta.replaceAll("exception", "ISSUEXPT");
			cadenaRespuesta = cadenaRespuesta.replaceAll("Exception", "ISSUEXPT");
			cadenaRespuesta = cadenaRespuesta.replaceAll("EXCEPTION", "ISSUEXPT");
			cadenaRespuesta = cadenaRespuesta.replaceAll("ORA-", "ISSUEBD-");
			cadenaRespuesta = cadenaRespuesta.replaceAll("\\n", "");
		}
		return cadenaRespuesta;
	}
	
	public String getDetalleInconveniente(String areaServicio, String procesoServicio,
			String urlServicio, String parametrosServicio, String detalleExep ) {
	
		String detalleInconveniente = " Servicio: "+procesoServicio+", "+
									  "Sistema: " + areaServicio + ", "+
									  "Descripcion: "+ urlServicio +  "[PARAMETROS]:"+parametrosServicio; // Reconfiguracion de CLASIFICACION y exposicion de erroresMonitoreo 
									  
		if(detalleExep!=null && !detalleExep.isEmpty()){			
			detalleInconveniente+="[DETALLE]:"+detalleExep;		 
		}
		return detalleInconveniente;
	}
	
	public ContenedorResponse llenarContenedorResponse(
			CodigosResponseWS codigo, boolean isError, String excpecion) {
		ContenedorResponse contenedor = new ContenedorResponse();
		contenedor.setCodigo(codigo.getIdCodigo());

		if (isError) {
			contenedor.setError(true);
			contenedor.setStatus(StatusPeticion.ERROR);
			if (excpecion != null) {
				contenedor.setDescripcion(codigo.getDescripcion()
						+ " Detalle del INCONVENIENTE: " + excpecion);
			} else {
				contenedor.setDescripcion(codigo.getDescripcion());
			}

		} else {
			contenedor.setDescripcion(codigo.getDescripcion());
			contenedor.setError(false);
			contenedor.setStatus(StatusPeticion.EXITO);
		}

		return contenedor;
	}
	
	public ContenedorResponse llenarContenedorResponse(
			CodigosResponseWS codigo, boolean isError, String excpecion,
			Object data) {
		ContenedorResponse contenedor = new ContenedorResponse();
		contenedor.setCodigo(codigo.getIdCodigo());

		if (isError) {
			contenedor.setError(true);
			contenedor.setStatus(StatusPeticion.ERROR);
			if (excpecion != null) {
				contenedor.setDescripcion(codigo.getDescripcion()
						+ " Detalle del INCONVENIENTE: " + excpecion);
			} else {
				contenedor.setDescripcion(codigo.getDescripcion());
			}

		} else {
			contenedor.setDescripcion(codigo.getDescripcion());
			contenedor.setError(false);
			contenedor.setStatus(StatusPeticion.EXITO);
		}
		if (data != null) {
			contenedor.setData(data);
		}

		return contenedor;
	}

}