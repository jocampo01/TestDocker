var app = angular.module("app", []);
app.controller("PruebaController", function ($scope, $rootScope) {
    var CONFIG = {
        MAX_VIDEO_WIDTH: 700 //Chiều rộng tối đa hiển thị của video
    };

    $scope.video = {
        path: "",
        width: 600,
        height: 300,
        scale: 1,
        desc: "",

        thumb: null,
        //thumb: "/static/images/sample.jpg",
        result: "C:\\Users\\Win\\Desktop\\videoplayback.mp4", //Đường dẫn file video được tạo
        resultThumb: "/assets/img/preview.jpg",
        publicLink: "",
        setVideoSize: function (width, height) {
            if (width > CONFIG.MAX_VIDEO_WIDTH) {
                $scope.video.scale = CONFIG.MAX_VIDEO_WIDTH / width;
                width = CONFIG.MAX_VIDEO_WIDTH;
                height = height * $scope.video.scale;
            } else {
                $scope.video.scale = 1;
            }
            $scope.video.width = width;
            $scope.video.height = height;

        }
    }

    $scope.top = {
        enabled: true,
        height: 100,
        padding: 0,
        bgColor: "white"
    }
    
    $scope.setting = {
        quality: 47,
        setQualitySlider: function(){
            $("#output-quality").slider({
                    formatter: function(value) {
                        var result = value + "%";
                        result += value > 70 ? " (Render may take much time)": "";
                        result += value < 30 ? " (Video quality may be poor)": "";
                        return result;
                    },
                    value: $scope.setting.quality
            });
        },
        onSettingModalHide: function(){
            callNative("setLocalDB", {key: "output-quality", value: $scope.setting.quality});
        }, 
        init: function(){
            $("#setting-modal").on('hidden.bs.modal', $scope.setting.onSettingModalHide)
        }
    }

    $scope.pageDisplay = {
        avatar: "/assets/img/avatar.png",
        name: "Facebook Page",

    }

    $scope.bottom = {
        enabled: true,
        height: 100,
        padding: 0,
        bgColor: "white"
    }

    $scope.step = 1;

    $scope.status = {
        isCreatingVideo: false, //Có đang tạo video hay không
        prepareShoting: false, //Có chuẩn bị snap banner sang hình ảnh
        isPosting: false
    }



    var selectFileModal;


    function UpdownDrag($ele, cb) {
        var isDragging = false;
        var startY = 0;

        $(window).on("mousedown", function (evt) {
            if (evt.target === $ele.get(0)) {
                isDragging = true;
                startY = evt.clientY;
                evt.preventDefault();
            }

        });

        $(window).on("mouseup", function (evt) {
            isDragging = false;

        });

        function callback(evt) {
            var currentY = evt.clientY;
            var delta = startY - currentY;
            startY = currentY;

            $scope.$apply(function () {
                cb(delta > 0, Math.abs(delta));
            })
        }


        $(window).on("mousemove", function (evt) {

            if (isDragging) {
                //console.log("move ne " + evt.clientY)
                callback(evt);
            }

        });
    }


    function initUpdownDrag() {
        //Khi tăng giảm padding top của video
        UpdownDrag($(".pwrapper .video .padding.top"), function (isUp, distance) {
            if (isUp) {
                $scope.top.padding = Math.min($scope.top.padding + distance, $scope.video.height, $scope.top.height);
            } else {
                var newValue = $scope.top.padding - distance;
                $scope.top.padding = newValue > 0 ? newValue : 0;
            }
        });

        //Khi tăng giảm padding bottom của video
        UpdownDrag($(".pwrapper .padding.bottom"), function (isUp, distance) {
            if (isUp) {
                $scope.bottom.padding = Math.min($scope.bottom.padding + distance, $scope.video.height, $scope.bottom.height);
            } else {
                var newValue = $scope.bottom.padding - distance;
                $scope.bottom.padding = newValue > 0 ? newValue : 0;
            }
        });
        
        

        //Khi tăng giảm height của banner top
        UpdownDrag($(".pwrapper .top.banner .updown"), function (isUp, distance) {
            if (isUp) {
                
                var newValue = $scope.top.height - distance;
                $scope.top.height = newValue > 0 ? newValue : 0;
                
                //Nếu padding > height thì gán lại bằng height
                if(newValue > 0 && $scope.top.padding > newValue){
                    $scope.top.padding = newValue;
                }
            } else {
                var newValue = $scope.top.height + distance;
                $scope.top.height = newValue < $scope.top.padding ? $scope.top.padding : newValue;
                //console.log($scope.top.padding, newValue, $scope.top.height)
            }
        });


        //Khi tăng giảm height của banner bottom
        UpdownDrag($(".pwrapper .bottom.banner .height.updown"), function (isUp, distance) {
            if (isUp) {
                var newValue = $scope.bottom.height - distance;
                $scope.bottom.height = newValue > 0 ? newValue : 0;
                
                //Nếu padding > height thì gán lại bằng height
                if(newValue > 0 && $scope.bottom.padding > newValue){
                    $scope.bottom.padding = newValue;
                }
            } else {
                $scope.bottom.height = $scope.bottom.height + distance;
            }
        });
    }

    function initChangeBannerBackgrounColor() {

        //Init change banner top background color
        $(".pwrapper .top.banner .bgchooser input").spectrum({
            color: "white",
            preferredFormat: "hex",
            showInput: true,
            showAlpha: true,
            change: function (color) {
                $scope.$apply(function () {
                    $scope.top.bgColor = color.toRgbString();
                });
            }
        });

        //Init change banner bottom background color
        $(".pwrapper .bottom.banner .bgchooser input").spectrum({
            color: "white",
            showAlpha: true,
            showInput: true,
            preferredFormat: "hex",
            change: function (color) {
                $scope.$apply(function () {
                    $scope.bottom.bgColor = color.toRgbString();
                });
            }
        });
    }



    $scope.showSelectVideoModal = function () {
        selectFileModal.modal("show");
    }

    $scope.hideSelectVideoModal = function () {
        selectFileModal.modal("hide");
    }

    function handleError(resp) {
        if (resp.message) {
            alert(resp.message);
        }
    }

    function callNative(funcName, params, cb) {
        Native.call(funcName, params, function (resp) {
            if (resp.code >= 0) {
                cb && cb(resp.data);
            } else {
                handleError(resp);
            }
        })
    }

    $scope.openSelectVideoDialog = function () {
        Native.fileSelectDialog({title: "Select video file", filter_desc: "Video Files", filter_exts: ["*.mp4", "*.avi"]}, function (resp) {

            if (resp.code >= 0) {
                var videoPath = resp.data;
                
                alert("Video path" + videoPath);
                $scope.hideSelectVideoModal();
                getVideoThumbnail(videoPath);
            } else {
                handleError(resp);
            }
        });
    }

    $scope.setStep = function (step) {
        $scope.step = step;
    }

    function getVideoThumbnail(videoPath) {
        Native.startProcessing();
        Native.call("getVideoThumb", {"video_path": videoPath}, function (resp) {
            Native.stopProcessing();
            
            if (resp.code >= 0) {
                
                var data = resp.data;
                var thumb = data.data;
                var width = data.width;
                var height = data.height;
                onSelectVideo(videoPath, thumb, width, height);
                $scope.$digest();
                setTimeout(function(){
                    $scope.$digest();
                }, 500)
            } else {
                handleError(resp);
            }
        });
    }

    function onSelectVideo(videoPath, thumb, width, height) {
        $scope.video.thumb = thumb;
        $scope.video.setVideoSize(width, height);
        $scope.video.path = videoPath;
    }

    //Khi user drag video vào webview
    window.onDragVideo = getVideoThumbnail;
    
    $scope.CreateVideo = {
        upCall: undefined,
        createOrStop: function(){
            if(!$scope.status.isCreatingVideo){
                $scope.CreateVideo.create();
            }else{
                $scope.CreateVideo.stop();
            }
        },
        stop: function(){
            $scope.status.isCreatingVideo = false;
            Native.stopProcessing();
            var upCall = $scope.CreateVideo.upCall;
            if(upCall){
                upCall.stop();
                $scope.CreateVideo.upCall = undefined;
            }
        },
        create: function () {
            if ($scope.video.thumb == null) {
                return alert("Please select video!");
            }

            if ($scope.status.isCreatingVideo) {
                return;
            }
            Native.startProcessing();
            $scope.status.prepareShoting = true;
            $scope.status.isCreatingVideo = true;
            $(".pwrapper").addClass("ready");

            var topBannerEle = document.getElementById('top-banner');
            if(topBannerEle.clientHeight > 2){
                html2canvas(topBannerEle, {useCORS: true}).then(function (canvas) {
                    try {
                        var topBannerBase64 = canvas.toDataURL("image/png");
                        step2(topBannerBase64);
                    } catch (err) {
                        console.error(err)
                        onCreateBannerFail();
                    }
                }).catch(onCreateBannerFail);
            }else{
                step2(null);
            }


            function step2(topBannerBase64){
                var bottomBannerEle = document.getElementById('bottom-banner');
                if(bottomBannerEle.clientHeight > 2){
                    html2canvas(bottomBannerEle, {useCORS: true}).then(function (canvas) {
                        try {
                            var bottomBannerBase64 = canvas.toDataURL("image/png");
                            step3(topBannerBase64, bottomBannerBase64);
                        } catch (err) {
                            console.error(err)
                            onCreateBannerFail();
                        }
                    }).catch(onCreateBannerFail);
                }else{
                    step3(topBannerBase64, null);
                }
            }

            function step3(topBannerBase64, bottomBannerBase64){
                html2canvas(document.getElementById('video-wrapper'), {useCORS: true}).then(function (canvas) {
                    try {
                        stopShoting();
                        if(!$scope.status.isCreatingVideo){
                            Native.stopProcessing();
                            return;
                        }
                        var videoWatermarkBase64 = canvas.toDataURL("image/png");
                        //$(document.body).append("<img src='" +videoWatermarkBase64+ "'" + " />")
                        var params = {
                            video_path: $scope.video.path,
                            top_banner_base64: topBannerBase64,
                            top_banner_padding: $scope.top.padding,
                            bottom_banner_base64: bottomBannerBase64,
                            bottom_banner_padding: $scope.bottom.padding,
                            video_watermark_base64: videoWatermarkBase64,
                            scale: $scope.video.scale,
                            quality: $scope.setting.quality
                        }
                        $scope.CreateVideo.upCall = Native.call("createViralVideo", params, function (resp) {
                            $scope.status.isCreatingVideo = false;
                            $scope.$digest();
                            Native.stopProcessing();
                            if (resp.code >= 0) {
                                var data = resp.data;

                                $scope.$apply(function () {
                                    $scope.video.result = data.path;
                                    $scope.video.resultThumb = data.thumb;

                                    $scope.setStep(2)
                                })
                            } else {
                                handleError(resp)
                            }
                        });

                        $scope.status.isCreatingVideo = true;
                    } catch (err) {
                        console.error(err)
                        onCreateBannerFail();
                    }
                }).catch(onCreateBannerFail);
            }


            function onCreateBannerFail() {
                $scope.status.prepareShoting = false;
                $scope.status.isCreatingVideo = false;
                $scope.$digest();
                Native.stopProcessing();
                stopShoting();
                alert("Error: create banner fail!");
            }

            function stopShoting() {
                $(".pwrapper").removeClass("ready");
            }


        }
    }
 

    $scope.downloadVideo = function () {
        var params = {
            default_name: "output.mp4",
            title: "Save video ...",
            is_save: true,
            filter_desc: "Video File",
            filter_exts: ["*.mp4"]
        }
        Native.fileSelectDialog(params, function (resp) {
            if (resp.code >= 0) {
                var videoPath = resp.data;
                var params = {
                    from_path: $scope.video.result,
                    to_path: videoPath
                }
                Native.startProcessing();
                Native.call("downloadVideo", params, function (resp) {
                    Native.stopProcessing();
                    if (resp.code >= 0) {
                        alert("Download successful!");
                    } else {
                        handleError(resp)
                    }
                })
            } else {
                handleError(resp);
            }
        });
    }

    $scope.playVideo = function () {
        callNative("playVideo", {path: $scope.video.result})
    }

    $scope.postToFacebook = function () {
        if ($scope.isPosting) {
            return;
        }
        var scheduleStr = $scope.Schedule.scheduleSelected;
        var schedule = scheduleStr !== null ? moment(scheduleStr, $scope.Schedule.format).valueOf() : 0;
        var params = {
            access_token: $scope.Page.pageSelected.access_token,
            video_path: $scope.video.result,
            desc: $scope.video.desc,
            schedule: schedule
        }

        Native.startProcessing();
        $scope.status.isPosting = true;
        Native.call("uploadVideo", params, function (resp) {
            $scope.status.isPosting = false;
            Native.stopProcessing()
            if (resp.code >= 0) {
                $scope.video.publicLink = resp.data.link;
                $scope.setStep(3);
            } else {
                handleError(resp)
            }
            $scope.$digest();
        })
    }

    function setLocalDB(key, value){
        callNative("setLocalDB", {key: key, value: value});
    }
    
    function getLocalDB(key, cb){
        callNative("setLocalDB", {key: key}, function(value){
            cb && cb(value);
        });
    }

    $scope.Page = {
        modal: undefined,
        pages: [{id: null, name: "No page selected", access_token: "", avatar: ""}],
        user: null, //Khác null tức là đã có access token
        accTknSource: "graph", //app -> lấy từ graph api hay từ app
        pageSelected: null,
        accessToken: "", //Graph api access token
        app: {
            id: "",
            secret: "",
            accessToken: "", //Short live token
            appAccessToken: "" //Long live token
        },
        isAccessTokenInvalid: null,
        getUserAndPageInfo: function (accessToken, cb, transparent) { //transparent -> có check ngầm hay không
            transparent = typeof transparent !== "undefined" ? transparent : false;
            Native.call("getUserAndPageInfo", {access_token: accessToken}, function (resp) {
                if (resp.code >= 0) {
                    $scope.Page.user = resp.data.user;
                    $scope.Page.isAccessTokenInvalid = true;
                    var pages = resp.data.pages;
                    //$scope.Page.pages = [$scope.Page.pages[0]]; //Clear old pages
                    $scope.Page.pages = pages;
                    $scope.Page.pageSelected = pages[0];
                    $scope.$digest();
                    setLocalDB("access_token", accessToken);
                } else {
                    setLocalDB("access_token", "");
                    $scope.Page.isAccessTokenInvalid = false;
                    if(!transparent){
                        handleError(resp);
                    }
                    
                }
                cb && cb(resp.code >= 0);

            });
        },
        changeAccount: function(){
            $scope.Page.user = null;
        },
        loginWithGraphAPI: function () {
            var accTkn = $scope.Page.accessToken;
            if (accTkn.length > 20) {
                Native.startProcessing();
                $scope.Page.getUserAndPageInfo(accTkn, function(success){
                    Native.stopProcessing();
                });
            }
        },
        loginWithAppToken: function(){
            var app = $scope.Page.app;
            if(app.id.length < 10)return alert("Please enter App ID");
            if(app.secret.length < 10)return alert("Please enter App Secret");
            if(app.accessToken.length < 10)return alert("Please enter App Access Token");
            
            var params = {
                app_id: app.id,
                app_secret: app.secret,
                access_token: app.accessToken
            }
            callNative("getAppAccessToken", params, function(accessToken){
                //Lưu thông số app 
                setLocalDB("app_id", app.id);
                setLocalDB("app_secret", app.secret);
                
                Native.startProcessing();
                $scope.Page.getUserAndPageInfo(accessToken, function(success){
                    Native.stopProcessing();
                });
            })
        },
        onClickSelectPage: function () {
            if ($scope.Page.pageSelected.id === null) {
                alert("Please select a page!");
            } else {
                $scope.Page.hideSelectPageModal();
            }
        },
        showSelectPageModal: function () {
            $scope.Page.modal.modal("show");
        },
        hideSelectPageModal: function () {
            $scope.Page.modal.modal("hide");
        },
        gotoAppAccessToken: function(){
            var appId = $scope.Page.app.id;
            if(appId.length < 10){
                return alert("Please enter App ID first!")
            }
            $scope.openLink("https://www.facebook.com/v2.9/dialog/oauth?response_type=token&display=popup&client_id="+appId+"&redirect_uri=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fexplorer%2Fcallback&scope=manage_pages%2Cpages_show_list%2Cpublish_pages");
        },
        onPageChanged: function(){
            var page = $scope.Page.pageSelected;
            if(page != null && page.id != null){
                setLocalDB("page_selected", page.id);
            }
        },
        init: function () {
            if($scope.Page.pageSelected === null){
                $scope.Page.pageSelected = $scope.Page.pages[0];
            }
            
            $scope.Page.modal = $("#select-page-modal");
            //$scope.Page.showSelectPageModal();
            callNative("getLocalDB", {key: "api_graph_token"}, function(resp){
                if(resp.code >= 0){
                    $scope.Page.accessToken = resp.data;
                    $scope.$digest();
                }
                
            });
        }
    }

    

    $scope.createNewVideo = function () {
        $scope.video.thumb = null;
        $scope.video.setVideoSize(600, 300);
        $scope.video.desc = "";
        $scope.top.padding = 0;
        $scope.bottom.padding = 0;
        $scope.top.bgColor = "white";
        $scope.bottom.bgColor = "white";
        $(".pwrapper .draggable").remove(); //Xóa mấy cái icon
        $scope.setStep(1);
    }

    $scope.goToAccessTokenPage = function () {
        $scope.openLink("https://www.facebook.com/v2.9/dialog/oauth?response_type=token&display=popup&client_id=145634995501895&redirect_uri=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fexplorer%2Fcallback&scope=manage_pages%2Cpages_show_list%2Cpublish_pages");
    }

    $scope.openLink = function (link) {
        callNative("openLink", {link: link})
    }

    var WrapperEle = {
        topBanner: undefined,
        video: undefined,
        bottomBanner: undefined,
        init: function () {
            WrapperEle.topBanner = $("#top-banner");
            WrapperEle.video = $("#video-wrapper");
            WrapperEle.bottomBanner = $("#bottom-banner");
        }
    }

    $scope.AddImage = {
        modal: $("#add-image-modal"),
        pos: "video", //top-banner, bottom-banner
        source: "computer", //emotions,
        imgFromComputer: "",
        emotionSelectedIndex: -1,
        showModal: function () {
            $scope.AddImage.modal.modal("show");
        },
        hideModal: function () {
            $scope.AddImage.modal.modal("hide");
        },
        getEmotion: function ($index) {
            return "assets/emotions/" + $index + ".png";
        },
        selectEmotion: function (index) {
            $scope.AddImage.emotionSelectedIndex = index;
        },
        canInsert: function () {
            var A = $scope.AddImage;
            return (A.isFromComputer() && A.imgFromComputer !== "") || (A.isFromEmotion() && A.emotionSelectedIndex >= 0);
        },
        isFromComputer: function () {
            return $scope.AddImage.source === "computer";
        },
        isFromEmotion: function () {
            return $scope.AddImage.source === "emotions";
        },
        onClickAddImage: function () {
            var _ = $scope.AddImage;
            if (_.canInsert()) {

                var img = null;
                if (_.isFromComputer() && _.imgFromComputer !== "") {
                    img = _.imgFromComputer;
                } else if (_.isFromEmotion() && _.emotionSelectedIndex >= 0) {
                    img = _.getEmotion(_.emotionSelectedIndex);
                }
                if (img != null) {

                    var parent = null;
                    if (_.pos === "top-banner") {
                        parent = WrapperEle.topBanner;
                    } else if (_.pos === "video") {
                        parent = WrapperEle.video;
                    } else if (_.pos === "bottom-banner") {
                        parent = WrapperEle.bottomBanner;
                    }
                }
                Utils.addSticker(img, parent);


            }
        },
        addImageAndClose: function () {
            var _ = $scope.AddImage;
            _.onClickAddImage();
            _.hideModal();
        },
        onClickChooseImage: function () {
            var params = {
                default_name: "output.mp4",
                title: "Select image ...",
                filter_desc: "Image Files",
                filter_exts: ["*.jpg", "*.png", "*.jpeg"]
            }

            Native.fileSelectDialog(params, function (resp) {
                if (resp.code >= 0) {
                    var imgPath = resp.data;
                    callNative("copyToPublicTmp", {path: imgPath}, function (imgLink) {
                        $scope.AddImage.imgFromComputer = imgLink;
                        $scope.$digest();
                    });
                } else {
                    handleError(resp);
                }
            })
        }
    }

    $scope.AddVideo = {
        CODE: {
            ERROR: -1,
            SET_LINK_INFO: 0,
            SET_DOWNLOAD_PERCENT: 1,
            DOWNLOAD_FINISHED: 2
        },
        source: "computer", //social
        isGettingInfo: false, //Đang request lấy thông tin link
        social: {
            valid: false, //Link có hợp lệ hay không
            thumb: "",
            thumbCut: "", //Thumb được cắt từ ffmpeg
            videoPath: "", //Đường dẫn video
            title: "",
            isDownloading: false,
            percent: 0,
            link: "",
            canSelect: false, //Có chọn được video này hay không, tức là đã tải và get được thumnail
            videoWidth: 0,
            videoHeight: 0
        },
        /*social: {
         valid: true,
         thumb: "https://i.ytimg.com/vi/aKgsA3yAaIs/hqdefault.jpg?sqp=-oaymwEWCKgBEF5IWvKriqkDCQgBFQAAiEIYAQ==&rs=AOn4CLCrGoFyUIXYepHxgZrNcbNlNyiUtw",
         title: "Hello world Hello world Hello world Hello world Hello world Hello world Hello world 2",
         isDownloading: true,
         percent: 50,
         link:"",
         },*/
        selectVideoOnSocial: function () {
            var _ = $scope.AddVideo;
            var link = $scope.AddVideo.social.link;
            if (link.length > 10 && _.isGettingInfo === false) {
                _.isGettingInfo = true;
                Native.startProcessing();
                Native.call("getDirectLink", {link: link}, function (resp) {
                    
                    _.isGettingInfo = false;
                    if (resp.code >= 0) {
                        var linkDownload = resp.data;
                        getVideoThumbnail(linkDownload);
                        $scope.hideSelectVideoModal();
                    } else {
                        Native.stopProcessing()
                        handleError(resp)
                    }
                    $scope.$digest();
                })
            }
        },
        onClickSelectVideo: function () {
            var social = $scope.AddVideo.social;
            onSelectVideo(social.videoPath, social.thumbCut, social.videoWidth, social.videoHeight);
            $scope.hideSelectVideoModal();
            //Reset some info
            social.valid = false;
            social.link = "";
            $scope.$digest();
        },
        onLinkYoutubeChange: function () {

        }
    }
    
    function initConfig(){
        var keys = ["access_token", "app_id", "app_secret", "page_selected"];
        
        callNative("getLocalDBs", {keys: keys}, function(config){
            
            var accessToken = config.access_token;
            $scope.Page.app.id = config.app_id;
            $scope.Page.app.secret = config.app_secret;
            
            
            //Get page info
            if(accessToken && accessToken.length > 10){
                $scope.Page.getUserAndPageInfo(accessToken, function(){
                    //Get page selected
                    $scope.Page.pages.forEach(function(page){
                        
                        if(page.id == config.page_selected){
                            $scope.Page.pageSelected = page;
                            $scope.$digest();
                            $("[bootstrap-select]").selectpicker('refresh');
                        }
                    })
                }, true);
            }
            $scope.$digest();
        });
        
        //Get quality setting
        callNative("getLocalDB", {key: "output-quality", def: "47"}, function(quallity){
            $scope.setting.quality = quallity;
            $scope.$digest();
            $scope.setting.setQualitySlider();
        })
    }
    
    function getFonts(cb){
        
        Native.call("getSystemFonts", {}, function(resp){
            if(resp.code >= 0){
                window.SYSTEM_FONTS = resp.data;
            }else{
                handleError(resp)
            }
            cb && cb();
        })
    }
    

    $scope.onAllTemplateIncluded = function () {
        selectFileModal = $("#select-video-modal");
        $scope.AddImage.modal = $("#add-image-modal");
        $scope.setting.init();
        
        $scope.showSelectVideoModal();
        WrapperEle.init();
        initUpdownDrag();
        initChangeBannerBackgrounColor();
        
        
        $scope.step = 1;
        Native.ready(function(){
            Native.stopProcessing();
            setTimeout(function(){
                getFonts(function(){ //Load font và sau đó init editor
                    initSample();
                });
            }, 10);
            
            
            $scope.Page.init();
            //$scope.Page.showSelectPageModal();
            initConfig();
        });
        
        
        //Dummy for test 
    }

    $scope.Schedule = {
        format: "DD/MM/YYYY HH:mm",
        scheduleUI: "", //Thẻ input schedule cho user chọn
        scheduleSelected: null, //Schedule được chọn
        removeSchedule: function () {
            $scope.Schedule.scheduleSelected = null;
        },
        selectSchedule: function () {
            var value = scheduleInputEle.datetimepicker("getValue");
            if (value.getTime() > new Date().getTime()) { //Nếu sau thời gian hiện tại
                $scope.Schedule.scheduleSelected = $scope.Schedule.scheduleUI;
            }

        }
    }
    $scope.AddImage.showModal();
});
