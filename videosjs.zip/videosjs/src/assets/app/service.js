var app = angular.module("app", []);
app.directive("actionButton", function(){
    return {
        restrict: 'E',
        scope: {
            text: "@",
            processing: "=",
            icon: "@?",
            large: "@?large",
            processingText: "@?"
        },
        link : function(scope, element, attrs){
            scope.processing = !!scope.processing;
            if(typeof scope.large === "undefined")
                scope.large = false;
            scope.large = !!scope.large;
            scope.showIcon = !!scope.icon;
            scope.processingText = scope.processingText || "Processing ...";
            
        },
        template: [ '<button ng-class="{processing: processing, \'btn-lg\': large}" type="button" id="btnCreateVideo" class="btn btn-primary">',
                        '<span ng-show="showIcon" class="glyphicon glyphicon-{{icon}}"></span>',
                        '<span ng-hide="processing" style="margin-left: 5px;">{{text}}</span>',
                        '<i ng-show="processing" >{{processingText}}</i>',
                    '</button>'
                   ].join("")           
               
    }
});

app.directive("preventLostSelection", function(){
    function saveSelection() {
        if (window.getSelection) {
            sel = window.getSelection();
            if (sel.getRangeAt && sel.rangeCount) {
                return sel.getRangeAt(0);
            }
        } else if (document.selection && document.selection.createRange) {
            return document.selection.createRange();
        }
        return null;
    }

    function restoreSelection(range) {
        if (range) {
            if (window.getSelection) {
                sel = window.getSelection();
                sel.removeAllRanges();
                sel.addRange(range);
            } else if (document.selection && range.select) {
                range.select();
            }
        }
    }
    
    var selection;
    
    return {
        restrict: 'A',
        link : function(scope, element, attrs){
            element.on("mousedown", function(){
                selection = saveSelection();
            });
            element.on("mouseup", function(){
                restoreSelection(selection);
            });
        }
    }
});

app.filter('range', function() {
  return function(input, total) {
    total = parseInt(total);

    for (var i=0; i<total; i++) {
      input.push(i);
    }

    return input;
  };
});


app.directive('includeReplace', function () {
    return {
        require: 'ngInclude',
        restrict: 'A', /* optional */
        link: function (scope, el, attrs) {
            el.replaceWith(el.children());
        }
    };
});

app.directive('bootstrapSelect', function () {
    return {
        restrict: 'A', /* optional */
        scope: {
            bootstrapSelect: "="
        },
        link: function (scope, el, attrs) {
            
            el.selectpicker();
            scope.$watch("bootstrapSelect", function(){
                el.selectpicker('refresh');
            })
        }
    };
});


var Utils = {
    handleDeleteObject: function(obj){
        var isHolding = false;
        obj.on("click", function(evt){
            if(!isHolding){
                onSelect();
            }
            evt.stopPropagation();
        });
        
        function onClickDocument(){
            if(isHolding){
                onUnselect();
            }
        }
        $(document).click(onClickDocument);
        
        function onKeyPress(evt){
            if(isHolding && evt.keyCode === 46){
                obj.remove();
            }
        }
        $(document).on("keyup", onKeyPress);
        

        function onSelect(){
            isHolding = true;
            obj.css("border", "1px solid red");
        }
        
        function onUnselect(){
            obj.css("border", "none");
            isHolding = false;
            
        }
    },
    initRemoveableElement: function(){
        $(document).on("click", ".removeable", function(evt){
            if(!evt.target.setupRemoveable){
                evt.target.setupRemoveable = true;
                Utils.handleDeleteObject($(evt.target));
            }
        });
    },
    addSticker: function(imgLink, parent){
        var pW = parent.width();
        var pH = parent.height();
        var imgEle = new Image();
        imgEle.onload = function(){
            var img = $(this);
            img.attr("class", "draggable removeable")
            img.css({
                "max-width": pW + 'px',
                "max-height": pH + 'px',
                position: "absolute"
            });
            var minW = Math.min(pW, this.width);
            var minH = Math.min(pH, this.height);
            img.css({
                top: pH/2 - minH/2,
                left: pW/2 - minW/2
            });
            parent.append(img);
            img.click();
            img.click();
        }
        imgEle.src = imgLink;
    }
}
