/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'smiley', 'zh', {
	options: '表情符號選項',
	title: '插入表情符號',
	toolbar: '表情符號'
} );
