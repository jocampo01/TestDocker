function JSONtoMap(JSONObject){
	var mapJSON={};
	
	toEntry(JSONObject,"",false);
	
	function toEntry(JSONObject, prefix, matriz){	
		angular.forEach(JSONObject, function(value, key) {
		    if(value instanceof Array){ 
		    	prefix2="";
		    	if(""!=prefix){
		    		prefix2=prefix.substring(0,prefix.length-1);
		    	}else{
		    		prefix2="listReglas"
		    	}
		    	mapJSON[prefix2]=toList(value,prefix,matriz);
		    }else if(value instanceof Object){
		    	toEntry(value,prefix+value.nombre+".",matriz);
		    }else{
		    	mapJSON[prefix+key]=value;
	        }
	    });
	}
	
	function  toList(JSONArray, prefix, matriz){
	    var list = new Array();
	    var mapaAuxMatriz= {};
	    
	    angular.forEach(JSONArray, function(value, key) {  	
	    	if(value instanceof Array) {
	        	toList(value,prefix,matriz);
	        }
	        else if(value instanceof Object) {
	        	if(matriz){		    					
					if("registro" in value && "nombre" in value ){
						var auxRegistro=value.registro;
						var auxNombre=value.nombre;
						
						if(value.registro in mapaAuxMatriz){
							mapaAuxMatriz[auxRegistro][auxNombre]=value;							
						}else{							
							var mapaIntMatriz= {};
							mapaIntMatriz[auxNombre]=value;
							mapaAuxMatriz[auxRegistro]=mapaIntMatriz;
						}
					}    					
				}  
	        	matrizActual=false;
	        	if("tipoSobrecarga" in value){
	        		if("MATRIZ"==value.tipoSobrecarga)
	        			matrizActual=true;
	        	}
	        	list.push(value);
	        	if( "nombre" in value && "registro" in value && "idParametroLista" in value){
	        		if("0"==value.idParametroLista)
	        			toEntry(value,prefix+value.nombre+".",matrizActual);
	        		else
	        			toEntry(value,prefix+value.nombre+"["+value.registro+"].",matrizActual);
	        	}else if("nombre" in value)
	        		toEntry(value,prefix+value.nombre+".",matrizActual);
	        	else if("nombreRegla" in value)
	        		toEntry(value,prefix+value.nombreRegla+".",matrizActual);
	        }	        
	    });
	    if(matriz){
	    	list = new Array();
	    	angular.forEach(mapaAuxMatriz, function(value, key) { 
	    		list.push(value);
	    	});		        	    
	    }
	    return list;
	}	 
	return mapJSON;
}

