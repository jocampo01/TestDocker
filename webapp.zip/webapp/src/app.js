'use strict'

define([], function () {

	var app = angular.module("app", ["ngRoute", "httpService", 'MapAngularLibrary',"ngDialog", "Authentication",  "appDrawing",
	                                 "angular-bind-html-compile", "angucomplete-alt", 'ui.select', 'MapBazLibrary'
	                                ]
							);
	
	MapAngularLibrary.constant( 'google_key', APP_KEY );
	document.onkeydown = function ( e ) {
		if (e.keyCode === 116) {
			return false;
		 }
	};
	
	
	
	if(window.location.protocol == 'file:'){
		IP = IP_WEB;
		configuracion.modo.offLine = true;
		app.requires.push( "myApp.templates" )
	}else
		configuracion.modo.onLine = true;
		
	var _path = window.location.pathname;
	if(_path.indexOf("indexTienda.jsp") > 0  ||  _path.indexOf("indexTienda.html") > 0  ||  _path.indexOf("index.html") > 0){
		configuracion.origen.tienda = true;
		configuracion.so.ios = true;
		
	}else if(_path.indexOf("indexWinWebView.html") > 0){
		configuracion.origen.tienda = true;
		configuracion.so.windows = true;
				
		//if(isProduccion && configuracion.modo.offLine)
			//IP = "https://10.53.35.62:8443/SolicitudCreditoWeb/";

	}else
		configuracion.origen.portalWeb = true;				
    
		
		
	
	if( configuracion.origen.tienda )	{		
		app.requires.push( "hardware" );
		app.requires.push( "configuracion" );
	}
					
	var TIMEOUT_RESOLVE = 10;
	
	window.routes = {
		"/": {
			templateUrl: "src/viewsControllers/fondo.html",
			controller: "pathController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){
					return startService.initModelConfigurator();
				}
			}
		},		
		"/recuperaSolicitud": {
			templateUrl: "src/viewsControllers/fondo.html",
			controller: "recuperaSolicitudController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){		
					return startService.initModelConfigurator();
				}
			}
		},	
		"/simulador": {
			templateUrl: "src/viewsControllers/simulador/simuladorView.html",
			controller: "simuladorController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},		
		"/login": {
			templateUrl: "src/viewsControllers/login/loginView.html",
			controller: "loginController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},	
		"/loginEmpleado": {
			templateUrl: "src/viewsControllers/login/loginEmpleadoView.html",
			controller: "loginEmpleadoController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},	
		"/menuWrapper": {
			templateUrl: "src/viewsControllers/menuWrapper/menuWrapperView.html",
			controller: "menuWrapperController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},			
		"/datosEmpleo": {
			templateUrl: "src/viewsControllers/datosEmpleo/datosEmpleoView.html",
			controller: "datosEmpleoController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/datosHogar": {
			templateUrl:  "src/viewsControllers/datosHogar/datosHogarView.html",
			controller: "datosHogarController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/ochoPasos": {
			templateUrl:  "src/viewsControllers/ochoPasos/ochoPasosView.html",
			controller: "ochoPasosController as vm",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/example":{
			templateUrl : "src/viewsControllers/example/example.html",	
			controller : "exampleController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/datosPersonales": {
			templateUrl : "src/viewsControllers/datosBasicos/datosBasicosView.html", 
			controller : "datosBasicosController as vm",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/ingresosGastos": {
			templateUrl:"src/viewsControllers/ingresosGastos/ingresosGastosView.html", 
			controller:"ingresosGastosController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/consultaColor": {
			templateUrl:"src/viewsControllers/consultaColorInfo/consultaColorView.html", 
			controller:"consultaColorController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/aval": { templateUrl: "src/viewsControllers/aval/avalView.html", 
			controller:"avalController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/expediente": { 
			templateUrl: "src/viewsControllers/expediente/expedienteView.html", 
			controller:"expedienteController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/contratos": { 
			templateUrl : "src/viewsControllers/contratos/contratosView.html", 
			controller : "contratosController as vm",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/referencias": {
				templateUrl : "src/viewsControllers/referencias/referenciasView.html", 
				controller : "referenciasController",
				requireLogin: false,
				resolve:{
					messageData: function(startService){						    
						return startService.initModelConfigurator();
					}
				}
			},
		"/datosEncuesta": {
			templateUrl : "src/viewsControllers/datosEncuesta/datosEncuestaView.html", 
			controller : "datosEncuestaController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/visitaAsesor": {
			templateUrl: "src/viewsControllers/visitaAsesor/visitaAsesorView.html", 
			controller:"visitaAsesorController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/estatus": { 
			templateUrl : "src/viewsControllers/estatus/estatusView.html", 
			controller : "statusController as vm",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},			
		"/nuevoCredito": { 
			templateUrl : "src/viewsControllers/nuevoCredito/nuevoCreditoView.html",
			controller : "nuevoCreditoController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/homonimos": { 
			templateUrl : "src/viewsControllers/homonimos/homonimosView.html",
			controller : "homonimosController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},			
		"/credito": { 
			templateUrl : "src/viewsControllers/liberacion/creditoView.html",
			controller : "creditoController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/bitacora": { 
			templateUrl : "src/viewsControllers/bitacora/bitacoraView.html",
			controller : "bitacoraController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},		
		"/liberacion": { 
			templateUrl : "src/viewsControllers/liberacion/liberacionView.html",
			controller : "liberacionController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/surtimiento": { 
			templateUrl : "src/viewsControllers/surtimiento/surtimientoView.html",
			controller : "surtimientoController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/aperturaCuenta": { 
			templateUrl : "src/viewsControllers/aperturaCuenta/aperturaCuentaView.html",
			controller : "aperturaCuentaController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/avisos": {
			templateUrl: "src/viewsControllers/avisos/avisosView.html",
			controller: "avisosController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},
		"/ficha": {
			templateUrl: "src/viewsControllers/ficha/fichaView.html",
			controller: "fichaController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},
		"/buzonExpedientes": {
			templateUrl: "src/viewsControllers/buzonExpedientes/buzonView.html",
			controller: "buzonController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},
		"/visorAsesor": {
			templateUrl: "src/viewsControllers/visorAsesor/visorAsesorView.html",
			controller: "visorAsesorController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},
		"/encolado": {
			templateUrl: "src/viewsControllers/encolado/encoladoView.html",
			controller: "encoladoController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},
		"/callCenter": {
			templateUrl: "src/viewsControllers/fondo.html",
			controller: "callCenterController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},
		"/cuentasCliente": {
			templateUrl: "src/viewsControllers/cuentasCliente/cuentasClienteView.html",
			controller: "cuentasClienteController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},
		"/catalogoItalika": {
			templateUrl: "src/viewsControllers/italika/catalogoView.html",
			controller: "catalogoController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},
		"/cotizadorItalika": {
			templateUrl: "src/viewsControllers/italika/cotizadorView.html",
			controller: "cotizadorController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},
		"/codigoSolicitud": {
			templateUrl: "src/viewsControllers/bazDigital/codigoSolicitudView.html",
			controller: "codigoSolicitudController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},
		"/recomienda": {
			templateUrl: "src/viewsControllers/folioRecomienda/recomiendaView.html",
			controller: "recomiendaController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},
		"/recompra": {
			templateUrl: "src/viewsControllers/recompra/recompraView.html",
				controller: "recompraController",
				requireLogin: false,
				resolve:{
					messageData: function(startService){	     	     
						return startService.initModelConfigurator();
					}
				}
		},
		
		"/fichaRecompra": {
			templateUrl: "src/viewsControllers/recompra/fichaView.html",
				controller: "fichaRecompraController",
				requireLogin: false,
				resolve:{
					messageData: function(startService){	     	     
						return startService.initModelConfigurator();
					}
				}
		},
		"/cambaceo": {
			templateUrl: "src/viewsControllers/cambaceo/cambaceoView.html",
			controller: "cambaceoController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},
// I-MODIFICACION TDC (CONTRATOS DE TDC)
		"/contratosTarjetas": { 
			templateUrl : "src/viewsControllers/contratosTarjetas/contratosTarjetasView.html", 
			controller : "contratosTarjetasController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
// F-MODIFICACION TDC (CONTRATOS DE TDC)
		},
		"/nuevaVisitaJVC": {
			templateUrl: "src/viewsControllers/visitaAsesor/visitaJVCView.html", 
			controller: "visitaJVCController",
			requireLogin: false,
			resolve: {
				messageData: ['startService', function(startService){
					return startService.initModelConfigurator();
				}]
			}
		},
/** INICIA_OS-FLUJO COACREDITADO **/
		"/ochoPasosOS": { 
			templateUrl : "src/viewsControllers/obligadoSolidario/ochoPasosOS/ochoPasosOSView.html", 
			controller : "ochoPasosOSController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/datosHogarOS": { 
			templateUrl : "src/viewsControllers/obligadoSolidario/datosHogarOS/datosHogarOSView.html", 
			controller : "datosHogarOSController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/simuladorOS": {
			templateUrl: "src/viewsControllers/obligadoSolidario/SimuladorOS/simuladorOSView.html",
			controller: "simuladorOSController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},
		"/contratosOS": { 
			templateUrl : "src/viewsControllers/obligadoSolidario/contratosOS/contratosOSView.html", 
			controller : "contratosOSController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/ingresosGastosOS": { 
			templateUrl : "src/viewsControllers/obligadoSolidario/ingresosGastosOS/ingresosGastosOSView.html", 
			controller : "ingresosGastosOSController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/expedienteOS": { 
			templateUrl : "src/viewsControllers/obligadoSolidario/expedienteOS/expedienteOSView.html", 
			controller : "expedienteOSController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/expedienteDocsOS": { 
			templateUrl : "src/viewsControllers/obligadoSolidario/expedienteOS/docsExpedienteOSView.html", 
			controller : "docsExpedienteOSController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/datosBasicosOS": { 
			templateUrl : "src/viewsControllers/obligadoSolidario/datosBasicosOS/datosBasicosOSView.html", 
			controller : "datosBasicosOSController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/datosEmpleoOS": { 
			templateUrl : "src/viewsControllers/obligadoSolidario/datosEmpleoOS/datosEmpleoOSView.html", 
			controller : "datosEmpleoOSController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/estatusOS": { 
			templateUrl : "src/viewsControllers/obligadoSolidario/estatusOS/estatusOSView.html", 
			controller : "estatusOSController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/recuperaSolicitudOS": { 
			templateUrl: "src/viewsControllers/fondo.html",
			controller : "recuperaSolicitudOSController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
			"/agendarCitaOS": { 
			templateUrl : "src/viewsControllers/obligadoSolidario/agendarCitaOS/agendarCitaOSView.html", 
			controller : "agendarCitaOSController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/callCenterOS": {
			templateUrl: "src/viewsControllers/fondo.html",
			controller: "callCenterOSController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){					    					    
					return startService.initModelConfigurator();
				}
			}
		},
		"/homonimosOS": { 
			templateUrl : "src/viewsControllers/obligadoSolidario/homonimosOS/homonimosOSView.html",
			controller : "homonimosOSController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		}
		,
		"/diadePago": {
			templateUrl : "src/viewsControllers/liberacion/diadePagoView.html",
			controller : "diadePagoController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/informacionGeneral": { 
			templateUrl : "src/viewsControllers/cliente/datosBasicos/informacionClienteView.html", 
			controller : "datosBasicosClienteController", 
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/datosCoacreditado": { 
			templateUrl : "src/viewsControllers/obligadoSolidario/datosCoacreditado/datosCoacreditadoView.html",
			controller : "datosCoacreditadoController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/cuentasGuardadito": {
			templateUrl : "src/viewsControllers/cuentasGuardadito/cuentasGuardaditoView.html",
			controller : "cuentasGuardaditoController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		},
		"/listaCuentas": {
			templateUrl : "src/viewsControllers/surtimiento/listaCuentasView.html",
			controller : "listaCuentasController",
			requireLogin: false,
			resolve:{
				messageData: function(startService){						    
					return startService.initModelConfigurator();
				}
			}
		}
/** TERMINA_OS-FLUJO COACREDITADO **/
	};/* END WINDOW ROUTES */
			
	app.config( function( $routeProvider ) {
		
		//this loads up our routes dynamically from the previous object 
	    for( var path in window.routes ) {
	    	$routeProvider.when( path, window.routes[path] );
	    }
	    
	    $routeProvider.otherwise( {redirectTo: '/'} );
	
	}).run( function($rootScope, authService, $timeout, $location, generalService, $window, $route){
						
		console.log('LOADING CONFIGURATION');
		
		$rootScope.fotoCteOriginal = "";
		$rootScope.isLocation = true;
		$rootScope.modoPrueba=false;						
		generalService.setArrayValue("initAPP", true);
		$rootScope.mostrarOfertaCotizador = false;
		$rootScope.MUESTRA_TERMOMETRO=MUESTRA_TERMOMETRO;
		$rootScope.MUESTRA_DOBLE_CAPACIDAD=MUESTRA_DOBLE_CAPACIDAD;
		$rootScope.userSession = null;
		$rootScope.ocrColonia = null;
		$rootScope.rechazoBuro = false;
		$rootScope.montoInvertirInicial="10000";
		$rootScope.productosAutorizados=[];
		$rootScope.productoSeleccionado="";
		$rootScope.sucursalSession = null;
	    $rootScope.imgUsuario = IMG_USR;		
		$rootScope.fotoCte = "data:image/png;base64," + $rootScope.imgUsuario;
		$rootScope.configAppJson = null
		generalService.buildSolicitudJson($rootScope, null);				
		generalService.buildPorcentajeJson($rootScope, null);	
		$rootScope.isTienda = configuracion.origen.tienda;
		$rootScope.$on('ngDialog.opened', function (e, $dialog) {
			$("body").animate({scrollTop :0}, '500',function(){	});
		});
			
		
		$rootScope.$on( "$locationChangeStart", function( event, next, current ){																							
			$rootScope.waitLoaderStatus = LOADER_SHOW;												

			$rootScope.paginaAnterior=$window.location.hash.substring(2,$window.location.hash.length);
			$rootScope.paginaActual=next.split("/")[next.split("/").length-1];
			
			if( $rootScope.recuperaSolicitud && $rootScope.paginaAnterior != "" )
				$rootScope.recuperaSolicitud=false;
			
			if( !configuracion.so.ios ){
				if($rootScope.paginaActual != "")
					generalService.setArrayValue("initAPP", false);
				
				if(!$rootScope.isLocation && !generalService.getArrayValue("initAPP")){				
	                event.preventDefault();
	                $rootScope.waitLoaderStatus = LOADER_HIDE;
				}
				
				$rootScope.isLocation = true;
			}
																
		});/* END ROOTSCOPE ON LOCATIONCHANGESTART */
		
	});/* END APP RUN PROMISE */
	
	app.config( ['ngDialogProvider', function ( ngDialogProvider ) {
		ngDialogProvider.setDefaults({
			className: 'ngDialog-theme-default centerDialog',
			plain: false,
			showClose: false,
			closeByDocument: false,
			closeByEscape: true,
			appendTo: false,
			preCloseCallback: function () {	}
		});
	}]);/* END APP CONFIG NGDIALOGPROVIDER */	
	
	app.filter( 'startFrom', function() {
	    return function(input, start) {
	    	if (!input || !input.length) {
				return;
			}
			start = +start; // parse to int
			return input.slice(start);
	    }
	});/* END APP FILTER STARTFROM */
	
	return app;
	
});