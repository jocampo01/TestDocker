'use strict'

define([], function () {

	var appFooter = angular.module("appFooter", ["ngRoute"]);
	
	if(window.location.protocol == 'file:'){	
		configuracion.modo.offLine = true;
		appFooter.requires.push( "myApp.templates" )
	}
			
	
	window.routesFooter = {
		"/": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},	
		"/recuperaSolicitud": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},	
		"/simulador": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},	
		"/login": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/loginEmpleado": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/menuWrapper": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/bitacora": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/datosEmpleo": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/datosHogar": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/ochoPasos": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/example":{
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/datosPersonales": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/ingresosGastos": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/aval": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/expediente": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/password": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/contratos": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/referencias": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/datosEncuesta": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/visitaAsesor": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/estatus": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},			
		"/nuevoCredito": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/homonimos": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},			
		"/consultaColor": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},			
		"/credito": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/diadePago": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/cuentasGuardadito": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/liberacion": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/surtimiento": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/aperturaCuenta": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/avisos": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/buzonExpedientes": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/ficha": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/visorAsesor": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/encolado": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/callCenter": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/cuentasCliente": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/catalogoItalika": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/cotizadorItalika": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/codigoSolicitud": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
// I-MODIFICACION TDC (CONTRATOS DE TDC)
		},
		"/contratosTarjetas": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
// F-MODIFICACION TDC (CONTRATOS DE TDC)
		},
// RECOMPRA
		"/recompra": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/fichaRecompra": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/recomienda": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/nuevaVisitaJVC": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/cambaceo": { 
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
/** INICIA_OS-FLUJO COACREDITADO **/
		"/datosHogarOS": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/ochoPasosOS": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/simuladorOS": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/contratosOS": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/ingresosGastosOS": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/expedienteOS": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/expedienteDocsOS": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/datosBasicosOS": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/datosEmpleoOS": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/estatusOS": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/recuperaSolicitudOS": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/agendarCitaOS": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/callCenterOS": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/homonimosOS": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/datosCoacreditado": {
			templateUrl: "src/viewsControllers/footer/footer.html",
			controller: "footerController"
		},
		"/informacionGeneral": { 
			templateUrl: "src/viewsControllers/footer/footer.html", 
			controller: "footerController" 
		},
		"/listaCuentas": { 
			templateUrl: "src/viewsControllers/footer/footer.html", 
			controller: "footerController" 
		}
/** TERMINA_OS-FLUJO COACREDITADO **/
	};
		
	appFooter.config(function($routeProvider) {
	    for(var path in window.routesFooter) 
	        $routeProvider.when( path, window.routesFooter[path] );	    
	    $routeProvider.otherwise( {redirectTo: '/'} );
	
	});
		
	return appFooter;
});