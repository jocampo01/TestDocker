var scripts = 
	[	
	 	'src/conf',
//	 	'vendor/js/maps/FullScreen.min',
//		'vendor/js/maps/CurrentLocation',
	 	'src/validateElements',
	 	'vendor/js/angular/ui-utils.min',
		'vendor/js/angular/angular-bind-html-compile.min',
		'vendor/js/angular/ngDialog.min',
		'vendor/js/angular/angular-route.min',
		'vendor/js/angular/angular-resource.min',
//		'vendor/js/angular/angular-animate.min',
		'vendor/js/angular/angular-cache.min',
		'vendor/js/angular/angular-locale_es.mx',
		'vendor/js/angular/ng-table.min',
		'vendor/js/xml2json.min',
	 	
		'vendor/js/jsencrypt',
		'vendor/js/pbkdf2.min',
		'vendor/js/google-crypto-aes.min',
		'vendor/js/hmac-sha256',
		'vendor/js/sjcl',
		'src/common',
		'src/commonLogs',
		'vendor/js/totp',
		'src/services/maps/full_screen',
	   	'src/services/maps/map',
	   	'src/services/maps/postmessage',
		'src/services/maps/mapBAZ',
		/*vendor/js/angular/lodash.underscore.min',*/
		/*'vendor/js/angular/angular-google-maps.min',*/
		
		
		'src/JsonToMap',
					
		'src/services/common/httpService',
		'src/directives/drawingDirective',
		'src/services/common/convertidorXML',
		'src/services/authService/authService',

		'vendor/js/Utf8EncodeDecode',
		'vendor/js/jquery/jquery-footer',
		'vendor/js/jquery/jquery-1.11.3.min',
		'vendor/js/angular/angucomplete-alt.min',
		 	
		'vendor/js/jquery/rangeSlider/jquery-ui-rangeSlider.min',
		'vendor/js/jquery/rangeSlider/jquery-rangeSliderVertical.min',
		'vendor/js/jquery/rangeSlider/jquery-rangeSlider.min',
		'vendor/js/jquery/jquery-owl.carousel.min',
		'vendor/js/jquery/jquery.easytabs.min',
		 			 	
		'vendor/js/jquery/jquery-menuSide.min',
		'vendor/js/jquery/jquery-menuSide',
		'vendor/js/jquery/jquery-ui-1.8.min',
		'vendor/js/jquery/ipad-touch-event.min',
		'vendor/js/jquery/jquery.panzoom.min',
		'vendor/js/select',
		
				
		'vendor/js/iphone-style-checkboxes'
		
		
	];/* END SCRIPTS ARRAY */

var isScriptLoaded = function( url )
{
	
	if (!url) return false;
	var scripts = document.getElementsByTagName( 'script' );

	for ( var index = 0; index < scripts.length; index++ ) {
		scripts[index].getAttribute('charset') == "utf-8";
		scripts[index].getAttribute('type') == "text/javascript";
		if (scripts[index].getAttribute('src') == url + ".js" ){
			return true;
			break;
		} 
	}
	
	return false;
	
};/* END IS SCRIPT LOADED FUNCTION */

var isRequireLoaded  = function( dataMain )
{
	
	if (!dataMain) return false;
	var scripts = document.getElementsByTagName( 'script' );
	
	for ( var index = 0; index < scripts.length; index++ ) {
		if ( scripts[index].hasAttribute( "data-main" ) ){
			if( scripts[index].getAttribute( "data-main" ) == dataMain )
				return true;
		} 
	}
	
	return false;
	
};/* END IS REQUIRE LOADED FUNCTION */

var createScriptRequireFn = function( pathResource, mainPath )
{
	
	var head = document.getElementsByTagName( 'body' );
	var headLen = head.length-1;
	head = head[headLen];
	var script = document.createElement( 'script' );
	script.src = pathResource;
	script.setAttribute( "data-main", mainPath );
	head.appendChild( script );
	
};/* END CREATE SCRIPT REQUIRE FUNCTION */

var cScriptLoader = (function ()
{
    function cScriptLoader( files )
    {

        var _this = this;
        _this.finish = false;

        this.log = function ( object )
        {
            console.log( object );
        };/* END LOG FUNCTION */

        this.logError = function( object )
        {
        	console.error( object );
        };/* END LOG ERROR FUNCTION */

        this.withNoCache = function ( filename )
        {
        
            if (filename.indexOf("?") === -1)
                filename += "?no_cache=" + new Date().getTime();
            else
                filename += "&no_cache=" + new Date().getTime();
        
            return filename;
        
        };/* END WITH NO CACHE FUNCTION */

        this.loadScript = function (i)
        {
            
            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.charset="utf-8";
            script.src = _this.m_js_files[i];
            
            var loadNextScript = function (){

                if ( i + 1 < _this.m_js_files.length )
                    _this.loadScript( i + 1 );
                else
                	_this.isFinish = true;
                
            };// END LOAD NEXT SCRIPT ANONYMOUS FUNCTION 

            script.onload = function (){
//                _this.log('Loaded script ["' + _this.m_js_files[i] + '"]');
                loadNextScript();
            };// EMD ON LOAD ANONYMOUS FUNCTION

            script.onerror = function (){
                _this.logError('Error loading script ["' + _this.m_js_files[i] + '"]');
                loadNextScript();
            };// END ON ERROR ANONYMOUS FUNCTION
        
//            _this.log('Loading script ["' + _this.m_js_files[i] + '"]');
            _this.m_head.appendChild(script);
        
        };/* END LOADSCRIPT FUNCTION */
        
        this.arefinishLoadingFiles = function()
        {
        	return _this.isFinish;
        };/* END ARE FINISH LOAD FILES FUNCTION */
        
        this.loadFiles = function ()
        {
            // this.log(this.m_js_files);
            _this.loadScript(0);

        };/* END LOAD FILES FUNCTION */

        this.m_js_files = [];
        this.m_head = document.getElementsByTagName("head")[0];
        // this.m_head = document.head; // IE9+ only
        
        function endsWith(str, suffix)
        {
            if (str === null || suffix === null)
                return false;

            return str.indexOf(suffix, str.length - suffix.length) !== -1;

        };/* END ENDS WITH FUNCTION */
        
        for (var i = 0; i < files.length; ++i){
            
        	files[i] = files[i] + ".js";
        	
        	if ( endsWith(files[i], ".js") ){
             	if( !isScriptLoaded( files[i].replace(".js", "") ) )
            		this.m_js_files.push( files[i] );
            }else
                this.logError('Error unknown filetype "' + files[i] + '".');
        }// END FOR FILES

    }/* END CSCRIPTLOADER PARENT FUNCTION */

    return cScriptLoader;

})();/* END CSCRIPTLOADER INTERNAL CLASS */
		
var loadScriptsFn = function()
{
	
	var pathRequire = "vendor/js/require.min.js";
	var pathMainRequire = "src/loadscripts";
	
	var timer = null;
	
	var ScriptLoader = new cScriptLoader( scripts );
	ScriptLoader.loadFiles();
	
	var finished = function(){
		
		if( ScriptLoader.arefinishLoadingFiles() ){
			clearInterval( timer );
			if( !isRequireLoaded( pathMainRequire ) )
				createScriptRequireFn( pathRequire, pathMainRequire );
		}
		
	};
	
	timer = setInterval( function(){ 
		finished();
	}, 200 );
	
	
};/* END LOAD SCRIPTS FUNCTION */

document.addEventListener("DOMContentLoaded", function(event) { 
	  
	loadScriptsFn();
	
});// END ADDEVENTLISTENER DOM CONTENT LOADED ANONYMOUS FUNCTION 