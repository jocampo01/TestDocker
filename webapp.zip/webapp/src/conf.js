var configuracion={
		"origen":{"tienda":false,"portalWeb":false},
		"so":{"ios":false, "windows":false, "android":false},
		"modo":{"offLine":false, "onLine":false},
		"login":{"acertum":false,"tienda":false, "solicitud":false },
		"simulador":{"opcion":0},
		"nuevoCredito":{"opcion":1},
		"datosUsuario":{"opcion":0},
		"estatus":{"opcion":0},		
};


window.onload = function () {
	
	if ( navigator.geolocation ){

		if( window.location.protocol == "https:" ){
			
			localStorage['currentPosition'] = null;
			localStorage['latitude'] = "19.2972509"; // Grupo Salinas
			localStorage['longitude'] = "-99.1853969"; // Grupo Salinas
			
			navigator.geolocation.getCurrentPosition( onSuccessGeolocation, onErrorGeolocation, 
					{
						maximumAge:Infinity, timeout:0
					}); 
				
		}else{
			console.warn( 'You need https protocol to use GeoLocation' );
			/* Default location*/
			localStorage['currentPosition'] = null;
			localStorage['latitude'] = "19.2972509"; // Grupo Salinas
			localStorage['longitude'] = "-99.1853969"; // Grupo Salinas
		}
		
    } else {
        console.error( 'Unable to locate current position' );
    }
	
	jQuery.browser = {};
	
    (function () {
        jQuery.browser.msie = false;
        jQuery.browser.version = 0;
        if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
            jQuery.browser.msie = true;
            jQuery.browser.version = RegExp.$1;
        }
    })();    
    
    if ( navigator.userAgent.toLowerCase().match("ipad") || navigator.platform.toLowerCase().match("ipad") ) 
    	esIpad = true;

    var disableEvent = function(e){ if(e.preventDefault){ /*e.preventDefault();*/ } return true; }
    
    window.oncontextmenu = disableEvent;
    window.addEventListener( "contextmenu", disableEvent );
    window.onselectstart = disableEvent;
    window.addEventListener( "selectstart", disableEvent );
    window.onpaste = disableEvent;
    window.oncut = disableEvent;
    window.oncopy = disableEvent;
    
};

var onSuccessGeolocation = function( position ) {
	
    console.log('Latitude: ' + position.coords.latitude + '\n' +
        'Longitude: ' + position.coords.longitude + '\n' +
        'Altitude: ' + position.coords.altitude + '\n' +
        'Accuracy: ' + position.coords.accuracy + '\n' +
        'Altitude Accuracy: ' + position.coords.altitudeAccuracy  + '\n' +
        'Heading: ' + position.coords.heading + '\n' +
        'Speed: ' + position.coords.speed + '\n' +
        'Timestamp: ' + new Date(position.timestamp) + '\n');
	
	localStorage['currentPosition'] = position;
	localStorage['latitude'] = position.coords.latitude;
	localStorage['longitude'] = position.coords.longitude;

	console.log( localStorage.getItem('latitude') + " <===> " + localStorage.getItem('longitude') );
	
//	doFallbackGeolocation();
	
};

// onError Callback receives a PositionError object
var onErrorGeolocation = function( error ) {
	
    switch( error.code ) {
    	case error.TIMEOUT:
    		// Quick fallback when no cached position exists at all.
    		doFallbackGeolocation();
      		// Acquire a new position object.
    		navigator.geolocation.getCurrentPosition( onSuccessGeolocation, onErrorGeolocation );
      	break;
    	default:
    		console.log( error );
    		console.error('[CONF SW-DEF] code: ' + error.code + '\n' +
    		        'message: ' + error.message + '\n');
    };
    
}

function doFallbackGeolocation(){
	
	localStorage['currentPosition'] = null;
	localStorage['latitude'] = "19.2972509"; // Grupo Salinas
	localStorage['longitude'] = "-99.1853969"; // Grupo Salinas
	
	console.log( localStorage.getItem( 'latitude' ) + " <==> " + localStorage.getItem( 'longitude' ) );
	
}

$( document ).on( 'focus', ':input', function(){
    $( this ).attr( 'autocomplete', 'off' );
});