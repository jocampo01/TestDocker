var appDrawing = angular.module("appDrawing", []);

appDrawing.directive('drawing1', function () {
	    return {
	        restrict: "A",	 	        
	        link: function ($scope) {
	
	            var canvas = document.getElementById("canvas1");
	            var context = canvas.getContext("2d");	 
	            try{
	            	canvas.width = document.getElementById('divCanvas').offsetWidth;
	            	canvas.height = document.getElementById('divCanvas').offsetHeight;
	            }catch(err){
	            	canvas.width = 544;
	            	canvas.height = 242;
	            }
	            context.fillStyle = "#fff";
	            context.strokeStyle = "#444";
	            context.lineWidth = 4;
	            context.lineCap = "round";
	            context.stroke();
	            context.fillRect(0, 0, canvas.width + '%', canvas.height);
	            var disableSave = true;
	            var pixels = [];
	            var cpixels = [];
	            var xyLast = {};
	            var xyAddLast = {};
	            var calculate = false;
	            { 	//functions
	                function remove_event_listeners() {
	                    canvas.removeEventListener('mousemove', on_mousemove, false);
	                    canvas.removeEventListener('mouseup', on_mouseup, false);
	                    canvas.removeEventListener('touchmove', on_mousemove, false);
	                    canvas.removeEventListener('touchend', on_mouseup, false);
	
	                    document.body.removeEventListener('mouseup', on_mouseup, false);
	                    document.body.removeEventListener('touchend', on_mouseup, false);
	                }
	
	                function get_coords(e) {
	                    var x, y;
	
	                    if (e.changedTouches && e.changedTouches[0]) {
	                        var offsety = canvas.offsetTop || 0;
	                        var offsetx = canvas.offsetLeft || 0;
	                        var ofsetyModal = canvas.offsetParent.offsetTop  || 0;
	                        var ofsetxModal = canvas.offsetParent.offsetLeft || 0;
	                        
	                        x = e.changedTouches[0].pageX - (ofsetxModal + offsetx);
	                        y = e.changedTouches[0].pageY -  (ofsetyModal + offsety);

//	                        x = e.changedTouches[0].pageX - offsetx;
//	                        y = e.changedTouches[0].pageY - offsety;
	                    } else if (e.layerX || 0 == e.layerX) {
	                        x = e.layerX;
	                        y = e.layerY;
	                    } else if (e.offsetX || 0 == e.offsetX) {
	                        x = e.offsetX;
	                        y = e.offsetY;
	                    }
	
	                    return {
	                        x: x,
	                        y: y
	                    };
	                };
	
	                function on_mousedown(e) {
	                    
	                	e.preventDefault();
	                    e.stopPropagation();
	                    
	                    canvas.addEventListener('mouseup', on_mouseup, false);
	                    canvas.addEventListener('mousemove', on_mousemove, false);
	                    canvas.addEventListener('touchend', on_mouseup, false);
	                    canvas.addEventListener('touchmove', on_mousemove, false);
	                    document.body.addEventListener('mouseup', on_mouseup, false);
	                    document.body.addEventListener('touchend', on_mouseup, false);
	
	                    empty = false;
	                    var xy = get_coords(e);
	                    context.beginPath();
	                    pixels.push('moveStart');
	                    context.moveTo(xy.x , xy.y);
	                    pixels.push(xy.x, xy.y);
	                    xyLast = xy;
	                    
	                };
	
	                function on_mousemove(e, finish) {
	                    
	                	e.preventDefault();
	                    e.stopPropagation();
	                    draw_point(e);
	                    
	                };
	
	                function on_mouseup(e) {
	                	
	                	draw_point(e);	                	
	                    remove_event_listeners();
	                    disableSave = false;
	                    context.stroke();
	                    pixels.push('e');
	                    calculate = false;
	                    
	                };
	                
	                function draw_point(e){
	                	
	                	var xy = get_coords(e);
	                    var xyAdd = {
	                        x: (xyLast.x + xy.x) / 2,
	                        y: (xyLast.y + xy.y) / 2
	                    };
	
	                    if (calculate) {
	                        var xLast = (xyAddLast.x + xyLast.x + xyAdd.x) / 3;
	                        var yLast = (xyAddLast.y + xyLast.y + xyAdd.y) / 3;
	                        pixels.push(xLast, yLast);
	                    } else {
	                        calculate = true;
	                    }
	
	                    context.quadraticCurveTo(xyLast.x+1, xyLast.y+1, xyAdd.x, xyAdd.y);
	                    pixels.push(xyAdd.x, xyAdd.y);
	                    context.stroke();
	                    context.beginPath();
	                    context.moveTo(xyAdd.x, xyAdd.y);
	                    xyAddLast = xyAdd;
	                    xyLast = xy;
	                    $scope.firma1 = true;
	                	
	                };
	                
	            }
	            
	            canvas.addEventListener('touchstart', on_mousedown, false);
	            canvas.addEventListener('mousedown', on_mousedown, false);
	
	            $scope.imageData1 = "";
	            $scope.GetData1 = function () {
	                var dataString = canvas.toDataURL("image/png");
	                $scope.imageData1 = dataString;
	            };
	
	            $scope.ClearCanvas1 = function () {
	                context.clearRect(0, 0, canvas.width, canvas.height);
	                $scope.firma1 = false;
	            };
	
	        }
	    };
});



appDrawing.directive('drawing2', function () {
    return {
        restrict: "A",	 	        
        link: function ($scope) {

            var canvas = document.getElementById("canvas2");
            var context = canvas.getContext("2d");	            
            canvas.width = 544;
            canvas.height = 242;
            context.fillStyle = "#fff";
            context.strokeStyle = "#444";
            context.lineWidth = 4;
            context.lineCap = "round";
            context.stroke();
            context.fillRect(0, 0, canvas.width + '%', canvas.height);
            var disableSave = true;
            var pixels = [];
            var cpixels = [];
            var xyLast = {};
            var xyAddLast = {};
            var calculate = false;
            { 	//functions
                function remove_event_listeners() {
                    canvas.removeEventListener('mousemove', on_mousemove, false);
                    canvas.removeEventListener('mouseup', on_mouseup, false);
                    canvas.removeEventListener('touchmove', on_mousemove, false);
                    canvas.removeEventListener('touchend', on_mouseup, false);

                    document.body.removeEventListener('mouseup', on_mouseup, false);
                    document.body.removeEventListener('touchend', on_mouseup, false);
                }

                function get_coords(e) {
                    var x, y;

                    if (e.changedTouches && e.changedTouches[0]) {
                        var offsety = canvas.offsetTop || 0;
                        var offsetx = canvas.offsetLeft || 0;
                        
                        x = e.changedTouches[0].pageX - offsetx;
                        y = e.changedTouches[0].pageY - offsety;
                    } else if (e.layerX || 0 == e.layerX) {
                        x = e.layerX;
                        y = e.layerY;
                    } else if (e.offsetX || 0 == e.offsetX) {
                        x = e.offsetX;
                        y = e.offsetY;
                    }

                    return {
                        x: x,
                        y: y
                    };
                };

                function on_mousedown(e) {
                    e.preventDefault();
                    e.stopPropagation();

                    canvas.addEventListener('mouseup', on_mouseup, false);
                    canvas.addEventListener('mousemove', on_mousemove, false);
                    canvas.addEventListener('touchend', on_mouseup, false);
                    canvas.addEventListener('touchmove', on_mousemove, false);
                    document.body.addEventListener('mouseup', on_mouseup, false);
                    document.body.addEventListener('touchend', on_mouseup, false);

                    empty = false;
                    var xy = get_coords(e);
                    context.beginPath();
                    pixels.push('moveStart');
                    context.moveTo(xy.x, xy.y);
                    pixels.push(xy.x, xy.y);
                    xyLast = xy;
                };

                function on_mousemove(e, finish) {
                    e.preventDefault();
                    e.stopPropagation();

                    var xy = get_coords(e);
                    var xyAdd = {
                        x: (xyLast.x + xy.x) / 2,
                        y: (xyLast.y + xy.y) / 2
                    };

                    if (calculate) {
                        var xLast = (xyAddLast.x + xyLast.x + xyAdd.x) / 3;
                        var yLast = (xyAddLast.y + xyLast.y + xyAdd.y) / 3;
                        pixels.push(xLast, yLast);
                    } else {
                        calculate = true;
                    }

                    context.quadraticCurveTo(xyLast.x, xyLast.y, xyAdd.x, xyAdd.y);
                    pixels.push(xyAdd.x, xyAdd.y);
                    context.stroke();
                    context.beginPath();
                    context.moveTo(xyAdd.x, xyAdd.y);
                    xyAddLast = xyAdd;
                    xyLast = xy;
                    $scope.firma2 = true;

                };

                function on_mouseup(e) {
                    remove_event_listeners();
                    disableSave = false;
                    context.stroke();
                    pixels.push('e');
                    calculate = false;
                };
            }
            canvas.addEventListener('touchstart', on_mousedown, false);
            canvas.addEventListener('mousedown', on_mousedown, false);

            $scope.imageData2 = "";
            $scope.GetData2 = function () {
                var dataString = canvas.toDataURL("image/png");
                $scope.imageData2 = dataString;
            };

            $scope.ClearCanvas2 = function () {
                context.clearRect(0, 0, canvas.width, canvas.height);
                $scope.firma2 = false;
            };

        }
    };
});
		