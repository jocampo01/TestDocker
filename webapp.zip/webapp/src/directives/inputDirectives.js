'use strict';

define(["app"], function (app) {

	app.directive("onlyNumbers", function() {
		return {			

		       require: 'ngModel',
		        link: function(scope, element, attrs, modelCtrl) {

		            modelCtrl.$parsers.push(function (inputValue) {
		                var transformedInput = inputValue ? inputValue.replace(/[^\d\s.-]+/i, '') : '';

		                if (transformedInput!=inputValue) {
		                    modelCtrl.$setViewValue(transformedInput);
		                    modelCtrl.$render();
		                }

		                return transformedInput;
		            });
		        }
		};
	});
	
	
	
	app.directive("onlyIntegers", function() {
		return {			
		       require: 'ngModel',
		        link: function(scope, element, attrs, modelCtrl) {

		            modelCtrl.$parsers.push(function (inputValue) {
		                var transformedInput = inputValue ? inputValue.replace(/[^\d.-]/g,'') : null;

		                console.log("transformedInput "+parseInt(transformedInput));
		                
		                if (transformedInput!=inputValue) {
		                    modelCtrl.$setViewValue(transformedInput);
		                    modelCtrl.$render();
		                }
		                if (parseInt(transformedInput) == 'NaN')
		                	return null;
		                else
		                	return parseInt(transformedInput);
		                
		            });
		        }
		};
	});
	

	app.directive("minusMayus", function() {
		return {
			require : 'ngModel',
			link : function(scope, element, attrs, modelCtrl) {

				modelCtrl.$parsers.push(function(inputValue) {
					var transformedInput = inputValue ? inputValue
							.toUpperCase() : "";

					if (transformedInput != inputValue) {
						modelCtrl.$setViewValue(transformedInput);
						modelCtrl.$render();
					}

					return transformedInput;
				});
			}
		};
	});
	
	
	app.directive("mayusMinus", function() {
		return {
			require : 'ngModel',
			link : function(scope, element, attrs, modelCtrl) {

				modelCtrl.$parsers.push(function(inputValue) {
					var transformedInput = inputValue ? inputValue
							.toLowerCase() : "";
						transformedInput = transformedInput.replace(/!|\"|#|\$|%|\&|'|\(|\)|\*|\+|,|\/|:|;|\<|\=|\>|\?|\[|\\|\]|\^|\{|\||\}|\~|\°|\¿|¡|\¨|\´|\ä|\ë|\ï|\ö|\ü|\Ä|\Ë|\Ï|\Ö|\Ü|\á|\é|\í|\ó|\ú|\Á|\É|\Í|\Ó|\Ú|\ñ|\Ñ|\`|\£|\¥|\€|\•|\›|\‹/g,'');
						transformedInput = transformedInput.replace(/[\uD800-\uDBFF]|[\uDC00-\uDFFF]|\ud83d[\ude00-\ude4f]/g, '' );
						
					if (transformedInput != inputValue) {
						modelCtrl.$setViewValue(transformedInput);
						modelCtrl.$render();
					}

					return transformedInput;
				});
			}
		};
	});	

	app.directive("onlyLetters", function() {
		return {
			restrict : 'A',
			require : 'ngModel',
			link : function($scope, element, attrs, ngModel){
				$scope.endsWith = function endsWith(str, suffix) {
				    return str.indexOf(suffix, str.length - suffix.length) !== -1;
				};
				
				$scope.$watch(attrs.ngModel, function(newValue, oldValue){
					if(newValue && newValue != null){
						if(newValue.trim() != ''){
							if($scope.endsWith(newValue, ' ')){
								newValue = newValue.trim().replace(/[^A-Za-z ]/g, '');
								newValue+=' ';
								ngModel.$setViewValue(newValue);
								element.val(newValue);
								$(element).change();
							}else{
								newValue = newValue.replace(/[^A-Za-z ]/g, '');
								ngModel.$setViewValue(newValue);
								element.val(newValue);
								$(element).change();
							}
						}else{
							newValue = newValue.trim();
							ngModel.$setViewValue(newValue);
							element.val(newValue);
							$(element).change();
						}
					}
				  });
			
			}
		};
	});
	
	app.directive("compareTo",  function() {
		    return {
		      require: "ngModel",
		      scope: {
		        otherModelValue: "=compareTo"
		      },
		      link: function(scope, element, attributes, ngModel) {

		        ngModel.$validators.compareTo = function(modelValue) {
		        	if(modelValue == scope.otherModelValue)
		        		return modelValue == scope.otherModelValue;
		        	if(modelValue==''&&scope.otherModelValue=='')
		        		return true;
		        	return false;
		        }
		        scope.$watch("otherModelValue", function() {
		            ngModel.$validate();
		          });
		        }
		      };
		    });

	app.directive('enterFocus', function() {
		return function(scope, element, attrs) {
			element.bind("keydown keypress", function(event) {
				var n = $(".active").size();
				if (event.charCode === 13) {
					event.preventDefault();
					var nextIndex = $('.active').index(this) + 1;
					if (nextIndex < n) {
						$('.active')[nextIndex].focus();
					}
				}
			});
		};
	});
	
	app.directive('autofocusAng', ['$timeout', function($timeout) {
		  return {
		    restrict: 'A',
		    link : function($scope, $element) {
		      $timeout(function() {
		        $element[0].focus();
		      });
              $element.on( 'blur', function(){
            	  $element[0].focus();
             });/* END BLUR */
		    }
		  }
	}]);
	
	app.directive("canvas", function () {
	    return {
	        restrict: "E",
	        link: function (scope, element, attrs) {
	            element.on('touchmove', function (e) {
	                e.preventDefault();
	                scope.id = element[0].getAttribute('id');
	                scope.increment(scope.id);
	            });
	        }
	    };
	});
	
//	(function () {
//	    'use strict';
//
//	    var module = angular.module('angular-bind-html-compile', []);
//
//	    module.directive('bindHtmlCompile', ['$compile', function ($compile) {
//	        return {
//	            restrict: 'A',
//	            link: function (scope, element, attrs) {
//	                scope.$watch(function () {
//	                    return scope.$eval(attrs.bindHtmlCompile);
//	                }, function (value) {
//	                    element.html(value);
//	                    $compile(element.contents())(scope);
//	                });
//	            }
//	        };
//	    }]);
//	}());
	
	
	app.directive('preventDefault', function() {
	    
		return function( scope, element, attrs ) {
	    
			angular.element( element ).bind( 'click', function( event ) {
	            event.preventDefault();
	            event.stopPropagation();
	        });
	    }
		
	});
	
	app.directive('focusMe', function($timeout, $parse) {
		  return {
		    //scope: true,   // optionally create a child scope
		    link: function(scope, element, attrs) {
		      var model = $parse(attrs.focusMe);
		      scope.$watch(model, function(value) {
		        //console.log('value=',value);
		        if(value === true) { 
		          $timeout(function() {
		            element[0].focus(); 
		          });
		        }
		      });
		      // set attribute value to 'false'
		      // on blur event:
		      element.bind('blur', function() {
		         //console.log('blur');
		         scope.$apply(model.assign(scope, false));
		      });
		    }
		  };
	});
	
	app.directive('stringToNumber', function() {
		return {
			require: 'ngModel',
		    link: function(scope, element, attrs, ngModel) {
		    	ngModel.$parsers.push(function(value) {
		    		return '' + value;
		    	});
		    
		    	ngModel.$formatters.push(function(value) {
		       
		    		return parseInt(value, 10);
		    
		    	});
		    }
		  
		};
	});
	
	/**
	 * Directiva para leer el archivo ajduntado
	 */
	app.directive("fileread", [function () {
	    return {
	        scope: {
	            fileread: "="
	        },
	        link: function (scope, element, attributes) {
	            element.bind("change", function (changeEvent) {
	                var reader = new FileReader();
	                reader.onload = function (loadEvent) {
	                    scope.$apply(function () {
	                        scope.fileread = loadEvent.target.result;	                        
	                    });
	                }
	                reader.readAsDataURL(changeEvent.target.files[0]);
	            });
	        }
	    }
	}]);
	
	app.directive('withoutSpace', function() {
	    return {
	         require: 'ngModel',
	         restrict: 'AEC',
	         link: function( scope, element, attrs, /*ctrl*/ ngModel ) {

	        	  var firstTime = true;
	        	  var cleanVal = "";
	        	  var cleanValCU = "";
	        	  var cleanValMail = "";
	              var start = null; 
	              var end = null;
	              var anterior = "";
	        	 
	              function validateNumero( value ){

	                   if ( isNaN(value) ){
	                        return false;
	                   }

	                   return true;
	              }/* END VALIDATENUMERO FUNCTION */

	              function util_numberWithCommas( number ) {                                                
	                   var parts = number.toString().split(".");
	                   parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
	                   return parts.join(".");                                                    
	              }/* END UTIL_NUMBERWITHCOMMAS */

	              function util_escapeRegExp( string ) {                                                    
	                   return string.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");                                            
	              }/* END UTIL_ESCAPEREGEXP FUNCTION */

	              function util_replaceAll( string, find, replace ) {                                                 
	                   return string.replace(new RegExp(util_escapeRegExp(find), 'g'), replace);                 
	              }/* END UTIL_REPLACEALL FUNCTION */

	              function toMaskPhone( value, foo ) {                                           
	                   
	                   var v = mphone(value);                                          
	                   
	                   if ( v != value ) {
	                        value = v;
	                   }                                           

	                   return value;                                                  

	              }/* END TOMASKPHONE FUNCTION */

	              var masks = ["55","81", "33"];
	              
	              function mphone( v ) {                                          
	              
	                   var r = v.replace(/\D/g,"");
	                   r = r.replace(/^0/,"");

	                   if (r.length > 10) {
	                       
	                	   // 11+ digits. Format as 5+4.
	                	   if( masks.indexOf(r.substring(0,2)) != -1 ){
	              			   r = r.replace(/^(\d\d)(\d{5})(\d{4}).*/,"($1) $2 $3");
	              		   }else{
	              			 r = r.replace(/^(\d\d\d)(\d{5})(\d{4}).*/,"($1) $2 $3");
	              		   }
	                        
	                   }else if (r.length > 6) {

	                	   // 6..10 digits. Format as 4+4
	                	   if( masks.indexOf(r.substring(0,2)) != -1 ){
	              			 r = r.replace(/^(\d\d)(\d{4})(\d{0,4}).*/,"($1) $2 $3");
	              		   }else{
	              			 r = r.replace(/^(\d\d\d)(\d{3})(\d{0,4}).*/,"($1) $2 $3");
	              		   }
	                        
	              	   }else if (r.length > 3) {
	                       
	              		   // 3..5 digits. Add (0XX..)
	              		   if( masks.indexOf(r.substring(0,2)) != -1 ){
	              			   r = r.replace(/^(\d\d)(\d{0,5})/,"($1) $2");
	              		   }else{
	              			   r = r.replace(/^(\d\d\d)(\d{0,5})/,"($1) $2");
	              		   }
	              		    
	                   }else {
	                        // 0..2 digits. Just add (0XX
	                        r = r.replace(/^(\d*)/, "($1");
	                   }                                           
	              
	                   return r;                                             
	              
	              }/* END MPHONE FUNCTION */

	              String.prototype.toMask = function(typeMask, element) {

	                   var out = "";
	                   var currentValue = this;
	                   if (currentValue != "" && currentValue) {
	                        
	                        switch (typeMask) {
	                             case "$":
	                                      
	                                       if (validateNumero(currentValue)) {
	                                            var longitud = element[0].getAttribute('maxlength');
	                                            out = '$ ' + util_numberWithCommas(currentValue);
	                                            if (out.length > parseInt(longitud)){
	                                                 var tmp = out.substring(0, parseInt(longitud));
	                                                 tmp = util_replaceAll( tmp, "$ ", "" );
	                                                 tmp = util_replaceAll( tmp, ",", "" );
	                                                 out = '$ ' + util_numberWithCommas(tmp);
	                                            }
	                                                 
	                                       } else {
	                                            var tmp = util_replaceAll( currentValue, "$ ", "" );
	                                            tmp = util_replaceAll( tmp, ",", "" );
	                                            out = tmp;
	                                       }
	                                  
	                                  break;
	                             case "!$":
	                            	 if (validateNumero(currentValue)) {
                                         var longitud = element[0].getAttribute('maxlength');
                                         out = util_numberWithCommas(currentValue);
                                         if (out.length > parseInt(longitud)){
                                              var tmp = out.substring(0, parseInt(longitud));
                                              tmp = util_replaceAll( tmp, "$ ", "" );
                                              tmp = util_replaceAll( tmp, ",", "" );
                                              out = util_numberWithCommas(tmp);
                                         }
                                              
                                    } else {
                                         var tmp = util_replaceAll( currentValue, "$ ", "" );
                                         tmp = util_replaceAll( tmp, ",", "" );
                                         out = tmp;
                                    }
	                             	break;
	                             case "@":
	                                       out = toMaskPhone( currentValue, mphone );
	                                  break;
	                             case "#":                                    
	                                       if (validateNumero(currentValue)) {
	                                            var longitud = element[0].getAttribute('maxlength');
	                                            out = util_numberWithCommas(currentValue);
	                                            if (out.length > parseInt(longitud)){
	                                                 var tmp = out.substring(0, parseInt(longitud));
	                                                 tmp = util_replaceAll( tmp, ",", "" );
	                                                 out = util_numberWithCommas(tmp);
	                                            }
	                                       } else {
	                                            var tmp = util_replaceAll( currentValue, "," , "" );
	                                            out = tmp;
	                                       }

	                                  break;
	                             default:
	                                       out = this;
	                                  break;
	                        }/* END SWITCH MASK */
	              
	                   } else {
	                        out = this;
	                   } /* END IF-ELSE TOMASK */

	                   return out;

	              };/* END PROTOTYPE TO MASK */
	              
	              var mascaraTarjeta = function(transformedInput){
						if (transformedInput.length > 12) {
							transformedInput = transformedInput.replace(/^(\w{4}|\d{4})(\w{4}|\d{4})(\w{4}|\d{4})(\d{0,4}|\w{0,4})/,"$1 $2 $3 $4");
						}else if (transformedInput.length > 8) {
							transformedInput = transformedInput.replace(/^(\w{4}|\d{4})(\w{4}|\d{4})(\w{0,4}|\d{4})/,"$1 $2 $3");
						}else if (transformedInput.length > 4) {
							transformedInput = transformedInput.replace(/^(\w{4}|\d{4})(\w{0,5}|\d{4})/,"$1 $2");
						}else{
							transformedInput = transformedInput.replace(/^(\w{0,4}|\d{4})(\w{4}|\d{4})(\w{4}|\d{4})(\w{4}|\d{4})/,"$1 $2 $3 $4");
						} 
						return transformedInput;
					}

	              var _valida = function (element,end1,start1, ngModel){
	                   
	                   var re = /^\s+|\s+$|(\s)\s+/g;     
	                   // elimina espacios
	                   cleanVal = element.val().replace( re, ' ' );
	                   cleanValCU = element.val().replace( re, ' ' );
	                   cleanValMail = element.val().replace( re, ' ' );
	                   
	                   var reSpecial = /\!|\¡|\&|\<|\>|\?|\¿|\+|\%|\$|\@|\'|\"|\{|\}|\*|\/|\=|\|/g;
	                   var reSpecialCU = /\!|\¡|\&|\<|\>|\?|\¿|\+|\%|\$|\@|\'|\"|\{|\}|\*|\/|\=/g;
	                   var reSpecialT = /\!|\¡|\&|\<|\>|\?|\¿|\+|\%|\$|\@|\'|\"|\-|\{|\}\/|\=|\°|\#|\(|\)|\[|\]|\¨|\_|\:|\;|\|/g;
//	                   var reEmoji = /[^\w.,\s\u0104\u0106\u0118\u0141\u0143\u00D3\u015A\u0179\u017B\u0105\u0107\u0119\u0142\u0144\u00F3\u015B\u017A\u017C]/g;
	                   var reEmoji = /[\uD800-\uDBFF]|[\uDC00-\uDFFF]|\ud83d[\ude00-\ude4f]/g;
	                   var cleanValT = cleanVal.replace( reSpecialT, '' );
	                   cleanVal = cleanVal.replace( reSpecial, '' );
	                   cleanValCU = cleanValCU.replace( reSpecialCU, '' );
	                   cleanVal = cleanVal.replace( reEmoji, '' );
	                   cleanValCU = cleanValCU.replace( reEmoji, '' );
	                   cleanValT = cleanValT.replace( reEmoji, '' );
	                   cleanValMail = cleanValMail.replace( reEmoji, '' );
	                   var  transformedInput = cleanVal;    
	                   // busca la etiquetade formatol
	                   var formato = element[0].getAttribute('formato');
	                   var formatoArray = null;
	                   
	                   if (formato)
	                        formatoArray = formato.split("-");
	                   else
	                        formatoArray =[""];                                                        

	                   switch (formatoArray[0]) {                                       
	                        
	                        case "M": //transforma de minusculas a mayusculas
	                        		var valor = cleanVal.replace(/[^A-Za-z0-9ñÑ ]/g, '');
	                                  transformedInput = valor ? valor.toUpperCase() : "";

	                             break;
	                        case "MAIL": //transforma de minusculas a mayusculas
                        		var valor = cleanValMail.replace(/[^A-Za-z0-9-_.\@]/g, '');
                        		 transformedInput = valor ? valor.toLowerCase() : "";
//                                  transformedInput = valor;

                             break;
	                        case "MCU": //transforma de minusculas a mayusculas o CU
                                
                                	  transformedInput = cleanValCU ? cleanValCU.toUpperCase() : "";

                                break;
	                        case "m": //transforma de mayusculas a minusculas
	                                  
	                                  transformedInput = cleanVal ? cleanVal.toLowerCase() : "";

	                             break;
	                        case "Lm": //transforma de mayusculas a minusculas y solo permite letras
	                                  
	                        		  var valor = cleanVal.replace(/[^A-Za-zñÑ ]/g, '');
	                                  transformedInput = valor ? valor.toLowerCase() : "";

	                             break;
	                        case "LM": //transforma de minusculas a mayusculas y solo permite letras
	                                  
	                        	      var valor = cleanVal.replace(/[^A-Za-zñÑ ]/g, '');
	                                  transformedInput = valor ? valor.toUpperCase() : "";

	                             break;
	                        case "LMP": //transforma de minusculas a mayusculas, solo permite letras, guiones y puntos
                                
	                        	var valor = cleanVal.replace(/[^ñÑA-Za-z-. ]/g, '');
                                transformedInput = valor ? valor.toUpperCase() : "";
                                
	                        	break;
	                        case "LMSP": //transforma de minusculas a mayusculas, No permite caracteres especiales al inicio de una cadena
		                        	var detectarCaracteres = function(cadena){
									var arrCaracEsp = [".","-","'"];
									for(var i=0;i<arrCaracEsp.length;i++){
										if(cadena.indexOf(arrCaracEsp[i]) == 0){
											cadena = cadena.replace(arrCaracEsp[i],"");
										}
									}
									
									return cadena;
								}
	
		                        	cleanVal = 	detectarCaracteres(typeof cleanVal === "string"?cleanVal:"");
	                        	
	                        		var valor = cleanVal.replace(/[^ñÑA-Za-z-. ]/g, '');
	                        		transformedInput = valor ? valor.toUpperCase() : "";
                                
	                        	break;
	                        case "LMN": //transforma de minusculas a mayusculas, solo permite letras y numeros
                                
	                        	var valor = cleanVal.replace(/[^A-Za-z0-9]/g, '');
                                transformedInput = valor ? valor.toUpperCase() : "";

                                break;
	                        case "NP": //solo admite numeros positivos
	                                  
	                                  var valor = element.val().replace( /\s/g, '',"$1 " );
	                                  transformedInput = valor ? valor.replace(/[^\d\s.]/g, '') : '';
	                                  
	                                  if (isNaN(transformedInput)){                     
	                                       var valorInt = transformedInput.replace(/--/g, "-");
	                                       transformedInput = valorInt;
	                                       var valorInt =    transformedInput.replace("..", ".");
	                                       transformedInput = valorInt;
	                                       var valorInt =    transformedInput.replace(/,/g, "");
	                                       transformedInput = valorInt;
	                                       
	                                       if (transformedInput == "-" || transformedInput == "." ){
	                                       // nothing
	                                       }else{
	                                            if (isNaN(transformedInput)){
	                                                 transformedInput = "";
	                                            }
	                                       }
	                                  }
	                                  
	                                  if (transformedInput){
	                                       transformedInput=transformedInput.toString().toMask(formatoArray[1],element);
	                                  }

	                             break;
	                        case "NI":  //solo admite numeros enteros
	                                  
	                                  var valor = element.val().replace( /\s/g, '',"$1 " );
	                                  transformedInput = valor ? valor.replace(/[^\d-]/g,'') : "";
	                                  
	                                  if (isNaN(transformedInput)){                     
	                                       var valorInt = transformedInput.replace(/--/g, "-");
	                                       if (transformedInput != "-"){
	                                            transformedInput =  parseInt(valorInt);
	                                            if (isNaN(transformedInput)){
	                                                 transformedInput = "";
	                                            }
	                                       }
	                                  }else{
	                                	  if( ngModel.$modelValue == null ){
	                                		  transformedInput = null;
	                                	  }
	                                  }
	                                  
	                                  if (transformedInput){
	                                       transformedInput=transformedInput.toString().toMask(formatoArray[1],element);
	                                  }

	                             break;
	                        case "NIP":  //solo admite numeros enteros positivos
	                                  
	                                  var valor = element.val().replace( /\s/g, '',"$1 " );
	                                  transformedInput = valor ? valor.replace(/[^\d]/g,'') : "";
	                                  
	                                  if (isNaN(transformedInput)){                     
	                                       var valorInt = transformedInput.replace(/--/g, "-");
	                                       transformedInput = valorInt;
	                                       if (transformedInput != "-"){
	                                            transformedInput =  parseInt(valorInt);
	                                            if (isNaN(transformedInput)){
	                                                 transformedInput = "";
	                                            }
	                                       }
	                                  }
	                                  
	                                  if (transformedInput){
	                                       transformedInput=transformedInput.toString().toMask(formatoArray[1],element);
	                                  }
	                             break;
	                        case "N":  //solo admite numeros
	                                  
	                                  var valor = element.val().replace( /\s/g, '',"$1 " );
	                                  transformedInput = valor ? valor.replace(/[^\d\s.-]+/i, '') : '';
	                                  
	                                  if (isNaN(transformedInput)){                     
	                                       var valorInt = transformedInput.replace(/--/g, "-");
	                                       transformedInput = valorInt;
	                                       var valorInt =    transformedInput.replace("..", ".");
	                                       transformedInput = valorInt;
	                                       var valorInt = transformedInput.replace(/,/g, "");
	                                       transformedInput = valorInt;
	                                            if (transformedInput == "-" || transformedInput == "." || transformedInput == "-."){
	                                                 // nothing
	                                            }else{
	                                                 if (isNaN(transformedInput)){
	                                                      transformedInput = "";
	                                                 }
	                                            }
	                                  }
	                                  
	                                  if (transformedInput){
	                                       transformedInput=transformedInput.toString().toMask(formatoArray[1],element);
	                                  }
	                             
	                             break;
	                             
	                        case "T": //mascara para tarjetas aderir atributo mascara="variable scope" aqui se dejara el valor real 
	                        	var valorSobrante = "";
								var valorInput = cleanValT ? cleanValT.replace(/[^\dX ]/g,'') : "";
								transformedInput = valorInput.substr(0,19);
								var modeloMascara = element[0].getAttribute('mascara');
								var valor = eval( "( scope." + modeloMascara + ")" );
								var valorReal = valor;
								valorReal = mascaraTarjeta(valorReal);
								if (valorReal.length  > transformedInput.length){
									if (end1  == start1){
										var re = new RegExp("(.{"+ (end1 - 1) +"}).{1}");
									}else{
										var re = new RegExp("(.{"+ (start1) +"}).{1}");
									}
		    								
									valorReal = valorReal.replace(re,"$1");
									valor = valorReal.replace(/\s/g, '',"$1 ");
									transformedInput = transformedInput.replace(/\s/g, '',"$1 ");
									for (var i = 0; (i < transformedInput.length && i < 12)  ;i++){
										if (!isNaN(transformedInput[i])){
											var re = new RegExp("(.{"+ i +"}).{1}");
											transformedInput = transformedInput.replace(re,"$1X");
										}	                            	
									}
								}else{
									
									transformedInput = transformedInput.replace(/\s/g, '',"$1 ");	
									for (var i = 0; (i < transformedInput.length)  ;i++){
										if (!isNaN(transformedInput[i])){
											if (i < 12){
												valor = valor.substr(0,i)+transformedInput[i]+valor.substr(i,19)
												var re = new RegExp("(.{"+ i +"}).{1}");
												transformedInput = transformedInput.replace(re,"$1X");
											}

										}	                            	
									}
									if (transformedInput.length > 12){
										if (end1 < 14 && valor.substring(12, 16) != ""){
											transformedInput = transformedInput.substring(0,12) + valor.substring(12, 16);
										}else{
											valor = valor.substring(0, 12) + transformedInput.substring(12,16);
										}
									}
								}	

								transformedInput = transformedInput.replace(/\s/g, '',"$1 ");
								if (transformedInput == "")
									scope.$eval( modeloMascara + "='" + transformedInput + "'");
								else
									scope.$eval( modeloMascara + "='" + valor + "'");
								transformedInput = mascaraTarjeta(transformedInput); 
								break;  
								
	                   }/* END SWITCH */

	                   if (transformedInput != cleanVal && transformedInput ){
	                        var endValor = transformedInput.length - cleanVal.length;
	                        end1 = end1 + endValor;
	                        start1 = end1;
	                   }

	                   cleanVal = transformedInput;
	                   element.val( cleanVal );  
	                   ngModel.$setViewValue( cleanVal );
	                   
	                   return {
	                        end: end1,
	                        start: start1
	                   };

	              }/* END SCOPE VALIDA */

	              element.on( 'keyup', function( e ) {
                      
	            	  if (element[0].hasAttribute('minlength')){
		            	  var longitud = parseInt(element[0].getAttribute('minlength'));
	                      if( longitud > 0 ){
	                    	  start = this.selectionStart;
		                      end = this.selectionEnd;                                                 
	                          var validaInput = _valida(element,end,start,ngModel);
//	                          var valida1 = element[0].value;
//	                          var start2 = end + (valida1.length - anterior.length);
//	                          if (start2 < 0)
//	                               start2 = 1;
//	                          var end2 = start2;
	                          if( element[0].setSelectionRange && document.activeElement == element[0] )
		            			  element[0].setSelectionRange(validaInput.start, validaInput.end );
	                          
	                      }
	            	  }
	              });/* END KEYDOWN */
	              
	              element.on( 'keydown', function( e ) {
	                        start = this.selectionStart;
	                        end = this.selectionEnd; 
	                        if (e.keyCode == "46"){
	                             end = end + 1
	                        }
	                        anterior = element[0].value;
	              });/* END KEYDOWN */
	              
	              
	              element.on( 'blur', function(){
	                   var cleanVal = element.val().trim();
	                   element.val( cleanVal );
	                   ngModel.$setViewValue( cleanVal ); 
	              });/* END BLUR */

	              scope.$watch(attrs.ngModel, function(){
	            	  
	            	  var validaInput = _valida(element,end,start,ngModel);
	            	  var valida1 = element[0].value;
	            	  
	            	  if (element){
	            		  var start2 = end + (valida1.length - anterior.length);
	            		  if (start2 < 0)
	            			  start2 = 1;
	            		  var end2 = start2;
	            		  if( element[0].setSelectionRange && document.activeElement == element[0] )
	            			  element[0].setSelectionRange(start2, end2 );
	            	  }
	            	  
	            	  if( firstTime ){
	            		  if( element[0].blur && document.activeElement == element[0] )
	            			  element[0].blur();
		              }
	            	  
	            	  firstTime = false;
	            	  
	              });/* END WATCH */
	              

	         }/* END LINK */
	    
	    };/* END RETURN */

	});/* END DIRECTIVE WITHOUT-SPACE*/
	
	
	app.directive("myCurrency", function($filter, $locale, generalService) {
		return {			
		       require: 'ngModel',		       
		        link: function(scope, element, attrs, ngModel) {
		        	var currency = $filter('currency'), formats = $locale.NUMBER_FORMATS;	
		        	
		        	
		        	scope.$watch(attrs.ngModel, function(newValue, oldValue){
		        		var value = newValue		        		
		        				        		
		        		value = generalService.cleanValue( newValue );
		        		if(value!=null && value.toString().length > 0){	
		        			value = currency(value, formats.CURRENCY_SYM+" ");
		        			var formatvalue =  value.replace(new RegExp('\\' + formats.DECIMAL_SEP + '\\d{2}'), '');
		        					        			
		        			ngModel.$setViewValue( formatvalue );		        			
			        		element.val( formatvalue );
			        	
		        		}
		        				        		
					});		        					        	
		        
		        }
		};
	});
	
	
	
//	app.directive('onTouch', function($parse, $timeout) {
//		  return {
//		        restrict: 'A',
//		        link: function(scope, elm, attrs) {
//		        	var scopeExpression = attrs.onTouch
//		            var invoker = $parse( scopeExpression );
//		        	var tapped;
//	        	    tapped = false;
//	        	    
//		        	if(esIpad){
//		        	    
//		        		elm.bind('touchstart', function(evt) {
//			                
////			        		scope.longPress = true;
////			        		scope.contTouch = 0;
//			        		
//			        		return tapped = true;			        		
//			        		
////							$timeout(function() {
////								if ( scope.longPress ) {
////									scope.$apply(function() {
////										evt.preventDefault();
////						        		evt.stopPropagation();
////									});
////								}
////							}, 1);
//			            });
//		        		
//		        		elm.bind("touchmove", function(event) {
//		        		      tapped = false;
//		        		      return event.stopImmediatePropagation();
//		        		});
//		        		
//			        	elm.bind('touchend', function(evt) {
////			                evt.preventDefault();
////			        		evt.stopPropagation();
//			        		if( tapped )
//			        			return scope.$apply(function() {invoker(scope,{$event: evt});});
//			            });
//		        	}else{
//		        	
//			            elm.bind('click', function(evt){
//			                evt.preventDefault();
//			                scope.$apply(function() {invoker(scope,{$event: evt});});		                
//			            });
//		            }
//		        }
//		    };
//	});
	
	app.directive('onTouch', function($parse, $timeout) {
		  return function(scope, elm, attrs) {
		        	
		        	var scopeExpression = attrs.onTouch;
		            var invoker = $parse( scopeExpression );
		        	
		            var tapped;
		            tapped = false;
		            
		            if( esIpad ){
		            
		            	elm.bind("touchstart", function(event) {
			            	event.preventDefault();/*FIX*/
		            		return tapped = true;		              
			            });
			            
			            elm.bind("touchmove", function(event) {
			            	tapped = false;
			            	return event.stopImmediatePropagation();
			            });
			            
			            return elm.bind("touchend", function(event) {
			            	event.preventDefault();
			            	event.stopPropagation();
			            	if (tapped) {
			            		return scope.$apply(attrs["onTouch"]);
			            	}
			            });
		            	
		            }else{
			            elm.bind("click", function( event ) {
			            	event.preventDefault();
			            	event.stopPropagation();
			            	if (!tapped) {
			            		return scope.$apply(attrs["onTouch"]);
			            	}		            	
			            });
		            }
		            
//		        	var scopeExpression = attrs.onTouch
//		            var invoker = $parse( scopeExpression );
//		        	if(esIpad){
//			        	elm.bind('touchend', function(evt) {
//			                evt.preventDefault();
//			                scope.$apply(function() {invoker(scope,{$event: evt});});
//			            });
//		        	}
//		            elm.bind('click', function(evt){
//		                evt.preventDefault();
//		                scope.$apply(function() {invoker(scope,{$event: evt});});		                
//		            });
		    };
	});
	
		
	app.directive('pdf', function() {
	    return {
	        restrict: 'E',
	        link: function(scope, element, attrs) {
	            var url = scope.$eval(attrs.src);
	            element.replaceWith('<object type="application/pdf" data="' + url + '"></object>');
	        }
	    };
	});
	
	app.directive('creaDom',  function($compile) {
		  return {
		        link: function( scope, element, attrs, ngModel) {
		        	var modelo = element[0].getAttribute('modelo');
		        	var mode = element[0].getAttribute('var');
		        	var 	modeloClase = element[0].getAttribute('ng-model');
//		        	var format = element[0].getAttribute('formato');
		        	var valor = eval( "( scope." + modelo + ")" );
		        	if (valor){
		        		var catalogo = eval( "( scope." + valor.CATALOGO + ")" );
//		        		console.log( "entre: " + (a++));
//		        	if (!format){                         		        		
		        		for( var objeto in catalogo ){
		        			if (catalogo[objeto].etiqueta == ""){
		        				var val = valor[catalogo[objeto].model]
		        				try{
		        					if (val.trim() != "")
		        						var tipo = document.createAttribute(valor[catalogo[objeto].model]);
		        				}
		        				catch(e){
		        					
		        				}	
		        				element[0].setAttributeNode(tipo);
		        			}else{
		        				var tipo = document.createAttribute(catalogo[objeto].etiqueta);
		        				 
		        				var val = valor[catalogo[objeto].model]
		        				try{
		        					tipo.value = val.trim();
		        				}
		        				catch(e){
		        					tipo.value = val;
		        				}
//		        			    	tipo.value = valor[catalogo[objeto].model];
		        				tipo.value = tipo.value.replace("undefined", "");
		        				if (tipo.value != "undefined")
		        					element[0].setAttributeNode(tipo);
		        			}  
		        		}
		        		
		        		
//		        		var tipo = document.createAttribute("ng-class");
//   			    	tipo.value = "{'colorEnabled' : "+modeloClase +" != '' && " + modeloClase + " != undeined}";
//		        		element[0].setAttributeNode(tipo);
		        		
		        		if (mode){
		        			var tipo = document.createAttribute("ng-model");
		        			tipo.value = mode;             		         
		        			element[0].setAttributeNode(tipo);
		        		}
		        		
		        		element[0].removeAttribute("crea-Dom");
		        	// Step 1: parse HTML into DOM element
		        		var template = angular.element(element);
		        	
		        	// Step 2: compile the template
		        		var linkFn = $compile(template);
		        	//console.log( linkFn );
		        	
		        	// Step 3: link the compiled template with the scope.
		        		element = linkFn(scope);
//		        		element[0].removeAttribute("type");
		        	}
		        }
		  }
	})
	

	app.directive('scrollInput', function() {
		return {
			restrict: 'AEC',
			link: function( scope, element, attrs /*ctrl*/ /*ngModel*/ ) {	
                scope.rangoI = 0;
                scope.rangoF = 50;
                scope.bar = 1400;
				element.on( 'scroll', function(data, element){
					scroll.bind();
					scope.x = $(data.originalEvent.srcElement).scrollTop();
					scope.y = data.y;
					if (scope.x > scope.bar){
		                scope.rangoF = scope.rangoF + 50;
		                scope.bar =  scope.bar + 1400;
//		                console.log("entro "+  scope.x  + " rangos "+ scope.rangoI + " "+ scope.rangoF );
					}
					if (scope.x == 0){
						scope.rangoI = 0;
		                scope.rangoF = 50;
		                scope.bar = 1400;
//		                console.log("entro "+  scope.x  + " rangos "+ scope.rangoI + " "+ scope.rangoF );
					}
				});/* END SCROLL */	
	 	    
			}/* END LINK */
	    
		};/* END RETURN */

	});/* END DIRECTIVE WITHOUT-SPACE*/
	
	app.directive("scroll", function ($window) {
	    return function(scope, element, attrs) {   
	    	scope.$parent.elemento = element;
	    	element.animate({scrollTop : 0});
	    	if (element[0].scrollHeight < element.height())
	    	    scope.$parent.fin = true;
	    	element.on( 'scroll', function(data, element){
				scroll.bind();
				var total = $(data.originalEvent.srcElement).context.scrollHeight - $(data.originalEvent.srcElement).context.clientHeight;
				var x = $(data.originalEvent.srcElement).scrollTop();
				if (x >= total - 1) {
					scope.$parent.fin = true;
	             }

	            scope.$apply();
			});/* END SCROLL */	
	    	
	    };
	});
	
	app.directive("onLettersNumbers", function() {
		return {
			restrict : 'AEA',
			require : 'ngModel',
			link : function($scope, element, attrs, ngModel){
				$scope.endsWith = function endsWith(str, suffix) {
				    return str.indexOf(suffix, str.length - suffix.length) !== -1;
				};
				
				$scope.$watch(attrs.ngModel, function(newValue, oldValue){
					if(newValue && newValue != null){
						if(newValue.trim() != ''){
							if($scope.endsWith(newValue, ' ')){
								newValue = newValue.trim().replace(/[^a-zA-Z0-9]/g, '');
								newValue+=' ';
								ngModel.$setViewValue(newValue);
								element.val(newValue);
								$(element).change();
							}else{
								newValue = newValue.replace(/[^a-zA-Z0-9]/g, '');
								ngModel.$setViewValue(newValue);
								element.val(newValue);
								$(element).change();
							}
						}else{
							newValue = newValue.trim();
							ngModel.$setViewValue(newValue);
							element.val(newValue);
							$(element).change();
						}
					}
				  });
			
			}
		};
	});
	
});