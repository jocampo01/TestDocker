'use strict';

define(["app"], function (app) {

	app.factory("avalService", function(endPointConfigService, REST){
		
		
		var service = {};
		
		service.guardaDatosAval = function(xml){	            
			var url = endPointConfigService.obtenerRutaEndPoint("guardaDatosAval");          
			var parametros = "celularRegistrado=5533662211&xmlAval="+xml;
			return REST.callHttp(url, parametros, 'POST', 'application/xml; charset=utf-8','application/json');	                              
		};
			
		
		return service; 
				
	});
	
});