'use strict';

define(["app"], function (app) {

	app.factory("bazDigitalService", function($q, $rootScope, endPointConfigService, REST, securityService, modalService, generalService){
		
		
		var service = {};								
				
		
		service.agendarCita = function(agendaCitaJson){	
// I-MODIFICACION TDC (SE AGREGA LLAMADO AL SERVIDOR DETARJETAS)			
			var URLtarjetas = false;
			if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto))
				URLtarjetas = true;
			var url = endPointConfigService.obtenerRutaEndPoint("agendarCitaBazDigital");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(agendaCitaJson)), 'POST','application/json','application/json',TIME_OUT_180SEG, URLtarjetas);		
// F-MODIFICACION TDC (SE AGREGA LLAMADO AL SERVIDOR DETARJETAS)			
		};
		
		service.agendarLlamada = function(agendaCitaJson){
// I-MODIFICACION TDC (SE AGREGA LLAMADO AL SERVIDOR DETARJETAS)							
			var URLtarjetas = false;
			if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto))
				URLtarjetas = true;
			var url = endPointConfigService.obtenerRutaEndPoint("agendarLlamadaClteVerde");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(agendaCitaJson)), 'POST','application/json','application/json',TIME_OUT_180SEG, URLtarjetas);		
// F-MODIFICACION TDC (SE AGREGA LLAMADO AL SERVIDOR DETARJETAS)			
		};
		
		service.agendaLlamadaBazDigital = function(agendaCitaJson){				
// I-MODIFICACION TDC (SE AGREGA LLAMADO AL SERVIDOR DETARJETAS)		
			var URLtarjetas = false;
			if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto))
				URLtarjetas = true;
			var url = endPointConfigService.obtenerRutaEndPoint("agendarLlamadaBazDigital");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(agendaCitaJson)), 'POST','application/json','application/json',TIME_OUT_180SEG, URLtarjetas);		
// F-MODIFICACION TDC (SE AGREGA LLAMADO AL SERVIDOR DETARJETAS)			
		};
		
		return service; 
				
	});


});