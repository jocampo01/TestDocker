'use strict'; 

define(["app"], function (app) {

	app.factory( "buroService", function( $rootScope, $location, endPointConfigService, REST, 
										  generalService, modalService, solicitudService, securityService,
										  validateService,$q,constantesTDC, tarjetaService){
		
		var service = {};
		var descCatalog = [];
		descCatalog[21] = {label:"Consumo", idLi:"consumo"};
		descCatalog[22] = {label:"Italika", idLi:"italika"};
		descCatalog[23] = {label:"Telefonia", idLi:"telefonia"};
		descCatalog[24] = {label:"Préstamo en efectivo", idLi:"prestamospersonales"};
		descCatalog[25] = {label:"Crédito Inmediato", idLi:"tarjetaazteca"};
		$rootScope.codigoBuro = null;
		
		function agregaEventoRespuestaDeBuro (exito) {
			if(exito){
				/*\Se agrega un evento para la bitacora\*/
//				(Evaluacion) - El servicio respondio correctamente
				$rootScope.addEvent( BITACORA.SECCION.evaluacion.id, BITACORA.SUBSECCION.servicioBuro.id, BITACORA.ACCION.proceso.id, 1, BITACORA.SECCION.evaluacion.guardarEnBD );
				/*\Se agrega un evento para la bitacora\*/
			} else {
//				Si el servicio de buro no responde exitosamente
				/*\Se agrega un evento para la bitacora\*/
//				(Evaluacion) - El servicio respondio con algún error
				$rootScope.addEvent( BITACORA.SECCION.evaluacion.id, BITACORA.SUBSECCION.servicioBuro.id, BITACORA.ACCION.proceso.id, 0, BITACORA.SECCION.evaluacion.guardarEnBD );
				/*\Se agrega un evento para la bitacora\*/																				
			}
		}
		
		service.consultaBuro = function(cssTittlo, cssbtnCancel, cssbtnOk, path, simulador, tipoConsulta, doFunction ){
			
			var currentPath = pathSeccion["#/" + $rootScope.paginaActual];
			var buroPath = validacionPath[currentPath];
			var esMalZonificada = $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.malZonificada.id;
			
			if( !esMalZonificada && ( generalService.validaConsultaBuro( $rootScope.solicitudJson) || simulador) && buroPath.buro && ( tipoConsulta == 0 || tipoConsulta == 1) && !($rootScope.solicitudJson.campana == "NVOPREAP" && $rootScope.solicitudJson.folioCallCenter != "" && $rootScope.solicitudJson.respuestaCallCenter == 0) ){						
				
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].domicilioActual = 1;
				
				var colorTitDatosHogar=$rootScope.paginaActual=="datosHogar"?"bgRosa":$rootScope.paginaActual=="datosPersonales"?"bgNaranja":"bgAzul";
				var colorBotDatosHogar=$rootScope.paginaActual=="datosHogar"?"rosa":$rootScope.paginaActual=="datosPersonales"?"naranja":"btn gris1";
				
				if (simulador){
					$rootScope.solicitudJson.consultaBuro = 1;
/** INICIA_OS-FLUJO COACREDITADO **/
					try{
						if($rootScope.solicitudOSJson.idSolicitud != null && $rootScope.solicitudOSJson.idSolicitud != ""){
							generalService.locationPath("/ochoPasosOS");						
						}else{
							generalService.locationPath("/ochoPasos");
						}
					}catch(e){
						generalService.locationPath("/ochoPasos");
					}
/** TERMINA_OS-FLUJO COACREDITADO **/	
				}else{
					
					/*\Se agrega un evento para la bitacora\*/
//					(Evaluacion) - Se lanza la petición para la consulta a buró
					$rootScope.addEvent( BITACORA.SECCION.evaluacion.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, 0, BITACORA.SECCION.evaluacion.guardarEnBD );
					/*\Se agrega un evento para la bitacora\*/

					console.log("ACEPTO BURO");	
					$rootScope.waitLoaderStatus = LOADER_SHOW;
										
					
					var buroRequest = {
							solicitud: $rootScope.solicitudJson,
							consultarBuro: tipoConsulta==null? 1:tipoConsulta							
					};
					
					var buroRequestEncrypt = securityService.cifrarRsaRequest(JSON.stringify(buroRequest));
					$rootScope.seConsultoBuro=true;
					var url = endPointConfigService.obtenerRutaEndPoint("consultaBuro");				
					REST.callHttp(url, buroRequestEncrypt, 'POST','application/json','application/json',120000)
					    .then(
							function(exitoburo){
								
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								
								if( exitoburo.data.codigo == RESPONSE_CODIGO_EXITO ){
									
									var responseJson = JSON.parse(exitoburo.data.respuesta);
									$rootScope.buroConditional = responseJson.codigo;
									var typeAuth = null;
								
									switch( responseJson.codigo ){
									
										case ERROR_BURO_SERVICIO:
											agregaEventoRespuestaDeBuro(true);
//											$rootScope.message("Consulta al Buro",[ERROR_SERVICE], "Aceptar", "/ochoPasos", cssTittlo, cssbtnOk);
											$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
											if( buroPath.nombrePath != "/ochoPasos" )
												generalService.locationPath( "/ochoPasos",true);
											break;
										case ERROR_BURO_SECCIONES_INCOMPLETAS:
											agregaEventoRespuestaDeBuro(true);
											$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
											if( buroPath.nombrePath != "/ochoPasos" )
												generalService.locationPath( "/ochoPasos",true);
//											$rootScope.message("Consulta al Buro",[responseJson.descripcion], "Aceptar", "/ochoPasos", cssTittlo, cssbtnOk);
											break;
										case ERROR_BURO_RECHAZADA:
											agregaEventoRespuestaDeBuro(true);
											service.productosAutorizados(responseJson.data,responseJson.descripcion);
											break;
										case BURO_CLAVES_FRAUDE:
											agregaEventoRespuestaDeBuro(true);
											$rootScope.message("Consulta al Buro",["Por favor, informa a tu cliente que estamos cuidando su historial crediticio. Es necesario que solucione su problema en el Buró de Crédito y con otras instituciones, por lo cual, no es posible continuar con la solicitud de crédito."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
											break;
										case ERROR_BURO_RECHAZADA_INGRESOS:
											agregaEventoRespuestaDeBuro(true);
//											$rootScope.message("Consulta al Buro",[responseJson.descripcion], "Aceptar", "/", cssTittlo, cssbtnOk);
											$rootScope.message("Consulta al Buro",["Por favor, informa a tu cliente que estamos cuidando su historial crediticio. Es necesario que solucione su problema en el Buró de Crédito y con otras instituciones, por lo cual, no es posible continuar con la solicitud de crédito."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
											break;
										case BURO_AUTORIZADO_SCORE:
											agregaEventoRespuestaDeBuro(true);
											typeAuth = BURO_AUTORIZADO_SCORE;
											($rootScope.consultaFuncionalidad.creditoInmediatoHabilitado)?consultaDomicilio(responseJson, path, doFunction, typeAuth):doSuccessFn( responseJson, path, doFunction, typeAuth );
											break;
										case RESPONSE_ORIGINACION_CODIGO_EXITO:
											agregaEventoRespuestaDeBuro(true);
											if(responseJson.data != null){
												if($rootScope.solicitudJson.tarjetasCredito != undefined && $rootScope.campanasConvivencia($rootScope.solicitudJson.campana)){
													$rootScope.modalConvivenviaDesdeBuro = true;
												}
												typeAuth = RESPONSE_ORIGINACION_CODIGO_EXITO;
												($rootScope.consultaFuncionalidad.creditoInmediatoHabilitado)?consultaDomicilio(responseJson, path, doFunction, typeAuth):doSuccessFn( responseJson, path, doFunction, typeAuth );
											}else{
												$rootScope.message("Consulta al Buro",["Lo sentimos, infórmale a tu cliente que por el momento no califica para obtener un crédito en Banco Azteca."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
											}
											break;
										case BURO_RECALCULAR_PLAZO:
											agregaEventoRespuestaDeBuro(true);
											typeAuth = BURO_RECALCULAR_PLAZO;
											($rootScope.consultaFuncionalidad.creditoInmediatoHabilitado)?consultaDomicilio(responseJson, path, doFunction, typeAuth):doSuccessFn( responseJson, path, doFunction, typeAuth );								
											break;
										case BURO_AUTORIZADO_PORCOMPROBAR:
											agregaEventoRespuestaDeBuro(true);
											typeAuth = BURO_AUTORIZADO_PORCOMPROBAR;
											($rootScope.consultaFuncionalidad.creditoInmediatoHabilitado)?consultaDomicilio(responseJson, path, doFunction, typeAuth):doSuccessFn( responseJson, path, doFunction, typeAuth );
											break;
/** INICIA_OS-FLUJO COACREDITADO **/
										//Códigp de respuesta para seguir el Coacreditado
										case BURO_OBLIGADO_SOLIDARIO:
											agregaEventoRespuestaDeBuro(true);
											$rootScope.muestraObligadoSolidario = true;
											$rootScope.tieneIntentos = false
											generalService.locationPath("/ochoPasos");
											typeAuth = BURO_OBLIGADO_SOLIDARIO;
											($rootScope.consultaFuncionalidad.creditoInmediatoHabilitado)?consultaDomicilio(responseJson, path, doFunction, typeAuth):doSuccessFn( responseJson, path, doFunction, typeAuth );
/** TERMINA_OS-FLUJO COACREDITADO **/
											break;
										case BURO_RESCATE_CONSUMO:
										case BURO_RESCATE_ITALIKA:
										case BURO_RESCATE_TELEFONIA:
											$rootScope.esSolicitudRescate = true;
											agregaEventoRespuestaDeBuro(true);
											$rootScope.rescateFaseIII=true;
											$rootScope.onceOfert = true;
											$rootScope.recargarInformacionQF = true;
											if(generalService.nuevoFlujoQickFixes())
												$rootScope.mostrarOfertaCotizador = false;
											$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
											$rootScope.solicitudJson = responseJson.data.solicitud;
											generalService.locationPath("/ochoPasos");
											break;
										case BURO_CALIFICA_PARA_MINICONSUMO: 
										case BURO_CALIFICA_PARA_MINICONSUMO_VALIDO_KO:
										case BURO_CALIFICA_PARA_MINICONSUMO_ROJO_KO:
											$rootScope.esSolicitudRescate = true;
											agregaEventoRespuestaDeBuro(true);
											$rootScope.onceOfert = true;
											$rootScope.recargarInformacionQF = true;
											if(generalService.nuevoFlujoQickFixes())
												$rootScope.mostrarOfertaCotizador = false;
											$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
											
											 if (responseJson.codigo == BURO_CALIFICA_PARA_MINICONSUMO)
												 $rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescate;
											 
											if (responseJson.codigo == BURO_CALIFICA_PARA_MINICONSUMO_VALIDO_KO)
												$rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescateFDos;
											
											if (responseJson.codigo == BURO_CALIFICA_PARA_MINICONSUMO_ROJO_KO)
												$rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescateFCuatro;
											
											generalService.locationPath("/ochoPasos");
											
											break;
										case BURO_ITALIKA_ROJO_SIN_KO:
										case BURO_CLIENTE_APTO_PARA_PRODUCTO_DE_RESCATE_ITALIKA:
										case BURO_ITALIKA_COLOR_VALIDO_KO:
										case BURO_ITALIKA_ROJO_CON_KO:
											agregaEventoRespuestaDeBuro(true);
											$rootScope.onceOfert = true;
											$rootScope.recargarInformacionQF = true;
											if(generalService.nuevoFlujoQickFixes())
												$rootScope.mostrarOfertaCotizador = false;
											$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
											
											if (responseJson.codigo == BURO_ITALIKA_ROJO_SIN_KO)
												 $rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.aplicaRescateItalikaScore;
											 
											if (responseJson.codigo == BURO_CLIENTE_APTO_PARA_PRODUCTO_DE_RESCATE_ITALIKA){
												$rootScope.esSolicitudRescate = true;
												 $rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.aplicaRescateItalikaScore;
											}
											if (responseJson.codigo == BURO_ITALIKA_COLOR_VALIDO_KO){
												$rootScope.esSolicitudRescate = true;
												$rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.aplicaRescateItalikaKnockOut;
											}
											if (responseJson.codigo == BURO_ITALIKA_ROJO_CON_KO){
												$rootScope.esSolicitudRescate = true;
												$rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.aplicaRescateItalikaKnockOutScore;
											}
											
											
											$rootScope.codigoBuro = responseJson.codigo;
											generalService.locationPath("/ochoPasos");
												
											break;
											
										case BURO_CLIENTE_APT0_PARA_PRODUCTO_DE_RESCATE_TELEFONIA:
											$rootScope.recargarInformacionQF = true;
											$rootScope.esSolicitudRescate = true;
											agregaEventoRespuestaDeBuro(true);
											$rootScope.codigoBuro = responseJson.codigo;
											generalService.locationPath( "/ochoPasos" );
											break;
										
											/** REQ 87110 - Producto de Rescate Prestamos Personales **/
										case BURO_CLIENTE_APT0_PRODUCTO_RESCATE_PRESTAMO_ROJO:
										case BURO_CLIENTE_APT0_PRODUCTO_RESCATE_PRESTAMO_VALIDO_KO:
										case BURO_CLIENTE_APT0_PRODUCTO_RESCATE_PRESTAMO_ROJO_KO:
											/** FASE II **/
											$rootScope.esSolicitudRescate = true;
										case BURO_CLIENTE_APT0_RESCATE_PP_PRESTAMO:
										case BURO_CLIENTE_APT0_RESCATE_PP_SIN_PRESTAMO:
											/** FASE II **/
                                            $rootScope.recargarInformacionQF = true;
											agregaEventoRespuestaDeBuro(true);
											typeAuth = RESPONSE_ORIGINACION_CODIGO_EXITO;
											doSuccessFn( responseJson, path, doFunction, typeAuth );
											
											break;
											/** REQ 87110 - Producto de Rescate Prestamos Personales **/
										case 1390:
										case 1391:
										case 1392:
										case 1393:
											$rootScope.esSolicitudRescate = true;
											agregaEventoRespuestaDeBuro(true);
											var valor = responseJson.codigo;
											$rootScope.onceOfert = true;
											if(generalService.nuevoFlujoQickFixes())
												$rootScope.mostrarOfertaCotizador = false;
											$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
											console.log(valor);
											var titulo = valor==1391?"En Banco Azteca le decimos CÓMO SI  a nuestros clientes":"En Banco Azteca le decimos CÓMO SI  a nuestros clientes";
											modalService.cambaceoModal(titulo, valor ).then( 
													function(exito){
														console.log("Continuar");
													}, function(error){
														console.log("Regresa al simulador del cliente");
													});
											generalService.locationPath( "/ochoPasos" );
											break;
										case 1394:
											agregaEventoRespuestaDeBuro(true);
											$rootScope.solicitudJson.marca = STATUS_SOLICITUD.pendienteProceso.marca.alternativaCambaceo; 
											service.productosAutorizados(responseJson.data,responseJson.descripcion);
											break;
										case BURO_CP_INVALIDO:
											agregaEventoRespuestaDeBuro(true);
											$rootScope.message("Consulta al Buro ["+BURO_CP_INVALIDO+"]",["No se pudo consultar buró."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
											break;
										case BURO_CP_SIN_FORMATO:
											agregaEventoRespuestaDeBuro(true);
											$rootScope.message("Consulta al Buro ["+BURO_CP_SIN_FORMATO+"]",["No se pudo consultar buró."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
											break;
										case BURO_CP_ERROR_PARSEO:
											agregaEventoRespuestaDeBuro(true);
											$rootScope.message("Consulta al Buro ["+BURO_CP_ERROR_PARSEO+"]",["No se pudo consultar buró."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
											break;
										case BURO_CP_NOM_INCOMPLETO:
											agregaEventoRespuestaDeBuro(true);
											$rootScope.message("Consulta al Buro ["+BURO_CP_NOM_INCOMPLETO+"]",["No se pudo consultar buró."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
											break;
										case ERROR_INESPERADO:
											agregaEventoRespuestaDeBuro(false);
											generalService.cleanRootScope($rootScope);							
											generalService.buildSolicitudJson($rootScope, null);
											if($rootScope.solicitudOSJson){
												generalServiceOS.cleanRootScope($rootScope);
												generalService.buildSolicitudOSJson($rootScope, null);
											}
											$rootScope.message("Error " + ERROR_INESPERADO,["Ocurrió un inconveniente, favor de volver a recuperar la solicitud."], "Aceptar", "/simulador", "bgazul", "azul", null, null, null);
											break;
										default:
											agregaEventoRespuestaDeBuro(false);
											$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
											generalService.locationPath( "/ochoPasos",true);
//											$rootScope.message("Consulta al Buro",[ERROR_SERVICE], "Aceptar", "/ochoPasos", cssTittlo, cssbtnOk);
									
									}																																																
									
								}else{
									agregaEventoRespuestaDeBuro(false);
//									$rootScope.message("Consulta al Buro",[ERROR_SERVICE], "Aceptar", "/ochoPasos", cssTittlo, cssbtnOk);
									$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
									generalService.locationPath( "/ochoPasos",true);
								}																									
							}, function(error){
								agregaEventoRespuestaDeBuro(false);
								$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
				                $rootScope.waitLoaderStatus = LOADER_HIDE;
				                if(path == null || path == undefined)
									generalService.locationPath("/ochoPasos",true);
								else
									generalService.locationPath(path);								                												
							}
					);
									
				}
			}else{
				if(generalService.validaTermino($rootScope.solicitudJson)){
					generalService.locationPath("/ochoPasos",true);
				}else{
					if(path == null || path == undefined)
						generalService.locationPath("/ochoPasos",true);
					else
						generalService.locationPath(path,true);
				}
					
			}
				
						
		};
		
		function consultaDomicilio(responseJson, path, doFunction, typeAuth) {
			$rootScope.waitLoaderStatus = LOADER_SHOW; 

			var idSolicitud = $rootScope.solicitudJson.idSolicitud;	

			solicitudService.consultaDomicilio(idSolicitud).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
							var solicitudJsonConsultaDomicilio = JSON.parse(data.data.respuesta);
							
							if(solicitudJsonConsultaDomicilio.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								
								if(responseJson.data == null){
									responseJson.data = {solicitud:""};
								}
								
								responseJson.data.solicitud = solicitudJsonConsultaDomicilio.data;
								doSuccessFn( responseJson, path, doFunction, typeAuth );
							}else{
								$rootScope.message("Error", [solicitudJsonConsultaDomicilio.descripcion], "Aceptar");
							}
						} else {
							$rootScope.message("Error", ["Error al consultar servicio de Fonetica de Domicilio, por favor comuniquese con soporte."], "Aceptar");
						}

					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
					}
			);
		}
		
		service.productosAutorizados=function(data,descripcion){
			var banderaCanalesGS = generalService.isCanalInterno($rootScope.sucursalSession.idCanal);
			var colorTitDatosHogar=$rootScope.paginaActual=="datosHogar"?"bgRosa":$rootScope.paginaActual=="datosPersonales"?"bgNaranja":"bgAzul";
			var colorBotDatosHogar=$rootScope.paginaActual=="datosHogar"?"rosa":$rootScope.paginaActual=="datosPersonales"?"naranja":"btn gris1";
			var banderaSolicitudInformada= data && data.solicitud?true:false;
			
			var productoElegido = "préstamo personal";
			var rechazoTodosProductos = false;
			if(data && !banderaSolicitudInformada){
				/*
				 * Excluye el producto cotizado y valida el color de los productos en el array de productos de rescate
				 */
				data = data.filter(function(value, index, ar){
						if(value.idProducto != $rootScope.solicitudJson.idProducto){
							return true;
						}
						return false;
					});
					if(data.length == 0){
						rechazoTodosProductos = true;
					}
				// SE COMENTA PARA QUE NO VALIDE PRODUCTOS RECHAZADOS INI
					$rootScope.rechazoBuro=true;
			}else
				rechazoTodosProductos = true;
				
			
			// SE COMENTA PARA QUE NO VALIDE PRODUCTOS RECHAZADOS FIN
			//Se valida si todos los productos son rechazados
			if (rechazoTodosProductos || !banderaCanalesGS){
				/**if(!generalService.isEmpty(descripcion) && descripcion==="Solicitud Rechazada por buro"){
					descripcion = "Te sugerimos mejorar tu información en el Buró de Crédito. O regresa a partir del "
						+ "15 de diciembre, tendremos una alternativa para tu caso en particular.", "www.burodecredito.com.mx";
				}
				
				$rootScope.message("Consulta al Buró",[ (generalService.isEmpty(descripcion)?"La solicitud no fue aprobada para ningun producto.":descripcion) ], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
				**/
				
				$rootScope.message("Consulta al Buró",["Lo sentimos, infórmale a tu cliente que por el momento no califica para obtener un crédito en Banco Azteca."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
				
			}else{
				var productosRescate = SUCURSALES_BURO.productosrescate.indexOf($rootScope.sucursalSession.idSucursal)!=-1?true:false;
				
//				var banderaCanalesGS = false;
//				angular.forEach(CANALESGS, function(value, key) {
//					if(value == $rootScope.sucursalSession.idCanal){
//						banderaCanalesGS = true;
//					}
//				});
				var x = 0;
				var catCssProductos=[];
				var productosAutorizados=[];
				var productosAutorizadosModal=[];
				var productos = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.CATALOGO PRODUCTOS"];
				for (var i=0;i < data.length;i++){
					if(data[i].idProducto != ID_PRODUCTO.tarjetaazteca){
						for(var a=0;a < productos.length;a++){
							if(data[i].idProducto == parseInt(productos[a].ID.valor)){
								productosAutorizados[x]=productos[a];
								break;
							}
						}
						$rootScope.productosAutorizados[x]=data[i];
						x++;
					}
				}
				
				for(var j=0;j<productos.length;j++){
					if($rootScope.solicitudJson.idProducto == parseInt(productos[j].ID.valor)){
						productoElegido = productos[j].ETIQUETA.valor;
						break;
					}									
				}
				
				for (var i=0; i<productosAutorizados.length; i++){
					var productId = parseInt(productosAutorizados[i].ID.valor);
					var estiloProducto = productosAutorizados[i].ETIQUETA.valor.replace(/\s/g,"");
					estiloProducto=productId==ID_PRODUCTO.prestamospersonales?"prestamospersonales":productId==ID_PRODUCTO.modatelas?"tarjetaazteca":estiloProducto;
					catCssProductos[i]=estiloProducto.toLowerCase();
					productosAutorizadosModal.push( { liId:catCssProductos[i], radioLabel:productosAutorizados[i].ETIQUETA.valor, radioId:"opc-producto-"+(i+1), radioValue:productId, disable:(generalService.cambaceoRechazadoConAlternativas($rootScope.solicitudJson.marca)?'true':'false') } );
				}
				$rootScope.idProductoAvisoModal=$rootScope.solicitudJson.idProducto;
//					var msnModal="Infórmale a tu cliente que por el momento no es candidato para "+productoElegido+"; sin embargo,"
				var msnModal="Infórmale a tu cliente que el producto "+productoElegido+" no fue autorizado, pero después de una visita de verificación en su domicilio podría ser aprobado un crédito para:";
// I-MODIFICACION TDC (PARAMETRIZAR EL MENSAJE DE PARA PRODUCTOS DE TARJETA)								
				var titulo = "Aviso Importante";
				var btn = "Cotizar después";
				var color = "btn gris1";
				var msnModal2 = ""; 
				if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
					msnModal="<div style='font-size:20px'><b>Infórmale a "+ $rootScope.nombreCamel + " " + $rootScope.apellidoPaternoCamel + " " + $rootScope.apellidoMaternoCamel+"</b></div>"; 
					titulo = "AVISO";
					btn = "Terminar";
					color = "btn Azul"
					msnModal2 = "Que por el momento no podemos otorgarle una "+ productoElegido + ".";
				}
// F-MODIFICACION TDC (PARAMETRIZAR EL MENSAJE DE PARA PRODUCTOS DE TARJETA)
				
/**INICIA Cambiamos los mensajes cuando es un ca,baceo y el producto cotizado es rechazado **/	
				if(generalService.cambaceoRechazadoConAlternativas($rootScope.solicitudJson.marca)){
					titulo = "Aviso Importante";
					msnModal = " Infómarle a tu cliente que el " + productoElegido + " no fue autorizado,sin embargo, tenemos las siguientes opciones de crédito: ";
					btn = "Aceptar";
				}
/** TERMINA Cambaceo**/				
				
				modalService.avisoProductos(titulo,[msnModal, msnModal2],btn,"bgAzul",color,null,null,"12345",productosAutorizadosModal)									
				.closePromise.then(
					function(exito){
						if($rootScope.idProductoAvisoModal != $rootScope.solicitudJson.idProducto){
							$rootScope.idProductoAvisoModal=$rootScope.solicitudJson.idProducto;
						}else{
							generalService.cleanRootScope($rootScope);
							generalService.buildSolicitudJson($rootScope, null);
						}
						
						generalService.locationPath( "/simulador" );
					},function(error){
						$rootScope.solicitudJson.idProducto=$rootScope.idProductoAvisoModal;
					});
				
			}
		};
				
		service.consultaBuroInterno = function(buroRequest){	
			var buroRequest = securityService.cifrarRsaRequest(JSON.stringify(buroRequest));
			
			var url = endPointConfigService.obtenerRutaEndPoint("consultaBuroInterno");			
			return REST.callHttp(url, buroRequest, 'POST','application/json','application/json');		
		};
		
		service.resultadoConsulta = function(solicitudId,rootScope){	
			var deferred = $q.defer();
						
			var url = endPointConfigService.obtenerRutaEndPoint("resultadoConsultaBuro");			
			REST.callHttp(url, securityService.cifrarRsaRequest(solicitudId), 'POST','application/json','application/json').then(
					function(data){									
						if(data.data.codigo == RESPONSE_CODIGO_EXITO ){																		
							var jresponse = JSON.parse(data.data.respuesta);
							var pagoPuntual=rootScope.solicitudJson.cotizacion.pagoPuntual;
							
							if( !generalService.flujoPorDispersion() ){
								if(generalService.isProdModatelas(rootScope))
									pagoPuntual=0;
							}
							
							if(jresponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
								var objRes={
									"datosCredito":jresponse.data,
									"resConsulta":{}
										
								};
								
								objRes.resConsulta.capacidadPago = (rootScope.solicitudJson.banderaIngresos == 1)? objRes.datosCredito.capacidadPagoComprobable : objRes.datosCredito.capacidadPagoNoComprobable;
								objRes.resConsulta.disponible = objRes.resConsulta.capacidadPago - pagoPuntual;
								objRes.resConsulta.disponible=rootScope.solicitudJson.seguroDeVida.abonoSeguro?objRes.resConsulta.disponible-rootScope.solicitudJson.seguroDeVida.abonoSeguro:objRes.resConsulta.disponible;
								objRes.resConsulta.ocupado=rootScope.solicitudJson.seguroDeVida.abonoSeguro?pagoPuntual+rootScope.solicitudJson.seguroDeVida.abonoSeguro:pagoPuntual;
									
								var indexPedido = PEDIDOS.map( function(d){
									return d['idProducto'];
								}).indexOf( parseInt(rootScope.solicitudJson.idProducto) );
								
								objRes.resConsulta.pedidos = [
					                  { 
					                	  descProducto : "Sin producto",
					                	  descSubProducto : "",
					                	  idProducto: 0,
					                	  idSubProducto: 0,
					                	  saldoPedido: ''
					                  }
								 ];
								if(indexPedido != -1){
									objRes.resConsulta.pedidos=[PEDIDOS[indexPedido]];
									objRes.resConsulta.pedidos[0].saldoPedido=pagoPuntual;
								}
								if($rootScope.solicitudJson.seguroDeVida.idSeguro){
									objRes.resConsulta.pedidos[objRes.resConsulta.pedidos.length]= { 
						                	  descProducto : "SEGURO VIDAMAX", /*$rootScope.solicitudJson.seguroDeVida.nombreSeguro*/
						                	  descSubProducto : "",
						                	  idProducto: $rootScope.solicitudJson.seguroDeVida.idSeguro,
						                	  idSubProducto: 0,
						                	  saldoPedido: $rootScope.solicitudJson.seguroDeVida.abonoSeguro
						             };
								}
								var capacidad = rootScope.solicitudJson.banderaIngresos==1?rootScope.solicitudJson.capacidadPagoComprobable:rootScope.solicitudJson.capacidadPagoNoComprobable;
								objRes.resConsulta.monto=capacidad*rootScope.solicitudJson.cotizacion.plazo;
								objRes.resConsulta.montoAutorizado=(rootScope.solicitudJson.idProducto!=ID_PRODUCTO.tarjetaazteca && !generalService.isProdModatelas(rootScope))?rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto:objRes.resConsulta.monto;
								objRes.resConsulta.descProducto=(rootScope.solicitudJson.idProducto!=ID_PRODUCTO.tarjetaazteca && !generalService.isProdModatelas(rootScope))?getDescripcionProducto(parseInt(rootScope.solicitudJson.idProducto),rootScope):"LCR";
								objRes.datosCredito.responseScoreO5Matrices = (rootScope.solicitudJson.banderaIngresos == 1)? objRes.datosCredito.responseScoreO5Matrices : objRes.datosCredito.responseScoreO5Matrices2;								
								deferred.resolve(objRes);								
																			
							}else
								deferred.reject(jresponse.descripcion);								
						}else
							deferred.reject(ERROR_SERVICE);								
					}, function(error){
					}
			);
			
			return deferred.promise;
			
			
		};
		
		service.resultadoConsultaProductos = function(solicitudId,rootScope){	
			var deferred = $q.defer();
						
			var url = endPointConfigService.obtenerRutaEndPoint("resultadoConsultaProductos");			
			REST.callHttp(url, securityService.cifrarRsaRequest(solicitudId), 'POST','application/json','application/json').then(
					function(data){									
						if(data.data.codigo == RESPONSE_CODIGO_EXITO ){																		
							var jresponse = JSON.parse(data.data.respuesta);
							
							if(jresponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){								
								deferred.resolve(jresponse.data);								
																			
							}else
								deferred.reject(jresponse.descripcion);								
						}else
							deferred.reject(ERROR_SERVICE);								
					}, function(error){
					}
			);
			
			return deferred.promise;
			
			
		};
		
		service.consultaBuroAval = function( jsonRequest ){
			var request = JSON.stringify(jsonRequest);			
			var url = endPointConfigService.obtenerRutaEndPoint( "consultaBuroAval" );			
			$rootScope.waitLoaderStatus = LOADER_SHOW;			
			REST.callHttp(url, securityService.cifrarRsaRequest( request ), 'POST','application/json','application/json').then(
					function(data){
						var jResponse = JSON.parse(data.data.respuesta);
						console.log( jResponse );
						switch (jResponse.codigo) {
							case 641:
								$rootScope.solicitudJson = jResponse.data;
								$rootScope.message( "COACREDITADO RECHAZADO", ["Infórmale a tu cliente que el Coacreditado que eligó ha sido rechazado, es necesario capturar un nuevo Coacreditado."], "Aceptar", "/ochoPasos", null, null, null, null, null );
								break;
							case 642:
								//modalService.alertModal("COACREDITADO ACEPTADO", [""], "Aceptar", null, null, null, null);
								$rootScope.solicitudJson = jResponse.data;
								generalService.locationPath("/ochoPasos");
								break;
							default:
								$rootScope.message( "BURO COACREDITADO", ["NO EXISTE EL CÓDIGO ["+jResponse.codigo+"]"], "Aceptar", "/ochoPasos", null, null, null, null, null );
						}
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
					},
					function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						generalService.locationPath("/ochoPasos");
					}
			);
		};
		
		service.getMontosPlazos = function( solicitudId, doFunction ){
			
			var url = endPointConfigService.obtenerRutaEndPoint("getMontosPlazosBuro");
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			REST.callHttp(url, securityService.cifrarRsaRequest(solicitudId), 'POST','application/json','application/json').then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
						
						var plazosResponse = JSON.parse( data.data.respuesta );							
						
						if( plazosResponse && plazosResponse != null ){

							console.log( plazosResponse );
/** INICIA_OS-FLUJO COACREDITADO **/
							if($rootScope.consultaBuroOS){
								$rootScope.consultaBuroOS = false;
								doOnSuccessFnBackOS(plazosResponse, doFunction, plazosResponse.codigo);
/** TERMINA_OS-FLUJO COACREDITADO **/
							}else{
								doOnSuccessFnBack( plazosResponse.data.plazosTermometro, plazosResponse.data.capacidadesPagoProducto, doFunction, plazosResponse.codigo );
							}
							
						}else{
							$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
						}
						
						
					}else{
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						console.error(data.data.descripcion);
						$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
					}
					
				}, function(error){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
				}
			)
			
		};
		
		var doOnSuccessFnBack = function( arrayPlazos, capacidadesPagoProducto , doFunction, argsFn )
		{
			
			generalService.setPlazos( $rootScope, arrayPlazos, argsFn );
			$rootScope.capacidadesPagoProducto=capacidadesPagoProducto;
			$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
			$rootScope.onceOfert = true;
			
			if( doFunction && doFunction != null ){
				
				if( argsFn != null && argsFn )
					doFunction( argsFn );
				else
					doFunction();
				
				return true;
				
			}
			
		};
		
/** INICIA_OS-FLUJO COACREDITADO **/
		var doOnSuccessFnBackOS = function(respuestaMontosPlazos, doFunction){
			if( doFunction && doFunction != null ){
				doFunction(respuestaMontosPlazos);
			}

			return respuestaMontosPlazos;
		};
/** TERMINA_OS-FLUJO COACREDITADO **/
		
		var doSuccessFn = function( responseJson, path, doFunction, argsFn )
		{
			
			$rootScope.solicitudJson = responseJson.data.solicitud;
			if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.malZonificada.id){
				generalService.setDataBridge( {esMalZonificada:true} );
				var excepciones = [ SECCION_HOGAR.toString() ];
				generalService.bloqueoSecciones( $rootScope.solicitudJson, excepciones );
			}
			if(generalService.nuevoFlujoQickFixes())
				$rootScope.recargarInformacionQF = true;
				
				$rootScope.mostrarOfertaCotizador = true;
			if(generalService.sobrescribeOfertaBuroConsumo($rootScope.solicitudJson))
				argsFn=RESPONSE_ORIGINACION_CODIGO_EXITO;
			
			doOnSuccessFnBack( responseJson.data.plazosTermometro, responseJson.data.capacidadesPagoProducto, doFunction, argsFn );
			
			if($rootScope.solicitudJson.campana == "NVOPREAP" && $rootScope.solicitudJson.folioCallCenter != "" && $rootScope.solicitudJson.respuestaCallCenter > 0 && $rootScope.solicitudJson.aceptaConsultaBuro == 0){
				angular.element("[ng-controller='commonController']").scope().muestraModalCotizador
			}
			
			if(path == null || path == undefined)
				generalService.locationPath("/ochoPasos");
			else
				generalService.locationPath(path);

		};
		
		var getDescripcionProducto=function(idProducto,rootScope){
	 		return generalService.getDescripcionProducto(idProducto,rootScope);
	 	};
		
		service.actualizarProductoConsumo = function(solicitudId){			
			var request = JSON.stringify(solicitudId);
			var url = endPointConfigService.obtenerRutaEndPoint("actualizarProductoConsumo");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(request), 'POST','application/json','application/json',TIME_OUT_180SEG);		
		};
		
		service.actualizaProductoRescate = function( requestJson ){				
			var url = endPointConfigService.obtenerRutaEndPoint("actualizaProductoRescate");			
			return REST.callHttp(url,  securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		return service; 
				
	});


});