'use strict';

define(["app"], function (app) {

	app.factory("callCenterService", function(endPointConfigService, REST, securityService){
		
		
		var service = {};
		
		service.getFolio = function(jsonRequest){	 			
			var url = endPointConfigService.obtenerRutaEndPoint("getFolioCallCenter");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',TIME_OUT_60SEG);	                              
		};
		
		service.liberar = function(jsonRequest){	 			
			var url = endPointConfigService.obtenerRutaEndPoint("liberarPorCallCenter");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',TIME_OUT_60SEG);	                              
		};
		
		service.dispersarTarjetas = function(jsonRequest){	 			
			var url = endPointConfigService.obtenerRutaEndPoint("getDispersionTarjetasCallCenter");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',TIME_OUT_60SEG);	                              
		};
		
		service.liberarPedidoSinTAZ = function(jsonRequest){	 			
			var url = endPointConfigService.obtenerRutaEndPoint("liberarPedidoSinTAZ");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',TIME_OUT_60SEG);	                              
		};
		
		
		return service; 
				
	});
	
});