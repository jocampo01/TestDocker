'use strict';

define(["app"], function (app) {

	app.factory("clienteUnicoService", function(endPointConfigService, REST, securityService, $rootScope){
		
		
		var service = {};
		
		/** Servicio para consulta de homonimos
		 *  homonimosJson = {
							solicitudJson: cadena con el json de la solicitud,
							huella: cadena en B64 de la huella, puiede ser vacio
							tipoBusqueda: numerico que si es 1 indica que la busqueda sera fonetica
						  } 
		 * */
		service.getHomonimos = function(homonimosJson){	  			
			var url = endPointConfigService.obtenerRutaEndPoint("getHomonimos");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosJson)), 'POST','application/json','application/json');	                              
		};
		/*
		 * Servicio para crear solicitudes de cambaceo
		 */
		service.consultaRenapo = function(homonimosJson){	  			
			var url = endPointConfigService.obtenerRutaEndPoint("consultaRenapo");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosJson)), 'POST','application/json','application/json');	                              
		};
			
		/** Servicio para consulta de homonimos del Coacreditado
		 *  homonimosJson = {
							nombre: ,
			    			apellidoPaterno: ,
			    			apellidoMaterno: ,
			    			fechaNacimiento: en formato 'dd-MM-yyyy'
						  } 
		 * */
		service.getHomonimosAval = function(homonimosJson){	  			
			var url = endPointConfigService.obtenerRutaEndPoint("getHomonimosAval");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosJson)), 'POST','application/json','application/json');	                              
		};
		
		
		/** Servicio para consulta de homonimos con busqueda fonetica
		 *  jsonRequest: Json con 2 parametros tienda y de tipo numerico y arrayCtesUnicos q es un arrelo con los nums de cliente unico
		 *   			 {
							tienda: numeroTienda,
							arrayCtesUnicos: ["pais-canal-sucursal-folio","pais-canal-sucursal-folio"]
						  } 
		 * */
		service.getHomonimosBsqFonetica = function(jsonRequest){	 
			// I-MODIFICACION TDC (SE AGREGA LLAMADO AL SERVIDOR DETARJETAS)			
			var URLtarjetas = false;
			if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto) && $rootScope.consultaFuncionalidad.banderaBloqueadosTDCReactivacion)
				URLtarjetas = true;
			var url = endPointConfigService.obtenerRutaEndPoint("getHomonimosBsqFonetica");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json', TIME_OUT_180SEG, URLtarjetas);	                              
		};
		
		
		
		/** Servicio para consulta de clientye unico
		 *  bsqCUJson: {
							solicitudJson: cadena con el json de la solicitud,
							opcion: 3
						  } 
		 * */
		service.getCU = function(bsqCUJson){	            
			var url = endPointConfigService.obtenerRutaEndPoint("getCU");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(bsqCUJson)), 'POST','application/json','application/json');	                              
		};
		
		
		
		/** Servicio para consulta de la foto del cliente
		 *  Se puede buscar por ruta o idSolicitud
		 *  biometricoJson: {
							ruta: cadena con la ruta de la foto,  "/1/53/172/29195.b64",
							idSolicitud: cadena con el # de solicitud,							
							cadena: null,
							tipoCadena: null
						  } 
		 * */
		service.getFoto = function(biometricoJson){	            
			var url = endPointConfigService.obtenerRutaEndPoint("getFoto");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(biometricoJson)), 'POST','application/json','application/json');	                              
		};
		
			
		/** Servicio para consulta guardar biometrico
		 *  biometricoJson: {
							ruta: null,
							idSolicitud: cadena con el # de solicitud,							
							cadena: "mano-dedo-cadenaHuellaUno,mano-dedo-cadenaHuellaDos,  
							tipoCadena: huella/foto,
							porcentaje: numero de procentaje
						  } 
			tipoCadena: Contiene la descripción de la cadena que se va a guardar (foto/huella)
		 *  cadena: Contiene la cadena en base 64 de la imagen o huella capturada. 
		            Para el caso de captura de huella, deberá estar separada por comas y concatenado al principio de la cadena el identificador de la mano y dedo, separados por guiones.
		            mano: 1 derecha, 2 izquierda.
		            dedo: 1 pulgar, 2 indice, 3 medio, 4 anular, 5 meñique
		 * */
		service.setBiometrico = function(biometricoJson){	            
			var url = endPointConfigService.obtenerRutaEndPoint("setBiometrico");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(biometricoJson)), 'POST','application/json','application/json');	                              
		};
		
		
		
		/** Servicio para consulta de la foto del cliente
		 *  cteunicoJson: {
							pais: numero de pais,
			    			canal: numero de canal,
			    			sucursal: numero de sucursal,
			    			folio: numero de folio
						  } 
		 * */
		service.getFotoCU = function(cteunicoJson){	            
			var url = endPointConfigService.obtenerRutaEndPoint("getFotoCU");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(cteunicoJson) ), 'POST','application/json','application/json');	                              
		};
		
		
		
		service.getHuellasCU = function(cteunicoJson){	            
			var url = endPointConfigService.obtenerRutaEndPoint("getHuellasCU");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(cteunicoJson) ), 'POST','application/json','application/json');	                              
		};
		
		
		
		service.getLCRCU = function(cteunicoJson){	            
			var url = endPointConfigService.obtenerRutaEndPoint("getLCRCU");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(cteunicoJson) ), 'POST','application/json','application/json');	                              
		};
		
		
		service.consultaFolioCU = function(cteunicoJson){	            
			var url = endPointConfigService.obtenerRutaEndPoint("consultaFolioCU");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(cteunicoJson) ), 'POST','application/json','application/json');	                              
		};
		
		
		service.validaHuellaINE = function(cteunicoJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("validaHuellaINE");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(cteunicoJson)), 'POST','application/json','application/json');		
		};	
		
		service.obtenerInformacion = function(cteunicoJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("obtenerInformacion");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(cteunicoJson)), 'POST','application/json','application/json');		
		};
		
		service.getHomonimosCambaceo = function(homonimosJson){	  			
			var url = endPointConfigService.obtenerRutaEndPoint("getHomonimosCambaceo");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosJson)), 'POST','application/json','application/json');	                              
		};
		
		service.altaCUTienda = function(jsonRequest){  
			var url = endPointConfigService.obtenerRutaEndPoint("altaCUTienda");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');                               
		};
		
		service.guardarFirmaUnica = function(jsonRequest){  
			var url = endPointConfigService.obtenerRutaEndPoint("guardarFirmaUnica");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');                               
		};
		
		return service; 
				
	});
	
});