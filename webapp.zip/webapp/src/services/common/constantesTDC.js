'use strict';

define(["app"], function (app) {
	
	app.constant("constantesTDC", {
		
		INICIALIZADORES_TERMOMETRO:{
			montoInicio: 3000,
			saltosSlider: 500
		},
		
		STATUS_TDC:{
			permitir_originar:
				[],
			no_permitir_originar:
				[]
		},
		
		TIPO_CONSULTA:{
			consultarStatusSolicitud: 0,
			consultarStatusSolicitudYLCR: 1
		},
		
		TERMOMETRO_LINEA_CREDITO_TDC:[]
	});
});