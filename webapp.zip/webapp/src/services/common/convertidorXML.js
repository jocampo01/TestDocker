(function() {
	angular
			.module('convertidorXML', [])
			.service(
					'convertidor',
					function() {
						var x2js = new X2JS();
						
						this.convertXml2JSon = function(xml) {
							return JSON.stringify( x2js.xml_str2json(xml) );
						};
						
						
						/* convierte una cadena en formato json a un cadena xml*/
						this.convertJSon2XML = function(jsonString) {
							var xmlOut = x2js.json2xml_str( JSON.parse( jsonString ));
							return replaceCharacter(xmlOut);
						};
						
						/* convierte un objeto json a un cadena xml*/
						this.convertJSonObject2XML = function(jsonObject) {
							var xmlOut = x2js.json2xml_str( jsonObject );	
							return replaceCharacter(xmlOut);
						};
						
																		
						function replaceCharacter(str){
							return str.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#x27;/g, "'").replace(/&#x2F;/g, '\/');
						}
						
					}

			);

})();

