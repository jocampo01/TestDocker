'use strict';

define(["app"], function (app) {
	
	app.factory("endPointConfigService", function(){
		
		//Objeto con la configuracion de direcciones url para los diferentes servicios REST
	        var endPointURLConfig = {   
	        		
		        	//PATHS PUBLICOS
		        	loadConfig:				"XOe8CP/oaPVejR/KXm9kAIUrywYgGK1V+6zFYz9RKNXi0d7qOAcG7lD2t11wOpo5gFA2C+rr1Z4hQB7hBFBzxA==",
		        	login: 					"XOe8CP/oaPVejR/KXm9kALIPmr/JPyGGnSmOlEYLAXM=",		        			        		        		        		        
		        	endSession: 			"XOe8CP/oaPVejR/KXm9kALfNP2gGjkC3nYbfezQUVoI=",	            	            	        		        			            	            	            	            	            	          		            
		            validaSesion:			"XOe8CP/oaPVejR/KXm9kAJM6vyUdeJeQsPa04dopMLQugBjIQWvtsDsR2paUgakj",
		            updateSolicitudes:		"XOe8CP/oaPVejR/KXm9kACtCOr9TifDMUHc1xNUJSv1ATBkCVVVH+c5KQmwqjziP",
//		            loggerFront:			"XOe8CP/oaPVejR/KXm9kANPJw7bwU8bZpgx5Wi8dURmCyi/MJbQtB+dvnrojzn6C",		            
		            
		            	            	            	            	            	           
		            //PRIVADOS
		            guardarEncuestaPreaprobados: "MhbVjbnHQak21sLbXoxnuGBZ75SxBKDKUFjVYxC/decjV2sHopCodzbNaCj84fV3TIVPrDnYze8YTUofa4lY8g==",
		            actualizaProductoRescate: "MhbVjbnHQak21sLbXoxnuErkCVeWMUT44dcA3lGRJrHlPl3MPmhXkSFMhDmoypShgCJ1CzlfruV7UDA+2iptlw==",
		            validateCode:			"MhbVjbnHQak21sLbXoxnuBMwQ6328BO8OSoRNW3iJfIxq5sGpivc9mvnB8uuSRUi",
		            getCode: 				"MhbVjbnHQak21sLbXoxnuBMwQ6328BO8OSoRNW3iJfKK1VIzGQsg2UNxTn9Q0/Fy",
		            consultaBuro:  			"MhbVjbnHQak21sLbXoxnuDbSZoiFga/2apJGdKMRLz3BWQft0WieCdP72u/NN8La",
		            actualizarProductoConsumo:  "MhbVjbnHQak21sLbXoxnuJww1TuxJmanJw6tUDHbEy+mX+m9ABHEKEUQld3jVxLhBVC6hOq48RjrtotNBP26Tw==", 
		            consultaBuroAval:		"MhbVjbnHQak21sLbXoxnuDbSZoiFga/2apJGdKMRLz1J9Ty+mELkshSkRCiHLfgF",
		            consultaBuroInterno:  	"MhbVjbnHQak21sLbXoxnuAdkEeRQxae28DCNDhVNhXe0fHI8jWrddVgm/CcThROd",
		            loadSolicitud:			"MhbVjbnHQak21sLbXoxnuEuLeL+6FR/49CZvKNJ5DILG025aDGhZmwX0dVYRJ9v9",
		            getObjSession: 		    "MhbVjbnHQak21sLbXoxnuIOd5zkVewF2qrRVtogEemI=",
		            consultarMapas: 			"MhbVjbnHQak21sLbXoxnuAvciWDTznpzrxhN786UrnCEwWiJxPu4jfnhknOlg2f1DvS0LPNtDyTRbbWT7HM/0A==",
		            getHomonimos:  			"MhbVjbnHQak21sLbXoxnuAV+d5WHYn6+YELamCj7PUSJvRNve2mHvcz8I+KGtm2M",
		            getHomonimosCambaceo:  	"MhbVjbnHQak21sLbXoxnuM0RfTCTU5kzcY2B7vRhGiS00rnW2H32YtYrLJKEM33i",
		            getHomonimosAval:		"MhbVjbnHQak21sLbXoxnuCa9x4v5Z4tQtMzLFiHIs8S8AwDp7euI43O0Dxvv8Zpy",
		            getHomonimosBsqFonetica:"MhbVjbnHQak21sLbXoxnuC64ZZ13X1M1Y9RW+cYSWIUo5nehsFuYJkGPzhoPcRtatMF0F8ftvmZVax66QOT7Tw==",
		            consultaRenapo:			"MhbVjbnHQak21sLbXoxnuOFL6cl+3xvsnsI1Y1EDjUbuGmmlHS626dvESknsTxBg",
		            userSession: 		    "MhbVjbnHQak21sLbXoxnuC4VCO4l1Cz/WSCgmvnG91froQx8nxunRnZxBF75l11S",
		            getSolicitud:			"MhbVjbnHQak21sLbXoxnuBh/ele1UjTw/3lJsqbYfpFPeXfloU4zAgpFjmqeXYI0",
		            convertirTifToJPG: 		"MhbVjbnHQak21sLbXoxnuJxNIZ0qegJj8ALhKBCDyhN19dCwwWIfozW68Tq/UafDgydf9Ll4sg8VLEZZObdVhEmZzsGhiNjLOxoepkIo2fQ=",
		            saveSolicitud:  		"MhbVjbnHQak21sLbXoxnuHh5TIzs+L4RT/T67aaRUEXvrBwRMjX4HnAZpVkxyjWr",
		            liberarSolicitud:		"MhbVjbnHQak21sLbXoxnuEuLeL+6FR/49CZvKNJ5DIJcdYs/HEkNH1wjn1FJK7yK",	            
		            agendaCita:    			"MhbVjbnHQak21sLbXoxnuGU6hJIU1wC9klFjSCgPcfe0IBKz1/lhvA5ugyZ83L5R",
		            getDatosAsesor:  		"MhbVjbnHQak21sLbXoxnuGU6hJIU1wC9klFjSCgPcfeG/+8VODLYQdrKJbXH8C71",
		            consultaCP:    			"MhbVjbnHQak21sLbXoxnuOhvVQ6Vl8ON0fy4QjPY+XxcQLIxtHm6GBUtfDVGC4u3",
		            digitalizarDocumento:  	"MhbVjbnHQak21sLbXoxnuJxNIZ0qegJj8ALhKBCDyhNTgCvgeqc+K8XwWICLzSAu",
		            getImagesExpediente:  	"MhbVjbnHQak21sLbXoxnuJxNIZ0qegJj8ALhKBCDyhOMhPs3M1c9HJ/Lv3BZ/OVK",
		            getImageBase64:  		"MhbVjbnHQak21sLbXoxnuJxNIZ0qegJj8ALhKBCDyhNLEk0sn3W/H1pwogOId0ldhw0cOqsQQOrsC8pBND5MSw==",
		            getCU:  	   			"MhbVjbnHQak21sLbXoxnuJ4bh1BzITR5wbs4F67PsrWTdg2tf8d5SvwfQElORMkI",
		            setBiometrico: 	   		"MhbVjbnHQak21sLbXoxnuJ4bh1BzITR5wbs4F67PsrU1EBfB0o4SNCWJyvuwlBs6I143Qi6UahKjKoXJUFukLg==",
		            getFolioCallCenter:		"MhbVjbnHQak21sLbXoxnuKbK2sc2WO/wfvQK+EgSUU0EV6gioa0AbsVpGOzWrud2",
		            contratosDigitalizados:	"MhbVjbnHQak21sLbXoxnuJxNIZ0qegJj8ALhKBCDyhN19dCwwWIfozW68Tq/UafD5TAvRuuejladz0KD/lfbqQ==",
		            getFotoCU: 	   			"MhbVjbnHQak21sLbXoxnuJ4bh1BzITR5wbs4F67PsrVWVbaa4xyPRmbElCzX6weq",
		            getFoto:  	   			"MhbVjbnHQak21sLbXoxnuJ4bh1BzITR5wbs4F67PsrXM/mFyPfjT1eHFLihTVr/C",
		            resultadoConsultaBuro:	"MhbVjbnHQak21sLbXoxnuHW4BsyiVw7tdMwIGwUWwCQlTzQ0LTcfPJgqKEesh+HM",
		            getBuzonExp:  	   		"MhbVjbnHQak21sLbXoxnuJxNIZ0qegJj8ALhKBCDyhMzst2UaR9eIxs7z4bhcE2q79qHKNSmnlFXsAfbb3LLkw==",
		            setDiaPago:  	   		"MhbVjbnHQak21sLbXoxnuBtegB5DlUSXQaTHilaYf8hwYDTAUvd/CLBSAoa1jNeX",
		            getStatusLCR:  	   		"MhbVjbnHQak21sLbXoxnuEuLeL+6FR/49CZvKNJ5DILow3N4KMXH9gAZJUTbJgYY",		            
		            validarDocumento:		"MhbVjbnHQak21sLbXoxnuDLpL0CWTH0vpSEnbvlW+ejo80hB2SgCrzwdLlSApdX2",
		            validarDocumentos:		"MhbVjbnHQak21sLbXoxnuJxNIZ0qegJj8ALhKBCDyhMZXqZBbBH117cHKTd8vAmf",		            
		            solicitudesProceso:		"MhbVjbnHQak21sLbXoxnuJnBDcv73Jx72iAXA2spfFkiO2LrbKoj4/Nb81cN+3Hv",
		            getMontosPlazosBuro:	"MhbVjbnHQak21sLbXoxnuP9DTpxNlA0XNFLPbs8atJY/tHI5GBoPzK6qAXxgv2X2",	            
		            firmasContrato:			"MhbVjbnHQak21sLbXoxnuHDV8N+s2ugj95viw5ZLXyEIBnFwjrYh1p1/5RrFT4BE",
		            getHuellasCU:			"MhbVjbnHQak21sLbXoxnuJ4bh1BzITR5wbs4F67PsrUv0z+UhLqDwwsoXVxX78LBdc7MCRKNQfOOMM01Tk+E/A==",
		            dispersion:				"MhbVjbnHQak21sLbXoxnuNA4dQH6BKSCrIB6rvj5RSI=",
		            citasSolicitudes:		"MhbVjbnHQak21sLbXoxnuJnBDcv73Jx72iAXA2spfFlE3SqVS36azL34ASiGbtRX",
		            fotoAsesor:				"MhbVjbnHQak21sLbXoxnuGU6hJIU1wC9klFjSCgPcfe4c5U40RvNDLrwRso3EtOX",
		            solicitudesAsesor:		"MhbVjbnHQak21sLbXoxnuJnBDcv73Jx72iAXA2spfFnkrSVjHSSNlzH8q3Cpv/N9",
		            getLCRCU:				"MhbVjbnHQak21sLbXoxnuJ4bh1BzITR5wbs4F67PsrXC1hu0NA5/shNeEX4B46V3",
		            datosPresupuesto:		"MhbVjbnHQak21sLbXoxnuIfv1RS0jNoEY5ic9o1dg2tLxm7MsO+6UTS6o70Kwma4",
		            consultaFolioCU:		"MhbVjbnHQak21sLbXoxnuJ4bh1BzITR5wbs4F67PsrUPwAAWZp/6HaorYXPSBIZs5e4GJn9R/vWVaFckmPqYCg==",
		            generaSolicRechazada:	"MhbVjbnHQak21sLbXoxnuBh/ele1UjTw/3lJsqbYfpEaytG/i3ISkcIBC07aD7Ju",
		            validaSolicRechazada:	"MhbVjbnHQak21sLbXoxnuCIHs0BZ6CzA1Q6+sa8yWyy931kKSE9wKZsimnGodX8jHwHDOZhf41viCEHOL8EpMg==",
		            seguroVidamax:			"MhbVjbnHQak21sLbXoxnuAnz2MnrU8ZBbA85HFzJud/FAW2hsO7JPR4vJjR/svHL",
		            getDatosLcrAutorizada:	"MhbVjbnHQak21sLbXoxnuOohJq8aSAuHTAvumuU9jIQMWgu0jS0qPKt3rGea4iTK",
					getDatosLcrBloqueada:	"MhbVjbnHQak21sLbXoxnuA1DKdBNzL3yNEtqUSlZyadI2ssLH3Ee0smdrbUjepr/",					
					cancelarSolicitud: 		"MhbVjbnHQak21sLbXoxnuOhvVQ6Vl8ON0fy4QjPY+XwBhfLLATFm4Ky3YmU2HHOu",
					actualizaProducto: 		"MhbVjbnHQak21sLbXoxnuGZjDBSdm1iKDl8PjP1JM8RjNLFfrcSpuvfdSoIdQf1nOf4gDg44VVT4whXTdB1QWw==",
					consultaItalika:		"MhbVjbnHQak21sLbXoxnuFeEhprG29UsnJHsxyuAxJ+W0RzEriWse8j8FGgnOWhi",
					activarTarjetas:		"MhbVjbnHQak21sLbXoxnuEt5vStu8Gt84l12A1J39dp2lU3n7uCcPmhL9g3mC0bBZeSBCfK+jeYkEB9MW/l5+g==",
					sucursalInfo:			"MhbVjbnHQak21sLbXoxnuJ/rYOjJ1Iw44//JuqExH9c=",
					sucursalInfoPorId:		"MhbVjbnHQak21sLbXoxnuNXMffYzGckEamtsiRvj9ZgSeDKmFZbIdiW/zSOnnnB7",
					liberarPorCallCenter:	"MhbVjbnHQak21sLbXoxnuKbK2sc2WO/wfvQK+EgSUU0BLB1FPbiiv0eIQYpgQo18",
					dispersionTarjeta:	    "MhbVjbnHQak21sLbXoxnuDTmVPmNDBJBDObuGQRN89SsYuu6DhZcC2PtWBLrT7zv",
					getSolicitudByCode:		"MhbVjbnHQak21sLbXoxnuOhvVQ6Vl8ON0fy4QjPY+Xz0y8MA5bKubKC15WEu926k",
					guardaTarjeta:			"MhbVjbnHQak21sLbXoxnuHig79M7Uf0IvnOvctLMlKx9GkkdCmGWvL89yb3K0xlz",
					agendarCitaBazDigital:	"MhbVjbnHQak21sLbXoxnuJ2NDHM1Dw95spkIEI7A7TJjgdfDLN+0fFpGKxZWqEqD",
					buscaTarjeta:			"MhbVjbnHQak21sLbXoxnuHig79M7Uf0IvnOvctLMlKy7P4vfQAEBQFIx+uNHTz/K",
					ligaFolioUnico: 		"MhbVjbnHQak21sLbXoxnuECWCqWrkpv2eGuT0Een5MWWgXEQ2VkndAq9q8akpapA",
					guardaLiberacionFolioUnico:	"MhbVjbnHQak21sLbXoxnuECWCqWrkpv2eGuT0Een5MXxL4Y8WEqfuqtDOPHga2l6lbadV0ochF85WQF2MccF8A==",
					consultaProductosItalika: 	"MhbVjbnHQak21sLbXoxnuHPNSrAWLdO8KuqBq/0QwNBmDWVQBrSQ9Dva8uVDOv0e",					
					getTasaItalika: 			 "MhbVjbnHQak21sLbXoxnuIauOWTJXzuHnEpfoW2MdOpOPYv8IxV93Gn2v/0qt45b",
					getProductoPorNombreItalika: "MhbVjbnHQak21sLbXoxnuHPNSrAWLdO8KuqBq/0QwNCdcqoZPIwd/dV5UgfFlqso",					
					getDispersionTarjetasCallCenter: "MhbVjbnHQak21sLbXoxnuKbK2sc2WO/wfvQK+EgSUU1hJsbHQ1KeBkXMdGkxJ2NdFBQ8P446TSOksIlDVRZtog==",
					validaContratosDigitalizados:	 "MhbVjbnHQak21sLbXoxnuJxNIZ0qegJj8ALhKBCDyhN19dCwwWIfozW68Tq/UafDsSe6z0AUVj+ScgIk0RNPJA==",
					actualizaMarca: 		"MhbVjbnHQak21sLbXoxnuGU6hJIU1wC9klFjSCgPcfcnEOoqhjrTOVH3pmo2kOos",
					liberarPedidoSinTAZ:	"MhbVjbnHQak21sLbXoxnuKbK2sc2WO/wfvQK+EgSUU05+gFC2Ql3M6wBZJ9SmVMxJsZAw44Inzcj9YNxAaEW7w==",
					getCampania:            "MhbVjbnHQak21sLbXoxnuIoaP67BGpWbimmfMGfomjo=",
					recuperaFirma:          "MhbVjbnHQak21sLbXoxnuHSvOy5U339ba2YA3U/w/EYc2Hz4FNQ+toJka2tDApwV",
					rechazoSolicitudGerente:	"MhbVjbnHQak21sLbXoxnuBh/ele1UjTw/3lJsqbYfpGCyDKNjlaBBEEYvDk895Gc",
					envioMensaje: 			"MhbVjbnHQak21sLbXoxnuIZ8L7wvmicCcm0CCZEg3rlgboOmS/v9AIeDtWcJXeF8",
					getSucursalBig: 			"MhbVjbnHQak21sLbXoxnuBh/ele1UjTw/3lJsqbYfpHXvx+kPgRrUHSkGfYVVQNa",
					loggerFront:			"MhbVjbnHQak21sLbXoxnuOiLCtoSewhYAo4zG1fZtKdN1YREkpQSQiS+PQf64Plv",
					agendarLlamadaClteVerde:"MhbVjbnHQak21sLbXoxnuJ2NDHM1Dw95spkIEI7A7TIclXtS8vIolSchHUSCXEWt",
					validaHuellaINE: 		"MhbVjbnHQak21sLbXoxnuJ4bh1BzITR5wbs4F67PsrVwxCgp/oswnSlmrxB8qQFbE8NQi5mW3LHeh3EexZNCkg==",
					actualizarSolicitud:	"MhbVjbnHQak21sLbXoxnuGU6hJIU1wC9klFjSCgPcfeBvLObtPhXe3lNGsJtXVZgQ9+ZBelcE5QHlvvkoG3G3A==",
					actualizaComprobante:	"MhbVjbnHQak21sLbXoxnuJxNIZ0qegJj8ALhKBCDyhMPEONLbpT3la7hxVPVCJPAdADpPGG9jWET1HcgXBEHAg==",
					capacidadPago:			"MhbVjbnHQak21sLbXoxnuKmFyyZF4z8V72TbwDe3WFpS/9lZIf5W5vduVhA+/AjoZkIq9sj0WwZLM7souiU3xQ==",
					consultaFuncionalidad: "MhbVjbnHQak21sLbXoxnuNuOPlTgpJQd0FxNfKqJaJJRY7ndRZvw9GamC/3d9Epxt96xzfzC1KhGIrIu63c30A==",
					consultaDomicilio:       "MhbVjbnHQak21sLbXoxnuOhvVQ6Vl8ON0fy4QjPY+XwhYAX5ZocZUf5L7C1dLSWMKStZqzzBwFhBbWPNvMRmWg==",
					generaFolioUnicoCE: "MhbVjbnHQak21sLbXoxnuOCKdGbQDO2yEeXYsEDxfHPbrkK1MTLv63W13jMIpYnc",
					obtenerBateriaPreguntasRespuestas: "MhbVjbnHQak21sLbXoxnuFKrAriwK6k8OJgEca6SYkj27DZ/PvU7NbkdiFhR1vFjUZjGfTXT1QS1LfIQRCNppJZlgup+vA4m5dbsXAJ15oA=",	
					guardarBateriaPreguntas: "MhbVjbnHQak21sLbXoxnuFKrAriwK6k8OJgEca6SYkiKXw9axLtZuNP9qYXxMrWZjJcAvIUgMPI5LatAPzRBVA==",
					generaAPRechazoRENAPO: "MhbVjbnHQak21sLbXoxnuBh/ele1UjTw/3lJsqbYfpEjazyo++e5myKUfdvBLRoChnkRPYEiFZ6MgvVOQxgwwA==",
					liberarLCR: "MhbVjbnHQak21sLbXoxnuEuLeL+6FR/49CZvKNJ5DIIaJ1hRV9wjb1M/0et2A9Jl",
					obtenerSolicitudesPorNombre: "MhbVjbnHQak21sLbXoxnuKmFyyZF4z8V72TbwDe3WFpIe7mEdLSxzpJhz1UqKBIh+BglDhFATyW9r3mvdVrEbg==",
					validaSucursal30km: "MhbVjbnHQak21sLbXoxnuCIHs0BZ6CzA1Q6+sa8yWyx3hQWOnDgQ07hMBZkwWRSNon1GONwL45bt9gZ0fvJIBg==",
					migracionSolicitudNuevaSucursal: "MhbVjbnHQak21sLbXoxnuP7GGFpmZaGT1RNC/u2H52dgxKhqG6icfM0wGr0NglYqJUVrilMzkCeDGwQpE2VFEw==",
					rechazarSolicitud: "MhbVjbnHQak21sLbXoxnuHdBp/GCotQHdiB3yyG6oe6chhw7J3fKBoroiGTd2oCD",
					guardarDatosCambaceo: "MhbVjbnHQak21sLbXoxnuBtegB5DlUSXQaTHilaYf8hBlbEs4Oihs4jy+KHZscutv2NI1Mgkf952YoNXcGsDiw==",
					consultarMarcas: "MhbVjbnHQak21sLbXoxnuP7GGFpmZaGT1RNC/u2H52crGXiRP7/m+23SSusnD1Qc",
					guardarDiaPagoNvoFlujoLiberacion:  "MhbVjbnHQak21sLbXoxnuBtegB5DlUSXQaTHilaYf8hxqhbLz9VQYQc1bM8Eghml",
		            validarNumTel: "MhbVjbnHQak21sLbXoxnuCIHs0BZ6CzA1Q6+sa8yWyxohdK0WA0VnmeBrsSHynaJ",
		            obtenerDatosTicket: "MhbVjbnHQak21sLbXoxnuKmFyyZF4z8V72TbwDe3WFpQTPRZ+SZtdn6x1sOpa/F6FtR9SaNXKIw8Yus3iTPX9Q==",
		            guardarFirmaUnica: "MhbVjbnHQak21sLbXoxnuJ4bh1BzITR5wbs4F67PsrUcIh2s+BziESbJzog6sn8o3mVrIggwu2U7Aip4tl1Npg==",
		            
					//BazDigital
					agendarLlamadaBazDigital: "MhbVjbnHQak21sLbXoxnuJ2NDHM1Dw95spkIEI7A7TL8wDRcX9YsjhvZxvfyhm+hgY2a2IDxfN0UJBv5tAxb8Q==",
					
					//Mesa de Crédito
					enviarRechazoGerenteMCO:	"MhbVjbnHQak21sLbXoxnuP7GGFpmZaGT1RNC/u2H52c3OEkuU9a4rQxAsKzxQDCKFNj/ODZmrEkVc4f+7AMpXQ==",
					enviarIngresosCompMayoresA20k: "MhbVjbnHQak21sLbXoxnuP7GGFpmZaGT1RNC/u2H52eWWHjb6lTLGcw1VwIckpdmbBsTPw81kqFNEWTAOiSwdQ==",
					actualizaStatusTiendaPorCambioCDP: "MhbVjbnHQak21sLbXoxnuGU6hJIU1wC9klFjSCgPcfcIX2+w+D0Mj0vjLCgrPgTdYG2j8CPxwTOEWUD1mbW3aw==",
					rechazoPorCambioCDP: "MhbVjbnHQak21sLbXoxnuP7GGFpmZaGT1RNC/u2H52c3OEkuU9a4rQxAsKzxQDCKl8l9IJtCfeMxRxxGv9arXQ==",					
					
					//SERVICIO PARA CONSULTAR LOS ABONOS
		            consultarAbonos: 		"MhbVjbnHQak21sLbXoxnuATB+uzmlVqR35E5ztpSp56EOBr2gpmYQ0W/upR0k/e6",
					
// I-MODIFICACION TDC								
					consultaCuentasTarjeta:  "MhbVjbnHQak21sLbXoxnuNQIVuLqiWIUVo6Y2ZzP+4hbuCn3tBoxXsk3PEG9buff",
					ligarTarjetaRevolvente:  "MhbVjbnHQak21sLbXoxnuNQIVuLqiWIUVo6Y2ZzP+4gvlBBHTEirxj+dBn3Y+0qX",
					consultaPreaprobadosXCU: "MhbVjbnHQak21sLbXoxnuKYaa3nGfPvceY/0esr/rBFgAXAJwPeWeWDlUDBsBDEGOJ+cSSTMuCAkgNpyKhZOfw==" ,
					evaluacionCita:          "MhbVjbnHQak21sLbXoxnuMHqVnp4j8kiJZg926wmezlNR6aQGgqhMBvUsYux3Urn",
					quemarFolioPreaprobado:  "MhbVjbnHQak21sLbXoxnuN5bVSO/P02yueFx0pHtNRB2CIIfT6H8KvAbKiEqQjpteGtWuWQCIxUa1TN5K2sFCA==" ,
					consultaEmpleado:		 "MhbVjbnHQak21sLbXoxnuGese4EFXYMYM+aPS4YbRSpAqIxF/YUw6rOi1df7CvANxEcNGPir+N10BOUFwU4E6Q==",
			        consultaCat:             "MhbVjbnHQak21sLbXoxnuGese4EFXYMYM+aPS4YbRSoITZi2P0pijXebYM8I72u3",
			        quitarCampana:           "MhbVjbnHQak21sLbXoxnuLwBO/gRpJ8P7sMCUmadGB7W/75aGQ+us9OFoyHG5gfP",
			        actualizarCapacidadPago: "MhbVjbnHQak21sLbXoxnuJWn47k2YQirJj0Z4I9L7dbN8KzOcRywrmJ6VjNnuxbOrRj4Bpq5TFt+65FlMDIgDg==",
			        consultaDatosCaratulaTDC: "MhbVjbnHQak21sLbXoxnuKYaa3nGfPvceY/0esr/rBGx1RIem+97bh9jnZqtzZrJdc5R/eskfTHf1OLIWWo0Kg==",
// F-MODIFICACION TDC					
					//PRUEBA
					cifrarPrueba: 			"service/rest/private/prueba",
					
		            //TARJETAS	            
		            activaTazInstantanea: 	"MhbVjbnHQak21sLbXoxnuAKyj4As6I+63gaz9RyIit/UVArUMYxwxd0972HLNHJDUtqLxptg/i9tgtCyTsxLjg==",	            
		            consultaCteAlnova: 		"MhbVjbnHQak21sLbXoxnuCE0MIuQKZI2f342Aal6z8M0/8gYN9fanOOZ3NeRNxu30rBEA4NT1S1nY+crTE+5EQ==",	            					    
		            cambioNIP: 				"MhbVjbnHQak21sLbXoxnuI7ffB2T1xoKWpCzWg7gMGjFa+Fy5eood4c9DHySG4YV",
		            consultaTaz: 			"MhbVjbnHQak21sLbXoxnuKYaa3nGfPvceY/0esr/rBH0Q8OTYYmznL38qCU6FRLs",
		            consultaInventario:		"MhbVjbnHQak21sLbXoxnuFeLgCumt0R6PI0KzOXgWptneYXjRang4nwztEI7lh8wzzZLmrtfN4OZXz5UfVEPTw==",
		            consultaDispersion:		"MhbVjbnHQak21sLbXoxnuDTmVPmNDBJBDObuGQRN89RtMHV5Xzj/Pox5ir43ssOW",
		            ejecutaDispersion:		"MhbVjbnHQak21sLbXoxnuDTmVPmNDBJBDObuGQRN89SzrBidl4uk9gP6RGdYp8CC",		            	
		            consultasCtasPP:		"MhbVjbnHQak21sLbXoxnuL3XJVuyazdqqKC3jlpE5ufWcIQhyNXQfHyAqSIVRrL8OQQT8GUV6f6jHlRjTQipVQ==",
		            checkInventario:		"MhbVjbnHQak21sLbXoxnuFeLgCumt0R6PI0KzOXgWpu8eQYejsNj4nrOuWTLOGmn",
		            ligarTarjeta:			"MhbVjbnHQak21sLbXoxnuNQIVuLqiWIUVo6Y2ZzP+4il2FVw5v5M8kr3tOY/CChR",
		            getDatosAsesorDisp:     "MhbVjbnHQak21sLbXoxnuJMVjYu81THPf09o1BAdiRGjr/q7A8PV9KBTkTo6DLNB",
		            getDatosAsesorDispAgendarCita:     "MhbVjbnHQak21sLbXoxnuK7txECYm2n6FRBSlrlUgBTSe8FK+miXTg8KvOP84crZ",
		            obtenerFotoJV:          "MhbVjbnHQak21sLbXoxnuNOJBEhmx//O3znDUxNRG/M=",
		            consultarIne: "MhbVjbnHQak21sLbXoxnuOhvVQ6Vl8ON0fy4QjPY+XysECyK2HatNr0ocGXc3laC",
		            promoCreditoRegistrar: "MhbVjbnHQak21sLbXoxnuGZjDBSdm1iKDl8PjP1JM8T4mo05RIrCardc1SaTmiZBxYqn5UKupGKqcJ2DXjwpBg==",
		            guardarPresupuesto: "MhbVjbnHQak21sLbXoxnuBh/ele1UjTw/3lJsqbYfpHyThZA7Pv3F2KhdUA8U0O6kQyIqi2dbJ5w4/x89MdPGA==",
		            
		            busquedaRecompra: 	"MhbVjbnHQak21sLbXoxnuLWQ2Ye1VG78ADTb6sC8U6kyRYYFiXb1rMHmfbfAnxPU",
		            clienteRecompra: 	"MhbVjbnHQak21sLbXoxnuGgd6wfeXGEpS96gwAELfulIgwRM7FFqgjv5fZ0sqgY9",
		            
		            consultaInventarioTAZ: "MhbVjbnHQak21sLbXoxnuLBRBGXt+aYb+x+uAPOXjZvbn5mA6Au2ukXRg3ucRaAT",
		            consultarCancelarTAZ: "MhbVjbnHQak21sLbXoxnuJTGSEJjzVOyIhcXQJ1iksKddXsmibDxKg7TjCuvUI5nPPwgWjIZa75E+7V0YamtoA==",
		            
// I-MODIFICACION REACTIVADO 
		            consultaReactivado :		"MhbVjbnHQak21sLbXoxnuIahQWdxXx0TOau5kja/4WJjd9A53czsvWj6fFe0a3MzFBc7Vm/dYErRg1Px2WrjGA==",
		            actualizaReactivado:		"MhbVjbnHQak21sLbXoxnuIahQWdxXx0TOau5kja/4WKi4KjHI8Gb2gHw9n5yUDNK",
		            consultaPreaprobadosXNombre:"MhbVjbnHQak21sLbXoxnuKYaa3nGfPvceY/0esr/rBFgAXAJwPeWeWDlUDBsBDEGzdIYuQa3NIT+3jlOaWJxdQ==",
// F-MODIFICACION REACTIVADO
// I-MODIFICACION recomienda y gana
		            recomiendaGana: "MhbVjbnHQak21sLbXoxnuDIerLLAXcC44gIBUbT/CbN1pwX2YVr3T9uxze3UCv1k6peUJPkGoR0h0XKSt6MSfQ==",
		            cuentasRecomienda: "MhbVjbnHQak21sLbXoxnuDIerLLAXcC44gIBUbT/CbPB6fc03JdNbBIhv659I+pf3vC5wbMnW3xQmxknsCj3Lg==",
		            informeRecomendado: "MhbVjbnHQak21sLbXoxnuDIerLLAXcC44gIBUbT/CbPASOgwd9PVBsS9XyC3jvYiebns/4Ty6RStKb6Y0p62ig==",
		            guardarFolioRecomendador: "MhbVjbnHQak21sLbXoxnuDIerLLAXcC44gIBUbT/CbPr9uPiSdBFU9wR5CTTfnbsV/qPJDmsUQlmTN9P0INvJ1sFbFxkKkzpZasOUJ2xSS4=",
		            validarFolio: "MhbVjbnHQak21sLbXoxnuDIerLLAXcC44gIBUbT/CbO9Uzh2SndARfALMLZI1UfWbMfY4bo085+h8AMEaczDwQ==",
		            enviarFolioCelular: "MhbVjbnHQak21sLbXoxnuDIerLLAXcC44gIBUbT/CbNGN862J35J6VyubczYuYRW6NyVORny++O4cfE0tREKqQ==",
		            busquedaRecomienda:  "MhbVjbnHQak21sLbXoxnuLWQ2Ye1VG78ADTb6sC8U6kyRYYFiXb1rMHmfbfAnxPU",
		            clienteRecomienda:  "MhbVjbnHQak21sLbXoxnuGgd6wfeXGEpS96gwAELfulIgwRM7FFqgjv5fZ0sqgY9",
		            obtenerInformacion:  "MhbVjbnHQak21sLbXoxnuJ4bh1BzITR5wbs4F67PsrXyp84pTmMB00hnJrigueVydGoC80YZJQnlNGMY+btnjQ==",
		            /** REQ 85337 Servicios de Reactivados*/
		            getSolicitudBazDig:	"MhbVjbnHQak21sLbXoxnuBh/ele1UjTw/3lJsqbYfpFFJwprlvVj9KJpmerV7c1W",
		            saveSolicitudReact: "MhbVjbnHQak21sLbXoxnuHh5TIzs+L4RT/T67aaRUEWDujwMOQnOgwFC1Ruqc318",
		            obtenerDiaDePago: "MhbVjbnHQak21sLbXoxnuKmFyyZF4z8V72TbwDe3WFr8mmS0E5F7RMTkV9tBk95SrlAl9hrct5lXA4dJm4cnVQ==",
// F-MODIFICACION recomienda y gana 
		            	resultadoConsultaProductos: "MhbVjbnHQak21sLbXoxnuBWqV/ejv3dx/mQM8nfeNauVTtHT9zOHR867U+DhcKJa",
		            	solicitarVisitaAsesor: "MhbVjbnHQak21sLbXoxnuHh5TIzs+L4RT/T67aaRUEX8ppbxGOsWdeIIBCqEHAiP",
// I. INCIDENCIAS
		            altaDinamicaIncidencias:"MhbVjbnHQak21sLbXoxnuGXQmsjOcq+F1WNNLB+efAZDtbuEZoIFMOPTU/eZaaV1",
		            ObtenerUltimoDetalleGuardadoSimplificado : "MhbVjbnHQak21sLbXoxnuGXQmsjOcq+F1WNNLB+efAbwwwdA+EJVP3DAhmFSCVahXF6o5o0Xno4oPr1VmR+36QfQV6b7MTe8YNu02nckRgc=",
		            mtdActValSol : "MhbVjbnHQak21sLbXoxnuGXQmsjOcq+F1WNNLB+efAb/rhOkjrMswb2fP4J+WP/d",
		            analizarSolicitudTienda : "MhbVjbnHQak21sLbXoxnuGXQmsjOcq+F1WNNLB+efAYpiJPt09/GT4jkFyguhNesHxH3I+vPDbuWfUswY+u1Zg==",
		            generarContratos : "MhbVjbnHQak21sLbXoxnuGXQmsjOcq+F1WNNLB+efAYye5nsmY2MDw/em0W16jgc7Mx9so5f9sZPHvKEWHDkNw==",
		            consultaServicioTienda : "MhbVjbnHQak21sLbXoxnuGXQmsjOcq+F1WNNLB+efAYZJqlrmuPV6FhQ8BoG0HRC3UoF1TNtPwpi0w1iuEQYaQ==",
		            generaFolioMCO : "MhbVjbnHQak21sLbXoxnuGXQmsjOcq+F1WNNLB+efAbVJsm4BjGYL36tWeeJhMOqujpw53ECFnUI2Qpptq8RwA==",
// F. INCIDENCIAS

//INICIA_OS-
		            	consultaFolioCUOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLrfjuZuRyoCJ5VWBfIGa0/L5MaCSfG1AyQMgHt5NmUwfJQ==",
		            	obtenerFolioCallCenterOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLreFFa0kFcrn+feHOaYYwOgoDtauCoCVl2HzIeGhoizcsA==",
		            	busquedaHomonimosOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLrd0mieGJKgAYI1f09N9CrGPtsYbVHnDpl7b10kPPajcNg==",
		            	buscarCUOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLrdI9ob5S0f5Y462lRWKT0p9Yo2du8cT1O6fhPs4h2uoGw==",
		            	guardaSeccionOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLrdCAzQEQO2oL5/6jtY/hi3RrBAiPaNihZm32WjuZj080w==",
		            	guardaFirmasBiometricosOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLrcedqZhmiVIEPkRVfp+Khra3sbhqngFtgfnbvkdxDyDkQ36hw60Qix5JZca9lYDpS8=",
		            	buscarSolicitudOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLrcv137iQW3Catt7ai7HO6tunXXzGpCBkifLyzQzuORF0Q==",
		            	agendarCitaOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLrdlWja39mfn4/a1VA8Z4MOBBfAzVeBFhPrs8kriP7rYag==",
		            	digitalizarImagenOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLrdOYtbftO/BRioTqa9+RM2tRmM5nOQgoJoKhu1bdksL+Q==",
		            	hacerConsultaOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLrcE/Em+6qKPG2n+d17Io3lb5WcczJ/PvSStCZiRrDw0gw==",
		            	actualizarStatusOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLrdnACDk45UlbY1EeCVEqJS0Q4EcCGPkSQZMbqcCZpYBCZB7xk5zgQSZZmWcUFsQHZ4=",
		            	validarStatusLcrOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLrdYBL/xbyR8IIHNM8DslpxAxV7SsdY+77WXjw+k7euCfn40Jv47eNFQCkuNj6Y4Q9Q=",
		            	obtenerDatosOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLrd6/dWZvIPJaJMFtvrpLFhUPUqIzaFNDSw/srmHf7DJaWu1pKHuL+TMB2fwH7Hc12Q=",
		            	fotoAsesorOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLrdAxPfXF1RCbA2HjXp/n776UpwVwGeIL7QI9+IvBSVzX126nbQceN/fm3MxKPkzhko=",
		            	recuperaFirmasOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLrc/2YXewzII9lIPUNbLa4qBs4loHrR0+hvrMNkEO79DUw==",
		            	validarContratosDigitalizadosOS: "MhbVjbnHQak21sLbXoxnuCJNbXUJpCVAZOhjJbfwLreun+srQmTCJFZRMP3t4xW+rTh85DlIqeIzZix9Uq+9zFmfFt5KStvCsfY2vBds9bw=",
//TERMINA_OS-
		            	obtenerLimitesDeCredito : "MhbVjbnHQak21sLbXoxnuKmFyyZF4z8V72TbwDe3WFqSZDM6NHe23nRvNWE/Lk6NB1i4XW0eO3rqGUWCNigaYw==",
		            	enviaEventosDeBitacoraABD 	: "MhbVjbnHQak21sLbXoxnuIZ8L7wvmicCcm0CCZEg3rm9rZqG9PYtwheq7CK+F8IZ/WqZcNKy7GzffQZscw8Dnw==",
		            	consultarStatusLCR:		"MhbVjbnHQak21sLbXoxnuKYaa3nGfPvceY/0esr/rBECBjPVoalpWuYE6aVM4Hqo1SZNROWJ+wm2h+rQ8Abnhg==",
				        bajarTienda: "MhbVjbnHQak21sLbXoxnuDUgwleA4Yn+IOlXhswvjZ83kMhJMGqJJQzO7TVU1+LfASLzjBOi9tN/zjglXHkkMg==",
				        altaCUTienda: "MhbVjbnHQak21sLbXoxnuJ4bh1BzITR5wbs4F67PsrX9MhliUet03H1ij4wehhpm",
				        clonarArchivoTest: "MhbVjbnHQak21sLbXoxnuP+ELUg4v6hyjOOc4FrrepP63kLdHGzQE807fVIjw6Of",
				        consultaLineaProducto: "MhbVjbnHQak21sLbXoxnuEuLeL+6FR/49CZvKNJ5DIKIVjdMLwUBut+C6c1NRjeVdED6uO4RSq/pBB+ldX1Ygg==",
				        //Web Services MAPS
					    consultaIdCartografia: "MhbVjbnHQak21sLbXoxnuOhvVQ6Vl8ON0fy4QjPY+Xyp0hDh5uQQYrnO2Tq0TJ7Hh8MFs/NOK4pnY2WrBD6qtg==",
					    //Cambio para CDT
					    obtenerDepartamentos : "MhbVjbnHQak21sLbXoxnuHyDuFC5pO1GW/HWTgHGmC2pXWoC9UCEj63DGnAeM4enjed0emF60MK7VBPMtQ1hcg==",
					    obtenerProductosPorDepartamento : "MhbVjbnHQak21sLbXoxnuHyDuFC5pO1GW/HWTgHGmC3id0kECb/ukHeKFR6j2dVateMhL5KC4Ujk2ewU9R4HV9FEkTTI4UOYnvxFpHIOKt0=",
					    guardarDetalleCotizacion: "MhbVjbnHQak21sLbXoxnuBh/ele1UjTw/3lJsqbYfpGOpqcJ/BoFMKNhhlGDrQGfEg3Mz27W0fciXgKoDkHm8A==",
					    //Web Service Consulta disponibilidad JP
					    consultaDisponibilidadJP: "MhbVjbnHQak21sLbXoxnuOhvVQ6Vl8ON0fy4QjPY+Xzg4vIaDvE9AvoGJ6rwPomiwgwlcUsBWS5e7B5zMh7qvQ==",
					    consultaEsquemaCitas: "MhbVjbnHQak21sLbXoxnuOhvVQ6Vl8ON0fy4QjPY+XzEAPDh73CuG9n8K3jIz/FgJb93H+KjnLHtEf767J1+7g==",
					    obtenerDatosEmpleadoAsesor : "MhbVjbnHQak21sLbXoxnuPMClz9BuJBDqNvWaLMg8K0C0NmhZvDcMCnxYBX1n9x6zNeOXmGV1gFDdJOojc+W5A==",
			            obtenerDatosVisita : "MhbVjbnHQak21sLbXoxnuNCUliK+F0KoJgrmIKLKGMU127iTi6Dk9//AuL43iX3nUTGwh4IaJi854XR4YvkIkA==",
			            validarLimiteEscClientes: "MhbVjbnHQak21sLbXoxnuCIHs0BZ6CzA1Q6+sa8yWyxrtmm3JTREqhhkU1bnfaeJRP+5B5I84PDCv5QPQVj6ng==",
			            consultaCuentasCliente: "MhbVjbnHQak21sLbXoxnuJTGSEJjzVOyIhcXQJ1iksLopDLZF65v21Z2OaPriGl5H+aXn0GnFm5Xs4Ox5vug8w==",
					    guardarSeccionGuardadito: "MhbVjbnHQak21sLbXoxnuHTXCblkEgtjGAURBIQYq9xxIz7S+KaPl1dETvHOLAmu",
					    consultaPromocion: "MhbVjbnHQak21sLbXoxnuEJonk9X+KFq8iktwhyloDsQ8EHKKmLXy12ZXQ+lBqoYoZqUFxmQp4CZQTq4Hqar0A==",
					    obtenerTipoVerificacion: "MhbVjbnHQak21sLbXoxnuCIHs0BZ6CzA1Q6+sa8yWyzMWz4xVu0Va5csTxrz9Xi//AgvUT06OZ7lBlIYOyLgYA==",
   					    seguroVidaMaxUnificado  : "MhbVjbnHQak21sLbXoxnuHh5TIzs+L4RT/T67aaRUEU4H7CroxSSeVa80CMkg9Yy1nCEPy/1RKMDosNKccaLPA==",
					    quemarFolioPreaprobado: "MhbVjbnHQak21sLbXoxnuCXH+Oo1F2W8/NXDLx4MOO3eMC0C9LGmSM0HxoszdoNGF0kd7t8vMVnG+zMU/Sf9gQ==",
					    renapoFirst: "MhbVjbnHQak21sLbXoxnuHdBp/GCotQHdiB3yyG6oe61/7JTKbm9lhQZACp8Y1sViXroznuqjS7HWgaTRqFUoA==",
					    consulta_CURP_RENAPO: "MhbVjbnHQak21sLbXoxnuKio86/zFzznYgNCa0o3FjNHmeYEefUoTO4FOoQDemsmAdrFd75lhddmlZEZb0s9Tg==",
					    busquedaGPS: "MhbVjbnHQak21sLbXoxnuOQogoDiuQPkeRWEgG7whq0DO970q/1hywWScumXwtyzHs3SVRRUqeidBCbYOzrD5g=="

		            	
	        }, rutaEndPoint = {};
	 
	        /**
	        * Metodo mediante el cual se obtiene la url del endpoint especificado
	        * @param recurso el nombre del recurso del servicio REST
	        * return la url del endpoint para hacer la operacion correspondiente
	        **/
	        rutaEndPoint.obtenerRutaEndPoint = function(recurso) {
	            return endPointURLConfig[recurso];
	        };
	        
	        return rutaEndPoint;
	});
	
});