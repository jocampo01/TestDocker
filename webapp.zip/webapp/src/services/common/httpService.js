(function() {
	angular.module('httpService', []).service(
					'REST',
					function($rootScope, $http, $q, securityService, generalService, modalService,  endPointConfigService) {
						
						/*url cifrada*/
						this.callHttp = function(URL, parametros, _method, headerContentType, headerAcept, _timeout, tarjetas, proceso) {
							var deferred = $q.defer();
							var promise = deferred.promise;
							var startTime = new Date().getTime();																																				
							 
							$http({
								method : _method,
								url : generalService.buildUrlTicket(URL,true, tarjetas),
								dataType : 'json',
								isArray: true,
								timeout: TIME_OUT_210SEG,
								data : parametros,
								headers : {
									'Content-Type' : headerContentType + '; charset=UTF-8',
									'Accept' : headerAcept,
									'KEY': securityService.getKey(),
									'INITIAL_VECTOR': securityService.getIV(),
									'proceso': proceso?proceso:"SCF"
									
								}
							}).then(function(response) {
								
								if( generalService.isDefined(response.data.codigo) ){
									deferred.resolve(response);
									
								}else{
									if(response.data.indexOf('../j_spring_security_check') > 0  ){
										modalService.alertModal("Fin de sesión", ["La sesión ha expirado, por favor ingresa nuevamente a la Nueva Originación Centralizada"],"Aceptar","bgrojo","rojo")
													.closePromise.then(															
															function(exito){
																callLogin();				
															},function(error){
																callLogin();														
															}
														);
										
										deferred.reject(response.data);
									}else
										deferred.resolve(response);
								}
									
																																																												
							}).catch(function(response) {
																																					
								var respTime = new Date().getTime() - startTime;																
								
								if(respTime >= response.config.timeout)
									response.config.timeout = HTTPCODE_TIMEOUT;		
								
								validateError(response.data, response.status, response.headers, response.config);
																								
								deferred.reject(response.data);
								
							});													

							return promise;
						};
						
						
						
						/*url cifrada
						 * NO VALIDA ERROR */
						this.noCallHTTP = function(URL, parametros, _method, headerContentType, headerAcept, _timeout, ciphURL, proceso) {
							var deferred = $q.defer();
							var promise = deferred.promise;																																											
							ciphURL = (ciphURL===undefined || ciphURL===null)?true:ciphURL;
							promise = $http({
								method : _method,
								url : generalService.buildUrlTicket(URL,ciphURL),
								dataType : 'json',
								isArray: true,
								timeout: TIME_OUT_210SEG,
								data : parametros,
								headers : {
									'Content-Type' : headerContentType + '; charset=UTF-8',
									'Accept' : headerAcept,
									'KEY': securityService.getKey(),
									'INITIAL_VECTOR': securityService.getIV(),
									'proceso' : proceso ? proceso : "SCF"
									
								}
							}).success(function(data, status, headers, config) {								
								deferred.resolve(data);
								
							}).error(function(data, status, headers, config) {												
								deferred.reject(data);
								
							});

							return promise;
						};
						
						function ejecutaLog(jsonReq){
								promise = $http({
									method : 'POST',
									url : generalService.buildUrlTicket(endPointConfigService.obtenerRutaEndPoint("loggerFront"),true),
									dataType : 'json',
									isArray: true,
									timeout:30000,
									data : securityService.encryptAES_value(JSON.stringify(jsonReq)),
									headers : {
										'Content-Type' : 'application/json'+ '; charset=UTF-8',
										'Accept' : 'application/json',
										'KEY': securityService.getKey(),
										'INITIAL_VECTOR': securityService.getIV()
										
									}
								}).success(function(data, status, headers, config) {								
									console.log(data);
								}).error(function(data, status, headers, config) {
									console.log(data);
								});
								
						};
						
						
						/*url texto plano
						  NO VALIDA ERROR */
						this._noCallHttp = function(URL, parametros, _method, headerContentType, headerAcept, _timeout) {
							var deferred = $q.defer();
							var promise = deferred.promise;																			
							
							promise = $http({
								method : _method,
								url : generalService.buildUrlTicket(URL,false),
								dataType : 'json',
								isArray: true,
								timeout: TIME_OUT_210SEG,
								data : parametros,
								headers : {
									'Content-Type' : headerContentType + '; charset=UTF-8',
									'Accept' : headerAcept,
									'KEY': securityService.getKey(),
									'INITIAL_VECTOR': securityService.getIV()
									
								}
							}).success(function(data, status, headers, config) {								
								deferred.resolve(data);
								
							}).error(function(data, status, headers, config) {																															
								deferred.reject(data);
								
							});

							return promise;
						};
						
						/*url texto plano*/
						this._callHttp = function(URL, parametros, _method, headerContentType, headerAcept, _timeout) {
							var deferred = $q.defer();
							var promise = deferred.promise;
							var startTime = new Date().getTime();															
							
							promise = $http({
								method : _method,
								url : generalService.buildUrlTicket(URL,false),
								dataType : 'json',
								isArray: true,
								timeout: TIME_OUT_210SEG,
								data : parametros,
								headers : {
									'Content-Type' : headerContentType + '; charset=UTF-8',
									'Accept' : headerAcept,
									'KEY': securityService.getKey(),
									'INITIAL_VECTOR': securityService.getIV()
									
								}
							}).success(function(data, status, headers, config) {								
								deferred.resolve(data);
								
							}).error(function(data, status, headers, config) {
								console.log("data "+data);																							
								var respTime = new Date().getTime() - startTime;																
								
								if(respTime >= config.timeout)
									config.timeout = HTTPCODE_TIMEOUT;
								
								validateError(data, status, headers, config);
																								
								deferred.reject(data);
								
							});

							return promise;
						};
						
						
						function validateError(data, status, headers, config){														
						
							validateSession().then(
									function(session){ 																									
										if(status != undefined ){
											
											if( status == 0   && config.timeout == HTTPCODE_TIMEOUT)
							                	modalService.alertModal(ERROR_TIME_OUT.titulo, [ERROR_TIME_OUT.texto],"Aceptar","bgrojo","rojo");
																																																			
											else
												modalService.alertModal("Validación de Sesión "+status, [ERROR_SERVICE],"Aceptar","bgrojo","rojo");
											
										}else						
											modalService.alertModal("Validación de Sesión Error", [data.message],"Aceptar","bgrojo","rojo"); 
										
										
									},function(nosession){
										console.log("validateSession = NO SESION");
				                		localStorage.removeItem('paths');
				                					                		
				                		console.log("generalService.getFlagLogin() "+generalService.getFlagLogin());
				                		
										modalService.alertModal("Fin de sesión", ["La sesión ha expirado, por favor ingresa nuevamente a la Nueva Originación Centralizada"],"Aceptar","bgrojo","rojo")
													.closePromise.then(															
															function(exito){
																callLogin();				
															},function(error){
																callLogin();														
															}
														);
										
				                		
									}
							);
																														
						};
						
						
//						function validateError(data, status, headers, config){
//							if(status != undefined ){
//								
//								if( status == 0  ){
//									if(config.timeout == HTTPCODE_TIMEOUT)
//				                		modalService.alertModal(ERROR_TIME_OUT.titulo, [ERROR_TIME_OUT.texto],"Aceptar","bgrojo","rojo");
//									else										
//										modalService.alertModal("Error "+status, [ ERROR_SERVICE ],"Aceptar","bgrojo","rojo");																																					
//									
//								}else
//									modalService.alertModal("Status Error "+status, [ERROR_SERVICE],"Aceptar","bgrojo","rojo");
//								
//							}else						
//								modalService.alertModal("Error en el servidor", [data.message],"Aceptar","bgrojo","rojo"); 
//						
//						};
						
						var validaYakanaSession=function(headers){
							if(!$rootScope.userSession)
								return false;
							if(headers.hasOwnProperty("content-type"))
								if(headers["content-type"].indexOf("text/html")!=-1)
									return false;
							return true;
						}
						
						var callLogin=function(){
                			if( !generalService.getFlagLogin() ){
                				
                				generalService.setFlagLogin(true);
                				
                				if( configuracion.so.windows ){                					
                					generalService.buildSolicitudJson($rootScope, null );
                					generalService.cleanRootScope($rootScope);
                					$rootScope.inSession = false;
        							$rootScope.userSession = null;  
        	                		$rootScope.sucursalSession = null;
        	                		$rootScope.solicitudesProceso=null;
                					$rootScope.executeAction("moduloTracker", "respuestaLogout", {nombre: "logout"});
                					
                				}else if( configuracion.so.ios )                					
		                			$rootScope.executeAction( "moduloTracker", "loginIpadResponse", {nombre:"login"} );
                				
                				else                  					
		                			modalService.loginModal();
                				
                			}
						};
						
						function validateSession(){
							var deferred = $q.defer();
							var promise = deferred.promise;
																					
							var URL = endPointConfigService.obtenerRutaEndPoint("validaSesion");
							$http({
								method : "POST",
								url : generalService.buildUrlTicket(URL,true),
								dataType : 'json',
								isArray: true,
								timeout: TIME_OUT_5SEG,
								data : {
										empleado: $rootScope.userSession.noEmpleado, sucursal: $rootScope.sucursalSession.idSucursal,
										ticket: generalService.getArrayValue('ticket'), esTienda: configuracion.origen.tienda
									   },
								headers : {
									'Content-Type' : 'application/json; charset=UTF-8',
									'Accept' : 'application/json'												
								}
							}).success(function(data, status, headers, config) {								
								if(data.codigo == RESPONSE_CODIGO_EXITO){
			                		console.log("validateSession = EN SESION");
			                		
			                		$rootScope.inSession = true;
//			                		$rootScope.userSession = data.respuesta;  			                		
			                		deferred.resolve(true);
			                		
			                	}else{
			                		deferred.reject(false);
			                			                				                			                						                						                					                	
			                	}	  
								
							}).error(function(data, status, headers, config) {								
								deferred.resolve(true);
								
							});
							
							return promise;
						};
						
																		
						
					}
																				

			);
					

})();