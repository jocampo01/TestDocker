'use strict';

define(["app"], function (app) {

	app.factory("modalService", function(ngDialog, generalService){
		
		var service = {};
		
		service.messageModal = function(lista, fontSize, seccion, parametroDialogoModel){	 																							
			
			var data = generalService.textosModal(null, lista, null, null, null, null, null, seccion, parametroDialogoModel)
			data.fontSize = fontSize;
			
			return  ngDialog.open({ 
									template: 'src/viewsControllers/modal/messageModal.html',
									controller: 'messageModalController',
									data: data																											
				   				});			
		};
		
		
		service.avisosWin = function(){	              
			return  ngDialog.openConfirm({ 
									template: 	"src/viewsControllers/avisos/avisosWindowsView.html",	
									controller: 'avisosWindowsController',
									className: 'ngDialog-theme-default visorPdf',
																											
				   	});
			
			
		};
		
/** INICIA_OS-FLUJO COACREDITADO **/
		service.avisosWinOS = function(){	              
			return  ngDialog.openConfirm({ 
									template: 	"src/viewsControllers/obligadoSolidario/avisosOS/avisosWindowsOSView.html",	
									controller: 'avisosWindowsOSController',
									className: 'ngDialog-theme-default visorPdf',																					
				   	});
		};
/** TERMINA_OS-FLUJO COACREDITADO **/
		
		service.firmas = function(titulo){
			var data = {titulo: titulo}
			return  ngDialog.openConfirm({ 
									template: 	"src/viewsControllers/modal/firmaModal.html",	
									controller: 'firmaModalController',
									className: 'ngDialog-theme-default visorFirmas',
									data: data	
																											
				   	});
			
			
		};

		service.alertModal = function(titulo, lista, nombreBoton, cssTitulo, cssBoton, seccion, parametroDialogoModel,spiner){	 																							
				
				return  ngDialog.open({ 
										template: 'src/viewsControllers/modal/alertModal.html',	
										data: generalService.textosModal(titulo, lista, nombreBoton, null, cssTitulo, cssBoton, null, seccion, parametroDialogoModel),
										className: 'ngDialog-theme-default centerDialog ' + spiner,
					   	});			
		};
		
		service.alertModalVersion = function(titulo, _lista, nombreBoton, cssTitulo, cssBoton, cssLi, seccion, parametroDialogoModel){
			
			var _data = generalService.textosModal(titulo, _lista, nombreBoton, null, cssTitulo, cssBoton, null, seccion, parametroDialogoModel);
			_data.estiloLi =	cssLi==null?   "azulLi": cssLi;
			
			return  ngDialog.open({ 
									template: 'src/viewsControllers/modal/alertModalVersion.html',	
									data: _data																																				
				   	});			
		};
		
		
		service.avisoProductos = function(titulo, lista, nombreBoton, cssTitulo, cssBoton, seccion, parametroDialogoModel,folioPrestaPrenda,productos){	 																							
			
			return  ngDialog.open({ 
									template: 'src/viewsControllers/modal/avisoProductos.html',	
									data: generalService.textosModal(titulo, lista, nombreBoton, null, cssTitulo, cssBoton, null, seccion, parametroDialogoModel,folioPrestaPrenda,productos)																												
				   	});			
		};
		
		service.alerListtModal = function(titulo, _lista, nombreBoton, cssTitulo, cssBoton, cssLi, seccion, parametroDialogoModel){
			
			var _data = generalService.textosModal(titulo, _lista, nombreBoton, null, cssTitulo, cssBoton, null, seccion, parametroDialogoModel);
			_data.estiloLi =	cssLi==null?   "azulLi": cssLi;
			
			return  ngDialog.open({ 
									template: 'src/viewsControllers/modal/alertListModal.html',	
									data: _data																																				
				   	});			
		};
		
		
		service.confirmModal = function(titulo, lista, nombreCancelarBoton, nombreConfirmBoton, cssTitulo, cssBotonCancelar, cssBotonConfirm, seccion, parametroDialogoModel){	              
			return  ngDialog.openConfirm({ 
						template: 'src/viewsControllers/modal/confirmModal.html',	
						data: generalService.textosModal(titulo, lista, nombreConfirmBoton, nombreCancelarBoton, cssTitulo, cssBotonConfirm, cssBotonCancelar, seccion, parametroDialogoModel)										
																												
			   	});			
		};
		
		service.aperturaGuardadito = function(nombreCancelarBoton, nombreConfirmBoton, cssTitulo, cssBotonCancelar, cssBotonConfirm, seccion, parametroDialogoModel){	              
			return  ngDialog.openConfirm({ 
						template: 'src/viewsControllers/modal/aperturaGuardaditoModal.html',	
						data: generalService.textosModal(null, null, nombreConfirmBoton, nombreCancelarBoton, cssTitulo, cssBotonConfirm, cssBotonCancelar, seccion, parametroDialogoModel)										
																												
			   	});			
		};
		
		service.avisosModal = function(titulo, lista, nombreCancelarBoton, nombreConfirmBoton, cssTitulo, cssBotonCancelar, cssBotonConfirm , creditoInmediato, contratos, 
                acpetados, firma, txtModalContratos, doFunction, seccion, parametroDialogoModel ){

			var _data = generalService.textosModal(titulo, lista, nombreConfirmBoton, nombreCancelarBoton, cssTitulo, cssBotonConfirm, cssBotonCancelar, seccion, parametroDialogoModel)
			_data.credInmd = creditoInmediato==null?true:creditoInmediato;
			_data.esContratos = contratos==null?false:contratos;
			_data.aceptados =  (acpetados>=0)?true:false;
			_data.statusFirma = firma;
			_data.txtModal = txtModalContratos==null?false:txtModalContratos;

			var resPromise = ngDialog.openConfirm({ 
				template: 'src/viewsControllers/avisos/visualizaDocView.html',
				data:_data
			});			

			if( doFunction && doFunction != null )
				doFunction();
			
			return resPromise;
			
		};
		
		
		service.huellaModal = function(cssTitulo){	              
			return  ngDialog.openConfirm({ 
									template: 'src/viewsControllers/modal/huellaModal.html',
									controller: 'huellaModalController',
									data:{
											estiloTitulo: cssTitulo==null? "bgAzul": cssTitulo
										},
																											
				   	});
		};
		
		
		service.codigoModal = function (inputCode,validacion,tipoPersona){
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/ochoPasos/codigoDialog.html',
				controller: 'codigoDialogController',
				data : {
					codigos : inputCode,
					validacion: validacion,
					tipoPersona: tipoPersona,
					closeByDocument: true,
	                closeByEscape: true
				}
			});
		}
		
		service.modalFirmaUnica = function(){
			
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/modalFirmas/modalFirmaUnicaView.html',
				controller: 'modalFirmaUnicaController',
				data: null
			});
			
		};	
		
		service.telefonoModal = function (caso){
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/simulador/telefonoDialog.html',
				controller: 'telefonoDialogController',
				data : {
					caso : caso,
					closeByDocument: true,
	                closeByEscape: true
				}
			});
		}
		
		
		service.homonimosAvalModal = function( titulo, cssTitulo, scope )
		{
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/aval/homonimosAvalView.html',
				controller: 'homonimosAvalController',
				className: 'ngDialog-theme-default homonimosModal',
				data:{
					title: titulo, 
					estiloTitulo: cssTitulo == null? "bgAzul": cssTitulo,
					scopeParent: scope					
				}
			});
			
		};
		
		service.ofertaModal = function( jsonOferta ){
			
			return ngDialog.openConfirm({ 
				template: 'src/viewsControllers/ochoPasos/ofertaView.html',
				controller: 'ofertaController',
				data: {
					oferta: jsonOferta
				}
//				closeByDocument:true
			});
			
		};
		
		service.loginModal = function(){	 
			
			if( window.location.hash == "#/login") 
				return null;
				
			else{
				return  ngDialog.open({ 
					template: 	'src/viewsControllers/modal/loginModal.html',	
					controller: 'loginModalController'
																							
				});
			}
			
			
		};	
			
		
		service.seguro = function(){	              
			return  ngDialog.openConfirm({ 
									template: 	'src/viewsControllers/modal/seguroView.html',	
									controller: 'seguroDialogController'
																											
				   	});
			
		};	
		
		
		service.deslizaTarjeta = function(titulo, cssTitulo){	              
			return  ngDialog.openConfirm({ 
									template: 	'src/viewsControllers/liberacion/tarjetaModal.html',	
									controller: 'tarjetaModalController',
									data:{
										title: titulo, 
										estiloTitulo: cssTitulo == null? "bgAzul": cssTitulo,			
									}
																											
				   	});
			
		};	
// I-MODIFICACION TDC		
		service.entregaTarjeta = function(titulo, cssTitulo){	              
			return  ngDialog.openConfirm({ 
									template: 	'src/viewsControllers/liberacion/AbrirTarjetaModal.html',	
									controller: 'tarjetaModalController',
									data:{
										title: titulo, 
										estiloTitulo: cssTitulo == null? "bgAzul": cssTitulo,			
									}
																											
				   	});
			
		};	
// F-MODIFICACION TDC
		
		
		service.nipModal = function(){	              
				return  ngDialog.open({ 
										template: 	'src/viewsControllers/modal/nipModal.html',	
										controller: 'nipModalController'
																												
					   	});														
		};
		
		service.validaDocsModal = function( titulo, cssTitulo, idDoc, imgs, txt){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/expediente/modalValidaDocs.html',
				controller: 'modalValidaDocController',
				className: ' ngDialog-theme-default autoWidthModal',
				data:{
					title: titulo, 
					estiloTitulo: cssTitulo == null? "bgCafe": cssTitulo,
					documentoId: idDoc,
					images: imgs,
					texto: txt
				}
			});			
		};
		
		service.cotizadorModal = function( titulo, cssTitulo, vScope, data){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/ochoPasos/modalCotizadorView.html',
				controller: 'modalCotizadorController',
				className: ' ngDialog-theme-default autoWidthModal',
				scope: vScope,
				data:data,
			    preCloseCallback: function() {
			    	$( "html" ).removeClass( "overflowHiddenHTML").addClass( "overflowInitialHTML");
			    }
			});			
		};
		
		service.cotizadorModalMLC = function( titulo, cssTitulo, vScope, data){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/ochoPasos/modalCotizadorViewML.html',
				controller: 'modalCotizadorControllerML',
				className: ' ngDialog-theme-default autoWidthModal',
				scope: vScope,
				data:data,
			    preCloseCallback: function() {
			    	$( "html" ).removeClass( "overflowHiddenHTML").addClass( "overflowInitialHTML");
			    }
			});			
		};

/*================================================= INE 2.0 =================================================*/	
		service.modalAyudaINE = function( titulo, cssTitulo, vScope, data){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/simulador/modalAyudaINEView.html',
				controller: 'modalAyudaINEController',
				className: ' ngDialog-theme-default autoWidthModal',
				scope: vScope,
				data: data,
			    preCloseCallback: function() {
			    	$( "html" ).removeClass( "overflowHiddenHTML").addClass( "overflowInitialHTML");
			    }
			});			
		};
/*===========================================================================================================*/		
		
		service.cotizadorModalNO = function( titulo, cssTitulo, vScope, data){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/ochoPasos/modalCotizadorNOView.html',
				controller: 'modalCotizadorNOController',
				className: ' ngDialog-theme-default autoWidthModal',
				scope: vScope,
				data:data,
			    preCloseCallback: function() {
			    	$( "html" ).removeClass( "overflowHiddenHTML").addClass( "overflowInitialHTML");
			    }
			});			
		};
// I-MODIFICACION TDC
		service.cuentasModal = function( titulo, cssTitulo, vScope, data){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/ochoPasos/modalCuentasView.html',
				controller: 'modalCuentasController',
				className: ' ngDialog-theme-default autoWidthModal',
				scope: vScope,
				data:{cuentas: data},
			    preCloseCallback: function() {
			    	$( "html" ).removeClass( "overflowHiddenHTML").addClass( "overflowInitialHTML");
			    }
			});			
		};

		service.tarjetaModal = function( titulo, cssTitulo, vScope, data){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/modal/modalTarjetaView.html',
				controller: 'modalTarjetaController',
				className: ' ngDialog-theme-default autoWidthModal',
				scope: vScope,
				data:data,
			    preCloseCallback: function() {
			    	$( "html" ).removeClass( "overflowHiddenHTML").addClass( "overflowInitialHTML");
			    }
			});			
		};
		
		
// F-MODIFICACION TDC
// I-MODIFICACION (BUSQUEDA SIPA)
		service.busqiedaSipaModal = function(color){
			
			return ngDialog.open({
				template: 'src/viewsControllers/modal/busquedaSipaModal.html',
				controller: 'busquedaSipaController',
				data:{color: color}
			});
			
		};
// F-MODIFICACION (BUSQUEDA SIPA)		
		service.cotizadorModalML = function( titulo, cssTitulo, vScope, data){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/ochoPasos/modalCotizadorMLView.html',
				controller: 'modalCotizadorMLController',
				className: ' ngDialog-theme-default autoWidthModal',
				scope: vScope,
				data:data,
			    preCloseCallback: function() {
			    	$( "html" ).removeClass( "overflowHiddenHTML").addClass( "overflowInitialHTML");
			    }
			});			
		};
		
		service.compDomicilioModal = function(documentoId){
						
			return ngDialog.open({
				template: 'src/viewsControllers/modal/compDomicilioModal.html',
				controller: 'compDomicilioModalController',
				data:{documentoId: documentoId}
			});
			
		};
		
		
		service.identificacionOficialModal = function(documentoId){
			
			return ngDialog.open({
				template: 'src/viewsControllers/modal/identificacionOficialModal.html',
				controller: 'identificacionOficialModalController',
				data:{documentoId: documentoId}
			});
			
		};		
		
/** INICIA_OS-FLUJO COACREDITADO **/
		service.compDomicilioOSModal = function(documentoId){
			
			return ngDialog.open({
				template: 'src/viewsControllers/obligadoSolidario/modalOS/compDomicilioOSModal.html',
				controller: 'compDomicilioOSModalController',
				data:{documentoId: documentoId}
			});
			
		};
		
		service.identificacionOficialOSModal = function(documentoId){
			
			return ngDialog.open({
				template: 'src/viewsControllers/obligadoSolidario/modalOS/identificacionOficialOSModal.html',
				controller: 'identificacionOficialOSModalController',
				data:{documentoId: documentoId}
			});
			
		};
/** TERMINA_OS-FLUJO COACREDITADO **/
		
		/**
		 * Se crea la modal en donde contendrá las opciones para autorizar salir de la zona de zonificación o volver a la direccion principal
		 **/
		service.modalAceptaZonificacion = function( titulo, cssTitulo, idDoc, imgs, txt){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/modal/modalAceptaZonificacion.html',
				controller: 'modalAceptaZonificacionController',
				className: ' ngDialog-theme-default autoWidthModal',
				data:{
					title: titulo, 
					estiloTitulo: cssTitulo == null? "bgCafe": cssTitulo,
					documentoId: idDoc,
					images: imgs,
					texto: txt
				}
			});			
		};		
		
		
		/*
		 * Se crea modal para el tratamiento de los datos personales en el aviso de Privacidad
		 */
		service.tratamientoDP = function( titulo, cssTitulo, idDoc, imgs, txt){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/modal/tratamientoDP.html',
				controller: 'tratamientoDPController',
				className: ' ngDialog-theme-default autoWidthModal',
				data:{
					title: titulo, 
					estiloTitulo: cssTitulo == null? "bgCafe": cssTitulo,
					documentoId: idDoc,
					images: imgs,
					texto: txt
				}
			});			
		};
		
		/*
		 * Se crea modal para el tratamiento de los datos personales del Coacreditado en el aviso de Privacidad
		 */
		service.tratamientoOSdp = function( titulo, cssTitulo, idDoc, imgs, txt){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/modal/tratamientoOSdp.html',
				controller: 'tratamientoOSdpController',
				className: ' ngDialog-theme-default autoWidthModal',
				data:{
					title: titulo, 
					estiloTitulo: cssTitulo == null? "bgCafe": cssTitulo,
					documentoId: idDoc,
					images: imgs,
					texto: txt
				}
			});			
		};
		
		service.showMessageContratos = function( titulo, cssTitulo, idDoc, imgs, txt){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/modal/showMessageContratos.html',
				controller: 'showMessageContratosController',
				className: ' ngDialog-theme-default autoWidthModal',
				data:{
					title: titulo, 
					estiloTitulo: cssTitulo == null? "bgCafe": cssTitulo,
					documentoId: idDoc,
					images: imgs,
					texto: txt
				}
			});			
		};
		
		
		service.notificacionModatelasModal = function(){	              
			return  ngDialog.openConfirm({ 
						template: 'src/viewsControllers/modal/notificacionModatelasModal.html',	
						controller: 'notificacionModatelasModalController'																																					
			   	});			
		};
		
		service.opcionCreditoModal = function( titulo, cssTitulo, vScope, data){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/modal/modalOpcionesDeCreditoView.html',
				controller: 'modalOpcionesDeCreditoController',
				className: ' ngDialog-theme-default autoWidthModal',
				scope: vScope,
				data:data,
				preCloseCallback: function() {
			    	$( "html" ).removeClass( "overflowHiddenHTML").addClass( "overflowInitialHTML");
			    }
			});			
		};
		
		service.ofertaPromocionesBuenFinModal = function( titulo, cssTitulo, vScope, data){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/modal/modalOfertaPromocionesBuenFinView.html',
				controller: 'modalOfertaPromocionesBuenFinController',
				className: ' ngDialog-theme-default autoWidthModal',
				scope: vScope,
				data:data,
				preCloseCallback: function() {
					$( "html" ).removeClass( "overflowHiddenHTML").addClass( "overflowInitialHTML");
				}
			});			
		};
		
		service.pdfViewModal = function(fileName, titulo, nombreConfirmBoton, nombreCancelarBoton, cssTitulo, cssBotonConfirm, cssBotonCancelar, creditoInmediato, contratos, 
                acpetados, firma, txtModalContratos,imagenesArray, muestraAvisos, negacionCheck){
			
			var _data = generalService.textosModal(titulo, null, nombreConfirmBoton, nombreCancelarBoton, cssTitulo, cssBotonConfirm, cssBotonCancelar, null, null);
			_data.fileName = (configuracion.modo.offLine?"documents/":"PdfServlet?fileName=")+fileName+"#page=1";
			_data.credInmd = creditoInmediato==null?true:creditoInmediato;
			_data.esContratos = contratos==null?false:contratos;
			_data.aceptados =  (acpetados>=0)?true:false;
			_data.statusFirma = firma;
			_data.txtModal = txtModalContratos==null?false:txtModalContratos;
			_data.imagenesArray = imagenesArray;
			_data.muestraAvisos = muestraAvisos;
			_data.negacionCheck= negacionCheck;
			
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/modal/pdfViewModal.html',
				className: 'ngDialog-theme-default visorPdf',
				controller: 'pdfWindowsController',
				data:_data
			});
			
		};
		
/** INICIA_OS-FLUJO COACREDITADO **/
		/** Se agregaron nuevo modales para los contratos del Coacreditado
		 * La siguiente funsión muestra el modal del contrato (Realiza la ejecución del HTML) 
		 **/
		service.pdfViewModalOS = function(fileName, titulo, nombreConfirmBoton, nombreCancelarBoton, cssTitulo, cssBotonConfirm, cssBotonCancelar, creditoInmediato, contratos, 
                acpetados, firma, txtModalContratos,imagenesArray, muestraAvisos, negacionCheck){
			
			var _data = generalService.textosModal(titulo, null, nombreConfirmBoton, nombreCancelarBoton, cssTitulo, cssBotonConfirm, cssBotonCancelar, null, null);
			_data.fileName = (configuracion.modo.offLine?"src/viewsControllers/obligadoSolidario/avisosOS/modalAvisosOS/":"PdfServlet?fileName=")+fileName+"#page=1";
			_data.credInmd = creditoInmediato==null?true:creditoInmediato;
			_data.esContratos = contratos==null?false:contratos;
			_data.aceptados =  (acpetados>=0)?true:false;
			_data.statusFirma = firma;
			_data.txtModal = txtModalContratos==null?false:txtModalContratos;
			_data.imagenesArray = imagenesArray;
			_data.muestraAvisos = muestraAvisos;
			_data.negacionCheck= negacionCheck;
			
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/obligadoSolidario/avisosOS/pdfWindowsOSView.html',
				className: 'ngDialog-theme-default visorPdf',
				controller: 'pdfWindowsOSController',
				data:_data
			});
		/** ---------------------------------------------- **/
/** TERMINA_OS-FLUJO COACREDITADO **/	
			
		};
		
		service.tipoIdentificacionOficialModal = function(nacionalidades){
			
			return ngDialog.open({
				template: 'src/viewsControllers/modal/tipoIdentOficialModal.html',
				controller: 'tipoIdentOficialModalController',
				data:{nacionalidades: nacionalidades}
			});
			
		};
		
		//*Modal para mostrar folio de recomienda y gana *// 
		service.recomiendaModal = function(color, folio){	              
			return  ngDialog.openConfirm({ 
						template: 'src/viewsControllers/folioRecomienda/recomiendaModal.html',	
						controller: 'recomiendaModalController',
						data:{color: color, folio: folio}
			   	});			
		};
		service.recomiendaCuentasModal = function(titulo, cssTitulo, vScope, data){	              
			return  ngDialog.openConfirm({ 
						template: 'src/viewsControllers/folioRecomienda/CuentasRecompraView.html',	
						controller: 'CuentasRecompraController',
						scope: vScope,
						data:{cuentas: data},
					    preCloseCallback: function() {
					    	$( "html" ).removeClass( "overflowHiddenHTML").addClass( "overflowInitialHTML");
					    }
			   	});			
		};
		service.codigoRecomiendaModal = function (inputCode,validacion,tipoPersona){
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/folioRecomienda/codigoRecomiendaDialog.html',
				controller: 'codigoRecomiendaDialogController',
				data : {
					codigos : inputCode,
					validacion: validacion,
					tipoPersona: tipoPersona,
					closeByDocument: true,
	                closeByEscape: true
				}
			});
		}
		
		//* Modal para mostrar los documentos rechazados por Mesa de control *//
		service.muestraDocsModal = function(titulo, cssTitulo, idDoc, imgs, txt){
			
			return ngDialog.openConfirm({
			template: 'src/viewsControllers/expediente/muestraDocView.html',
			controller: 'muestraDocController',
			className: 'ngDialog-theme-default autoWidthModal',
			data:{
				title: titulo, 
				estiloTitulo: cssTitulo == null? "bgCafe": cssTitulo,
				documentoId: idDoc,
				images: imgs,
				texto: txt
			}
		});			
	};		
	
/** INICIA_OS-FLUJO COACREDITADO **/
	/** Modal para mostrar la notificacion del Coacreditado **/
	service.obligadoSolidarioModal = function(titulo, lista, nombreCancelarBoton, nombreConfirmBoton, otro, cssTitulo, cssBotonCancelar, cssBotonConfirm, seccion, parametroDialogoModel){	              
		return  ngDialog.openConfirm({ 
					template: 'src/viewsControllers/modal/obligadoSolidarioModal.html',	
					data: {titulo, lista, nombreConfirmBoton, nombreCancelarBoton, nombreCancelarBoton, otro, cssTitulo, cssBotonConfirm, cssBotonCancelar, seccion, parametroDialogoModel}																					
		   	});			


	};
/** TERMINA_OS-FLUJO COACREDITADO **/
	
	/** Carga la modal para mostrar los productos de Rescate de Telefonia **/	
	service.proResTelefoniaModal = function( titulo, codigosBuro){									
		return ngDialog.openConfirm({
			template: 'src/viewsControllers/modal/modalProResTelefonia.html',
			controller: 'modalProResTelefoniaController',
			className: ' ngDialog-theme-default autoWidthModal',
			data:{
				title: titulo,
				codigosBuro: codigosBuro
			}
		});			
	};	
	
/** Carga la modal para mostrar los mensajes del cambaceo **/	
	service.cambaceoModal = function( titulo, codigosBuro){									
		return ngDialog.openConfirm({
			template: 'src/viewsControllers/modal/modalCambaceo.html',
			controller: 'modalCambaceoController',
			className: ' ngDialog-theme-default autoWidthModal',
			data:{
				title: titulo, 
				codigosBuro: codigosBuro
			}
		});			
	};	
	
	/** Carga la modal para mostrar los productos de restate de Italika **/	
	service.rescateItalikaModal = function( titulo, marca){									
		return ngDialog.openConfirm({
			template: 'src/viewsControllers/modal/modalRescateItalika.html',
			controller: 'modalRescateItalikaController',
			className: ' ngDialog-theme-default autoWidthModal',
			data:{
				title: titulo, 
				codigosBuro: marca
			}
		});			
	};
	
	/** Carga la modal para mostrar los productos de Rescate de Consumo **/	
	service.rescateConsumoModal = function( titulo, producto){									
		return ngDialog.openConfirm({
			template: 'src/viewsControllers/modal/modalProResConsumo.html',
			controller: 'modalProResConsumoController',
			className: ' ngDialog-theme-default autoWidthModal',
			data:{
				title: titulo,
				producto: producto
			}
		});			
	};
	
	/** Modal para Producto de Rescate Prestamo Personal **/
	service.rescatePrestamoModal = function( titulo, marca){									
		return ngDialog.openConfirm({
			template: 'src/viewsControllers/modal/modalProResPrestamoPersonal.html',
			controller: 'modalProResPrestamoPersonalController',
			className: ' ngDialog-theme-default autoWidthModal',
			data:{
				title: titulo,
				marca: marca
			}
		});			
	};
	
	/** Modal para Producto de Rescate Prestamo Personal **/
	service.rescatePrestamoFaseIIModal = function( titulo, marca){									
		return ngDialog.openConfirm({
			template: 'src/viewsControllers/modal/modalRescatePP.html',
			controller: 'modalRescatePPController',
			className: ' ngDialog-theme-default autoWidthModal',
			data:{
				title: titulo,
				marca: marca
			}
		});			
	};
	
	/** Modal para Producto de Rescate Consumo **/
	service.rescateConsumoFaseIIIModal = function( titulo, marca){									
		return ngDialog.openConfirm({
			template: 'src/viewsControllers/modal/modalRescateConsumoF3View.html',
			controller: 'modalRescateConsumoF3Controller',
			className: ' ngDialog-theme-default autoWidthModal',
			data:{
				title: titulo,
				marca: marca
			}
		});			
	};
	
	/** Modal para Producto de Rescate Credito en Efectivo  **/
	service.rescateCreditoEnEfectivo = function( titulo, marca){									
		return ngDialog.openConfirm({
			template: 'src/viewsControllers/modal/rescateCreditoEnEfectivoView.html',
			controller: 'rescateCreditoEnEfectivoController',
			className: ' ngDialog-theme-default autoWidthModal',
			data:{
				title: titulo,
				marca: marca
			}
		});			
	};
	
	/** Modal para Linea Consumo **/
	service.rescateConsumoFaseIII_2Modal = function( titulo, marca){									
		return ngDialog.openConfirm({
			template: 'src/viewsControllers/modal/modalRescateConsumoF3_2View.html',
			controller: 'modalRescateConsumoF3_2Controller',
			className: ' ngDialog-theme-default autoWidthModal',
			data:{
				title: titulo,
				marca: marca
			}
		});			
	};
	
	/** Modal para Producto de Rescate Italika **/
	service.rescateItalikaFaseIIIModal = function( titulo, marca){									
		return ngDialog.openConfirm({
			template: 'src/viewsControllers/modal/modalRescateItalikaF3View.html',
			controller: 'modalRescateItalikaF3Controller',
			className: ' ngDialog-theme-default autoWidthModal',
			data:{
				title: titulo,
				marca: marca
			}
		});			
	};
	
	/** Modal para Producto de Rescate Telefonia **/
	service.rescateTelefoniaFaseIIIModal = function( titulo, marca){									
		return ngDialog.openConfirm({
			template: 'src/viewsControllers/modal/modalRescateTelefoniaF3View.html',
			controller: 'modalRescateTelefoniaF3Controller',
			className: ' ngDialog-theme-default autoWidthModal',
			data:{
				title: titulo,
				marca: marca
			}
		});			
	};
	
	/** Modal intermedio entre dia de pago y ficha para productos de Rescate **/	
	service.liberarPRModal = function( titulo, producto){									
		return ngDialog.openConfirm({
			template: 'src/viewsControllers/modal/modalLiberacionPR.html',
			controller: 'modalLiberacionPRController',
			className: ' ngDialog-theme-default autoWidthModal',
			data:{
				title: titulo,
				producto: producto
			}
		});			
	};
	
	//modal cotizador para convivencia
	service.modalCotizadorTDC = function(vScope){
		return  ngDialog.open({
			template: 'src/viewsControllers/modal/modalCotizadorTDC.html',
			controller: 'modalCotizadorTDCController',
			className: 'ngDialog-theme-default autoWidthModal ',
			data:{
				scopeParent: vScope					
			}
		});
	};
	
	//* Modal informativo para el comprobante de ingresos*//
	service.muestraInfoModalExp = function(titulo, cssTitulo, txt){
		
		return ngDialog.openConfirm({
		template: 'src/viewsControllers/expediente/modalExpInformativo.html',
		className: 'ngDialog-theme-default autoWidthModal',
		data:{
			title: titulo, 
			estiloTitulo: cssTitulo == null? "bgCafe": cssTitulo,
			texto: txt
			}
		});			
	};

	
		//* Modal informativo *//
		service.muestraInfoModalDB = function(titulo, cssTitulo, txt){
			
			return ngDialog.openConfirm({
			template: 'src/viewsControllers/datosBasicos/modalDBInformativo.html',
			className: 'ngDialog-theme-default autoWidthModal',
			data:{
				title: titulo, 
				estiloTitulo: cssTitulo == null? "bgNaranja": cssTitulo,
				texto: txt
			}
		});			
		};
		
		/** Modal informativo para el Dia de las Madres **/	
		service.diaMadresModal = function( titulo, cuerpo, pie){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/modal/modalDiaMadres.html',
				controller: 'modalDiaMadresController',
				className: ' ngDialog-theme-default autoWidthModal',
				data:{
					title: titulo,
					cuerpo: cuerpo,
					pie: pie
				}
			});			
		};

		service.contratosOriginacion = function( titulo, cssTitulo, idDoc, imgs, txt){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/contratos/contratosOriginacionView.html',
				controller: 'contratosOriginacionController',
				className: ' ngDialog-theme-default autoWidthModal',
				data:{
					title: titulo, 
					estiloTitulo: cssTitulo == null? "bgCafe": cssTitulo,
					documentoId: idDoc,
					images: imgs,
					texto: txt
				}
			});			
		};
	
		service.visorContratos = function( titulo, cssTitulo, vScope, data){
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/ochoPasos/modalVisorContratosView.html',
				controller: 'modalVisorContratosController',
				className: ' ngDialog-theme-default autoWidthModal',
				scope: vScope,
			    preCloseCallback: function() {
			    	$( "html" ).removeClass( "overflowHiddenHTML").addClass( "overflowInitialHTML");
			    }
			});			
		};
		
		service.visorSeccionContratos = function( titulo, cssTitulo, vScope, data){
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/contratos/visorSeccionContratosView.html',
				controller: 'visorSeccionContratosController',
				className: ' ngDialog-theme-default autoWidthModal',
				scope: vScope,
			    preCloseCallback: function() {
			    	$( "html" ).removeClass( "overflowHiddenHTML").addClass( "overflowInitialHTML");
			    }
			});			
		};

		service.modalIDComplementaria = function( titulo, cssTitulo, vScope, data){
			return ngDialog.openConfirm({
			template: 'src/viewsControllers/simulador/modalIDComplementariaView.html',
			controller: 'modalIDComplementariaController',
			className: ' ngDialog-theme-default autoWidthModal',
			scope: vScope,
			data: data,
			    preCloseCallback: function() {
			    $( "html" ).removeClass( "overflowHiddenHTML").addClass( "overflowInitialHTML");
			    }
			});
		};
		
		
		service.buenFin = function( jsonResponsePromo){									
			return ngDialog.openConfirm({
			template: 'src/viewsControllers/modal/modalPromocionBuenFin.html',
			controller: 'modalPromocionBuenFinController',
			className: ' ngDialog-theme-default autoWidthModal',
			data:{
				jsonResponsePromo: jsonResponsePromo
			}
			});			
		};
		
		/** Modal Pregunta Preaprobado **/
		service.preguntaPreaprobado = function( titulo, marca){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/modal/modalMensajePreaprobados.html',
				controller: 'modalMensajePreaprobadosController',
				className: ' ngDialog-theme-default autoWidthModal',
				data:{
					titulo: titulo,
					marca: marca
				}
			});			
		};
		
		/** Modal Preaprobados Prestamo Personal **/
		service.cotizadorPP = function( titulo, marca){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/modal/modalPreaprobadosPPView.html',
				controller: 'modalPreaprobadosPPController',
				className: ' ngDialog-theme-default autoWidthModal',
				data:{
					title: titulo,
					marca: marca
				}
			});			
		};
		/** Modal Preaprobados Italika, Consumo, Tarjeta y Telefonia **/
		service.preAprobados = function( titulo, marca){									
			return ngDialog.openConfirm({
				template: 'src/viewsControllers/modal/modalPreAprobados.html',
				controller: 'modalPreaprobadosController',
				className: ' ngDialog-theme-default autoWidthModal',
				data:{
					title: titulo,
					marca: marca
				}
			});			
		};
		
		return service; 
	});
	
});