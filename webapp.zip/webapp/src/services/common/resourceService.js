app.factory("resourceService", function($resources, endPointConfigService){
	
	 /**
         * Método para agregar parametros al endPoint
         * 
         * @param {json} objJson Objeto de parametros
         * @param {string} endPoint URL del endPoint
         * @returns {string} endPoint con parametros
         */
        var agregarParametrosAlEndpoint = function(objJson, endPoint) {
            var endPointConParametros = endPoint;
            if ("undefined" !== objJson && null !== objJson) {
                Object.keys(objJson).forEach(function (key) {
                    endPointConParametros += "/:"+key;
                });
            }
            return endPointConParametros;
        };
 
        //HEADER
        var header = {'Content-Type': 'application/json'};
 
        //SERVICE
        var service = {};
        
        //Obtener recurso
        service.getResource = function(endPointKey, objJson){
            var endPoint = endPointConfigService.obtenerRutaEndPoint(endPointKey);
            return $resource(
                    //URL
                    agregarParametrosAlEndpoint(objJson, endPoint),
                    //OBJ
                    objJson,
                    {
                        //METHODS
                        get: { method: 'GET', headers: header },
                        post: { method: 'POST', headers: header },
                        //put: { method: 'PUT', headers: header },
                        //delete: { method: 'DELETE', headers: header },
                        //PARAMETROS
                        charge:{params:{charge:true}}
                    }
                );
        };
})