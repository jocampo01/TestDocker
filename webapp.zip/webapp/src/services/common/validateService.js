'use strict';

define(["app"], function (app) {

	app.factory("validateService", function($rootScope, $location, sessionService, modalService, generalService){
		
		
		var service = {};
		
//		service.error = function(error){
//			$rootScope.waitLoaderStatus = LOADER_HIDE;
//			if(error.status != undefined ){
//				
//				if( error.status == 0  ){
//					if(error.config.timeout == HTTPCODE_TIMEOUT)
//                		modalService.alertModal(ERROR_TIME_OUT.titulo, [ERROR_TIME_OUT.texto],"Aceptar","bgrojo","rojo");
//					else{
//							sessionService.validaSesion();
//					}																						
//					
//				}else if( /*!configuracion.origen.tienda  && */  error.status == 200  &&  error.data.indexOf('../j_spring_security_check')>0  )
//					sessionService.validaSesion();
//					
//				else
//					modalService.alertModal("Error "+error.status, [error.statusText],"Aceptar","bgrojo","rojo");
//				
//			}else						
//				modalService.alertModal("Error en el servidor", [error.message],"Aceptar","bgrojo","rojo"); 
//		};
//		
		
		
		
		service.path = function( pathDestino /*, doFunction*/ ){
			var coloniaOpc=false;
			var arrayPepAnt=null;
			var arrayPep2Ant=null;
			var seccionId = pathSeccion[  window.location.hash ];
			if(( $rootScope.objetoColoniaSeleccionado != undefined && $rootScope.objetoColoniaSeleccionado != "" && $rootScope.objetoColoniaSeleccionado.desc ) && (seccionId == SECCION_HOGAR || seccionId == SECCION_CLIENTES)){
				if($rootScope.coloniaOpcional != ""){
					coloniaOpc=true;
					$rootScope.objetoColoniaSeleccionado.desc=$rootScope.coloniaOpcional;
				}
			}
			var seccionDestino = pathSeccion ["#"+pathDestino];
			if(seccionId == SECCION_VISITA_ASESOR)
				generalService.locationPath(pathDestino);
			else{
				var dMenores=null;
				var dMayores=null;
				var dependientes=false;
				
				var respaldoJsonString = generalService.getRespaldo();
				
//				if( seccionId == SECCION_PERSONALES ){
//					$rootScope.solicitudJson.cotizacion.clientes[0].foto = $rootScope.fotoAnterior;
//					$rootScope.fotoCte = $rootScope.fotoanterior1;
//				}
				
				if(seccionId != SECCION_INGRESOS_GASTOS)
					service.limpiaMascaras();	
				
				if (seccionId == SECCION_PERSONALES || seccionId == SECCION_CLIENTES){
					for (var i = 0; i < $rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS.length; i++){
						if ($rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].numero == 1){
							arrayPepAnt = $rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i];
						}else{
							arrayPep2Ant = $rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i];
						}
					}
					
					var respaldoBasico = JSON.parse(respaldoJsonString);
					for (var i = 0; i < $rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS.length; i++){
						if ($rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].numero == 1){
							if($rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].status == 0 &&
							   $rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].status == respaldoBasico.cotizacion.clientes[0].preguntaPEPS[i].status )
								$rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i]=respaldoBasico.cotizacion.clientes[0].preguntaPEPS[i];
						}else{
							if($rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].status == 0 &&
							   $rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].status == respaldoBasico.cotizacion.clientes[0].preguntaPEPS[i].status )
								$rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i]=respaldoBasico.cotizacion.clientes[0].preguntaPEPS[i];
						}
					}
				}
				
				var solicitudJsonString = generalService.delete$$hashKey($rootScope.solicitudJson);
				
				if(seccionId == SECCION_INGRESOS_GASTOS){
									
					/* RESPALDO: cambiamos formato del monto quitando signo pesos y comas para dejarlo en entero */
					dMenores = respaldoJsonString.split('/')[1];
					if(dMenores == "null" || dMenores == "")
						dMenores = null;
					else 
						dMenores = parseInt(dMenores);
					
					dMayores = respaldoJsonString.split('/')[2];
					if(dMayores == "null" || dMayores == "")
						dMayores = null;	
					else 
						dMayores = parseInt(dMayores);
					
					
					respaldoJsonString=respaldoJsonString.split('/')[0];
					
					var flujoEfectivoRespJson = JSON.parse(respaldoJsonString);
					angular.forEach( flujoEfectivoRespJson, function(ig){
						try{	
							var monto = parseInt(generalService.cleanValue( ig.monto ));
							if(monto >= 0)
								ig.monto = monto;							
							
						}catch(e){ }																			
					});
					if( generalService.isEmpty($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores ))
						$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores=null;
					else
						$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores);
						
					if(generalService.isEmpty($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores))
						$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores=null;
					else
						$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores);
						
					if(dMenores != $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores)
						dependientes=true;
					if(dMayores != $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores)
						dependientes=true;
					
					respaldoJsonString = generalService.delete$$hashKey(flujoEfectivoRespJson);
					
					/* ACTUAL: cambiamos formato del monto quitando signo pesos y comas para dejarlo en entero */
					var ff = new Array();
					
					angular.forEach( $rootScope.flujoEfectivo, function(ig){
						try{	
							var monto = parseInt(generalService.cleanValue( ig.monto ));
							if(monto >= 0){
								var gasto = { idTipo:ig.idTipo, tipoDes:ig.tipoDes, idConcepto:ig.idConcepto, conceptoDes:ig.conceptoDes, monto:monto };							
								ff.push(gasto);								
							}
							
						}catch(e){ }																			
					});														
					
					
					solicitudJsonString = generalService.delete$$hashKey(ff);				
					$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo = JSON.parse(solicitudJsonString);
					
				}else if(seccionId == SECCION_DOCUMENTOS){
					
					if (	!configuracion.origen.tienda  ||  
							( ($rootScope.userSession.idPuesto == PUESTO_GERENTE ||
									$rootScope.userSession.idPuesto == PUESTO_GERENTE_PRUEBA || 
							  ($rootScope.sucursalSession!=null  && generalService.isCanalExterno($rootScope.sucursalSession.idCanal) )  )  && 
							  $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.ejecutivo   )
						){
						
							solicitudJsonString = respaldoJsonString;
							$rootScope.solicitudJson = JSON.parse(solicitudJsonString);
					}				
	
				}
				var objColonia="";
				var objColoniaAval="";
				if( seccionId == SECCION_HOGAR || seccionId == SECCION_AVAL || seccionId == SECCION_CLIENTES){
	
					if( $rootScope.objetoColoniaSeleccionado != undefined && $rootScope.objetoColoniaSeleccionado != "" && $rootScope.objetoColoniaSeleccionado.desc ){
						objColonia=$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia;
						$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.objetoColoniaSeleccionado.desc;
						solicitudJsonString = generalService.delete$$hashKey($rootScope.solicitudJson);
					}
					
					
//					if( $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc ){
//						objColoniaAval=$rootScope.solicitudJson.avales[0].datosHogar.colonia;
//						$rootScope.solicitudJson.avales[0].datosHogar.colonia = $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc;
//						solicitudJsonString = generalService.delete$$hashKey($rootScope.solicitudJson);
//					}
	
				}		
				
				
				var colorDialogo = "azulD";
				var botonDialogo = "btnAzulD";
				
				if (seccionId == SECCION_PERSONALES || seccionId == SECCION_CLIENTES){
					angular.forEach( $rootScope.flujoEfectivo, function(ig){
						try{	
							var monto = parseInt(generalService.cleanValue( ig.monto ));
							if(monto == 0)
								ig.monto = "";
						}catch(e){ }																			
					});
				}
				
				var newFlujoEfectivo=JSON.stringify($rootScope.flujoEfectivo, function (key, val) { 
					 if (key == '$$hashKey')  
						 return undefined; 
					  
					  return val; 
				}); 
				var cambioFlujoEfectivo = false;
				if ((seccionId == SECCION_PERSONALES || seccionId == SECCION_CLIENTES) && generalService.flujoEfectivo != newFlujoEfectivo)
					cambioFlujoEfectivo = true;
				
				if((respaldoJsonString != solicitudJsonString || cambioFlujoEfectivo || dependientes) && seccionDestino != seccionId ){
					switch(seccionId){
						case SECCION_CLIENTES:
						case SECCION_PERSONALES:
							colorDialogo = "bgNaranja";
							botonDialogo = "btnNaranja";
							break;
						case SECCION_HOGAR:
							colorDialogo = "bgRosa";
							botonDialogo = "btnRosa";
							break;
						case SECCION_EMPLEO:
							colorDialogo = "bgAzulD";
							botonDialogo = "btnAzulD";
							break;
						case SECCION_INGRESOS_GASTOS:
							colorDialogo = "bgVerde";
							botonDialogo = "btnVerde";
							break;
						case SECCION_AVAL:
							colorDialogo = "bgAzulT";
							botonDialogo = "btnVerdeD";
							break;
						case SECCION_REFERENCIAS:
							colorDialogo = "bgCafeA";
							botonDialogo = "btnCafe";
							break;
						case SECCION_DOCUMENTOS:
							colorDialogo = "bgCafe";
							botonDialogo = "btnCafeD";
							break;
						case SECCION_CONTRATOS:
							colorDialogo = "bgRosa";
							botonDialogo = "btnRosaD";
							break;
						case SECCION_SOLICITUD:
							colorDialogo = "bgAzul";
							botonDialogo = "btnAzul";
							break;
						case SECCION_SIMULADOR:
							colorDialogo = "bgAzul";
							botonDialogo = "btnAzul";
							break;
					}/* END SWITCH */
				modalService.confirmModal("Advertencia", ["Aun no ha guardado los datos ¿Desea continuar?", "Si da click en \"Aceptar\" se perderán los cambios."], "Cancelar","Aceptar",colorDialogo, "btnCancel", botonDialogo)
					.then( 
						function(confirm){
							if( seccionId == SECCION_PERSONALES || seccionId == SECCION_CLIENTES){
								$rootScope.solicitudJson.cotizacion.clientes[0].foto = $rootScope.fotoAnterior;
								$rootScope.fotoCte = $rootScope.fotoanterior1;
							}
							if(seccionId == SECCION_INGRESOS_GASTOS){
								$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo = JSON.parse(respaldoJsonString);
								$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores=dMenores;
								$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores=dMayores; 
							}else{
								$rootScope.solicitudJson = JSON.parse(respaldoJsonString);
								if( seccionId == SECCION_HOGAR || seccionId == SECCION_AVAL || seccionId == SECCION_CLIENTES){
	
									if( $rootScope.objetoColoniaSeleccionado != undefined && $rootScope.objetoColoniaSeleccionado != "" && $rootScope.objetoColoniaSeleccionado.desc )
										$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.objetoColoniaSeleccionado.desc;
									
									
//									if( $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc )
//										$rootScope.solicitudJson.avales[0].datosHogar.colonia = $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc;
									
	
								}
							}
							$rootScope.coloniaOpcional = "";
							if(seccionDestino == SECCION_OCHO_PASOS){
								/*\Se agrega un evento para la bitacora\*/
	    		  				agregaEventoCancelar(pathDestino);
	    						/*\Se agrega un evento para la bitacora\*/
	    		  				generalService.locationPath(pathDestino);
							}
							else
								codigoValidar(pathDestino);
						},function(cancel){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if( seccionId == SECCION_HOGAR || seccionId == SECCION_CLIENTES){
								if(objColonia != "")
									$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=objColonia;
								if(coloniaOpc)
									$rootScope.objetoColoniaSeleccionado.desc="NO SE ENCUENTRA COLONIA";
							}
							if( seccionId == SECCION_AVAL )
								$rootScope.solicitudJson.avales[0].datosHogar.colonia=objColoniaAval;
							if ( seccionId == SECCION_PERSONALES || seccionId == SECCION_CLIENTES ){
								for (var i = 0; i < $rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS.length; i++){
									if ($rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].numero == 1){
										$rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i] = arrayPepAnt;
									}else{
										$rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i] = arrayPep2Ant;
									}
								}
							}
							console.log("no continuar");						
						}
					);
					
				}else{
					
					
					
					if( seccionId == SECCION_HOGAR || seccionId == SECCION_AVAL || seccionId == SECCION_CLIENTES){
						
						if(seccionId == SECCION_HOGAR || seccionId == SECCION_CLIENTES){
							if(objColonia != "")
								$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=objColonia;
							if(seccionDestino != seccionId){
								if(coloniaOpc)
									$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=$rootScope.coloniaOpcional;
								$rootScope.coloniaOpcional="";
							}else{
								if(coloniaOpc)
									$rootScope.objetoColoniaSeleccionado.desc="NO SE ENCUENTRA COLONIA";
							}
						}
						
						if( ($rootScope.objetoColoniaSeleccionado != undefined && $rootScope.objetoColoniaSeleccionado != "" && $rootScope.objetoColoniaSeleccionado.desc) && seccionDestino != seccionId)
							$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.objetoColoniaSeleccionado.desc;
						
//						if( $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc)
//							$rootScope.solicitudJson.avales[0].datosHogar.colonia = $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc;
						
	
					}
					
						
					
	//				if( doFunction ){
	//					doFunction();
	//				}
					
					
					
														
					codigoValidar(pathDestino);				
				
				}	
			}
		};
		
		
		var codigoValidar = function(opcion) {
	    	var tipoPersona = CLIENTE.id;
			
	    	var callModal = function( persona ){
	    		if($rootScope.consultaFuncionalidad.liberacionSinCodigo) {
		  			if(opcion != null && opcion) {
						/*\Se agrega un evento para la bitacora\*/
		  				agregaEventoCancelar(opcion);
						/*\Se agrega un evento para la bitacora\*/
    					generalService.locationPath(opcion);
    				}
	    		} else {
	    			modalService.codigoModal( null, opcion, persona ).then(
    					function(exito) {
    						/*\Se agrega un evento para la bitacora\*/
    		  				agregaEventoCancelar(opcion);
    						/*\Se agrega un evento para la bitacora\*/
    						generalService.locationPath(opcion);
    					}, function(error) {
    						/*\Se agrega un evento para la bitacora\*/
    		  				agregaEventoCancelar(opcion);
    						/*\Se agrega un evento para la bitacora\*/
    						generalService.locationPath(opcion);
    					}
    				);
	    		}
	    	};
	    		    		
		  	if( opcion == validacionPath[SECCION_AVAL].nombrePath )
		  		tipoPersona = AVAL.id;
		  				  		
		  	if( ( $rootScope.solicitudJson.envioCelular == 0 
		  			/* || ( $rootScope.solicitudJson.cotizacion.clientes[0].email != "" 
		  			&& $rootScope.solicitudJson.envioCorreo == 0 )*/ 
		  		) && tipoPersona == CLIENTE.id ){
		  			callModal( tipoPersona );
		  	}else if( ( $rootScope.solicitudJson.avales[0].envioCelular == 0 
		  			/*|| ( $rootScope.solicitudJson.avales[0].email != "" 
		  					&& $rootScope.solicitudJson.avales[0].envioCorreo == 0 )*/ 
		  			) && tipoPersona == AVAL.id && $rootScope.solicitudJson.avales[0].presencial == 1 ){
		  			callModal( tipoPersona );
		  	}else{
		  		if( opcion != null && opcion ){
		  			/*\Se agrega un evento para la bitacora\*/
	  				agregaEventoCancelar(opcion);
					/*\Se agrega un evento para la bitacora\*/
	  				generalService.locationPath(opcion);
		  		}
		  	}
		  	
		};
		
		service.limpiaMascaras = function()
		{
			
			var arrayInputs = document.getElementsByTagName( "input" );
						
			for( var i = 0; i < arrayInputs.length; i++ ){
				
				var currentInput = arrayInputs[i];
				
				if( currentInput.hasAttribute('formato') && currentInput.hasAttribute('valor') ){
									
					var format = currentInput.getAttribute('formato');
//					$scope.modelValue = $rootScope.$eval( currentInput.getAttribute('ng-model') ); 
//					console.log( $scope.modelValue );
//					$rootScope.$eval( currentInput.getAttribute('ng-model') ) = "16516";
					var model = currentInput.getAttribute('ng-model');
					
					if( currentInput.hasAttribute('valor')){
						var etiquetaValor = currentInput.getAttribute('valor');
					}
					
					var newValue = currentInput.value;//$rootScope.$eval( model );
					
					var returnObj = generalService.limpiaFormato( newValue, format );
					
					switch( format ){
						case 'NIP-#':
								if( newValue ){
									$rootScope.$eval( etiquetaValor + "=" + parseInt(returnObj) );
								}else{
									console.warn( 'Be careful, {' + etiquetaValor + '} can\'t exe instanced' );
									$rootScope.$eval( etiquetaValor + "=''" );
								}
							break;
						case 'NIP-$':
								if( newValue ){
									$rootScope.$eval( etiquetaValor + "=" + parseInt(returnObj) );
								}else{
									console.warn( 'Be careful, {' + etiquetaValor + '} can\'t exe instanced' );
									$rootScope.$eval( etiquetaValor + "=''" );
								}
							break;
						case 'LM':
							break
						case 'Lm':
							break
						case 'M':
							break
						case 'm':
							break
						default:
								if( newValue || newValue == ""){
									$rootScope.$eval( etiquetaValor + "='" + returnObj+ "'");
								}
								
					}/* END SWITCH */
					
				}
				
			}/* END FOR */
						
		};
		
		var agregaEventoCancelar = function(pathDestino){
			if( $location.$$url != pathDestino ){
				switch($location.$$url){
					case validacionPath[SECCION_PERSONALES].nombrePath: //Datos Básicos
						$rootScope.addEvent( BITACORA.SECCION.datosBasicos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.cancelar.id, $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje, BITACORA.SECCION.datosBasicos.guardarEnBD );
						break;
					case validacionPath[SECCION_HOGAR].nombrePath: //Datos del Hogar
						$rootScope.addEvent( BITACORA.SECCION.datosHogar.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.cancelar.id, $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje, BITACORA.SECCION.datosHogar.guardarEnBD );
						break;
					case validacionPath[SECCION_EMPLEO].nombrePath: //Datos del Empleo
						$rootScope.addEvent( BITACORA.SECCION.datosEmpleo.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.cancelar.id, $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje, BITACORA.SECCION.datosEmpleo.guardarEnBD );
						break;
					case validacionPath[SECCION_INGRESOS_GASTOS].nombrePath: //Gastos
						$rootScope.addEvent( BITACORA.SECCION.gastos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.cancelar.id, $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje, BITACORA.SECCION.gastos.guardarEnBD );
						break;
					case validacionPath[SECCION_REFERENCIAS].nombrePath: //Referencias
						$rootScope.addEvent( BITACORA.SECCION.referencias.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.cancelar.id, $rootScope.solicitudJson.referencias.porcentaje, BITACORA.SECCION.referencias.guardarEnBD );
						break;
					case validacionPath[SECCION_DOCUMENTOS].nombrePath: //Expediente
						$rootScope.addEvent( BITACORA.SECCION.expedientes.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.cancelar.id, $rootScope.solicitudJson.documentos.porcentaje, BITACORA.SECCION.expedientes.guardarEnBD );
						break;
					case validacionPath[SECCION_CONTRATOS].nombrePath: //Contratos
						$rootScope.addEvent( BITACORA.SECCION.contratos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.cancelar.id, $rootScope.solicitudJson.contratos.porcentaje, BITACORA.SECCION.contratos.guardarEnBD );
						break;
					default:
						break;
				}
			}
		}
		
		return service; 
				
		
	});
});