'use strict';

define(["app"], function (app) {

	app.factory("documentosService", function($rootScope, $location, endPointConfigService, REST, securityService, generalService, modalService){
		
		
		var service = {};
		
		service.digitalizar = function(digitDocRequest){	
			digitDocRequest = securityService.cifrarRsaRequest(JSON.stringify(digitDocRequest));
			
			var url = endPointConfigService.obtenerRutaEndPoint("digitalizarDocumento");                  
			return REST.callHttp(url, digitDocRequest, 'POST','application/json','application/json');	                              
		};
		
		service.actualizaComprobante = function(digitDocRequest){	
			digitDocRequest = securityService.cifrarRsaRequest(JSON.stringify(digitDocRequest));
			
			var url = endPointConfigService.obtenerRutaEndPoint("actualizaComprobante");                  
			return REST.callHttp(url, digitDocRequest, 'POST','application/json','application/json');	                              
		};

		service.getImages = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("getImagesExpediente");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		
		service.getImageBase64 = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("getImageBase64");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.contratosDigitalizados = function(solicitudJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("contratosDigitalizados");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(solicitudJson)), 'POST','application/json','application/json');	                              
		};
		
		service.getBuzonExp = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("getBuzonExp");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		
		service.validarDocumento = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("validarDocumento");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',180000);	                              
		};
		
		
		service.firmasContrato = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("firmasContrato");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.validarDocumentos = function(jsonRequest){						
			var url = endPointConfigService.obtenerRutaEndPoint("validarDocumentos");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',180000);	                              
		};
		
		service.validaContratosDigitalizados = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("validaContratosDigitalizados");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.encolarDocSimulador = function(_path, divIdIfe, fncRespIfeFrente, fncRespIfeReverso, divIdIdAvisos, fncRespAvisoPriv, fncRespBuro, tipoFormato){	
			
				if(generalService.getArrayValue('nomsImgIFE') != null){
					
					var fechaVigenciaIFE = "";
					if( generalService.getArrayValue('fechaVigenciaIFE') != null ){
						fechaVigenciaIFE = generalService.getArrayValue('fechaVigenciaIFE')
						generalService.setArrayValue("fechaVigenciaIFE",null);
					}			
					
					
					var porcentaje = 100;
					if($rootScope.solicitudJson.documentos.documento != null && $rootScope.solicitudJson.documentos.documento.length > 0)
						porcentaje = generalService.porcentajeDocs($rootScope);
					
					var documentosString = JSON.stringify($rootScope.solicitudJson.documentos);
					var documentosObj = JSON.parse(documentosString);
					documentosObj.porcentaje = porcentaje; 
					documentosObj.documento = new Array();
					
					
					documentosObj.documento.push( { idDocumento:'1',documentoDes: IDENTIFICACION_OFICIAL.descripcion,
							 status:STATUS_PENDIENTE,
							 idTipoPersona:1,idPersona:$rootScope.solicitudJson.cotizacion.clientes[0].idPersona, consecutivoPersona:0, idTipoDocumento:1, 
							 tipoDocumentoDes:"Credencial de Elector (IFE/ INE)",  fechaVigencia:fechaVigenciaIFE,
							 idMotivoRechazo:0, observacion:"", cantidad:generalService.getArrayValue('imgsIFE').length } );											
					
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					service.validarDocumentos( { idSolicitud: $rootScope.solicitudJson.idSolicitud, jsonDoc: JSON.stringify(documentosObj) } ).then(
							function(data){
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								if(data.data.codigo == RESPONSE_CODIGO_EXITO){
									var responseJson = JSON.parse(data.data.respuesta);
									if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
										$rootScope.solicitudJson = responseJson.data;																																
										$rootScope.calculaDocumentos();
										$rootScope.enviarIdentificacion(_path, tipoFormato);
									}else if(_path != null){
										generalService.locationPath(_path);
									}							
								}else if(_path != null){
									generalService.locationPath(_path);
								}
							}, function(error){
				                $rootScope.waitLoaderStatus = LOADER_HIDE;	
				                if(_path != null)
				                	generalService.locationPath(_path);
							}
						);
				}else{
					$rootScope.enviarIdentificacion(_path, tipoFormato);
				}
		};
		
		
		
		service.encolar = function(divIdIfe, fncRespIfeFrente, fncRespIfeReverso, divIdIdAvisos, fncRespAvisoPriv, fncRespBuro, _path, tipoFormato){																				
//				if(generalService.getArrayValue('nomsImgIFE') != null){
//					
//					var etiquetaFrente  = generalService.getDatafromCategory("SIMULADOR", "ETIQUETA FRENTE", "VALOR.valor" );
//					var etiquetaReverso = generalService.getDatafromCategory("SIMULADOR", "ETIQUETA REVERSO", "VALOR.valor" );
//					
//					var nomsImgIFE = generalService.getArrayValue('nomsImgIFE');
//					var imgsIFE = generalService.getArrayValue('imgsIFE');
//					var nombreCte = $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno;
//					var fotoCte = "";											
//					
//					$rootScope.enviarImagen(
//							$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
//							nomsImgIFE[0],								
//							"digitalizacion",
//							IDENTIFICACION_OFICIAL.descripcion + " " + CLIENTE.descripcion +" " + etiquetaFrente,
//							divIdIfe,
//							generalService.buildDigitDocRequest($rootScope.solicitudJson.idSolicitud, IDENTIFICACION_OFICIAL.id, 0, imgsIFE[0], nombreCte, $rootScope.fotoCteOriginal, tipoFormato),
//							fncRespIfeFrente
//						);	
//					
//					
//					$rootScope.enviarImagen(
//							$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
//							nomsImgIFE[1],								
//							"digitalizacion",
//							IDENTIFICACION_OFICIAL.descripcion + " " + CLIENTE.descripcion +" " + etiquetaReverso,
//							divIdIfe,
//							generalService.buildDigitDocRequest($rootScope.solicitudJson.idSolicitud, IDENTIFICACION_OFICIAL.id, 0, imgsIFE[1], nombreCte, $rootScope.fotoCteOriginal, tipoFormato),
//							fncRespIfeReverso
//						);										
//					
//					generalService.setArrayValue("nomsImgIFE",null);
//					generalService.setArrayValue("imgsIFE",null);																									
//				}
				
					
//				if( !generalService.isEmpty($rootScope.imgPrivacidad) && $rootScope.encolarFirmasAvisoBuro ){
//					var b64FirmaAviso = $rootScope.imgPrivacidad.replace("data:image/png;base64,","").trim();
//					
//					
//					$rootScope.enviarImagen(
//							$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
//							"",
//							DESC_FIRMA_PRIVACIDAD,
//							FIRMA_PRIVACIDAD.descripcion,
//							divIdIdAvisos,
//							{	
//								ruta: null,
//								idSolicitud: $rootScope.solicitudJson.idSolicitud,
//								cadena: b64FirmaAviso,
//								tipoCadena: "firmaAviso",
//								nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
//								foto: $rootScope.fotoCteOriginal
//							},	
//							fncRespAvisoPriv
//					);
//				}
//					
//				
//				if( !generalService.isEmpty($rootScope.imgBuro) && $rootScope.encolarFirmasAvisoBuro ){
//					var b64FirmaBuro = $rootScope.imgBuro.replace("data:image/png;base64,","").trim();					
//					
//					$rootScope.enviarImagen(
//							$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
//							"",
//							DESC_FIRMA_BURO,
//							FIRMA_BURO.descripcion,
//							divIdIdAvisos,
//							{	
//								ruta: null,
//								idSolicitud: $rootScope.solicitudJson.idSolicitud,
//								cadena: b64FirmaBuro,
//								tipoCadena: "firmaBuro",
//								nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
//								foto: $rootScope.fotoCteOriginal
//							},	
//							fncRespBuro
//					);	
//				}
				
//				if(!$rootScope.encolarFirmasAvisoBuro && !generalService.isEmpty($rootScope.imgPrivacidad)){
//					var avisoEnviado = false;
//					$rootScope.SendSignOnLine(avisoEnviado, _path);
//				}else if(!generalService.isEmpty($rootScope.imgBuro)){
//					avisoEnviado = true;
//					$rootScope.SendSignOnLine(avisoEnviado, _path);
//				}else if(_path != null){
//					generalService.locationPath(_path);
//				}

//				if(_path != null)
//					generalService.locationPath(_path);
				
//				return null;							
							    																
		};
		
		service.recuperaFirmas = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("recuperaFirma");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.convertirTifToJPG = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("convertirTifToJPG");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		return service; 
				
	});
	
});