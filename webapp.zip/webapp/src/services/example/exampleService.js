'use strict';

define(["app"], function (app) {

	app.factory("exampleService", function(endPointConfigService, REST){
		
		
		var service = {};		
		
		service.getCaptcha = function(){
			var url = endPointConfigService.obtenerRutaEndPoint("getCaptcha");			
			return REST.callHttp(url, '', 'GET','application/json','application/json');		
		};
		
		service.validaCaptcha = function(jsonObject){
			var url = endPointConfigService.obtenerRutaEndPoint("validaCaptcha");			
			return REST.callHttp(url, jsonObject, 'POST','application/json','application/json');		
		};
		
		
		service.homonimos = function(jsonObject){
			var url = endPointConfigService.obtenerRutaEndPoint("homonimos");			
			return REST.callHttp(url, jsonObject, 'POST','application/json','application/json');		
		};
		
		
		return service; 
				
	});


});