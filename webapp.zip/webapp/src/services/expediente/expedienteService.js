'use strict';

define(["app"], function (app) {
	
	app.factory("expedienteService", function($rootScope,documentosService){
	
	
		var service = {};
		
		service.resizeImage = function(w , h){	            			
			var widthPercent = 100;
			var heightPercent = 100;
			var newWidth = w;
			var newheight = h;
			
			//250 x 140 es el tamaño donde se muestra la imagen
						
			if(w > 240)
				widthPercent = (240 * 100) / w;
			
			if(h > 140)
				heightPercent = (140 * 100) / h;
			
			//sacamos el ancho y alto con el porcentahe menor
			if(widthPercent < heightPercent){
				newWidth = (widthPercent * w) / 100;
				newheight = (widthPercent * h) / 100;
				
			}else{									
				newWidth = (heightPercent * w) / 100;
				newheight = (heightPercent * h) / 100;
			}
												
			
			return {width: newWidth, height: newheight};                       
		};
		
		
		
		
		service.buildImage = function(imgB64, docId, scope,formatoDocumento){
			imgB64 = imgB64.split(",")[1];
			if(formatoDocumento != undefined && formatoDocumento == "tif"){
				var request = {base64Tif:imgB64}
	
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				documentosService.convertirTifToJPG(request).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
	
						if(data.data.codigo == 1) {
							data.data.respuesta = data.data.respuesta.split("\n").join("");
							visualizaImagenMini(data.data.respuesta, docId, scope, formatoDocumento);
						}else{
							visualizaImagenMini(imgB64, docId, scope, formatoDocumento);
						}
					}, function(error) {
					}
				);
			}else{
				visualizaImagenMini(imgB64, docId, scope, formatoDocumento);
			}
		};
		
		function visualizaImagenMini(imgB64, docId, scope, formatoDocumento){
			try{						
				var img = new Image();
				img.src = "data:image/png;base64,"+imgB64;
				
				img.onload = function(){						
										
					var wh = service.resizeImage(img.width, img.height);
					
					img.width = wh.width;
					img.height = wh.height;
										
					scope.datosDoc[docId].img1 = img.src;
					scope.datosDoc[docId].width = img.width+"px";
					scope.datosDoc[docId].height = img.height+"px";
					
					switch(docId){
						case COMP_ARRAIGO_DOMICILIARIO.id:
							scope.datosDoc[COMP_DOMICILIO.id].imgTmp.img = img.src;
							break;
						case COMP_ARRAIGO_LABORAL.id:
							scope.datosDoc[COMP_INGRESOS.id].imgTmp.img = img.src;
							break;
					}					
					
					scope.$apply();
				}																								
				
			}catch(e){
				console.log('e '+e);
				
			}
		}
		
			
		
		return service; 
				
	});
		
	

});




