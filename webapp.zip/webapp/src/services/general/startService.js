'use strict';

define(["app"], function (app) {
	app.service('startService', ['$timeout', '$rootScope', 'generalService', 'securityService', 'REST', '$q', 
		'modalService', 'endPointConfigService', 'clienteUnicoService', 'modelConfigService', 'solicitudService', 
		'loginService', function ($timeout, $rootScope, generalService, securityService, REST, $q,modalService, 
				endPointConfigService, clienteUnicoService, modelConfigService, solicitudService, loginService) {
		/* GLOBAL VARIABLES */
		var TIME_RESPONSE_WS = 80000;
		var TIME_GET_JSON = 3000;
		var cont = 0;
		var flag = false;
		var solicitudId = null;
		var banderaRefered = false;
		var ejecutaConfiguracionData;
		var QM_Data;
		
		$rootScope.consultaAbonos = {
				prestamosPersonales: [],
				preaprob  : [],
				sipa : [],
				winback : [],
				_30_30_30 : [],
				rescatePrestamo : []
				
		}
		
		var numeroIntentos = 3;
		$rootScope.contadorAbonos = {
				pp: numeroIntentos,
				preaprob  : numeroIntentos,
				sipa : numeroIntentos,
				winback : numeroIntentos,
				_30_30_30 : numeroIntentos,
				rescatePrestamo : numeroIntentos
		}
		
		function _initModelConfigurator() {
			console.log('RUN WS');

			$rootScope.flagResponseWS = false;

			if(MODEL_CATALOGOS_JSON != null || (MODEL_PP_JSON != null || MODEL_30_30_30_JSON!= null || MODEL_WINBACK_JSON!= null || MODEL_PRE_APROBADOS_JSON!= null || MODEL_RESCATE_PP_JSON!= null) || MODEL_VISTAS_JSON != null) {
				return true;	
			} else {
				var defered = $q.defer();
				var promise = defered.promise;

				$timeout(function() {
					if(configuracion.origen.tienda) {
						modelConfigService.setCatalogos();

						$rootScope.getSession('commoCtrlDivId', function(dataSession) {
							generalService.setArrayValue('ticket', dataSession.idSession);
							$rootScope.inSession = true;
							$rootScope.userSession = dataSession.datosUsuario;  
							$rootScope.sucursalSession = dataSession.datosSucursal;

							var key = generalService.keyEmpBase64();		        					           			 						    			           		
							securityService.setKeys(key, key);
							
							if($rootScope.sucursalSession != undefined || $rootScope.sucursalSession != null) {
								if($rootScope.sucursalSession.idPais != 0 && $rootScope.sucursalSession.idSucursal != 0 && $rootScope.sucursalSession.idCanal !=0){
									/**
									 * Servicio para consulta la funcionalidad por sucursal
									 * Se ejecuta cuando se recarga la pagina
									 * Se ejecuta cuando se se loguean desde cualquier Wrapper
									 * El fragmento de código "defered.resolve(true);" manda a la pantalla del simulador
									 **/
									loginService.consultaFuncionalidad({idPais: $rootScope.sucursalSession.idPais, 
										idSucursal: $rootScope.sucursalSession.idSucursal, 
										idCanal: $rootScope.sucursalSession.idCanal}).then(
										function(data) {
											if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
												var jsonresponse = JSON.parse(data.data.respuesta);
	
												if(jsonresponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
													/**
													 * En caso de exito se mapea el objeto "consultaFuncionalidad"
													 **/
													$rootScope.consultaFuncionalidad = jsonresponse.data;
																									
													if(isProduccion && !isParcial && configuracion.origen.tienda 
															&& configuracion.modo.offLine) {
														IP_SERVER = navigator.platform.toLowerCase().match("ipad") ? 
																$rootScope.consultaFuncionalidad.esquemaAmbienteIPiPad : 
																$rootScope.consultaFuncionalidad.esquemaAmbienteIPWindows;
	
														IP = "https://" + IP_SERVER + "/SolicitudCreditoWeb/";
													}
													
													banderaRefered = true;
													ejecutaConfiguracionData = data;
													QM_Data = data;
													cargarAbonosPrestamoPersonal(defered,promise,data);
												} else {
													/**
													 * En caso de error se carga una modal que indica que hubo une error
													 **/
													modalService.alertModal(ERROR_CARGA_PAGINA.titulo, 
															[ERROR_CARGA_PAGINA.texto]);
													
													defered.resolve(false);		                		
												}
											} else {
												/**
												 * En caso de error se carga una modal que indica que hubo une error
												 **/
												modalService.alertModal(ERROR_CARGA_PAGINA.titulo, 
														[ERROR_CARGA_PAGINA.texto]);
												
												defered.resolve(false);		                		
											}
										}, function(error) {		                    
											defered.resolve(false);
										}
									);
								}else{
									modalService.alertModal(ERROR_CARGA_PAGINA.titulo, 
											["Ocurrio un error con la datos de la sesión, por favor, comuniquese con Soporte."]);
									
									defered.resolve(false);	
								}
							} else {
								defered.resolve(true);	
							}					    
						});
					} else {
						loadDataApp().then(
							function(exito) { 																									
								defered.resolve(exito);
							}
						);
					}
				}, 1000);

				return promise;							
			}
		}
		/* END INIT SERVICE */

//		var deferred = $q.defer();
//		var promiser = deferred.promise;	
		function loadDataApp() {
			var defered = $q.defer();
			var promise = defered.promise;		

			REST.callHttp(endPointConfigService.obtenerRutaEndPoint("loadConfig"), null, 'POST', 'application/json', 
					'application/json', TIME_RESPONSE_WS ).then(
				function(data){ //EXITO
					if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
						if($rootScope.sucursalSession != undefined || $rootScope.sucursalSession != null) {
							/**
							 * Servicio para consulta la funcionalidad por sucursal
							 * Se ejecuta cuando se recarga la pagina
							 * Se ejecuta cuando se se loguean desde cualquier Wrapper
							 * El fragmento de código "defered.resolve(true);" manda a la pantalla del simulador
							 **/
							loginService.consultaFuncionalidad({idPais: $rootScope.sucursalSession.idPais, 
								idSucursal: $rootScope.sucursalSession.idSucursal, 
								idCanal: $rootScope.sucursalSession.idCanal}).then(
								function(objetoFuncionalidad) {
									if(objetoFuncionalidad.data.codigo == RESPONSE_CODIGO_EXITO) {
										var jsonResponseFuncionalidad = JSON.parse(objetoFuncionalidad.data.respuesta);

										if(jsonResponseFuncionalidad.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO) {
											/**
											 * En caso de exito se mapea el objeto "consultaFuncionalidad"
											 **/
											$rootScope.consultaFuncionalidad =  jsonResponseFuncionalidad.data;
											
											if(isProduccion && !isParcial && configuracion.origen.tienda 
													&& configuracion.modo.offLine) {
												IP_SERVER = navigator.platform.toLowerCase().match("ipad") ? 
														$rootScope.consultaFuncionalidad.esquemaAmbienteIPiPad : 
														$rootScope.consultaFuncionalidad.esquemaAmbienteIPWindows;

												IP = "https://" + IP_SERVER + "/SolicitudCreditoWeb/";
											}
											
											cargarAbonosPrestamoPersonal(defered,promise,data);
										} else {
											/**
											 * En caso de error, se carga la vista y se continua al Simulador
											 **/
											cargarAbonosPrestamoPersonal(defered,promise,data);
										}
									} else {
										/**
										 * En caso de error, se carga la vista y se continua al Simulador
										 **/
										cargarAbonosPrestamoPersonal(defered,promise,data);
									}
								}, function(error) {
									/**
									 * En caso de error, se carga la vista y se continua al Simulador
									 **/
									cargarAbonosPrestamoPersonal(defered,promise,data);
								}
							);
						} else {
							/**
							 * En caso de que no se tenga el objeto de la sucursal, se carga la vista 
							 * y se continúa al Simulador.
							 **/
							ejecutaConfiguracion(defered, promise, data);
						}
					} else {
						modalService.alertModal(ERROR_CARGA_PAGINA.titulo, [ERROR_CARGA_PAGINA.texto + '' + 
							data.data.descripcion]);
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						defered.resolve(false);
					}		                			                			                			                	
				}, function(error) { //ERROR
					$rootScope.waitLoaderStatus = LOADER_HIDE;		                    
					defered.resolve(false);
				}
			);

			return promise;
		};

		function ejecutaConfiguracion(deferred, promise, data) {
			generalService.calculaPorcentaje($rootScope);
			securityService.setKeys(data.headers().key, data.headers().initial_vector);
			modelConfigService.setCatalogos();
			generalService.setProduccion(data.data.respuesta.produccion);

			if(data.data.respuesta.solicitudJson != null && data.data.respuesta.solicitudJson.length > 0) {
				var responseJsonSolicitud = JSON.parse(data.data.respuesta.solicitudJson);

				if(responseJsonSolicitud.codigo == ERROR_CLIENTE_UNICO) {
					modalService.alertModal("Error", [responseJsonSolicitud.descripcion]);
				}

				$rootScope.recuperaSolicitud = true;
				generalService.buildSolicitudJson($rootScope, responseJsonSolicitud.data);

				if(data.data.respuesta.buroJson) {
					var buroJsonObj = JSON.parse(data.data.respuesta.buroJson);
					
					if(buroJsonObj.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO 
							||  buroJsonObj.codigo == BURO_RECALCULAR_PLAZO 
							|| buroJsonObj.codigo == BURO_AUTORIZADO_PORCOMPROBAR 
							|| buroJsonObj.codigo == BURO_AUTORIZADO_SCORE) {
						$rootScope.buroHandler = buroJsonObj.data.plazosTermometro;
						$rootScope.capacidadesPagoProducto = buroJsonObj.data.capacidadesPagoProducto;
						$rootScope.buroConditional = buroJsonObj.codigo;
						$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
					} else {
						$rootScope.buroHandler = [];
						$rootScope.buroConditional = -1;
						$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
					}
				} else {
					$rootScope.buroHandler = [];
					$rootScope.buroConditional = -1;
					$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
				}	                				

				if(responseJsonSolicitud.data.cotizacion.clientes[0].foto == FOTO_ENVIADA) {				                				
					$rootScope.fotoCte = "images/loading.gif";
					
					var cu = responseJsonSolicitud.data.cotizacion.clientes[0].clienteUnico;
					
					if(!generalService.isEmpty(cu)) {
						var cuArray = cu.split('-');
						var requestCU = {pais: parseInt(cuArray[0]), canal: parseInt(cuArray[1]), 
								sucursal: parseInt(cuArray[2]), folio: parseInt(cuArray[3])};
						clienteUnicoService.getFotoCU(requestCU).then(
							function(data) {     						
								if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
									var resp = JSON.parse(data.data.respuesta);
									
									if(resp.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO 
											&& !generalService.isEmpty(resp.data)) {
										$rootScope.fotoCte = "data:image/png;base64," + resp.data;
										$rootScope.fotoCteOriginal = resp.data;
									} else {
										$rootScope.fotoCte = "data:image/png;base64,"+$rootScope.imgUsuario;
									}						                	                									                	            
								}			                					                				                		                			               
							}, function(error) {  	
								$rootScope.fotoCte = "data:image/png;base64," + $rootScope.imgUsuario;
								console.log(error);	 						                    	                
							}
						);
					} else {
						clienteUnicoService.getFoto({idSolicitud: responseJsonSolicitud.data.idSolicitud}).then(
							function(data) {
								if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
									var resp = JSON.parse(data.data.respuesta);
									
									if(resp.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO 
											&& !generalService.isEmpty(resp.data)) {
										$rootScope.fotoCte = "data:image/png;base64," + resp.data;
										$rootScope.fotoCteOriginal = resp.data;
									} else {
										$rootScope.fotoCte = "data:image/png;base64," + $rootScope.imgUsuario;
									}           	                									                	            
								}
							}, function(error) {	
								$rootScope.fotoCte = "data:image/png;base64," + $rootScope.imgUsuario;
								console.log(error);
							}
						);
					}
				}
			}

			//console.log("CONFIGURATION  OK");
			deferred.resolve(true);
		}		
				
				var cargarAbonosPrestamoPersonal = function(defered,promise,data){
					
					if($rootScope.contadorAbonos.pp <= 0){
						$rootScope.message( "Aviso", ["No se pudieron obtener los abonos de Prestamos Personales correctamente"], "Aceptar","/menuWrapper");
						return null;
					}
					
					
					if($rootScope.consultaAbonos.prestamosPersonales == undefined || $rootScope.consultaAbonos.prestamosPersonales.length == 0){
						loginService.consultarAbonos({idPais:$rootScope.sucursalSession.idPais, idSucursal:$rootScope.sucursalSession.idSucursal, idCanal:$rootScope.sucursalSession.idCanal, campana:"PRESTAMO_PERSONAL", idProducto:24, periodicidad: 1, isRecompra: true  }).then(
					    		function(objetoAbonos) {
					    			if(objetoAbonos.data.codigo == RESPONSE_CODIGO_EXITO) {
					    				var jsonResponseAbonos = JSON.parse(objetoAbonos.data.respuesta);
					    				if(jsonResponseAbonos.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
					    					/**
										 * En caso de exito se mapea el objeto  continua a consultar los demas abonos
										 **/
					    					$rootScope.consultaAbonos.prestamosPersonales =  jsonResponseAbonos.data;
					    					

					    					if($rootScope.consultaAbonos.prestamosPersonales.length ==0){
					    						$rootScope.contadorAbonos.pp --; 
					    						cargarAbonosPrestamoPersonal(defered,promise,data);
					    					}else{
					    					invocarAbonos(defered,promise,data);
					    					defered.resolve(true);
					    					}
					    				}else{
					    					/**
										 * En caso de error, se continua al Simulador
										 **/
					    					$rootScope.contadorAbonos.pp --;
					    					cargarAbonosPrestamoPersonal(defered,promise,data);
					    				}
					    			}else{
					    				/**
									 * En caso de error, se continua al Simulador
									 **/
					    				$rootScope.contadorAbonos.pp --;
					    				cargarAbonosPrestamoPersonal(defered,promise,data);
					    		    }
					    		}, function(error) {
					    			/**
								 * En caso de error, se continua al Simulador
								 **/
					    			$rootScope.contadorAbonos.pp --;
					    			cargarAbonosPrestamoPersonal(defered,promise,data);
					    		}
					    );
					}else{
						invocarAbonos(defered,promise,data);
					}
					
				}
				
				
				var invocarAbonos = function(defered,promise,data){
					cargarAbonosPreaprob(defered,promise,data);
					cargarAbonosSIPA(defered,promise,data);
					cargarAbonosWinback(defered,promise,data);
					//cargarAbonos30_30_30();
					cargarAbonosRescate(defered,promise,data);
				}
				var cargarAbonosPreaprob = function(defered,promise,data){
						
						if($rootScope.contadorAbonos.preaprob <= 0){
							$rootScope.message( "Aviso", ["No se pudieron obtener los abonos de Preaprobados correctamente"], "Aceptar");
							return null;
						}
						
						if($rootScope.consultaAbonos.preaprob == undefined || $rootScope.consultaAbonos.preaprob.length == 0){
							loginService.consultarAbonos({idPais:$rootScope.sucursalSession.idPais, idSucursal:$rootScope.sucursalSession.idSucursal , idCanal:1, campana:"PREAPROB", idProducto:24, periodicidad: 1, isRecompra: false  }).then(
						    		function(objetoAbonos) {
						    			if(objetoAbonos.data.codigo == RESPONSE_CODIGO_EXITO) {
						    				var jsonResponseAbonos = JSON.parse(objetoAbonos.data.respuesta);
						    				if(jsonResponseAbonos.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
						    					/**
											 * 
											 **/
						    					$rootScope.consultaAbonos.preaprob =  jsonResponseAbonos.data;
						    					if($rootScope.consultaAbonos.preaprob.length == 0){
						    						$rootScope.contadorAbonos.preaprob --; 
						    						cargarAbonosPreaprob(defered,promise,data);
					    						}
//						    					if($rootScope.consultaAbonos.preaprob.length > 0){
//						    						cargarAbonosSIPA(defered,promise,data);
//						    					}
//						    					else{
//						    						$rootScope.contadorAbonos.preaprob --; 
//						    						cargarAbonosPreaprob(defered,promise,data);
//						    					}
						    				}else{
						    					/**
											 * En caso de error, se continua al Simulador
											 **/
						    					$rootScope.contadorAbonos.preaprob --; 
						    					cargarAbonosPreaprob(defered,promise,data);
						    				}
						    			}else{
						    				/**
										 * En caso de error, se continua al Simulador
										 **/
						    				$rootScope.contadorAbonos.preaprob--;
						    				cargarAbonosPreaprob(defered,promise,data);
						    		    }
						    		}, function(error) {
						    			/**
									 * En caso de error, se continua al Simulador
									 **/
						    			$rootScope.contadorAbonos.preaprob--;
						    			cargarAbonosPreaprob(defered,promise,data);
						    		}
						    );
						}
					}
					
					var cargarAbonosSIPA = function(defered,promise,data){
						
						if($rootScope.contadorAbonos.sipa <= 0){
							$rootScope.message( "Aviso", ["No se pudieron obtener los abonos de SIPA correctamente"], "Aceptar");
							return null;
						}
						if($rootScope.consultaAbonos.sipa == undefined  || $rootScope.consultaAbonos.sipa.length == 0){
							loginService.consultarAbonos({idPais:$rootScope.sucursalSession.idPais, idSucursal:$rootScope.sucursalSession.idSucursal , idCanal:1, campana:"SIPA", idProducto:24, periodicidad: 1, isRecompra: false  }).then(
						    		function(objetoAbonos) {
						    			if(objetoAbonos.data.codigo == RESPONSE_CODIGO_EXITO) {
						    				var jsonResponseAbonos = JSON.parse(objetoAbonos.data.respuesta);
						    				if(jsonResponseAbonos.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
						    					/**
											 * En caso de exito se mapea el objeto "consultaFuncionalidad" y continua al Simulador
											 **/
						    					$rootScope.consultaAbonos.sipa =  jsonResponseAbonos.data;
						    					if($rootScope.consultaAbonos.sipa.length == 0){
						    						$rootScope.contadorAbonos.sipa --; 
						    						cargarAbonosSIPA(defered,promise,data);
						    					}
//						    					if($rootScope.consultaAbonos.sipa.length > 0){
//						    						cargarAbonosWinback(defered,promise,data);
//						    					}
//						    					else{
//						    						$rootScope.contadorAbonos.sipa --; 
//						    						cargarAbonosSIPA(defered,promise,data);
//						    					}
						    				}else{
						    					/**
											 * En caso de error, se continua al Simulador
											 **/
						    					$rootScope.contadorAbonos.sipa--;
						    					cargarAbonosSIPA(defered,promise,data);
						    				}
						    			}else{
						    				/**
										 * En caso de error, se continua al Simulador
										 **/
						    				$rootScope.contadorAbonos.sipa--;
						    				cargarAbonosSIPA(defered,promise,data);
						    		    }
						    		}, function(error) {
						    			/**
									 * En caso de error, se continua al Simulador
									 **/
						    			$rootScope.contadorAbonos.sipa--;
						    			cargarAbonosSIPA(defered,promise,data);
						    		}
						    );
						}
					}
					
					
					var cargarAbonosWinback = function(defered,promise,data){
						
						if($rootScope.contadorAbonos.winback <= 0){
							$rootScope.message( "Aviso", ["No se pudieron obtener los abonos de Winback correctamente"], "Aceptar");
							return null;
						}
						
						if($rootScope.consultaAbonos.winback == undefined  || $rootScope.consultaAbonos.winback.length == 0){
							loginService.consultarAbonos({idPais:$rootScope.sucursalSession.idPais, idSucursal:$rootScope.sucursalSession.idSucursal , idCanal:1, campana:"WINBACK", idProducto:24, periodicidad: 1, isRecompra: false  }).then(
						    		function(objetoAbonos) {
						    			if(objetoAbonos.data.codigo == RESPONSE_CODIGO_EXITO) {
						    				var jsonResponseAbonos = JSON.parse(objetoAbonos.data.respuesta);
											
						    				if(jsonResponseAbonos.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
						    					/**
											 * En caso de exito se mapea el objeto "consultaFuncionalidad" y continua al Simulador
											 **/
						    					$rootScope.consultaAbonos.winback =  jsonResponseAbonos.data;
						    					
						    					if($rootScope.consultaAbonos.winback.length == 0){
						    						$rootScope.contadorAbonos.winback --; 
						    						cargarAbonosWinback(defered,promise,data);
						    					}
						    					
//						    					if($rootScope.consultaAbonos.winback.length > 0){
//						    						cargarAbonos30_30_30(defered,promise,data);
//						    					}
//						    					else{
//						    						$rootScope.contadorAbonos.winback --; 
//						    						cargarAbonosWinback(defered,promise,data);
//						    					}
						    				}else{
						    					/**
											 * En caso de error, se continua al Simulador
											 **/
						    					$rootScope.contadorAbonos.winback --;
						    					cargarAbonosWinback(defered,promise,data);
						    				}
						    			}else{
						    				/**
										 * En caso de error, se continua al Simulador
										 **/
						    				$rootScope.contadorAbonos.winback --;
						    				cargarAbonosWinback(defered,promise,data);
						    		    }
						    		}, function(error) {
						    			/**
									 * En caso de error, se continua al Simulador
									 **/
						    			$rootScope.contadorAbonos.winback --;
						    			cargarAbonosWinback(defered,promise,data);
						    		}
						    );
						}
					}
					
					
					var cargarAbonos30_30_30 = function(defered,promise,data){
						if($rootScope.contadorAbonos._30_30_30 <= 0){
							$rootScope.message( "Aviso", ["No se pudieron obtener los abonos de 30 30 30 correctamente"], "Aceptar");
							return null;
						}
						
						if($rootScope.consultaAbonos._30_30_30 == undefined || $rootScope.consultaAbonos._30_30_30.length == 0){
							loginService.consultarAbonos({idPais:$rootScope.sucursalSession.idPais, idSucursal:$rootScope.sucursalSession.idSucursal , idCanal:1, campana:"30_30_30", idProducto:24, periodicidad: 1, isRecompra: false  }).then(
						    		function(objetoAbonos) {
						    			if(objetoAbonos.data.codigo == RESPONSE_CODIGO_EXITO) {
						    				var jsonResponseAbonos = JSON.parse(objetoAbonos.data.respuesta);
						    				if(jsonResponseAbonos.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
						    					/**
											 * En caso de exito se mapea el objeto "consultaFuncionalidad" y continua al Simulador
											 **/
						    					$rootScope.consultaAbonos._30_30_30 =  jsonResponseAbonos.data;
						    					if($rootScope.consultaAbonos._30_30_30.length == 0){
						    						$rootScope.contadorAbonos._30_30_30 --; 
						    						cargarAbonos30_30_30(defered,promise,data);
						    					}
						    					
//						    					if($rootScope.consultaAbonos._30_30_30.length > 0){
//						    						cargarAbonosRescate(defered,promise,data);
//						    					}
//						    					else{
//						    						$rootScope.contadorAbonos._30_30_30 --; 
//						    						cargarAbonos30_30_30(defered,promise,data);
//						    					}
						    					
						    				}else{
						    					/**
											 * En caso de error, se continua al Simulador
											 **/
						    					$rootScope.contadorAbonos._30_30_30 --; 
						    					cargarAbonos30_30_30(defered,promise,data);
						    				}
						    			}else{
						    				/**
										 * En caso de error, se continua al Simulador
										 **/
						    				$rootScope.contadorAbonos._30_30_30 --; 
						    				cargarAbonos30_30_30(defered,promise,data);
						    		    }
						    		}, function(error) {
						    			/**
									 * En caso de error, se continua al Simulador
									 **/
						    			$rootScope.contadorAbonos._30_30_30 --; 
						    			cargarAbonos30_30_30(defered,promise,data);
						    		}
						    );
						}
					}
					
					
					var cargarAbonosRescate = function(defered,promise,data){
						if($rootScope.consultaFuncionalidad.habilitarPDRCreditoEnEfectivo){
							if($rootScope.contadorAbonos.rescatePrestamo <= 0){
								$rootScope.message( "Aviso", ["No se pudieron obtener los abonos de Rescate correctamente"], "Aceptar");
								return null;
							}
							
							if($rootScope.consultaAbonos.rescatePrestamo == undefined || $rootScope.consultaAbonos.rescatePrestamo.length == 0){
								loginService.consultarAbonos({idPais:$rootScope.sucursalSession.idPais, idSucursal:$rootScope.sucursalSession.idSucursal , idCanal:1, campana:"RESCATE_PRESTAMO", idProducto:24, periodicidad: 1, isRecompra: false  }).then(
										function(objetoAbonos) {
											if(objetoAbonos.data.codigo == RESPONSE_CODIGO_EXITO) {
												var jsonResponseAbonos = JSON.parse(objetoAbonos.data.respuesta);
												if(jsonResponseAbonos.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
													/**
													 * En caso de exito se mapea el objeto "consultaFuncionalidad" y continua al Simulador
													 **/
													$rootScope.consultaAbonos.rescatePrestamo =  jsonResponseAbonos.data;
													
													if($rootScope.consultaAbonos.rescatePrestamo.length ==0){
														$rootScope.contadorAbonos.rescatePrestamo --; 
														cargarAbonosRescate(defered,promise,data);
													}
													
												}else{
													/**
													 * En caso de error, se continua al Simulador
													 **/
													$rootScope.contadorAbonos.rescatePrestamo --;
													cargarAbonosRescate(defered,promise,data);
												}
											}else{
												/**
												 * En caso de error, se continua al Simulador
												 **/
												$rootScope.contadorAbonos.rescatePrestamo --;
												cargarAbonosRescate(defered,promise,data);
											}
										}, function(error) {
											/**
											 * En caso de error, se continua al Simulador
											 **/
											$rootScope.contadorAbonos.rescatePrestamo --;
											cargarAbonosRescate(defered,promise,data);
										}
								);
							}
						}
					}		


		return {
			initModelConfigurator: _initModelConfigurator
		};
	}]);
});
