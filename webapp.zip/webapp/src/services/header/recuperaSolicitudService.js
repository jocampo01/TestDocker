'use strict';

define(["app"], function (app) {
	
	app.factory("recuperaSolicitudService", function($q, solicitudService,generalService, clienteUnicoService, modalService, $rootScope, buroService){
	
	
		var service = {};
		
		service.loadSolicitud=function (solicitudId, recuperasolicitud, rootScope, datos){		
			service.reiniciaBanderas();
			var defered = $q.defer();
			var promise = defered.promise;
			generalService.buildSolicitudJson($rootScope, null);
			//if(recuperasolicitud.continar){							
			
				solicitudService.loadSolicitud(solicitudId).then(
						
						function(data){ //EXITO
																									                			                			                			              
			                	if(data.data.codigo == RESPONSE_CODIGO_EXITO){
			    		                		
			                		var _jsonSolicitud = null;
			                		generalService.calculaPorcentaje(rootScope);
			                				                				          			                	
			                		
			                		if(data.data.respuesta.solicitudJson != null && data.data.respuesta.solicitudJson.length > 0){
 
			                			var responseJsonSolicitud = JSON.parse( data.data.respuesta.solicitudJson );
			                						                				
			                			
			                			if(responseJsonSolicitud.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO || 
			                			   responseJsonSolicitud.codigo == BLOQUEADO ||
			                			   responseJsonSolicitud.codigo == OFERTA_30_DIAS ||
			                			   responseJsonSolicitud.codigo == RESPONSE_CODIGO_ERROR_GENERA_CU
			                			   ){
			                				if(rootScope.sucursalSession){
				                				if(rootScope.sucursalSession.estado){
				                					responseJsonSolicitud.data.lugarOriginacion = (rootScope.sucursalSession.estado == "Distrito Federal")?"Ciudad de México":rootScope.sucursalSession.estado;
				                				}else{
				                					responseJsonSolicitud.data.lugarOriginacion = ""
				                				}
				                			}else{
				                				responseJsonSolicitud.data.lugarOriginacion = ""
				                			}
				                			
				                			if( responseJsonSolicitud.codigo == ERROR_CLIENTE_UNICO ){
//				                				modalService.alertModal( "Error", [responseJsonSolicitud.descripcion] );
				                				
				                			}else if( responseJsonSolicitud.codigo == BLOQUEADO ){			                																									
//				                				modalService.alertModal( "Aviso", ["No es posible continuar con la solicitud ya la LCR se encuentra bloqueada."] );
				                				rootScope.NombreFicha = datos.primerNombre == undefined?datos.nombre:datos.primerNombre;
				                				rootScope.maternoFicha = datos.apellidoMaterno;
				                				rootScope.paternoFicha = datos.apellidoPaterno;
				                				
				                				/**
												*REQ 85337 Se guardan datos para poder recuperar la solicitud en la ficha
												*/
				                				rootScope.clienteUnicoFicha = datos.cu;
				                				rootScope.idSolicitudFicha = datos.idSolicitud;
				                				
				                				generalService.setArrayValue("datosFicha", responseJsonSolicitud.data);
				                				defered.resolve(BLOQUEADO);
				                				return false;
				                			}else if(responseJsonSolicitud.codigo == OFERTA_30_DIAS){/*OFERTA 30 DIAS*/
				              // I-MODIFICACION TDC
				                				if(!$rootScope.productosTarjetas(responseJsonSolicitud.data.idProducto)){
			                						responseJsonSolicitud.data.marca = STATUS_SOLICITUD.autorizada.marca.pendienteDigitalizar;
			                					}
			                 // I-MODIFICACION TDC
				                			}
				                			
				                			rootScope.recuperaSolicitud=true;
				                			generalService.buildSolicitudJson(rootScope, responseJsonSolicitud.data  );
				                			
				    						if( (rootScope.solicitudJson.idSeguimiento != STATUS_SOLICITUD.autorizada.id || rootScope.solicitudJson.idSeguimiento != STATUS_SOLICITUD.preautorizada.id) 
				    								&& rootScope.solicitudJson.marca != STATUS_SOLICITUD.autorizada.marca.sinLiberar )
				    							rootScope.onceOfert = true;	
				    						
				    						var continuar=true;
				    						
				    						if((rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.generada.id || rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id) &&
						                	   (rootScope.solicitudJson.consultaBuro == 0 || rootScope.solicitudJson.consultaMatriz == 0))
						                		rootScope.recuperaSolicitudBuro=true;
				    						
				                			if( !rootScope.recuperaSolicitudBuro && data.data.respuesta.buroJson ){
				                				var buroJsonObj = JSON.parse( data.data.respuesta.buroJson );
				                				
				                				if( buroJsonObj.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ||  buroJsonObj.codigo == BURO_RECALCULAR_PLAZO ||  
				                					buroJsonObj.codigo == BURO_AUTORIZADO_PORCOMPROBAR || buroJsonObj.codigo == BURO_AUTORIZADO_SCORE ){
				                					
				                					if(buroJsonObj.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO && buroJsonObj.data.solicitud != null)
				                						rootScope.solicitudJson=buroJsonObj.data.solicitud;
				                					rootScope.buroHandler = buroJsonObj.data.plazosTermometro;
				                					rootScope.capacidadesPagoProducto = buroJsonObj.data.capacidadesPagoProducto;
				                					if(generalService.sobrescribeOfertaBuroConsumo(rootScope.solicitudJson))			         
				                						rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO;
				                					else
				                						rootScope.buroConditional = buroJsonObj.codigo;
				                					if(buroJsonObj.codigo==570 && rootScope.solicitudJson.idProducto!=24){
				                						rootScope.buroConditional = 2;
				                					}
					                				rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
					                				
				                									                				
				                				}else{
				                					if(buroJsonObj.codigo == ERROR_BURO_RECHAZADA){
				                						buroService.productosAutorizados(buroJsonObj.data,buroJsonObj.descripcion);
				                						continuar=false;
				                					}else{
					                					rootScope.buroHandler = [];
						                				rootScope.buroConditional = -1;
						                				rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
				                					}
				                				}
				                							                							                							                				
				                				
				                			}else{
				                				if(!rootScope.recuperaSolicitudBuro){
					                				rootScope.buroHandler = [];
					                				rootScope.buroConditional = -1;
					                				rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
				                				}
				                			}			                				
				                			
				                			if(continuar){
					                			rootScope.historicoMarcas = null;
					                			if(data.data.respuesta.historicoMarcas){
					                				var j = JSON.parse(data.data.respuesta.historicoMarcas);
					                				if(j.data[0].codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
					                					rootScope.historicoMarcas=[];
					                					for(var i=0;i<j.data[0].data.length;i++){
					                						rootScope.historicoMarcas[i]=j.data[0].data[i].marca;
					                					}
					                				}
					                				service.cargaBanderas();
					                			}
					                			
					                			if(data.data.respuesta.seccionGuardadito != null){
					                				var responseGuardadito = JSON.parse(data.data.respuesta.seccionGuardadito);
					                				if(responseGuardadito.codigo == 2){
					                					if(responseGuardadito.data.noIntentos < 2 && responseGuardadito.data.reintentar){
					                						continuar=false;
					                						$rootScope.aperturaCaptacion = {numeroIntentos: responseGuardadito.data.noIntentos};
					                						$rootScope.ejecutarPortalCaptacion(rootScope.solicitudJson.idPais,rootScope.solicitudJson.idCanal,rootScope.solicitudJson.idSucursal,rootScope.solicitudJson.idSolicitud,rootScope.solicitudJson.idSeguimiento);
					                					}else
					                						$rootScope.sinGuardadito=true;
						                			}else{
						                				if(responseGuardadito.codigo == 954){
						                					continuar=false;
						                					$rootScope.aperturaCaptacion = {numeroIntentos: 0};
						                					$rootScope.ejecutarPortalCaptacion(rootScope.solicitudJson.idPais,rootScope.solicitudJson.idCanal,rootScope.solicitudJson.idSucursal,rootScope.solicitudJson.idSolicitud,rootScope.solicitudJson.idSeguimiento);
						                				}else
						                					$rootScope.sinGuardadito=true;
						                			}
					                			}
					                			
					                			if(continuar){
						                			if( responseJsonSolicitud.data.cotizacion.clientes[0].foto == FOTO_ENVIADA  ){				                				
						                				rootScope.fotoCte = "images/loading.gif";
						                				
						                				var cu = responseJsonSolicitud.data.cotizacion.clientes[0].clienteUnico;
						                				if( !generalService.isEmpty(cu) ){
						                					
						                					var cuArray = cu.split('-');
						                					var requestCU = {pais:parseInt(cuArray[0]), canal:parseInt(cuArray[1]), sucursal:parseInt(cuArray[2]), folio:parseInt(cuArray[3]) };
						                					clienteUnicoService.getFotoCU( requestCU ).then(
								                					function(data){ 		                						
								                	                	if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								                	                		var resp = JSON.parse(data.data.respuesta)
								                	                		
								                	                		var json = {
									                								"requestCU": requestCU,
									                			    				"Peticion": resp
									                						};
								                	                		
								                	                		$rootScope.loggerServicios("getFotoCU", json);
									                						
								                	                		if( resp.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO && !generalService.isEmpty(resp.data)){
								                	                			rootScope.fotoCte = "data:image/png;base64,"+resp.data;
								                	                			rootScope.fotoCteOriginal=resp.data;
								                	                		}else						                	                									                	            
								                	                			rootScope.fotoCte = "data:image/png;base64,"+rootScope.imgUsuario;
								                	                	}	                			                		                				                					                				                		                			               
								                    				}, function(error){  	
								                    					rootScope.fotoCte = "data:image/png;base64,"+rootScope.imgUsuario;
								                    	                console.log(error);	 						                    	                
								                    				}
								                			);
						                					
						                					
						                				}else{
						                					
						                					clienteUnicoService.getFoto( { idSolicitud: responseJsonSolicitud.data.idSolicitud } ).then(
								                					function(data){					                											                										                									                						
								                						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								                							var resp = JSON.parse(data.data.respuesta);
								                							
								                							var json = {
									                								"Solicitud": responseJsonSolicitud.data.idSolicitud,
									                			    				"Peticion": resp
									                						};
								                							$rootScope.loggerServicios("getFoto", json);
								                							
								                							if( resp.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO && !generalService.isEmpty(resp.data)){
								                	                			rootScope.fotoCte = "data:image/png;base64,"+resp.data;
								                	                			rootScope.fotoCteOriginal=resp.data;
								                							}else						                	                									                	            
								                	                			rootScope.fotoCte = "data:image/png;base64,"+rootScope.imgUsuario;
								                							
								                						}
								                						
								                					}, function(error){	
								                						rootScope.fotoCte = "data:image/png;base64,"+rootScope.imgUsuario;
								                						console.log(error);
								                					}
								                				);
						                				}
						                								                				
						                			}
						                			
						                			rootScope.nombreCamel=generalService.camelize(rootScope.solicitudJson.cotizacion.clientes[0].nombre);
						                			rootScope.apellidoPaternoCamel=generalService.camelize(rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno);
						                			rootScope.apellidoMaternoCamel=generalService.camelize(rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno);
						                			
						                			if( recuperasolicitud.path!=null  &&  recuperasolicitud.path == "/simulador"){
						                				generalService.buildSolicitudJson(rootScope, null );
						                				try{
						                					generalService.setArrayValue("solicitudRecuperada", true);
							                				rootScope.solicitudJson.cotizacion.clientes[0].nombre = responseJsonSolicitud.data.cotizacion.clientes[0].nombre;
							                				rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno = responseJsonSolicitud.data.cotizacion.clientes[0].apellidoPaterno;
							                				rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno = responseJsonSolicitud.data.cotizacion.clientes[0].apellidoMaterno;			                							                			
							                				rootScope.solicitudJson.cotizacion.clientes[0].idGenero = responseJsonSolicitud.data.cotizacion.clientes[0].idGenero;
							        	 					rootScope.solicitudJson.cotizacion.clientes[0].genero = responseJsonSolicitud.data.cotizacion.clientes[0].genero;			        	 					
							        	 					rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento = responseJsonSolicitud.data.cotizacion.clientes[0].fechaNaciomiento;
							        	 					rootScope.solicitudJson.cotizacion.clientes[0].celular = responseJsonSolicitud.data.cotizacion.clientes[0].celular;
						                				}catch(e){ }
						                			}
						                			
						                			//service.goPath(rootScope.solicitudJson, recuperasolicitud.path, rootScope);
						                			defered.resolve(true);
					                			}
				                			}
			                				
			                			}else if(responseJsonSolicitud.codigo == SOLICITUD_EN_PROCESO_DE_ACTUALIZACION){//Solicitud se encuentra en proceso de actualizacion de datos
			                				defered.resolve(SOLICITUD_EN_PROCESO_DE_ACTUALIZACION);
			                			}else if(responseJsonSolicitud.codigo == RESPONSE_CODIGO_ERROR_ID){
			                				defered.resolve(RESPONSE_CODIGO_ERROR_ID);
			                			}else if(responseJsonSolicitud.codigo == RESPONSE_CODIGO_ERROR_BAZ_DIGITAL){
			                				defered.resolve(RESPONSE_CODIGO_ERROR_BAZ_DIGITAL);
			                			}else if(responseJsonSolicitud.codigo == RESPONSE_CODIGO_SOL_RECHAZADA){/** Si la solicitud está rechazada **/
			                				$rootScope.solicitudJson = responseJsonSolicitud.data
			                				defered.resolve(137);
			                			}else{
			                				defered.resolve(RESPONSE_CODIGO_ERROR_GENERAL);
			                			}
			                		}else
			                			defered.resolve(false);
			                			//service.goPath(null, null, rootScope);
			                		
			                	}else{
			                		modalService.alertModal(ERROR_CARGA_PAGINA.titulo, [ERROR_CARGA_PAGINA.texto +''+ data.data.descripcion]);
			                		rootScope.waitLoaderStatus = LOADER_HIDE;
	
								}		                			                			                			                	
			                	
			                	
						}, function(error){ 
							rootScope.waitLoaderStatus = LOADER_HIDE;
			                    console.error(error);
			                    
			                    if(error.status != undefined && error.status == 0){
			                    	if(error.config.timeout == HTTPCODE_TIMEOUT)
			                    		modalService.alertModal(ERROR_TIME_OUT.titulo, [ERROR_TIME_OUT.texto]);
			                    	else
			                    		modalService.alertModal("Error en el servidor "+ error.status , [error.statusText]);
			                    	
			                    }else if(error.message != undefined)
			                    	modalService.alertModal("Error en el servidor", [error.message]);
			                    
			                    defered.reject(false);
						}
						
					);
				
//			}else{							
//				if(recuperasolicitud.path == "huella")
//					rootScope.verificarHuella( 'fondoDivId', function(response){
//						try{
//							
//							if(response.codigo == 0 && response.matches.length > 0){							
//								solicitudService.generaSolicRechazada( {idSolicitud:solicitudId} );														
//								
//							}else{
//								rootScope.waitLoaderStatus = LOADER_HIDE;
//								
//								generalService.setArrayValue("pasoCallCenter", 'init')
//								generalService.setArrayValue("encolarImagenes", false);
//								generalService.locationPath("/callCenter");												
//								
//							}
//								
//						}catch(e){
//							rootScope.waitLoaderStatus = LOADER_HIDE;				
//							rootScope.message( "Error al verificar la huella Simulador", [e], "Aceptar", null, null, null, null, "GENERAL", "EXCEPCION COMPONENTE");
//						}		
//					}, 					
//					[x.cu]);
//				else
//					service.goPath(null, null,rootScope);
//			}
			
			return promise;
			
		};
		
		service.cargaBanderas = function(){
			$rootScope.categoriaLinea = {linea: 0,lineaDes: "",subLinea: 0,subLineaDes: "",montoDeseado: ""};
			$rootScope.nuevoFlujoLiberacion = generalService.consultaHistoricoMarcas([MARCAS_SOLICITUD.nuevoFlujoLiberacion])!=0?true:false;
			$rootScope.marcaDiaDePagoSeleccionado = generalService.consultaHistoricoMarcas([STATUS_SOLICITUD.generada.marca.diaDePagoSeleccionado])!=0?true:false;
			$rootScope.marcaTipoDispersionSeleccionado = generalService.consultaHistoricoMarcas([STATUS_SOLICITUD.autorizada.marca.tipoDispersionSeleccionado])!=0?true:false;
			$rootScope.requiereCambioDomiclioConvivencia = generalService.consultaHistoricoMarcas([MARCAS_SOLICITUD.requiereCambioDomiclioConvivencia])!=0?true:false;
			$rootScope.flujoSinTAZ = generalService.consultaHistoricoMarcas([93,103,104,114,117,5026,5027,118,120,121,122,123,124,125,126,127,128,129,136,150,151,5029,5030,5031])!=0?true:false;
			$rootScope.liberacionflujoJV = generalService.consultaHistoricoMarcas([MARCAS_SOLICITUD.diadePago])!=0?true:false;
			$rootScope.sinObligadoSolidario = generalService.consultaHistoricoMarcas([STATUS_SOLICITUD.generada.marca.clienteAceptoProductoCosumoSinOS, STATUS_SOLICITUD.generada.marca.prodResPrestamoConGarantias])!=0?true:false;
			$rootScope.rescatePPGarantias = generalService.consultaHistoricoMarcas([150])!=0?true:false;
			$rootScope.rescatePPObligado = generalService.consultaHistoricoMarcas([151])!=0?true:false;
			$rootScope.requiereObligado = generalService.consultaHistoricoMarcas([1057])!=0?true:false;
			$rootScope.rescatePP = generalService.consultaHistoricoMarcas([117,5026,5027])!=0?true:false;
			$rootScope.rescatePPFaseI = generalService.consultaHistoricoMarcas([117])!=0?true:false;
			$rootScope.rescatePPFaseII = generalService.consultaHistoricoMarcas([5026])!=0?true:false;
			$rootScope.rescateFaseIII = generalService.consultaHistoricoMarcas([5029,5030,5031])!=0?true:false;
			$rootScope.isFirmaUnica = (generalService.consultaHistoricoMarcas([STATUS_SOLICITUD.generada.marca.firmaUnica]) != 0)?true:false;
			$rootScope.banderaCoacreditado = true;
			$rootScope.mostrarSeccionTAZ = true;
			$rootScope.esSolicitudRescate = generalService.consultaHistoricoMarcas([43,93,103,104,114,117,5026,5027,118,120,121,122,123,124,125,126,127,128,129,136,150,151,5029,5030,5031,1057])!=0?true:false;
			$rootScope.aperturarGuardadito = generalService.consultaHistoricoMarcas([MARCAS_SOLICITUD.aperturarGuardadito.solicitudApta])!=0?true:false;
			$rootScope.sinGuardadito = $rootScope.aperturarGuardadito && generalService.consultaHistoricoMarcas([MARCAS_SOLICITUD.aperturarGuardadito.clienteNoPudo,MARCAS_SOLICITUD.aperturarGuardadito.clienteNoAcepto])!=0?true:false;
			$rootScope.habilitarConsultaCuentas = $rootScope.aperturarGuardadito && generalService.consultaHistoricoMarcas([MARCAS_SOLICITUD.aperturarGuardadito.clienteNoApto])==0?true:false;
			$rootScope.habilitarGuardadito = $rootScope.aperturarGuardadito && $rootScope.solicitudJson.idSeguimiento != STATUS_SOLICITUD.malZonificada.id && $rootScope.solicitudJson.idSeguimiento != STATUS_SOLICITUD.reprogramada.id && generalService.consultaHistoricoMarcas([MARCAS_SOLICITUD.aperturarGuardadito.clienteConCuenta,MARCAS_SOLICITUD.aperturarGuardadito.clienteLogro])!=0 && generalService.consultaHistoricoMarcas([MARCAS_SOLICITUD.aperturarGuardadito.clienteNoApto])==0?true:false;
			$rootScope.ineSinCalle = generalService.consultaHistoricoMarcas([1078])!=0?true:false;
			$rootScope.preaprobadoEncontradoBD = generalService.consultaHistoricoMarcas([1081])!=0?1:generalService.consultaHistoricoMarcas([1082])!=0?2:0;
			$rootScope.ejecutarEncuentaPreaprobado = generalService.consultaHistoricoMarcas([1080])!=0?false:true;
		};
		
		service.reiniciaBanderas = function(){
			$rootScope.categoriaLinea = {linea: 0,lineaDes: "",subLinea: 0,subLineaDes: "",montoDeseado: ""};
			$rootScope.historicoMarcas = null;
			$rootScope.historicoMarcasOS = null;
			$rootScope.banderaCoacreditado = true;
			$rootScope.nuevoFlujoLiberacion = false;
			$rootScope.marcaDiaDePagoSeleccionado=false;
			$rootScope.marcaTipoDispersionSeleccionado=false;
			$rootScope.requiereCambioDomiclioConvivencia=false;
			$rootScope.flujoSinTAZ=false;
			$rootScope.liberacionflujoJV = false;
			$rootScope.sinObligadoSolidario = false;
			$rootScope.rescatePPGarantias = false;
			$rootScope.rescatePPObligado = false;
			$rootScope.requiereObligado = false;
			$rootScope.rescatePP = false;
			$rootScope.rescatePPFaseI = false;
			$rootScope.rescatePPFaseII = false;
			$rootScope.rescateFaseIII = false;
			$rootScope.recuperaSolicitudBuro=false;
			$rootScope.actualizoCotizacion=true;
			$rootScope.armaJsonCotizacion();
			$rootScope.esSolicitudRescate = false;
			$rootScope.aperturarGuardadito = false;
			$rootScope.sinGuardadito = false;
			$rootScope.habilitarConsultaCuentas = false;
			$rootScope.habilitarGuardadito = false;
			$rootScope.ineSinCalle = false;
			$rootScope.preaprobadoEncontradoBD = 0;
			$rootScope.seEjecutoLiberacionLCR = false;
			$rootScope.ejecutarEncuentaPreaprobado = true;
		};
		
		
//		service.goPath=function(solicitudJson, path, rootScope){
//			rootScope.waitLoaderStatus = LOADER_HIDE;			
//									
//			
//			if( generalService.isEmpty(path) ){				
//				
//																									
//				if( generalService.existeSolicitud(solicitudJson) ){
//										
//					if(  solicitudJson.cotizacion.clientes[0].clienteUnico == "" )		
//						generalService.locationPath(generalService.getPathSection(solicitudJson,rootScope.sucursalSession.idCanal));																												
//						
//					else
//						generalService.locationPath("/simulador");
//						
//						
//				}else if(rootScope.urlAnterior != "#/avisos"){
//					generalService.buildSolicitudJson(rootScope, null);
//					generalService.locationPath("/simulador");
//				
//				}else
//					generalService.locationPath("/simulador");
//																																											
//			}else				
//				generalService.locationPath(path);																		
//			
//		};
				
		return service; 
				
	});
		
	

});




