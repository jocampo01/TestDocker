'use strict';

define(["app"], function (app) {

	app.factory("italikaService", function(endPointConfigService, REST, securityService){
		
		
		var service = {};
				
		
		service.consultaItalika = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("consultaItalika");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.consultaProductosItalika = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("consultaProductosItalika");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.getTasaItalika = function(){				
			var url = endPointConfigService.obtenerRutaEndPoint("getTasaItalika");                  
			return REST.callHttp(url, "", 'GET','application/json','application/json');	                              
		};
		
		service.getProductoPorNombreItalika = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("getProductoPorNombreItalika");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
				
		
		return service; 
				
	});
	
});