'use strict';

define(["app"], function (app) {
	
	
	app.factory("loginService", function(endPointConfigService, REST, securityService){
		
				
		var service = {};
		
		service.login = function(jsonLogin){	            
			var url = endPointConfigService.obtenerRutaEndPoint("login");    			
			return REST.callHttp(url, securityService.encrypAES_json(jsonLogin), 'POST', 'application/json','application/json');	      
		};
		
		service.getCode = function(jsonRequest){			
			var url = endPointConfigService.obtenerRutaEndPoint("getCode");    			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST', 'application/json','application/json');	      
		};
		
		service.validateCode = function(jsonCode){	            
			var url = endPointConfigService.obtenerRutaEndPoint("validateCode");    			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonCode)), 'POST', 'application/json','application/json');	      
		};
		
		service.cifrarPrueba = function(jsonCode){	            
			var url = endPointConfigService.obtenerRutaEndPoint("cifrarPrueba");    			
			return REST._callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonCode)), 'POST', 'application/json','application/json');	      
		};
		
		service.consultaFuncionalidad = function(jsonCode){	            
			var url = endPointConfigService.obtenerRutaEndPoint("consultaFuncionalidad");    			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonCode)), 'POST', 'application/json','application/json');	      
		};
			
		service.consultarAbonos = function(jsonCode){	            
			var url = endPointConfigService.obtenerRutaEndPoint("consultarAbonos");    			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonCode)), 'POST', 'application/json','application/json');	      
		};
		
		return service; 
				
	});
	
});