/* 
 * Necessarily you need google maps js, and angular directives for maps
 */

'use strict';

define(["app"], function (app) {
	
	
	app.factory( "MarkerCreatorService", function( $timeout, $interval ){
		
		var div_google_streetView = "google_streetview";
		var div_google_noneView = "google_noneView";
		var div_map_streetview = "map_streetview";
		var markerId = 0;
	    var _marker = null, _panorama_url = null, _panorama = null;
	    
	    function create( latitude, longitude )
	    {

	        var marker = {
	            options: {
	                draggable: true,
	                animation: 0,
	                labelAnchor: "28 -5",
	                labelClass: 'markerlabel'    
	            },
	            events:{
	                dragend: function ( marker, eventName, args ) {
	                    var lat = marker.getPosition().lat();
	                    var lon = marker.getPosition().lng();

	                    getMarker().latitude = lat;
	                    getMarker().longitude = lon;
	                    getStreetView( null );

	                },
	                projection_changed: function( marker, eventName, args ){
	                	var lat = marker.getPosition().lat();
	                    var lon = marker.getPosition().lng();
	                    
	                    getMarker().latitude = lat;
	                    getMarker().longitude = lon;
	                    getStreetView( null );
	                }
	            },
	            latitude: latitude,
	            longitude: longitude,
	            id: ++markerId          
	        };

	        setMarker( marker );
	       
	        return marker;        

	    }

	    function setMarker( marker )
	    {
	        _marker = marker;
	    }

	    function getMarker()
	    {
	        return _marker;
	    }

	    function getMarkerPosition( marker )
	    {

	        var position = {
	            'latitude': marker.latitude,
	            'longitude': marker.longitude
	        }

	        return position;

	    }

	    function getStreetView( successCallback )
	    {

	    	var panorama = null;
	    	
	        var _latitude = getMarker().latitude, _longitude = getMarker().longitude;

	        var _position = new google.maps.LatLng( _latitude, _longitude );
	        
//	        console.log( "LAT [" + _latitude + "] - LONG [" + _longitude + "]" );
	        
	        var panoramaOptions = {
	            position: _position,
	            pov: {
	                heading: 0, //30
	                pitch: 0, //5
	                zoom: 1 //2
	            },
	            disableDefaultUI: true,
	            linksControl: true,
	            panControl: false,
//	            zoomControlOptions: {
//	                style: google.maps.ZoomControlStyle.SMALL
//	            },	            
	            enableCloseButton: false,
	            fullScreenControl: false,
	            fullScreenButton: false,
	            zoomControl: false,
	            scaleControl: false,
	            mapTypeControl: false,
	            streetViewControl: false,
	            addressControl: false
	        };
	        
	        //Exists?
	        if( _panorama == null ){
	            panorama = new google.maps.StreetViewPanorama( document.getElementById( div_google_streetView ), panoramaOptions);
	        }else{
	            panorama = _panorama;
	            panorama.setPosition( _position );
	            //panorama = _panorama.google.maps.setPosition( _position );
	        }
	        
	        panorama.setMotionTracking(false);//Erick was here
	        
//	        panorama.controls[google.maps.ControlPosition.TOP_RIGHT] = [];
//            
//            panorama.controls[google.maps.ControlPosition.TOP_RIGHT].push( 
//	        		FullScreenPanorama( panorama, document.getElementById('google_streetview')  , null )
//	        );        	        
	        var _panorama_data = {
	            heading: 30,
	            pitch: 0,
	            zoom: 1,
	            latitude: _latitude,
	            longitude: _longitude,
	            fov: 90
	        };
	        
	        var panoramaChanged = function( objPanorama ){
	        	
	        	_panorama_data.latitude = objPanorama.getPosition().lat();
	            _panorama_data.longitude = objPanorama.getPosition().lng();
	            _panorama_data.heading = objPanorama.getPov().heading;
	            _panorama_data.pitch = objPanorama.getPov().pitch;
	            _panorama_data.zoom = objPanorama.getPov().zoom;
	     
	            //FOV is calculated using the below formula.
	            _panorama_data.fov = 90 / Math.max( 1, objPanorama.getPov().zoom );
	        	
	        };
	        
	        panorama.addListener( 'position_changed', function() {
	            panoramaChanged( panorama );
	        });
	        
	        panorama.addListener( 'pov_changed', function() {
	        	panoramaChanged( panorama );
	        });

	        var streetViewService = new google.maps.StreetViewService();
	        var CONST_METER = 50;
	        var containerStreetView = null;
	        var containerImageNoneView = null;
	        var containerMap = null;
	        
	        
	        var stopInterval = null, intervalCont = 1;
			
//			var verifySlider = function(){
				containerStreetView =  document.getElementById( div_google_streetView );
				containerImageNoneView = document.getElementById( div_google_noneView );
//				containerMap = $('.gmnoprint > map');
//				return (containerStreetView != null && containerImageNoneView != null &&  containerMap.length > 0 );
//			};
							
//			var trySlider = function(){
//									
//				if( verifySlider() ){
//					
//					$interval.cancel( stopInterval )
//			
					streetViewService.getPanoramaByLocation( _position, CONST_METER, function(panoramaData, status) {	            
			        	if (status == google.maps.StreetViewStatus.OK) {
			        		containerImageNoneView.style.display = "none";
			        		containerStreetView.style.display = "block";
			        		panorama.setVisible( true );
			        	}else{
			        		containerImageNoneView.style.display = "block";
			        		containerStreetView.style.display = "none";
			        		panorama.setVisible( false );
			        	}
			        });	      
					
//				}else if( intervalCont == 100 )
//					$interval.cancel( stopInterval );
//				else{
//					console.log( intervalCont );
//					intervalCont++;
//				}
//			};
//			
//			stopInterval = $interval( trySlider, 100 );
	        	        
	        
	        if( panorama != null ){
	        
	        	_panorama_url = doStreetViewURL( _panorama_data, 800, 400, 'https://maps.googleapis.com/maps/api' );
	            _panorama = panorama;

	        }else{
	            console.error( 'Unable to load the picture service' );
	        }
	        
	        if( successCallback && successCallback != null )
	        	successCallback();
	        
	        return _panorama_data;
	    
	    }

	    function getPanorama()
	    {

	        return _panorama;

	    }

	    function setPanorama( pano ){
	    	
	    	_panorama = pano;
	    	
	    }
	    
	    function getStreetViewURL()
	    {

	        return _panorama_url;

	    }

	    function doStreetViewURL( json_panorama, width, height, base_dir )
	    {

	        var url_options = 'size=' + width + 'x' + height + '&location=' + json_panorama.latitude + ',' + json_panorama.longitude + '&fov=' + json_panorama.fov + '&heading=' + json_panorama.heading + '&pitch=' + json_panorama.pitch + '&zoom=' + json_panorama.zoom;

	        return base_dir + '/streetview?' + url_options;

	    }


	    function invokeSuccessCallback( successCallback, marker )
	    {

	        if( marker ){
	            
	            if ( typeof successCallback === 'function' ) {
	                successCallback( marker );
	            }

	        }else{
	            successCallback();
	        }


	    }

	    function createByCoords( latitude, longitude, successCallback, initCallBack )
	    {
	        	    	
	    	var marker = create( latitude, longitude );
	        invokeSuccessCallback( successCallback, marker );
	        
//	        if( initCallBack && initCallBack != null )	        
//	        	getStreetView( initCallBack );
//	        else
	        	getStreetView( null );
	        
	    	var geocoder = new google.maps.Geocoder();

	    	var latlng = { 
	    			lat: parseFloat( latitude ), 
	    			lng: parseFloat( longitude )
	    	};
	    	
	        geocoder.geocode( {'location' : latlng }, function ( results, status ) {
	            
	            if ( status === google.maps.GeocoderStatus.OK ) {
	            	console.log( 'MAP OK' );
	            	if( initCallBack && initCallBack != null )
	            		initCallBack();
//	    	        	getStreetView( initCallBack );
//	    	        else
//	    	        	getStreetView( null );
	            } else {
	                console.error( "Unknown address: {" + latitude + ','+ longitude + '} service' );
	            }

	        });

	    }

	    function refreshMarkerByZone( latitude, longitude, successCallback, refreshMap )
	    {
	        
	        var marker = create( latitude, longitude );
	        invokeSuccessCallback( successCallback, marker );
	        
	        if( refreshMap )
	        	getStreetView( null );
	        
	        return marker;

	    }

	    
	    function createByAddress( address, postal_code, successCallback ) 
	    {
	        
	    	if( address.charAt(0) === "," ){
	    		address = address.substring(1);
	    	}
	    	
	        var geocoder = new google.maps.Geocoder();
	        
	        console.log( 'DIRECCCCCCCION: ' + address );
	        
	        geocoder.geocode( {'address' : address}, function ( results, status ) {
	            
	            if ( status === google.maps.GeocoderStatus.OK ) {

	            	var validateComponent = function( obj ){
	            		
	            		var hasPostalCode = false;
	            		
	            		obj.map( function( data ){
	            			
	            			var index = data['types'].indexOf( 'postal_code' );
	            			
	            			if( index > -1 ){
	            				
	            				var data_long_name = data['long_name'], data_short_name = data['short_name'];
	            				
	            				if( data_long_name == postal_code || data_short_name == postal_code )
	            					hasPostalCode = true;
	            				else
	            					hasPostalCode = false;
	            				
	            			}else
	            				hasPostalCode = false;

	            		});
	            		
//	            		console.log( hasPostalCode );
	            		
	            		return hasPostalCode;
	            		
	            	};
	            	
	            	var firstAddress = null;
	            	
	            	for( var index in results ){
	            		
	            		if( validateComponent( results[index]['address_components'] ) ){
	            			firstAddress = results[index];
//	            			console.log( "====================================================" );
//	            			console.log( firstAddress );
	            			break;
	            		}
	            		
	            	}
	            	
	            	if( firstAddress == null ){
	            		firstAddress = results[0];
	            	}
	            	
	                if( firstAddress.geometry.location_type === "APPROXIMATE" ){
	                	console.error( "We cant access to: " + address );
	                }else{
	                	
	                	console.log( "ENTRO " + address);
	                
		                var latitude = firstAddress.geometry.location.lat();
		                var longitude = firstAddress.geometry.location.lng();
		                var marker = create( latitude, longitude );
		                invokeSuccessCallback( successCallback, marker );
		                getStreetView( null );
		                //console.log( results );		                
	                }

	            } else {
	                console.error( "Unknown address: " + address + ' service' );
	            }

	        });

	    }

	    function createByCurrentLocation( successCallback )
	    {
	        
	        if ( navigator.geolocation ){

//	            navigator.geolocation.getCurrentPosition( function ( position ) {
//	                var marker = create( position.coords.latitude, position.coords.longitude );
//	                invokeSuccessCallback( successCallback, marker );
//	            });

	        } else {
	            console.error( 'Unable to locate current position service' );
	        }

	    }

	    // onError Callback receives a PositionError object
	    var onErrorGeolocation = function( error )
	    {
	    	
	        switch( error.code ) {
	        	case error.TIMEOUT:
	        		// Quick fallback when no cached position exists at all.
	        		doFallbackGeolocation();
	          		// Acquire a new position object.
	        		navigator.geolocation.getCurrentPosition( onSuccessGeolocation, onErrorGeolocation );
	          	break;
	        	default:
	        		console.error( error );
	        		console.error('[CONF SW-DEF] code: ' + error.code + '\n' +
	        		        'message: ' + error.message + '\n');
	        };
	        
	    }

	    function doFallbackGeolocation()
	    {
	    	
	    	localStorage['currentPosition'] = null;
	    	localStorage['latitude'] = "18.849506"; // Grupo Salinas
	    	localStorage['longitude'] = "-97.105735"; // Grupo Salinas
	    	
	    	console.log( localStorage.getItem( 'latitude' ) + " <==> " + localStorage.getItem( 'longitude' ) );
	    	
	    }
	    
	    function testCurrentLocation( scopeMap )
	    {

	    	if ( navigator.geolocation ){
	    		
	    		var onSuccessGeolocation = function( position ){
	    			var lat = position.coords.latitude; //19.296610 PUNTO SIN STREET VIEW; 
	    			var long = position.coords.longitude; //-99.186054;
	    			refreshMarkerByZone( lat, long, function ( marker ) {  
	    				scopeMap.markers[0] = marker;
	    				scopeMap.control.refresh( {
		    	            latitude: lat, 
		    	            longitude: long
		    	        });
					}, true);
	    		};
	    		    			
    			navigator.geolocation.getCurrentPosition( onSuccessGeolocation, onErrorGeolocation, 
    				{
    					maximumAge:Infinity, timeout:0
    				}
    			); 

	        } else {
	            console.error( 'Unable to locate current position service' );
	        }
	    	
	    }
	    	    
	    function enableFullScreen( scopeMap, callBack )
	    {
	    	
	    	 $timeout( function(){
			    	
	    		 var gMap = scopeMap.control.getGMap();
			    				    	
				 var openDefault = "Pantalla Completa", closeDefault = "Salir de Pantalla Completa";
				    
				 gMap.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push( FullScreenControl( gMap, [openDefault],
				  		[closeDefault], callBack ));
				    
				 var foo = function(){
				   	testCurrentLocation( scopeMap );
				 };
				    
				 if( window.location.protocol == "https:" ){
					 gMap.controls[google.maps.ControlPosition.LEFT_BOTTOM].push( CurrentLocationControl( gMap, foo ) );
				 }
				    
			  }, 100 );				
	    	
	    }
	    
	    function enableFullScreenPanorama( panorama )
	    {
	    
	    	$timeout(function(){
		    	
	    		var pano = null;
		    	
		    	if( panorama ){
		    		pano = panorama;
		    	}else{
		    		pano = getPanorama();
		    	}
	    			    	
//		    	pano.controls[google.maps.ControlPosition.TOP_RIGHT] = [];
		    	
		    	if( pano.controls[google.maps.ControlPosition.RIGHT_BOTTOM].length == 0 ){
		    		pano.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push( 
			        		FullScreenPanorama( pano, document.getElementById('google_streetview')  , null )
			        );
		    	}
		    	
	    	},  100);
	    	
	    }

	    return {
	        createByCoords: createByCoords,
	        createByAddress: createByAddress,
	        createByCurrentLocation: createByCurrentLocation,
	        getMarkerPosition: getMarkerPosition,
	        getStreetView: getStreetView,
	        doStreetViewURL: doStreetViewURL,
	        getStreetViewURL: getStreetViewURL,
	        getPanorama: getPanorama,
	        getMarker: getMarker,
	        setMarker: setMarker,
	        setPanorama: setPanorama,
	        refreshMarkerByZone: refreshMarkerByZone,
	        enableFullScreen: enableFullScreen,
	        enableFullScreenPanorama: enableFullScreenPanorama
	    };
	
				
	});
	
});