/*
*	Custom Buttons 
*/

var B64_COLLAPSE = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABLklEQVRIS92WsRWCMBCGTQG1TqIj6AaOQEWrI8gaVGzgCDKCTKI1FPEuL8lLyF2ID9NIByT3Jf9P/kNs4Krr+jyOY9913Rvv115VVW3Lsry0bdsILA4F71LK5zRNp7UQLF4UxUMIcYC6jdC0Hm72FAQWIHFHsBrh7ox6Pis+gCpHNSkGSQVQxVENuyoOkgLgiuPivW1TEDDrFZMIZNg5mitZXB89ACWXNov1AH3TY4LiwQ6Mie5OzDPOZP2eLO4BjNbcGVgABNPMeCtRdsDa08vND0z+NeiPANlNzg5wzZ1li3oVOwexqCejws0WjPEFwMBFPRl28+BKCTsYw/YTL66pVEyNaw5iGw4XuSmAWNNSLTOW56kADmKbPgxgI/eb+JhFfaMkyvTbcoVP+/YBeZNw7LV1Ko4AAAAASUVORK5CYII=';
var B64_EXPAND = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABI0lEQVRIS+2VvRWCMBDHTQG1TqIj6AaOQEWrI8gaVGzgCDKCTKI1FPHOx2EIl0sIlPIeBeTy/13uKyrPc70RnrIslbTu2698BqsCtNbPrutOVVW9Ja9da1mWbZMkeSilDmRjnqCBn/tYiCX+1ULIAGjbdpemaR0DscVB6wharxEAY42GcyGcOIaYcjucgJI5B+ISR8+dAFwMgUjiI4BUERQusCnghDfTFjw8w/cd3gZj7qo8sYn6k1xtcQIhBMRrqaxFQEwv2Hv+AG8UQ5J8gSQXnNKiJFt17ixT3+yadDI1mjEV2Tr3NaM4KnziFC4JwgJ87c/lwQWZAHBch3pugzjIZFxjsvqbSJwtIbPL0PpdOP3GKHEuJ9yVyTq36qXPEZYCPl/PXjhBp2AtAAAAAElFTkSuQmCC';

function googleMapButton( b64Image, className ) {
	
    "use strict";
    
    var controlDiv = document.createElement("div");
    controlDiv.className = className;
    controlDiv.index = 1;
    controlDiv.style.padding = "10px";
    //controlDiv.style.margin = "10px";
    
    var controlUi = document.createElement("div");
    controlUi.style.backgroundColor = "rgb(255, 255, 255)";
    controlUi.style.color = "#565656";
    controlUi.style.cursor = "pointer";
    controlUi.style.textAlign = "center";
    controlUi.style.boxShadow = "rgba(0, 0, 0, 0.298039) 0px 1px 4px -1px";
    controlDiv.appendChild( controlUi );
    
    var img = document.createElement( "img" );
    img.setAttribute( 'src', b64Image );
    img.style.height = "2em;";
    img.style.width = "2em";
    img.style.padding = "5px";
    
    controlUi.appendChild( img );
    controlUi.addEventListener( 'click', function () {
    	controlUi.style.backgroundColor = "rgb(255, 255, 255)";
    	controlUi.style.color = "#565656";
    });
    
    controlUi.addEventListener( 'mouseenter', function () {
        controlUi.style.backgroundColor = "rgb(235, 235, 235)";
        controlUi.style.color = "#000";
    });
    
    controlUi.addEventListener( 'mouseleave', function () {
    	controlUi.style.backgroundColor = "rgb(255, 255, 255)";
      	controlUi.style.color = "#565656";
    });
      
    return controlDiv;
    
}

function FullScreenControl( map, doFunction ) {
	
    "use strict";
    
    var imgExpand = document.createElement( "img" );
    imgExpand.setAttribute( 'src', B64_EXPAND );
    imgExpand.style.height = "2em;";
    imgExpand.style.width = "2em";
    imgExpand.style.padding = "5px";

    var imgCollapse = document.createElement( "img" );
    imgCollapse.setAttribute( 'src', B64_COLLAPSE );
    imgCollapse.style.height = "2em;";
    imgCollapse.style.width = "2em";
    imgCollapse.style.padding = "5px";
    
    var controlDiv = googleMapButton( B64_EXPAND, "fullScreen" );
    var fullScreen = false;
    var interval = null;
    var mapDiv = map.getDiv();
    var divStyle = mapDiv.style;
    
    if ( mapDiv.runtimeStyle ) {
        divStyle = mapDiv.runtimeStyle;
    }
    
    var originalPos = divStyle.position;
    var originalWidth = divStyle.width;
    var originalHeight = divStyle.height;
    
    // ie8 hack
    if ( originalWidth === "" ) {
        originalWidth = mapDiv.style.width;
    }
    
    if ( originalHeight === "" ) {
        originalHeight = mapDiv.style.height;
    }
    
    var originalTop = divStyle.top;
    var originalLeft = divStyle.left;
    var originalZIndex = divStyle.zIndex;
    var bodyStyle = document.body.style;
    
    if ( document.body.runtimeStyle ) {
        bodyStyle = document.body.runtimeStyle;
    }
    
    var originalOverflow = bodyStyle.overflow;
    
    controlDiv.goFullScreen = function () {

        var center = map.getCenter();
        mapDiv.style.position = "fixed";
        mapDiv.style.width = "100%";
        mapDiv.style.height = "100%";
        mapDiv.style.top = "0";
        mapDiv.style.left = "0";
        mapDiv.style.zIndex = "100";
        document.body.style.overflow = "hidden";
  
        var elem = _find( controlDiv.children, "div" );
  
        if( elem != null )
            elem.innerHTML = imgCollapse.outerHTML;
        else 
            console.error( "In function _find" );
  
        fullScreen = true;
        google.maps.event.trigger(map, "resize");
        map.setCenter(center);
        
        interval = setInterval( function () {
        	
            if ( mapDiv.style.position !== "fixed" ) {
                mapDiv.style.position = "fixed";
                google.maps.event.trigger(map, "resize");
            }
            
        }, 100);
    };
    
    controlDiv.exitFullScreen = function () {
    	
        var center = map.getCenter();
                
        if ( originalPos === "" ) {
            mapDiv.style.position = "relative";
        }else {
            mapDiv.style.position = originalPos;
        }
        
        mapDiv.style.width = originalWidth;
        mapDiv.style.height = originalHeight;
        mapDiv.style.top = originalTop;
        mapDiv.style.left = originalLeft;
        mapDiv.style.zIndex = originalZIndex;
        document.body.style.overflow = originalOverflow;

        var elem = _find( controlDiv.children, "div" );

        if( elem != null )
            elem.innerHTML = imgExpand.outerHTML;
        else 
            console.error( "In function _find" );

        fullScreen = false;
        google.maps.event.trigger( map, "resize" );
        map.setCenter( center );
        clearInterval( interval );
        
    };
    
    google.maps.event.addDomListener( controlDiv, "click", function () {
        
    	if ( !fullScreen ) {
            controlDiv.goFullScreen();
        }else {

            controlDiv.exitFullScreen();
            
            if( doFunction != null ) 
            	doFunction();

        }
    	
    });
    
    return controlDiv;
    
}

function FullScreenPanorama( panorama, panoramaContainer, doFunction ) {
	
    "use strict";

    var imgExpand = document.createElement( "img" );
    imgExpand.setAttribute( 'src', B64_EXPAND );
    imgExpand.style.height = "2em;";
    imgExpand.style.width = "2em";
    imgExpand.style.padding = "5px";

    var imgCollapse = document.createElement( "img" );
    imgCollapse.setAttribute( 'src', B64_COLLAPSE );
    imgCollapse.style.height = "2em;";
    imgCollapse.style.width = "2em";
    imgCollapse.style.padding = "5px";
    
    var controlDiv = googleMapButton( B64_EXPAND, "fullScreen" );
    var fullScreen = false;
    var interval = null;
    var mapDiv = panoramaContainer;
    var divStyle = mapDiv.style;
    
    if ( mapDiv.runtimeStyle ) {
        divStyle = mapDiv.runtimeStyle;
    }
    
    var originalPos = divStyle.position;
    var originalWidth = divStyle.width;
    var originalHeight = divStyle.height;
    
    // ie8 hack
    if ( originalWidth === "" ) {
        originalWidth = mapDiv.style.width;
    }
    
    if ( originalHeight === "" ) {
        originalHeight = mapDiv.style.height;
    }
    
    var originalTop = divStyle.top;
    var originalLeft = divStyle.left;
    var originalZIndex = divStyle.zIndex;
    var bodyStyle = document.body.style;
    
    if ( document.body.runtimeStyle ) {
        bodyStyle = document.body.runtimeStyle;
    }
    
    var originalOverflow = bodyStyle.overflow;
    
    controlDiv.goFullScreen = function () {
//        var center = panorama.getCenter();
        mapDiv.style.position = "fixed";
        mapDiv.style.width = "100%";
        mapDiv.style.height = "100%";
        mapDiv.style.top = "0";
        mapDiv.style.left = "0";
        mapDiv.style.zIndex = "100";
        document.body.style.overflow = "hidden";
        
        var elem = _find( controlDiv.children, "div" );
  
        if( elem != null )
            elem.innerHTML = imgCollapse.outerHTML;
        else 
            console.error( "In function _find" );

        fullScreen = true;
        google.maps.event.trigger( panorama, "resize");
        
        interval = setInterval( function () {
        	
            if ( mapDiv.style.position !== "fixed" ) {
                mapDiv.style.position = "fixed";
                google.maps.event.trigger( panorama, "resize");
            }
            
        }, 10);
    };
    
    controlDiv.exitFullScreen = function () {
    	
//        var center = map.getCenter();
                
        if ( originalPos === "" ) {
            mapDiv.style.position = "relative";
        }else {
            mapDiv.style.position = originalPos;
        }
        
        mapDiv.style.width = originalWidth;
        mapDiv.style.height = originalHeight;
        mapDiv.style.top = originalTop;
        mapDiv.style.left = originalLeft;
        mapDiv.style.zIndex = originalZIndex;
        document.body.style.overflow = originalOverflow;
        
        var elem = _find( controlDiv.children, "div" );
  
        if( elem != null )
            elem.innerHTML = imgExpand.outerHTML;
        else 
            console.error( "In function _find" );

        fullScreen = false;
        google.maps.event.trigger( panorama, "resize" );
//        map.setCenter( center );
        clearInterval( interval );
        
    };
    
    // setup the click event listener
    google.maps.event.addDomListener( controlDiv, "click", function () {
        
    	if ( !fullScreen ) {
            controlDiv.goFullScreen();
        }else {

            controlDiv.exitFullScreen();
            
            if( doFunction != null ) 
            	doFunction();

        }
    	
    });
    
    return controlDiv;
    
}

function FullScreenImage( satelitalImage, satelitalContainer ,panoramaContainer, doFunction ) {
    
    "use strict";

    var imgExpand = document.createElement( "img" );
    imgExpand.setAttribute( 'src', B64_EXPAND );
    imgExpand.style.height = "1em;";
    imgExpand.style.width = "1em";
    imgExpand.style.padding = "5px";

    var imgCollapse = document.createElement( "img" );
    imgCollapse.setAttribute( 'src', B64_COLLAPSE );
    imgCollapse.style.height = "1em;";
    imgCollapse.style.width = "1em";
    imgCollapse.style.padding = "5px";
    
    var controlDiv = googleMapButton( B64_EXPAND, "fullScreenImage" );
    controlDiv.style.position = "absolute";
    controlDiv.style.right = "0";
    controlDiv.style.bottom = "0";
    satelitalContainer.appendChild( controlDiv );

    var fullScreen = false;
    var interval = null;
    var mapDiv = satelitalContainer;
    var divStyle = mapDiv.style;
    
    if ( mapDiv.runtimeStyle ) {
        divStyle = mapDiv.runtimeStyle;
    }
    
    var originalPos = divStyle.position;
    var originalWidth = divStyle.width;
    var originalHeight = divStyle.height;
    
    // ie8 hack
    if ( originalWidth === "" ) {
        originalWidth = mapDiv.style.width;
    }
    
    if ( originalHeight === "" ) {
        originalHeight = mapDiv.style.height;
    }
    
    var originalTop = divStyle.top;
    var originalLeft = divStyle.left;
    var originalZIndex = divStyle.zIndex;
    var bodyStyle = document.body.style;
    
    if ( document.body.runtimeStyle ) {
        bodyStyle = document.body.runtimeStyle;
    }
    
    var originalOverflow = bodyStyle.overflow;
    
    controlDiv.goFullScreen = function () {
        mapDiv.style.position = "fixed";
        //mapDiv.style.width = "100%";
        //mapDiv.style.minHeight = "100%";
        mapDiv.style.top = "0";
        mapDiv.style.left = "0";
        mapDiv.style.zIndex = "100";
        document.body.style.overflow = "hidden";
        
        var elem = _find( controlDiv.children, "div" );
  
        if( elem != null )
            elem.innerHTML = imgCollapse.outerHTML;
        else 
            console.error( "In function _find" );

        fullScreen = true;
        
        interval = setInterval( function () {
            
            if ( mapDiv.style.position !== "fixed" ) {
                mapDiv.style.position = "fixed";
            }
            
        }, 10);
    };
    
    controlDiv.exitFullScreen = function () {
        
        if ( originalPos === "" ) {
            mapDiv.style.position = "relative";
        }else {
            mapDiv.style.position = originalPos;
        }
        
        mapDiv.style.width = originalWidth;
        mapDiv.style.height = originalHeight;
        mapDiv.style.top = originalTop;
        mapDiv.style.left = originalLeft;
        mapDiv.style.zIndex = originalZIndex;
        document.body.style.overflow = originalOverflow;
        
        var elem = _find( controlDiv.children, "div" );
  
        if( elem != null )
            elem.innerHTML = imgExpand.outerHTML;
        else 
            console.error( "In function _find" );

        fullScreen = false;

        clearInterval( interval );
        
    };
    
    // setup the click event listener
    google.maps.event.addDomListener( controlDiv, "click", function () {
        
        if ( !fullScreen ) {
            controlDiv.goFullScreen();
        }else {

            controlDiv.exitFullScreen();
            
            if( doFunction != null ) 
                doFunction();

        }
        
    });
    
    return controlDiv;
    
}

function _find( nodes, elem ){

    for( var i = 0; i < nodes.length; i++ ){

        if( nodes[i].tagName === elem.toUpperCase() ){
            return nodes[i];
        }

    }

    return null;


}