var MapBazLibrary = angular.module('MapBazLibrary', []);
var respuestaBAZ;



MapBazLibrary.service( 'MapBazService', function(MapBazConnection,$sce,$timeout){

	var map = null, panorama = null, marker = null, sv_service = null;
	var mapDiv = "", streetViewDiv = "";
	var RADIUS_CHECK_STREETVIEW = 50;
	var jsonInit = {};
	
	$( document ).ready(function() {
		pm.bind("xiZonificadorOriCen", function (xData) {
			respuestaBAZ=xData.xRes;
			callbackScope(respuestaBAZ);
		});
	});

	var MapFunctions = {};

	MapFunctions.createMap = function( mapDivElement, jsonInitialize)
	{
		respuestaBAZ=null;
		jsonInit = jsonInitialize;
		mapDiv = mapDivElement;
		
		var doFunction = function(){

			if( !mapDivElement || !$("#"+mapDivElement))
				throw "Faltan ID's referencia para el mapa!";

			var url= buildUrl(jsonInit);
			updateScope(url); 
		};

		if( typeof jsonInit.doOnFail != 'undefined' && jsonInit.doOnFail != null )
			doFunctionFail = jsonInit.doOnFail;

		if( jsonInit.hasOwnProperty( 'failOptions' ) && typeof jsonInit.failOptions != 'undefined' && jsonInit.failOptions != null ){
			jsonConnection = jsonInit.failOptions;
			jsonConnection.mapDiv = mapDivElement;
		}
		jsonConnection.mapDiv = mapDivElement;

		MapBazConnection.executeOnConnection( doFunction, doFunctionFail, jsonConnection );

	};

	var buildUrl=function(jsonInit){
			var geo = {
				lat: jsonInit.lat,
				lng: jsonInit.lng
			};

			var options = {
				divWidth: $("#"+mapDiv).width(),
				divHeight:$("#"+mapDiv).height(),
			};
			
			var direccion={				
				xDireccion : jsonInit.direccion.xDireccion,
				idPais:jsonInit.direccion.idPais,
				idEdo:jsonInit.direccion.idEdo,
				idMun:jsonInit.direccion.idMun,
				cp:jsonInit.direccion.cp,
				idCol:jsonInit.direccion.idCol,
				calle:jsonInit.direccion.calle
			}
			
			var tienda={
				xCveZon : jsonInit.tienda.xCveZon,
				xPais : jsonInit.tienda.xPais,
				xCanal : jsonInit.tienda.xCanal,
				xSucursal : jsonInit.tienda.xSucursal
			}
			
			urlBAZ="http://10.57.161.224/ZonificadorOriCen/Default.aspx";
			urlBAZ+="?xPais="+tienda.xPais;
			urlBAZ+="&xCanal="+tienda.xCanal;
			urlBAZ+="&xSucursal="+tienda.xSucursal;
			urlBAZ+="&xCveZon="+tienda.xCveZon;
			urlBAZ+="&xDireccion="+direccion.xDireccion;
			urlBAZ+="&xUbicacion="+geo.lng+"|"+geo.lat;
			urlBAZ+="&xTamanio="+options.divWidth+"|"+options.divHeight;
			urlBAZ+="&xInfoDom="+direccion.idPais+"|"+direccion.idEdo+"|"+direccion.idMun+"|"+direccion.cp+"|"+direccion.idCol+"|"+direccion.calle;

			return urlBAZ;
	};
	
	MapFunctions.updatePosition = function( longitud, latitud)
	{
		if( !jsonInit )
			throw "No se ha inicializado correctamente el mapa."

		jsonInit.lat=latitud;
		jsonInit.lng=longitud;

		var url= buildUrl(jsonInit);
		updateScope(url); 
	};

	MapFunctions.geolocation = function( jsonAddress )
	{
		if( !jsonAddress )
			throw "La cadena a buscar no se inicializó correctamente."

		if( !jsonInit )
			throw "No se ha inicializado correctamente el mapa."

		jsonInit.lat=0;
		jsonInit.lng=0;

		jsonInit.direccion.xDireccion=jsonAddress.xDireccion;
		jsonInit.direccion.idPais=jsonAddress.idPais;
		jsonInit.direccion.idEdo=jsonAddress.idEdo;
		jsonInit.direccion.idMun=jsonAddress.idMun;
		jsonInit.direccion.cp=jsonAddress.cp;
		jsonInit.direccion.idCol=jsonAddress.idCol;
		jsonInit.direccion.calle=jsonAddress.calle;	

		var url= buildUrl(jsonInit);
		updateScope(url); 

	};

	MapFunctions.getDataPosition = function()
	{
		if( !jsonInit )
			throw "No se ha inicializado correctamente el mapa."

		return respuestaBAZ;

	};
	
	var updateScope=function(urlBAZ){
		var scope = angular.element($("#"+mapDiv)).scope();
		$timeout(function(){
			scope.$apply(function(){
				console.log(urlBAZ);
				scope.urlBAZ = $sce.trustAsResourceUrl(urlBAZ);			
			})
		},0);
	};

	var callbackScope=function(paramBAZ){
		var scope = angular.element($("#"+mapDiv)).scope();
		$timeout(function(){
			scope[jsonInit.fnCallback](paramBAZ);
			scope.$apply();
		},0);
	};
	return MapFunctions;
});

MapBazLibrary.service( 'MapBazConnection', function(){

	var MapFunctions = {}, jsonInit = {};
	var scripts = [];
	var CONNECTION_TIMEOUT = 500, 
	MESSAGE_NO_CONNECTION = "No se pudo establecer una petición con Google, por favor revisa tu conexión a Internet.";
	var google_key = "";

	MapFunctions.executeOnConnection = function( callBackFn, callBackFnFail, jsonConf )
	{
	
		jsonInit = jsonConf;
		var cont = 0, timer = null;

		if( Object.keys(jsonInit).length === 0 )
			console.warn( "CONFIGURACIÓN TIMEOUT DEFAULT." );
		else if( jsonInit.hasOwnProperty( 'timeout' ) && jsonInit.timeout > 0 )
			CONNECTION_TIMEOUT = 100 * jsonInit.timeout;
		else
			console.error( "CONFIGURACIÓN TIMEOUT INCORRECTA, SE TOMA TIEMPO DEFAULT." );
			
		var verifyConection = function()
		{
			var hasConection = false;
			try{
				if(/*$("divMapXtreme").length>0*/true)
					hasConection = true;
				else
					hasConection = false;
			}catch( e ){
				hasConection = false;
			}
			return hasConection;
		};

		var tryBazMap = function()
		{

			if( verifyConection() ){				
				clearInterval( timer );
				console.log( "HAY MAPAS DE BANCO!" );
				if( typeof callBackFn !== 'undefined' && callBackFn != null )
					callBackFn();
			}else if( cont == CONNECTION_TIMEOUT ){
				clearInterval( timer );
				window.stop();
				console.error( "NO HAY BAZ MAPS!" );
				createDivErrors();
				if( typeof callBackFnFail !== 'undefined' && callBackFnFail != null )
					callBackFnFail();				
				// throw "NO SE PUDO CONECTAR A GOOGLE";
			}else{
				cont++;
			}

		};

		timer = setInterval( tryBazMap, 10 );


	};

	function createDivErrors(){
		console.log("Div Error");
	}
	return MapFunctions;

});