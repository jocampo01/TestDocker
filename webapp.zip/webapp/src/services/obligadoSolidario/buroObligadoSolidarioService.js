'use strict'; 

define(["app"], function (app) {

	app.factory( "buroObligadoSolidarioService", function( $rootScope, $location, endPointConfigService, REST, 
										  generalService, modalService, solicitudService, securityService,
										  validateService,$q, generalServiceOS ){
		
		var service = {};
		var descCatalog = [];
		descCatalog[21] = {label:"Consumo", idLi:"consumo"};
		descCatalog[22] = {label:"Italika", idLi:"italika"};
		descCatalog[23] = {label:"Telefonia", idLi:"telefonia"};
		descCatalog[24] = {label:"Préstamo en efectivo", idLi:"prestamospersonales"};
		descCatalog[25] = {label:"Crédito Inmediato", idLi:"tarjetaazteca"};
		
		service.consultaBuro = function(cssTittlo, cssbtnCancel, cssbtnOk, path, simulador, tipoConsulta, doFunction ){
			
			var currentPath = pathSeccion["#/" + $rootScope.paginaActual];
			var buroPath = validacionPath[currentPath];						
			
			if( ( generalServiceOS.validaConsultaBuro( $rootScope.solicitudOSJson) || simulador) && buroPath.buro && ( tipoConsulta == 0 || tipoConsulta == 1) ){													
				
				$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].domicilioActual = 1;
				
				var colorTitDatosHogar=$rootScope.paginaActual=="datosHogar"?"bgRosa":$rootScope.paginaActual=="datosPersonales"?"bgNaranja":"bgAzul";
				var colorBotDatosHogar=$rootScope.paginaActual=="datosHogar"?"rosa":$rootScope.paginaActual=="datosPersonales"?"naranja":"btn gris1";
				
				if (simulador){
					$rootScope.solicitudJOSson.consultaBuro = 1;
					
					try{
						if($rootScope.solicitudOSJson.idSolicitud != null && $rootScope.solicitudOSJson.idSolicitud != ""){
							generalServiceOS.locationPath("/ochoPasosOS");
						}else{
							generalServiceOS.locationPath("/ochoPasosOS");
						}
					}catch(e){
						generalServiceOS.locationPath("/ochoPasosOS");
					}
					
				}else{
					console.log("ACEPTO BURO");	
					$rootScope.waitLoaderStatus = LOADER_SHOW;
										
					
					var buroRequest = {
							solicitud: $rootScope.solicitudOSJson,
							consultarBuro: tipoConsulta==null? 1:tipoConsulta							
					};
					
					var buroRequestEncrypt = securityService.cifrarRsaRequest(JSON.stringify(buroRequest));
					$rootScope.seConsultoBuro=true;
					var url = endPointConfigService.obtenerRutaEndPoint("hacerConsultaOS");				
					REST.callHttp(url, buroRequestEncrypt, 'POST','application/json','application/json',120000)
					    .then(
							function(exitoburo){
								
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								
								if( exitoburo.data.codigo == RESPONSE_CODIGO_EXITO ){
									
									var responseJson = JSON.parse(exitoburo.data.respuesta);
									$rootScope.buroConditional = responseJson.codigo;
									var typeAuth = null;
								
									switch( responseJson.codigo ){
									
										case ERROR_BURO_SERVICIO: 
												$rootScope.termometroHandlerOS = BURO_RESPUESTAWS_ERROR;
												if( buroPath.nombrePath != "/ochoPasosOS" ){
													generalServiceOS.locationPath( "/ochoPasosOS" );
												}
											break;
										case ERROR_BURO_SECCIONES_INCOMPLETAS:
												$rootScope.termometroHandlerOS = BURO_RESPUESTAWS_ERROR;
												if( buroPath.nombrePath != "/ochoPasosOS" ){
													generalServiceOS.locationPath( "/ochoPasosOS" );
												}
											break;
										case ERROR_BURO_RECHAZADA:											
											  var selected = {
												originalObject: {
													idSolicitud : $rootScope.solicitudJson.idSolicitud,
													idEstatusSeguimiento: $rootScope.solicitudJson.idSeguimiento,
													fiStatusLcrID: $rootScope.solicitudJson.idEstatusLCR,
													tipoPersona: "", 
													nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre,
													apellidoPaterno: $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno,
													apellidoMaterno: $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
													celular: $rootScope.solicitudJson.cotizacion.clientes[0].celular, 
													marca: $rootScope.solicitudJson.marca,
													cu: $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
													diasRechazo: $rootScope.solicitudJson.diasRechazo,
													idCondicio: $rootScope.solicitudJson.idCondicion,
													idStstusLCR: $rootScope.solicitudJson.idEstatusLCR,
													idMotivoBloqueo: $rootScope.solicitudJson.idMotivoBloqueo,
													creditoInmediato: $rootScope.solicitudJson.creditoInmediato
												 	}
												}

											  generalService.setArrayValue("selectedBusqueda", selected);
											
											  $rootScope.message("Consulta al Buro",["Infórmale a tu cliente que su Coacreditado no califica para respaldar su crédito, es necesario presentar otro Coacreditado."], "Aceptar", "/recuperaSolicitud", colorTitDatosHogar, colorBotDatosHogar);
											break;
										case BURO_CLAVES_FRAUDE:
												$rootScope.message("Consulta al Buro",["Por favor, informa a tu cliente que estamos cuidando su historial crediticio. Es necesario que solucione su problema en el Buró de Crédito y con otras instituciones, por lo cual, no es posible continuar con la solicitud de crédito."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
											break;
										case ERROR_BURO_RECHAZADA_INGRESOS:
												$rootScope.message("Consulta al Buro",["Por favor, informa a tu cliente que estamos cuidando su historial crediticio. Es necesario que solucione su problema en el Buró de Crédito y con otras instituciones, por lo cual, no es posible continuar con la solicitud de crédito."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
											break;
										case BURO_INTENTOS_AGOTADOS_OS:
												$rootScope.message("Consulta al Buro",["Infórmale a tu cliente que su Coacreditado no califica para respaldar su crédito, por lo que la solicitud quedará rechazada."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
										    break;
										case BURO_AUTORIZADO_SCORE:
												doSuccessFn( responseJson, path, doFunction, typeAuth );
											break;
										case RESPONSE_ORIGINACION_CODIGO_EXITO:
												if(responseJson.data != null){
													$rootScope.solicitudOSJson = responseJson.data.solicitud;
													$rootScope.muestraObligadoSolidario = true;
													doSuccessFn( responseJson, path, doFunction, typeAuth );
												}else{
													$rootScope.message("Consulta al Buro",["Lo sentimos, infórmale a tu cliente que por el momento no califica para obtener un crédito en Banco Azteca."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
												}
											break;
										case BURO_RECALCULAR_PLAZO:
												typeAuth = BURO_RECALCULAR_PLAZO;
												doSuccessFn( responseJson, path, doFunction, typeAuth );								
											break;
										case BURO_AUTORIZADO_PORCOMPROBAR:
												typeAuth = BURO_AUTORIZADO_PORCOMPROBAR;
												doSuccessFn( responseJson, path, doFunction, typeAuth );
											break;
										case BURO_OBLIGADO_SOLIDARIO:
												$rootScope.muestraObligadoSolidario = true;
												typeAuth = BURO_OBLIGADO_SOLIDARIO;
												doSuccessFn( responseJson, path, doFunction, typeAuth );
											break;
										case BURO_CP_INVALIDO:
											$rootScope.message("Consulta al Buro ["+BURO_CP_INVALIDO+"]",["No se pudo consultar buró."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
										case BURO_CP_SIN_FORMATO:
											$rootScope.message("Consulta al Buro ["+BURO_CP_SIN_FORMATO+"]",["No se pudo consultar buró."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
										case BURO_CP_ERROR_PARSEO:
											$rootScope.message("Consulta al Buro ["+BURO_CP_ERROR_PARSEO+"]",["No se pudo consultar buró."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
										case BURO_CP_NOM_INCOMPLETO:
											$rootScope.message("Consulta al Buro ["+BURO_CP_NOM_INCOMPLETO+"]",["No se pudo consultar buró."], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
										default:
											$rootScope.termometroHandlerOS = BURO_RESPUESTAWS_ERROR;
											generalServiceOS.locationPath( "/ochoPasosOS" );
									}																																																
									
								}else{
//									$rootScope.message("Consulta al Buro",[ERROR_SERVICE], "Aceptar", "/ochoPasos", cssTittlo, cssbtnOk);
									$rootScope.termometroHandlerOS = BURO_RESPUESTAWS_ERROR;
									generalServiceOS.locationPath( "/ochoPasosOS" );
								}
								
																																	
							}, function(error){
								$rootScope.termometroHandlerOS = BURO_RESPUESTAWS_ERROR;
				                $rootScope.waitLoaderStatus = LOADER_HIDE;
				                if(path == null || path == undefined)
									generalServiceOS.locationPath("/ochoPasosOS");
								else
									generalServiceOS.locationPath(path);								                												
							}
					);
									
				}
			}else{
				if(generalService.validaTermino($rootScope.solicitudJson)){
					generalServiceOS.locationPath("/ochoPasosOS");
				}else{
					if(path == null || path == undefined)
						generalServiceOS.locationPath("/ochoPasosOS");
					else
						generalServiceOS.locationPath(path);
				}
					
			}
				
						
		};
		
		function consultaDomicilio(responseJson, path, doFunction, typeAuth) {
			$rootScope.waitLoaderStatus = LOADER_SHOW; 

			var idSolicitud = $rootScope.solicitudJson.idSolicitud;	

			solicitudService.consultaDomicilio(idSolicitud).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
							var solicitudJsonConsultaDomicilio = JSON.parse(data.data.respuesta);
							
							if(solicitudJsonConsultaDomicilio.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								responseJson.data.solicitud = solicitudJsonConsultaDomicilio.data;
								doSuccessFn( responseJson, path, doFunction, typeAuth );
							}else{
								$rootScope.message("Error", [solicitudJsonConsultaDomicilio.descripcion], "Aceptar");
							}
						} else {
							$rootScope.message("Error", ["Error al consultar servicio de Fonetica de Domicilio, por favor comuniquese con soporte."], "Aceptar");
						}

					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
					}
			);
		}
		
		service.productosAutorizados=function(data,descripcion){
			var banderaCanalesGS = generalService.isCanalInterno($rootScope.sucursalSession.idCanal);
			var colorTitDatosHogar=$rootScope.paginaActual=="datosHogar"?"bgRosa":$rootScope.paginaActual=="datosPersonales"?"bgNaranja":"bgAzul";
			var colorBotDatosHogar=$rootScope.paginaActual=="datosHogar"?"rosa":$rootScope.paginaActual=="datosPersonales"?"naranja":"btn gris1";
			
			var productoElegido = "préstamo personal";
			var rechazoTodosProductos = false;
			if(data){
				/*
				 * Excluye el producto cotizado y valida el color de los productos en el array de productos de rescate
				 */
				data = data.filter(function(value, index, ar){
						if(value.idProducto != $rootScope.solicitudJson.idProducto){
							return true;
						}
						return false;
					});
					if(data.length == 0){
						rechazoTodosProductos = true;
					}
				// SE COMENTA PARA QUE NO VALIDE PRODUCTOS RECHAZADOS INI
					$rootScope.rechazoBuro=true;
			}else
				rechazoTodosProductos = true;
				
			
			// SE COMENTA PARA QUE NO VALIDE PRODUCTOS RECHAZADOS FIN
			//Se valida si todos los productos son rechazados
			if (rechazoTodosProductos || !banderaCanalesGS){
				$rootScope.message("Consulta al Buró",[ (generalService.isEmpty(descripcion)?"La solicitud no fue aprobada para ningun producto.":descripcion) ], "Aceptar", "/", colorTitDatosHogar, colorBotDatosHogar);
			}else{
				var productosRescate = SUCURSALES_BURO.productosrescate.indexOf($rootScope.sucursalSession.idSucursal)!=-1?true:false;
				
//				var banderaCanalesGS = false;
//				angular.forEach(CANALESGS, function(value, key) {
//					if(value == $rootScope.sucursalSession.idCanal){
//						banderaCanalesGS = true;
//					}
//				});
				var x = 0;
				var catCssProductos=[];
				var productosAutorizados=[];
				var productosAutorizadosModal=[];
				var productos = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.CATALOGO PRODUCTOS"];
				for (var i=0;i < data.length;i++){
					if(data[i].idProducto != ID_PRODUCTO.tarjetaazteca){
						for(var a=0;a < productos.length;a++){
							if(data[i].idProducto == parseInt(productos[a].ID.valor)){
								productosAutorizados[x]=productos[a];
								break;
							}
						}
						$rootScope.productosAutorizados[x]=data[i];
						x++;
					}
				}
				
				for(var j=0;j<productos.length;j++){
					if($rootScope.solicitudJson.idProducto == parseInt(productos[j].ID.valor)){
						productoElegido = productos[j].ETIQUETA.valor;
						break;
					}									
				}
				
				for (var i=0; i<productosAutorizados.length; i++){
					var productId = parseInt(productosAutorizados[i].ID.valor);
					var estiloProducto = productosAutorizados[i].ETIQUETA.valor.replace(/\s/g,"");
					estiloProducto=productId==ID_PRODUCTO.prestamospersonales?"prestamospersonales":productId==ID_PRODUCTO.modatelas?"tarjetaazteca":estiloProducto;
					catCssProductos[i]=estiloProducto.toLowerCase();
					productosAutorizadosModal.push( { liId:catCssProductos[i], radioLabel:productosAutorizados[i].ETIQUETA.valor, radioId:"opc-producto-"+(i+1), radioValue:productId, disable:'false' } );
				}
				$rootScope.idProductoAvisoModal=$rootScope.solicitudJson.idProducto;
//					var msnModal="Infórmale a tu cliente que por el momento no es candidato para "+productoElegido+"; sin embargo,"
				var msnModal="Infórmale a tu cliente que el producto "+productoElegido+" no fue autorizado, pero después de una visita de verificación en su domicilio podría ser aprobado un crédito para:";
// I-MODIFICACION TDC (PARAMETRIZAR EL MENSAJE DE PARA PRODUCTOS DE TARJETA)								
				var titulo = "Aviso Importante";
				var btn = "Cotizar después";
				var color = "btn gris1";
				var msnModal2 = ""; 
				if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
					msnModal="<div style='font-size:20px'><b>Infórmale a "+ $rootScope.nombreCamelOS + " " + $rootScope.apellidoPaternoCamelOS + " " + $rootScope.apellidoMaternoCamelOS+"</b></div>"; 
					titulo = "AVISO";
					btn = "Terminar";
					color = "btn Azul"
					msnModal2 = "Que por el momento no podemos otorgarle una "+ productoElegido + ".";
				}
				modalService.avisoProductos(titulo,[msnModal, msnModal2],btn,"bgAzul",color,null,null,"12345",productosAutorizadosModal)
// F-MODIFICACION TDC (PARAMETRIZAR EL MENSAJE DE PARA PRODUCTOS DE TARJETA)													
				.closePromise.then(
					function(exito){
						if($rootScope.idProductoAvisoModal != $rootScope.solicitudJson.idProducto){
							$rootScope.idProductoAvisoModal=$rootScope.solicitudJson.idProducto;
						}else{
							generalService.cleanRootScope($rootScope);
							generalService.buildSolicitudJson($rootScope, null);
						}
						
						generalServiceOS.locationPath( "/simulador" );
					},function(error){
						$rootScope.solicitudJson.idProducto=$rootScope.idProductoAvisoModal;
					});
				
			}
		};
		
		
		var doOnSuccessFnBack = function( arrayPlazos, capacidadesPagoProducto , doFunction, argsFn )
		{
			
			generalService.setPlazos( $rootScope, arrayPlazos, argsFn );
			$rootScope.capacidadesPagoProducto=capacidadesPagoProducto;
			$rootScope.termometroHandlerOS = BURO_RESPUESTAWS_OK;
			$rootScope.onceOfert = true;
			
			if( doFunction && doFunction != null ){
				
				if( argsFn != null && argsFn )
					doFunction( argsFn );
				else
					doFunction();
				
				return true;
				
			}
			
		};
		
		var doSuccessFn = function( responseJson, path, doFunction, argsFn )
		{
			
			//$rootScope.solicitudOSJson = responseJson.data.solicitud;
			//$rootScope.mostrarOfertaCotizador = true;
			//if(generalService.sobrescribeOfertaBuroConsumo($rootScope.solicitudOSJson))
			//	argsFn=RESPONSE_ORIGINACION_CODIGO_EXITO;
			
			//doOnSuccessFnBack( responseJson.data.plazosTermometro, responseJson.data.capacidadesPagoProducto, doFunction, argsFn );
			
			if(path == null || path == undefined)
				generalServiceOS.locationPath("/ochoPasosOS");
			else
				generalServiceOS.locationPath(path);

		};
		
				
		return service; 
				
	});


});