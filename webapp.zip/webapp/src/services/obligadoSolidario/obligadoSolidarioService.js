'use strict';

define(["app"], function (app) {

	app.factory("obligadoSolidarioService", function(endPointConfigService, REST, securityService){
		
		
		var service = {};
		
		service.getHomonimosOS = function(jsonRequest){	  			
			var url = endPointConfigService.obtenerRutaEndPoint("validarStatusLcrOS");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};		
		service.consultaFolioCUOS = function(homonimosOSJson){
			var url = endPointConfigService.obtenerRutaEndPoint("consultaFolioCUOS");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosOSJson)), 'POST','application/json','application/json');
		};
		
		service.obtenerFolioCallCenterOS = function(jsonCode){	            
			var url = endPointConfigService.obtenerRutaEndPoint("obtenerFolioCallCenterOS");    			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonCode)), 'POST', 'application/json','application/json');	      
		};
		
		service.busquedaHomonimosOS = function(homonimosOSJson){
			var url = endPointConfigService.obtenerRutaEndPoint("busquedaHomonimosOS");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosOSJson)), 'POST','application/json','application/json');
		};
		
		service.buscarCUOS = function(homonimosOSJson){
			var url = endPointConfigService.obtenerRutaEndPoint("buscarCUOS");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosOSJson)), 'POST','application/json','application/json');
		};
		
		service.guardaSeccionOS = function(homonimosOSJson){
			var url = endPointConfigService.obtenerRutaEndPoint("guardaSeccionOS");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosOSJson)), 'POST','application/json','application/json');
		};
		
		service.guardaFirmasBiometricosOS = function(homonimosOSJson){
			var url = endPointConfigService.obtenerRutaEndPoint("guardaFirmasBiometricosOS");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosOSJson)), 'POST','application/json','application/json');
		};
		
		service.buscarSolicitudOS = function(homonimosOSJson){
			var url = endPointConfigService.obtenerRutaEndPoint("buscarSolicitudOS");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosOSJson)), 'POST','application/json','application/json');
		};
		
		service.agendarCitaOS = function(homonimosOSJson){
			var url = endPointConfigService.obtenerRutaEndPoint("agendarCitaOS");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosOSJson)), 'POST','application/json','application/json');
		};
		
		service.digitalizarImagenOS = function(homonimosOSJson){
			var url = endPointConfigService.obtenerRutaEndPoint("digitalizarImagenOS");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosOSJson)), 'POST','application/json','application/json');
		};
		
		service.actualizarStatusOS = function(homonimosOSJson){
			var url = endPointConfigService.obtenerRutaEndPoint("actualizarStatusOS");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosOSJson)), 'POST','application/json','application/json');
		};
		
		service.digitalizarImagenOS = function(homonimosOSJson){
			var url = endPointConfigService.obtenerRutaEndPoint("digitalizarImagenOS");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosOSJson)), 'POST','application/json','application/json');
		};
		
		service.obtenerDatosOS = function(homonimosOSJson){
			var url = endPointConfigService.obtenerRutaEndPoint("obtenerDatosOS");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosOSJson)), 'POST','application/json','application/json');
		};
		
		service.fotoAsesorOS = function(homonimosOSJson){
			var url = endPointConfigService.obtenerRutaEndPoint("fotoAsesorOS");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(homonimosOSJson)), 'POST','application/json','application/json');
		};
		
		service.recuperaFirmasOS = function(recuperarFirmas){
			var url = endPointConfigService.obtenerRutaEndPoint("recuperaFirmasOS");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(recuperarFirmas)), 'POST','application/json','application/json');
		};
		
		service.validarContratosDigitalizadosOS = function(jsonSolicitud){
			var url = endPointConfigService.obtenerRutaEndPoint("validarContratosDigitalizadosOS");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonSolicitud)), 'POST','application/json','application/json');
		};
		
		return service;
	});
	
});