'use strict';

define(["app"], function (app) {

	app.factory("recomiendaService", function($q, $rootScope, endPointConfigService, REST, securityService, modalService, generalService){
		
		
		var service = {};								
		/** 
		 * kori
		 */
		service.consultaServiceRecomienda = function(requestJson){				
			
			var url = endPointConfigService.obtenerRutaEndPoint("busquedaRecomienda");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json', TIME_OUT_120SEG);		
			
		};
		
		service.clienteServiceRecomienda = function(requestJson){				
			
			var url = endPointConfigService.obtenerRutaEndPoint("clienteRecomienda");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json', TIME_OUT_120SEG);		
			
		};
		service.recomiendaGana= function(jsonRequest){	
			var url = endPointConfigService.obtenerRutaEndPoint("recomiendaGana");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};	
		service.cuentasRecomienda= function(jsonRequest){	
			var url = endPointConfigService.obtenerRutaEndPoint("cuentasRecomienda");              
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};	
		
		service.informeRecomendado= function(jsonRequest){	
			var url = endPointConfigService.obtenerRutaEndPoint("informeRecomendado");              
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.guardarFolioRecomendador= function(jsonRequest){	
			var url = endPointConfigService.obtenerRutaEndPoint("guardarFolioRecomendador");              
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.validarFolio= function(jsonRequest){	
			var url = endPointConfigService.obtenerRutaEndPoint("validarFolio");              
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.enviarFolioCelular= function(jsonRequest){	
			var url = endPointConfigService.obtenerRutaEndPoint("enviarFolioCelular");              
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		return service; 
				
	});


});