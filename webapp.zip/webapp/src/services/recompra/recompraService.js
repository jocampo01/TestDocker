'use strict';

define(["app"], function (app) {

	app.factory("recompraService", function($q, $rootScope, endPointConfigService, REST, securityService, modalService, generalService){
		
		
		var service = {};								
		/** 
		 * kori
		 */
		service.consultaServiceRecompra = function(requestJson){				
			
			var url = endPointConfigService.obtenerRutaEndPoint("busquedaRecompra");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
			
		};
		
		service.clienteServiceRecompra = function(requestJson){				
			
			var url = endPointConfigService.obtenerRutaEndPoint("clienteRecompra");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
			
		};

		
		return service; 
				
	});


});