'use strict';

define(["app"], function (app) {

	app.factory("referenciasService", function(endPointConfigService, REST){
		
		
		var service = {};
		
		service.setReferencias = function(xml){	            
			var url = endPointConfigService.obtenerRutaEndPoint("setReferencias");    
			var parametros = "celularCte=5533662211&xmlReferencias="+xml;
			return REST.callHttp(url, parametros, 'POST', 'application/xml; charset=utf-8','application/json');	                              
		};
			
		service.exampleXMLget = function(xml){	            
			var url = endPointConfigService.obtenerRutaEndPoint("exampleXMLget")+"?xml="+xml+"&cel=45781659";
			return REST.callHttp(url, '', 'GET', 'application/x-www-form-urlencoded','');	                              
		};
		
		
		service.exampleXMLpost = function(xml){	            
			var url = endPointConfigService.obtenerRutaEndPoint("exampleXMLpost");   
			var parametros = "xml="+xml+"&cel=45781659";
			return REST.callHttp(url, parametros, 'POST', 'application/xml; charset=utf-8','');	                              
		};
		
		return service; 
				
	});
	
});