'use strict';

define(["app"], function (app) {
	

	app.service('securityService', [function (){	
		
		var _key;
		var _iv;
		var pubRSA="MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAq7Fz4N56KXAPwy0Qv/pR xA94wF+SR0kf0XLLsid98zqUKqlbhwjg1P+DR3hF+DS+9QNFnovSoFu/Db1evsmR 9vTgJ+2nkFhQy2aSV/cOjzNomZKTB2lNKPzkRz1kBHS7+5mSTtJoj51JoZIKKfUI yz3NxGNo6xvTzP7AS+T2VINv2+hFo4DEmuBoUSEBk7vyqERSLWdVLc36j4qyVSk2 kuEM4fCgm/5Kf3epwvCyiBY8GUKLUQ7kWJg5iZZt9eTKMFMVWX5aRTPZoFx+cR2+ 6jlM+r+kUNVyVom0WYDlmtqPlV/WXjx96qXbp2OHqSgtgTuLk81ihmiFpYhkGReT 5wIDAQAB";
		var secret = "MM2DGZBRORHHAQ2D";
		 
		var _setKeys = function(key, iv){			
			_key = key;
			_iv = iv;
		};
		
		var _getKey = function(){
			return  _key;			
		};
		
		var _getIV = function(){
			return  _iv;			
		};
		
		
		/** Encripta una cadena */
		var _encryptAES_value = function(value){
			var key = CryptoJS.enc.Base64.parse(_key);			
			var iv = CryptoJS.enc.Base64.parse(_iv);
			
			value = value.replace(/Ñ/g,"<N>");			
			
			var fecha = new Date();						
			value += '<>'+fecha.getMinutes()+fecha.getSeconds();
			
			var textencryipted = CryptoJS.AES.encrypt(value.toString() , key, { mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7, iv: iv,  });	
			var encrypt2Value = CryptoJS.AES.encrypt(value.toString()+'<>'+textencryipted.toString() , key, { mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7, iv: iv,  });
			
			return encrypt2Value.toString();
		}
		
		
		/** Encripta una cadena */
		var _decryptAES_value = function(value){
			var key = CryptoJS.enc.Base64.parse("MFIxRzFONEMxME5DM0I0Wg==");			
			var iv = CryptoJS.enc.Base64.parse("MFIxRzFONEMxME5DM0I0Wg==");
														
			var plaintext = CryptoJS.AES.decrypt(value.toString() , key, { mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7, iv: iv });	
						
			return plaintext.toString(CryptoJS.enc.Utf8);
		}
		
		/** Encripta una objeto json */
		var _encrypAES_json = function(jsonObject){
			var KEY = CryptoJS.enc.Base64.parse(_key);			
			var IV = CryptoJS.enc.Base64.parse(_iv);
			var jsonEncrypt = {};
			
			for (var key in jsonObject) {
				   if (jsonObject.hasOwnProperty(key)) {
					   var value = jsonObject[key];
					   
					    if( value != null && value.toString().length > 0){
					    	value = value.toString();
					    	
					    	value = value.replace( /Ñ/g,"<N>");					    	
					    	
					    	var fecha = new Date();						
							value += '<>'+fecha.getMinutes()+fecha.getSeconds();
    					    
					        var encryptValue = CryptoJS.AES.encrypt(value , KEY, { mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7, iv: IV,  });
					        var encrypt2Value = CryptoJS.AES.encrypt(value +'<>'+encryptValue.toString() , KEY, { mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7, iv: IV,  });
					        
					        jsonEncrypt[key] = encrypt2Value.toString();
					        
					    }else					    	
					    	jsonEncrypt[key] = '';
					    				
					    	
				    }
				}
			
								
			return jsonEncrypt;
		}
		
		var _cifrarRsaRequest=function(message){
			  var envioServicio;
			  var aleatorio=_getRandomHex(16);
			  //Base32
			  var totp = new Totp(secret);
			  var llaveAES=aleatorio+"."+totp.now();
			  var wordArray = CryptoJS.enc.Utf8.parse(llaveAES.substring(0,16));
			  //var base64Llave = CryptoJS.enc.Base64.stringify(wordArray);
			  //var key=CryptoJS.enc.Base64.parse(base64Llave);
			  //var iv=CryptoJS.enc.Base64.parse(base64Llave);
			  var key=wordArray;
			  var iv=wordArray;
			  var encryptedAES=CryptoJS.AES.encrypt(message, key, {iv: iv, padding: CryptoJS.pad.Pkcs7, mode: CryptoJS.mode.CBC});
			  var encrypt= new JSEncrypt();
			  encrypt.setPublicKey(pubRSA);
			  var llaveAESbyRSA= encrypt.encrypt(llaveAES);
			  var hashMessageSHA256=CryptoJS.SHA256(CryptoJS.enc.Utf8.parse(message));
			  
			  envioServicio= encryptedAES+"."+llaveAESbyRSA+"."+hashMessageSHA256;
			  
		  return envioServicio;
		}
		
	    var _getRandomHex= function(longitud){
	    	  return CryptoJS.enc.Hex.stringify(CryptoJS.lib.WordArray.random(256)).substring(0,longitud);
	     };

		return {	
			setKeys: _setKeys,		
			getKey: _getKey,
			getIV:_getIV,
			encryptAES_value: _encryptAES_value,
			encrypAES_json: _encrypAES_json,
			decryptAES_value: _decryptAES_value,
			cifrarRsaRequest:_cifrarRsaRequest,
			getRandomHex:_getRandomHex
		};
		
	}]);
	
});