'use strict';

define(["app"], function (app) {

	app.factory("sessionService", function($rootScope, endPointConfigService, REST, modalService, securityService, generalService){
		
		
		var service = {};
		
		service.getObjSession = function(){	            
			var url = securityService.decryptAES_value( endPointConfigService.obtenerRutaEndPoint("getObjSession"));
			return REST._noCallHttp(url, "", "GET", "application/json", "application/json");	                              
		};
		
		
		
		service.getObjSessionId = function(sessionid){	            
			var url = securityService.decryptAES_value( endPointConfigService.obtenerRutaEndPoint("getObjSession"));
			if(sessionid != null)
				url += "?ticket="+sessionid;
			
			return REST._callHttp(url, "", "GET", "application/json", "application/json");	                              
		};
		
		service.userSession = function(sessionid){
			
			var url = securityService.decryptAES_value( endPointConfigService.obtenerRutaEndPoint("userSession") );						
			if(sessionid != null)
				url += sessionid;
			
			return REST._callHttp(url, '', "GET", "", "application/json");	                              
		};
		
		
		service.getUserSession = function(sessionid){	            
			var url = securityService.decryptAES_value( endPointConfigService.obtenerRutaEndPoint("getUserSession"))+sessionid;
			return REST._callHttp(url, "", "GET", "application/json", "application/json");	                              
		};
		
		service.endSession = function(){	            
			var url = endPointConfigService.obtenerRutaEndPoint("endSession");
			//Se mandan a BD los eventos almacenados en memoria
			$rootScope.enviaEventos();
			return REST.callHttp(url, "", "GET", "", "");	                              
		};
		
		
		
		service.validaSesion = function(){	            
			var url = endPointConfigService.obtenerRutaEndPoint("validaSesion");
			REST.callHttp(url, "", "GET", "application/json", "application/json").then(
					function(_data){ //EXITO	                				                				                	
	                	if(_data.data.codigo == RESPONSE_CODIGO_EXITO){
	                		console.log("validateSession = EN SESION");
	                		
	                		$rootScope.inSession = true;
	                		$rootScope.userSession = _data.data.respuesta;             			                		
	                		
	                	}else{
	                		console.log("validateSession = NO SESION");
	                		localStorage.removeItem('paths');	    	                		
	                		
                			if( !generalService.getFlagLogin() ){
                				
                				generalService.setFlagLogin(true);
                				
                				if( configuracion.origen.tienda )
    	                			$rootScope.executeAction( "moduloTracker", "loginIpadResponse", {nombre:"login"} );
    	                		else    	                			    	                			
    	                			modalService.loginModal();
    	                			    	                				    	                		                				
                			}	                			                		                			                			                				                		
	                		
	                	}	                		
	                			
	                			                		                				                					                				                		                			                
					},function(_error){
						if(_error.status != undefined ){							
							if( _error.status == 0 && _error.config.timeout == HTTPCODE_TIMEOUT)								
								modalService.alertModal(ERROR_TIME_OUT.titulo, [ERROR_TIME_OUT.texto],"Aceptar","bgrojo","rojo");
							else
								modalService.alertModal("Error "+_error.status, [_error.statusText],"Aceptar","bgrojo","rojo");
							
						}else						
							modalService.alertModal("Error en el servidor", [_error.message],"Aceptar","bgrojo","rojo");
					}
			);                              
		};
		
		
		return service; 
				
		
	});
});