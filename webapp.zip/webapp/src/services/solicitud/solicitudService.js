'use strict';

define(["app"], function (app) {

	app.factory("solicitudService", function($q, $rootScope, endPointConfigService, REST, securityService, modalService, generalService, generalServiceOS){
		
		
		var service = {};								
		
		
		service.loadSolicitud = function(solicitudId){				
			var jsonBuro = {
					idSolicitud: solicitudId
			}
			var solicitudString = generalService.delete$$hashKey(jsonBuro);
			var url = endPointConfigService.obtenerRutaEndPoint("loadSolicitud");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(solicitudString), 'POST','application/json','application/json',TIME_OUT_180SEG);		
		};
		
		
		service.getSolicitud = function(solicitudId){				
			var url = endPointConfigService.obtenerRutaEndPoint("getSolicitud");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(solicitudId), 'POST','application/json','application/json');		
		};	
		
		
		service.getSolicitudesProceso = function(){				
			var url = endPointConfigService.obtenerRutaEndPoint("solicitudesProceso");			
			return REST.callHttp(url, null, 'GET','application/json','application/json',TIME_OUT_180SEG);		
		};	
		
		service.guardarDatosCambaceo = function (solicitudJson){
			var url = endPointConfigService.obtenerRutaEndPoint("guardarDatosCambaceo");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(solicitudJson)), 'POST','application/json','application/json');		
		}
		
		service.saveSolicitud = function(solicitudJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("saveSolicitud");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(solicitudJson)), 'POST','application/json','application/json');		
		};	
		
		
		service.liberarSolicitud = function( solicitudJson ){				
			var url = endPointConfigService.obtenerRutaEndPoint("liberarSolicitud");			
			return REST.callHttp(url,  securityService.cifrarRsaRequest(JSON.stringify(solicitudJson)), 'POST','application/json','application/json');		
		};
		
		service.rechazarSolicitud = function (solicitudJson){
			var url = endPointConfigService.obtenerRutaEndPoint("rechazarSolicitud");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(solicitudJson)), 'POST','application/json','application/json');
		}
		
		service.liberarLCR = function(solicitudJson){
			$rootScope.seEjecutoLiberacionLCR=true;
			var url = endPointConfigService.obtenerRutaEndPoint("liberarLCR");			
			return REST.callHttp(url,  securityService.cifrarRsaRequest(JSON.stringify(solicitudJson)), 'POST','application/json','application/json');
		};
		
		service.actualizarSolicitud = function( solicitudJson, proceso ){				
			var url = endPointConfigService.obtenerRutaEndPoint("actualizarSolicitud");			
			return REST.callHttp(url,  securityService.cifrarRsaRequest(JSON.stringify(solicitudJson)), 'POST','application/json','application/json',0,false,proceso);		
		};
		
		service.agendaCita = function(agendaCitaJson){				
// I-MODIFICACION TDC (APUNTAR AL SERVER DE TARJETAS)
			var URLtarjetas = false;
			if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto))
				URLtarjetas = true;
			var url = endPointConfigService.obtenerRutaEndPoint("agendaCita");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(agendaCitaJson)), 'POST','application/json','application/json',TIME_OUT_180SEG, URLtarjetas);		
// F-MODIFICACION TDC (APUNTAR AL SERVER DE TARJETAS)
		};
		
		
		service.consultaCP = function(cp){			
			var url = securityService.decryptAES_value( endPointConfigService.obtenerRutaEndPoint("consultaCP") )+"/"+cp;			
			return REST.noCallHTTP(url, '', 'GET','application/json','application/json',null,false);		
		};
		
		service.consultaDomicilio = function (idSolicitud){
			var url = securityService.decryptAES_value( endPointConfigService.obtenerRutaEndPoint("consultaDomicilio"))+"/"+idSolicitud;
			return REST.noCallHTTP(url, '', 'GET','application/json','application/json',null,false);
		}
		
		service.validaSucursal30km = function (address){							
			var url = endPointConfigService.obtenerRutaEndPoint("validaSucursal30km");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(address)), 'POST','application/json','application/json');
		}
		
		service.getDatosAsesor = function(coordenadasJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("getDatosAsesor");			
			return REST.noCallHTTP(url, securityService.cifrarRsaRequest(JSON.stringify(coordenadasJson)), 'POST','application/json','application/json');		
		};
		
		service.getDatosAsesorDisp = function(coordenadasJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("getDatosAsesorDisp");			
			return REST.noCallHTTP(url, securityService.cifrarRsaRequest(JSON.stringify(coordenadasJson)), 'POST','application/json','application/json');		
		};
		
		service.getDatosAsesorDispAgendarCita = function(coordenadasJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("getDatosAsesorDispAgendarCita");			
			return REST.noCallHTTP(url, securityService.cifrarRsaRequest(JSON.stringify(coordenadasJson)), 'POST','application/json','application/json');		
		};
		
		service.getFotoAsesor = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("fotoAsesor");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.solicitarVisitaAsesor = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("solicitarVisitaAsesor");			
			return REST.noCallHTTP(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.getFotoAsesorArq = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("obtenerFotoJV");
			url = securityService.decryptAES_value(url) + requestJson.idEmpleado + "/foto"
			return REST.noCallHTTP(url, null, 'GET','application/json','application/json',null,false);		
		};
		
		service.setDiaPago = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("setDiaPago");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		
		service.getStatusLCR = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("getStatusLCR");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
			
		
		service.updateSolicitudes = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("updateSolicitudes");			
			return REST.callHttp(url, "jsonActualizar="+JSON.stringify(requestJson), 'POST','application/x-www-form-urlencoded','application/json');		
		};
		
		service.consultarMapas = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("consultarMapas");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.citasSolicitudes = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("citasSolicitudes");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		
		service.solicitudesAsesor = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("solicitudesAsesor");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		
		service.datosPresupuesto = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("datosPresupuesto");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.validaFolioCallCenter = function(solicitudJsonRequest, solicitudJsonResponse, origen){
			
			var defered = $q.defer();
			var promise = defered.promise;
			
			if (solicitudJsonResponse && typeof solicitudJsonResponse === 'object') {
				let idSeguimiento = solicitudJsonResponse.idSeguimiento || 0;
				
				if (18 == idSeguimiento) {
					let marca = solicitudJsonResponse.marca || 0;
					let respuestaCC = solicitudJsonResponse.respuestaCallCenter || 0;
					// Cuando el path es '/simulador' la función message limpia el rootScope y la solicitud, pero...
					let postMortem = function() { generalService.buildSolicitudJson($rootScope, null); }
					
					$rootScope.message('AVISO', 
						[generalService.resCallCenter(idSeguimiento,marca,respuestaCC)], 'Aceptar', '/simulador', 
						null, // Color Modal 
						null, // Color Sección
						postMortem
					);
					
					// Se contesta con un rechazo, puesto que no se hace nada en caso de rechazo.
					defered.reject();
				}
			}
			
			if( !generalService.isEmpty(solicitudJsonResponse.folioCallCenter)){
				if( solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.CLIENTE_CORRECTO){
						
//					modalService.alertModal("Call Center",["Infórmale a tu cliente que para continuar con su proceso de solicitud de crédito es necesario que realice un mantenimiento de biométricos en sucursal."]);
					defered.resolve(null);
						
				}else if(solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.CLIENTE_INCORRECTO ){
					
					if(origen == 1) {
						modalService.alertModal("Call Center", ["El folio ya fue validado por mesa de control. Por favor continua con la captura de la solicitud."]);
					}
					defered.resolve(null);
						
				}else if(/*solicitudJsonRequest.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.SIN_RESPUESTA  &&*/  solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.IDENTIFICACION_NO_VALIDA || solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.IDENTIFICACION_COMPL_NO_VALIDA){
					var mensaje = (solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.IDENTIFICACION_COMPL_NO_VALIDA)?"No es posible continuar. La identificación complementaria presentada no es válida.":"No es posible continuar. La identificación presentada no es válida.";
					
					modalService.confirmModal("Call Center", [mensaje, "¿Desea generar un nuevo folio de Call Center?"], "Cancelar", "Aceptar").then(
						function(exito){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							
							if(solicitudJsonResponse.tipoIdentificacion != 2 && solicitudJsonResponse.tipoIdentificacion != 3){
								if($rootScope.fotoCteOriginal)
									generalService.setArrayValue("pasoCallCenter", 'IFE');
								else
									generalService.setArrayValue("pasoCallCenter", 'foto');
											
								generalService.esValidoFlujoCallCenter(solicitudJsonResponse);
								generalService.setArrayValue("encolarImagenes", false);
								defered.resolve("/callCenter");
							}else{
								generalService.esValidoFlujoCallCenter(solicitudJsonResponse);
								generalService.setArrayValue("pasoCallCenter", 'init');
								generalService.setArrayValue("encolarImagenes", true);
								generalService.setArrayValue("pathOrigen", 'visorAsesor');
								generalService.setArrayValue("solicitarIDComplementaria", true);
								generalService.locationPath("/callCenter");		  
							}
						},function(error){
							generalService.cleanRootScope($rootScope);
							generalService.buildSolicitudJson($rootScope, null );
							defered.resolve("/");	  														
						}
					);

					
				}else if(solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.NACIONALIDAD_BLOQUEADA){
					generalService.cleanRootScope($rootScope);
				    generalService.buildSolicitudJson($rootScope, null );
				    modalService.alertModal("Call Center", ["Nacionalidad Bloqueada"]);
				    defered.resolve("/");
				    
				}else if( (solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.INCONSISTENCIA_DATOS ||  
						   solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.DATOS_NO_COINCIDEN) ){
					
					generalService.cleanRootScope($rootScope);
				    generalService.buildSolicitudJson($rootScope, null );
				    
				    try{        				
        				$rootScope.solicitudJson.cotizacion.clientes[0].nombre = solicitudJsonResponse.cotizacion.clientes[0].nombre;
            			$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno = solicitudJsonResponse.cotizacion.clientes[0].apellidoMaterno;
            			$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno = solicitudJsonResponse.cotizacion.clientes[0].apellidoPaterno;					                			
            			$rootScope.solicitudJson.cotizacion.clientes[0].idGenero = solicitudJsonResponse.cotizacion.clientes[0].idGenero;
	 					$rootScope.solicitudJson.cotizacion.clientes[0].genero = solicitudJsonResponse.cotizacion.clientes[0].genero;		        	 					
	 					$rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento = solicitudJsonResponse.cotizacion.clientes[0].fechaNaciomiento;
	 					$rootScope.solicitudJson.cotizacion.clientes[0].celular = solicitudJsonResponse.cotizacion.clientes[0].celular;
	 					generalService.setArrayValue("solicitudRecuperada", true);
	 					
        			}catch(e){ }
        			
        			switch(solicitudJsonResponse.respuestaCallCenter){
	        			case STATUS_CALL_CENTER_RESPONSE.INCONSISTENCIA_DATOS:
	        				generalService.cleanRootScope($rootScope);
	    				    generalService.buildSolicitudJson($rootScope, null );
	        				modalService.alertModal("Call Center", ["Los datos capturados son incorrectos, favor de validarlos."]);
	        				break;
	        			case STATUS_CALL_CENTER_RESPONSE.DATOS_NO_COINCIDEN:	
	        				generalService.cleanRootScope($rootScope);
	    				    generalService.buildSolicitudJson($rootScope, null );
	        				modalService.alertModal("Call Center", ["Los datos capturados son incorrectos, favor de validarlos."]);
	        				break;
	    			}
				    
				    defered.resolve("/simulador");
				    
				}else if(solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.CTE_EXISTE_MAZ){
					var nombreCte = solicitudJsonResponse.cotizacion.clientes[0].nombre+' '+ 
									solicitudJsonResponse.cotizacion.clientes[0].apellidoPaterno+' '+
									solicitudJsonResponse.cotizacion.clientes[0].apellidoMaterno;
					modalService.alertModal("AVISO",["No es posible continuar con la solicitud ya que el cliente  "+nombreCte+"  es un cliente Activo en Micronegocio"], "Aceptar");
					generalService.cleanRootScope($rootScope);
				    generalService.buildSolicitudJson($rootScope, null );
					defered.resolve("/simulador");
					
				}else if(solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.CTE_LCR_AUTORIZADA){																		
					generalService.setDataBridge( { origen    : FICHA.origen.recuperar } );
					defered.resolve("/ficha");
					
				}else if(solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.FOLIO_VENCIDO){
					var mensaje = "El folio a mesa de crédito no pudo ser validado, es necesario generar uno nuevo";
					
					modalService.confirmModal("Call Center", [mensaje, "¿Desea generar un nuevo folio de Call Center?"], "Cancelar", "Aceptar").then(
						function(exito){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							
							if(solicitudJsonResponse.tipoIdentificacion != 2 && solicitudJsonResponse.tipoIdentificacion != 3){
								if($rootScope.fotoCteOriginal)
									generalService.setArrayValue("pasoCallCenter", 'IFE');
								else
									generalService.setArrayValue("pasoCallCenter", 'foto');
											
								generalService.esValidoFlujoCallCenter(solicitudJsonResponse);
								generalService.setArrayValue("encolarImagenes", false);
								defered.resolve("/callCenter");
							}else{
								generalService.esValidoFlujoCallCenter(solicitudJsonResponse);
								generalService.setArrayValue("pasoCallCenter", 'init');
								generalService.setArrayValue("encolarImagenes", true);
								generalService.setArrayValue("pathOrigen", 'visorAsesor');
								generalService.setArrayValue("solicitarIDComplementaria", true);
								generalService.locationPath("/callCenter");		  
							}
						},function(error){
							generalService.cleanRootScope($rootScope);
							generalService.buildSolicitudJson($rootScope, null );
							defered.resolve("/");	  														
						}
					);
				}else
					defered.resolve(null);
					
			}else
				defered.resolve(null);
				
						
			return promise;
		}
		
		service.validaFolioCallCenterOS = function(solicitudJsonRequest, solicitudJsonResponse, origen){
			
			var defered = $q.defer();
			var promise = defered.promise;
						
			if( !generalService.isEmpty(solicitudJsonResponse.folioCallCenter)){
				if( solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.CLIENTE_CORRECTO){
						
//					modalService.alertModal("Call Center",["Infórmale al Coacreditado que para continuar con su proceso de solicitud de crédito es necesario que realice un mantenimiento de biométricos en sucursal."]);
					defered.resolve(null);
						
				}else if(solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.CLIENTE_INCORRECTO ){
					
					if(origen == 1) {
						modalService.alertModal("Call Center", ["El folio ya fue validado por mesa de control. Por favor continua con la captura de la solicitud."]);
					}
					defered.resolve("/ochoPasosOS");
						
				}else if(/*solicitudJsonRequest.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.SIN_RESPUESTA  &&*/  solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.IDENTIFICACION_NO_VALIDA || solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.IDENTIFICACION_COMPL_NO_VALIDA){
					var mensaje = (solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.IDENTIFICACION_COMPL_NO_VALIDA)?"No es posible continuar. La identificación complementaria presentada por el Coacreditado no es válida.":"No es posible continuar. La identificación presentada por el Coacreditado no es válida.";
					
					modalService.confirmModal("Call Center", [mensaje, "¿Desea generar un nuevo folio de Call Center?"], 
			                  "Cancelar", "Aceptar").then(
									  function(exito){
										  if(solicitudJsonResponse.tipoIdentificacion != 2 && solicitudJsonResponse.tipoIdentificacion != 3){
											  if($rootScope.fotoCteOriginalOS)
												  generalService.setArrayValue("pasoCallCenter", 'IFE');
											  else
												  generalService.setArrayValue("pasoCallCenter", 'foto');
												
//											  generalService.setArrayValue("encolarImagenes", false);
											  defered.resolve("/callCenterOS");
										  }else{
												generalService.esValidoFlujoCallCenter(solicitudJsonResponse);
												generalService.setArrayValue("pasoCallCenter", 'init');
												generalService.setArrayValue("encolarImagenes", true);
												generalService.setArrayValue("pathOrigen", 'visorAsesor');
												generalService.setArrayValue("solicitarIDComplementaria", true);
												generalService.locationPath("/callCenterOS");		  
											}
									  },function(error){
//										  generalServiceOS.cleanRootScopeOS($rootScope);
//										  generalServiceOS.buildSolicitudOSJson($rootScope, null );
										  defered.resolve("/ochoPasos");	  														
									  }
					);

					
				}else if(solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.NACIONALIDAD_BLOQUEADA){
					generalServiceOS.cleanRootScopeOS($rootScope);
					generalServiceOS.buildSolicitudOSJson($rootScope, null );
				    modalService.alertModal("Call Center", ["Nacionalidad Bloqueada"]);
				    defered.resolve("/ochoPasos");
				    
				}else if( (solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.INCONSISTENCIA_DATOS ||  
						   solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.DATOS_NO_COINCIDEN) ){
					
					generalServiceOS.cleanRootScopeOS($rootScope);
					generalServiceOS.buildSolicitudOSJson($rootScope, null );
				    
//				    try{        				
//        				$rootScope.solicitudOSJson.cotizacion.clientes[0].nombre = solicitudJsonResponse.cotizacion.clientes[0].nombre;
//            			$rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno = solicitudJsonResponse.cotizacion.clientes[0].apellidoMaterno;
//            			$rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno = solicitudJsonResponse.cotizacion.clientes[0].apellidoPaterno;					                			
//            			$rootScope.solicitudOSJson.cotizacion.clientes[0].idGenero = solicitudJsonResponse.cotizacion.clientes[0].idGenero;
//	 					$rootScope.solicitudOSJson.cotizacion.clientes[0].genero = solicitudJsonResponse.cotizacion.clientes[0].genero;		        	 					
//	 					$rootScope.solicitudOSJson.cotizacion.clientes[0].fechaNaciomiento = solicitudJsonResponse.cotizacion.clientes[0].fechaNaciomiento;
//	 					$rootScope.solicitudOSJson.cotizacion.clientes[0].celular = solicitudJsonResponse.cotizacion.clientes[0].celular;
//	 					generalService.setArrayValue("solicitudRecuperada", true);
//	 					
//        			}catch(e){ }
//        			
        			switch(solicitudJsonResponse.respuestaCallCenter){
	        			case STATUS_CALL_CENTER_RESPONSE.INCONSISTENCIA_DATOS:
	        				generalService.cleanRootScope($rootScope);
	    				    generalService.buildSolicitudJson($rootScope, null );
	        				modalService.alertModal("Call Center", ["Los datos capturados del Coacreditado son incorrectos, favor de validarlos."]);
	        				break;
	        			case STATUS_CALL_CENTER_RESPONSE.DATOS_NO_COINCIDEN:	
	        				generalService.cleanRootScope($rootScope);
	    				    generalService.buildSolicitudJson($rootScope, null );
	        				modalService.alertModal("Call Center", ["Los datos capturados del Coacreditado son incorrectos, favor de validarlos."]);
	        				break;
	    			}
				    
				    defered.resolve("/ochoPasos");
				    
				}else if(solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.CTE_EXISTE_MAZ){
					var nombreCte = solicitudJsonResponse.cotizacion.clientes[0].nombre+' '+ 
									solicitudJsonResponse.cotizacion.clientes[0].apellidoPaterno+' '+
									solicitudJsonResponse.cotizacion.clientes[0].apellidoMaterno;
					modalService.alertModal("AVISO",["No es posible continuar con la solicitud ya que el Coacreditado "+nombreCte+"  es un cliente Activo en Micronegocio"], "Aceptar");
					generalServiceOS.cleanRootScopeOS($rootScope);
					generalServiceOS.buildSolicitudOSJson($rootScope, null );
					defered.resolve("/ochoPasos");
					
				}else if(solicitudJsonResponse.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.FOLIO_VENCIDO){
					var mensaje = "El folio a mesa de crédito no pudo ser validado, es necesario generar uno nuevo";
					
					modalService.confirmModal("Call Center", [mensaje, "¿Desea generar un nuevo folio de Call Center?"], 
			                  "Cancelar", "Aceptar").then(
									  function(exito){
										  if(solicitudJsonResponse.tipoIdentificacion != 2 && solicitudJsonResponse.tipoIdentificacion != 3){
											  if($rootScope.fotoCteOriginalOS)
												  generalService.setArrayValue("pasoCallCenter", 'IFE');
											  else
												  generalService.setArrayValue("pasoCallCenter", 'foto');
												
//											  generalService.setArrayValue("encolarImagenes", false);
											  defered.resolve("/callCenterOS");
										  }else{
												generalService.esValidoFlujoCallCenter(solicitudJsonResponse);
												generalService.setArrayValue("pasoCallCenter", 'init');
												generalService.setArrayValue("encolarImagenes", true);
												generalService.setArrayValue("pathOrigen", 'visorAsesor');
												generalService.setArrayValue("solicitarIDComplementaria", true);
												generalService.locationPath("/callCenterOS");		  
											}
									  },function(error){
//										  generalServiceOS.cleanRootScopeOS($rootScope);
//										  generalServiceOS.buildSolicitudOSJson($rootScope, null );
										  defered.resolve("/ochoPasos");	  														
									  }
					);
				}else
					defered.resolve(null);
					
			}else
				defered.resolve(null);
				
						
			return promise;
		}
		
		
		service.generaSolicRechazada = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("generaSolicRechazada");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');				
		};
		
		service.validaSolicRechazada = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("validaSolicRechazada");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');				
		};

		service.getDatosLcrAutorizada = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("getDatosLcrAutorizada");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.getDatosLcrBloqueada = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("getDatosLcrBloqueada");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.loggerFront = function(requestJson){
			requestJson = { "objeto": requestJson };
			var url = endPointConfigService.obtenerRutaEndPoint("loggerFront");			
			return REST.noCallHTTP(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.cancelarSolicitud = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("cancelarSolicitud");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.actualizaProducto = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("actualizaProducto");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.getSucursal = function(proceso){				
			var url = endPointConfigService.obtenerRutaEndPoint("sucursalInfo");                  
			return REST.noCallHTTP(url, null, 'GET','application/json','application/json', null, null, proceso);	                              
		};
		
		service.getSucursalPorId = function(requestJson) {				
			var suc = requestJson.idSucursal;
			var canal = requestJson.idCanal;
			var url = securityService.decryptAES_value(endPointConfigService.obtenerRutaEndPoint("sucursalInfoPorId"))+"/"+suc+"/"+canal;
			
			return REST.noCallHTTP(url, '', 'GET','application/json','application/json',null,false);
		};
		
		service.dispersionTarjeta = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("dispersionTarjeta");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.liberarPedidoSinTAZ = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("liberarPedidoSinTAZ");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		
		service.getSolicitudByCode = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("getSolicitudByCode");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		
		service.guardaTarjeta = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("guardaTarjeta");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.buscaTarjeta = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("buscaTarjeta");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.ligaFolioUnico = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("ligaFolioUnico");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.guardarDatosLiberacion = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("guardaLiberacionFolioUnico");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.actualizaMarca = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("actualizaMarca");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.getCampania = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("getCampania");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.rechazoGerente = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("rechazoSolicitudGerente");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.enviarRechazoGerenteMCO = function(idSolicitud){			
			var url = securityService.decryptAES_value( endPointConfigService.obtenerRutaEndPoint("enviarRechazoGerenteMCO") )+"/"+idSolicitud;			
			return REST.noCallHTTP(url, '', 'GET','application/json','application/json',null,false);		
		};		
		
		service.envioMensaje = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("envioMensaje");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.getSucursalBig = function(requestJson) {				
			var url = endPointConfigService.obtenerRutaEndPoint("getSucursalBig");
			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)),
					 'POST','application/json','application/json');
		};
		
		service.enviarIngresosCompMayoresA20k = function(idSolicitud){				
			var url = securityService.decryptAES_value( endPointConfigService.obtenerRutaEndPoint("enviarIngresosCompMayoresA20k") )+"/"+idSolicitud;			
			return REST.noCallHTTP(url, '', 'GET','application/json','application/json',null,false);		
		};
		
		/**
		 * Servicio para obtener la bateria de preguntas del cliente
		 **/
		service.obtenerBateriaPreguntasRespuestas = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("obtenerBateriaPreguntasRespuestas");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		/**
		 * Servicio para guardar la bateria de preguntas del cliente
		 **/
		service.guardarBateriaPreguntas = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("guardarBateriaPreguntas");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.capacidadPago = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("capacidadPago");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.promoCreditoRegistrar = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("promoCreditoRegistrar");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		/**
		 * Método para la generación del Aviso de Privacidad Rechazo RENAPO.
		 * 
		 * El jsonRequest debe tener la siguiente forma:
		 * {
		 * 		"jsonSolicitud": JSON.stringify(jsonSolicitud),
		 *		"fotoB64": cadena_fotoB64
		 * }
		 * 
		 */
		service.generarAvisoPrivacidadRechazoRENAPO = function(requestJson) {
			var url = endPointConfigService.obtenerRutaEndPoint("generaAPRechazoRENAPO");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 
					'POST', 'application/json', 'application/json');
		}
		
		service.obtenerSolicitudesPorNombre = function(requestJson){
        	//Se mandan a BD los eventos almacenados en memoria
			$rootScope.enviaEventos();
			var url = endPointConfigService.obtenerRutaEndPoint("obtenerSolicitudesPorNombre");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.migracionSolicitudNuevaSucursal = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("migracionSolicitudNuevaSucursal");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.consultarIne = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("consultarIne");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.guardarPresupuesto = function(requestJson,proceso){
			generalService.generaGuardadoCotizacion(requestJson);
			if($rootScope.JsonCotizacion != null)
				requestJson["bitacoraCotizacion"] = JSON.stringify($rootScope.JsonCotizacion);
			var url = endPointConfigService.obtenerRutaEndPoint("guardarPresupuesto");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json',0,false,proceso);		
		};

		
// I-MODIFICACION REACTIVADO		
		service.consultaReactivado= function(jsonRequest){	
			var url = endPointConfigService.obtenerRutaEndPoint("consultaReactivado");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',TIME_OUT_60SEG, false);	                              
		};
		
		service.actualizaReactivado= function(jsonRequest){	
			var url = endPointConfigService.obtenerRutaEndPoint("actualizaReactivado");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',TIME_OUT_60SEG, false);	                              
		};	
// F-MODIFICACION REACTIVADO
		
// I - INCIDENCIAS
		service.altaDinamicaIncidencias = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("altaDinamicaIncidencias");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.ObtenerUltimoDetalleGuardadoSimplificado = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("ObtenerUltimoDetalleGuardadoSimplificado");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.mtdActValSol = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("mtdActValSol");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.analizarSolicitudTienda = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("analizarSolicitudTienda");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.generarContratos = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("generarContratos");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.consultaServicioTienda = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("consultaServicioTienda");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.generaFolioMCO = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("generaFolioMCO");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
// F- INCIDENCIAS

		
// I-MODIFICACION QUITAR CAMPANA
		service.quitarCampana = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("quitarCampana");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
// F-MODIFICACION QUITAR CAMPANA

// I-MODIFICACION ACTUALIZAR CAPACIDAD DE PAGO
		service.actualizarCapacidadPago = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("actualizarCapacidadPago");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json',TIME_OUT_120SEG, true);		
		};
// I-MODIFICACION ACTUALIZAR CAPACIDAD DE PAGO
		
		/**
		* REQ 85337 servicios para reactivados MOC a MOC
		*/
		service.getSolicitudBazDig = function(solicitudId){				
			var url = endPointConfigService.obtenerRutaEndPoint("getSolicitudBazDig");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(solicitudId), 'POST','application/json','application/json');		
		};
		
		service.saveSolicitudReact = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("saveSolicitudReact");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.guardarDiaPago = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("guardarDiaPagoNvoFlujoLiberacion");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		//obtener dia de pago 
		service.obtenerDiaDePago = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("obtenerDiaDePago");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		
		service.consultarMarcas = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("consultarMarcas");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		//Servicio para actualizar CDP al cambiar oferta
		service.actualizaStatusTiendaPorCambioCDP = function( solicitudJson ){				
			var url = endPointConfigService.obtenerRutaEndPoint("actualizaStatusTiendaPorCambioCDP");			
			return REST.callHttp(url,  securityService.cifrarRsaRequest(JSON.stringify(solicitudJson)), 'POST','application/json','application/json');		
		};
		
		//Servicio para rechazar una solicitud al cambiar CDP a No comprobables y no le alcanza su CDP (flujo Ingresos Comprobables MCO)
		service.rechazoPorCambioCDP = function(idSolicitud){				
			var url = securityService.decryptAES_value( endPointConfigService.obtenerRutaEndPoint("rechazoPorCambioCDP") )+"/"+idSolicitud;			
			return REST.noCallHTTP(url, '', 'GET','application/json','application/json',null,false);		
		};
		
		//Obtener Limites de Crédito
		service.obtenerLimitesDeCredito = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("obtenerLimitesDeCredito");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		//Mandar guardar la Bitacora de Tiempos
		service.enviaEventosDeBitacoraABD = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("enviaEventosDeBitacoraABD");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.clonarArchivoTest = function(requestJson,proceso){				
			var url = endPointConfigService.obtenerRutaEndPoint("clonarArchivoTest");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json',0,false,proceso);		
		};
		
		service.consultaLineaProducto = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("consultaLineaProducto");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		/**
		* Web Service MAPS
		*/			
		service.consultaIdCartografia = function(idSolicitud){			
			var url = securityService.decryptAES_value( endPointConfigService.obtenerRutaEndPoint("consultaIdCartografia") )+"/"+idSolicitud;			
			return REST.noCallHTTP(url, '', 'GET','application/json','application/json',null,false);		
		};
		
		service.validarNumTel = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("validarNumTel");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};

//Cambios CDT - catalgos Consumo
		/**Servicios para obtener catalogos por canal*/
		service.obtenerDepartamentos = function(jsonRequest){ 
			var url = endPointConfigService.obtenerRutaEndPoint("obtenerDepartamentos");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');
		};
		
		service.obtenerProductosPorDepartamento = function(jsonRequest){ 
			var url = endPointConfigService.obtenerRutaEndPoint("obtenerProductosPorDepartamento");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');                               
		};
		
		service.guardarDetalleCotizacion = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("guardarDetalleCotizacion");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
//End - Cambios CDT - catalgos Consumo
		
		service.consultaDisponibilidadJP = function(idSolicitud){				
			var url = endPointConfigService.obtenerRutaEndPoint("consultaDisponibilidadJP");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(idSolicitud)), 'POST','application/json','application/json');		
		};
		
		service.consultaEsquemaCitas = function(idSolicitud){				
			var url = endPointConfigService.obtenerRutaEndPoint("consultaEsquemaCitas");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(idSolicitud)), 'POST','application/json','application/json');		
		};
		
		service.obtenerDatosTicket = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("obtenerDatosTicket");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.obtenerDatosEmpleadoAsesor = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("obtenerDatosEmpleadoAsesor");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.obtenerDatosVisita = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("obtenerDatosVisita");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.validarLimiteEscClientes = function(requestJson){
			var url = endPointConfigService.obtenerRutaEndPoint("validarLimiteEscClientes");
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');
		};
		
		service.guardarSeccionGuardadito = function(requestJson,proceso){				
			var url = endPointConfigService.obtenerRutaEndPoint("guardarSeccionGuardadito");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json',0,false,proceso);		
		};
		
		service.obtenerTipoVerificacion = function(idSolicitud,proceso){				
			var url = endPointConfigService.obtenerRutaEndPoint("obtenerTipoVerificacion");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(idSolicitud)), 'POST','application/json','application/json',0,false,proceso);		
		};
		
		service.segurovidamaxUnificado = function(requestJson){				
			var url = endPointConfigService.obtenerRutaEndPoint("seguroVidaMaxUnificado"); 
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');	                              
		};
		
		service.quemarFolioPreaprobado = function(requestJson,proceso){				
			var url = endPointConfigService.obtenerRutaEndPoint("quemarFolioPreaprobado");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json',0,false,proceso);		
		};
		
		service.primeroConsultaRENAPO = function(params, proceso) {
			proceso = proceso ? proceso : 'CNEE';
			
			let url;
			
			// Los parámetros llevan una CURP.
			if (params && params.curp) {
				let postergado = $q.defer();
				let promesa = postergado.promise;
				 
				url = endPointConfigService.obtenerRutaEndPoint("consulta_CURP_RENAPO");
				
				let x = securityService.cifrarRsaRequest(JSON.stringify({ curp: params.curp }));
				
				REST.callHttp(url, x, 'POST', 'application/json', 'application/json', 0, !1, proceso).then(
					function(success) {
						if (success && success.data && success.data.codigo == RESPONSE_CODIGO_EXITO) {
							let response;
							
							try {
								response = JSON.parse(success.data.respuesta);
							} catch(z) { console.log('La respuesta no es parseable, parce.'); }
							
							// El viento nos trajo algunas cositas.
							if (response && response.codigo == 2) {
								/**
								 * Buscar una discrepancia entre los parámtros provistos y lo que regresa el
								 * RENAPO. Se debe identificar la variación, puesto que es lo que se regresa como 
								 * atributos del objeto.
								 */
								
								let diff = {};
								
								// Cambios en el nombre.
								if (params.nombre && response.data && response.data.nombre 
									&& params.nombre != response.data.nombre) {
									diff.nombre = response.data.nombre;
								}
								
								// Cambios en el patronímico.
								if (params.apellidoPaterno 
									&& response.data && response.data.apellido_paterno 
									&& params.apellidoPaterno != response.data.apellido_paterno) {
									diff.apellido_paterno = response.data.apellido_paterno;
								}
								
								// Cambios en el matronímico.
								if (params.apellidoMaterno 
									&& response.data && response.data.apellido_materno 
									&& params.apellidoMaterno != response.data.apellido_materno) {
									diff.apellido_materno = response.data.apellido_materno;
								}
								
								// Cambios en el género.
								if (response.data && response.data.sexo) {
									let gender = response.data.sexo == 'H' ? 'M' : response.data.sexo == 'M' ?
										'F' : response.data.sexo;
									if (params.sexo && params.sexo != gender) {
										diff.sexo = response.data.sexo;
									}
								}
								
								// Cambios en la fecha de nacimiento.
								if (response.data && response.data.fecha_nacimiento) {
									let birthday = response.data.fecha_nacimiento;
									
									if (typeof birthday === 'string' && birthday.length > 0) {
										birthday = birthday.split('/');
										
										if (Array.isArray(birthday) && birthday.length == 3) {
											if (!isNaN(+birthday[0] + +birthday[1] + +birthday[2])) {
												birthday[0] = ('00' + +birthday[0]).slice(-2);
												birthday[1] = ('00' + +birthday[1]).slice(-2);
												birthday[2] = ('0000' + +birthday[2]).slice(-4);
						 						
												birthday = birthday[2] + '-' + birthday[1] + '-' + birthday[0];
						 					}
										}
									}
									
									if (params.fechaNacimiento && params.fechaNacimiento != birthday) {
										diff.fecha_nacimiento = response.data.fecha_nacimiento;
									}
								}
								
								// Cambios en el estado de nacimiento.
								if (+params.entidadFederativa) {
									// Por premisa, param.curp es una cadena de longitud igual a 18.
									let state = params.curp.substring(11, 13);
									let estados = [
										"NE", "AS", "BC", "BS", "CC", "CL", "CM", "CS", "CH", "DF", "DG", "GT", "GR", 
										"HG", "JC", "MC", "MN", "MS", "NT", "NL", "OC", "PL", "QT", "QR", "SP", "SL", 
										"SR", "TC", "TS", "TL", "VZ", "YN", "ZS"
									];
									
									for (let i in estados) {
										if (estados[i] == state) {
											if (i != params.entidadFederativa) {
												diff.estado_nacimiento = +i ? +i : 33; // NE - Nacido en el Extranjero.
											}
											
											break;
										}
									}
								}
								
								// Se agregó algún atributo al JSON vacío diff.
								if (typeof diff === 'object' && Object.getOwnPropertyNames(diff).length) {
									// Regresamos el caso 99 - Different.
									postergado.resolve({
										data: {
											codigo: RESPONSE_CODIGO_EXITO,
											respuesta: angular.toJson({
												codigo: 99,
												data: diff
											})
										}
									});
									
									return;
								} else { // No se detectaron diferencias.
									// Regresamos el caso de éxito.
									postergado.resolve({
										data: {
											codigo: RESPONSE_CODIGO_EXITO,
											respuesta: angular.toJson({ codigo: 2, data: {} })
										}
									});
									
									return;
								}
							}
							
							// El CURP no hizo match con las BDs de RENAPO.
							if (response && response.codigo == 661) {
								postergado.resolve({
									data: {
										codigo: RESPONSE_CODIGO_EXITO,
										respuesta: angular.toJson(response)
									}
								});
								
								return;
							}
						}
						
						// Se regresa un fracaso rotundo.
						postergado.resolve({
							data: {
								codigo: RESPONSE_CODIGO_EXITO,
								respuesta: angular.toJson({ codigo: 19031990, data: null })
							}
						});
					}, function(unsuccess) { postergado.reject(null); }
				);
				
				return promesa;
			} else {
				 url = endPointConfigService.obtenerRutaEndPoint("renapoFirst");
				
				return REST.callHttp(url, securityService.cifrarRsaRequest(angular.toJson(params)), 'POST', 
					'application/json', 'application/json', 0, false, proceso);
			}
		}
		
		service.busquedaGPS = function(address,proceso){				
			var url = endPointConfigService.obtenerRutaEndPoint("busquedaGPS");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(address)), 'POST','application/json','application/json',0,false,proceso);		
		};
		
		return service; 				
	});
});