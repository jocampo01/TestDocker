'use strict';

define(["app"], function (app) {


	app.factory("surtimientoService", function(endPointConfigService, securityService, REST){
		
		var service = {};
		
		service.consultaCuenta = function(p) {
			var url = endPointConfigService.obtenerRutaEndPoint("consultaCuentas")
			var data="ACLIENTEALNOVA="+p.cAlnova;
			return REST.callHttp(url, data, 'GET','application/x-www-form-urlencoded','application/json');
		};
		
		
		service.dispersion = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("dispersion");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json');		
		};
		
		service.consultaDispersion = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("consultaDispersion");			
			return REST.callHttp(url, requestJson, 'POST','application/json','application/json');		
		};
		
		service.ejecutaDispersion = function(requestJson){							
			var url = endPointConfigService.obtenerRutaEndPoint("ejecutaDispersion");			
			return REST.callHttp(url, requestJson, 'POST','application/json','application/json');		
		};
		
		service.consultaPromocion = function(requestJson,proceso){							
			var url = endPointConfigService.obtenerRutaEndPoint("consultaPromocion");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(requestJson)), 'POST','application/json','application/json',0,false,proceso);		
		};
			
		return service; 
				
	});
	
});