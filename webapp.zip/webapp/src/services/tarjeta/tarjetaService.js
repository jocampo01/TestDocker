'use strict';

define(["app"], function (app) {

	app.factory("tarjetaService", function(endPointConfigService, REST, securityService, $rootScope, generalService, validateService, solicitudService){
		
		
		var service = {};
				
		
		service.activaTazInstantanea = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("activaTazInstantanea");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		
		service.activarTarjetas = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("activarTarjetas");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.consultaCteAlnova = function(ctaAlnova){				
			var url = endPointConfigService.obtenerRutaEndPoint("consultaCteAlnova");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(ctaAlnova), 'POST','application/json','application/json');	                              
		};
		
		service.cambioNIP = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("cambioNIP");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.consultaTaz = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("consultaTaz");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		
		service.consultaInventario = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("consultaInventario");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		
		service.seguroVidamax = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("seguroVidamax");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.consultasCtasPP = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("consultasCtasPP");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		
		service.ligar = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("ligarTarjeta");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.guardarTarjeta = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("guardaTarjeta");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.generaFolioUnicoCE = function(jsonRequest){
			var url = endPointConfigService.obtenerRutaEndPoint("generaFolioUnicoCE");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');
		}
// I-MODIFICACION TDC (NUEVOS SERVICIOS)
		service.consultaCuentasTarjetas= function(jsonRequest){	
			var URLtarjetas = false;
			if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto))
				URLtarjetas = true;
			var url = endPointConfigService.obtenerRutaEndPoint("consultaCuentasTarjeta");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',null, URLtarjetas);	                              
		};
		service.ligarTarjetaRevolvente= function(jsonRequest){	
			var URLtarjetas = false;
			if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto))
				URLtarjetas = true;
			var url = endPointConfigService.obtenerRutaEndPoint("ligarTarjetaRevolvente");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',TIME_OUT_60SEG, URLtarjetas);	                              
		};
		
		service.evaluacionCita= function(jsonRequest){	
			var url = endPointConfigService.obtenerRutaEndPoint("evaluacionCita");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',TIME_OUT_60SEG, true);	                              
		};
		service.consultaPreaprobadosXCU= function(jsonRequest){	
			var url = endPointConfigService.obtenerRutaEndPoint("consultaPreaprobadosXCU");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',TIME_OUT_60SEG, true);	                              
		};
		service.quemarFolioPreaprobado= function(jsonRequest){	
			var url = endPointConfigService.obtenerRutaEndPoint("quemarFolioPreaprobado");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',TIME_OUT_60SEG, true);	                              
		};
		 service.consultaEmpleado= function(jsonRequest){	
				var url = endPointConfigService.obtenerRutaEndPoint("consultaEmpleado");                  
				return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',TIME_OUT_60SEG, true);	                              
		};
		service.consultaCat= function(jsonRequest){	
			var url = endPointConfigService.obtenerRutaEndPoint("consultaCat");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',TIME_OUT_60SEG, true);	                              
		};
		service.consultaPaXNombre= function(jsonRequest){	
			var url = endPointConfigService.obtenerRutaEndPoint("consultaPreaprobadosXNombre");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',TIME_OUT_60SEG, true);	                              
		};
		service.consultaStatusLCR = function (jsonRequest){
			var url = endPointConfigService.obtenerRutaEndPoint("consultarStatusLCR");			
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');		
		}
		
		service.bajarTiendaLCR= function(jsonRequest){	
			var url = endPointConfigService.obtenerRutaEndPoint("bajarTienda");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');
		};

		service.consultaInventarioTAZ = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("consultaInventarioTAZ");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		
		service.consultarCancelarTAZ = function(jsonRequest){				
			var url = endPointConfigService.obtenerRutaEndPoint("consultarCancelarTAZ");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json');	                              
		};
		service.guardarEncuestaPreaprobados = function(jsonRequest,proceso){				
			var url = endPointConfigService.obtenerRutaEndPoint("guardarEncuestaPreaprobados");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',0,false,proceso);	                              
		};
// F-MODIFICACION TDC (NUEVOS SERVICIOS)
		
		service.checkInvetario = function(solicitudJson){													
				
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				var sucursal = generalService.addZerosLeft($rootScope.sucursalSession.idSucursal, 4);
				
				var url = endPointConfigService.obtenerRutaEndPoint("checkInventario");			
				REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(solicitudJson)), 'POST','application/json','application/json')
					.then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								$rootScope.solicitudJson = JSON.parse(data.data.respuesta);
								
								if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinTaz || $rootScope.sucursalSession.idCanal==CANALES.soriana){
									var request = {
											idSolicitud: $rootScope.solicitudJson.idSolicitud,
											tarjeta: "1"
									};
									
									$rootScope.waitLoaderStatus = LOADER_SHOW;
									solicitudService.liberarLCR(request).then(
										function(data){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											
											if(data.data.codigo == RESPONSE_CODIGO_EXITO){
												var jResponse = JSON.parse(data.data.respuesta);
												
												if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
													
													$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.liberacionAplicada;
													if(generalService.flujoPorDispersion()){
														generalService.locationPath("/surtimiento");								
													}else{
														var request = {
															idSolicitud: $rootScope.solicitudJson.idSolicitud
														};
																	
														callCenterService.liberarPedidoSinTAZ( request ).then(
															function(data){
																$rootScope.waitLoaderStatus = LOADER_HIDE;
																if(data.data.codigo == RESPONSE_CODIGO_EXITO){
																	var respuesta = JSON.parse(data.data.respuesta);
																	if(respuesta.codigo == 2){
																		$rootScope.solicitudJson = respuesta.data;
																		
																		/*\Se agregan eventos para la bitacora\*/
//																		(Surtimiento)
																    	$rootScope.addEvent( BITACORA.SECCION.surtimiento.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.surtir.id, 0, BITACORA.SECCION.surtimiento.guardarEnBD );								
																		/*\Se agregan eventos para la bitacora\*/
																    	
																		generalService.locationPath("/ficha");
																	}else{
																		generalService.locationPath("/estatus");
																	}
																} else {
																	generalService.locationPath("/estatus");
																}
															}, function(error){
																generalService.locationPath("/estatus");
															}
														);
													}
												}else{
													generalService.locationPath("/estatus");
												}	
											}else{
												$rootScope.message("Error", [generalService.displayMessage(data.data.descripcion)],"Aceptar","/simulador","bgCafeZ", "cafeZ");
											}
										}
									);
								
								}else{
									generalService.locationPath("/liberacion");
								}
							}else{
								$rootScope.message( "", ["No es posible continuar con el proceso debido a que hubo un error al verificar el inventario."], "Aceptar");
								generalService.locationPath("/simulador");
							}
								
							
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 
						}
					);										
			
			return null;
		};
		
		service.consultaDatosCaratulaTDC = function (jsonParams) {
			let url = endPointConfigService.obtenerRutaEndPoint("consultaDatosCaratulaTDC");
			
			return REST.callHttp(url, securityService.cifrarRsaRequest(angular.toJson(jsonParams)), 
				'POST','application/json','application/json');
		}
		
		service.consultaCuentasCliente = function(jsonRequest,proceso){	
			var url = endPointConfigService.obtenerRutaEndPoint("consultaCuentasCliente");                  
			return REST.callHttp(url, securityService.cifrarRsaRequest(JSON.stringify(jsonRequest)), 'POST','application/json','application/json',0,false,proceso);	                              
		};
		
		return service; 
				
	});
	
});