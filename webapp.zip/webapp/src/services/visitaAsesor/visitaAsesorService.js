'use strict';

define(["app"], function (app) {


	app.factory("visitaAsesorService", function(endPointConfigService, REST){
		
		
		var service = {};
		
		service.guardaVisitaAsesor = function(p){	            
			var url = endPointConfigService.obtenerRutaEndPoint("visitaAsesor"); 
			var data="xmlProspecto="+p.xml+"&celularProspecto="+p.celular+"&emailProspecto="+p.email;
			return REST.callHttp(url,data, 'POST','application/x-www-form-urlencoded','application/json');	                              
		};
			
		
		return service; 
				
	});
	
});	