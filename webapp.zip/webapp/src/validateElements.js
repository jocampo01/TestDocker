// calcula porcentajes
function cuentatext(formulario, porcent1, campoOpc,scope){
	var els = document.getElementsByName(formulario);
	var inputs = els[0].getElementsByTagName('input');
	var total = 0;
	var convalor = 0;
	var nombreant = "";
	porcentaje = 0;
	
	for (var i=0; i < inputs.length; i++) {
		var tipos = inputs[i].getAttribute('type');
		var nombre = inputs[i].getAttribute('name');
		var opcional = inputs[i].getAttribute('opcional');
		var contenido = inputs[i].getAttribute('innerText');
		
		if  (tipos == 'text' || tipos== 'mail' || tipos== 'password' || tipos == 'number' ||
			 tipos == 'tel'  || tipos == 'date'|| tipos == 'email'   || tipos == 'file') {
			if (opcional != 'true'){
				var selection = inputs[i].getAttribute('selection');
				if (selection == "true"){
					valorSel  = inputs[i].previousElementSibling.innerText														
				}else{
					valorSel = inputs[i].value;
				}
				
				total = total + 1
				var vacio = true;
				for (var O = 0; O < valorSel.length; O++ ) {
					if (valorSel.charAt(O) != " " ) {
						vacio = false;      
					}
				}
				if (!(vacio || valorSel == null)){
					convalor = convalor + 1;
					var valorrr = inputs[i].value 
				}else{
					if(campoOpc)
						scope.$eval(formulario+"."+nombre+".$invalid=true");
				}
			}
			
		}
		if (tipos == "radio" || tipos == "checkbox"){
			if (opcional != 'true'){
				if (nombre != nombreant){	    				
					total = total + 1
				}
				if (inputs[i].checked==true){
					convalor = convalor + 1;
				}
				nombreant = nombre;
			}
		}
	}
	
	
	 var inputs = els[0].getElementsByTagName('select');
				 
	 for (var i=0; i < inputs.length; i++) {
		   var tipos = inputs[i].getAttribute('type');
		   var nombre = inputs[i].getAttribute('name');	
		   var opcional = inputs[i].getAttribute('opcional');
		   if (opcional != 'true'){
			   total = total + 1
			   if (!(inputs[i].value == "?" || inputs[i].value == "")){
				   convalor = convalor + 1;
			   }else{
					if(campoOpc)
						scope.$eval(formulario+"."+nombre+".$invalid=true");
			   }
		   }
	 }
	 
	 var inputs = els[0].getElementsByTagName('uiselect');
	 
	 for (var i=0; i < inputs.length; i++) {
		   var tipos = inputs[i].getAttribute('type');
		   var nombre = inputs[i].getAttribute('name');	
		   var opcional = inputs[i].getAttribute('opcional');
		   if (opcional != 'true'){
			   total = total + 1
			   if (!(inputs[i].value == "?" || inputs[i].value == "")){
				   convalor = convalor + 1;
			   }else{
					if(campoOpc)
						scope.$eval(formulario+"."+nombre+".$invalid=true");
			   }
		   }
	 }
	 
	 var inputs = els[0].getElementsByTagName('textarea');
	 
	 for (var i=0; i < inputs.length; i++) {
		   var tipos = inputs[i].getAttribute('type');
		   var nombre = inputs[i].getAttribute('name');	
		   var opcional = inputs[i].getAttribute('opcional');
		   if (opcional != 'true'){
			   total = total + 1
			   var vacio = true;
			   for (var O = 0; O < inputs[i].value.length; O++ ) {
					if ( inputs[i].value.charAt(O) != " " ) {
						vacio = false;      
					}
				}
			   if (!(vacio || inputs[i].value == null)){
				   convalor = convalor + 1;
			   }else{
					if(campoOpc)
						scope.$eval(formulario+"."+nombre+".$invalid=true");
			   }
		   }
	 }
	 
	 var inputs = els[0].getElementsByTagName('a');
	 
	 for (var i=0; i < inputs.length; i++) {
		   var tipos = inputs[i].getAttribute('type');
		   var nombre = inputs[i].getAttribute('name');	
		   var opcional = inputs[i].getAttribute('opcional');
		   var model = inputs[i].getAttribute('value');
		  if (tipos == "ipad"){
			  if (opcional != 'true'){
				  total = total + 1
				  if (model != 0){
					  convalor = convalor + 1;
				  }
			  }
		  }
	 }
	        
	 
	 var inputs = els[0].getElementsByTagName('img');
	 
	 for (var i=0; i < inputs.length; i++) {
		   var tipos = inputs[i].getAttribute('type');
		   var nombre = inputs[i].getAttribute('name');	
		   var opcional = inputs[i].getAttribute('opcional');
		   var model = inputs[i].getAttribute('value');
		  if (tipos == "ipad"){
			  if (opcional != 'true'){
				  total = total + 1
				  if ((model == "1")){
					  convalor = convalor + 1;
				  }
			  }
		  }
	 }
	 
	 var inputs = els[0].getElementsByTagName('canvas');
	 
	 for (var i=0; i < inputs.length; i++) {
		   var tipos = inputs[i].getAttribute('type');
		   var nombre = inputs[i].getAttribute('name');	
		   var opcional = inputs[i].getAttribute('opcional');
		   var model = inputs[i].getAttribute('value');
		  if (tipos == "ipad"){
			  if (opcional != 'true'){
				  total = total + 1
				  if ((model == "true")){
					  convalor = convalor + 1;
				  }
			  }
		  }
	 }
	 if (parseInt(porcent1))
		 convalor = porcent1;
	 porcentaje = (convalor * 100) / total;
	 if (isNaN(porcentaje)){
		 porcentaje = 0;
	 }
	 return parseInt((porcentaje).toFixed(0));
}



// verifica si se modificaron los campos para llamar al buro service
 function  DatosAnterioresArreglo(formulario, flag){
	//var els = document.getElementsByName(formulario);
	var els = document.getElementsByName(formulario);
	var inputs = els[0].getElementsByTagName('input');
	var nombreant = "";
	var ArregloAnterior = [];
	var ArregloAnteriorHomonimos = [];
	var arregloEdicionDatos=[];

	for (var i=0; i < inputs.length; i++) {
		var tipos = inputs[i].getAttribute('type');
		var nombre = inputs[i].getAttribute('name');
		var buro = inputs[i].getAttribute(flag);
		var existeEdicion = inputs[i].getAttribute(flag);
//		var homonimoAval = inputs[i].getAttribute('homonimo-aval');
		var model1 = inputs[0].getAttribute('ng-model');
		var valor= inputs[i].value;
		
		if  (tipos == 'text' || tipos== 'mail' || tipos== 'password' || tipos == 'number' || 
			 tipos == 'tel'  || tipos == 'date'|| tipos == 'email'   || tipos == 'file') {
			if (buro == 'true'){
				ArregloAnterior.push(valor);
			}
			if(existeEdicion=='true'){
				arregloEdicionDatos.push({nombreCampo:nombre,valor:valor});
			}
			
//			if( homonimoAval == 'true' ){
//				ArregloAnteriorHomonimos.push(valor);
//			}
			
		}
		if (tipos == "radio" || tipos == "checkbox"){
			if (buro == 'true'){    				
				if (inputs[i].checked==true){
					ArregloAnterior.push(valor);
				}
				if(existeEdicion=='true')
					arregloEdicionDatos.push({nombreCampo:nombre,valor:inputs[i].checked});
			}
			
//			if( homonimoAval == 'true' ){
//				if (inputs[i].checked==true){
//					ArregloAnteriorHomonimos.push(valor);
//				}
//			}
			
		}
	}
	
	 var inputs = els[0].getElementsByTagName('select');
	 for (var i=0; i < inputs.length; i++) {;	
		   var buro = inputs[i].getAttribute(flag);
		   var nombre = inputs[i].getAttribute('name');
		   var existeEdicion = inputs[i].getAttribute(flag);
//		   var homonimoAval = inputs[i].getAttribute('homonimo-aval');
		   var valor= inputs[i].value;		   
		   
		   if(existeEdicion=='true'){
			   //valor= inputs[i].options[inputs[i].selectedIndex].text;
			   arregloEdicionDatos.push({nombreCampo:nombre,valor:valor});
		   }
		   
		   if (buro == 'true'){
			   ArregloAnterior.push(valor);
		   }
		   
//		   if( homonimoAval == 'true' ){
//				ArregloAnteriorHomonimos.push(valor);
//		   }
		   
	 }
	 var inputs = els[0].getElementsByTagName('textarea');
	 
	 for (var i=0; i < inputs.length; i++) {
		   var tipos = inputs[i].getAttribute('type');
		   var nombre = inputs[i].getAttribute('name');	
		   var buro = inputs[i].getAttribute(flag);
		   var existeEdicion = inputs[i].getAttribute(flag);
//		   var homonimoAval = inputs[i].getAttribute('homonimo-aval');
		   var valor= inputs[i].value;
		   if (buro == 'true'){
			   ArregloAnterior.push(valor);
			   
		   }
		   if(existeEdicion=='true'){
			   arregloEdicionDatos.push({nombreCampo:nombre,valor:valor});
		   }
		   
//		   if( homonimoAval == 'true' ){
//				ArregloAnteriorHomonimos.push(valor);
//		   }
	 }
	 
	 var inputs = els[0].getElementsByTagName('a');
	 
	 for (var i=0; i < inputs.length; i++) {
		   var tipos = inputs[i].getAttribute('type');
		   var nombre = inputs[i].getAttribute('name');	
		   var buro = inputs[i].getAttribute(flag);
//		   var homonimoAval = inputs[i].getAttribute('homonimo-aval');
		   var valor =  inputs[i].getAttribute('value');
		  if (buro == "true"){
			  ArregloAnterior.push(valor);
			  
		  }
		  
//		  if( homonimoAval == 'true' ){
//			  ArregloAnteriorHomonimos.push(valor);
//		  }
	 }
	        
	 
	 var inputs = els[0].getElementsByTagName('img');

	 for (var i=0; i < inputs.length; i++) {
		   var tipos = inputs[i].getAttribute('type');
		   var buro = inputs[i].getAttribute(flag);	
//		   var homonimoAval = inputs[i].getAttribute('homonimo-aval');
		   var valor = inputs[i].getAttribute('value');
		  if (tipos == "ipad"){
			  if (buro == 'true'){
				  ArregloAnterior.push(valor);
			  }
			  
//			  if( homonimoAval == 'true' ){
//				  ArregloAnteriorHomonimos.push(valor);
//			  }
			  
		  }
	 }
	 
	 var inputs = els[0].getElementsByTagName('canvas');
	 
	 for (var i=0; i < inputs.length; i++) {
		   var tipos = inputs[i].getAttribute('type');
		   var nombre = inputs[i].getAttribute('name');
		   var buro = inputs[i].getAttribute(flag);	
//		   var homonimoAval = inputs[i].getAttribute('homonimo-aval');
		   var valor = inputs[i].getAttribute('value');
		  if (tipos == "ipad"){
			  if (buro == 'true'){
				  ArregloAnterior.push(valor);
			  }
			  
//			  if( homonimoAval == 'true' ){
//				  ArregloAnteriorHomonimos.push(valor);
//			  }
		  }
	 }
	 
//	 if( flag == 'homonimos' )
//		 return ArregloAnteriorHomonimos;
//	 else
	 if(flag=='edicion'){
		 ArregloAnterior = arregloEdicionDatos;
	 }
	 
	 	return  ArregloAnterior;

}
 
 //Valida campo por campo para detectar si en alguno de ellos se realizó alguna edición.
 //Elimina aquellos que no fueron editados.
 function validaCamposEditados(jsonNuevo,jsonRespaldo){
	 for(var i=0; i<jsonRespaldo.length; i++){
			for(var p=0; p<jsonNuevo.length;p++){
				if(jsonNuevo[p].nombreCampo==jsonRespaldo[i].nombreCampo){
					if(jsonNuevo[p].valor==jsonRespaldo[i].valor){
						delete jsonNuevo[p];
						jsonNuevo=limpiarArreglo(jsonNuevo);
						break;
					}
				}
			}
		}
	 return jsonNuevo;
 }
 
 //Elimina los campos de un json que esten undefined o nulos.
 function limpiarArreglo(json){
		var newArray=new Array();
		for(var i=0; i<json.length; i++){
			if(json[i]){
				newArray.push(json[i]);
			}
		}
		return newArray;
	}
 
 