'use strict';

define(["app"], function (app) {
	
	app.controller('aperturaCuentaController', function( 	$rootScope, $scope, $location, messageData, modalService, validateService, generalService ) {
		
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		
		
		$scope.init = function(){			
						
			$scope.manejador = "principal"; /*detalle, deposito, principal*/
			
			$scope.showPage = messageData;
			
			if( messageData  ){					
				
//				if( generalService.existeSolicitud($rootScope.solicitudJson) ){
					
					loadView();
				
//				}else
//					$rootScope.message(SIN_SOLICITUD.titulo, [SIN_SOLICITUD.texto], "Aceptar", "/");																				
				
			}else
				$rootScope.message(ERROR_CARGA_PAGINA.titulo, [ERROR_CARGA_PAGINA.texto], "Aceptar", "/");
				
		};/* END INIT FUNCTION */
					
		
		$scope.setNIP = function(){
			modalService.nipModal();
		};
		
		function loadView(){			
			
			$scope.isTienda = configuracion.origen.tienda; 
			$scope.origen = ($scope.isTienda == true) ? "TIENDA":"WEB";
			
			
			$scope.labelTitulo = "Apertura de Cuenta Guardadito";
			$scope.pregunta1 = "¿Como quieres tu préstamo?";
			$scope.LDC = "La LDC fue aprobada para:";
			$scope.btnLiberacion = "Liberar";
			$scope.btnGuardadito = "Guardadito";
			$scope.btnEfectivo = "Efectivo";		
			
						
		};/* END LOAD VIEW FUNCTION */
		
				
		
		
			
	});
		
});