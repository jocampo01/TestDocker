'use strict';

define( ["app"], function ( app ){

	app.factory( "AvalBasicoFactory", function ( $timeout, $rootScope, $location, loginService, modalService, 
											 generalService, authService, solicitudService, 
											 clienteUnicoService, buroService ) {
		
		var basicoFactory = {};		
		var $parentScope;
		var servicioEnvioImgDocIpad = "clienteUnico";
		var functionCallbackEnvioFotoIpad = "responseEnvioFotoIpad";
		var functionCallbackEnvioHuellaIpad = "responseEnvioHuellaIpad";
		
		basicoFactory.main = function( scope )
		{
			$parentScope = scope;
			basicoFactory.initEstilos();
		};
		
		basicoFactory.initEstilos = function()
		{
			
			/* FUSILAMOS DATOS BASICOS */
			$parentScope._folioIdent 		= generalService.getDataInput( "DATOS BASICOS", "FOLIO IDENTIFICACION"	, 	null );
			$parentScope._estadoCivil		= generalService.getDataInput("DATOS BASICOS","ESTADO CIVIL"			, 	null );
			$parentScope._lugarNacimiento	= generalService.getDataInput("DATOS BASICOS","LUGAR NACIMIENTO"		, 	null );
			$parentScope._ocupacion			= generalService.getDataInput("DATOS BASICOS","OCUPACION"				, 	null );
			$parentScope._etqVigencia 		= {	texto: "Vigencia de Identificación oficial" };
			$parentScope._vigenciaIdent 	= {
												marcaAgua : "Vigencia de Identificación",
												opcional : false,
												obligatorio: false,
												buro: false,
												cincom: false,
												estilo: "inpuSelect",
												imagen: "images/icon-form/calendario.png",
												deshabilitado: false
											};
			
			$parentScope.fe = {
				comprobable: {
					"idTipo": 1,
					"tipoDes": "INGRESO",
					"idConcepto": 3,
					"conceptoDes": "COMPROBABLES",
					"monto": ''
				},
				noComprobable: {
					"idTipo": 1,
					"tipoDes": "INGRESO",
					"idConcepto": 4,
					"conceptoDes": "NO COMPROBABLES",
					"monto": ''
				}
			};
				
			if( $rootScope.solicitudJson.avales[0].flujoEfectivo.length > 0 ){
				$rootScope.solicitudJson.avales[0].flujoEfectivo.map(function(data){
						
					if( data['idConcepto'] == 4 ){
						$parentScope.fe.noComprobable.monto = data['monto'];  
					}
						
					if( data['idConcepto'] == 3 ){
						$parentScope.fe.comprobable.monto = data['monto'];
					}	
						
				});
			}
			
		};
		
		basicoFactory.test = function( obj )
		{
			console.log( "FUCK YEA" );
			modalService.alertModal("FUCK YEA",[obj], null, null, null);
			console.log( obj );
		};
		
		basicoFactory.tomarRostro = function()
		{
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$rootScope.tomarRostro( 'fotoAvalDiv', 'fotoAval');
			
		};
		
		basicoFactory.tomarHuella = function()
		{
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$rootScope.capturarHuella( 'huellaAvalDiv', '4,7' , 'huellaAval' );
			
		};
		
		basicoFactory.respuestaFoto = function( respuestaComponente )
		{
			
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			
			try{
				if(respuestaComponente.codigo == RESPONSE_CODIGO_EXITO_IPAD){
//					var porcentajeFoto = cuentatext('datosPersonalesDiv',1).toString();
					$parentScope.archivoFoto = respuestaComponente.archivo; 
					$parentScope.enviarArchivoFoto = true;
					$parentScope.cadenaEnviar = respuestaComponente.cadenaJPG;
					$parentScope.objetoEnviar = "foto_aval";
					$parentScope.manoEnviar = null;
					$parentScope.dedoEnviar = null;
					$parentScope.fotoAnterior = $rootScope.solicitudJson.avales[0].foto;
					$rootScope.solicitudJson.avales[0].foto = "2";				
				}else{
					$parentScope.enviarArchivoFoto = false;
				}				
			}catch(e){
				$rootScope.message( $parentScope._titulo.texto,[e], "Aceptar", null);
				$scope.enviarArchivoFoto = false;
			}
			
		};
		
		basicoFactory.respuestaHuella = function( respuestaComponente )
		{
			
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			
			try{
				if(respuestaComponente.codigo == RESPONSE_CODIGO_EXITO_IPAD){
//					var porcentajeFoto = cuentatext('datosPersonalesDiv',1).toString();
					$parentScope.archivoHuella = respuestaComponente.nombreHuellas;
					$parentScope.enviarArchivoHuella = true;
					
					$parentScope.huellaAnterior = $rootScope.solicitudJson.avales[0].huella;
					$rootScope.solicitudJson.avales[0].huella = "2";
					$parentScope.objetoEnviar = "huella_aval";
					$parentScope.manoEnviar = 1;
					$parentScope.dedoEnviar = 2;
					//$scope.cadenaEnviar = $scope.manoEnviar + "-" + $scope.dedoEnviar + "-" + response.nombreHuellas;
					$parentScope.cadenaEnviar = $parentScope.manoEnviar + "-" + $parentScope.dedoEnviar + "-XXXXXXXXXXXXXXXXXX,2-1-YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY";
				}else{
					$parentScope.enviarArchivoHuella = false;
				}
			}catch(e){
				$rootScope.message( $parentScope._titulo.texto,[e], "Aceptar", null);
				$parentScope.enviarArchivoHuella = false;
			}
			
		};
		
		basicoFactory.archivarFoto = function()
		{
			
			$rootScope.enviarImagen(
				$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
				$parentScope.archivoFoto,
				servicioEnvioImgDocIpad,
				"Foto aval",
				'fotoAvalDiv',
				{	
					ruta: null,
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					cadena: $parentScope.cadenaEnviar,
					tipoCadena: $parentScope.objetoEnviar,
					nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
					foto: $rootScope.fotoCteOriginal
				},	
				functionCallbackEnvioFotoIpad
			);
			
		};
		
		basicoFactory.archivarHuella = function()
		{
			
			$rootScope.enviarImagen(
				$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
				$parentScope.archivoHuella[2],
				servicioEnvioImgDocIpad,
				"Huella aval",
				'huellaAvalDiv',
				{	
					ruta: null,
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					cadena: $parentScope.archivoHuella[2],
					tipoCadena: $parentScope.objetoEnviar,
					nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
					foto: $rootScope.fotoCteOriginal
				},
				functionCallbackEnvioHuellaIpad
			);
			
		};
		
		return basicoFactory;
	    		
	});/*END APP FACTORY - BasicoFactory*/
	
});