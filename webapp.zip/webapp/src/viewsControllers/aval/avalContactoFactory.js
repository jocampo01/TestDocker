'use strict';

define( ["app"], function ( app ){

	app.factory( "AvalContactoFactory", function ( $timeout, $rootScope, $location, loginService, modalService, 
											 generalService, authService, solicitudService, 
											 clienteUnicoService, buroService ) {
		
		var contactoFactory = {};
		var $parentScope;
		var functionCallbackEnvioFirmaIpad = "responseEnvioFirmas";
		var functionCallbackEnvioFotoIpad = "responseEnvioFotoIpad";
		var etiquetaFrente = "";
		var etiquetaReverso = "";
		
		contactoFactory.main = function( scope )
		{
			$parentScope = scope;
			contactoFactory.initEstilos();
		};
		
		contactoFactory.initEstilos = function()
		{
			
			/* FUSILAMOS DE REFERENCIAS */
			$parentScope._relacion =  {
				"visible"		:	generalService.getDatafromCategory("REFERENCIAS", "RELACION","VISIBLE.valor" ),
				"obligatorio" 	:	generalService.getDatafromCategory("REFERENCIAS", "RELACION","OBLIGATORIO.valor" ),
				"marcaAgua" 	: 	generalService.getDatafromCategory("REFERENCIAS", "RELACION","MARCAAGUA.valor" ),
				"opcional"		: 	generalService.getDatafromCategory("REFERENCIAS", "RELACION","OPCIONAL.valor" ),
				"disabled"		: 	generalService.getDatafromCategory("REFERENCIAS", "RELACION","DESHABILITADO.valor" ),
				"buro"			:   generalService.getDatafromCategory("REFERENCIAS", "RELACION","BURO.valor" ),  
				"valor"			: 	""
			};
			
			/* FUSILAMOS DE SIMULADOR */
			etiquetaFrente  = " " + generalService.getDatafromCategory("SIMULADOR", "ETIQUETA FRENTE", "VALOR.valor" );
			etiquetaReverso = " " + generalService.getDatafromCategory("SIMULADOR", "ETIQUETA REVERSO", "VALOR.valor" );

		};
		
		contactoFactory.llamarOcrIFE = function()
		{
			
			try{	 				
				$rootScope.aplicarOCR_IFE( 'ocrDiv', 'ocrIFE' );
			}catch(e){
				modalService.alertModal("Error al capturar imagen",[e], null, null, null);           	 
			}
				
		};
		
		contactoFactory.respuestaOcr = function( respuestaComponente )
		{
			
			if( respuestaComponente.codigo == 0 ){
	 			if (parseInt(respuestaComponente.persona.anoVigencia))
	 				$rootScope.solicitudJson.avales[0].fechaVigenciaIdentificacion = "01/01/" + respuestaComponente.persona.anoVigencia;
	 			else
	 				$rootScope.solicitudJson.avales[0].fechaVigenciaIdentificacion = "";
	 			
	 			$rootScope.solicitudJson.avales[0].nombre = respuestaComponente.persona.nombre; 
	 			$rootScope.solicitudJson.avales[0].apellidoPaterno = respuestaComponente.persona.apPaterno;
	 			$rootScope.solicitudJson.avales[0].apellidoMaterno = respuestaComponente.persona.apMaterno;	 				 			
	 			
	 			if( !generalService.isEmpty(respuestaComponente.persona.calle) )
	 				$rootScope.solicitudJson.avales[0].datosHogar.calle = respuestaComponente.persona.calle.substring(0,49);	 				
	 			
	 			if( !generalService.isEmpty(respuestaComponente.persona.cp) && respuestaComponente.persona.cp.length == 5)
	 				$rootScope.solicitudJson.avales[0].datosHogar.cp = respuestaComponente.persona.cp;
	 				 			
	 			if( !generalService.isEmpty(respuestaComponente.persona.genero) ){	 		
	 				switch(respuestaComponente.persona.genero){
	 				case 'M': 
	 						$rootScope.solicitudJson.avales.idGenero = "F";
	 						$rootScope.solicitudJson.avales[0].genero = $parentScope.getDescripcionCatalogo('F', $parentScope.combos.generos);
	 					break;
	 				case 'H': 	 					
	 						$rootScope.solicitudJson.avales[0].idGenero = "M";
	 						$rootScope.solicitudJson.avales[0].genero = $parentScope.getDescripcionCatalogo('M', $parentScope.combos.generos);
	 					break;
	 				}
	 			}	 			
	 			
	 			var fnOk = false;
	 			
	 			if( !generalService.isEmpty(respuestaComponente.persona.fechaNacimiento) ){
	 				var fnArray = respuestaComponente.persona.fechaNacimiento.split("/");	 				
	 				fnOk = desglosaFechaNacimiento(fnArray[0] + fnArray[1] + fnArray[2]);
	 			}	
	 			
	 			if( !fnOk &&  !generalService.isEmpty(respuestaComponente.persona.curp) ){
	 				fnOk = desglosaFechaNacimiento(respuestaComponente.persona.curp.substring(4,10));
	 			}
	 			
	 			
	 			if( !fnOk &&  !generalService.isEmpty(respuestaComponente.persona.claveElector) ){
	 				fnOk = desglosaFechaNacimiento(respuestaComponente.persona.claveElector.substring(6,12));	 				 				 					 				 				 				 		
	 			}
	 				 				 			
	 			$rootScope.solicitudJson.avales[0].folioIdentificacion = respuestaComponente.persona.folio;
	 			
	 			if(respuestaComponente.nombres != null && respuestaComponente.nombres.length > 0 ){
	 				generalService.setArrayValue('nomsImgIFE', respuestaComponente.nombres);
		 			generalService.setArrayValue('imgsIFE', respuestaComponente.imagenes);
	 			}
	 			
	 			$rootScope.solicitudJson.avales[0].banderaOCR = 1;
	 			
	 		}else{
	 			modalService.confirmModal("OCR AVAL", ["Se cancelo o fallo la digitalización de la identificación.", "Intenta nuevamente"], 
						  "Cancelar","Aceptar", null, "gris", null,null,null )
							.then(
									function(exito){													
										$rootScope.aplicarOCR_IFE('ocrDiv','ocrIFE');
									},function(error){
										$rootScope.solicitudJson.avales[0].banderaOCR = 0;														
									}
							);
	 		}

			
		};
				
		contactoFactory.test = function( obj )
		{
			console.log( "FUCK YEA" );
			modalService.alertModal("FUCK YEA",[obj], null, null, null);
			console.log( obj );
		};
		
		function desglosaFechaNacimiento( fn ){
			
	 		var cont = 0;
	 		
	 		if( fn.length == 6){
	 			var annio="", mes="", dia="";
		 		
		 		try{
		 			var anioActual = new Date().getFullYear().toString().substring(2);
					var anioFN = fn.substring(0,2);
					
					if( generalService.isEmpty($parentScope.nAnno)  ){
						if(generalService.isNumeric(anioFN)){
							if( parseInt(anioActual) < parseInt(anioFN) )
								annio = "19" + anioFN;				
							else
								annio = "20" + anioFN;
							
							$parentScope.nAnno = annio;
							cont++;
						}
						
					}else
						cont++;
														
					mes = fn.substring(2,4);
					if( generalService.isEmpty($parentScope.nMes)  ){
						if(generalService.isNumeric(mes)){
							var _mes = parseInt(mes);						
							if( _mes > 0 && _mes < 12){
								$parentScope.nMes = mes;
								cont++;
							}
						}												
					}else
						cont++;
					
					dia = fn.substring(4,6);
					if( generalService.isEmpty($parentScope.nDia) ){
						
						if( generalService.isNumeric(dia) ){
							var _dia = parseInt(dia);
							if( _dia > 0 && _dia < 32){
								$parentScope.nDia = dia;
								cont++;
							}
						}
						
					}else
						cont++;
																											
					
		 		}catch(e){
		 			$parentScope.nAnno = null;
		 			$parentScope.nMes = null;
		 			$parentScope.nDia = null;		 			
		 		}
		 		
	 		}
	 			 		
	 		return (cont == 3)? true:false;
	 		
	 	};
	 	
	 	contactoFactory.archivarFirmas = function()
	    {
		   	try{
				if( configuracion.origen.tienda && !generalService.isEmpty($rootScope.imgPrivacidad) 
						&& !generalService.isEmpty($rootScope.imgBuro) ){																		
					$parentScope.b64FirmaAviso = $rootScope.imgPrivacidad.replace("data:image/png;base64,","").trim();
					$parentScope.b64FirmaBuro = $rootScope.imgBuro.replace("data:image/png;base64,","").trim();						
					contactoFactory.archivarFirma(DESC_FIRMA_PRIVACIDAD, FIRMA_PRIVACIDAD_AVAL.descripcion, $parentScope.b64FirmaAviso, "firmaAvisoAval");
					contactoFactory.archivarFirma(DESC_FIRMA_BURO, FIRMA_BURO_AVAL.descripcion, $parentScope.b64FirmaBuro, "firmaBuroAval");
				}
			}catch(e){
				modalService.alertModal("ERROR AL ENCOLAR FIRMA AVAL ", [e], "Aceptar", $parentScope._titulo.colorSeccion, $parentScope._titulo.colorSeccion );
			}			
		};
	 	
	 	contactoFactory.archivarFirma = function( descripcion, segundaDesc, imagen, tipoFirma )
	 	{
	 		
	 		$rootScope.enviarImagen(
				$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
				"",
				descripcion,
				segundaDesc,
				'firmas',
				{	
					ruta: null,
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					cadena: imagen,
					tipoCadena: tipoFirma,
					nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
					foto: $rootScope.fotoCteOriginal
				},
				functionCallbackEnvioFirmaIpad
			);
			
	 	};
	 	
	 	contactoFactory.archivarIFE = function()
	 	{
	 		
	 		if( configuracion.origen.tienda ){																		
				if( generalService.getArrayValue('nomsImgIFE') != null && generalService.getArrayValue('imgsImgIFE') != null ){
					var nomsImgIFE = generalService.getArrayValue('nomsImgIFE');
					var imgsIFE = generalService.getArrayValue('imgsIFE');
					var nombreCte = $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+ $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno;
											
					$rootScope.enviarImagen(
						$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
						nomsImgIFE[0],								
						"digitalizacion",
						IDENTIFICACION_OFICIAL_AVAL.descripcion + etiquetaFrente,
						"contacto",
						generalService.buildDigitDocRequest($rootScope.solicitudJson.idSolicitud, IDENTIFICACION_OFICIAL_AVAL.id, 0, imgsIFE[0], nombreCte, $rootScope.fotoCteOriginal ),
						"responseEnvioImgIpad"
					);	
					
					$rootScope.enviarImagen(
						solicitudJson.cotizacion.clientes[0].idPersona,
						nomsImgIFE[1],								
						"digitalizacion",
						IDENTIFICACION_OFICIAL_AVAL.descripcion + etiquetaReverso,
						"contacto",
						generalService.buildDigitDocRequest($rootScope.solicitudJson.idSolicitud, IDENTIFICACION_OFICIAL_AVAL.id, 0, imgsIFE[1], nombreCte, $rootScope.fotoCteOriginal ),
						"responseEnvioImgIpad"
					);
					
					generalService.setArrayValue( "nomsImgIFE", null );
					generalService.setArrayValue( "imgsIFE", null);
				}
			}	 		
	 		
	 	};
	 	
	 	contactoFactory.esNombreCliente = function()
	    {
	    
	    	if( $rootScope.solicitudJson.cotizacion.clientes[0].nombre == $rootScope.solicitudJson.avales[0].nombre 
	    		&& $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno == $rootScope.solicitudJson.avales[0].apellidoPaterno
	    		&& $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno == $rootScope.solicitudJson.avales[0].apellidoMaterno
	    		&& $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento == $rootScope.solicitudJson.avales[0].fechaNaciomiento
	    	)
	    		return true;
	    	return false;
	    	
	    };
					
		return contactoFactory;
	    		
	});/*END APP FACTORY - ContactoFactory*/
	
});