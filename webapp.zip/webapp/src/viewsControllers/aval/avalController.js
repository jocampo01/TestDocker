'use strict';

define(["app"], function (app) {
	
	
	app.controller( "avalController", function ( $timeout, $scope, $rootScope, avalService, modalService, generalService, solicitudService, 
											   buroService, messageData, clienteUnicoService, validateService,
											   AvalContactoFactory, AvalHogarFactory, AvalBasicoFactory, MapService,MapConstants, MapBazService ) {
		
		$scope.pageClass = generalService.calculaVistas($rootScope.paginaActual,$rootScope.paginaAnterior,$rootScope.recuperaSolicitud);
		$scope.bloqueaSeccion = $rootScope.solicitudJson.avales[0].editable;
		$scope.guardarShow = false;
	    $scope.vistaDatosUsuario=configuracion.datosUsuario.opcion=0;
		$scope.labelTiempo=generalService.labelTiempo;
		$scope.labelMin=generalService.labelMin;
		$scope.guardarFoto = true;
		$scope.guardarHuella = true;
		
		var x = 0;
		var y = 0;
//		$rootScope.waitLoaderStatus = LOADER_SHOW;
		var csstabs = { 
			off: {
				css: "tab tres verdeVt active",
				status: false
			}, 
			on: {
				css: "tab tres verdeVt",
				status: true
			}, 
			disabled: {
				css: 'tab tres verdeVt active pasoDeshabilitado',
				status: false
			}
		};
		var cssOcr = { enabled: "btn verdeD", disabled: "btn verdeD pasoDeshabilitado" };
		var zona_T = $rootScope.solicitudJson.avales[0].datosHogar.zonificacion;
		
		var AVAL_INGRESOS = 1;
		var AVAL_PROPIEDAD = 2;
		
		$scope.gralAddress = {};
	    $scope.completeAddress = '';
	    $scope.combos = {};
	    
	    var upu_address = [ '', '', '', '', '', '', ''];
		
		var cont = 0;
	
		/* Date module conf*/
		var fechaMayorEdad = new Date();
		fechaMayorEdad.setFullYear(fechaMayorEdad.getFullYear() - 18);
		var formatofechaMayorEdad =	fechaMayorEdad.getFullYear() + "-" +
									((fechaMayorEdad.getMonth() + 1) < 10 ? '0' : '') + (fechaMayorEdad.getMonth() + 1) + "-" +
									(fechaMayorEdad.getDate() < 10 ? '0' : '') + fechaMayorEdad.getDate();
		
		var fechaMayorEdad75 = new Date();
		fechaMayorEdad75.setFullYear(fechaMayorEdad75.getFullYear() - 75);
		var formatofechaMayorEdad75 =	fechaMayorEdad75.getFullYear() + "-" +
									((fechaMayorEdad75.getMonth() + 1) < 10 ? '0' : '') + (fechaMayorEdad75.getMonth() + 1) + "-" +
									(fechaMayorEdad75.getDate() < 10 ? '0' : '') + fechaMayorEdad75.getDate();
		
		
		var fechaDia = new Date();
		var yyyy = new Date().getFullYear()-18;
		var yy75 = new Date().getFullYear()-75;
		var dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
		var mm = ((fechaDia.getMonth() + 1) < 10 ? '0' : '') + (fechaDia.getMonth() + 1);
		var diafin = 31;
		//var fechaActual = new Date();
		var anioActual = fechaDia.getFullYear();
		
		if( !$rootScope.avisosCheck || $rootScope.regresaAvisos )
	    	$rootScope.avisosCheck = { value: false };
		if( $rootScope.solicitudJson.avales[0].aceptaTerminos )
	    	$rootScope.avisosCheck = { value : true};
		
		$scope.cargadias = function()
		{
			
			$scope.days = [];
			for( var i = 1; i <= diafin; i++ ){
				
				if( i < 10 )
					$scope.days.push( "0" + i );
				else
					$scope.days.push( "" + i );
				
			}
		
		}		
		
		$scope.months = [	{id:"01", descripcion:'ENERO'},
			 				{id:"02", descripcion:'FEBRERO'},
			 				{id:"03", descripcion:'MARZO'},
			 				{id:"04", descripcion:'ABRIL'},
			 				{id:"05", descripcion:'MAYO'},
			 				{id:"06", descripcion:'JUNIO'},
			 				{id:"07", descripcion:'JULIO'},
			 				{id:"08", descripcion:'AGOSTO'},
			 				{id:"09", descripcion:'SEPTIEMBRE'},
			 				{id:"10", descripcion:'OCTUBRE'},
			 				{id:"11", descripcion:'NOVIEMBRE'},
			 				{id:"12", descripcion:'DICIEMBRE'}
			 			];			 				
		 
		$scope.years = [];
		 
		for( var i = (new Date().getFullYear() - 18); i> new Date().getFullYear() - 101; i-- ){
			
			$scope.years.push( "" + i );
			
		}
		
		//validacion de fecha
		$scope.aniobisiesto = function(){ 
			
			if ( ( $scope.nAnno % 4 == 0 ) && ( ( $scope.nAnno % 100 != 0 ) || ( $scope.nAnno % 400 == 0 ) ) ) {
				
				if ( $scope.nMes == "02"){
					diafin = "29";
					$scope.cargadias();
				}
				
			}else{
				
				if ( $scope.nMes == "02" ){
					diafin = "28";
					$scope.cargadias();
				}
			}
			
			if ( $scope.nMes == "01" || $scope.nMes == "03" || $scope.nMes == "05" || $scope.nMes == "07" || $scope.nMes == "08" || $scope.nMes == "10" || $scope.nMes == "12"){			    		
				diafin = "31";
				$scope.cargadias();
			}
			
			if ( $scope.nMes == "04" || $scope.nMes == "06" || $scope.nMes == "09" || $scope.nMes == "11" ){
				diafin = "30";
				$scope.cargadias();
			}
			
		}

		$scope.validadiasconmes = function(){
			
			if ( !( $scope.nMes == null || $scope.nMes == "" ) ){
				
				$scope.aniobisiesto();  
				
				if( $scope.nDia > diafin ){
					$scope.nDia = diafin;	
				}
				
			}
			
		}

		$scope.validadias = function(){
			
			$scope.aniobisiesto();
			
			if( $scope.nDia > diafin && $scope.nMes != 'Mes' ){
				$scope.nDia = diafin;				  
			}				 
		
		}

		$scope.validames = function(){
			
			$scope.aniobisiesto();
			
			if( $scope.nDia > diafin ){
				$scope.nDia = diafin;				  
			}
		
		}
		
		$scope.convertir = function(){
			$scope.datosAnterioresHomonimos = JSON.stringify(DatosAnterioresArreglo( 'avalForm', 'homonimo-aval' ));
		}
	
		$scope.init = function()
		{
			
			$scope.showPage = false;
			$scope.showPage = messageData;
			$scope.homonimoFlag = false;
			$scope.tabContactoCSS = csstabs.on;
			$scope.tabHogarCSS = csstabs.disabled;
			$scope.tabBasicosCSS = csstabs.disabled;
			$scope.ocrCss = cssOcr.disabled;
			$scope.nombreCompleto = $rootScope.solicitudJson.cotizacion.clientes[0].nombre + " " 
									+ $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno 
									+ " " + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno; 
	    	
//			$scope.configFullScreen();
//			MarkerCreatorService.setPanorama( null );
//			$scope.getStreetView();
			
//			$scope.initMap(null);
//			$scope.configFullScreen();
			
			if( messageData ){
				
				$scope.setContentPage();			
								
				generalService.setRespaldo($rootScope.solicitudJson);				
	    	
				$scope.cargadias();
				
		    	var estados = generalService.construirCatalogo("CATALOGO ESTADOS");//["Aguascalientes", "Baja California", "Baja California Sur", "Campeche", "Chiapas", "Chihuahua", "Coahuila de Zaragoza", "Colima", "Distrito Federal", "Durango", "Guanajuato", "Guerrero", "Hidalgo", "Jalisco", "Mexico", "Michoacan de Ocampo", "Morelos", "Nayarit", "Nuevo Leon", "Oaxaca", "Puebla", "Queretaro de Arteaga", "Quintana Roo", "San Luis Potosi", "Sinaloa", "Sonora", "Tabasco", "Tamaulipas", "Tlaxcala", "Veracruz-Llave", "Yucatan", "Zacatecas"];
				var clases = generalService.construirCatalogo("CATALOGO CLASE VIVIENDA");
				var viviendas = generalService.construirCatalogo("CATALOGO TIPO DE DOMICILIO");
				var avales = generalService.construirCatalogo("CATALOGO TIPO AVAL");
				var propiedades = generalService.construirCatalogo("CATALOGO TIPO PROPIEDAD");
				var generos = generalService.construirCatalogoIdString("CATALOGO GENERO");
				var parentesco = generalService.construirCatalogo("CATALOGO PARENTESCO");
				var estadoCivil = generalService.construirCatalogo("CATALOGO ESTADO CIVIL");											
				var ocupaciones = generalService.construirCatalogo("CATALOGO OCUPACION");
				
				var presencialAval = [ 
				    {
				    	id: 1,
				    	descripcion: "SI",
				    	prioridad: 1
				    },
				    {
				    	id: 2,
				    	descripcion: "NO",
				    	prioridad: 2
				    }
				];
				
				var tiempoVigencia = 20;
				var aniosVigencia = [];
				
				for( var anio = anioActual - tiempoVigencia; anio < anioActual + tiempoVigencia; anio++){
					aniosVigencia.push(anio);
				}
				
				$scope.combos = {
					"estados": estados,
					"clases": clases,
					"viviendas": viviendas,
					"avales": avales,
					"propiedades": propiedades,
					"generos": generos,
					"parentesco": parentesco,
					"estadoCivil": estadoCivil,
					"ocupaciones": ocupaciones,
					"aniosVigencia": aniosVigencia,
					"presencial": presencialAval
				};
							
				$scope.telefonoAval = $rootScope.solicitudJson.avales[0].datosHogar.telefono;
				$scope.celularAval = $rootScope.solicitudJson.avales[0].celular;
		    	
				$timeout(function(){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					//$scope.convertir();
					$scope.showPage = messageData;
					$scope.avalPresente();
					$scope.ocrPresente();
				}, TIME_OUT_VIEW_MODEL);
				
			}
																			
					
		};
		
	    $scope.avisos = function()
	    {
	    	$rootScope.imgPrivacidad = "";
	    	$rootScope.imgBuro = "";
	    	$rootScope.regresaAvisos = false;
	    	
	    	if( $rootScope.avisosCheck.value )
	    		generalService.locationPath("/avisos");
	    	else{
				$rootScope.solicitudJson.avales[0].aceptaTerminos = 0;
				$rootScope.solicitudJson.avales[0].tratamientoDatos = 0;
				$rootScope.solicitudJson.avales[0].transferenciaDatos = 0;
				$rootScope.solicitudJson.avales[0].aceptaConsultaBuro = 0;
	    	}
	    };
		
		$scope.responseEnvioFirmas = function( responseIPAD )
		{
			try{
				if( responseIPAD.codigo != 0 ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Error al encolar archivos." + JSON.stringify(responseIPAD)], "Aceptar", null);
				}				
			}catch(e){
				$rootScope.message("CONTRATOS",[ "Error al encolar archivos."+e.message], "Aceptar", null);				
			}
		};
		
		$scope.ocrIFE = function( response )
		{
			if( typeof response !== 'undefinded' && response != null && response )
				AvalContactoFactory.respuestaOcr( response );
			else{
				if( configuracion.origen.tienda )
					AvalContactoFactory.llamarOcrIFE( configuracion.origen.tienda );			
			}			
		};/* OCR IFE FUNCTION */
		
		$scope.fotoAval = function( response )
		{
			
			if( typeof response !== 'undefinded' && response != null && response )
				AvalBasicoFactory.respuestaFoto( response );
			else
				if(configuracion.origen.tienda)
					AvalBasicoFactory.tomarRostro();
		
		};
		
		$scope.huellaAval = function( response )
		{
			
			if( typeof response !== 'undefinded' && response != null && response )
				AvalBasicoFactory.respuestaHuella( response );
			else
				if(configuracion.origen.tienda)
					AvalBasicoFactory.tomarHuella();
			
		};
		
		$scope.responseEnvioImgIpad = function( responseIPAD ){
			
		};

		$scope.responseEnvioFotoIpad = function( responseIPAD )
		{
			
			try{
				if( responseIPAD.codigo == 0 )
					$scope.guardarFoto = true;
				else{
					$scope.guardarFoto = false;
					console.error("AVAL: " + responseIPAD.mensaje );
				}				
			}catch(e){				
				$scope.guardarFoto = false;
				$rootScope.message($scope.titulo.texto,[ "Error al encolar archivos."], "Aceptar", null,null,null,null,"GENERAL","ERROR COMPONENTE");
				console.error( e.message );
			}
			
		};
		
		$scope.responseEnvioHuellaIpad = function( responseIPAD )
		{
			
			try{
				
				if( responseIPAD.codigo == 0 )					
					$scope.guardarHuella = true;
				else{					
					$scope.guardarHuella = false;
					console.error("AVAL: " + responseIPAD.mensaje );
				}				
			}catch(e){				
				$scope.guardarHuella = false;
				$rootScope.message($scope.titulo.texto,[ "Error al encolar archivos."], "Aceptar", null,null,null,null,"GENERAL","ERROR COMPONENTE");
				console.error( e.message );				
			}			
			
		};			
				
		$scope.showSeccionTab = function( seccion )
		{
			
			if( $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc )
				$rootScope.solicitudJson.avales[0].datosHogar.colonia = $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc;
			
			switch( seccion ){
				case 0:
						$scope.tabContactoCSS = csstabs.on;
						$scope.tabBasicosCSS = csstabs.off;
						$scope.tabHogarCSS = csstabs.off;
					break;
				case 1:
						$scope.tabContactoCSS = csstabs.off;
						$scope.tabBasicosCSS = csstabs.on;
						$scope.tabHogarCSS = csstabs.off;
						$scope.cargaVigencia();
					break;
				case 2:
						$scope.tabContactoCSS = csstabs.off;
						$scope.tabBasicosCSS = csstabs.off;
						$scope.tabHogarCSS = csstabs.on;
						$scope.callTabHogar();
					break;
			};			
			
		};/* END SHOW SECCION TAB FUNCTION */
		
		$scope.callTabHogar = function(){
			
			if( typeof $rootScope.mapas === 'undefined' || $rootScope.mapas == null ){
				$scope.initMap(null);
				MarkerCreatorService.setPanorama( null );
				$scope.getStreetView();
				$rootScope.mapas = false;
				
			}else{
				
				$timeout( function(){
					MarkerCreatorService.refreshMarkerByZone( x, y, function ( marker ) {  
						$scope.map.markers[0] = marker;
						refresh( marker );
					});
				}, 100 );
				
			}
			
			$scope.configFullScreen();
			
//			if( $rootScope.solicitudJson.avales[0].datosHogar.cp  != "" )
			$scope.serviceModuleLocation( $rootScope.solicitudJson.avales[0].datosHogar.cp, $rootScope.solicitudJson.avales[0].datosHogar.colonia );
//			$scope.getStreetView();
//			$scope.serviceModuleLocation( $rootScope.solicitudJson.avales[0].datosHogar.cp, $rootScope.solicitudJson.avales[0].datosHogar.colonia );
		};
		
		$scope.callHomonimos = function( doFunction )
		{
		
			//$scope.homonimoFlag = true;
			
			//$scope.convertir();
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			validateService.limpiaMascaras();
			var solicitudJsonString = generalService.delete$$hashKey( $rootScope.solicitudJson );
			
			var json = {
				nombre: $rootScope.solicitudJson.avales[0].nombre,
				paterno: $rootScope.solicitudJson.avales[0].apellidoPaterno,
				materno: $rootScope.solicitudJson.avales[0].apellidoMaterno,
				fechaNacimiento: ($rootScope.solicitudJson.avales[0].fechaNaciomiento), //replace( /\//g, "-")
				pais: "1",
				solicitud: solicitudJsonString
			};
			
			$scope.esHomonimo = false;
			//json3
			clienteUnicoService.getHomonimosAval( json ).then(
				
				function( data ){ //EXITO			                						
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					console.log( data );
					
					if( data.data.codigo == RESPONSE_CODIGO_EXITO ){	                		
                		//modalService.alertModal("OK ", [JSON.stringify(data.data.respuesta)]);
						$scope.objectResponse = data.data.respuesta;
						
						try{
							
							var dataJSON = JSON.parse( data.data.respuesta );
							console.log( dataJSON );
							
							var respuestaHomonimos = JSON.parse(dataJSON.respuestaHomonimos); 
							var solicitud = JSON.parse(dataJSON.solicitud);
							
							if( !respuestaHomonimos.lstResponse )
								respuestaHomonimos.lstResponse = [];
							
							if( respuestaHomonimos.lstResponse.length > 0 ){
								$scope.esHomonimo = true;
								modalService.homonimosAvalModal( "Búsqueda de homonimos", "bgAzul", $scope );
							}else{
								$scope.esHomonimo = false;
								$rootScope.solicitudJson = solicitud;
								
								if( doFunction && doFunction != null )
									doFunction( true );

							}							
							
						}catch( e ){
							console.error( "[AVAL CONTROLLER] " + e.message );
							$rootScope.message(	"Error en el servidor", [ $scope.mensajeError ],
									"Aceptar", null,  $scope._titulo.colorSeccion , $scope._titulo.colorSeccion,
									null, "GENERAL", "ERROR GENERAL");
						}	
						
					}else{
						console.error( data );
						$scope.homonimoFlag = false;
						$rootScope.message(	"Error en el servidor", [ generalService.displayMessage(data.data.descripcion) ],
								"Aceptar", null,  $scope._titulo.colorSeccion , $scope._titulo.colorSeccion,
								null, "GENERAL", "ERROR GENERAL");
					}
					
//					$scope.getCurrentAddress();
				
				}, function(error){ //ERROR 
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					console.log(error);
					$scope.homonimoFlag = false;
					$rootScope.message(	"Error en el servidor", [ $scope.mensajeError ],
							"Aceptar", null,  $scope._titulo.colorSeccion , $scope._titulo.colorSeccion,
							null, "GENERAL", "ERROR GENERAL");
				}
				
			);
			
		};
		
	    $scope.configFullScreen = function( doFunction ){
			
			 var foo = function(){
	    		  
				 var latitud = $scope.map.markers[0].latitude;
				 var longitud = $scope.map.markers[0].longitude;
	    		  
				 MarkerCreatorService.refreshMarkerByZone( latitud, longitud, function ( marker ) {  
					 $scope.map.markers[0] = marker;
					 refresh( marker );
				 });
				  
			 };		
			
			MarkerCreatorService.enableFullScreen( $scope.map, foo );
			MarkerCreatorService.enableFullScreenPanorama();
			
			$timeout( function(){
				if( doFunction && doFunction != null )
					doFunction();
			}, 100);
			
			
		};
	    
	    $scope.setContentPage = function()
	    {
	    	if (configuracion.origen.tienda)
				$scope.origen = "TIENDA";
			else
				$scope.origen = "WEB";
	    	
	    	$scope.esTienda = configuracion.origen.tienda;
			
	    	$scope.labelTiempo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO TIEMPO."+$scope.origen+".valor"];
			$scope.labelMin = " " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO MIN."+$scope.origen+".valor"];
						
	    	generalService.setMapping(  MODEL_VISTAS_JSON );
	    	
	    	$scope._titulo				= generalService.getDataInput("OBLIGADO SOLIDARIO","TITULO"						, $scope.origen	);
			$scope._nombre           	= generalService.getDataInput("OBLIGADO SOLIDARIO","NOMBRE"						, null         	);
			$scope._apellidoPaterno     = generalService.getDataInput("OBLIGADO SOLIDARIO","APELLIDO PATERNO"			, null         	);
			$scope._apellidoMaterno     = generalService.getDataInput("OBLIGADO SOLIDARIO","APELLIDO MATERNO"			, null         	);
			$scope._anio				= generalService.getDataInput("OBLIGADO SOLIDARIO","ANIO"						, null         	);
			$scope._mes					= generalService.getDataInput("OBLIGADO SOLIDARIO","MES"						, null         	);
			$scope._dia					= generalService.getDataInput("OBLIGADO SOLIDARIO","DIA"						, null         	);
			$scope._edificio			= generalService.getDataInput("OBLIGADO SOLIDARIO","EDIFICIO"					, null         	);  
			$scope._andador	        	= generalService.getDataInput("OBLIGADO SOLIDARIO","ANDADOR"					, null         	);
			$scope._calle           	= generalService.getDataInput("OBLIGADO SOLIDARIO","CALLE"						, null         	);
			$scope._codigoPostal		= generalService.getDataInput("OBLIGADO SOLIDARIO","CODIGO POSTAL"				, null         	);
			$scope._colonia				= generalService.getDataInput("OBLIGADO SOLIDARIO","COLONIA"					, null         	);
			$scope._estado				= generalService.getDataInput("OBLIGADO SOLIDARIO","ESTADO"						, null         	);
			$scope._lote				= generalService.getDataInput("OBLIGADO SOLIDARIO","LOTE"						, null         	);
			$scope._manzana				= generalService.getDataInput("OBLIGADO SOLIDARIO","MANZANA"					, null			);
			$scope._delegacion			= generalService.getDataInput("OBLIGADO SOLIDARIO","MUNICIPIO"					, null         	);
			$scope._numeroExterior		= generalService.getDataInput("OBLIGADO SOLIDARIO","NUMERO EXTERIOR"			, null      	);
			$scope._numeroInterior		= generalService.getDataInput("OBLIGADO SOLIDARIO","NUMERO INTERIOR"			, null			);
			$scope._superManzana		= generalService.getDataInput("OBLIGADO SOLIDARIO","SUPERMANZANA"				, null			);
			$scope._telefonoCasa		= generalService.getDataInput("OBLIGADO SOLIDARIO","TELEFONO CASA"				, null			);
			$scope._celular				= generalService.getDataInput("OBLIGADO SOLIDARIO","CELULAR"					, null			);
			$scope._referencia			= generalService.getDataInput("OBLIGADO SOLIDARIO","REFERENCIA"					, null			);
			$scope._tipoAval			= generalService.getDataInput("OBLIGADO SOLIDARIO","TIPO AVAL"					, null			);
			$scope._tipoPropiedad		= generalService.getDataInput("OBLIGADO SOLIDARIO","TIPO PROPIEDAD"				, null			);
			$scope._tipoPropiedadInput	= generalService.getDataInput("OBLIGADO SOLIDARIO","TIPO PROPIEDAD INPUT"		, null			);
			$scope._etqDireccion		= generalService.getDataInput("OBLIGADO SOLIDARIO","ETIQUETA DIRECCION"			, $scope.origen	);
			$scope._etqMapa				= generalService.getDataInput("OBLIGADO SOLIDARIO","ETIQUETA MAPA"				, $scope.origen	);
			$scope._etqReferencia		= generalService.getDataInput("OBLIGADO SOLIDARIO","ETIQUETA REFERENCIA"		, $scope.origen	);
			$scope._etqTelefono			= generalService.getDataInput("OBLIGADO SOLIDARIO","ETIQUETA TELEFONO"			, $scope.origen	);
			$scope._etqTiempo			= generalService.getDataInput("OBLIGADO SOLIDARIO","ETIQUETA TIEMPO"			, $scope.origen	);
			$scope._etqNacimiento		= generalService.getDataInput("OBLIGADO SOLIDARIO","ETIQUETA NACIMIENTO"		, $scope.origen	);
			$scope._etqNombre			= generalService.getDataInput("OBLIGADO SOLIDARIO","ETIQUETA NOMBRE"			, $scope.origen	);
			$scope._etqPropiedades		= generalService.getDataInput("OBLIGADO SOLIDARIO","ETIQUETA PROPIEDADES"		, $scope.origen	);
			$scope._etqPropiedadesInput	= generalService.getDataInput("OBLIGADO SOLIDARIO","ETIQUETA PROPIEDADES INPUT"	, $scope.origen	);
			$scope._etqIngresos			= generalService.getDataInput("OBLIGADO SOLIDARIO","ETIQUETA INGRESOS"			, $scope.origen	);
			$scope._etqTipoAval			= generalService.getDataInput("OBLIGADO SOLIDARIO","ETIQUETA TIPO AVAL"			, $scope.origen	);
			$scope._btnGuardar			= generalService.getDataInput("OBLIGADO SOLIDARIO","BOTON GUARDAR"				, $scope.origen	);
			
			$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";
	    	
	    	$scope.datosAval = {
		    	flujoEfectivo: ""
		    };
	    	
	    	$scope.txtBtnContacto = "Guardar";
	    	
	    	AvalContactoFactory.main( $scope );
	    	AvalBasicoFactory.main( $scope );
	    	
	    	$scope.obligarAvisos();
	    	
	    }	    
	    
	    $scope.obligarAvisos = function()
	    {
	    	
	    	if( $rootScope.avisosCheck.value )
				$scope.bloqueaInput = false;
			else	
				$scope.bloqueaInput = true;
	    	
	    };
	    
	    $scope.getCurrentAddress = function( doFunction )
	    {

	        var addressObject = $scope.gralAddress;
	        var address = $scope.completeAddress;

	        var street = $rootScope.solicitudJson.avales[0].datosHogar.calle; //addressObject.street;
	        var extnum = $rootScope.solicitudJson.avales[0].datosHogar.numeroExterior; //addressObject.extnum;
	        var intnum = $rootScope.solicitudJson.avales[0].datosHogar.numeroInterior; //addressObject.intnum;
	        var zipcode = $rootScope.solicitudJson.avales[0].datosHogar.cp; //;
	        
	        var suburb = null;
	        
	        if( $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc )
	        	suburb = $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc; //addressObject.suburb;
	        else
	        	suburb = $rootScope.solicitudJson.avales[0].datosHogar.colonia; //addressObject.suburb;
	        
	        var town = $rootScope.solicitudJson.avales[0].datosHogar.estado; //
	        var del = $rootScope.solicitudJson.avales[0].datosHogar.delegacion; //
	        
	        if ( street !== '' && street ) {
	            
	            upu_address[0] = street;
	            address += street;            
	    
	        }

	        if( extnum !== '' && extnum ){

	            upu_address[1] = extnum;
	            address += ' ' + extnum;

	        }

	        if( intnum !== '' && intnum){

	            upu_address[2] = intnum;
	            address += ', ' + intnum;

	        }

	        if( zipcode !== '' && zipcode ){

	            upu_address[3] = zipcode;
	            address += ', ' + zipcode;
	            refreshMap( address );
	            $scope.getStreetView();

	        }

	        if( suburb !== '' && suburb ){

	            upu_address[4] = suburb;
	            address += ', ' + suburb;

	        }
	        
	        if( del !== '' && del ){

	            upu_address[5] = del;
	            address += ', ' + del;

	        }

	        if( town !== '' && town ){

	            upu_address[6] = town;
	            address += ', ' + town;
	            refreshMap( address );
	            $scope.getStreetView();


	        }

	        $scope.gralAddress.completeAddress = address;

	        if( doFunction ){
	        	doFunction();
	        }
	        
	    };/* END GET_CURRENT_ADDRESS FUNCTION */
	    
	    $scope.suburbEvent = function( flag ){
	    	
	    	$rootScope.solicitudJson.avales[0].datosHogar.delegacion = $rootScope.solicitudJson.avales[0].datosHogar.colonia.delegacion; 
            $rootScope.solicitudJson.avales[0].datosHogar.idEstado = parseInt( $rootScope.solicitudJson.avales[0].datosHogar.colonia.idEstado );
            $rootScope.solicitudJson.avales[0].datosHogar.estado = $rootScope.solicitudJson.avales[0].datosHogar.colonia.descEstado;
            $rootScope.solicitudJson.avales[0].datosHogar.idDelegacion = parseInt($rootScope.solicitudJson.avales[0].datosHogar.colonia.idDelegacion);
            
            if( flag )
            	$scope.getCurrentAddress();
	    	
	    }; /* END SUBURBEVENT */

	    $scope.getStreetViewURL = function()
	    {
	    	
	    	var url = MarkerCreatorService.doStreetViewURL(  $scope.map.panorama, 500, 500, 'http://maps.googleapis.com/maps/api' );
	    	
	    	console.log( url );   	
	    	
	    	
	    	convertImgToBase64( url, function( base64Img ){
	    		
	    		//localStorage['test'] = base64Img;
	    		
	    	});
	    	
	    	
	    	setTimeout( function(){
	    		
	    		//algo = localStorage.getItem( 'test' );
	    		
	    	}, 10);
	    	
	    	//localStorage.removeItem( 'test' );
	    	
	    };/* END GET_STREET_VIEW_URL FUNCTION */

	    $scope.blockCP = false;
	    
	    $scope.serviceModuleLocation = function( zipcode, dataType )
	    {
	    	
//	    	if ( avalForm.cp.$valid){
	    		
		    	if( zipcode != "" && zipcode != -1 && zipcode != 0 ){
		    		
		    		var len = 0;
		    		
		    		if( zipcode ){
		    			len = zipcode.length;
		    		}else{
		    			resetFields( false );
		    		}	    		
		    		
		    		if( len == 5 && $scope.blockCP == false ){
		    	
		    			$scope.blockCP = true;
		    			$scope.zonification = true;

		    			$scope.getCurrentAddress();
		    			
			    		solicitudService.consultaCP( zipcode ).then(
		    	    		
			    				function( data ){
			    					
			    					$scope.zonification = false;
			    					
								    if (!$scope.guardarShow)
								    	$rootScope.waitLoaderStatus = LOADER_HIDE;
								
			    					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								
			    						try{
										
			    							var responseJson = JSON.parse(data.data.respuesta);										
									
			    							if( responseJson.codeError == "00" ){
		
			    								$scope.isInputDisabled = true;
			    								resetFields( false );
			    								$scope.blockCP = false;
			    								dynamicSelectSuburb( responseJson.numRegistros, responseJson.registro, dataType );
		
			    							}else{

			    								//Error
			    								$scope.isInputDisabled = false;
												resetFields( true );
												
												var foo = function(){
													$scope.blockCP = false;
												};
												
												$rootScope.message(
														$scope._titulo.texto, [ "El código postal es inválido." ], 
														"Aceptar", null,  $scope._titulo.colorSeccion, $scope._titulo.colorSeccion, 
														foo, "GENERAL", "ERROR CP");
												
			    							}/* END IF RESPONSEJSON */
										
			    						}catch(e){
			    							console.error(e.message);
			    						}
									
			    					}else{	
			    						
			    						$scope.blockCP = false;
			    						$rootScope.message(	"Error en el servidor", [ generalService.displayMessage(data.data.descripcion) ],
	    										"Aceptar", null,  $scope._titulo.colorSeccion , $scope._titulo.colorSeccion,
	    										null, "GENERAL", "ERROR GENERAL");
			    						
			    					}/* END IF-ELSE RESPONSE CODIGO EXITO */
			    					
			    					$scope.blockCP = false;
								
			    				}, function( error ){
			    					
			    					$scope.blockCP = false;
			    					$scope.zonification = false;
			    					$rootScope.message(	"Error en el servidor", [ ERROR_SERVICE ],
			    										"Aceptar", null,  $scope._titulo.colorSeccion , $scope._titulo.colorSeccion,
			    										null, "GENERAL", "ERROR GENERAL");
				                
			    				}/* END FUNCTION ERROR */
					
			    		);/* END SOLICITUD SERVICE */
			    		
		    		}else{
		    			resetFields( false );
		    		}/* END IF-ELSE LEN = 5 */
		    		
		    	}else{
		    		resetFields( true );
		    	}/* END IF-ELSE ZIPCODE VALIDATE */
	    	
//	    	}/* END IF SCOPE FORM VALID*/
	    	
	    };/* END SERVICE MODULE LOCATION */

	    function resetFields( flag )
	    {
	    	
	    	if( flag ){
	    		
	    		//Error
	    		$rootScope.solicitudJson.avales[0].datosHogar.cp = "";
	    		$rootScope.solicitudJson.avales[0].datosHogar.colonia = "";
	    		
	    	}
	    	
	    	$scope.combos.colonias = [];
	    	
	    	if( $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc )
    			$rootScope.solicitudJson.avales[0].datosHogar.colonia = "";
	    	
	    	$rootScope.solicitudJson.avales[0].datosHogar.delegacion = "" 
            $rootScope.solicitudJson.avales[0].datosHogar.idEstado = 0;
            $rootScope.solicitudJson.avales[0].datosHogar.estado = "";
            $rootScope.solicitudJson.avales[0].datosHogar.idDelegacion = 0;
            	    	
	    };/* END RESET_FIELDS FUNCTION */
	    
	    function dynamicSelectSuburb( numRegistros, registros, dataType ){
	    	
	    	try{
	    		
	    		var numColonias = 0;
	    		var colonias = [];
	    		
	    		if( parseInt(numRegistros) > 0 ){
	    			
	    			if( parseInt(numRegistros) == 1 ){
	    				
	    				if( parseInt(registros.paisID) == 1 ){
	    					
	    					numColonias++;
		    				var dataObj = {
		    					"id": 0,
		    					"idEstado": registros.edoID,
		    					"desc": registros.descColonia,
		    					"descEstado": registros.descEdo,
		    					"delegacion": registros.descPoblacion,
		    					"idDelegacion": registros.poblacionID
		    				};
		    				
		    				colonias.push( dataObj );
		    				
		    				if( dataType != null && dataType != "" ){
		    					
	    						if( dataObj.desc === dataType ){
	    							$rootScope.solicitudJson.avales[0].datosHogar.colonia = colonias[0];
	    						}
	    					
	    					}
	    				}
	    				
	    			}else{
	    			
	    				for( var i = 0; i < parseInt(numRegistros); i++ ){
	    				    		
	    					if( parseInt(registros[i].paisID) == 1 ){
	    						
	    						numColonias++;
		    					var dataObj = {
		    						"id": i,
		    						"idEstado": registros[i].edoID,
		    						"desc": registros[i].descColonia,
		    						"descEstado": registros[i].descEdo,
		    						"delegacion": registros[i].descPoblacion,
		    						"idDelegacion": registros[i].poblacionID
		    					};
		    				
		    					colonias.push( dataObj );
		    				
		    					if( dataType != null && dataType != "" ){
		    					
		    						if( dataObj.desc === dataType ){
		    							$rootScope.solicitudJson.avales[0].datosHogar.colonia = colonias[i];
		    						}
		    					
		    					}
	    					}	
	    				}
	    				
	    			}
	    			
	    		}
	    		
	    		if( numColonias > 0 ){
	    			
		    		$scope.combos['colonias'] =  colonias;
		    			    		
		    		if( dataType != null && dataType != "" ){
		    			
	//	    			generalService.setRespaldo($rootScope.solicitudJson);
		    			
	//	    			MarkerCreatorService.setPanorama( null );
		    			$scope.suburbEvent( false );
		    			
		    			var domicilios = $rootScope.solicitudJson.avales[0].datosHogar; 
		    			
		    			$rootScope.solicitudJson.avales[0].datosHogar.delegacion = $rootScope.solicitudJson.avales[0].datosHogar.colonia.delegacion; 
		                $rootScope.solicitudJson.avales[0].datosHogar.idEstado = parseInt( $rootScope.solicitudJson.avales[0].datosHogar.colonia.idEstado );
		                $rootScope.solicitudJson.avales[0].datosHogar.estado = $rootScope.solicitudJson.avales[0].datosHogar.colonia.descEstado;
		                $rootScope.solicitudJson.avales[0].datosHogar.idDelegacion = parseInt($rootScope.solicitudJson.avales[0].datosHogar.colonia.idDelegacion);
		    					                
		                $timeout( function(){
		    				
		    				var latitud = $rootScope.solicitudJson.avales[0].datosHogar.zonificacion.latitud;
			    			var longitud = $rootScope.solicitudJson.avales[0].datosHogar.zonificacion.longitud;
		    				
			    			var astorPlace = { 
			    					lat: parseFloat( latitud ), 
			    					lng: parseFloat( longitud )
			    			};
			    			
		    				var panoTMP = MarkerCreatorService.getPanorama();
			    				
		    				panoTMP.setPosition( astorPlace );
		    				panoTMP.setMotionTracking(false);//Erick was here
		    				
			    			panoTMP.setPov({
			    				heading: parseFloat( $rootScope.solicitudJson.avales[0].datosHogar.zonificacion.heading ),
			    				pitch: parseFloat( $rootScope.solicitudJson.avales[0].datosHogar.zonificacion.pitch ),
			    				zoom: parseFloat( $rootScope.solicitudJson.avales[0].datosHogar.zonificacion.zoom )
			    			});
		    		
				    		panoTMP.setVisible(true);
			    			
			    	        MarkerCreatorService.refreshMarkerByZone( latitud, longitud, function ( marker ) {  
			    	        	 $scope.map.markers[0] = marker ;
				    	         refresh( marker );
			    			});
		    				
		    			}, 100);
		    			
		                var arrayColonia=null;
		                if( $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc ){
		                	arrayColonia=$rootScope.solicitudJson.avales[0].datosHogar.colonia;
		    				$rootScope.solicitudJson.avales[0].datosHogar.colonia = $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc;
		                }
		    			generalService.setRespaldo($rootScope.solicitudJson);
		    			if (arrayColonia != null)
		    				$rootScope.solicitudJson.avales[0].datosHogar.colonia=arrayColonia;
		    			
		    		}
		    		
		    		MarkerCreatorService.enableFullScreenPanorama();
		    		
	    		}/* END IF NUMCOLONIAS */
	    		
	    	}catch(e){
//	    		console.error( e.message );
	    		$rootScope.message(	"Error en el servidor", [ ERROR_SERVICE ],
						"Aceptar", null,  $scope._titulo.colorSeccion , $scope._titulo.colorSeccion,
						null, "GENERAL", "ERROR GENERAL");
	    	}
	    	
	    }/* END DYNAMIC */
	    

	    function convertImgToBase64( url, callback, outputFormat ){

	        var img = new Image();
	        img.crossOrigin = 'Anonymous';
	        

	        img.onload = function(){
	            var canvas = document.createElement('CANVAS');
	            var ctx = canvas.getContext('2d');
	            canvas.height = img.height;
	            canvas.width = img.width;
	            ctx.drawImage(img,0,0);
	            var dataURL = canvas.toDataURL( outputFormat || 'image/png');
	            callback( dataURL );
	            canvas = null; 
	        };

	        img.src = url;

	    };/* END CONVERT_IMG_TO_BASE64 FUNCTION */
	    
	    $scope.getStreetView = function()
	    {
	    	
	    	var json_panorama = MarkerCreatorService.getStreetView( null );
	    	$scope.map.panorama = json_panorama;
	    	
	    };/* END GET_STREET_VIEW FUNCTIO */

	    function refreshMap( stringAddress )
	    {
	    	
	    	var zipcode = $rootScope.solicitudJson.avales[0].datosHogar.cp; //;
	    	
	    	MarkerCreatorService.createByAddress( stringAddress + ", MÉXICO", zipcode, function( marker ) {
	    		
	    		//$scope.map.markers.push( marker );
	    		$scope.map.markers[0] = marker ;
	    		refresh( marker );
	    		
	    	});
	    	
	    };/* END REFRESH_MAP FUNCTION */

	    function refresh( marker ) 
	    {
	    	
	    	$scope.gralAddress.latitude = marker.latitude;
	    	$scope.gralAddress.longitude = marker.longitude;  
	    	$scope.autentiaMarker = marker;
	    	
	    	$scope.map.control.refresh( {
	    		latitude: marker.latitude, 
	    		longitude: marker.longitude
	    	});
	    	
	    };/* END REFRESH FUNCTTION */
	    	
	    $scope.getDescripcionCatalogo = function(id, lista)
	    {
			return generalService.descripcionCatalogo(id, lista);
		};
		
		$scope.avalHandler = function()
		{
			
			var opc = $rootScope.solicitudJson.avales[0].idTipoAval;
				
			$scope._etqPropiedades1 = {
					texto: "",
					imagen: ""
			};
			
			if( opc === AVAL_INGRESOS ){
				
				$scope.esIngreso = true;
				
				$scope._etqPropiedades1.texto = $scope._etqIngresos.texto;
				$scope._etqPropiedades1.imagen = $scope._tipoPropiedadInput.imagen;
				
				$rootScope.solicitudJson.avales[0].idTipoPropiedad = 0;
				$rootScope.solicitudJson.avales[0].tipoPropiedadDes = "";
				
			}else{
				
				$scope.esIngreso = false;
				
				$scope._etqPropiedades1.texto = $scope._etqPropiedades.texto;
				$scope._etqPropiedades1.imagen = $scope._tipoPropiedad.imagen;
				
//				$rootScope.solicitudJson.avales[0].flujoEfectivo = [];				
				
			}			
			
		};
		
		$scope.saveStreetView = function()
	    {
			
			var panorama = MarkerCreatorService.getPanorama();
	    		
	    	$rootScope.solicitudJson.avales[0].datosHogar.zonificacion.latitud = "" + panorama.getPosition().lat();
	    	$rootScope.solicitudJson.avales[0].datosHogar.zonificacion.longitud = "" + panorama.getPosition().lng();
	    	$rootScope.solicitudJson.avales[0].datosHogar.zonificacion.heading = "" + panorama.getPov().heading;
	    	$rootScope.solicitudJson.avales[0].datosHogar.zonificacion.pitch = "" + panorama.getPov().pitch;
	    	$rootScope.solicitudJson.avales[0].datosHogar.zonificacion.zoom = "" + panorama.getPov().zoom;
	    	 
	    	//FOV is calucalated using the below forumla.
	    	$rootScope.solicitudJson.avales[0].datosHogar.zonificacion.fov = "" + (90 / Math.max( 1, panorama.getPov().zoom ) );
	    		
	    }
	    
		$scope.validar = function()
	    {
	    	
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			
			var dataValidate = {
				valido: false,
				mensaje: [ "Debes ingresar una fecha." ]
			};
				    	
			var anio = $scope.nAnno;
			var mes = $scope.nMes;
			var dia = $scope.nDia;
			
	    	if( anio === 'Año' && mes === 'Mes' && dia === 'Día' ){
	    			    		
	    		dataValidate.valido = true;
	    		
	    		if( dataValidate.mensaje.length != 0 ){
		    		dataValidate.mensaje.pop();
	    		}

	    		
	    	}else{

	    		if( anio != 'Año' && mes != 'Mes' && dia != 'Día' ){

	    			dataValidate.valido = true;
		    		
	    			if( dataValidate.mensaje.length != 0 ){
			    		dataValidate.mensaje.pop();
		    		}
	    			
		    	}	    	 

	    	}

	    	return dataValidate;
	    	
	    };
	    
		$scope.validacionHomonimos = function()
		{
			
			var flag = true;
			
			if( $rootScope.solicitudJson.avales[0].nombre == '' &&
				$rootScope.solicitudJson.avales[0].apellidoPaterno == '' &&
				$rootScope.solicitudJson.avales[0].apellidoMaterno == '' ){
				flag = false;
			}
			
			return flag;
			
		};
		
		$scope.saveZone = function(){
			
	    	var jsonTM = $rootScope.solicitudJson.avales[0].datosHogar.colonia;
	    	
	    	console.log( jsonTM );
	    	
	    	if( jsonTM.hasOwnProperty( 'desc' ) ){
	    		
	    		$rootScope.solicitudJson.avales[0].datosHogar.delegacion = $rootScope.solicitudJson.avales[0].datosHogar.colonia.delegacion; 
                $rootScope.solicitudJson.avales[0].datosHogar.idEstado = parseInt( $rootScope.solicitudJson.avales[0].datosHogar.colonia.idEstado );
                $rootScope.solicitudJson.avales[0].datosHogar.estado = $rootScope.solicitudJson.avales[0].datosHogar.colonia.descEstado;
                $rootScope.solicitudJson.avales[0].datosHogar.idDelegacion = parseInt($rootScope.solicitudJson.avales[0].datosHogar.colonia.idDelegacion);
                $rootScope.solicitudJson.avales[0].datosHogar.colonia = $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc;
                
	    	}else{
//	    		$scope.serviceModuleLocation( $rootScope.solicitudJson.avales[0].datosHogar.cp, $rootScope.solicitudJson.avales[0].datosHogar.colonia );
	    	}
	    
	    };		
			    
	    $scope.guardarContacto = function()
	    {
	    	var formatoNacimiento = $rootScope.solicitudJson.avales[0].fechaNaciomiento.split("/")[2] + "-" +
	    							$rootScope.solicitudJson.avales[0].fechaNaciomiento.split("/")[1] + "-" +
	    							$rootScope.solicitudJson.avales[0].fechaNaciomiento.split("/")[0];
	    	if(formatofechaMayorEdad >= formatoNacimiento){
	    		if(formatofechaMayorEdad75 <= formatoNacimiento){
			    	if( $rootScope.avisosCheck.value ){
			    		$rootScope.solicitudJson.avales[0].aceptaTerminos = 1;
			    		$rootScope.solicitudJson.avales[0].tratamientoDatos = 1;
			    		$rootScope.solicitudJson.avales[0].transferenciaDatos = 1;
			    		$rootScope.solicitudJson.avales[0].aceptaConsultaBuro = 1;
			    	}
			    		    	
			    	if( AvalContactoFactory.esNombreCliente() )
			    		$rootScope.message(	"ESPERA", ['Coméntale a ' + $scope.nombreCompleto + ' , que no es posible registrarlo como Coacreditado ya que tiene una solicitud de crédito en proceso.'] 
			    		, "Aceptar", null, $scope._titulo.colorSeccion, $scope._titulo.colorSeccion );
			    	else
			    		$scope.guardarSeccion( AVAL.subSeccion.CONTACTO );
	    		}else
	    			$rootScope.message( "Datos inválidos", ["El Coacreditado supera la edad máxima definida en las políticas internas, por lo cual, no es posible continuar con el proceso."] , "Aceptar", null, "bgazulT", $scope._titulo.colorSeccion,null,null,null);
	    	}else
	    		$rootScope.message( "Datos inválidos", ["El Coacreditado no cumple con la edad mínima requerida por las políticas internas, por lo cual, no es posible continuar con el proceso."] , "Aceptar", null, "bgazulT", $scope._titulo.colorSeccion,null,null,null);
	    };
	    
	    $scope.guardarBasico = function()
	    {
	    	
	    	$rootScope.solicitudJson.avales[0].flujoEfectivo = [];
	    	
	    	for( var currentFE in $scope.fe ){
	    		if( $scope.fe[currentFE].monto != '' ){
	    			$scope.fe[currentFE].monto = parseInt(generalService.cleanValue( $scope.fe[currentFE].monto ));
	    			$rootScope.solicitudJson.avales[0].flujoEfectivo.push( $scope.fe[currentFE] );
	    		}
	    	}
	    	
	    	if( configuracion.origen.tienda ){
	    		
	    		if( $scope.enviarArchivoFoto ){
					AvalBasicoFactory.archivarFoto();
				}
			
				if( $scope.enviarArchivoHuella ){
					AvalBasicoFactory.archivarHuella();
				}
				
				if( !$scope.guardarFoto ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					return;
				}
					
				
				if( !$scope.guardarHuella ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					return;
				}
				
	    	}	    		
	    	
	    	$scope.guardarSeccion( AVAL.subSeccion.BASICO );
	    	
	    };
	    
	    $scope.guardarHogar = function()
	    {
	    	
	    	$scope.saveZone();
			$scope.saveStreetView();
	    	$scope.guardarSeccion( AVAL.subSeccion.HOGAR );
	    	
	    };
	    
	    $scope.guardarSeccion = function( subSeccion )
	    {
	    
	    	if( $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc )
				$rootScope.solicitudJson.avales[0].datosHogar.colonia = $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc;
	    	
	    	var callBackFunction = function( encolar ){
	    		
	    		if( typeof encolar !== 'undefined' && encolar != null && encolar ){
	    			AvalContactoFactory.archivarIFE();
	    			AvalContactoFactory.archivarFirmas();
	    		}
	    			    		
	    		$scope.servicioGuardar( subSeccion, encolar );
	    		
	    	};
	    	
	    	$scope.guardarPorcentajeTemporal();
	    		    	
	    	switch (subSeccion.id) {
				case AVAL.subSeccion.CONTACTO.id:
						$rootScope.solicitudJson.avales[0].porcentajeContacto  = cuentatext( subSeccion.formulario );
						if( $rootScope.solicitudJson.avales[0].primerInser == 0 )
							$scope.callHomonimos( callBackFunction );
						else
							callBackFunction();
					break;
				case AVAL.subSeccion.BASICO.id:
						$rootScope.solicitudJson.avales[0].porcentajeBasico  = cuentatext( subSeccion.formulario );
						callBackFunction();
					break;
				case AVAL.subSeccion.HOGAR.id:
						$rootScope.solicitudJson.avales[0].datosHogar.porcentaje  = cuentatext( subSeccion.formulario );
						callBackFunction();
					break;
			};
	    	
	    };
	    
	    $scope.guardarPorcentajeTemporal  = function()
	    {
	    	
	    	$scope.percentContacto = $rootScope.solicitudJson.avales[0].porcentajeContacto;
			$scope.percentBasico = $rootScope.solicitudJson.avales[0].porcentajeBasico;
			$scope.percentHogar = $rootScope.solicitudJson.avales[0].datosHogar.porcentaje;
			
	    };
	    
	    $scope.servicioGuardar = function( subSeccion, encolar )
	    {
	    	if ($scope.vigenciaInvalida && $rootScope.solicitudJson.avales[0].banderaOCR == 1){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
//				$rootScope.message($scope.titulo.texto,["Año de identificación expedida"], "Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion,null,"DATOS BASICOS","FECHA EXPEDIDA");
				$rootScope.message($scope._titulo.texto,["La identificación no está vigente. Favor de solicitar e ingresar una nueva identificación para continuar con el proceso"], "Aceptar", null, $scope._titulo.colorModal, $scope._titulo.colorSeccion,null,null,null);
			}else{
		    	var arrayPercent = [  $rootScope.solicitudJson.avales[0].porcentajeContacto, $rootScope.solicitudJson.avales[0].porcentajeBasico, $rootScope.solicitudJson.avales[0].datosHogar.porcentaje ];
		    	var arrayPercentTmp = [ $scope.percentContacto, $scope.percentBasico, $scope.percentHogar ];
		    	var porcentajeant = generalService.average( arrayPercentTmp );
				$rootScope.solicitudJson.avales[0].porcentaje  = generalService.average( arrayPercent );
				
				validateService.limpiaMascaras();
				var solicitudJsonString = generalService.delete$$hashKey( $rootScope.solicitudJson );
		    	
		    	$rootScope.waitLoaderStatus = LOADER_SHOW;
				solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: SECCION_AVAL } ).then(
						function(data){
				
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
					
								var responseJson = JSON.parse(data.data.respuesta);						
	
								if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									
									$rootScope.mapas = undefined;
									$rootScope.solicitudJson = responseJson.data;
									$rootScope.porcentajes.secciones[4].porcentaje = $rootScope.solicitudJson.avales[0].porcentaje;
									
									var json = $rootScope.solicitudJson;
									
									var jsonRequest = {
								    	solicitud: json,
								    	consultaBuro: 1
								    };
									
									if( $rootScope.solicitudJson.avales[0].porcentaje == 100 
											&& $rootScope.solicitudJson.avales[0].consultaBuro == 0 ){
										buroService.consultaBuroAval( jsonRequest );
									}else{
										
										if( $scope.avalPresente() ){
											switch (subSeccion.id) {
												case AVAL.subSeccion.BASICO.id:
														$scope.tabContactoCSS = csstabs.off;
														$scope.tabBasicosCSS = csstabs.off;
														$scope.tabHogarCSS = csstabs.on;
														$scope.callTabHogar();
													break;
												case AVAL.subSeccion.HOGAR.id:
														generalService.locationPath( validacionPath[SECCION_OCHO_PASOS].nombrePath );
													break;
												case AVAL.subSeccion.CONTACTO.id:
														if( typeof encolar !== 'undefined' && encolar != null && encolar ){
															var arrayColonia=null;
															if( $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc ){
																arrayColonia=$rootScope.solicitudJson.avales[0].datosHogar.colonia;
																$rootScope.solicitudJson.avales[0].datosHogar.colonia = $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc;
															}
											    			generalService.setRespaldo($rootScope.solicitudJson);
											    			if (arrayColonia != null)
											    				$rootScope.solicitudJson.avales[0].datosHogar.colonia=arrayColonia;
										    			}
														$scope.tabContactoCSS = csstabs.off;
														$scope.tabBasicosCSS = csstabs.on;
														$scope.tabHogarCSS = csstabs.off;
													break;
											}
										}else{
											generalService.locationPath( validacionPath[SECCION_OCHO_PASOS].nombrePath );
										}
										$rootScope.waitLoaderStatus = LOADER_HIDE;
									}

									
								}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
								}else{
									if(responseJson.codigo == ERROR_SOL_RECHAZADA){
										var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
										var marca = $rootScope.solicitudJson.marca;
										var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
										var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
										$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],
												"Aceptar", "/simulador",  "bgazulT" , "btn verdeD",buildJsonDefault);
									}else{
										if( subSeccion.id == AVAL.subSeccion.HOGAR.id )
											$scope.serviceModuleLocation( $rootScope.solicitudJson.avales[0].datosHogar.cp, $rootScope.solicitudJson.avales[0].datosHogar.colonia );
										$rootScope.solicitudJson.avales[0].porcentaje = porcentajeant;
										$rootScope.message(	"Error en el servidor", [ $scope.mensajeError ],
												"Aceptar", null,  $scope._titulo.colorSeccion , $scope._titulo.colorSeccion,
												null, "GENERAL", "ERROR GENERAL");
									}
									$rootScope.waitLoaderStatus = LOADER_HIDE;
								}
					
								
							}else{
								if( subSeccion.id == AVAL.subSeccion.HOGAR.id )
									$scope.serviceModuleLocation( $rootScope.solicitudJson.avales[0].datosHogar.cp, $rootScope.solicitudJson.avales[0].datosHogar.colonia );
								$rootScope.solicitudJson.avales[0].porcentaje = porcentajeant;
								$rootScope.message(	"Error en el servidor", [ generalService.displayMessage(data.data.descripcion) ],
										"Aceptar", null,  $scope._titulo.colorSeccion , $scope._titulo.colorSeccion,
										null, "GENERAL", "ERROR GENERAL");
								$rootScope.waitLoaderStatus = LOADER_HIDE;
							}
					
						}, function(error){
							if( subSeccion.id == AVAL.subSeccion.HOGAR.id )
								$scope.serviceModuleLocation( $rootScope.solicitudJson.avales[0].datosHogar.cp, $rootScope.solicitudJson.avales[0].datosHogar.colonia );
							$rootScope.solicitudJson.avales[0].porcentaje = porcentajeant;
							$rootScope.waitLoaderStatus = LOADER_HIDE;							
																	
						}
				);/* END THEN SOLICITUD SERVICE */
			}
	    };
	    
		$scope.guardar = function(){	
			if ($scope.vigenciaInvalida && $rootScope.solicitudJson.avales[0].banderaOCR == 1){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
//				$rootScope.message($scope.titulo.texto,["Año de identificación expedida"], "Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion,null,"DATOS BASICOS","FECHA EXPEDIDA");
				$rootScope.message($scope._titulo.texto,["La identificación no está vigente. Favor de solicitar e ingresar una nueva identificación para continuar con el proceso."], "Aceptar", null, $scope._titulo.colorModal, $scope._titulo.colorSeccion,null,null,null);
			}else{
				$scope.datosActualesHomonimos = JSON.stringify(DatosAnterioresArreglo( 'avalForm', 'homonimo-aval' ));
				
				validateService.limpiaMascaras();
				
				if( $scope.datosAnterioresHomonimos === $scope.datosActualesHomonimos ){
					$scope.homonimoFlag = true;	
				}else{
					$scope.homonimoFlag = false;
					if( $scope.validacionHomonimos() ){
						$scope.callHomonimos();
					}
				}
							
				var validate = $scope.validar();
				if( $scope.homonimoFlag ){  
				if( validate.valido ){
					
					if( $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc )
						$rootScope.solicitudJson.avales[0].datosHogar.colonia = $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc;
				
	//				var jsonTM = $rootScope.solicitudJson.avales[0].datosHogar.colonia;
					
	//				if( jsonTM.hasOwnProperty( 'desc' ) )
	//					$rootScope.solicitudJson.avales[0].datosHogar.colonia = $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc;
	//	        	else
	//	        		$scope.serviceModuleLocation( $rootScope.solicitudJson.avales[0].datosHogar.cp, $rootScope.solicitudJson.avales[0].datosHogar.colonia );
					
					$scope.saveZone();
					$scope.saveStreetView();
					
	//				if( !angular.isUndefined( $rootScope.solicitudJson.avales[0].flujoEfectivo[0] ) ){
	//					$rootScope.solicitudJson.avales[0].flujoEfectivo[0].monto = parseInt( $rootScope.solicitudJson.avales[0].flujoEfectivo[0].monto );
	//					$rootScope.solicitudJson.avales[0].flujoEfectivo[0].idTipo = 1;
	//					$rootScope.solicitudJson.avales[0].flujoEfectivo[0].tipoDes = "INGRESO";
	//					$rootScope.solicitudJson.avales[0].flujoEfectivo[0].idConcepto = 3;
	//					$rootScope.solicitudJson.avales[0].flujoEfectivo[0].conceptoDes = "COMPROBABLES";					
	//				}
						
					
					var fechaSel = $scope.nAnno + "/" + $scope.nMes + "/" + $scope.nDia
			    	var fechaMin = yy75 + "/" + mm + "/" + dd
			    	if (($scope.nAnno == yyyy && $scope.nMes > mm) || ($scope.nAnno == yyyy && $scope.nMes == mm && $scope.nDia > dd)){
						var mensaje = "Datos inválidos";										
						$rootScope.message( mensaje, ["El cliente no cumple con la edad mínima requeridda por las políticas internas, por lo cual, no es posible continuar con el proceso."] , "Aceptar", 
											null, $scope._titulo.colorSeccion, $scope._titulo.colorSeccion, null,
											"GENERAL", "EDAD MINIMA");
			    	}else{
			    		
			    		if (fechaSel <= fechaMin){
			    			var mensaje = "Datos inválidos";										
							$rootScope.message( mensaje, ["El cliente supera la edad máxima definida en las políticas internas, por lo cual, no es posible continuar con el proceso."] , "Aceptar", 
												null, $scope._titulo.colorSeccion, $scope._titulo.colorSeccion, null,
												"GENERAL", "EDAD MAXIMA");
			    		}else{
			    			
			    			var porcentajeant = $rootScope.solicitudJson.avales[0].porcentaje;
			    			$rootScope.solicitudJson.avales[0].porcentaje  = cuentatext('avalForm');
			    			
			    			validateService.limpiaMascaras();
			    			var solicitudJsonString = generalService.delete$$hashKey( $rootScope.solicitudJson );
	//		    			$rootScope.waitLoaderStatus = LOADER_SHOW;
			    			
			    			if (offLine){				
			    				$rootScope.cargaDocumentos();
			    				$rootScope.waitLoaderStatus = LOADER_HIDE;
			    				$rootScope.porcentajes.secciones[4].porcentaje = $rootScope.solicitudJson.avales[0].porcentaje;
			    				generalService.locationPath("/ochoPasos");
			    			}else{
			    				$rootScope.waitLoaderStatus = LOADER_SHOW;
			    				solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: SECCION_AVAL } ).then(
			    						function(data){
								
			    							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
									
	//											$rootScope.waitLoaderStatus = LOADER_HIDE;
									
			    								var responseJson = JSON.parse(data.data.respuesta);						
			    								if(responseJson.codigo == 2){
			    									$rootScope.solicitudJson = responseJson.data;
			    									$rootScope.porcentajes.secciones[4].porcentaje = $rootScope.solicitudJson.avales[0].porcentaje;
			    									buroService.consultaBuro("bgAzul", "btn gris", "btn azul" );
			    								}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
			    									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
			    									$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
			    								}else{
			    									if(responseJson.codigo == ERROR_SOL_RECHAZADA){
			    										var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
														var marca = $rootScope.solicitudJson.marca;
														var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
			    										var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
			    										$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],
			    												"Aceptar", "/simulador",  "bgazulT" , "btn verdeD",buildJsonDefault);
			    									}else{			    									
				    									$scope.serviceModuleLocation( $rootScope.solicitudJson.avales[0].datosHogar.cp, $rootScope.solicitudJson.avales[0].datosHogar.colonia );
				    									$rootScope.solicitudJson.avales[0].porcentaje = porcentajeant;
				    									$rootScope.message(	"Error en el servidor", [ $scope.mensajeError ],
					    										"Aceptar", null,  $scope._titulo.colorSeccion , $scope._titulo.colorSeccion,
					    										null, "GENERAL", "ERROR GENERAL");
			    									}
			    								}
									
			    								$rootScope.waitLoaderStatus = LOADER_HIDE;
			    							}else{
			    								$scope.serviceModuleLocation( $rootScope.solicitudJson.avales[0].datosHogar.cp, $rootScope.solicitudJson.avales[0].datosHogar.colonia );
			    								$rootScope.solicitudJson.avales[0].porcentaje = porcentajeant;
			    								$rootScope.message(	"Error en el servidor", [ generalService.displayMessage(data.data.descripcion) ],
			    										"Aceptar", null,  $scope._titulo.colorSeccion , $scope._titulo.colorSeccion,
			    										null, "GENERAL", "ERROR GENERAL");
			    								$rootScope.waitLoaderStatus = LOADER_HIDE;
			    							}
									
			    						}, function(error){
			    							$scope.serviceModuleLocation( $rootScope.solicitudJson.avales[0].datosHogar.cp, $rootScope.solicitudJson.avales[0].datosHogar.colonia );
			    							$rootScope.solicitudJson.avales[0].porcentaje = porcentajeant;
			    							$rootScope.waitLoaderStatus = LOADER_HIDE;
			    																	
			    						}
			    				);/* END THEN SOLICITUD SERVICE */
			    			}/* END ELSE OFFLINE */	
			    		}/* END ELSE MAXIMA EDAD */
			    	}/* END ELSE MENOR EDAD */
				}else{
	//				generalService.avalPorcent = cuentatext('avalForm');
					$rootScope.message(	"Error en la página", validate.mensaje , "Aceptar", null, 
										$scope._titulo.colorSeccion, $scope._titulo.colorSeccion );
					$rootScope.waitLoaderStatus = LOADER_HIDE;
			    }/* END ELSE VALIDAR */
				}
	//			$timeout( function(){$rootScope.waitLoaderStatus = LOADER_HIDE;},0);
			}
		};
		
		$scope.ocrPresente = function()
		{
			
			if( $rootScope.solicitudJson.avales[0].presencial == 1 ){
				$scope.txtBtnContacto = "Siguiente";
				$scope.ocrCss = cssOcr.enabled;
			}else{
				$scope.ocrCss = cssOcr.disabled;
				$scope.txtBtnContacto = "Guardar";
			}
		};
		
		$scope.avalPresente = function()
		{
			
			var estaPresente = null;
			
			if( $rootScope.solicitudJson.avales[0].presencial == 1 ){
				$scope.tabContactoCSS = csstabs.on;
				$scope.tabBasicosCSS = csstabs.off;
				$scope.tabHogarCSS = csstabs.off;
				$scope.ocrCss = cssOcr.enabled;
				estaPresente = true;
			}else{
				$scope.tabContactoCSS = csstabs.on;
				$scope.tabBasicosCSS = csstabs.disabled;
				$scope.tabHogarCSS = csstabs.disabled;
				$scope.ocrCss = cssOcr.disabled;
				estaPresente = false;
			}
			
			return estaPresente;
			
		};/* END AVAL PRESENTE FUNCTION */
		
		$scope.cargaVigencia = function()
		{
			if ( $rootScope.solicitudJson.avales[0].fechaVigenciaIdentificacion != "" )
				$scope.vigenciaIdentificacion = parseInt($rootScope.solicitudJson.avales[0].fechaVigenciaIdentificacion.split('/')[2]);
			else
				$scope.vigenciaIdentificacion = "";
		};/* END CARGA VIGENCIA FUNCTION */
		
		$scope.fechaVigencia = function(vigencia)
		{
			if( parseInt(vigencia) )
				$rootScope.solicitudJson.avales[0].fechaVigenciaIdentificacion = "01/01/" + vigencia;
			if ( vigencia < anioActual )
				$scope.vigenciaInvalida = true;
			else
				$scope.vigenciaInvalida = false;
		};/* END FECHA VIGENCIA FUNCTION */
				
		if( zona_T.latitud != "" ){
						
			x = parseFloat( zona_T.latitud );
			y = parseFloat( zona_T.longitud );
			
		}else{
			
			console.log( 'Default location' );			
			
			x = parseFloat( localStorage.getItem( 'latitude' ) );
			y = parseFloat( localStorage.getItem( 'longitude' ) );
			
		}
		
		$scope.autentiaMarker = {
			latitude: x,
			longitude: y
		};
		
		$scope.initMap = function( doFunction ){
		
//			$timeout( function(){
				MarkerCreatorService.createByCoords( x, y, function ( marker ) {  
			        $scope.autentiaMarker = marker;
				}, doFunction);
				
			    $scope.map.markers[0] = $scope.autentiaMarker;
//			}, 10000);
			
//			MarkerCreatorService.createByCoords( x, y, function ( marker ) {  
//		        $scope.autentiaMarker = marker;
//			}, doFunction);
			
//		    $scope.map = {
//		    	center: {
//		    		latitude: $scope.autentiaMarker.latitude,
//					longitude: $scope.autentiaMarker.longitude
//		    	},
//			    zoom: 18,
//			    markers: [],
//			    control: {},
//			    options: {
//			    	scrollwheel: true, //false
//			    	streetViewControl: false,
//			    	panControl: false,
//			    	zoomControl: false
//			    },
//			    panorama: null
//			};
//		    $scope.map.markers[0] = $scope.autentiaMarker;
			
		};

//		MarkerCreatorService.createByCoords( x, y, function ( marker ) {  
//	        $scope.autentiaMarker = marker;
//		});
		
		$scope.map = {
			center: {
				latitude: $scope.autentiaMarker.latitude,
				longitude: $scope.autentiaMarker.longitude
			},
			zoom: 18,
			markers: [],
			control: {},
			options: {
				scrollwheel: true, //false
				streetViewControl: false,
				panControl: false,
				zoomControl: false
			},
			panorama: null
		};

	
	    if( $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc ){
	    	$rootScope.solicitudJson.avales[0].datosHogar.colonia = $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc;
		}
		
	});
	
});