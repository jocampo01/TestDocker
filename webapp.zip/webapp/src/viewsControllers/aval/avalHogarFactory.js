'use strict';

define( ["app"], function ( app ){

	app.factory( "AvalHogarFactory", function ( $timeout, $rootScope, $location, loginService, modalService, 
											 generalService, authService, solicitudService, 
											 clienteUnicoService, buroService ) {
		
		var hogarFactory = {};
		
			
		return hogarFactory;
	    		
	});/*END APP FACTORY - HogarFactory*/
	
});