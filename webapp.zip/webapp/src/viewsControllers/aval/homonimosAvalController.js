'use strict';

define(["app"], function (app) {

	app.controller( 'homonimosAvalController', function( $scope,  $rootScope, ngDialog, $location, solicitudService, 
												modalService, callCenterService, clienteUnicoService, generalService, $timeout ){
		
//		console.log( $scope );
//		console.log( ngDialog );
		
		var jsonString = $scope.ngDialogData.scopeParent.objectResponse;
		
		$scope.ngDialogData.parseJSON = JSON.parse( jsonString );
		
		$scope.radioValor = { valor: "" };
		$scope.promptDisabled = true;
		
		$scope.getHomonimo = function()
		{
					
			var currentCU = $scope.radioValor.valor;
			
			if( currentCU && currentCU != "" ){
				
				$scope.promptDisabled = false;
				
			}
			
		};
		
		$scope.setHomonimo = function()
		{
			
			var jsonString = $scope.radioValor.valor
			
			var currentCU = JSON.parse( jsonString );

			var avalados = parseInt( currentCU.avalados );
			
			if( avalados < 3 ){
				
				$rootScope.solicitudJson.avales[0].nombre = currentCU.nombre;			
				$rootScope.solicitudJson.avales[0].apellidoPaterno = currentCU.apePaterno;
				$rootScope.solicitudJson.avales[0].apellidoMaterno = currentCU.apeMaterno;
	
				var fechaNacimiento = currentCU.fecNacimiento.substring( 0, 10 );
				
				if( fechaNacimiento.indexOf( '-' ) > -1 ){
					fechaNacimiento = replaceAll( fechaNacimiento, '-', '/' );
				}
				
				if( fechaNacimiento.split('/')[0].length == 4 ){
					$scope.ngDialogData.scopeParent.nAnno = fechaNacimiento.split('/')[0];
					$scope.ngDialogData.scopeParent.nDia = fechaNacimiento.split('/')[2];
				}else{
					$scope.ngDialogData.scopeParent.nAnno = fechaNacimiento.split('/')[2];
					$scope.ngDialogData.scopeParent.nDia = fechaNacimiento.split('/')[0];
				}
				
				$scope.ngDialogData.scopeParent.nMes = fechaNacimiento.split('/')[1];
				
				$rootScope.solicitudJson.avales[0].datosHogar.calle = currentCU.calle;
				$rootScope.solicitudJson.avales[0].datosHogar.numeroExterior = currentCU.numExt;
				$rootScope.solicitudJson.avales[0].datosHogar.numeroInterior = currentCU.numInt;
				$rootScope.solicitudJson.avales[0].datosHogar.cp = currentCU.cp;
				
				$scope.ngDialogData.scopeParent.serviceModuleLocation( currentCU.cp, null );
				
				$timeout( function(){
					$scope.setSuburb( currentCU.estado );
				}, 700 );
				
//				var foo = function(){
//					$scope.ngDialogData.scopeParent.refreshStreetView();
//				};
//				
//				$timeout( foo, 1 );
				
//				$scope.ngDialogData.scopeParent.getCurrentAddress( foo );
				
				
				$scope.closeThisDialog();
			
			}else{
				modalService.alertModal( "", ["Infórmale a tu cliente que el Coacreditado que eligió ya tiene 3 avalados. Por politicas internas  no es posible efectuar el registro, es necesario capturar un nuevo Coacreditado. "], 
						"Aceptar", "bgAzul", "azul" );
			}
			
		};
		
		$scope.setSuburb = function( suburb )
		{
			
			var arraySuburb = $scope.ngDialogData.scopeParent.combos.colonias;
						
			var index = -1;
			
			_.each( arraySuburb, function( data, idx ) { 
			
				if ( data.desc === suburb ) {
				   index = idx;
				   return;
				}
				
			});

			
			console.log( arraySuburb[index] );

			$rootScope.solicitudJson.avales[0].datosHogar.colonia = arraySuburb[index];
			$rootScope.solicitudJson.avales[0].datosHogar.delegacion = arraySuburb[index].delegacion;
			$rootScope.solicitudJson.avales[0].datosHogar.idEstado = parseInt(arraySuburb[index].idEstado);
			
			
		};
		
		function replaceAll( string, find, replace )
		{
		
			return string.replace(new RegExp(escapeRegExp(find), 'g'), replace);
		
		}
		
		function escapeRegExp( string ) {
			
		    return string.replace( /([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1" );
		
		}
		
		
	});
	
});