'use strict';

define(["app"], function (app) {
	
	app.controller("avisosController", function (	$timeout, $scope, $rootScope, solicitudService, 
													generalService, modalService, buroService, messageData, 
													validateService ) {
		
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		$scope.confTipoWindows = configuracion.so.windows;
		$scope.firma1 = false;
		$scope.aceptaPrivacidad = false;
		$scope.esBuro = false;
		$scope.avisosAceptados = 0;
		$scope.urlDoc = "AvisoPrivacidad.html";
		$scope.doc_details;
		$rootScope.imgPrivacidad = "";
		$rootScope.imgBuro = "";
		$scope.firmaContratos = 0;
		$scope.aceptados = 0;
		$scope.tratDatos = $rootScope.solicitudJson.tratamientoDatos==0?false:true;
		$scope.transfDatos = $rootScope.solicitudJson.transferenciaDatos==0?false:true;
		$scope.esContratos = false;		
		
		$rootScope.doc_details = {
	        file_url: $scope.urlDoc
	    };
		
		generalService.setArrayValue("solicitudRecuperada", true);
		
		$scope.init = function()
	    {
			if( messageData ){
	    		$scope.setContentPage();
	    		$rootScope.waitLoaderStatus = LOADER_HIDE;
	    	}
	    
	    };/* END INIT FUNCITON */
		
//		$scope.$on('$viewContentLoaded', function(){
//			alert("hiii");
//			$rootScope.waitLoaderStatus = LOADER_HIDE;
//		});
//		
//	    angular.element(document).ready(function () {
//	    	alert("hiii2");
//	    });
		  
	    
//	    $scope.missionCompled = function()
//	    {
//	         alert('Done');   
//	    };
	    
		$scope.setContentPage = function()
	    {			
	    	if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";

	    	generalService.setMapping(  MODEL_VISTAS_JSON );
	    	$scope.txtRegresar = generalService.getDataInput("OCHO PASOS","TEXTO BOTON REGRESAR", $scope.origen);
	    	$scope.tituloAviso = generalService.getDataInput("AVISOS","TITULO AVISOS", $scope.origen);
	    	$scope.tituloBuro = generalService.getDataInput("AVISOS","TITULO BURO", $scope.origen);
	    	$scope.txtAvisos = generalService.getDataInput("AVISOS","TEXTO AVISOS", $scope.origen);
	    	$scope.nombreAviso = generalService.getDataInput("AVISOS","TEXTO PRIVACIDAD", $scope.origen);
	    	$scope.txtVerDoc = generalService.getDataInput("AVISOS","TEXTO VER DOCUMENTO", $scope.origen);
	    	$scope.imgDocs = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.AVISOS.IMG DOCUMENTOS.URL.valor"];
	    	$scope.txtCheck1 = generalService.getDataInput("AVISOS","TEXTO CHECK 1", $scope.origen);
	    	$scope.txtCheck2 = generalService.getDataInput("AVISOS","TEXTO CHECK 2", $scope.origen);
	    	$scope.txtCheck3 = generalService.getDataInput("AVISOS","TEXTO CHECK 3", $scope.origen);
	    	$scope.btnBorraFirma = generalService.getDataInput("AVISOS","BOTON BORRAR FIRMA", $scope.origen);
	    	$scope.btnContinuar = generalService.getDataInput("AVISOS","BOTON CONTINUAR", $scope.origen);
			
	    };/* END SET_CONTENT_PAGE FUNCTION */	    
		
		
		
		$scope.visualizaDoc =  function (){
			
			$scope.btnNoAceptar = generalService.getDataInput("AVISOS","BOTON NO ACEPTAR", $scope.origen);
			$scope.btnAceptar = generalService.getDataInput("AVISOS","BOTON ACEPTAR", $scope.origen);
						
//			if($scope.origen == "TIENDA" && configuracion.so.ios)				
//				$scope.verPdf($scope.urlDoc, $scope.tituloAviso.texto);				
//			else{				
				var imagenesArray = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";		
				
				modalService.pdfViewModal($scope.urlDoc, $scope.tituloAviso.texto, $scope.btnAceptar.texto, $scope.btnNoAceptar.texto, null, $scope.btnAceptar.estilo, $scope.btnNoAceptar.estilo,
										 null, $scope.esContratos, $scope.aceptados,$scope.firmaContratos, null,imagenesArray)
							.then(
									function(aceptar){
										$scope.responseViewPDF({codigo:RESPONSE_CODIGO_EXITO_IPAD});
									},function(noaceptar){
										$scope.responseViewPDF({codigo:1});						  													
									}
								);
//			}				
			
		};
				
		$scope.continuarAvisos = function (){									
			
			if($scope.firma1 == true){
				if($scope.avisosAceptados == 1 && $scope.aceptaPrivacidad){
					$scope.nombreAviso = $scope.tituloBuro;
					$scope.tituloAviso = $scope.tituloBuro;
					$scope.urlDoc = "BuroCredito.html";
					$rootScope.doc_details = {
					        file_url: $scope.urlDoc
					};
					$scope.aceptaPrivacidad = false;
					$scope.esBuro = true;
					if(!$scope.confTipoWindows){
						$scope.GetData1();
						$rootScope.imgPrivacidad = $scope.imageData1;
						$scope.ClearCanvas1();
					}
					
				}else if($scope.avisosAceptados == 2 && $scope.aceptaPrivacidad){
					$scope.nombreAviso = $scope.tituloBuro;
					$scope.tituloAviso = $scope.tituloBuro;
					$scope.urlDoc = "BuroCredito.html";
					$rootScope.doc_details = {
					        file_url: $scope.urlDoc
					};
					$scope.aceptaPrivacidad = false;
					$scope.esBuro = true;
					if(!$scope.confTipoWindows){
						$scope.GetData1();
						$rootScope.imgPrivacidad = $scope.imageData1;
						$scope.ClearCanvas1();
					}
					
				} else if($scope.avisosAceptados == 2 && !$scope.aceptaPrivacidad) {
					if($rootScope.paginaAnterior!="aval"){
						$rootScope.solicitudJson.aceptaTerminos = 1;
						$rootScope.solicitudJson.tratamientoDatos = 1;
						$rootScope.solicitudJson.transferenciaDatos = 1;
						$rootScope.solicitudJson.aceptaConsultaBuro = 1;
					}
					if(!$scope.confTipoWindows){
						$scope.GetData1();
						$rootScope.imgBuro = $scope.imageData1;
						$scope.ClearCanvas1();
					}					
					generalService.locationPath("/"+$rootScope.paginaAnterior);
				}
			}
		};
		
		$scope.funcionMover=function(){
			if($scope.click)
				$scope.firma1=true;
		};
		
		$scope.miFuncion=function(){
			console.log(document.getElementById("canvas1"));
			console.log(document.getElementById("canvas1").toDataURL("image/png"));
			$scope.fasd = 2;
		};
		
		$scope.increment = function(id) {
			if ($scope.id == "canvas1"){
				$scope.firma1 = true;
			}
			
			$scope.$digest();
		};
		
		$scope.regresa = function (){			
			
			$rootScope.avisosAceptados = false;
			$rootScope.regresaAvisos = true;
			if($scope.avisosAceptados == 0 && !$scope.aceptaPrivacidad){
				$rootScope.solicitudJson.aceptaTerminos = 0;
				generalService.locationPath("/"+$rootScope.paginaAnterior);
				
			} else if($scope.avisosAceptados == 1 && $scope.aceptaPrivacidad){
				$rootScope.solicitudJson.aceptaTerminos = 0;
				generalService.locationPath("/"+$rootScope.paginaAnterior);
				
			} else if($scope.avisosAceptados == 2 && $scope.aceptaPrivacidad) {
				$rootScope.solicitudJson.aceptaTerminos = 0;
				generalService.locationPath("/"+$rootScope.paginaAnterior);
				
			} else if($scope.avisosAceptados == 1 && !$scope.aceptaPrivacidad) {
				$scope.aceptaPrivacidad = true;
				$scope.esBuro = false;
				$scope.nombreAviso = generalService.getDataInput("AVISOS","TEXTO PRIVACIDAD", $scope.origen);
				$scope.tituloAviso = generalService.getDataInput("AVISOS","TITULO AVISOS", $scope.origen);
				$scope.urlDoc = "AvisoPrivacidad.html";
				$rootScope.doc_details = {
				        file_url: $scope.urlDoc
				};	
				
				if(!$scope.confTipoWindows){
					$scope.ClearCanvas1();
					$scope.cargaFirma ($rootScope.imgPrivacidad);
				}
				
			} else if($scope.avisosAceptados == 2 && !$scope.aceptaPrivacidad) {
				$scope.aceptaPrivacidad = true;
				$scope.esBuro = false;
				$scope.avisosAceptados--;
				$scope.nombreAviso = generalService.getDataInput("AVISOS","TEXTO PRIVACIDAD", $scope.origen);
				$scope.tituloAviso = generalService.getDataInput("AVISOS","TITULO AVISOS", $scope.origen);
				$scope.urlDoc = "AvisoPrivacidad.html";
				$rootScope.doc_details = {
				        file_url: $scope.urlDoc
				};
				
				if(!$scope.confTipoWindows){
					$scope.GetData1();
					$rootScope.imgBuro = $scope.imageData1;
					$scope.ClearCanvas1();
					$scope.cargaFirma ($rootScope.imgPrivacidad);
				}
				
			}
		};
		
		$scope.cargaFirma = function (imgB64){
			
			var canvas = document.getElementById("canvas1");
			var ctx = canvas.getContext("2d");

			var image = new Image();
			image.onload = function() {
			    ctx.drawImage(image, 0, 0);
			};
			image.src = imgB64;
			$scope.firma1 = true;
		};
		
		$scope.negacion = function (value){
			var foo = function (){
				$scope.acepta1 = false;
				$scope.acepta2 = false;
				$scope.buroCheck = false;
			};
			if($scope.aceptaPrivacidad == true && value == true){
				var aviso = ["Sin la aceptación del Aviso de Privacidad, no es posible continuar con la solicitud."];
				//$rootScope.message("Aviso", aviso, "Aceptar", null, "bgRosa", "btnRosaD", foo, "AVISO CONTRATO");
				$rootScope.message("Notificación", aviso, "Aceptar", null, "bgRosa", "btnRosaD", foo, null);
			
			}else if($scope.esBuro == true && value == true){
				var aviso = ["Sin la aceptación de la consulta de Buró de Crédito, no es posible continuar con la solicitud."];
				//$rootScope.message("Aviso", aviso, "Aceptar", null, "bgRosa", "btnRosaD", foo, "AVISO BURO");
				$rootScope.message("Notificación", aviso, "Aceptar", null, "bgRosa", "btnRosaD", foo, null);
			}
		}
		
		$scope.verPdf = function (urlDoc, nombreArchivo){
			$rootScope.visualizaPdf("viewDoc", 
									urlDoc,
									nombreArchivo,
									true,
									urlDoc=="AvisoPrivacidad.pdf"?true:false,
									"responseViewPDF");
		};
		
		$scope.responseViewPDF = function( responseIPAD )
		{
			$rootScope.loggerIpad("responseViewPDF", null, responseIPAD);
			try{
				
				if( responseIPAD.codigo == 0 ){
					//console.log(JSON.stringify(responseIPAD));
					//$rootScope.message("AVISO", [JSON.stringify(responseIPAD)], "Aceptar", null);
					if($scope.avisosAceptados == 0 && $scope.esBuro == false ){
						console.log("lanzar comop de firma para aviso de privacidad");
						$scope.aceptaPrivacidad = true;
 						$scope.esBuro = false;
 						 						 						
 						if($scope.confTipoWindows){
 							$rootScope.waitLoaderStatus = LOADER_SHOW;
 							$rootScope.capturarFirmaWV("avisosDivId","responseFirmaWV",{titulo:"Firma Aviso de Privacidad"});
 						}else
 							$scope.avisosAceptados++;
 						
					} else if($scope.avisosAceptados == 1 && $scope.esBuro == false){
						console.log("dos");
						$scope.aceptaPrivacidad = true;
 						$scope.esBuro = false;
 						
					} else if($scope.avisosAceptados == 1 && $scope.esBuro == true){
						console.log("lanzar comop de firma para buro");						
						$scope.aceptaPrivacidad = false;
 						$scope.esBuro = true;
 						
 						if($scope.confTipoWindows){
 							$rootScope.waitLoaderStatus = LOADER_SHOW;
 							$rootScope.capturarFirmaWV("avisosDivId","responseFirmaWV",{titulo:"Firma Buró de Crédito"});
 						}else
 							$scope.avisosAceptados++;
					}
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if($scope.avisosAceptados == 0){
						$scope.aceptaPrivacidad = false;
 						$scope.esBuro = false;
					} else if($scope.avisosAceptados == 1 && $scope.aceptaPrivacidad){
						$scope.aceptaPrivacidad = false;
 						$scope.esBuro = false;
 						$scope.avisosAceptados--;	
					} else if($scope.avisosAceptados == 1 && $scope.esBuro){
						$scope.aceptaPrivacidad = false;
 						$scope.esBuro = true;
					} else if($scope.avisosAceptados == 2 && $scope.esBuro){
						$scope.aceptaPrivacidad = false;
 						$scope.esBuro = true;
 						$scope.avisosAceptados--;	
					}
					
				}
				
			}catch(e){
				console.log(e.message);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("CONTRATOS",[ "Error al visualizar el documento."+e.message], "Aceptar", null);
				console.error( e.message );
				
			}
			
			
		};
		
		
		$scope.responseFirmaWV = function(responseWV){
			$rootScope.loggerIpad("responseFirmaWV", null, responseWV);
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
				if($scope.aceptaPrivacidad){
					$scope.avisosAceptados++;
					$rootScope.imgPrivacidad = responseWV.img64;
					$scope.firma1 = true;
				}else if($scope.esBuro){					
					$scope.avisosAceptados++;
					$rootScope.imgBuro = responseWV.img64;
					$scope.firma1 = true;
				}
			}/*else								
				$rootScope.message("", [responseWV], "Aceptar", null, "bgRosa", "btnRosaD");*/			
							
		};
		
		$scope.visorPdfWeb = function (nameDoc, titulo){
		
			modalService.pdfViewModal(nameDoc, titulo, $scope.btnAceptar.texto, $scope.btnNoAceptar.texto, null, $scope.btnAceptar.estilo, $scope.btnNoAceptar.estilo )
						.then(
								function(aceptar){
									$scope.responseViewPDF({codigo:RESPONSE_CODIGO_EXITO_IPAD});
								},function(noaceptar){
									$scope.responseViewPDF({codigo:1});						  													
								}
							);			
		}
		
		$scope.archivarFirma = function()
		{
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$scope.contadorArchivarFirmas++;
			//$scope.GetData1();
			$scope.imgFirma = $rootScope.imgPrivacidad;
	    	$scope.b64Firma = $scope.imgFirma.replace("data:image/png;base64,","").trim();
			
			$rootScope.enviarImagen(
					$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
					"",
					FIRMAR_CONTRATOS,
					FIRMAR_CTE_CONTRATOS,
					'canvas1',
					{	
						solicitudJson: $rootScope.solicitudJson.idSolicitud,
		    			firmaCliente: $scope.b64Firma,
		    			firmaAval: "",
		    			nombre: "Prueba Encolamiento Firmas",//$rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
						foto: $rootScope.fotoCteOriginal
					},	
					"responseEnvioFirmas"
			);
		};
		
		$scope.responseEnvioFirmas = function( responseIPAD )
		{
			$rootScope.loggerIpad("responseEnvioFirmas", null, responseIPAD);
			$scope.contadorRepsuestaFirmas++
			try{
				
				if( responseIPAD.codigo == 0 ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Correcto para guardar firmas TRY." + JSON.stringify(responseIPAD)], "Aceptar", null);
					//$scope.guardar();
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Error al encolar archivos." + JSON.stringify(responseIPAD)], "Aceptar", null);
					
				}
				
			}catch(e){
				console.log(e.message);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("CONTRATOS",[ "Error al encolar archivos."+e.message], "Aceptar", null);
				console.error( e.message );
				
			}
			
			
		};
	});
	
});