'use strict';
//var imagenes=new Array();
define(["app"], function (app) {
	
	app.controller("avisosWindowsController", function (	$timeout, $scope, $rootScope, ngDialog, generalService, $location, authService, loginService, modalService, solicitudService, tarjetaService, buroService, $anchorScroll) {
		
		$rootScope.firmaPrivacidad = undefined;
		$rootScope.firmaBuro = undefined;
		$rootScope.firmaCaratula = undefined;
		$rootScope.firmaSolicitud = undefined;
		$rootScope.isSolicitudDos = undefined;
		$rootScope.firmaSeguroCliente = undefined;
		$rootScope.firmaSeguroCarta = undefined;	
		$rootScope.firmaAcuseTaz = undefined;
		$scope.isSolicitudDos2 = true; 
		$scope.desactivarBoton=false;
		$scope.leyendaFirmar = "Firmar";
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		$scope.buroCheck = true;
		$scope.verRegresar = true;
		$scope.confTipoWindows = configuracion.so.windows;
		var titleWraper = "";
		$scope.firma1 = false;
		$scope.aceptaPrivacidad = true;
		$scope.verAvisoPrivacidad = true;
		$scope.verBuroCredito = false;
		$scope.esBuro = false;
		$scope.verBuroCredito = false;
		$scope.avisosAceptados = 0;
		$scope.urlDoc = "AvisoPrivacidad.html";		
		if($scope.aceptaPrivacidad){
			titleWraper = "Aviso de Privacidad";
			$scope.leyendaBoton = "Aviso de Privacidad";
		}
		else{
			titleWraper = "Autorización para Consulta de Historial Crediticio";
			$scope.leyendaBoton = "Buró de Crédito";
			$scope.verBuroCredito = true;
		}
																	
		$scope.imagenesArray = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";				 
		$scope.doc_details;
		$rootScope.imgPrivacidad = "";
		$rootScope.imgBuro = "";
		$scope.firmaContratos = 0;
		$scope.aceptados = 0;
		$scope.tratDatos = $rootScope.solicitudJson.tratamientoDatos==0?false:true;
		$scope.transfDatos = $rootScope.solicitudJson.transferenciaDatos==0?false:true;
		$scope.esContratos = false;		
		$scope.esIpad=configuracion.so.ios;
		$scope.mensajeRegresar = false;
		
		$scope.firmar = function(){
			
//			$scope.confirm();
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
				var title = "";
			if($scope.aceptaPrivacidad)
				title = "Firma Aviso de Privacidad";
			else
				title = "Firma Buró de Crédito";
			if ($scope.confTipoWindows){
				$rootScope.capturarFirmaWV("avisosDivId","responseFirmaWV",{titulo:title});
			}else{
				modalService.firmas(title)
				.then(
						function(exito){
							/*
							 * Para mostrar la modal del aviso de Privacidad
							 * tendra que tener el valor 1
							 */
							$scope.verRegresar = true;
							if($scope.verAvisoPrivacidad)
								$scope.verAvisoPrivacidad = false;
							else
								$scope.verBuroCredito = true;
							if($scope.verBuroCredito)
								$scope.verBuroCredito = false;
							$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
						},function(error){
							$scope.responseFirmaWV({codigo: 1});
							$scope.verRegresar = true;
						});
			}
		}
		
		$scope.mostrarModalTratamiento = function(tipoContrato){

			if(tipoContrato == 1){
				$scope.verRegresar = false;
				$scope.verAvisoPrivacidad = false;
				modalService.tratamientoDP("", "bgAzul",  1, null, "").then( 
						function(confirm) {
								$scope.firmar();
						},function(cancel){
							
							showMessageAviso();
							
							
//							$rootScope.message("Aviso", ["Sin la aceptación del Aviso de Privacidad, no es " +
//									"posible continuar con la solicitud."], "Aceptar", null, "bgGris", "btnGrisD");
//							$scope.verAvisoPrivacidad = true;
//							$scope.verRegresar = true;
						}
					);
			}else{
				$scope.firmar();
			}
			
		}
		
		function showMessageAviso (){
			modalService.showMessageContratos("", "bgAzul",  1, null, "").then(
					function(confirm){
						$scope.verAvisoPrivacidad = true;
						$scope.verRegresar = true;
					});
		}

			
		$rootScope.doc_details = {
	        file_url: $scope.urlDoc
	    };
		
		generalService.setArrayValue("solicitudRecuperada", true);
		
		
		
		$scope.setHeaderWrapper=function(visible,mensaje){
			var x={nombre:"tituloVisorPDF", mostrar:visible,titulo:mensaje};
			if(configuracion.so.ios){
				$rootScope.executeAction( "avisosDivId", "setHeaderWrapperResponse",x);
//				$rootScope.executeAction( "ochoPasosDivId", "recuperaSolicitud",  {nombre:"envioDocumentos", idCliente:$rootScope.solicitudJson.cotizacion.clientes[0].idPersona, mostrarSpinner:1} );
			}
		};
		
		$scope.setHeaderWrapperResponse=function(ipadResponse){
			$rootScope.loggerIpad("setHeaderWrapperResponse", null, ipadResponse);
			if( ipadResponse.codigo == RESPONSE_CODIGO_EXITO_IPAD )
				console.log("OK");
			else
				$rootScope.message("Visor Firmas",[ipadResponse.mensaje], "Aceptar");
		};

		$scope.setHeaderWrapper(1,titleWraper);	
		$scope.setContentPage = function()
	    {			
	    	if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";

	    	generalService.setMapping(  MODEL_VISTAS_JSON );
	    	$scope.txtRegresar = generalService.getDataInput("OCHO PASOS","TEXTO BOTON REGRESAR", $scope.origen);
	    	$scope.tituloAviso = generalService.getDataInput("AVISOS","TITULO AVISOS", $scope.origen);
	    	$scope.tituloBuro = generalService.getDataInput("AVISOS","TITULO BURO", $scope.origen);
	    	$scope.txtAvisos = generalService.getDataInput("AVISOS","TEXTO AVISOS", $scope.origen);
	    	$scope.nombreAviso = generalService.getDataInput("AVISOS","TEXTO PRIVACIDAD", $scope.origen);
	    	$scope.txtVerDoc = generalService.getDataInput("AVISOS","TEXTO VER DOCUMENTO", $scope.origen);
	    	$scope.imgDocs = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.AVISOS.IMG DOCUMENTOS.URL.valor"];
	    	$scope.txtCheck1 = generalService.getDataInput("AVISOS","TEXTO CHECK 1", $scope.origen);
	    	$scope.txtCheck2 = generalService.getDataInput("AVISOS","TEXTO CHECK 2", $scope.origen);
	    	$scope.txtCheck3 = generalService.getDataInput("AVISOS","TEXTO CHECK 3", $scope.origen);
	    	$scope.btnBorraFirma = generalService.getDataInput("AVISOS","BOTON BORRAR FIRMA", $scope.origen);
	    	$scope.btnContinuar = generalService.getDataInput("AVISOS","BOTON CONTINUAR", $scope.origen);
			
	    };/* END SET_CONTENT_PAGE FUNCTION */	    
		
		
		
		$scope.visualizaDoc =  function (){
			
			$scope.btnNoAceptar = generalService.getDataInput("AVISOS","BOTON NO ACEPTAR", $scope.origen);
			$scope.btnAceptar = generalService.getDataInput("AVISOS","BOTON ACEPTAR", $scope.origen);
						
												
				var imagenesArray = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";
												
				modalService.pdfViewModal($scope.urlDoc, $scope.tituloAviso.texto, $scope.btnAceptar.texto, $scope.btnNoAceptar.texto, null, $scope.btnAceptar.estilo, $scope.btnNoAceptar.estilo,
										 null, $scope.esContratos, $scope.aceptados,$scope.firmaContratos, null,imagenesArray)
							.then(
									function(aceptar){
										$scope.responseViewPDF({codigo:RESPONSE_CODIGO_EXITO_IPAD});
									},function(noaceptar){
										$scope.responseViewPDF({codigo:1});						  													
									}
								);
//			}				
			
		};
				
		$scope.continuarAvisos = function (){									
//			$rootScope.firmaPrivacidad = undefined;
//			$rootScope.firmaBuro = undefined;
			
			if($scope.firma1 == true){
				if($scope.avisosAceptados == 1 && $scope.aceptaPrivacidad){
					$scope.nombreAviso = $scope.tituloBuro;
					$scope.tituloAviso = $scope.tituloBuro;
					$scope.urlDoc = "BuroCredito.html";
					$rootScope.doc_details = {
					        file_url: $scope.urlDoc
					};
					$scope.aceptaPrivacidad = false;
					$scope.esBuro = true;
					
					

					
				}else if($scope.avisosAceptados == 2 && $scope.aceptaPrivacidad){
					$scope.nombreAviso = $scope.tituloBuro;
					$scope.tituloAviso = $scope.tituloBuro;
					$scope.urlDoc = "BuroCredito.html";
					$rootScope.doc_details = {
					        file_url: $scope.urlDoc
					};
					$scope.aceptaPrivacidad = false;
					$scope.esBuro = true;

					
				} else if($scope.avisosAceptados == 2 && !$scope.aceptaPrivacidad) {
					if($rootScope.paginaAnterior!="aval"){
						$rootScope.solicitudJson.aceptaTerminos = 1;
						//$rootScope.solicitudJson.tratamientoDatos = 1;
						//$rootScope.solicitudJson.transferenciaDatos = 1;
						$rootScope.solicitudJson.aceptaConsultaBuro = 1;
						
					}
					$scope.setHeaderWrapper(0,"");
					$scope.confirm();
				}
			}
		};
		
		$scope.funcionMover=function(){
			if($scope.click)
				$scope.firma1=true;
		};
		
		$scope.miFuncion=function(){
			console.log(document.getElementById("canvas1"));
			console.log(document.getElementById("canvas1").toDataURL("image/png"));
			$scope.fasd = 2;
		};
		
		$scope.increment = function(id) {
			if ($scope.id == "canvas1"){
				$scope.firma1 = true;
			}
			
			$scope.$digest();
		};
		
		$scope.regresa = function (){	
			$rootScope.firmaBuro = undefined;
			$rootScope.firmaPrivacidad = undefined;
			$rootScope.solicitudJson.aceptaTerminos = 0;
			$rootScope.avisosAceptados = false;
			$rootScope.regresaAvisos = true;
			$scope.setHeaderWrapper(0,"");
			$scope.closeThisDialog();

		};
		
		$scope.cargaFirma = function (imgB64){
			
			var canvas = document.getElementById("canvas1");
			var ctx = canvas.getContext("2d");

			var image = new Image();
			image.onload = function() {
			    ctx.drawImage(image, 0, 0);
			};
			image.src = imgB64;
			$scope.firma1 = true;
		};
		
		
		$scope.negacion = function (value, check){
			var foo = function (){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.acepta2 = false;
				$scope.acepta3 = false;
				$scope.buroCheck = true;
			};
			if(value == true && $scope.buroCheck ){
				switch (check) {
				case 1 :
					$rootScope.solicitudJson.transferenciaDatos = 1;
					$scope.esatusCheck=true;
					break;
				case 2 :
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					var aviso = ["Sin la aceptación del Aviso de Privacidad, no es posible continuar con la solicitud."];
					$scope.buroCheck = false;
					$rootScope.message("Notificación", aviso, "Aceptar", null, "bgGris", "btnGrisD", foo, null, null, "frenteShow");
					break;
				case 3 :
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					var aviso = ["Sin la aceptación de la consulta de Buró de Crédito, no es posible continuar con la solicitud."];
					$scope.buroCheck = false;
					$rootScope.message("Notificación", aviso, "Aceptar",  null, "bgGris", "btnGrisD", foo, null,null, "frenteShow");
					break;	
				}
			}else{
				if(!value && check == 1){
					$rootScope.solicitudJson.transferenciaDatos = 0;
					$scope.esatusCheck=false;
				}
			}
		
                     
			
//			if($scope.aceptaPrivacidad == true && value == true && $scope.buroCheck ){
//				var aviso = ["Sin la aceptación del Aviso de Privacidad, no es posible continuar con la solicitud."];
//				//$rootScope.message("Aviso", aviso, "Aceptar", null, "bgGris", "btnGrisD", foo, "AVISO CONTRATO");
//				$scope.buroCheck = false;
//				$rootScope.message("Notificación", aviso, "Aceptar", null, "bgGris", "btnGrisD", foo, null);
//			
//			}else if($scope.esBuro == true && value == true && $scope.buroCheck){
//				var aviso = ["Sin la aceptación de la consulta de Buró de Crédito, no es posible continuar con la solicitud."];
//				//$rootScope.message("Aviso", aviso, "Aceptar", null, "bgGris", "btnRosaD", foo, "AVISO BURO");
//				$scope.buroCheck = false;
//				$rootScope.message("Notificación", aviso, "Aceptar", null, "bgGris", "btnGrisD", foo, null);
//			}
		}
		
		$scope.verPdf = function (urlDoc, nombreArchivo){
			$rootScope.visualizaPdf("viewDoc", 
									urlDoc,
									nombreArchivo,
									true,
									urlDoc=="AvisoPrivacidad.pdf"?true:false,
									"responseViewPDF");
		};
		
		$scope.responseViewPDF = function( responseIPAD )
		{
			$rootScope.loggerIpad("responseViewPDF", null, responseIPAD);
			try{
				
				if( responseIPAD.codigo == 0 ){
					//console.log(JSON.stringify(responseIPAD));
					//$rootScope.message("AVISO", [JSON.stringify(responseIPAD)], "Aceptar", null);
					if($scope.avisosAceptados == 0 && $scope.esBuro == false ){
						console.log("lanzar comop de firma para aviso de privacidad");
						$scope.aceptaPrivacidad = true;
 						$scope.esBuro = false;
 						 						 						
 						if($scope.confTipoWindows){
 							$rootScope.waitLoaderStatus = LOADER_SHOW;
 							$rootScope.capturarFirmaWV("avisosDivId","responseFirmaWV",{titulo:"Firma Aviso de Privacidad"});
 						}else
 							$scope.avisosAceptados++;
 						
					} else if($scope.avisosAceptados == 1 && $scope.esBuro == false){
						console.log("dos");
						$scope.aceptaPrivacidad = true;
 						$scope.esBuro = false;
 						
					} else if($scope.avisosAceptados == 1 && $scope.esBuro == true){
						console.log("lanzar comop de firma para buro");						
						$scope.aceptaPrivacidad = false;
 						$scope.esBuro = true;
 						
 						if($scope.confTipoWindows){
 							$rootScope.waitLoaderStatus = LOADER_SHOW;
 							$rootScope.capturarFirmaWV("avisosDivId","responseFirmaWV",{titulo:"Firma Buró de Crédito"});
 						}else
 							$scope.avisosAceptados++;
					}
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if($scope.avisosAceptados == 0){
						$scope.aceptaPrivacidad = false;
 						$scope.esBuro = false;
					} else if($scope.avisosAceptados == 1 && $scope.aceptaPrivacidad){
						$scope.aceptaPrivacidad = false;
 						$scope.esBuro = false;
 						$scope.avisosAceptados--;	
					} else if($scope.avisosAceptados == 1 && $scope.esBuro){
						$scope.aceptaPrivacidad = false;
 						$scope.esBuro = true;
					} else if($scope.avisosAceptados == 2 && $scope.esBuro){
						$scope.aceptaPrivacidad = false;
 						$scope.esBuro = true;
 						$scope.avisosAceptados--;	
					}
					
				}
				
			}catch(e){
				console.log(e.message);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("CONTRATOS",[ "Error al visualizar el documento."+e.message], "Aceptar", null);
				console.error( e.message );
				
			}
			
			
		};
		
		
		$rootScope.responseFirmaWV = function(responseWV){
			$scope.verAvisoPrivacidad = false;
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
				if($scope.aceptaPrivacidad){
					$scope.avisosAceptados++;
					$rootScope.imgPrivacidad = responseWV.img64;
					$rootScope.firmaPrivacidad = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
					$scope.firma1 = true;
					$scope.verRegresar = true;

				}else if($scope.esBuro){					
					$scope.avisosAceptados++;
					$rootScope.imgBuro = responseWV.img64;
					$rootScope.firmaBuro = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");;
					$scope.firma1 = true;
					$scope.verBuroCredito = false;
					$scope.verRegresar = true;
				}
				
				$scope.leyendaFirmar = "Continuar";
			}else if($scope.verBuroCredito){
				$scope.verBuroCredito = true;
				$scope.verAvisoPrivacidad = false;
			}else{
				$scope.verAvisoPrivacidad = true;
				$scope.verBuroCredito = false;
			}	
		};
		
		$scope.continuarFlujo = function(){
			/*\Se agrega un evento para la bitacora\*/
//			(Contratos)
			$rootScope.addEvent( BITACORA.SECCION.originacion.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.continuar.id, $rootScope.solicitudJson.contratos.porcentaje, BITACORA.SECCION.originacion.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
			
			
			var elmnt = document.getElementById("visorScroll");
		    elmnt.scrollLeft=0;
		    elmnt.scrollTop=0;
			if($scope.aceptaPrivacidad){
				$scope.urlDoc = "BuroCredito.html";
				$scope.esBuro = true;
				$scope.aceptaPrivacidad= false;
				$scope.leyendaFirmar = "Firmar";
				
				var pdfImagenes=true;				

				if($scope.aceptaPrivacidad){
					titleWraper = "Aviso de Privacidad";
					$scope.leyendaBoton = "Aviso de Privacidad";
				}else{
					titleWraper = "Autorización para Consulta de Historial Crediticio";
					$scope.leyendaBoton = "Buró de Crédito";
					$scope.verBuroCredito = true;
					$scope.verAvisoPrivacidad = false;
				}

				$scope.setHeaderWrapper(1,titleWraper)				
				$scope.imagenesArray = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";							 
				
			}else if($scope.esBuro){
				$scope.leyendaFirmar = "Firmar";
				$scope.continuarAvisos();
				$scope.desactivarBoton=true;
			}
		}
		
		$scope.ajustaScroll = function(){
//			var elmnt = document.getElementById("visorScroll");
//		    elmnt.scrollLeft=0;
//		    elmnt.scrollTop=0;
		    $anchorScroll();
		};
		
		$scope.visorPdfWeb = function (nameDoc, titulo){
		
			modalService.pdfViewModal(nameDoc, titulo, $scope.btnAceptar.texto, $scope.btnNoAceptar.texto, null, $scope.btnAceptar.estilo, $scope.btnNoAceptar.estilo )
						.then(
								function(aceptar){
									$scope.responseViewPDF({codigo:RESPONSE_CODIGO_EXITO_IPAD});
								},function(noaceptar){
									$scope.responseViewPDF({codigo:1});						  													
								}
							);			
		}
		
		$scope.archivarFirma = function()
		{
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$scope.contadorArchivarFirmas++;
			//$scope.GetData1();
			$scope.imgFirma = $rootScope.imgPrivacidad;
	    	$scope.b64Firma = $scope.imgFirma.replace("data:image/png;base64,","").trim();
			
			$rootScope.enviarImagen(
					$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
					"",
					FIRMAR_CONTRATOS,
					FIRMAR_CTE_CONTRATOS,
					'canvas1',
					{	
						solicitudJson: $rootScope.solicitudJson.idSolicitud,
		    			firmaCliente: $scope.b64Firma,
		    			firmaAval: "",
		    			nombre: "Prueba Encolamiento Firmas",//$rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
						foto: $rootScope.fotoCteOriginal
					},	
					"responseEnvioFirmas"
			);
		};
		
		$scope.responseEnvioFirmas = function( responseIPAD )
		{
			$rootScope.loggerIpad("responseEnvioFirmas", null, responseIPAD);
			$scope.contadorRepsuestaFirmas++
			try{
				
				if( responseIPAD.codigo == 0 ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Correcto para guardar firmas TRY." + JSON.stringify(responseIPAD)], "Aceptar", null);
					//$scope.guardar();
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Error al encolar archivos." + JSON.stringify(responseIPAD)], "Aceptar", null);
					
				}
				
			}catch(e){
				console.log(e.message);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("CONTRATOS",[ "Error al encolar archivos."+e.message], "Aceptar", null);
				console.error( e.message );
				
			}
			
			
		};
	});
	
});