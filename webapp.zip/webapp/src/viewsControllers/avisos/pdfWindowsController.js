'use strict';

define(["app"], function (app) {
	
	app.controller("pdfWindowsController", function (	$timeout, $scope, $rootScope, ngDialog, generalService, $location, authService, loginService, modalService, solicitudService, tarjetaService, buroService) {
		
		$scope.leyendaFirmar = "Firmar";
// I-MODIFICACION TDC (NUEVOS DOCUMENTOS)
		$scope.ID_PRODUCTO = ID_PRODUCTO;
		$scope.producto = "ORO";
		$scope.montototal = "";
		$scope.montoMinimo="";
		$scope.firmaSolUno = false;
		$scope.firmaSolDos = false;
		$scope.numeroFolio = $rootScope.solicitudJson.folioFlujoUnico;
		if($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
			$scope.cuentaTarjeta = $rootScope.solicitudJson.tarjetasCredito.tarjetaOro.numeroCuenta;
		}
		
		try{
			for (var i = 0; i <  $rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo.length; i++){
				if ($rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo[i].conceptoDes == "COMPROBABLES"){
					$scope.ingresosCom = $rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo[i].monto;
				}else{
					$scope.ingresosNoCom = $rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo[i].monto;
				}
			}
		}catch(e){}
		
		$scope.egresos= function(concepto){
			var monto = 0;
			for (var i = 0; i <  $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo.length; i++){
				if ($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo[i].conceptoDes == concepto){
					monto = $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo[i].monto;
				}
			}
			return monto;
		}
			//solo para pruebas
//			$rootScope.validarTienda = true;
			//solo para pruebas
		
		var fechaDia = new Date();
		$scope.hh = fechaDia.getHours();
		$scope.min = fechaDia.getMinutes();
		$scope.ss = fechaDia.getSeconds();
		$scope.aaaa = fechaDia.getFullYear();
		$scope.dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
		$scope.mm = ((fechaDia.getMonth() + 1) < 10 ? '0' : '') + (fechaDia.getMonth() + 1); 
		
		meses.indexOf()
		
		var index3 =  meses.map(function(d){
				return d["id"];
		    			
			}).indexOf ($scope.mm);
		if (index3 > -1)
			$scope.mes = meses[index3].descripcion;
		
		$scope.fin = false;
// F-MODIFICACION TDC (NUEVOS DOCUMENTOS)

// I-MODIFICACION TDC (BENEFICIOS PARA EL CONTRATO DE ACUSE DE TARJETA)		
	    		$scope.beneficios = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.LIBERACION.LISTA BENEFICIOS TARJETA"];
	    		if ($rootScope.solicitudJson.idProducto == ID_PRODUCTO.tarjetaCreditoEKT){
	    			$scope.beneficios=[{VALOR:{valor:"Programa de Lealtad Elektrapuntos acumulables: 30% sobre el total de tus compras del mes en Elektra y 10% en otros comercios"}, VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}},
	    			                   {VALOR:{valor:"20% de reembolso sobre el monto de tu primera compra (Topado a $500 pesos)."}},
	    			                   {VALOR:{valor:"Sin anualidad (Usa tu tarjeta al menos una vez al mes en compras y/o disposiciones y evita el cobro de $70 mensuales/comisión por no uso)."},VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}},
	    			                   {VALOR:{valor:"Seguros gratis (protección de precios y compras)."},VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}},
	    			                   {VALOR:{valor:"Pagos mensuales, puedes pagar el mínimo o el total de tu saldo para no generar intereses."},VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}},
	    			                   {VALOR:{valor:"Consulta Términos y Condiciones en www.bancoazteca.com.mx"},VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}}]
	    		}
// F-MODIFICACION TDC (BENEFICIOS PARA EL CONTRATO DE ACUSE DE TARJETA)	

		$scope.buroCheck = true;
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		$scope.confTipoWindows = configuracion.so.windows;
		var titleWraper = "";
		$rootScope.firma1 = false;
//		$scope.aceptaPrivacidad = true;
//		$scope.esBuro = false;
		$scope.status = 1;
		$scope.avisosAceptados = 0;
		$scope.urlDoc = "AvisoPrivacidad.pdf";
		var pdfImagenes=true;
		var imagenesArray=null;
		if($scope.aceptaPrivacidad)
			titleWraper = "Aviso de Privacidad";
		else
			titleWraper = "Autorización para Consulta de Historial Crediticio";
		
		$scope.esIpad=configuracion.so.ios;
		$scope.confTipoWindows = configuracion.so.windows;
		$scope.firmasIndependientes = false;
		$scope.showAlternatives = true;
		$scope.mostrarAP = false;
		$scope.verRegresar = true;
		if($rootScope.isAviso){
			$scope.showAlternatives = false;
			$scope.mostrarAP = true;
			$scope.leyendaBoton = "Aviso de Privacidad";
			$scope.aceptaPrivacidad = true;
			$scope.esBuro = false;
		}else if($rootScope.isBuro){					
			$scope.leyendaBoton = "Buró de Crédito";
			$scope.aceptaPrivacidad = false;
			$scope.esBuro = true;
		}else if($rootScope.isContratoCaratula){
			$scope.leyendaBoton = "Contrato, Carátula y Anexo de Comisiones";
		}else if($rootScope.isSolicitud){
			$scope.firmasIndependientes = true;
			$scope.leyendaBoton = "Mercadotecnia";
			//$scope.leyendaBotonDos = "Solicitud de Crédito";
		}else if($rootScope.isAcuseTaz){
			$scope.leyendaBoton = "Acuse Taz";
		}
		else if($rootScope.isBienes){
			$scope.leyendaBoton = "Bienes";
		}
		else if($rootScope.isSeguroCliente){
			$scope.leyendaBoton = "Seguro Vidamax";
		}else if($rootScope.isSeguroCarta){
			$scope.leyendaBoton = "Seguro Vidamax";
		}
		
		$scope.init = function()
	    {		
			if( messageData ){
	    		$scope.setContentPage();
	    		$rootScope.waitLoaderStatus = LOADER_HIDE;
	    		$scope.setHeaderWrapper(1,$scope.ngDialogData.title);		
	    	}
			if($rootScope.isAcuseTaz)
				$scope.firmasIndependientes = false;
				
	    };/* END INIT FUNCITON */
		
		$scope.setHeaderWrapper=function(visible,mensaje){
			var x={nombre:"tituloVisorPDF", mostrar:visible,titulo:mensaje};
			if(configuracion.so.ios){
				$rootScope.executeAction( "avisosDivId", "setHeaderWrapperResponse",x);
//				$rootScope.executeAction( "ochoPasosDivId", "recuperaSolicitud",  {nombre:"envioDocumentos", idCliente:$rootScope.solicitudJson.cotizacion.clientes[0].idPersona, mostrarSpinner:1} );
			}
		};
		
		$scope.setHeaderWrapperResponse=function(ipadResponse){
			$rootScope.loggerIpad("setHeaderWrapperResponse", null, ipadResponse);
			if( ipadResponse.codigo == RESPONSE_CODIGO_EXITO_IPAD )
				console.log("OK");
			else
				$rootScope.message("Visor Firmas",[ipadResponse.mensaje], "Aceptar");
		};

		$scope.setHeaderWrapper(1,$scope.ngDialogData.title);	

		
		$scope.regresa = function (){	
			$scope.setHeaderWrapper(0,"");	
			$scope.closeThisDialog();

		};
		

		
		$scope.negacion = function (value, element, atributo){
			var foo = function (){
				$scope.acepta1 = false;
				$scope.acepta2 = false;
				$scope.acepta3 = false;
				$scope.buroCheck = true;
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			};
			
			if(value == true && $scope.buroCheck){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$scope.buroCheck = false;
				var aviso =  ["Por políticas internas y para continuar con la solicitud del crédito se requiere la aceptación de" + $scope.ngDialogData.negacionCheck.textoMensaje];
				//$rootScope.message("Aviso", aviso, "Aceptar", null, "bgGris", "btnGrisD", foo, "AVISO CONTRATO");
				$rootScope.message("Notificación", aviso, "Aceptar", null, "bgGris", "btnGrisD", foo, null, null, "frenteShow");
			}
		}

		
		$scope.negacion2 = function (value, check){
			var foo = function (){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.acepta4 = false;
				$scope.acepta5 = false;
				$scope.buroCheck = true;
			};
			if ($rootScope.isfirmaDomiciliar){
			
			}else{
				if(value == true && $scope.buroCheck ){
					switch (check) {
					case 1 :
						$rootScope.solicitudJson.transferenciaDatos = 1;
						break;
					case 2 :
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						var aviso = ["Sin la aceptación del Aviso de Privacidad, no es posible continuar con la solicitud."];
						$scope.buroCheck = false;
						$rootScope.message("Notificación", aviso, "Aceptar", null, "bgGris", "btnGrisD", foo, null, null, "frenteShow");
						break;
					case 3 :
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						var aviso = ["Sin la aceptación de la consulta de Buró de Crédito, no es posible continuar con la solicitud."];
						$scope.buroCheck = false;
						$rootScope.message("Notificación", aviso, "Aceptar",  null, "bgGris", "btnGrisD", foo, null,null, "frenteShow");
						break;	
					}
				}else{
					if(value == false && check == 1){
						$rootScope.solicitudJson.transferenciaDatos = 0;
					}
				}
			}
		}
		
		
		$scope.aceptar = function(){
//			$rootScope.solicitudJson.transferenciaDatos = ($scope.acepta1 && $scope.acepta2)? 1:0;
			$scope.setHeaderWrapper(0,"");	
			$scope.confirm();
		}
		
		$scope.firmar = function(tipoFirma){
			$scope.tipoFirma = tipoFirma;
			if($rootScope.title != ""){
				if ($scope.confTipoWindows){
					$rootScope.capturarFirmaWV("avisosDivId","responseFirmaWV",{titulo:$rootScope.title});
				}else{
					modalService.firmas($rootScope.title)
					.then(
							function(exito){
								$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
							},function(error){
								$scope.responseFirmaWV({codigo: 1});
								$scope.verRegresar = true;
								$scope.mostrarAP = true;
							});
				}
			}
		}

		$scope.responseFirmaWV = function(responseWV){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			var tipoDeFima = (typeof $scope.tipoFirma == 'undefined') ? true: false;
			if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
				if($rootScope.isAviso){
					$scope.avisosAceptados++;
					$rootScope.isAvisoWSD = true;
					$rootScope.imgPrivacidad = responseWV.img64;
					$rootScope.firmaPrivacidad = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
				}else if($rootScope.isBuro){					
					$scope.avisosAceptados++;
					$rootScope.isBuroWSD = true;
					$rootScope.imgBuro = responseWV.img64;
					$rootScope.firmaBuro = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
				}else if($rootScope.isContratoCaratula){
					$scope.avisosAceptados++;
					$rootScope.isContratoCaratulaWSD = true;
					$rootScope.imgCaratula = responseWV.img64;
					$rootScope.firmaCaratula = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
				}else if($rootScope.isSolicitud){
					$scope.avisosAceptados++;
					if(tipoDeFima){
						$scope.firmaSolUno = true;
						$rootScope.firmaSolUnoWSD = true;
						$rootScope.imgSolicitud = responseWV.img64;
						$rootScope.firmaSolicitud = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
					}
					else{
						$scope.firmaSolDos = true;
						$rootScope.firmaSolDosWSD = true;
						$rootScope.imgSolicitudDos = responseWV.img64;
						$rootScope.firmaSolicitudDos = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
					}
				}
				else if($rootScope.isSeguroCliente){
					$scope.avisosAceptados++;
					$rootScope.isSeguroClienteWSD = true;
					$rootScope.imgSeguroCliente = responseWV.img64;
					$rootScope.firmaSeguroCliente = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
				}else if($rootScope.isSeguroCarta){
					$scope.avisosAceptados++;
					$rootScope.isSeguroCartaWSD = true;
					$rootScope.imgSeguroCarta = responseWV.img64;
					$rootScope.firmaSeguroCarta = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
// I-MODIFICACION TDC (NUEVOS DOCUMENTOS)				
				}else if($rootScope.isfirmaDomiciliar){
					$scope.avisosAceptados++;
					$rootScope.imgfirmaDomiciliar = responseWV.img64;
					$rootScope.firmaDomiciliar = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
				}else if($rootScope.isAcuseTarjeta){
					$scope.avisosAceptados++;
					$rootScope.imgfirmaEntrega = responseWV.img64;
					$rootScope.firmaEntrega = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
// F-MODIFICACION TDC (NUEVOS DOCUMENTOS)
				}else if($rootScope.isAcuseTaz){
					$scope.avisosAceptados++;
					$rootScope.imgAcuseTaz = responseWV.img64;
					$rootScope.isAcuseTAZWSD = true;
					$rootScope.firmaAcuseTaz = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
				}else if($rootScope.isBienes){
					$scope.avisosAceptados++;
					$rootScope.isBienesWSD = true;
					$rootScope.bienesFirmado = true;
					$rootScope.imgFirmaBienes = responseWV.img64;
					$rootScope.firmaBienes = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
				}
				
				if($rootScope.isSolicitud){
					if($scope.firmaSolUno && $scope.firmaSolDos){
						$scope.firmasIndependientes = false;
						$scope.leyendaFirmar = "Continuar";
					}else{
						$scope.leyendaFirmar = "Firmar";
					}	
				}else{
					$scope.leyendaFirmar = "Continuar";
				}
					
			}	
		};
		
		$scope.mostrarModalTratamiento = function(tipoContrato){

			if(tipoContrato == 1){
				$scope.verRegresar = false;
				$scope.mostrarAP = false;
				modalService.tratamientoDP("", "bgAzul",  1, null, "").then( 
						function(confirm) {
								$scope.firmar();
						},function(cancel){
							
							showMessageAviso();

						}
					);
			}else{
				$scope.firmar();
			}
			
		}
		
		function showMessageAviso (){
			modalService.showMessageContratos("", "bgAzul",  1, null, "").then(
					function(confirm){
						$scope.mostrarAP = true;
						$scope.verRegresar = true;
					});
		}
		
// I-MODIFICACION TDC (FUNCION PARA VER LOS DOCUMENTOS INFORMATIVOS)
		$scope.siguiente = function(){
			switch ($scope.status){
			case 1:
				$scope.status = 2;
				$scope.urlDoc = ($rootScope.solicitudJson.idProducto != 28)?"AnexoComisiones.html":"AnexoComisionesTEC.html";
				$scope.setHeaderWrapper(1, FIRMA_ANEXO_TARJETA.etiqueta);	
				$scope.elemento.animate({scrollTop : 0});
				$timeout(function(){
					$scope.fin = false;
					if (document.getElementById('idScroll').scrollHeight < $(document.getElementById('idScroll')).height())
						$scope.fin = true;
				},100)
				$scope.ngDialogData.title =  FIRMA_ANEXO_TARJETA.etiqueta;
				break;
			case 2:
				$scope.status = 3;
				$scope.urlDoc = ($rootScope.solicitudJson.idProducto != 28)?"5puntosTDC.html":"5puntosTEC.html";
				$scope.elemento.animate({scrollTop : 0});
				$timeout(function(){
					$scope.fin = false;
					if (document.getElementById('idScroll').scrollHeight < $(document.getElementById('idScroll')).height())
						$scope.fin = true;
				},100)
				$scope.ngDialogData.title=  FIRMA_PUNTOS_TARJETA.etiqueta;
				$scope.setHeaderWrapper(1,FIRMA_PUNTOS_TARJETA.etiqueta);	
				break;
			case 3:
				$scope.setHeaderWrapper(0,"");	
				$scope.closeThisDialog(true);
				break;
			}
			$scope.ngDialogData.imagenesArray = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";	
		}
		
		 $scope.abrirModalCuentas = function(cuentas){
		    	modalService.cuentasModal("Cotizador", "verdeCred",$scope, cuentas).then( 
						function(cuentaSel){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$scope.cuenta = cuentaSel;
							if (cuentaSel.maximo){
								$rootScope.solicitudJson.tarjetasCredito.tarjetaOro.estatusDomicializacion = DOMICILIACION_COMPLETO;
								$scope.montototal = "X";
							}else{
								$rootScope.solicitudJson.tarjetasCredito.tarjetaOro.estatusDomicializacion = DOMICILIACION_MINIMO;
								$scope.montoMinimo="X";
							}
							$rootScope.solicitudJson.tarjetasCredito.tarjetaOro.numeroCuenta = cuentaSel.numeroCuenta;
						}, function(exito){
							$scope.closeThisDialog(true);
							generalService.locationPath("/liberacion");	
							$rootScope.waitLoaderStatus = LOADER_HIDE;
						}
				);
		 }
		 if ($rootScope.isfirmaDomiciliar){
				$scope.abrirModalCuentas($scope.ngDialogData.negacionCheck.cuentas);
				$rootScope.waitLoaderStatus = LOADER_SHOW;
 		}
// F-MODIFICACION TDC (FUNCION PARA VER LOS DOCUMENTOS INFORMATIVOS)		
	});
	
});