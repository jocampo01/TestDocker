'use strict';

define(["app"], function (app) {
	
	app.controller('codigoSolicitudController', function(  $rootScope, $scope, messageData, generalService, modalService, solicitudService, tarjetaService, callCenterService){
		
		var CTE_BAZ_DIGITAL = "No es posible continuar con la solicitud debdio a que no es un cliente de BAZDidital";
		var DESC_ENCOLAMIENTO_HUELLAS = "Huella cliente BazDigital"
		$scope.codigo = null;
		
		$scope.init = function(){						
			
			
			if( messageData  ){					
					
				loadView();
					
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.showPage = messageData;
				
				if(configuracion.so.ios)					
					$scope.ocrCodigo();
				
			}
									
				
		};
		
		
		$scope.ocrCodigo = function(){
			$rootScope.ocrCodigoQR("codigoSolicitudId", "respuestaOCR", {} );
		};
		
		$scope.respuestaOCR = function( data ){
			$rootScope.loggerIpad("respuestaOCR", null, data);
			try{
				switch(data.codigo){
					case RESPONSE_CODIGO_QR.EXITO:
						$scope.codigo = data.respuesta;																															
						$scope.getSolicitud();
						break;
					case RESPONSE_CODIGO_QR.CANCELADO:
						$scope.codigo="";
						break;
					default:
						$rootScope.message("Código", ["Falló la lectura del código, favor de intentar nuevamente", "["+data.mensaje+"]"], "Aceptar", null, "bgCafeZ", "cafeZ");
						break;
				}
			}catch(e){
				$rootScope.message("Código", ["Falló la lectura del código, favor de intentar nuevamente", "["+e+"]"], "Aceptar", null, "bgCafeZ", "cafeZ");
			}
				
				
		};
		
		$scope.validaCreditoInmediato=function(){
			
			var banderaDeIngresos= $rootScope.solicitudJson.banderaIngresos;
			var creditoInmediato = $rootScope.solicitudJson.creditoInmediato;
			var color=0;
			
			switch (banderaDeIngresos) {
			case 0:
				color = $rootScope.solicitudJson.idColorNC;
				break;
			case 1:
				color = $rootScope.solicitudJson.idColor;
				break;
			default:
				$rootScope.message("AVISO", [ "El estatus de la bandera de ingresos es incorrecto" ], "Aceptar", $scope.pathInicial);
				break;

			}
			
			if(($rootScope.solicitudJson.marca!=STATUS_SOLICITUD.autorizada.marca.liberadaConTaz) && ($rootScope.solicitudJson.marca!=STATUS_SOLICITUD.autorizada.marca.sinTaz)){
				
				if((color == COLORES_EVALUACION_CTE.VERDE_OBSCURO   || color == COLORES_EVALUACION_CTE.VERDE || color == COLORES_EVALUACION_CTE.VERDE_CLARO || color == COLORES_EVALUACION_CTE.AZUL) && (creditoInmediato == 1)){
					return 'creditoInmediato'; 
				}else if((color == COLORES_EVALUACION_CTE.VERDE_OBSCURO   || color == COLORES_EVALUACION_CTE.VERDE || color == COLORES_EVALUACION_CTE.VERDE_CLARO || color == COLORES_EVALUACION_CTE.AZUL) && (creditoInmediato == 0)){
					return 'noCreditoInmediato'; 
				}else if((color == COLORES_EVALUACION_CTE.AMARILLO || color == COLORES_EVALUACION_CTE.NARANJA) && (creditoInmediato == 0)){
					return 'noCreditoInmediato'; 
				}else
					return 'rechazado';
					
				
			}else
				return 'estatusIncorrecto';
			
		}
		
		
		$scope.getSolicitud = function(){									
			$rootScope.waitLoaderStatus = LOADER_SHOW;			
			solicitudService.getSolicitudByCode( {codigoSolicitud: $scope.codigo} )
						  .then(
								function(data){
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									
									if(data.data.codigo == RESPONSE_CODIGO_EXITO){											
										var jResponse = JSON.parse(data.data.respuesta);
										
										switch(jResponse.codigo){
											case RESPONSE_ORIGINACION_CODIGO_CON_HUELLAS:	
												$rootScope.solicitudJson = jResponse.data;
												$rootScope.nombreCamel=generalService.camelize($rootScope.solicitudJson.cotizacion.clientes[0].nombre);
					                			$rootScope.apellidoPaternoCamel=generalService.camelize($rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno);
					                			$rootScope.apellidoMaternoCamel=generalService.camelize($rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno);
					                			var estatus = $rootScope.solicitudJson.idSeguimiento;
					                			var existeCita=$rootScope.solicitudJson.existeCita;
					                			
					                			if(generalService.isBazDigital()){
					                				
					                				switch($scope.validaCreditoInmediato()){
					                				case 'creditoInmediato':
					                					if(((estatus == STATUS_SOLICITUD.preautorizada.id || estatus == STATUS_SOLICITUD.autorizada.id) && (existeCita==0)))
															validaHuella();
														else
															$rootScope.message("AVISO", ["Estatus incorrecto"], "Aceptar", null, "bgCafeZ", "cafeZ");				          
					                					break;
					                					
					                				case 'noCreditoInmediato':
					                					if((estatus == STATUS_SOLICITUD.autorizada.id)&& (existeCita==1))
					                						validaHuella();
															else
																$rootScope.message("AVISO", ["Estatus incorrecto"], "Aceptar", null, "bgCafeZ", "cafeZ");	
					                					break;
					                					
					                				case 'rechazado':
					                					$rootScope.message("AVISO", ["La solicitud esta rechazada"], "Aceptar", null, "bgCafeZ", "cafeZ");	
					                					break;
					                					
					                				default:
					                					generalService.setDataBridge({origen : FICHA.origen.recuperar});
					                					generalService.locationPath("/ficha");
					                					break;
					                				}
												}else
													$rootScope.message("AVISO ", [CTE_BAZ_DIGITAL], "Aceptar", null, "bgCafeZ", "cafeZ");												
														
												break;
																							
											case RESPONSE_ORIGINACION_CODIGO_SIN_HUELLAS:
												$rootScope.solicitudJson = jResponse.data;	
												var estatus = $rootScope.solicitudJson.idSeguimiento;
					                			var existeCita=$rootScope.solicitudJson.existeCita;
												
												if(generalService.isBazDigital()){
													
													switch($scope.validaCreditoInmediato()){
					                				case 'creditoInmediato':
					                					if(((estatus == STATUS_SOLICITUD.preautorizada.id || estatus == STATUS_SOLICITUD.autorizada.id) && (existeCita==0))){
					                						$rootScope.waitLoaderStatus = LOADER_SHOW;
															$rootScope.capturarHuella('codigoSolicitudId','4,5,6,7', 'respuestaHuellaIpad');
					                					}
														else
															$rootScope.message("AVISO", ["Estatus incorrecto"], "Aceptar", null, "bgCafeZ", "cafeZ");				          
					                					break;
					                					
					                				case 'noCreditoInmediato':
					                					if((estatus == STATUS_SOLICITUD.autorizada.id)&& (existeCita==1)){
					                						$rootScope.waitLoaderStatus = LOADER_SHOW;
															$rootScope.capturarHuella('codigoSolicitudId','4,5,6,7', 'respuestaHuellaIpad');
					                					}
					                					else
																$rootScope.message("AVISO", ["Estatus incorrecto"], "Aceptar", null, "bgCafeZ", "cafeZ");	
					                					break;
					                					
					                				case 'rechazado':
					                					$rootScope.message("AVISO", ["La solicitud esta rechazada"], "Aceptar", null, "bgCafeZ", "cafeZ");	
					                					break;
					                					
					                				default:
					                					generalService.setDataBridge({origen : FICHA.origen.recuperar});
					                					generalService.locationPath("/ficha");
					                					break;
					                				}
													}
												break;
												
											case RESPONSE_ORIGINACION_CODIGO_SIN_CU:												
																									
												$rootScope.message("AVISO", ["No es posible continuar debido a que la solicitud no tiene registrado cliente unico." ], 
																   "Aceptar", null, "bgCafeZ", "cafeZ");
																								
												break;											
												
											default:
												$rootScope.message("CODIGO "+jResponse.codigo, [jResponse.descripcion], "Aceptar", null, "bgCafeZ", "cafeZ");						
												break;
												
										}			
																																	
										
									}else
										$rootScope.message("CODIGO "+data.data.codigo, ["Error en la respuesta del servicio para obtener la solicitud. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafeZ", "cafeZ");											
									
										
									
								}, function(error){
					                $rootScope.waitLoaderStatus = LOADER_HIDE; 
								}
							);									
				
		};
		
		
		$scope.respuestaHuellaIpad = function( response ){						
						
			if( response.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
				
				if(response.nombreHuellas.length == 0 && response.identificador.length > 0) {
					response.nombreHuellas = ["", "", response.identificador];
				}
				
				$rootScope.enviarImagen(
							$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
							response.nombreHuellas[2],
							"clienteUnico",
							DESC_ENCOLAMIENTO_HUELLAS,
							'codigoSolicitudId',
							{								
								idSolicitud: $rootScope.solicitudJson.idSolicitud,
								cadena: response.nombreHuellas[2],							
								nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
								foto: $rootScope.fotoCteOriginal
							},
							"responseEnvioImgIpad"
				);				
												
				
								
			}else{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("Error al capturar las huellas", [response.mensaje], "Aceptar", null, "bgCafeZ", "cafeZ");
			} 
				
				
		};
			
		
		$scope.responseEnvioImgIpad = function(responseIPAD){
			$rootScope.waitLoaderStatus = LOADER_HIDE;			
			$rootScope.loggerIpad("responseEnvioImgIpad", null, responseIPAD);
			if( responseIPAD.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
				$rootScope.executeAction( "codigoSolicitudId", "execActionResponse",  
						  { nombre:"envioDocumentos", idCliente:$rootScope.solicitudJson.cotizacion.clientes[0].idPersona, mostrarSpinner:1, 
	                        filtroDocumentos: DESC_ENCOLAMIENTO_HUELLAS   } );
			}
						
		};
		
		
		$scope.execActionResponse = function(responseIPAD){
			$rootScope.loggerIpad("execActionResponse", null, responseIPAD);
			if( responseIPAD.codigo == RESPONSE_CODIGO_EXITO_IPAD )
				getPath();
			else
				$rootScope.message("Error al enviar las huellas", ["Error al enviar las huellas, favor de intentar nuevamente", "["+responseIPAD.mensaje+"]"], "Aceptar", null, "bgCafeZ", "cafeZ");
						
		};
		
		var validaHuella = function(){
			
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) > -1 )
				$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
			
			else{
				if ( configuracion.origen.tienda ){
					$rootScope.waitLoaderStatus = LOADER_SHOW;					
					$rootScope.verificarHuella( 'codigoSolicitudId', 'responseVerificarHuellaIpad', [$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico]);
						
				}else{
					if( generalService.isProduccion() ){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						modalService.huellaModal("bgAzul");
					}else
						$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.COMPONENTE_CANCELADO_PORUSR, matches:["OK"]} );
				}			
					
			}
			
			
				
		};
		
		
		$scope.responseVerificarHuellaIpad = function( response ){												
			$rootScope.loggerIpad("responseVerificarHuellaIpad", null, response);
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			
				switch(response.codigo){
					case VALIDA_HUELLA_RESPONSE.EXITO:												
						getPath();								
						break;
						
					case VALIDA_HUELLA_RESPONSE.ERROR:						
					case VALIDA_HUELLA_RESPONSE.ERROR_COMPONENTE:
					case VALIDA_HUELLA_RESPONSE.NO_SE_ENCONTARON_HUELLAS:
					case VALIDA_HUELLA_RESPONSE.NO_HAY_COINCIDENCIAS:
						$rootScope.message("Componente de huella", [response.mensaje], "Aceptar", null, "bgCafeZ", "cafeZ");						
						break;
						
					case VALIDA_HUELLA_RESPONSE.COMPONENTE_CANCELADO_PORUSR:	
						break;											
						
					default:
						$rootScope.message( "Componete de huella", ["Código "+response.codigo+" no definido. "], "Aceptar");						
						break;
						
				}				
											
		};
				
		$scope.menu = function(){
			$rootScope.waitLoaderStatus = LOADER_HIDE;	
			generalService.cleanRootScope($rootScope);
			generalService.buildSolicitudJson($rootScope, null );			
			
			if(configuracion.so.ios){
				$rootScope.executeAction("regresaMenu", "responseWrapper",{nombre:"mostrarMenu"});
			}else{
				generalService.locationPath("/menuWrapper");
			}
		};
		
		var getPath = function(){
			
			//if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id  &&  $rootScope.solicitudJson.existeCita == 0  ){
				
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				
				tarjetaService.consultaInventario({sucursal: generalService.addZerosLeft($rootScope.sucursalSession.idSucursal, 4), opcion: "01"})
							  .then(
									function(data){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										
										if(data.data.codigo == RESPONSE_CODIGO_EXITO){											
											var inventarioResponse = JSON.parse(data.data.respuesta);
											
											if(inventarioResponse.codigo == RESPONSE_TARJETA_CODIGO_EXITO){
												var hayTarjetas = false;
												var tazArray = inventarioResponse.data;
												
												for(var i=0; i<tazArray.length; i++) {
													var tazDisponibles = tazArray[i].tarjetaDisponibles
													if( parseInt(tazDisponibles) > 0){
														hayTarjetas = true;
														break;
													}
														
												}
												
												if($rootScope.solicitudJson.creditoInmediato==1){
													if(hayTarjetas)
														generalService.locationPath("/liberacion");
													else
														generalService.locationPath("/datosHogar");
												}else{
													
													if(hayTarjetas)
														generalService.locationPath("/liberacion");
													else
														$scope.dispersarCallCenter();
												}
												
												
												
											}else
												$rootScope.message("CODIGO "+inventarioResponse.codigo, ["No es posible continuar con el proceso debido a que hubo un error al verificar el inventario."], "Aceptar", null, "bgCafeZ", "cafeZ");							
											
										}else
											$rootScope.message("CODIGO "+data.data.codigo, ["No es posible continuar con el proceso debido a que hubo un error al verificar el inventario."], "Aceptar", null, "bgCafeZ", "cafeZ");											
										
											
										
									}, function(error){
						                $rootScope.waitLoaderStatus = LOADER_HIDE; 
									}
								);
				
			
			/*}else if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazEntregada &&  
					$rootScope.solicitudJson.existeCita == 0  )
				generalService.locationPath("/datosHogar");
			
			else if( ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.callCenter) || 
					 ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazEntregada && $rootScope.solicitudJson.existeCita == 1) ||
					 ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id && $rootScope.solicitudJson.existeCita == 1)  )
			
				generalService.locationPath("/estatus");
			
			else
				$rootScope.message("AVISO", ["Estatus incorrecto"], "Aceptar", null, "bgCafeZ", "cafeZ");
				*/
				
			
		};
		
		$scope.dispersarCallCenter = function() {
			$rootScope.waitLoaderStatus = LOADER_SHOW;

			if (generalService.isBazDigital()) {
				var request = {
					idSolicitud : $rootScope.solicitudJson.idSolicitud,
					tipoPeticion : 1,
					idPlataforma : PLATAFORMA.BAZDIGITAL
				};

				callCenterService.dispersarTarjetas(request).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
							var jResponse = JSON.parse(data.data.respuesta);

							if (jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO) {
								generalService.setDataBridge({origen : FICHA.origen.recuperar});
								generalService.locationPath("/ficha");
							} else
								$rootScope.message("Dispersar CallCenter ", [ jResponse.descripcion, "Codigo de error " + jResponse.codigo ], "Aceptar");

						} else
							$rootScope.message("Dispersar CallCenter", ["Error en la respuesta del servicio para dipersar CallCenter. Por favor, reintente nuevamente."], "Aceptar");


					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;

					}
				);

			}
			else
				$rootScope.message("AVISO ", [CTE_BAZ_DIGITAL], "Aceptar", null, "bgCafeZ", "cafeZ");

		};
		
		
		var loadView = function(){
			$scope.isIOS = configuracion.so.ios;
			$scope.isTienda = configuracion.origen.tienda; 
			$scope.origen = ($scope.isTienda == true)? "TIENDA":"WEB";						
		};
			
		
		

		
	});
		
});



