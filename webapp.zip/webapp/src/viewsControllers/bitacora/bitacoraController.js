'use strict';

define(["app"], function (app) {

	app.controller('bitacoraController', function( $timeout,$scope,$rootScope,modalService,generalService,solicitudService, messageData, bazDigitalService, callCenterService, 
			   documentosService, $sce ) {
		var pais=$rootScope.sucursalSession.idPais;
		var canal=$rootScope.sucursalSession.idCanal;
		var sucursal=$rootScope.sucursalSession.idSucursal;
		var firma=$rootScope.userSession.noEmpleado;
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		if (isProduccion){
//			$scope.URL = $sce.trustAsResourceUrl("http://10.57.161.223/regional/regional/consultas/BasicoJSP/BitSolicitudes.jsp?hidCanal="+canal+"&hidSucursal="+sucursal+"&hidNumFirma="+firma)
			$scope.URL = $sce.trustAsResourceUrl("http://10.53.28.177/SIEBAZ/Presentacion/Views/Solicitudes/wfSolicitudesOperativo.aspx?hidPais="+pais+"&hidCanal="+canal+"&hidSucursal="+sucursal)
		}else{
//			$scope.URL = $sce.trustAsResourceUrl("http://10.48.1.180/regional/regional/consultas/BasicoJSP/BitSolicitudes.jsp?hidCanal="+canal+"&hidSucursal="+sucursal+"&hidNumFirma="+firma)
			$scope.URL = $sce.trustAsResourceUrl("http://10.53.28.177/SIEBAZ/Presentacion/Views/Solicitudes/wfSolicitudesOperativo.aspx?hidPais="+pais+"&hidCanal="+canal+"&hidSucursal="+sucursal)
		}

		$scope.regresa = function(){
			if(configuracion.so.ios){
				$rootScope.executeAction("regresaMenu", "responseWrapper",{nombre:"mostrarMenu"});
			}else{
				generalService.locationPath("/menuWrapper");
			}
		}
	});
});