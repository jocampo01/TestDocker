'use strict';

define(["app"], function (app) {
	app.controller('cambaceoController',function($q, $compile, $scope,$timeout, $rootScope, $interval, ngDialog, modalService, generalService,authService, callCenterService,
											      clienteUnicoService, solicitudService, buroService, messageData, sessionService, securityService, validateService, documentosService,
											      tarjetaService, loginService, recuperaSolicitudService) {		
		
		recuperaSolicitudService.reiniciaBanderas();
		// GENERA_CODIGO_CELULAR = 1;
		$scope.pageClass = generalService.calculaVistas($rootScope.paginaActual,$rootScope.paginaAnterior,$rootScope.recuperaSolicitud);
		generalService.setDataBridge(null);
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		$scope.nacionalidades = null;
		$scope.validaCURP = validaCURP;
		$scope.notRequiredCURP = notRequiredCURP;
		
// I-MODIFICACION TDC 		
		$scope.limiteCredito = 0.0;
		$scope.campanaTDC = "";
		$scope.statusCampanaTDC="";
// F-MODIFICACION TDC 
		$scope.nAnno=null;
		$scope.nMes=null;
		$scope.nDia=null;
		$scope.showInvertir=true;
		$scope.showLimite=false;
		$scope.cambios=0;
		var montoAntInvertir=0;
		var montoAntLimite=0;
		$scope.montoLimite=0;
// I-MODIFICACION TDC (VARIABLE EMPLEAO Y FOLIO PREAPROBADO)
		$scope.foliioPre = {folio: "", check: false, empleadoEkt: ""};
		$scope.folioCUPre = "";
		$scope.bloqueaDatosreac = false; 
// F-MODIFICACION TDC (VARIABLE EMPLEAO Y FOLIO PREAPROBADO)
		$scope.montoInvertir=$rootScope.montoInvertirInicial;
		$scope.tabs=[{activa:false,opc:0,titulo:"Inversión"},
		             {activa:false,opc:1,titulo:"Límite de Crédito"}];
		$scope.correoInvalido=true;
	
		$scope.productosTarjetas={};
		$scope.ocultarElementos = false;
		var montoMaximo = 99999;
		var ifefrente = "";
		var ifereverso = "";
		var tipoTasa = tipoTasas.prestamoPersonal.id;
		var tipoFormato = "";
		var contadorCel = 0;
		
		ifefrente = IDENTIFICACION_OFICIAL.descripcion + " " + CLIENTE.descripcion +" " + generalService.getDatafromCategory("SIMULADOR", "ETIQUETA FRENTE", "VALOR.valor" );
		ifereverso = IDENTIFICACION_OFICIAL.descripcion + " " + CLIENTE.descripcion +" " + generalService.getDatafromCategory("SIMULADOR", "ETIQUETA REVERSO", "VALOR.valor" );
		
		var contador_renapo = 3;

//I - VALIDACION CLAVE ELECTOR
		$scope.bandCE=false;
		$scope.respCE="";
		$scope.menCE="";
//F - VALIDACION CLAVE ELECTOR
		
		var productosTar= [
		           {id:0,desc:"TDC Oro"        ,estilo:false,deshabilitado:false,visible: $rootScope.consultaFuncionalidad.solicitudesOro ,prioridad:1, producto: ID_PRODUCTO.tarjetaCredito},
		           {id:1,desc:"TDC Elektra"    ,estilo:true ,deshabilitado:true,visible: $rootScope.consultaFuncionalidad.solicitudesEkt ,prioridad:2, producto: ID_PRODUCTO.tarjetaCreditoEKT},
		           {id:2,desc:"TDC Oro Garantizada"    ,estilo:true ,deshabilitado:true,visible:false ,prioridad:3, producto:  ID_PRODUCTO.tarjetaCreditoTOG}
		           ]
		           
		
		$scope.productosTarjetas={
// I-MODIFICACION TDC (SE AGREGAN NUEVOS PRODUCTOS DE TARJETAS)
				productos:[],
				estilo:"verdeCred"
// F-MODIFICACION TDC (SE AGREGAN NUEVOS PRODUCTOS DE TARJETAS)
		};
// I-MODIFICACION TDC 	
		
		for (var i=0; i<productosTar.length; i++){
			if (productosTar[i].visible){
				$scope.productosTarjetas.productos.push(productosTar[i]);
			} 
		}
		if($scope.productosTarjetas.productos.length > 0)
			$scope.productoSeleccionado = $scope.productosTarjetas.productos[0].producto;
// F-MODIFICACION TDC
		$scope.validaCorreo=function(email){
			if(email){
				var re = /(^[-\w.]+@{1}[-a-z0-9]+[.]{1}[a-z-z0-9-]{2,5})+(?:\.[a-zA-Z0-9-]+)*$/;
				if(re.test(email))
					$scope.correoInvalido=false;
				else
					$scope.correoInvalido=true;
			}
		}
		
		$rootScope.contratosResponseCita=true;
		$rootScope.documetosResponseCita=true;
		
		if($rootScope.sucursalSession){
			if($rootScope.sucursalSession.estado){
				$rootScope.solicitudJson.lugarOriginacion = ($rootScope.sucursalSession.estado == "Distrito Federal")?"Ciudad de México":$rootScope.sucursalSession.estado;
			}else{
				$rootScope.solicitudJson.lugarOriginacion = "";
			}
		}else{
			$rootScope.solicitudJson.lugarOriginacion = "";
		}
		
		var intento = 0;
		var location_path = "/"
		var cusArray = null;
		var nombreArchivoFoto = null;
		var numImagesIpad = 0;
		var fechaDia = "";
		var edadMinima = "";
		var edadMaxima = "";
		var etiquetaFrente = "";
		var etiquetaReverso = "";
		var etiquetaPrivacidad = "";
		var etiquetaBuro = "";
		var yyyy = "";
		var yy75 = "";
		var fechaDia1 = "";
		var aaaa = "";
		var dd = "";
		var mm = "" ;
		var encolarImagenes = true;
		var modalEspera = null;
		var timer = null;
		var codigoRespuestaHomonimos = null;
		var catCssProductos = []		
		var arrayPlazoMonto;
		var showProductosCanal = true;
		var validaMontoInicio = true;

		$scope.checkAvisos;
		$scope.canales = CANALES;
		$scope.isCanalInterno = true;
		$scope.validaSucursalesCot = true;
		$scope.muestraInfoTasas = true;
		
		var nombreMes = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio","Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
		$rootScope.anioActual = new Date().getFullYear();
		$rootScope.mesActual = nombreMes[new Date().getMonth()];
		$rootScope.diaActual = new Date().getDate();
		
		$scope.init = function(tarjeta){
			// Se inicializa el placeholder del campo CURP
			$scope.placeholderCURP = "CURP (opcional)";
			
			if (generalService.isEmpty($rootScope.solicitudJson.idSolicitud))
				resetDatosEvento();
			//evento CAMBACEO 
			$rootScope.addEvent( BITACORA.SECCION.cambaceo.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, 0, BITACORA.SECCION.cambaceo.guardarEnBD );
			
			if($rootScope.categoriaLinea == undefined || $rootScope.categoriaLinea.linea == undefined || $rootScope.categoriaLinea.linea == "" || $rootScope.categoriaLinea.linea < 0){
				$rootScope.categoriaLinea = {
					      "linea": 0,
					      "lineaDes": "",
					      "subLinea": 0,
					      "subLineaDes": "",
					      "montoDeseado": ""
				};
			}
			
			$scope.obtenerImagenDestinoPrestamo();
			
			contadorCel = 0;
			$scope.showPage = false;
			$rootScope.cp = "";
//I - VALIDACION CLAVE ELECTOR			
			$scope.bandCE=false;
			$scope.respCE="";
			$scope.menCE="Captura la clave de elector";
//F - VALIDACION CLAVE ELECTOR
			
			// Se configura esta bandera, para validaciones.
			try {
				$scope.ocrRequired = $rootScope.consultaFuncionalidad.ocrobligatorio;
			} catch(x) {
				$scope.ocrRequired = false;
			}

			// La sucursal tiene el OCR obligatorio.
			if($scope.ocrRequired) {
				$scope.bloqueaINEPass = true;				
			} else {
				$scope.bloqueaINEPass = false;
			}

			// Esta bandera siempre nace en true, para el bloqueo;
			$scope.bloqueaInput = true;
			
			if( messageData ){														
				var continuar = false;								
				
				if($rootScope.sucursalSession){
					$scope.isCanalInterno = generalService.isCanalInterno($rootScope.sucursalSession.idCanal);
					showProductosCanal = generalService.showProductosCanal($rootScope.sucursalSession.idCanal)
					
					var productos = CANAL_PRODUCTOS[$rootScope.sucursalSession.idCanal];//MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.CATALOGO PRODUCTOS"];
					if(!generalService.isDefined(productos))
						productos = CANAL_PRODUCTOS[0];
					
					if($rootScope.userSession.idPuesto == PUESTO_VENTAS || $rootScope.userSession.idPuesto == PUESTO_GERENTE_COMERCIO || $rootScope.userSession.idPuesto == PUESTO_SUBGERENTE_COMERCIO){
						var proTemp = [];
						for(var i=0;i<productos.length;i++){
							if(productos[i].ETIQUETA.valor != "PRESTAMOS PERSONALES" && productos[i].ID.valor != ID_PRODUCTO.tarjetaCredito){
								proTemp.push(productos[i]);
							}
						}
						productos = proTemp;
					}else if(
							( ( $rootScope.userSession.idPuesto == PUESTO_EJECUTIVO || $rootScope.userSession.idPuesto == ASESOR_DE_NEGOCIOS || $rootScope.userSession.idPuesto == PUESTO_ASESOR_CREDITO || $rootScope.userSession.idPuesto == PUESTO_GERENTE_VENTAS_CREDITO) 
							|| ( $rootScope.userSession.idPuesto == PUESTO_GERENTE )
							&& CANALES_INTERNOS.indexOf($rootScope.sucursalSession.idCanal) != -1) && $rootScope.consultaFuncionalidad.activaProductosPorPerfil
							){
						var proTemp = [];
						for(var i=0;i<productos.length;i++){
							if(productos[i].ETIQUETA.valor == "PRESTAMOS PERSONALES" || productos[i].ETIQUETA.valor == "TARJETA DE CREDITO"){
								proTemp.push(productos[i]);
							}
						}
						productos = proTemp;
					}
				}else
					productos = [];
				
				$scope.obligarAvisos();
				$scope.isTienda = configuracion.origen.tienda;
				$rootScope.cp = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp;
				$scope.checkAvisos = $rootScope.solicitudJson.aceptaTerminos;				
				$scope.seCotizoItalika = generalService.getArrayValue("seCotizoItalika");
				$scope.vistaSimulador=configuracion.simulador.opcion;
				$scope.vistaDatosUsuario = configuracion.datosUsuario.opcion;		
				generalService.setMapping( MODEL_VISTAS_JSON );

				if($scope.seCotizoItalika){		
					
					$scope.existePlazo = true;							
					$scope.cargapagina(productos);
					
					$scope.nombreProducto = generalService.getArrayValue("nombreProducto");
					
					var textoPagoOpertuno = $scope.pagoOportuno.texto.replace(/fOrange/g,'fItalika');					
					$compile($("#pago").html(textoPagoOpertuno.replace(/nota/g,'notaItalika')).contents())($scope);
						    
				}else if( !showProductosCanal ){
					$scope.cargapagina(productos);
				    $scope.endCotizador = false;
				    $scope.existePlazo = true;
				    $rootScope.waitLoaderStatus = LOADER_HIDE;							
							
				}else{																						

						$scope.cargapagina(productos);
						$scope.setEstiloModelo();
//						if($rootScope.rechazoBuro)
//							$rootScope.solicitudJson.idProducto=$rootScope.idProductoAvisoModal;
														
						if($rootScope.rechazoBuro)
							$rootScope.solicitudJson.idProducto="";
							
							
//						if($rootScope.solicitudJson.idProducto != ID_PRODUCTO.modatelas+""){
//								if($rootScope.solicitudJson.idProducto != ID_PRODUCTO.tarjetaCredito && $rootScope.solicitudJson.idProducto != ""){
								if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal){
									$scope.calculaPlazos($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto);
									$scope.calculaMonto();
									$scope.sliderListener();
								}
								
								$timeout( function(){																		
																					
									if($rootScope.rechazoBuro){
										$rootScope.solicitudJson.idProducto=$rootScope.idProductoAvisoModal;
										$scope.setEstilo();
									}
									
									if($rootScope.sucursalSession!=null && $rootScope.sucursalSession.idCanal == CANALES.soriana){
										$rootScope.solicitudJson.idProducto = productos[0].ID.valor;
										$scope.setEstilo();
									}
									
									if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.tarjetaCredito && !tarjeta)
										$scope.setEstilo();
//I-MODIFICACION (mensaje para pre aprobados TDC)
									else if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.tarjetaCredito && tarjeta)
										$rootScope.canalActual = $rootScope.solicitudJson.idProducto;
//I-MODIFICACION (mensaje para pre aprobados TDC)
																													
									if(generalService.isDefined( generalService.getArrayValue("presupuestoC3"))){
										$rootScope.solicitudJson.idProducto = ID_PRODUCTO.consumo;
										$scope.setEstilo();
										$scope.cargarPresupuestoC3();
									}
									
									$rootScope.waitLoaderStatus = LOADER_HIDE;
					 			}, 100);
//						}else{
//								$rootScope.modoPrueba=true;
//								//$rootScope.canalTerceros=true;							
//						}
						
						$scope.endCotizador = false;
						$scope.existePlazo = true;
				}
				
				
				$scope.celular1.valor = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
				$timeout(function(){
							if ($rootScope.solicitudJson.cotizacion.clientes[0].idGenero == "F" || 
								$rootScope.solicitudJson.cotizacion.clientes[0].idGenero == "M"){
								// no hace nada
							}else
								$rootScope.solicitudJson.cotizacion.clientes[0].idGenero="";
							if(!parseInt($scope.nDia))
								$scope.nDia="";
							if(!parseInt($scope.nMes))
								$scope.nMes="";
							if(!parseInt($scope.nAnno))
								$scope.nAnno="";
							
							$scope.showPage = messageData;
				}, 0);
				
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp = $rootScope.cp;
				
				$rootScope.canalActual = (productos != undefined && productos.length>0)?productos[0].ID.valor:"";
			}
				if($scope.productosTarjetas.productos.length>0)
					$scope.cambiaTarjeta($scope.productosTarjetas.productos[0].id);
				
				$rootScope.solicitudJson.idProducto = $scope.radioProducto[0].radioValue;
				$scope.setEstilo();
		};
		
		$scope.check1SolicitarModel = false;
		$scope.check2SolicitarModel = false;
		$scope.esObligatorio = true;
		$scope.validarApellidos = function(parametro){
			if($rootScope.faseGeneraRechazo == 1 || $rootScope.faseGeneraReactivado == 1 || $rootScope.faseGeneraMigracionSuc == 1){
				$scope.check1SolicitarModel = false;
				$scope.check2SolicitarModel = false;
				$scope.esObligatorio = false;
			}else{
				if(parametro == 1){
					$scope.check1SolicitarModel = ($scope.check1SolicitarModel == false);
					
					if($scope.check1SolicitarModel){
						$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno = "";
						$scope.deshabilitarMaterno = true;
						$scope.manejoErroresMaterno = false;
						
						if($rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno.length > 0){
							$scope.esObligatorio = false;
							$scope.forSimulador.$invalid = false;
						}else{
							$scope.esObligatorio = true;
							$scope.forSimulador.$invalid = true;
						}
					}else{
						$scope.deshabilitarMaterno = false;
						$scope.manejoErroresMaterno = true;
						
						if($rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno.length > 0 && $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno.length > 0){
							$scope.esObligatorio = false;
							$scope.forSimulador.$invalid = false;
						}else{
							$scope.esObligatorio = true;
							$scope.forSimulador.$invalid = true;
						}
					}
					
				}else if(parametro == 2){
					$scope.check2SolicitarModel = ($scope.check2SolicitarModel == false);
					
					if($scope.check2SolicitarModel){
						$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno = "";
						$scope.deshabilitarPaterno = true;
						$scope.manejoErroresPaterno = false;
						
						if($rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno.length > 0){
							$scope.esObligatorio = false;
							$scope.forSimulador.$invalid = false;
						}else{
							$scope.esObligatorio = true;
							$scope.forSimulador.$invalid = true;
						}
					}else{
						$scope.deshabilitarPaterno = false;
						$scope.manejoErroresPaterno = true;
						
						if($rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno.length > 0 && $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno.length > 0){
							$scope.esObligatorio = false;
							$scope.forSimulador.$invalid = false;
						}else{
							$scope.esObligatorio = true;
							$scope.forSimulador.$invalid = true;
						}
					}
				}
			}
			
			$scope.validaApellidos($rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno, $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno, 0, 3);
		}
		
		$scope.obligarAvisos = function() {
			if($rootScope.solicitudJson.aceptaTerminos == 0) {
				// La sucursal demanda el OCR como obligatorio.
				if($scope.ocrRequired) {
					$scope.bloqueaINEPass = true;
				} else {
					$scope.bloqueaInput = true;
				}				
			} else {
				// La sucursal tiene el OCR obligatorio.
				if($scope.ocrRequired) {
					$scope.bloqueaINEPass = false;
					
					// Es web. No hay botón de OCR.
					if(!$scope.isTienda) {						
						$scope.bloqueaInput = false;
					}else{
						$scope.bloqueaInput = true;
					}
				} else {
					$scope.bloqueaInput = false;
				}
			}			
		};
		
		function inicializaProductos(productos){
			if(productos.ID.valor == 21){
				$scope.lineaDeProducto = LINEA_DE_PRODUCTO_CONSUMO;
			}else if(productos.ID.valor == 22){
				$scope.lineaDeProducto = LINEA_DE_PRODUCTO_ITALIKA;
			}else if(productos.ID.valor == 23){
				$scope.lineaDeProducto = LINEA_DE_PRODUCTO_TELEFONIA;
			}
		}
		
	 	$scope.getLinea=function(){
	 		
	 		switch($rootScope.categoriaLinea.linea){
				case 1 :							
					$scope.subLinea= SUBLINEA_ACCESORIOS;
					break;
				case 2:	
					$scope.subLinea= SUBLINEA_COLCHONES;
					break;
				case 3:
					$scope.subLinea= SUBLINEA_COMPUTO;
					break;
				case 4:
					$scope.subLinea= SUBLINEA_ELECTRONICA;
					break;
				case 5:
					$scope.subLinea= SUBLINEA_ENTRETENIMIENTO;
					break;
				case 6:
					$scope.subLinea= SUBLINEA_BLANCA;
					break;
				case 7:
					$scope.subLinea= SUBLINEA_MUEBLES;
					break;
				case 8:
					$scope.subLinea= SUBLINEA_JUGUETES;
					break;
				case 9:
					$scope.subLinea= SUBLINEA_TELEFONIA;
					break;
				case 10:
					$scope.subLinea= SUBLINEA_ITALIKA;
					break;
			};
			
			$rootScope.categoriaLinea.montoDeseado = ""
			$rootScope.categoriaLinea.subLinea = "";
			$rootScope.categoriaLinea.subLineaDes = "";
	 	}; 
	 	
	 	$scope.getSubLinea=function(desc){
	 		if($scope.subLinea){
	 			var index = $scope.subLinea.map(function(d){return d["id"];}).indexOf($rootScope.categoriaLinea.subLinea);
	 			
	 			if(index >= 0){
	 				$rootScope.categoriaLinea.subLineaDes = $scope.subLinea[index].descripcion;
	 				
	 				if(CANALES_INERNOS_NEG.indexOf($rootScope.sucursalSession.idCanal) != -1){
	 					montoMaximo = $scope.subLinea[index].montoMaximo;
	 				}else{
	 					montoMaximo = 99999;
	 				}
	 			}
	 		}
	 	}
		
		$scope.ppDestino = {
 			catalogoDestino: LINEA_DE_PRODUCTO_PRESTAMO,
 			catalogoCatDestino: [],
 			catDestino: "",
 			catDestinoDesc: "",
 			catSubDestino: "",
 			catSubDestinoDesc: ""
	 	}
	 	
	 	var estiloSeleccion = {
	 		"border": "3px solid #161cd0",
	 		"border-radius": "100%",
	 		"background-color": "white"
	 	}
	 	$scope.getDestino=function(categoriaDestino){
	 		switch(categoriaDestino){
				case 1 :							
					$scope.ppDestino.catalogoCatDestino = SUBLINEA_EMERGENCIA;
					$scope.ppDestino.catDestino = categoriaDestino;
					$scope.ppDestino.catSubDestino = "";
					
					$scope.estiloCatEmergencia = estiloSeleccion;
					$scope.estiloCatLiquidacion = "";
					$scope.estiloCatRemodelacion = "";
					$scope.estiloCatGastos = "";
					$scope.estiloCatEvento = "";
					break;
				case 2:	
					$scope.ppDestino.catalogoCatDestino = SUBLINEA_LIQUIDACION;
					$scope.ppDestino.catDestino = categoriaDestino;
					$scope.ppDestino.catSubDestino = "";
					
					$scope.estiloCatEmergencia = "";
					$scope.estiloCatLiquidacion = estiloSeleccion;
					$scope.estiloCatRemodelacion = "";
					$scope.estiloCatGastos = "";
					$scope.estiloCatEvento = "";
					break;
				case 3:
					$scope.ppDestino.catalogoCatDestino = SUBLINEA_REMODELACIÓN;
					$scope.ppDestino.catDestino = categoriaDestino;
					$scope.ppDestino.catSubDestino = "";
					
					$scope.estiloCatEmergencia = "";
					$scope.estiloCatLiquidacion = "";
					$scope.estiloCatRemodelacion = estiloSeleccion;
					$scope.estiloCatGastos = "";
					$scope.estiloCatEvento = "";
					break;
				case 4:
					$scope.ppDestino.catalogoCatDestino = SUBLINEA_GASTOS;
					$scope.ppDestino.catDestino = categoriaDestino;
					$scope.ppDestino.catSubDestino = "";
					
					$scope.estiloCatEmergencia = "";
					$scope.estiloCatLiquidacion = "";
					$scope.estiloCatRemodelacion = "";
					$scope.estiloCatGastos = estiloSeleccion;
					$scope.estiloCatEvento = "";
					break;
				case 5:
					$scope.ppDestino.catalogoCatDestino = SUBLINEA_EVENTO;
					$scope.ppDestino.catDestino = categoriaDestino;
					$scope.ppDestino.catSubDestino = "";
					
					$scope.estiloCatEmergencia = "";
					$scope.estiloCatLiquidacion = "";
					$scope.estiloCatRemodelacion = "";
					$scope.estiloCatGastos = "";
					$scope.estiloCatEvento = estiloSeleccion;
					break;
	 		};
	 		
	 		for(var i=0;i<LINEA_DE_PRODUCTO_PRESTAMO.length;i++){
	 			if(categoriaDestino == LINEA_DE_PRODUCTO_PRESTAMO[i].id){
	 				$scope.ppDestino.catDestinoDesc = LINEA_DE_PRODUCTO_PRESTAMO[i].descripcion
	 				break;
	 			}
	 		}
	 		
	 		$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText = "";
			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = $scope.minPrestamo
			$scope.errorCatDestino = true;
	 	}
	 	
	 	$scope.getCatDestino=function(categoriaDestino){
	 		$scope.ppDestino.catSubDestino = categoriaDestino;
	 		
	 		for(var i=0;i<$scope.ppDestino.catalogoCatDestino.length;i++){
	 			if(categoriaDestino == $scope.ppDestino.catalogoCatDestino[i].id){
	 				$scope.ppDestino.catSubDestinoDesc = $scope.ppDestino.catalogoCatDestino[i].descripcion
	 				break;
	 			}
	 		}
	 		
	 		$scope.habilitarMontoPP = (categoriaDestino == undefined);
	 	}
	 	
	 	var banderaMuestraMensaje = true;
	 	function mapearDestinoJson (jsonDestino, monto){
			monto = (banderaMuestraCantidad && $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText != "" && $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText != 0 && monto != "" && monto != 0)?monto:0;
			
			banderaMuestraCantidad = true;
			
	 		if($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText !="" && !($scope.maxPrestamo > monto && monto > $scope.minPrestamo)){
	 			banderaMuestraMensaje = false;
			}else{
				banderaMuestraMensaje = true;
			}
	 		
	 		var jsonDestino = {
 				linea: jsonDestino.catDestino,
 				lineaDes: jsonDestino.catDestinoDesc,
 				subLinea: jsonDestino.catSubDestino,
 				subLineaDes: jsonDestino.catSubDestinoDesc,
 				montoDeseado : monto+""
	 		}
	 		
	 		return jsonDestino;
	 	}
		
	 	var banderaMuestraCantidad = true;
		$scope.validaCantidad = function(valor,bandera){/*Validar Cantidad*/
			if($rootScope.solicitudJson.idProducto == PRODUCTOS.prestamoPersonal.ID.valor && (valor != "" && valor != 0)){
				var valorMontoO =  $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText;
				var valorMontoM =  ($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText+"").replace(/[,$]/g,"").trim();
				if (valorMontoM == ""){
					valorMontoM = 0;
				}
				if(bandera == 2){
					if(parseInt(valorMontoM) < $scope.minPrestamo){
						$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = $scope.minPrestamo;
						$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText = $scope.minPrestamo;
						banderaMuestraCantidad = false;
						$rootScope.message( "Nueva Originación Centralizada", ["Debe seleccionar un monto mayor a "+formatoValor($scope.minPrestamo)+" pesos"], "Aceptar");
						
					}else if(parseInt(valorMontoM) > $scope.maxPrestamo){	
						$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = $scope.maxPrestamo;
						$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText = $scope.maxPrestamo;
						banderaMuestraCantidad = false;
						$rootScope.message( "Nueva Originación Centralizada", ["Debe seleccionar un monto menor a "+formatoValor($scope.maxPrestamo)+" pesos"], "Aceptar");
					}else{
						
						if(valorMontoM > 20000){
							valorMontoM = redondearValor(valorMontoM, 500);
						}else{
							valorMontoM =  redondearValor(valorMontoM,100);
						}
						
						$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = valorMontoM;
						$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText = valorMontoM;
					}
				}
				
				if(valorMontoM == "" && validaMontoInicio){
					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = $scope.minPrestamo;
					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText = $scope.minPrestamo;
					validaMontoInicio = false;
				}
				
				if(parseInt(valorMontoM) == 0){
					if($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText.length>1){
						$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = 0;
						$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText = 0;
					}
						
					$scope.muestraInfoTasas = false;
				}else{
					$scope.muestraInfoTasas = true;
				}
				
				$scope.sliderListener();
					
			}else if($rootScope.solicitudJson.idProducto != ID_PRODUCTO.prestamoPersonal && $rootScope.solicitudJson.idProducto != ID_PRODUCTO.tarjetaCredito){
				
				var valorMontoDeseado = ($scope.categoriaLinea.montoDeseado+"").replace(/[,$]/g,"").trim();
				
				if(valorMontoDeseado > 0){
					
					if(valorMontoDeseado > montoMaximo){
						$scope.categoriaLinea.montoDeseado = montoMaximo;
						$rootScope.message( "Nueva Originación Centralizada", ["Debe seleccionar un monto menor a "+formatoValor(montoMaximo)+" pesos"], "Aceptar");
					}
					
				}else if(valorMontoDeseado != ""){
					$scope.categoriaLinea.montoDeseado = "";
					$rootScope.message( "Nueva Originación Centralizada", ["Debe seleccionar un monto mayor a "+formatoValor(0)+" pesos"], "Aceptar");
				}
				
			}else if(valor == "" || valor == 0){
				$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = $scope.minPrestamo;
				$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText = $scope.minPrestamo;
				banderaMuestraCantidad = false;
				$rootScope.message( "Nueva Originación Centralizada", ["Debe seleccionar un monto mayor a "+formatoValor($scope.minPrestamo)+" pesos"], "Aceptar");
			}
		}
		
		$scope.digitalizaCambaceo = function(){
			
			//evento CAMBACEO 
			$rootScope.addEvent( BITACORA.SECCION.cambaceo.id, BITACORA.SUBSECCION.digitalizarDocumentos.id, BITACORA.ACCION.iniciarDigitalizacion.id, 0, BITACORA.SECCION.cambaceo.guardarEnBD );
			
			if($scope.isTienda){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$rootScope.capturarImagenIpad($rootScope.solicitudJson.cotizacion.clientes[0].idPersona, 2, ["Recibo"], "3", "fondoDivId", "responseIdentificacionIpad",2, "Comprobante");
			}
				
			else
				$scope.bloqueaInput = false;
		}
		
		$scope.responseIdentificacionIpad = function(responseIpad){		
			$rootScope.loggerIpad("responseIdentificacionIpad", null, responseIpad);
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			
			try{
				if(responseIpad.codigo == RESPONSE_CODIGO_EXITO_IPAD){

					//evento CAMBACEO 
					$rootScope.addEvent( BITACORA.SECCION.cambaceo.id, BITACORA.SUBSECCION.digitalizarDocumentos.id, BITACORA.ACCION.finDigitalizacion.id, 1, BITACORA.SECCION.cambaceo.guardarEnBD );

					$scope.bloqueaInput = false;
					var arregloDocumento = [];
					
					if(responseIpad.formato != null && responseIpad.formato != "") {
		 				tipoFormato = responseIpad.formato;
		 			}
					
					for(var j=0;j<2;j++){
						arregloDocumento.push({idDocumento:682,documento:responseIpad.arrArchBase64[j],formatoImagen:tipoFormato});
					}
					
					$scope.arrCambaceo = arregloDocumento;
				}else{

					//evento CAMBACEO 
					$rootScope.addEvent( BITACORA.SECCION.cambaceo.id, BITACORA.SUBSECCION.digitalizarDocumentos.id, BITACORA.ACCION.finDigitalizacion.id, -1, BITACORA.SECCION.cambaceo.guardarEnBD );

					modalService.confirmModal("Solicitud de cambaceo", ["Falló la captura de la hoja de cambaceo. Intentar nuevamente "], "CANCELAR","ACEPTAR", null, null, null,null).then(
							function(exito){	
								$rootScope.waitLoaderStatus = LOADER_SHOW;
								$scope.digitalizaCambaceo();														
								
							},function(error){
								console.log(error);														
							}
					  );
				}
			}catch(e){
				$rootScope.loggerIpad("Catch al digitalizar cambaceo", null, e);
			}
		};
		
		function redondearValor(valor, unidad){
			var valorDes = Math.ceil(valor / unidad)*unidad;
			var valorAnt = valorDes - unidad;
			
			var valorR1 = valorDes - valor;
			var valorR2 = valor - valorAnt;
			
			if(valorR1 <= valorR2){
				return valorDes; 
			}else{
				return valorAnt; 
			}
			
		}
		
		function formatoValor(monto){
			var num = monto+"";
			if(!isNaN(num)){
				num = num.toString().split('').reverse().join('').replace(/(?=\d*\.?)(\d{3})/g,'$1,');
				num = num.split('').reverse().join('').replace(/^[\.]/,'');
			}else{
				num = "";
			}
			
			return "$"+num;
		}

	 	$scope.abrirDialogo = function(){		
	 		$rootScope.waitLoaderStatus = LOADER_HIDE;
	 		modalService.huellaModal("bgAzul");
	 	};
			
	 	$scope.getDescripcionProducto=function(idProducto){
	 		return generalService.getDescripcionProducto(idProducto);
	 	};
	 	
		$scope.cargapagina = function(productos, consultaPresupuesto){
			var esPrimerProducto = true;
			
			if ($rootScope.solicitudJson.idSolicitud == '' && !generalService.getArrayValue("solicitudRecuperada") && !$scope.seCotizoItalika){
				generalService.buildSolicitudJson($rootScope, null);
/** INICIA_OS-FLUJO COACREDITADO **/
				generalService.buildSolicitudOSJson($rootScope, null);
/** TERMINA_OS-FLUJO COACREDITADO **/
				$rootScope.fotoCte = "data:image/png;base64,"+$rootScope.imgUsuario;
				$rootScope.cp = "";
			/*	$timeout(function(){document.getElementsByName( $scope.terminosCondiciones.campo )[0].checked = false;
				$scope.cTerminos2=0;
				},100);*/
				
				$scope.obligarAvisos();
			}
			generalService.setArrayValue("solicitudRecuperada", false);
			$scope.vistaSimulador=configuracion.simulador.opcion;
			$scope.vistaDatosUsuario = configuracion.datosUsuario.opcion;	
			if ($scope.vistaSimulador == '2')
				generalService.setRespaldo($rootScope.solicitudJson);
				
						
			
			if( !showProductosCanal ){				
				$rootScope.solicitudJson.idProducto = productos[0].ID.valor;
				resetPlazo();
			}else{
				
				if(productos.length>0 && ($rootScope.canalActual == 0 || $rootScope.canalActual == undefined) && !consultaPresupuesto){
					$rootScope.solicitudJson.idProducto = productos[0].ID.valor;
				}else if($rootScope.canalActual != 0 && $rootScope.canalActual != undefined && !consultaPresupuesto){
					$rootScope.solicitudJson.idProducto = $rootScope.canalActual;
				}
										
				$scope.radioProducto=[];
																		
				
				if($rootScope.rechazoBuro){
					var productosRechazoBuro=[];
					var a=0;
					for(var x=0;x < productos.length;x++){
						for(var i=0;i < $rootScope.productosAutorizados.length; i++){
							if(parseInt(productos[x].ID.valor) == $rootScope.productosAutorizados[i].idProducto){
								productosRechazoBuro[a]=productos[x];
								a++;
							}
						}
					}
					productos = productosRechazoBuro;
					$rootScope.solicitudJson.idProducto="";
				}
				

				for (var i=0; i<productos.length; i++){		
						
						var productId = parseInt(productos[i].ID.valor);																											
						var estiloProducto = productos[i].ETIQUETA.valor.replace(/\s/g,"");
						estiloProducto=productId==ID_PRODUCTO.prestamoPersonal?"prestamospersonales":productId==ID_PRODUCTO.modatelas?"tarjetaazteca":estiloProducto;
						catCssProductos[i]=estiloProducto.toLowerCase();
																													
						
//						if($rootScope.sucursalSession!=null  &&  !$scope.isCanalInterno  && productId != ID_PRODUCTO.italika)						
//							$scope.radioProducto.push( { liId:catCssProductos[i], radioLabel:productos[i].ETIQUETA.valor, radioId:"opc-producto-"+(i+1), radioValue:productId, disable:'true' } );
//						else
						if (productos[i].ID.valor == ID_PRODUCTO.tarjetaCredito && (!$rootScope.consultaFuncionalidad.solicitudesOro && !$rootScope.consultaFuncionalidad.solicitudesEkt) )
							productos[i].VISIBLE.valor = false;
						 
						var idEpos = "";
						if(productId == 21){
							idEpos = "Mercancias";
						}else if(productId == 22){
							idEpos = "Italika";
						}else if(productId == 23){
							idEpos = "Telefonia";
						}else if(productId == 24){
							idEpos = "Prestamo";
						}

						if(!$rootScope.consultaFuncionalidad.cambaceoPrestamo && productos[i].ID.valor == ID_PRODUCTO.prestamoPersonal)
							productos[i].VISIBLE.valor = false;
						else if(!$rootScope.consultaFuncionalidad.cambaceoItalika && productos[i].ID.valor == ID_PRODUCTO.italika)
							productos[i].VISIBLE.valor = false;
						else if(!$rootScope.consultaFuncionalidad.cambaceoConsumo && productos[i].ID.valor == ID_PRODUCTO.consumo)
							productos[i].VISIBLE.valor = false;
						else if(!$rootScope.consultaFuncionalidad.cambaceoTelefonia && productos[i].ID.valor == ID_PRODUCTO.telefonia)
							productos[i].VISIBLE.valor = false;
						else if(productos[i].ID.valor == ID_PRODUCTO.tarjetaCredito)
							productos[i].VISIBLE.valor = false;
						
						
						if(productos[i].VISIBLE.valor)
							$scope.radioProducto.push( { liId:(catCssProductos[i] == "tarjetaazteca")?"tarjetaaztecaproducto":catCssProductos[i], radioLabel:productos[i].ETIQUETA.valor, radioId:"opc-producto-"+(i+1), radioValue:productId, disable:'false', negocio:idEpos } );											
						
						if(esPrimerProducto){
							inicializaProductos(productos[i]);
							esPrimerProducto = false;
						}	
				}
													
				
				$scope.radioPeriodicidad=[];
				var arrPeriodicidad = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.CATALOGO PERIODICIDAD"];
				for(var i=0; i < arrPeriodicidad.length; i++){
					var periodoMinus = arrPeriodicidad[i].ETIQUETA.valor.toLowerCase();
					var periodoMayus = periodoMinus.slice(0,1).toUpperCase();
					var valorPeriodo = periodoMayus + periodoMinus.slice(1,10);
					if (arrPeriodicidad[i].ACTIVO.valor == "true")
						var disable = true;
					else
						var disable = false;
					$scope.radioPeriodicidad.push( {id: parseInt(arrPeriodicidad[i].ID.valor), valor: valorPeriodo, key: "opc-como-"+arrPeriodicidad[i].ID.valor, disable: !disable });
				}
				
				arrayPlazoMonto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA",tipoTasa);
			}
			if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
			
			$scope.ID_PRODUCTO = ID_PRODUCTO;				
			$scope.titulo              = generalService.getDataInput("SIMULADOR","TITULO"                ,$scope.origen);
			$scope.nombre              = generalService.getDataInput("SIMULADOR","NOMBRE"                ,null         );  
			$scope.aPaterno            = generalService.getDataInput("SIMULADOR","APELLIDO PATERNO"      ,null         );
	 		$scope.aMaterno            = generalService.getDataInput("SIMULADOR","APELLIDO MATERNO"      ,null         );
			$scope.genero              = generalService.getDataInput("SIMULADOR","GENERO"                ,null         );
			$scope.celular1            = generalService.getDataInput("SIMULADOR","CELULAR"               ,null         );
			$scope.correo              = generalService.getDataInput("SIMULADOR","CORREO"                ,null         );
			$scope.mDia                = generalService.getDataInput("SIMULADOR","DIA NACIMIENTO"        ,null         );
			$scope.mMes                = generalService.getDataInput("SIMULADOR","MES NACIMIENTO"        ,null         );
			$scope.mAnio               = generalService.getDataInput("SIMULADOR","ANIO NACIMIENTO"       ,null         );
			$scope.terminosCondiciones = generalService.getDataInput("SIMULADOR","TERMINOS Y CONDICIONES",$scope.origen);
			$scope.codigoCaptcha       = generalService.getDataInput("SIMULADOR","CODIGO CAPTCHA"        ,null         );
			$scope.inputCaptcha        = generalService.getDataInput("SIMULADOR","INPUT CAPTCHA"         ,null         );
			$scope.digitalizar         = generalService.getDataInput("SIMULADOR","TEXTO DIGITALIZAR"     ,"VALOR"      );
			$scope.etiquetaCuanto      = generalService.getDataInput("SIMULADOR","ETIQUETA CUANTO"       ,$scope.origen);
			$scope.etiquetaCuantoInvertir = generalService.getDataInput("SIMULADOR","ETIQUETA CUANTO"       ,$scope.origen);
			$scope.etiquetaCuantoLimite = generalService.getDataInput("SIMULADOR","ETIQUETA CUANTO"       ,$scope.origen);
			$scope.etiquetaCuantoInvertir.texto="¿Cuánto dinero desea invertir tu solicitante?";
			$scope.etiquetaCuantoLimite.texto="¿Cuánto límite de crédito desea tu solicitante?";
			$scope.etiquetaModoPago    = generalService.getDataInput("SIMULADOR","ETIQUETA MODOPAGO"     ,$scope.origen);
			$scope.etiquetaTiempo      = generalService.getDataInput("SIMULADOR","ETIQUETA TIEMPO"       ,$scope.origen);
			$scope.etiquetaDatos       = generalService.getDataInput("SIMULADOR","ETIQUETA DATOS"        ,$scope.origen);
			$scope.etiquetaNacimiento  = generalService.getDataInput("SIMULADOR","ETIQUETA NACIMIENTO"   ,$scope.origen);
			$scope.pagoRequerido       = generalService.getDataInput("SIMULADOR","PAGO REQUERIDO"        ,$scope.origen);
			
			$scope.folioIdent          = generalService.getDataInput("DATOS BASICOS","FOLIO IDENTIFICACION",$scope.origen);
			$scope.claveElector          = generalService.getDataInput("DATOS BASICOS","CLAVE ELECTOR",$scope.origen);
			
//			$scope.folioIdent = {
//					"tipoElemento"  : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.TIPOELEMENTO[1].valor"],
//					"campo"         : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.CAMPO[1].valor"],
//					"marcaAgua"     : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.MARCAAGUA[1].valor"],
//					"visible"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.VISIBLE[1].valor"],
//					"deshabilitado" : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.DESHABILITADO[1].valor"],
//					"obligatorio"   : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.OBLIGATORIO[1].valor"],
//					"estilo"        : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.ESTILO[1].valor"],
//					"imagen"        : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.IMAGEN[1].valor"],
//					"longMin"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.LONGMIN[1].valor"],
//					"longMax"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.LONGMAX[1].valor"],
//					"formato"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.FORMATO[1].valor"]
//			
//			};
			
			// $scope.bloqueaInput = true;

			// $scope.bloqueaINEPass = true;
			$scope.folioIdent.deshabilitado = $scope.claveElector.deshabilitado;
			//$scope.folioIdent.deshabilitado = $scope.bloqueaInput;
			
			$scope.pagoRequerido.texto = $scope.pagoRequerido.texto.replace(/\\/g,'');
			$scope.pagoOportuno        = generalService.getDataInput("SIMULADOR","PAGO OPORTUNO"         ,$scope.origen);
			$scope.pagoOportuno.texto = $scope.pagoOportuno.texto.replace(/\\/g,'');
			$scope.btnDigitalizar      = generalService.getDataInput("SIMULADOR","BOTON DIGITALIZAR"     ,$scope.origen);
			$scope.btnSolicitar        = generalService.getDataInput("SIMULADOR","BOTON SOLICITAR"       ,$scope.origen);
			edadMinima = generalService.getDatafromCategory("SIMULADOR", "EDAD MINIMA", "VALOR.valor" );
			edadMaxima = generalService.getDatafromCategory("SIMULADOR", "EDAD MAXIMA", "VALOR.valor" );
			etiquetaFrente  = generalService.getDatafromCategory("SIMULADOR", "ETIQUETA FRENTE", "VALOR.valor" );
			etiquetaReverso = generalService.getDatafromCategory("SIMULADOR", "ETIQUETA REVERSO", "VALOR.valor" );
			$scope.lugarNacimiento     = generalService.getDataInput("DATOS BASICOS","LUGAR NACIMIENTO"      ,null         );
			$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";		
						
			$scope.generos=generalService.construirCatalogoIdString("CATALOGO GENERO");
			$scope.nacionalidades = [{id:1, descripcion:"Mexicana"},{id:2, descripcion:"Extranjera"}];
			$scope.diafin  = 31;
			fechaDia = new Date();
			yyyy = new Date().getFullYear()- edadMinima;
			yy75 = new Date().getFullYear()- edadMaxima;
			fechaDia1 = new Date();
			aaaa = fechaDia.getFullYear();
			dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
			mm = ((fechaDia.getMonth() + 1) < 10 ? '0' : '') + (fechaDia.getMonth() + 1); 
			$scope.radioPlazo=new Array();
			$scope.days = dias;
			$scope.months = meses;			 				
			$scope.years = [];
			for(var i=(new Date().getFullYear()- edadMinima);i >= new Date().getFullYear() - 75;i--)
				$scope.years.push(""+i);		 
			$(".productos li").click(function (){
				$("li").removeClass('active');
				$(this).addClass('active');    	
			});
			
			$scope.celular1.valor = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
			$scope.nacionalidad = {
// I-MODIFICACION TDC (IMAGEN NACIONALIDAD)
					visible:true, imagen:"images/icon-form/Nacionalidad.png", marcaAgua:"Nacionalidad", campo:"nacionalidad", estilo:$scope.genero.estilo, deshabilitado:false, obligatorio:false,					
// F-MODIFICACION TDC (IMAGEN NACIONALIDAD)
			}
			
			$scope.lugaresNacimiento = generalService.construirCatalogo("CATALOGO ESTADOS");						
						
			inicializaProductos({ID: {valor: $rootScope.solicitudJson.idProducto}});
		};
		
		
		$scope.setEstiloModelo = function(){
			
			switch($rootScope.solicitudJson.idProducto){
				case ID_PRODUCTO.prestamoPersonal:							
					$rootScope.tasas = "";
					break;
				case ID_PRODUCTO.consumo:	
					 $rootScope.tasas = MODEL_TASAS_JSON["TASAS CONSUMO - ITALIKA - TELEFONIA.TASAS CONSUMO - ITALIKA - TELEFONIA.CATALOGO"];
					break;
				case ID_PRODUCTO.italika:
					$rootScope.tasas = MODEL_TASAS_JSON["TASAS CONSUMO - ITALIKA - TELEFONIA.TASAS CONSUMO - ITALIKA - TELEFONIA.MOTOS"];
					break;
				case ID_PRODUCTO.telefonia:
					$rootScope.tasas = MODEL_TASAS_JSON["TASAS CONSUMO - ITALIKA - TELEFONIA.TASAS CONSUMO - ITALIKA - TELEFONIA.TELEFONIA PREPAGO"];
					break;
				case ID_PRODUCTO.tarjetaCredito:
//					$scope.nacionalidades = [{id:1, descripcion:"Mexicana"},{id:2, descripcion:"Extranjera"}];					
					$rootScope.tasas = "";
					break;
					
			};			
		};
		
		$scope.obtenerEstilosDestinoPrestamo = function(){
			if($rootScope.solicitudJson.idProducto != undefined) {
				switch($rootScope.solicitudJson.idProducto) {
					case ID_PRODUCTO.prestamoPersonal: return "3px solid #f79857";
					case ID_PRODUCTO.tarjetaAztecaProducto: return "3px solid #ca774a";
					default: return "3px solid #f79857"; 
				}
			} else {
				return "3px solid #f79857";
			}
		}
		
		$scope.obtenerImagenDestinoPrestamo = function(){
			if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal){
				$scope.imagenesDestinoPrestamo = {
					emergencia:"data:image/jpg;base64,iVBORw0KGgoAAAANSUhEUgAAATsAAAE+CAYAAADyEbd0AAAACXBIWXMAAC4jAAAuIwF4pT92AAAJAklEQVR42u3dS1rbSBSA0VifJ+yQJbAklsAOPVSG4XMMth4l3cc5w+50B1RVv66wgcs8z38AqptcAkDsAMQOQOwAxA5A7ADEDkDsAMQOEDsAsQMQOwCxAxA7ALEDEDsAsQMQO0DsAMQOQOwAxA5A7ADEDkDsAMQOQOwAsQMQO4Dcri4BZ7p9vs+P/vnbx9fF1WFPl3meXQXCRE708BhLu9At/bMgdqQMHYgdrUInkIgdgNiRiRciEDvahE7wEDsAsQMQOwCxA8QOQOwAxA5A7ADEDkDsAMQOQOwAxA4QOwCxAxA7ALEDEDsAsQMQOwCxA8TOJQDEDkDsAMQOQOwAxA5A7ADEDkDsALEDEDsAsQNI4pr9E7h9vs/3/+zt4+tiaYESsXsUuft/J3pA6sfY30K35s8BYpc2dIIHpI3d2nDdPt9n0YPerp0+2dvn++zreLB9wMh4jiaLhzVh6dNQxqelyzzP6Q/E97vMqwtgwssVNesVd52yrE25ye7VC2+agH3ORZazNFVcoCXBE714NyLiPbZWMFU5KGuDZ8oTSaHbvv8znKGp8qK9fXxdPNbmDpfQxQld9rVI8wLFkoV5tCheuMi3ntYiZuSyvh0lVewED86f5rLGLt1j7JbHUi9cIHRjQucxtsCimfIQudf+e5PdwAnvqCnPUUHo8kv/aqzggSeg0o+xey6KR1o6h27rNJflXJSJ3dYF6vR+I0SuW+jKxc7YjtAJXZvYeaxF6Nbt2+r7vmzsBA+RM819V/qHd3qlFqETuhaT3R4L6oULuoeuyr5uETsbA3vZDbxN7PaIluCd9zjvJiJ0Yid45cImgp5OxE7w2set40E1zYndqZuowk+BqBK4ygdX6MQuzZSXaQNVfhtNxoPssVXsUgUvw0bq9l7BSmtimhO7MBss6mYaGbg9P+csH6fQiV2L4GWa7PaMx1mf294BzLhGQid2gjD4c6o8qWZYK5ETOwdo0OdQ/Qv7mdZM6MQu7ME5c3N1jFyV9Xs1dkIndmEOTLavafmujxjX5NljrMiJXajDEu2QOBB5rlH1r6+KXZGDkmma634Yot7AKr3YInYFD4rIiZ4pXexo/GjtWrqJiR2HHQaHIOd1tcZi5zA6AKJnjcXOAXQIXG8emVwCB4/t19FvmTPZcWDoRM4aYLJzyDhkyjPhiR1CJ3h4jGXdgRE5NyHETuiwTniMdYA46rHWI63YIXSCh9gJndAJHmIndAgeYtf3IGGdELvUU50DVCt4pjuxEzoED7HrGjpTnRsdYtd+OsD6IXbp7+oOisdZxE7oEDzEDkDsTHWY7sSO+AcC64vYlZjqsD9cBbHz+IrHWcTO4w3WG7HzeIL9gti5y2PdxQ5A7HB3x/rnc3UJGGXvrz8JBGJHybj99P8XPcSOkpETPcSOVpETPbbwAgUpQxf1Y0HsEDrBw2Ms/UI34ves3j7fZ4+0iB2H2Ss49/+fV+IneHiM5ZCpbmRoRAyx4/TQvX18XY6I0St/j6/fIXZ4VEbsQHgQOzzCBgzdb3+3R1nEDhA7yPb46hEasQMQO0DsAMQOQOwAxA5A7ADEDkDsAMQOQOyAVnb/sexZf9qE77Gkqsw/AWbPczm5qP8+dj8WCKGr+/FPLmrNzwOcyQGxEwgQuuifjxcoxBta2Bw7YQA36wyG/pLs6K9w2hR0k+FdBz+dy62/AH3qfFG93QQ8xpqaAI+xggc5dX6DsVdjoRhfnhkUu4oX1mYBsQPcsFN+PpMLa6pD8Dp8HtOeH1D2iyt0CF7dj//q4oLgdeBrdoDYAYgdgNgBiB2A2AGIHaFE+KZyP2wCsQMQO5b47U2pZ05WpjrEjvbR8V0DiB1D4nH0Lxk31SF2lJ/ynv0dpjrEjkMeDUdNeUdPj9RydQlYGrxXg3P/59ZMXEvjZqrDZMfhE96WyWzNFCd0iB1hgtfl40HsKBa8CJEROl7ha3bsFpujXzwQOUx2lJ/0hA6THaUnPZHDZAcgdoDYAYgdgNjBKr6/FbEDEDsAsQMQOwCxA8QOQOwAxA5A7ADEDkDsAMQOQOwAsQMQOwCxAxA7ALEDELsy/PhxiMMvyRY5gu4fvxDcZBd6kwrdPw6r/WSyM8WBSc9kJ3Rg0jPZiRz2n0nPZOfOipsuYnfCxnLnxQ1Y7EqH7u3j6yJ0rLVm/wie2B0aOpHjzOgJntgND53IMTp6roLYhQidq0WUKc90J3anP2LAUVOe4ImdxwrsP7Hj1TvjXhvN3dceEzyxa7XhRc+ajwieffU/3y4W4G56vzHdtU1wiF3LAyJ+4obYiR/ihtiN2NgRQvPogAmgsCF2pwbv+58deVh++n+LYI6orVkn8RW7sBPeUeETwRyh2LIGQid2aR5p7//bozfvK39f5iBGjIH3aIpd2+A9Owhnb+q1f//ISGY56COugciJXYgJYsTmPnv6cyhjBF7oxK5N9CJPfx0d+XhvffdzmWfXcsQGO/PrXQ5IzrBV2oMmO5Pe6QdUCONGwdqIXahDsXRDfv/zEQ7Vs4+h4oGLPuFsueZr9qTYsejgrNlg0cK3NQxnHrLsj2h+xJPYlZ7ysoXPgYv3iOqai126Ke+3g2BDC5zIiV34CWePDS5+vcNm7cWu1bT37CA5BPXCZn3FzrS34MA5JLmiZu3ETvgGHFCH6dyYWROxE76Ah7v7WzsETuwYuOkjHdCzXkn0pmbETvxMWcKG2PU5OL41SNgQu9YHTARFDbFrfyCFUNAQOwe5QRCFDLFj1yDsHUyRQuwwQcFCk0tw3uQC9qTJLsXmMskgcGLXatOJHgIndqY9EDmxEz4YEzh7739+b+xBd1Wbj6OmN3tN7GxI7Cexw0bFvhE7Dtq8NrH9YX+IXduNbXPbA/aA2LXc9DZ+jzW2zmLnUDgYZdfQOoqdQ+PgWCPEzsFyyFx7xM7ha3sgI11PcRM7EsXv7EOd6XqIm9jRMIAdiJvYIYDChtghgKKG2CGCoobYIYaChtjRJI4ChtgBPOBXKQJiByB2AGIHIHYAYgcgdgBiByB2gNgBiB2A2AGIHYDYAYgdgNgBiB2A2AFiByB2AGIHIHYAUfwF+XSGUHucROwAAAAASUVORK5CYII=",
					liquidacion:"data:image/jpg;base64,iVBORw0KGgoAAAANSUhEUgAAATsAAAE+CAYAAADyEbd0AAAACXBIWXMAAC4jAAAuIwF4pT92AAAHqklEQVR42u3dTVLbQBCA0ZjyhhtyBI7EEbghS2WRSlVC2caS5qen+70DBGQ0n1u2NLls2/YLILsXLwEgdgBiByB2AGIHIHYAYgcgdgBiB4gdgNgBiB2A2AGIHYDYAYgdgNgBiB0gdgBiByB2AGIHIHYAYgcgdgBiByB2gNgBiB2A2AGIHYDYAYgdgNgBiB2A2AFiByB2AGIHIHYAYgcgdgBiByB2AGIHiB2A2AGIHYDYAYgdgNgBiB2A2AGIHSB2AGIHIHYAYgcgdgBiByB2AGIHIHaA2AGIHYDYAYgdgNgBiB2A2AGIHYDYAWIHIHYAYgcgdgBiByB2AGIHIHYAYgeIHYDYAYgdgNgBiB2A2AGIHYDYAWIHIHYAYgcgdgBiByB2AGIHIHYAYgeIHYDYAYgdgNgBiB3ASFcvAfd8fbxtXgV6eH3/vIz+mZdtcz4jcOSPntghcpSIns/sEDpKnINi5yQTOkqci2Ln5IIS56TYOamgxLnp1hMemnGLAELWg29jnXAiR4lz0GUsQkeJc0zsEDpCnmutL3nFzuUDlCB2mOoocc6JHVDCUreejLgEM92A2KUJ2tGfL4QgdkuGrcXvK4AgdsvHbe8xCR8Uj12V2x2EDwrGrvr9XMIHBWLXM3S9wtHzd/76eNsEDxLFrlUwZoTh0c9scVx//w3Rg8VjdyYI0QNw6/c7erymPFg4dnsXfobF/v0Y9rwGggfjnX5cbM8if33/vGRd5HuPzQP5sOhlbPZJbu+xihkkm+yqTnItjl0QIUHsfCbldYAykx1A+ti5RPM6QJnJ7uvjbau82IUO4hi6EUCVz69EDorG7lYEsoVP4EDs0oZP4EDsTkUjavyyx028EbtAi653CC14ELtdXt8/Lz3CsWKMer0WQJDJrvpzop6egGKXsf8u+uzhEzgoHLvs4RM4ELvdkYgeQGEDsesek1EhFDQQO1MVsCRbPA3gthNIHLvqO54IHRSb7GzxBERwHb3os3/uJnBQOHa3YmCLJyB17O7FYbX4iRuIXbr4CRuI3bTAtI6hoIHYHdJ7W6OV4mSLJ0g+2VXe4snTHlDwMrbKFk8CB8Vj9ygIq8dP4EDsDsciagCzh024mWHUer+uuOh6vTgWO5jsTCALvHMB99niCRC7s9OMicZUB2UuY7M++C9yIHaloydyUDx2t2KQJXwCB2KXMnziBmLXNCARAihsIHZhQnM0irND5iZmSBC7kdsaRZ6+bO8EBSa7KrudmNrAZWyp8AkciN3DKKwaP3EDsTsdjUgBFDUQu+mBORvFmSHrGXSBhkVit+qijjKR+gYYBsXu6+NtqzBdiAoUiN1PCz1j8DLHreoONYidBVR0ehM9xK7YAqp+iZpxhxrEzgIaFLoRx9zjdzftIXYNF2WWXU5mH8e9n9/i2Kp88YTYTQnNqMV1NAarLP5WN28LHmL3z6JqeSkV8bOzLIv96DPLgofYfVsImT7kz76494ZP8HAZ22ByELkYx+ymacSuSPiqTy4/fSSRdYr3txe7bieSz+XWDR6Ujd2RSPS8XQKg+xcUK0xX94LqRlpvOOTx4iWw2B07YmeR/Hc8lRZ+tePFZWyT4GW6DMz8cHzFnZMFXeyan1AZP/fKED6LHbEThtPRsGU8FIxdpfA9E5dexy1oECh2jxZnpPj1vJl2tSi5sRixGxSBWRGs/IyoJ0gQuwlTwOzYZNjQQOQQO3E4FYPVj0/cEDuXgodjEflYZ8TN532UiJ1LwbEL36QGk2O38jRUPUYmM8QuyTQEiF36acgWT6Y68nuxOJ47nooL3s4nmOyKTzjZJz2BM82L3Y0TouIlYMZne1sETiAoPdll/79FVw6fCQ6xE4Rm8YhyvMKG2DW4dNmzkKqE79nItHoNxAwGTHZHHweLvL3TkZBnjVTlnV8Quy5xiLa90/efXW2x+8IBsRs8BUSJTIXwCRxiF/ASMFIUVj1WcUPsTEKnoxHtmIWNaEaukeuMhWZ3kz5/bDEjU+han8/XKBGo+k3fKoHyTSwuYwcs+lkLLfvTH1DpjfOybd6wR4/T2U5Mbwi0DlyPc0rsdvwhqi1ql65Eu8pLcRm70uK3xROsR+xOxsAWTxB/qhO7DpHw7SrEipzYDYzI7AAKG9VDJ3YBY/PsH17AEDmxa/7HGBmWiBH76XVw6wkrELug0av2rgtiFzQAGcMncIgdT4VhtQCKG2JHugAKG2JHmMhEeH4QxI7S05dbXVjdi5cAELviTDN/XoNHr4NLaVzGJgue7Z1gbfaz27m4be9kqsNkVy6KmRa7SQ6TnenuaSvFr9KxgtgNmHIiRMF/1whiF+ay7mhERv6eQofYiV5qIofYiZ7AgdiJn8CB2ImfuIHYCaCwgdiJopCB2AHcZtcTQOwAxA5A7ADEDkDsAMQOQOwAxA4QOwCxAxA7ALEDEDsAsQMQOwCxAxA7QOwAxA5A7ADEDkDsAMQOQOwAxA5A7ACxAxA7ALEDEDsAsQMQOwCxAxA7ALEDxA5A7ADEDkDsAMQOQOwAxA5A7ADEDhA7ALEDEDsAsQMQOwCxAxA7ALEDEDtA7ADEDkDsAMQOQOwAxA5A7ADEDkDsALEDEDsAsQMQOwCxAxA7gJN+AwiXqjW+/B/HAAAAAElFTkSuQmCC",
					remodelacion:"data:image/jpg;base64,iVBORw0KGgoAAAANSUhEUgAAAToAAAE8CAYAAABQG31BAAAACXBIWXMAAC4jAAAuIwF4pT92AAANLklEQVR42u3dS3IUMRZGYZtgwg5ZAktiCeyQoXvQ7Qja4XLlQ4/7+M4YylVK3ZO/lJLy9e3t7QUAKvNNEwAgOgAgOgAgOgAgOgAgOgAgOgAgOgBEBwBEBwBEBwBEBwBEBwBEBwBEBwBEB4DoAKAi3zUBEIe/v39+euT3j19/XrXOdV4dpQ7EE9sziI/ogLKCIzyiA9oIjuyIDmgjOcIjOqCF4MjuOZ66AgUEB4kOSC2495R29HOlOqIDUiW4z6R15O+Q3f9jZwQwQHDm4SQ6QIKbILRnf58QJTogdII7IikiIzog7RD1jMC++rcjv2v2J8iGrkCgIr+S0mYOYT9+dtYUSXRAAMndFchX33O0PDPKztAVGDRMvSqA2eI48ztWP0GW6IAkCe7sgt5ZcruTwlZJfRe2gAEv986F2y24o7/v6uJjiQ5oLLgz/3+V4I6muhGCy5TqJDoQ3OTijiKE91TX8bABiQ4Ed0NWEXcn2I4m0YHghhVy9S1YVx6ySHRAsSFq5LVmd+R09qFFBqFLdCC4QilsxzD00RPdSFgwDJL7X5GfLdbIxX12v+yzf5/9BmDoivaCm/U3I8hh5PfLPCcp0aGE4HZIztA2D0SHloLrIrlVxzjN+DyiA8EFEdxKkUh1RAeCk+CkOqIDwVUQiVRHdCA4CU6q+xQLhhFScCOKeeX7T7ttls/2e62jQ0vBzZDeo78bKV12XVdn6Iq0kvs4RL17DHjH44tmDYejQXTYLrgrx3iPSnHdZNd17pLokEZwjwq108LXTOKM1I4eRiD8ELVzEgHRgeAuP1l99v8yHD0UKdVFT8FEh7IJ7qvPGH16ruFubMzRYZrgdi72PfoZI+aYSC5+20h0KJPgZv2ezu+NkOiAQAnujnCvzAPeXbNXjehCl+iwJcVlSzpVfmNXOUt0WJriVm64H5nqqou8Ova6Ynu6uTvPNXKebETiiTzfOPM7R97ra+iK6cOeq2+5//jvMryOL6PkJDpgo+BGf+bMZBd5qLrqybBEB4IblCwepbPRq/OPLiiOPhe3KsnZGQGCW1QMz2R3ZQib9aHC0bbu8tDE0BXTBTdDchbx3m/nke0Q/dBRosOS3QxX5tDuCKub7HbOKc5+mmvoivCCuyOdbu9hWHUNO67xs2BYgZwqkCwLa3fPF664fhEklyHNSXQEFz4B3El1FRNhpEMTMrUt0RHc1AKZece/uxA40+Ga0U6FyXYDITqCCz/s2JUIXb/r3yla/yE6gtvSQVcWwleyi5rqol6/jJIjOoJ72jk/+zwnc8S7hiuuSVbJER3BXX5xzJFOHWnImCHVZRZcdIiO4C5/njdl1Z9m2HmmH9EhzIb7z2QXdVdCtAcTBEd0WDzEuSOACkOblek0+oOiapIjOoJbLqrOQ90MS30qSo7omguuIzuGrwRHdAheIP9+1l1BdJNvlsXa1SVHdArk1Ofd3XeauW0JLvdNiugI7tLfWnmCbZZtXJluAp0kR3QKpNUwdKYsM82jdpMc0RHc0++X4eUvI5bO3HmVIsERHYokuAztOfLBSbVr2FlyREdwaTgyTxfl3RfRrmF3yRFdcMnt7nQdBHv0NxIc0aGY4DKnutHtnDWFkxzRlRDcqPdoZtunOkp2s/b+ElxMvNc1gOBmDKFGpJXIhTCrnTPPo5Ic0bUR3KiizlQII35Hpx0fHadGiC644EYML8+eF9etGDLPoxIc0aUX3AjJZU4pBEdyo/AwIqjg4BqSHNFJAB8+f1Tyq1wUBNcXQ9dJRTKik519Kuq8uNopnOQkunYd7LO/U+G8OIIjOKIL3Ml2nAk3YihLcLHbguSIrqXkrnT6j7/DEDWHIEiO6MLJxPckOIIjunLFc/RBgI5IcCRHdOmT3NEz0nTK/ZKrtHdXfzqH5SUnO92dU2xH7oro2tErHnslxc3nmyaIP9TCf9uO5EjO0DXYkHXU33v0dzK8uGbnzYHgINEVSXWVE+KdBEdykOgSpshOQ97qOztIjujaDG+7DDsJjuAMXTGkmLOnvcpDVJKT6FqkDw8T+iY4giM6LEp7lSSX7XeSHNGVTSKzOmyVhxFd3nFLckTXslCvDl8JjuAwBg8jNg8hv5Jg9mKpupuB5CS6MtJamaaqrZPrdsoxyRGdNDdJnNlPwyU4EF2iVLejA2d+p0GV4ic5opPkJqa6rK/eIzjsxHl0Nzr26AcQBEdykOjKJcGzx7UTHMlBokuV6ioXOsFBoisogModvKvgSI7oWg41ux2DbpjaT+xEhzaprrPgpDiik+qKp7rugiM5okPhVEdw59qB4IhOqiM4kgPRSXUEl/UGp3cTnVQnwZVNcyRXAwuGJxSI7VquIyQ6BJZcp+ImuT44YfjGEHZ0ihpZwFcWvSpuSHQomeCkF+0h0SFFquvwEmhAopPgJJZFbQeJTqpbVEwSHCDRhUsOo+Qiwe29cUGiUxwTh0kSHCDRlU12EhwwBjsjBstsZwIkuDHXSjtKdHgimiOS+vffHH1RDsEBEl3KZDdCrFp7/HXSrvXwMCKpgBQjQHRlZedJap1EDqIjO4IDhmGOLnhKILd910Xb18FT103pzkQ4INEBUh2GYY4OANEB0h6IDkiO4SnRAVKdVEd0gFQHogMKyE6qy411dEWGNhIJ8Bjr6IILjBBjXXftJ9ERmiLWf9xoJDpCkwD1Fe1LdMRGfE37DuERHbkRX5u+RHhEF15uOzppJLFXK9KdbUt4RLe8E1bodNor3w2E7BqLbmYHvNqxst/5I7Zpxj42Y8Ex2TUT3chiPNJ5uq+hW93eWfvZipsj2TUQ3YiCe9RRPLg4Xkwzr0O2vjbyd+z4m0RXSHJHjy6HoVgE4Rz5+2RXUHRXCunfjkBs68R391pl6Gsrvi/ZNRPd1fkLctsrvVXzW5Xl8uz7EF0R0V0ZQnRbSxb992aad4ooFrIrLrord9fZRV+lU+1YQhJ9KBZZKGQ3llSnl8yQXJcOM/NQyb+/f7599vk/fv15zTqdsLtfZG47ogvQ8dwJ16bkZwX7SJKdhv8jby5ILLrs80AdxPdV4WVLJ1H6jFQ3jjDvjBh9QX/8+vNKctrybF+rvIuD6Ary9/fPNx0hRlu6DvnTZXbCPHW98pQp+0LVSknh6sOOaPNzGXdu6NPP+Z6p+Gad1NG5o8xOW+bmINFdLIiVi4WdrXatjaI+LMqcjKS6Bonuswv+Pkk+s5CjbV6PlpAcngCJblEBvxebIssnuCiJLksikuoaJbqvLj7pSW9ASdE9k56iHCM27Rjjmjy6BnZLJBbdnTm4j/9PIrk2hNROuW70ZJc00Y0ajj4TX/Xi3vWuDFuZtCfRbRDes6K+suUp28uOV3xfyUKqI7pAwjsjga82rkfs8JnkSw5SHdE9KapVF331MoosnVmCIG6iKyq9isKqLrZKSUiqayi6r4pQZ5DapDqia1egxEdqVcQg1RHd6SLu2GHc8cmb6BR9CQnq6MdTkFRHdCR44W5KWCBvoiNHGO5hOt80AdyE6v+m7kNbogOIgegAqU6qIzpAqgPRAVKdVEd0ADGA6ACQN9EBxHCKbrIjOqChvCU6gBikOqIDINURHSDVSXVEB0CqIzpAqpPqiA4gBqmO6ABiaJ5UiQ4w3JPoAEh1RAdAqiM6QKqT6ogOkOpAdIBUJ9URHSDVgegAqU6qIzqAGJokVaIDyNvQFYBUR3QApDqiA6Q6qY7oAEh1RAdIdVId0QGQ6ogOkOo6pzqiA4ihfKojOoAYyidVogOkuvIQHSDVlU91RAdIdRIdAKkuu7yJDpDqJDoAUl12eRMdINVJdACkuuzyJjqAGMonVaIDUD6pEh0g1ZVPdUQHoHyqIzpAqiuf6ogOQPlUR3SAVFc+1REdQAzlUx3RAcRQXt5EBxBDeXkTHUAM5eVNdAAxlP++RAdIdacEd1RykWRIdICUNFRwEcVOdIBUN1RwEX/nd10PiCWWCJK4mi6jipzogA2pLuowtZrgiA6Q6soLjugAqa684N7xMALYKLvRApotuR+//rxmXCYj0QENh8bVE5xEBzRNdVWWikh0AIYJs9L+XIkOKJrq7iS4aocQSHSABFcuwUl0QNFUJ8FJdED6lPZIRhIc0QGpUt0ZaREc0QFlUx3BncccHRAs1Y1OcR3m4CQ6gDTbI9EBBQVFchIdQJISHYBswjIPJ9EBhCjRAcgmMQlOogMkOOQSXZS3IgHEZugKfHmz0gogOoVCcsBEXt/e3lIVhShfR3KuJSQ6CUGSAyomurMFIhHkFZxrh9aiu5oGFI7rBaQS3d2hjyJyfYAUortbTIrKtQBSiG5kkSm2Pe2t3UF0AQqweyHOfjpKcCC6oMVZqVh3LfMgOBBdgULeWdxR16iRG4iusQAqQ24gOtIjNoDoiI/UAKIjQEIDiI4EyQwgusJSJC+A6ADg5eXFUeoAiA4AiA4AiA4AiA4AiA4AiA4AiA4A0QEA0QEA0QEA0QEA0QEA0QEA0QEA0QEgOgAgOgDIyX8AnU7YyXTJkn8AAAAASUVORK5CYII=",
					evento:"data:image/jpg;base64,iVBORw0KGgoAAAANSUhEUgAAATsAAAE+CAYAAADyEbd0AAAACXBIWXMAAC4jAAAuIwF4pT92AAAPTklEQVR42u3dSXIcRxJGYQKGDW/II/BIPAJvyGVp0Y02NIUhhxh8+J6ZNjIJVZkR/ur3HCKeHo/HNwCozrNTAIDsAIDsAIDsAIDsAIDsAIDsAIDsAIDsAPTmxSmow59fPz59Heb7z99PzhK68uR1sdqCIz6A7FpKjvjQFdfsmotuxt8DyA6hBUp6IDuUTXVSHsgOafn+8/fT6z+EB/wHNygKpbojcjsjMjcuINkhZJo7k/okPEh2SJfq7iSwI0KT8CDZoUUilPAg2TVKUbvTzUfCGfW9JDxIdkT3v3+/K+Gs+FwJD2TXSHJHirlywRMeyK5pmote8DPaSq0qyK5xmtspvB1i/Up40h3IrnCa09ISHsiupeh2F712EyC7IW3rmfdLq6Yc6Q5kVzzN/V3ku4QXQSaEB7JrIrrdwgNAdkNFd6Rl7XqdTLoD2RUSXabCXyldKxiD7IJLboboZrTNVdp/QkR0yi0EsEpyK16cn/3yfxZxecwGZLdJdCuEN2v9uioJjQDRVna72tZZwlstuwptKAHiM1o9VLzrxfnoIql0jdENFZSW3e6FJ1cmih3JlPigjSW6U9/lzPeIsDKxdI9KvJjcYz/rM4n8+fXjEaHYZosuspBf/ybpkV2pVBdxQu8W3gyBzDqe9/6uthSSXRDRfZXudgpvpCh2nl/ywxXSXrPb9RzaSLF89j1HX7MbJYXo7Z9d0tAu2UVIllFSx4jvkUUQb7+n1Ie32HBnYyv92baNUUR3dAFTgOySJpndwovwvTNLTqpDm2SXabLPetXt6jmQ5EB2CYWXYWnzGXK+8vc6tKxETnalJ20W4e0WnXIA2RHeku9rW0aA7IYJb7f0Zgvv7P9fUXRuTqCk7F4LNlvKi1DkEh3ITsor3zYSHchOykspmxF741aH4Mmu/cR2YwAgO21tAuFJdUBz2WVpa+8IiOhipHSQnZQHgOykvHWpq3v7qn1HyvXsVkpo5arCZ9fA27VXLkB2BeT22eevkMZnwouyYQ9AdoUEF102Uh1QQHaRbw6sEF62dDdzvLwGiLKyyzBhd+89ujPVrR6f2ZuFg+yILllb2/GSwlH5ESO+fQu2leLKVTtGF3C0FLX6zYzIkB1CJbvV+32O3m2+Sspz3QuS3cYi2yGR3anqzvfYvZG2ZIeIhHiDImKR3dl8JuO1xyjfmZhQOtlFS3URUtadz63wuMbIywwEihCyyyK6VfK5+3lHP2tmmz5SoCM+i+xAdgWFN2OP2pWyniFxssN22WUV3Q5xjJLd7vXvVt742f3wN8iulOxWSuSrzxglulXn3jU4rOQ5ohwyTuboNwUiLhxw9Y63xVWRSnYVmS283S1wROmZdSC7jcJbcUd0p6gjSU/KQ2jZVWth7xzH7ELN+GjGVekpZ0h2CYR3t1ivPoQb+ccly4bnILuUrdTOY1pdrFnOt53hMILlj550aGHvyuyz83B0Mcu7j6lcPYbZY2ifXFzlxSlYm1COFOtHy0VFWSX4zP8zWjhndmCzQRFCtrFdJuWK47yTvl7bwFFindFWZr3jDbJrmfCitWuzr3XNkl6EYwPZ+ZVdKLyrqW61CEZ/nru1kOwaC++M6HYd++jj0tbiK5bejbUt3pwCfHv+jtztnrHkUrZl7N24IDuySyi8oxI7cyfz7hitXjOP8EB239aunLv6Ox5NdbuOdddzcYSHFrJbdV0mwvce2ZpGOLYdn0t4ZJdKdrsvPI8qmCvt38xjr5C2CA9LZTfjNbFMO2NlPq6swtt53RBkN2SSZXl84E7xVBbekePbde4Ij+xCyC7zM1LRhH71xsbKlLf6gWGiI7upE3vHg7U7pbn7if+PPn+H8EZcSyM5lJDd6ImcbRn0Ud93hmBXCW/W6i8ER3YhZDfjmsvolYCjv8a16prXihsJM9/8ANltk92MJ/xX3JWLkBp33DVdJTyCQ3rZvU7GGVsL7nr0oMry6tmFR3IIJ7sZkzjC8t0rpBdhMdBR30WbCrK7MJGjPTWfPbWs+vFYtVAByC5swWcW3Ujp7SzqaMIjOJSS3YyHcSMUSQfpZd3BDGS3vMCrim5H2s2W8mbvUgayS5sIuomuU1sLlJRdhdanyqMnUdpaYARhNsmeeUE70uMZZ89HhsUPzmz+TXrYxXOUYskqutlbEa5eKGHFGNrhC+Vl915BZP2Vnym5v8/Jka0CCQ8InOxmP3Gf8c2I7C3e2T1cSQ/lZTe7qGf8/d3FmSHdSXmIytK7sSvTVZQdy84uOXX3Gl3mx2vcuMBMXioe1G7RKdp/n4ujd2udO5RrY2fJZ2exnLleNUvm2Xdccx0PZBe4DVsluU6Jm/DQXnYrU13kV9CyypXwQHZJE50zNX8cSA/tZBfpWl1k0UWWw9XvRniQ7DYU5EzRKWrnBmQXgkiJLlsbPSKZa2tRXnaZHqTFfHkTHiQ7Uk0tOcID2RUTUDdxnn1tTFuLlrLLtnwRtLUgO1IF4YHspC0yG9HWOquQ7Ei1xTi4joeUsjNpoa2FZIe2wtPWoo3stJbQ1kKyA+FJecgku5WTUyFoa1GbtHtQmLR4T3pH97o4mwoh2WmToK0F2UG6JTyQHTBZeO7WIoXsTL4erffscZbyINmB/AmP7BA/7WQryt1p0+MpeFEc6JbyPJ4i2aFA8stYnKuTlLaW7CC9tjr32lqyA5bLfZdQPJ5CdtDCkrCUR3aAthZkB6kuWSurrSU7JBEdtLUgO8Up3REeyE6qw1fC09aSHYKILusd2AzpTsojOxBduzRLeGQHresSgWRsa81iskNDUVQSvut4ZAeiG34s2YUn5ZEdiK6E8LS1ZAeia9HSamvJDkQ3/Pgiy0JbS3YgOgmJ8ELw9Hg455EnfcfW9awIdp2jUcKyNBfZtS9s1+hiiWNmGiM8siM752apSHa2l4RHdm2L2uTvd23LmM/jxSnAFcmsKsrXz8ksvTPHYAtHyU6yC56gVn3XLNL76Hyc+f6ER3ZkF1weHcV39piPfnfCIzuySyCKTMl0x3FJeWRHdhMn+Oo0tLNI7xxrxHRKeGRHdgnaPoWqrSU7LJHdqId0M6Sl6sJzLsmO7DYUUZZXuwgPZFdcdqvaI0WqrY2OVU8UzJCCObOQJcaNiTXyyI7oDhTADEEdXZfOCI39EXJOyQ4b2h/CIzyyQ4hUt6Ld1NKOPZf2uiA7BJZQ1o10so+d63hkJ9UVlyvh+TEhO+IKKx4Fqa0lO2idoa0lO5z9FSccPyTdhUd2ko9j1NaSHYhmdyKFtpbsAPiRITtImORFeGRnosP4N2xryQ5Aix9MsgOKS8rjKWRXCtfD8Nm88HgK2QFlU917cuv8eArZIUy7hXhdQKUxIzugodA6trVkJ1GlShrYc+4rtLVkB8IlvBZt7YuhrjVpP5qMf379eEhQvX5cXsf76OZLR//brHOJ7CDVFT2vZ8772TF6/e8zSY/smv7aZ2yhSM2cIjuCOtTKKlRi6yw8siPPbYXbPdVV+iHI0Na6G1uQCFsYSnTvn5O3/xD4Wp4eD3My+iS5+mu5K1mdufsnufX90SU7wlsmuxmTsrvooghu1Dm+ezyRxprsCstupfB2iLW74HacyyvHGmXMya647K5M0JlP1FeR3WrBZd/gPML3dze2AWcfR/n7v307Ue8UeXbRrRLc7MsWoz7/zFsXkh2WJLuO7VYmwUV/N/XI98twrVayk/CIbrFQsi2tdOQZugwpj+waCi9SQXeQXJV14+4+OLz7TQuyI73HruLuLrisz+F9Jq1oryu+xTW7BIW3Qh6VnqfaJbkIb65cHY/Rj5TMeEhessO04og4YSMJbnd6GzkGZ8c/QltKdmjZjq4Szg7B7RqHI5c6LPEEEFyZH5kr1+EiXrsjO5DcZsFlSEYVlvwnO5DcYsFlvTwQ+U4r2YHkBsins+AqQXZJClqxjBXQihRXccyOpruICZDs0EZyBCfZAa0lR3BrLxuQHZBIchJcvvNGdsEmgo1q4kqO4I6dl6hzmOwIocUxSXG9W1iyazzZ3v6tCMUcTXIEN34cLd6J7b+qO8VHcrnnn4UAkH5SR15WarTkCK5Hm0t2+HDi7txEm+RqSczuYmiV8kiuluhG7TpHdphSvFcm5YiUt3IlXJJbO+e+Goso553sGghuxK/xVeHtlhzBaV/JrpHgvvp7Ryf1GeGRnPY1GjbcSTLJIt0dHf2GAsnVFF20sZDs8H+T8+jyPVc2aDlTECSXt3WNCtnhUmv7Vngk10N0mVMd2eFWyiM5oss0Ns+GGasm7QjRff/5+4noiE6yw5aEt0pyRiO26KLjbmyiybez4He1rCSXR3TRx0qyw7IW2HU5oiM7pC4MaY7oMhw32QVMRFGujYxIYiRHdGQHaY7kiI7sIM0hsugyQnaQ5pqP6RXRZRw/ssMQ0ZEc0UXHGxQgOqJrMYaSnYIgucaS6zSOkp2iIDqiazGOkp2iUBza1hbjSHaKQpprNp5dx5HsFMYw0ZGctpXskFZ00pyxJDsoDpIr1bZWH0+yUxxEJ821GE+yUyAuXhNdi/Eku8YFIs2RXKfx9FBxwclPdERHdJKdIiG6kpIjOrJTKDdFR3KxJCfNkZ1iITppjujILhtn96EgOmmO6MhOwRBdKclJc2QHoislOWmO7HBDXEQnzZEdyqcEoqsvOeNIdi0L6OgrYIqjhuSMJdm1hOjyJG5pjuwwoB2tutkxyZEc2eGSFJFLcsaP7LSv/y0AosshOWmO7HBDdIqlpuSMHdnhRBEpFpIjO5RvXxUMyZEdyreviiaX5IwZ2WFgcWJu+iI5soNUR3LGiewwtlgVEMmB7EBwJEd2qNDCKqaYkjM2ZIfFRezckBzZAQRHcmQHLawUR3JkB7RPcSRHdsB2wWlVyQ4gOJIjOyCb3I5IiOTIDkVkka0YRz1CMzPFkRzZgfC2yW2F4EiO7BCA7z9/P31U0JGEN/rhZ4ID2eHdwl9ZuLPe6lghOJKry9Pj4W2jjG3e3wV5d1PmKEI78z0JDmTXQHijtuSL2JZHaYdBdgia7jIK74hsCA5kR3jT3uusJDeCA9kVkF1k6R0VzMzvSHIgu4LC+6q4d9wl3SFgggPZNRFelKJfmSoJDmTXXHgrhLCjVSY3kB3hlYXgQHakR24A2REeuQFkR3zkBrID6ZEayA4ESGogOwCIxrNTAIDsAIDsAIDsAIDsAIDsAIDsAIDsAIDsAJAdAJAdAJAdAJAdAJAdACzlH4evtXv54WE6AAAAAElFTkSuQmCC",
					gastos:"data:image/jpg;base64,iVBORw0KGgoAAAANSUhEUgAAATsAAAE+CAYAAADyEbd0AAAACXBIWXMAAC4jAAAuIwF4pT92AAAMr0lEQVR42u3dQY7bShJFUatQE+/QS/CSvITaoYfqQcNAdXVJYpKRmZEZ5wIG/gdsiaIeL1+QFHm73+8/AGB33qwCAGQHAGQHAGQHAGQHAGQHAGQHAGQHAGQHgOwAgOwAgOwAgOwAgOwAgOwAgOwAgOwAgOwAkB0AkB0AkB0AkB0AkB0AjOPdKtiHv39+PXwI8M/fHzdrCJW5eUj2voIjPoDsSkqO8EB2KCM50kNVnKAoLLperwlkxAmKjST3rKWRGoyxxtjlRXd0FHW2FmSHLdtc62sTHoyx2EJyQGWcoNhIdKP+PWCMRVfJPRPW19c40vy+e1+NEZod0ojuyGtoaQDZpZFc5JlWAM9xgiJpm7sqOZIENLvUovv5++PWKqqzYiNEaHaYwhX5RF5vB2h26N76CAgguzLtjfQAsis1rpIeEIeLihOMrr1k2fq+TlhAs0PXljdaMtoiyA5LSI+sALLT9E6K0giL3XHMLjmRN9zcTXRnGy6x18RFxQs0vYjRdZfRN/rGCcSn2WGRjfzsrZxW29h7y5r09scxu8UaXsUNfMTlOa5pNMaicCNcQXLPPseZQwB///y6a3maHYgujeiunrV+9dhJLY/sgKmii7w059VrER7ZQat7+d5nRfFsuXvdt4/wauCYXUHR9Trg//V1//3/1V+GXBX0s2d0/Hvtn78/bsRGdkjKyGNvZ55e9vnfvvr7UYJ+9dS1Z8v26L2ctNgD19kt3NZanv8adXHyK8EcObGQYZmz71wQj2N2RUbY3u955X1XEB2MsVhs3L36i4uRos0mOuOsMRZJRtieZ2CjxHPkmNqV5R0hSMLT7JC81fWWVMT7Rz0vN+qMszF6HxyzW7DVZZHo1YcHrSASLY7sYANslt6oz9Vbotoe2aGwFI9Ib4SEos8Ka3dkh2Qj7CrXovVazqjX1drIDkbYsJYXfVeR6JuTEh7ZIWmr20HMZ6V05MYB//77u/do+UUH1salJwVaXeuGG9kee/3APrLNPVrGr7+b/fx3XGBMdtigHUZf6BstvB7P1HDXE2MsNm99rSPj7McX9rjf3bNlJEDNDpvJ7Ixwnv2qosfyujQEmh2mSa+l8fX4zWu06LQ7zQ6LtL+I41kZ7zYystF9tx4JT7PD5A2+RQAtDezrn1njeKToIoVldCY7LDR+tm7cPTfwZ8+J6CWaI8+chTEWycfZI02m9bkSvW7rlGF0BdkhWSNr/VXC6N/XEh3IDt0EE9Hyeo+FV2U+Q3QuNCY7TBTc2Z8p9ZZeTxlluq28hkl2GNjervwus+Wxhz02+qPPcW19wDZhgew2HU8jfog++qE9O8iIJNfF08WSyy3qQuHV1lHk5zp7Y4PoGyJgLq6zu7gRRd+IsrXBrX4Afcb95IjOGIsJ7e3oMbRnDW+Fe6ud/WwzvjNnYMmO4Aa1irPCy9o+jhwHfPR71NGfxzV+++KY3eD2FrGxvVrGLBtm63KOeJbEmUMCRKfZEdwk2bwa+3rfV66H6GaP6kSn2ZHbYMG1bHSzzm5eXa9XfoN75TZVreuQ6MiO4DpvCK0tY+YDdXpJ9+qo/kp2qxwKANkt3d56jFSjfg0x+hkUZ+6A/Eh0I+/aArLT3jrJrqfkZ6/DkZ+J6MhOe1tIeBnEN/KBOySHLWW3S3tbraGBIMlOeyM6wgPZaW/kRnjIwfuuG3vmAJIbUEh2ldobuQHFZEdwALaWXdSGX01uzy6EdZzIDgzJZDfjOQcrB5/EgA3GWHJr/7yP2t0KN+wEyG4BwWluANk1b9yr3M+/4gXM8P2S3QCxzA4KuQFktyWrjqaO2wFkt6XcVmvIANm9aCbklvtzA2SXqJVUOe42aocBkN3GLcYYCJDd9GbiejcAWzS7r6MsuQHYdow1ml5vx2S+Zk5RTHbkBqA3bysL6efvj9u/P1qH1gFs0+xIzSUowJayIzcAy8rOQfa+o6x1CHzPm1UAgOxgvAfIDllHWWsBSCI7zQRA6WanldhhAMZY2GlYp1hRdpoJgNLNzh4UgDEWh9uxnQZAdgDILk8zAYDtm50RzCgLRFPiIdm7bfQtjfi7z65RoyK3+32+B6I3SI1mP2nvllFodv8TrqNhIjeNe3fZougYS26QI2wpO6EEcJUUx+wIDStiDF4LFxUDIDsAMMYaZWFExUK8Cyqq8mzn6kltmt3QAH4O25HWJ5yIniRkiuyEEiWEJ1dkJ4wgPCzFu1WA1Vr8rGUiPbJbZo/rbO84dhSDkxZr82ZjAuwwyQ4A4ZHdvEBpdQA0O0C7wzcsdzY2stVpiGts/DO+pyOfxwkLzQ5YHnfJJjsjAggPZCd8qCg8O2eyAwgPZAfsBuGRHVCi3YHsAOMsyA4gPJAdsCiER3ZAiXZHeGQHlBIeyA4oITztjuwAwgPZAbtBeGQHlGh3IDvAOAuyAwgPZAcsCuGRHVCi3YHsAOMsyA4gPJAdsCiER3ZAiXZHeGQHlBIeyA4oITztjuwAwgPZAbtBeGQHlGh3IDvAOAuyAwgPr3i3CpCdqhv+Cp97pdH83UYE4Mo2tIrwjLEASpQGsgNQArIDUKLdlTpm5zonoC7OxsIOCSENLvvJCmMsgBI7I7IDECa8zMfuyA5ACcgOQIl2R3YANDsA2KXdkR0AzQ4AzrY7sgNQgmyjLNkBMMYCwC6jLNkB0OwA4AqZjtuRHQDNDgCOsMJxO7IDoNkBANkBANkBwH/JckaW7ACEkP0kBdkBMMYCANkBANkBANkBANkBANkBANkByEqGC4vJDoBmBwAtZP4VBdkBKDHKkh0AYywARI6yM9sd2QHQ7AAgut2RHQCQHYBdmHXcjuwAlBhlyQ6AMRYAdhllyQ5ACd6tglx7rOxPaMKcFrNqLn7+/rhleZQi2SWr459fj/jkQi7IbrswC7hMyAXZlQz0o/cVbpmQi3M4QdEQqgzHHrIc/0Cu72PFXIxeZs1uwRDZm8vFSrnIcpJCs1t4b6nlWe9yodmlCsyjPW3Ee2h5e+Ui6vX//vl1lwmy6xroloB9/btX3le4c0vu6HcTKUCZILsuoY4I1efXOLMcwr1fJj6/jkyQ3dRQ9wrS2YAL9/6ZaF0umSC7S6GOvs/+o9fL9HMbrJsLwvvx43a/59uOHn2Jvb6sltD0PNkQ+R725HKRKRejt+nveBPoa0HpcbHxo9dsCYY2KBdyQXahge69fF/fQ7Bz52LEL20Ij+y6MSPQz8JpRM2bi5GZkIs2yh6zOxrMq4GOPGB9dllsBHIxOxcZjtk5GzsxRK2XEnw9o3b0jJwzcXKBomPs2Yszj4T0rFSO/lujy9xcnBFd1lxUE6JjdkF71+ir5WfIGv3lmC0XZCegt+gg9tiba3d5c3GlzY3MRSVBanYXwtAj0EfDapzNnYtRU4d2R3Zdx4Usy3Pmd7O+4eutbqboWnNhJ1hUdpFyECJU3S6yvT7ZdWx1o0VnL54nF5l2gFnzmnWKIrtFRj4i22NHOep9HbIgu+2l82r5bATWB9kVD/UKzclePOfObeXs9M5Qpmxqdg1fkFFSLuwENTsACG3MZAdAEyY7e0T4PkB2AOkWXlayE3xg+xGW7AQNvvMyvK/8hVZsMEKd7/vQpI9ndOa6erfhCyNQIRfGWAAlSCm72WOBsQQ7sNK9GUs3u953AT5T4WfXfD9jy7mxZs1FpRF1izHWhhwffFifFbfjt1VW1Oc/FcNvoyNFubjGkmdjW4V3NBCfLyN49qDhTJcbnFkObfm8LFZ5AHXro0ArTGXvFQKd4YsfsUGOfI7pTtl4td6O7txG7wQjs1whFy49eRKgDI+si7xAk+j6r0e5IDsjUOfXd+wmz3ctF2S3zF685Ylds25nraXlzlGGXDisodl1CXZkuFtFJ9Tjd4KjhXckY75jshsS7Ihwnwm0MWXuODtiR3hmZ2YH+P/c7ve70HaSSw9BnjmzbI+/dy7OLgvZCXbKNvVdMIU6Tyay5EImjLFDRxei2/sQx6P1nyEX0Oy6jAsj9uZEt14uMmeici7KN7uWL37k3vy73wFHn/VFv+bfMxcZxmfNrsBe/JXgrgQv8nW1OrmQC7ILC2PEWbUe12oR3dq56HWZU/VckF3A3rdXiAR6b+HtkFGyKyi8qEDNfn/IBdkJdreAjX4/yAXZITRooxBouZALsts+3AItE3JBdluHW5jlQi7IbvtwC7RcyATZbR1ugZYJmSC7bQMuzHIhF2S3bcAFWS7kguy2C7kAy4VckB0AhOHmnQDIDgDIDgDIDgDIDgDIDgDIDgDIDgDIDgDZAQDZAQDZAQDZAQDZAQDZAQDZAQDZAQDZASA7ACA7ACA7ACA7AMjCfwCK1U0e/M4tOQAAAABJRU5ErkJggg=="
				}
			}else if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.tarjetaAztecaProducto){ 
				$scope.imagenesDestinoPrestamo = {
					emergencia:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATsAAAE+CAYAAADyEbd0AAAEGWlDQ1BrQ0dDb2xvclNwYWNlR2VuZXJpY1JHQgAAOI2NVV1oHFUUPrtzZyMkzlNsNIV0qD8NJQ2TVjShtLp/3d02bpZJNtoi6GT27s6Yyc44M7v9oU9FUHwx6psUxL+3gCAo9Q/bPrQvlQol2tQgKD60+INQ6Ium65k7M5lpurHeZe58853vnnvuuWfvBei5qliWkRQBFpquLRcy4nOHj4g9K5CEh6AXBqFXUR0rXalMAjZPC3e1W99Dwntf2dXd/p+tt0YdFSBxH2Kz5qgLiI8B8KdVy3YBevqRHz/qWh72Yui3MUDEL3q44WPXw3M+fo1pZuQs4tOIBVVTaoiXEI/MxfhGDPsxsNZfoE1q66ro5aJim3XdoLFw72H+n23BaIXzbcOnz5mfPoTvYVz7KzUl5+FRxEuqkp9G/Ajia219thzg25abkRE/BpDc3pqvphHvRFys2weqvp+krbWKIX7nhDbzLOItiM8358pTwdirqpPFnMF2xLc1WvLyOwTAibpbmvHHcvttU57y5+XqNZrLe3lE/Pq8eUj2fXKfOe3pfOjzhJYtB/yll5SDFcSDiH+hRkH25+L+sdxKEAMZahrlSX8ukqMOWy/jXW2m6M9LDBc31B9LFuv6gVKg/0Szi3KAr1kGq1GMjU/aLbnq6/lRxc4XfJ98hTargX++DbMJBSiYMIe9Ck1YAxFkKEAG3xbYaKmDDgYyFK0UGYpfoWYXG+fAPPI6tJnNwb7ClP7IyF+D+bjOtCpkhz6CFrIa/I6sFtNl8auFXGMTP34sNwI/JhkgEtmDz14ySfaRcTIBInmKPE32kxyyE2Tv+thKbEVePDfW/byMM1Kmm0XdObS7oGD/MypMXFPXrCwOtoYjyyn7BV29/MZfsVzpLDdRtuIZnbpXzvlf+ev8MvYr/Gqk4H/kV/G3csdazLuyTMPsbFhzd1UabQbjFvDRmcWJxR3zcfHkVw9GfpbJmeev9F08WW8uDkaslwX6avlWGU6NRKz0g/SHtCy9J30o/ca9zX3Kfc19zn3BXQKRO8ud477hLnAfc1/G9mrzGlrfexZ5GLdn6ZZrrEohI2wVHhZywjbhUWEy8icMCGNCUdiBlq3r+xafL549HQ5jH+an+1y+LlYBifuxAvRN/lVVVOlwlCkdVm9NOL5BE4wkQ2SMlDZU97hX86EilU/lUmkQUztTE6mx1EEPh7OmdqBtAvv8HdWpbrJS6tJj3n0CWdM6busNzRV3S9KTYhqvNiqWmuroiKgYhshMjmhTh9ptWhsF7970j/SbMrsPE1suR5z7DMC+P/Hs+y7ijrQAlhyAgccjbhjPygfeBTjzhNqy28EdkUh8C+DU9+z2v/oyeH791OncxHOs5y2AtTc7nb/f73TWPkD/qwBnjX8BoJ98VQNcC+8AABYmSURBVHgB7Z3huSQnDkVn/TmoTcCxbEyOxQlsVrvGNnY1TVUJJECCM3+6qxoJ6Vxxu96MPfPjB78gAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQg4J3Av7wXSH17E/jtP//+X63DX379L7NZA8O9bgIMVDc6AjUE7kyuzInplUS47iWA2fWSI66bgNTo8gYYXibBq4bAT5pgYiHQSqDV6Frzsx4CdwR4srsjw31zAhqj4+nOXI7jEvJkd5zkNAyBMwlgdmfq7q5rntzcSbJdQZjddpLGaygbXX6N1wEVRyCA2UVQiRohAAE1AcxOjZAEEIBABAKYXQSVqBECEFATwOzUCEkAAQhEIIDZRVCJGiEAATUBzE6NkAQQgEAEAphdBJWoEQIQUBPA7NQISQABCEQggNlFUIkaIQABNQHMTo2QBBCAQAQCmF0ElagRAhBQE8Ds1AhJAAEIRCCA2UVQiRohAAE1AcxOjZAEEIBABAKYXQSVqBECEFATwOzUCEkAAQhEIIDZRVCJGiEAATUBzE6NkAQQgEAEAphdBJWoEQIQUBPA7NQISQABCEQggNlFUIkaIQABNQHMTo2QBBCAQAQCmF0ElagRAhBQE8Ds1AhJAAEIRCCA2UVQiRohAAE1AcxOjZAEEIBABAKYXQSVqBECEFATwOzUCEkAAQhEIIDZRVCJGiEAATUBzE6NkAQQgEAEAphdBJWoEQIQUBPA7NQISQABCEQggNlFUIkaIQABNYGf1RkWJ/jtP//+X1nCL7/+91/lPa4hAIGzCYQ1u5rJZSnzZ5heJsIrBCAQ8sfYbGZv8knXveXhcwhAID6BcGbXamCt6+NLSgcQgECNQCiz6zWuFNcbW4PGPQhAIB6BsL9n14M6GR6/j9dDjphTCdw9JEQ8R6Ge7CwG7k48i9zk6COAJn3cRkYlTZ50eft8ZG29ucP8JxpP4K/fMk/rrpCuMdf7vB9HQKpNrQL0qlEZc69VpyjabPdkJwXfKuiYsSIrBHwR6DkXPTErut7C7ErYLYZXxq4Q4ZQ9pbqcwsNTn+kc7H4Wwpjd20EphXpbfx20Mvb6Ge/XE2jRcn218SqwmH+LHKPJhTE7CYgSeDok0oNSxkr2Y007AakeOXPr+hzHq4xAy9xH1yLMH1Ak6aTC1ETRxMrGhlWtBN40qenYugfr6wTe2F+jSh3uYst11xwe3ocyuwTsDnQJswZeE1vm5xoCUQlIz0Hqr+Uc1dZ6YhTO7BI8qVg1+NLYtE8tPt3nFwSiEtDO/1O89/MS0uzSoD1BLwexJoI0vhZb5ucaAt4JSOc99VGbeUl8Lc4Tl7BmlyFKRNAIeBeb9+cVAt4JSM9I6qNmWNL4WqwnNuHNLsHUiKGJ9SQktUCgRkA63ym2ZlbS+FpsrZ6V97YwuwRQI4omdqV47A2BJwKauZbGpv0jGF2qcxuzS81oBNLEpr35BQEvBLSzrI33wqGsYyuzS81phZLGR/k2KwXnem8C0vlNFGozrI33THc7s8uwpaJpBK/F5v15hcBsApqZT7Vq42f327rftmanFW934VsHhfV+CUhnNXVQ+4LWxvsl81nZ1maXWpUKqRmCWuwnZq4gMIaAdL7T7rU51caP6WpM1u3NLmHTCKqJHSMZWSHwJwHtbErjayYZUYMjzC4JIxU2ra2JK42vxaac/IKAFQHpLKb9avOojbfqY3aeY8wug5UKrRmSWmzef9dXKdfe/k9kWmPVwrnGTBtfqynKvePMLgkjFVwzLLXYKEPxVqeU31sei8935lzyaeFe4yKNr8WWtUS8PtLsklAa4TWxEYdE2q+H3nY8qC38a/1r4z3oalHDsWaX4GmGQBJbGzwL0WbkkPQ3ow7NHpH5575bdKj1q43PdezwerTZZQGlA9EzTLWYvK+3VykHb3VL6omkQ+6nRY9af9L4WmyuYadXzO4vNTWD8RQbYZCe6t9p2HMvO2lS66VFz1p85rTbK2Z3UVQ6JLUBuYutrb1sueztXb0WBVn2HKVOC245h7TnGmdpbNqrFp9r2PEVsytUlQ7LdVCeYq7riq2WXD7V2lrQqt4se0g9r+rjjrekv1rNkri8Zy0+f7brK2ZXUbZlaCrhH7e8DJVVT176+YD8+4VFf156e+qlVuPT+pJTLb5cs+s1ZvegbMsQ3aVZPVzaHlbXf8f16X70nu/qr2lxt7bGpxZfW7frPczuRdmWYSpTrRwuTd2pj5W1lxw11xoOqxjc1VzWc7euxquMra3Z/R5mJ1C4Zaiu6VYNWLR6r8xGvY/E5KnWNFNPn5f8Vs1gWYeHa8xOqELLgKWUK4astcbc+opa896zXyMw6q2xZHmSrmXvtWvMrkbl5p5kCFcNmKS2sq1VtZZ1rLpuZTaLV2tdNX6zaq3t7fUeZtepTDmQq4arrEPSzqpaJbWtWNPKcAa/1poytxm15b2ivWJ20RS71Nt6IDgIF3jFW28sW+tJ7aBvIWpxidkVQKJcthwGDoFcVU9cPdUiJ+h3JWbnV5tqZRyAKhbzm544P9XCF5lcesxOzmr5yqehL4vjEJRE2q/h3c7McwRm51mdS20cvAuMiW/hPhH24K0wu8GALdJLDxxPcxa06znQoM4l0l3MzrlaHDI/AqGFHy16KsHseqhNiuFwTQLdsA2aNMBythSzcyZILkdyqPixNdOa+yrRJlWEPnN1edsNs3sjtOBzyWHiIC0QptgSnQogzi8xO2cCcYCcCfJSDnq9AHL0MWbnSAwOjiMxGkpBtwZYC5didgvhX7fmwFxpxHuPfv41w+wcaMRBcSCCQQnoaABxYIqfBuYmtREB/jDCCOTgNOg0GLAyPU92SoDa8LenAQ6QlvD8eDSdz1yyI092EkqD1rwdikHbknYwgbcvKHQfLMBNeszuBszo25KBfzs0o2sk/zgCEv3H7X5mZszOqe4YnVNhhGWhnxDUxGX8nt1E2Hmrt291DkomFf8Vrf1oiNlN1oLhnwzcwXZo7kCE30vgx1gfOlAFBCAwmABPdoMBX9PzDX+lcdZ7tF+vN0926zX4owJ+n86JEIPKQN9BYBvSYnYNsDRL377ZNbmJjU+A+RivIT/Gjmf8422Q+dafIIKTLZiFdULwZLeO/R87Y3SLBZi8PXpPBn7ZDrO7wBjx9u2bfMSe5IxLgHkZpx1mN47ta2a+5V8RbbkA3dfIitmt4c6uEIDAZAKY3WTgeTu+3TOJM1/Rf77uP8/fkh1PIWD9+08YxCmTM6ZPzG4M1yOzWptbCTHnx/RKMlxLCGB2EkqseSSQTehxkeGHeT9MzxDqAakwuwNEHtViNp1R+d/y5v0xvTdSfJ4I8AcUzEEXgWw0XcHGQZ5qMW6NdIYEMDtDmKek8mguHms6ZR6i9MmPsVGUclKnlalIfvRs3Sutl+R1gpIyJhPA7CYDP2E7K8Mp80jMD8M7YcL6euTH2D5uR0ZJzKY0KEtQI3Nb1kkunwQwO5+6uKvqzeiSEc0wI8k+b7W6g0tBUwhgdlMws4k1gRnGal0z+dYSwOzW8t9id4xnCxm3bwKz215ifYNPPxauNLqnvZ9q1hMhQ0QCmF1E1agZAhBoJoDZNSMjIBN4erLKa0a/eqhhdI/ktyGA2dlwJAsEIOCcAGbnXCDKgwAEbAhgdjYcyQIBCDgngNk5F4jyIAABGwKYnQ1HskAAAs4JYHbOBaI8CEDAhgBmZ8ORLBCAgHMCmJ1zgSgPAhCwIYDZ2XAkCwQg4JwAZudcIMqDAARsCGB2NhzJAgEIOCdg/teyR/3bJvh/LJ1PKuV1E4h6JlPDlufS9MkuMtRUe+T6u08CgVsTiD7TlvWbmZ1lUSunb5c+VjJkbx8Edpllqz5MzM6qGB8jQhUQiE9gtzNp0Y+J2cUfjc8OLMB+ZuQKAhBYTUBtdhjDagnZHwKfBDiTnzzylfmfxubE6dXyT1Kuea3eMxRWJMkThYD3M5k43p3LdF9Tv/rJ7k5kTVF3Oa3vR6jRumfyQeBUAsPM7s6dTwVN3xCAwFoCQ3+MxfDWisvuECgJRD6T2p/Ehj3ZlZC5hgAE5hDQmsKcKufvoja7HcHu2NP80WJHCPgioDY7X+1QDQQgkAjs9oVt0Y+J2VkU4mVEd+rFC1PqWENgl1m26sPE7JKUqSCrotaMxn7fhqs4sq8fApzJf7Qw/9PY6HD/QcM7COxBgDP5p45mT3Z7jAVdQAACuxLA7HZVlr4gAIEPApjdBw4uIACBXQlgdrsqS18QgMAHAczuAwcXEIDArgQwu12VpS8IQOCDAGb3gYOLFgIe/qdyDzW0MGPtOgKY3Tr27AwBCEwkgNlNhB11q6f/KHXlk9XKvaNqeXLdmN3J6hv17tF0ngzaqG3SBCOA2QUTbFW5b+aRDG+m6c3caxVz9rUlgNnZ8jw+2wwTetvjzZiPF+lQAJjdocL3tC01kWRGb4bUs/+ovD21EBOPgPnfehIPARW3EEiGJzWycp3ULK/1lDmun9Xe9+xRy8O9/QjwZLefpsM76jWUliezlrW54d66cjyvexPA7PbWd1h33ozFWz3DwJO4mwBm142OwGQwHkzGQw1Mg38C/J6df43cV5jNpvX317SN5X21eYg/gwBPdmfoPKXLZD6zDGjWPlPAsckUAjzZTcF81ibZiEY86eXcZxGlWwsCPNlZUCQHBCDgngBm514iCoQABCwIYHYWFMkBAQi4J4DZuZeIAiEAAQsCmJ0FRXI0ERjxBxdNBbD4SAKY3ZGy0zQEziOA2Z2nOR1D4EgCmN2RstM0BM4jgNmdpzkdQ+BIApjdkbLTNATOI4DZnac5HUPgSAKY3ZGy0zQEziOA2Z2nOR1D4EgCmN2RstM0BM4jgNmdpzkdQ+BIApjdkbLTNATOI4DZnac5HUPgSAKY3ZGy0zQEziOA2Z2nOR1D4EgCmN2RstM0BM4jgNmdpzkdQ+BIApjdkbLTNATOI4DZnac5HUPgSAKY3UDZ+evHB8IlNQQaCfCPZDcCkyzH5CSUWHNHIM8P/yD4HaG++zzZ9XGrRqUhzYNaXXDYTQ6rTnDmScevjObJriTSeI25NQJjeTOBPGN8eTSj+wjgye4DR9tFHsK2KFZDoI8AT3p93HIUT3aZRMMrJtcAi6XmBPL88aTXhpYnuwZefLM2wGLpcALZ9IZvtMkGmJ1QyJ7B4ptXCJdl3QT4Apajw+wErFqNLpkcRicAy5IqgZ75aZ3R6sab38TsXgRuGaKeIX3Zno8PJtA6Ty2zeiJWzO5BdenwtA7lw5Z8BIEvAmm+vm5yo5kAZneDrMXoblJwGwJmBKRfqNK5NSssUCLMrlMs6fB1picMAlUCkqc8DK+K7gdmV+fyeFcycI8J+BACCgLMXx88zK7C7emb0WrQnvaolMStzQho9beaw82wPraD2T3iGfthGnjt0I+tkOzWBCw1fzI85upbOf53sW8mt3eehus2SPBBOZij9hGUwhJjAqW2xulJ10AAs2uANWtpeUAwv1nk9fuU2ukzksGKAGZnRXJgnvIAYX4DYTemLrVpDGf5RAKYXQPsNNgejKZ2wDzU1YAy5NIa95CNHFo0ZtcofKvhXU1o5GG5y33dv7HVY5ffsRwJpEenFXWOZDA6N2bXQTgNWc9wXmNmDerdPtdaOhCED7njMrMxjQYe6p/JymIvzK6TYho2zbCWsbOHV7JfWWMnqiVhkv5mF2bF02Nvs1n27IfZ9VD7KyYNndUA1/KsHure/Wu9KDB/hPbW9JFkwsUIBlF6n4C3awvMrgvbP0F5AEcMd5kz7/XP7j7fRanTkl6plWXulOtEptYMMTsjonkYRw59LXfe16gN0ggI1HQQhHUtQd8ubNUg/p6sChaLAZt5IMoWLOovc556vUpHCw1X1e51VjC7ijIWg5bTehs4y95yj9FfvWhkrY2XvrzMB2ZXUeJu6NLw3H1WSfN1K8Lwafr7atjJDe/cNcyfZtJ737PHg9+zaySeB6hnQK8xOU/j9sOXt9R17Wd4YcUGLXUWoS4uteyi979CBMyuk3oaNs3AXmOjDm7UujslV4Vd9dYkgnk/Pcyun92PPHjaQS7jc15FaYQ6IFDqqimJmdDQ+zMWs9Mz/Nv0UiqLAS9zMOgGIg1OUWpmtR3aW5H88QOzs2P5R6Y8nJbDX8uV9zEun3QCAjU9BGFNS9C3CZdoMWYnwtS+6DqsIw7HXc7rvu1VE3ElcMf4usbyPdpZ0vzOhdl9MzG/cx3i0QfoKf+1DvMmAyZ8YjWrHTSZRZofY+eR/mun63DPPmwt+13rnA7JYMOWXg22a0oRnW1Ts44W82S3UIxy6D0dUMtayj6fkFvu+7TPzM9a+p9Z12l7YXaOFC8PxS4Hf5c+JKNSaiiJYc0cApjdHM5du9QOzknG0QVtYlBNn4nbs1UjAcyuEdjq5XcHDBMcp8wd83E7knkEAcxuBNUFOZ8OJEb4LsgTv/doVkQggNlFUElZo+Qg72yIkv6ViAkPQACzCyDSjBItDMHaMC1qmsGOPWIQwOxi6BSiSswphEzHFvnTsZ13NG795NJRAiEQ+CDATH7geLzgye4Rz/eH1+HiSeabD3fGE7jO4Pjd9tkBs1NomYcO01NAJFREIM+aaDGLqgQwuyqWtpvXQcT42tix+pnAdbaeV/LpGwH+wZ0KIasBw/gqcLn1SsBi/pi9b8yY3TeTv+9YDF1OxvBlEryWBCznLOVm1krCf15jdnUuX3cZyC8k3FAQYJ4U8DpDMbsOcAxqBzRCTP59kitGnuCuNN7fY3bvjG5XWJte3oghziRivzIfvvTD7Iz0GDXYqTzMz0ikwWmYgcGAlekxOyXAWvjIoU/7YX416nPvjdYYne31xOzsmX5knHEoOBgfyM0vZmmIjubSfSTE7D5wjL2YeWhSJzwBtuuJRu3MokRgdguVmn2wrq2eboSwv07DGe8xOyc6rzx8NQTRzdATz+gsa/MR8R5m51Q1T4dVimjkoY7EYyQHqRas+yaA2X0zcXsn0oF3C3FAYZjbAKgDUmJ2A6DOTIkBzqTNH/rMpW27G2Zny9NFNgxQLwNPa3qG3jJgdt4UGVgPJvgNF1P7ZrLrHcxuV2U7+trVDDG0jmHYMASz21DUWS2tNEcMbJbK7AMBCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCDQQeD/xPXRNLQJv1AAAAAASUVORK5CYII=",
					liquidacion:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATsAAAE+CAYAAADyEbd0AAAEGWlDQ1BrQ0dDb2xvclNwYWNlR2VuZXJpY1JHQgAAOI2NVV1oHFUUPrtzZyMkzlNsNIV0qD8NJQ2TVjShtLp/3d02bpZJNtoi6GT27s6Yyc44M7v9oU9FUHwx6psUxL+3gCAo9Q/bPrQvlQol2tQgKD60+INQ6Ium65k7M5lpurHeZe58853vnnvuuWfvBei5qliWkRQBFpquLRcy4nOHj4g9K5CEh6AXBqFXUR0rXalMAjZPC3e1W99Dwntf2dXd/p+tt0YdFSBxH2Kz5qgLiI8B8KdVy3YBevqRHz/qWh72Yui3MUDEL3q44WPXw3M+fo1pZuQs4tOIBVVTaoiXEI/MxfhGDPsxsNZfoE1q66ro5aJim3XdoLFw72H+n23BaIXzbcOnz5mfPoTvYVz7KzUl5+FRxEuqkp9G/Ajia219thzg25abkRE/BpDc3pqvphHvRFys2weqvp+krbWKIX7nhDbzLOItiM8358pTwdirqpPFnMF2xLc1WvLyOwTAibpbmvHHcvttU57y5+XqNZrLe3lE/Pq8eUj2fXKfOe3pfOjzhJYtB/yll5SDFcSDiH+hRkH25+L+sdxKEAMZahrlSX8ukqMOWy/jXW2m6M9LDBc31B9LFuv6gVKg/0Szi3KAr1kGq1GMjU/aLbnq6/lRxc4XfJ98hTargX++DbMJBSiYMIe9Ck1YAxFkKEAG3xbYaKmDDgYyFK0UGYpfoWYXG+fAPPI6tJnNwb7ClP7IyF+D+bjOtCpkhz6CFrIa/I6sFtNl8auFXGMTP34sNwI/JhkgEtmDz14ySfaRcTIBInmKPE32kxyyE2Tv+thKbEVePDfW/byMM1Kmm0XdObS7oGD/MypMXFPXrCwOtoYjyyn7BV29/MZfsVzpLDdRtuIZnbpXzvlf+ev8MvYr/Gqk4H/kV/G3csdazLuyTMPsbFhzd1UabQbjFvDRmcWJxR3zcfHkVw9GfpbJmeev9F08WW8uDkaslwX6avlWGU6NRKz0g/SHtCy9J30o/ca9zX3Kfc19zn3BXQKRO8ud477hLnAfc1/G9mrzGlrfexZ5GLdn6ZZrrEohI2wVHhZywjbhUWEy8icMCGNCUdiBlq3r+xafL549HQ5jH+an+1y+LlYBifuxAvRN/lVVVOlwlCkdVm9NOL5BE4wkQ2SMlDZU97hX86EilU/lUmkQUztTE6mx1EEPh7OmdqBtAvv8HdWpbrJS6tJj3n0CWdM6busNzRV3S9KTYhqvNiqWmuroiKgYhshMjmhTh9ptWhsF7970j/SbMrsPE1suR5z7DMC+P/Hs+y7ijrQAlhyAgccjbhjPygfeBTjzhNqy28EdkUh8C+DU9+z2v/oyeH791OncxHOs5y2AtTc7nb/f73TWPkD/qwBnjX8BoJ98VQNcC+8AABCuSURBVHgB7d3rtdy2FQZQWStFpYHUkppSSxpIV8llbCzhUhzwhQMC4PafeXAInLMBfJor2fKPH/4hQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIAAAQIECBAgQIBAXYE/6g5ntJkE/v3Pv/93pn700o/AP/71n+bZ03zCfrhVsiUg4LZUvBcl0DL0hF3UKg42rpAbbMEmK7dF6Am7yTbNlXYE3RU199QWiA48YVd7xQYbT9ANtmCTlxsZeMJu8s1Tak/QlXRce0ogKvCE3VMr+vC8gu7hBTB9USAi8P5WnNHF1wtEbLrXo74Y4MlfZH2ze+HGO7LhhNwLN0bDlp/Ygz8b9meqQQQE3SALNXCZT+wxYTfwhoko/YlNGNGHMfsX2NtrR779nelS2J3RmuCztTfQBCRaeImAsHvJQh9pc+9X2iNj+AyBMwIt95ywO7MyPkuAwLACQ/2rJy1+BGv5K82wu0bhBAYU6C7sWgRaaZ1K8wvCkpxrBPoWeDTsSsHSI9tWvQKwx5VSE4HfBZqG3VZY/F7SWO/kPQm+sdZOte8SaBJ2eSDMzJv3KfhmXmm9jSgQFnb5wR8R5m7Nef+C766m+wncFwgJu/yg3y/x+whRwRFZ8zJ2VN3fdbwiQOCTQNWwqxUYTwRDac4afaUxSvN8WiTvEyBwX6Ba2KXDfKWk3gNgq76r/S73bY13xc09BAgcF6gSdmcP/gyHfd3DGQOBd3yD+iSBWgK3/3OxM4d8CYh1SNRq5OlxzvZ2xu3p3sxPYAaBKt/s9iBmDbitvlOvwmxLx3sEnhO4/c2uVPrZbzulsUa7dqR3gTjaqqp3ZIGwsEvfcEbGqVE7hxqKxiBwXyAs7O6XZgQCBAjUEwgLOz+i/blIHOptViMRuCMQFnZLUctBf/Nhf3PvdzalewlECDT509h06N/y+1ep34gFMyYBAtcEmoRdKi0PgdmCL+8t9euRAIF+BJqGXd52Hg6jBl/eQ96b5wQI9CfwWNjlFOvQ6DX81nXmPczwfPb+ZlgjPVwX6CLs1uWXDl10EJbmXtfpNQEC4wiEhd0SShHBETFm9HJFWUTXbXwCMwmEhd2ClL6FjRhQNRY59V9jLGMQIHBPIDTsUmn5oZ89+PJeU/8eCRB4XqBJ2OVt5mEwS/DlPeW9ek6AQD8CzcMub30rJHoPwK2a8548J0CgT4FHw26LpBQmrYKwVMNWzd4jQKB/ge7CrkQmhEo6rhEgUBII/YsAShO/6Vqrb6RvMtUrgbMCYWG3HHCH/M+/+eXsovg8AQL1BcLCLpX65sB7c+9p/T0S6EWgye/Z5Yd+9t93y3vtZZHVQYDAjx9Nwi6HTmEwW+ilvvJePSdAoB+B5mGXWl+Hw2jht64/9eWRAIE+BR4LuzXHOjx6Cr91bevavSZAoH+BbsJuTbUXMLXDcG++dX1eEyAwlkBY2C1hFBkgkWPXXsJoi9r1Go/AjAJhYbdgpW9fIwVTrUVOvdcazzgECNwTCA27VFp+8GcOvrzP1LtHAgT6EGgSdnmr60AYPfzW/eS9ek6AQD8CzcNu3fpWWPQagFu1rvsZ+fXs/Y28NjPX3uq8Px52W4u4d+iicPbm3arVewQIjCHQZdjt0Y0WSlHhvOfkOgECvwTC/yKAX1N5RoAAgecEwsJu+TbjG42/4um5rW1mAt8Fwn+MTYE32o+e35nOv0p9n7/THQQIRAiEh10qOh3+2UMv9Zn69kiAQB8CzcIutZuHwSzBl/eU+vRIgEBfAs3DLm8/D4mRgi+vO+/HcwIE+hV4NOxylq0A6SEAt+rK6/acAIExBLoJuy2uo0FzNRSPjr9VW433rtZdY25jEHibQFjYLQe5VZi0mufK5mjpcKU+9xB4i0BY2C2A+TeXngMpYrHz3iPGNyYBAucEQsMuLyU//LMGX95j3rvnBAg8L9As7PJW16Ewavit+8h79JwAgb4EHgm7NcFWaPQUgFv1rXvwmgCBvgW6CLstoqMBczcUj86zVePd9+7WXpr/yb5KdblG4CmBbsPuKEhvhzoywI6aLJ/rpY4zNfssgUiBsLBbDltvQRQBKVQiVI1JoL7AH3eGPHLQZwu8Iz3fMe3h3tnWrAdTNXwWKJ2pmnsx7Jtdai01UrPoNHarx9RDq/menif1O/KaPW1o/v4EwsMutTziAUo1px7e9pj3L/jetvrz9dss7BLdKAcorzPVXuOxRWhE1J7GbFF/DWdjEFgLhP+e3XrC0useDlI61KU696710MdWjTV6W8bttb+tnr3Xv0BpX9bca12F3adlqdnwpzmW90vopfta1Veq4eq1N/Z81cp9MQKlPVjzbIWE3VJgqYEYsraj1lyEtpV/nu3sms1o8FnHlSiB0r6rucdCwm5BSUWWGonCixo39RQ1fk/jHl23N5n0tD4z1VLaazX3V/gfUOTFlprqefHyHnqus2ZtqedR16ymhbHmEAgPu5wpHaDlvVEOUV5z3stbni/9l9ZquZaMSp8b0Sv1NWLtav5doGnY5dOvN1KPB2VdY17/m54vDj2uz5vWQK/3BULC7kpIfLrHIbu/yEYgQODHj5CwWwLqU3idRa81TmneT4Ga3m9RQ6m+p68lh6frMD+BOwI/79z8lnvffNjf3Ptb9vdb+gwLu9kOydLPbD2VNvnb+i1ZuDaHQMiPsYkmhcNMPwamnpYeZ+pr6SfvbXld859erSJ7rulnrPsCoWGXyls2VK+bPdV45TE/KKP2l/dwxcA9BEYRaBJ2C0Z+qEYNhtKi5v2lz/XW51aNqVaPBGYXaBZ2OWR+6HoLhLzOu8/zPtdjRfVdmnNdg9cE3iTwSNjlwOvDGRUC+ZxHny+1rOs7eu/e56LG3Zv36vVIi6s1uY/AGYHHw25d7KcQeCoE07yf6lrXP9Pr1PtMPenlvQIhYRfxLeDpsMkP/tO1RG/XvNfouYxPoJVASNgtxecHZrZwyHtbeh29v3U/S0/+ITCbQFjY5VDpMI0eCnlP+fPUX/5ez71u1ZvXHvG8Z4+Ifo3Zn0CTsEtt54ds9s2f95r6T4/RvZfmTjV4JPA2gaZhl+NuHcjoEMjnf/L5Vu9P1nNk7reszRELnxlT4LGw2+IqhYDDtiXmPQIEjgp0FXaloktBWLrvyLVPQZrej5z7SH1PfyY5PF2H+QncEQj5W09mOxxLP7P1dGTTvLXvIzY+M57AMN/seqBNgTf7N73UZw/mT9Uw+xo/5frkvLf+V4pL4XsHY4RNs9dDaYFG6K9Uf7rGIEl4bC1Q2ns1z1f4N7ulkZoFt16IvfnyhRqtz7z2vT5dJzC6QHjYLUD5oRotEM4scN5nuq+XfrdqSzV6JPAGgdthtxzmMwcp/2wvQRC50Hm/W/PUMtibZ2tu7xF4k8DtsFuw0oE9e+DWn0/j9LIASz3rGmvXFj1+jXrTuoxQa41+jTGnQJWwSzR3w+HTYUqHLc3T8jGf+1N9LetpOVfee8t5zUUgQqBq2C0FpgNSMxhqjnUHMfW2jNFLTXf62bo373HruvcIjCpQPewSxHJoZg2Epcd1KIza67qPtH4eCcwmEBZ2C1R+kEYNg6MLnvea7umt560aU60eCTwh0PKMhIZdjpcftJYN5jW0fp73/GnumhZH5vtUh/cJtBbY2/u193OzsMsht5rYazy/f6bnWxY99vfW9elxLdR0TeCRsNsqtXTonzpoy7ylurb68B4BAmWBp87z7f82ttzWGFf38N8ceHs2ywq/2WeMHf58lUf2UV5lxJ4Sdl/CRxciYgHyBe7t+VGX3upWz9gCUeesmx9jR1iedPijFqMXg9RnL/Wog0ANAd/svhTvHO5Zgu+OQY2NaAwCi0DkeRJ2X8A1D3rkYtU8DjV7rlmXsd4p0OLcCLuvvRV98FssZOmIRPdXmts1AnsCrc6HsPtaiZ7C4OjC91Tz3mZ2ncCWwNG9vnXvlfeE3Zfap+BIi/Hp+hXwEe/Zc0jXR+xNze8R8KexB9Y6HeY3hV7q+QCPjxAYQkDYnVimPABmDL68vxMsPkpgCAFhd3GZtoJhtADc6uEih9sIdC8g7Cou0VZ49BKAW7VVbN1QBLoXEHbBS3QmZM4G45mxg9s0PIHuBYRdR0vUc3idDeKOWJVC4P8CPzkQIEDgDQL+PbuvVS59a+n521aLDVqyWeZ/u0+LNTBHHQE/xu44psP+tkOd+t7hcZnAMAK+2f21VEcP9+yhd9RhYZvdYphTrNBDAr7ZHWL69aE8DGY67Hlfv7r1jMA8Ar7ZZWt598CPFH5v6jVbYk9fLCDsNhb/bhDkQ/YQgLP1k/t6TuCogLD7IFUzID5M8e3tq6HYss6rNX5r1AsCDwkIux34lmGyU8pjl4XcY/Qmrigg7A5ivi30BNzBjeFjwwgIu4tLNWP4CbiLm8FtQwgIu0rLNGL4CbdKi2+YIQSEXeAy9RSAgi1woQ09hICw62CZ7oaiIOtgEZVAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQIECBAgAABAgQITCDwPx1vW7HE6bzgAAAAAElFTkSuQmCC",
					remodelacion:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAToAAAE8CAYAAABQG31BAAAEGWlDQ1BrQ0dDb2xvclNwYWNlR2VuZXJpY1JHQgAAOI2NVV1oHFUUPrtzZyMkzlNsNIV0qD8NJQ2TVjShtLp/3d02bpZJNtoi6GT27s6Yyc44M7v9oU9FUHwx6psUxL+3gCAo9Q/bPrQvlQol2tQgKD60+INQ6Ium65k7M5lpurHeZe58853vnnvuuWfvBei5qliWkRQBFpquLRcy4nOHj4g9K5CEh6AXBqFXUR0rXalMAjZPC3e1W99Dwntf2dXd/p+tt0YdFSBxH2Kz5qgLiI8B8KdVy3YBevqRHz/qWh72Yui3MUDEL3q44WPXw3M+fo1pZuQs4tOIBVVTaoiXEI/MxfhGDPsxsNZfoE1q66ro5aJim3XdoLFw72H+n23BaIXzbcOnz5mfPoTvYVz7KzUl5+FRxEuqkp9G/Ajia219thzg25abkRE/BpDc3pqvphHvRFys2weqvp+krbWKIX7nhDbzLOItiM8358pTwdirqpPFnMF2xLc1WvLyOwTAibpbmvHHcvttU57y5+XqNZrLe3lE/Pq8eUj2fXKfOe3pfOjzhJYtB/yll5SDFcSDiH+hRkH25+L+sdxKEAMZahrlSX8ukqMOWy/jXW2m6M9LDBc31B9LFuv6gVKg/0Szi3KAr1kGq1GMjU/aLbnq6/lRxc4XfJ98hTargX++DbMJBSiYMIe9Ck1YAxFkKEAG3xbYaKmDDgYyFK0UGYpfoWYXG+fAPPI6tJnNwb7ClP7IyF+D+bjOtCpkhz6CFrIa/I6sFtNl8auFXGMTP34sNwI/JhkgEtmDz14ySfaRcTIBInmKPE32kxyyE2Tv+thKbEVePDfW/byMM1Kmm0XdObS7oGD/MypMXFPXrCwOtoYjyyn7BV29/MZfsVzpLDdRtuIZnbpXzvlf+ev8MvYr/Gqk4H/kV/G3csdazLuyTMPsbFhzd1UabQbjFvDRmcWJxR3zcfHkVw9GfpbJmeev9F08WW8uDkaslwX6avlWGU6NRKz0g/SHtCy9J30o/ca9zX3Kfc19zn3BXQKRO8ud477hLnAfc1/G9mrzGlrfexZ5GLdn6ZZrrEohI2wVHhZywjbhUWEy8icMCGNCUdiBlq3r+xafL549HQ5jH+an+1y+LlYBifuxAvRN/lVVVOlwlCkdVm9NOL5BE4wkQ2SMlDZU97hX86EilU/lUmkQUztTE6mx1EEPh7OmdqBtAvv8HdWpbrJS6tJj3n0CWdM6busNzRV3S9KTYhqvNiqWmuroiKgYhshMjmhTh9ptWhsF7970j/SbMrsPE1suR5z7DMC+P/Hs+y7ijrQAlhyAgccjbhjPygfeBTjzhNqy28EdkUh8C+DU9+z2v/oyeH791OncxHOs5y2AtTc7nb/f73TWPkD/qwBnjX8BoJ98VQNcC+8AAB42SURBVHgB7Z0NtiCpbUbHc7yobCBryZqylmwgu0oG27h5dCGQSoCgrs/xqSp+9HMlvuH167H/+IP/QAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIHAegb+dFzIRQ+BeAv/zX//xf0/Z/ed//y9n9QnM4BjwBkGxDAIzCLSErecL4esR+jmP0P3kwRcElhCwClwdHIJXE3n+RuieuTAKgSkEvASuDA6xK2k8vyN0z1wYhYA7gRkiVwaJ4JU0fr4jdD958AUBdwKzBa4MGLErafx6//uvV94gAAFPAisFzjPuG21xo7uxquS0lYC3wOVb2qjdvH4rhGDOEbpgBSGccwmMCpEmwyfRGvHztE/j97a1f96WEPlAYDWBJDwj4uMVFyKmJ8mNTs+MHRD4B4HZ4tYTtJ7/3v4vlRGh+1K1ydWFQE9gPJyMipQUy6gNj3ij20DooleI+MIQkETFM0itQElxaW218kg+vGy1fMwcR+hm0sX2FQQkIfFO0CImvfgsNnNete03trLNHU+Ebgd1fB5DoD7oswJ/KyBSnBbb3vZmcRu1y29dR0mx7lME0kGXDvsTDIugJDvWfU8xPI1p8rDk/eQz2hg3umgVIZ6tBDSikAPNQqXZm/dkGx5PyX/Pn7T3Kbaevac9O8f4V8B20sd3GALag54DTwdes3eXQKQYn3xrYs85n/jkRndi1YjZjYD1oGfRGN2f17sF3jAkxVPGIK1rmP5tuLT322SwAW50wQpCOGsIWA+65XBb9sygkHJOsVhznxHTKpvc6FaRxk8IAtZD3hKrnr3WvpkwejF5+t6RnyV+bnQWauw5joD18EsHuWdT2nsCwBx/L88TcuFGd0KViNFMwHpI8yGXHEu2R/ZLtt/OSbH1bD/FLtl7Wt/zsXqeG91q4vhbQkA6mFIAJxxaKf43c9bcE2vr3jfxavZyo9PQYu0RBCwiZz2oLV9We56AW7HVPkZjleyN2qh9r/pG6FaRxs90AtJBbDl/e0Aln29tt2LWjHvGJ9lKMUXIt8WGfwWsRYbxYwikA9g7hE/JRD6YT/HuHjuZF0K3u3vwbybwRuBOPrQaYFKeln84SL697Um+tHMInZYY67cTiCRwK4VkO/i/ApDyjRBfKwaErkWG8XAEIglcODhCQJI4ed/CvO0JaammEDoVLhbvIBBd4FYKyQ7+tU8p33ptlG+ELkoliOM3AtEF7reAAw9I4uR9C/O254GVvzDsQREbrgSsB6U+zCN26j3WRJKdEX9W+9H2nZYvf48uWgd9OB6rUNRi5WVHW4qW3zo+rV3P9a0Ykw9tnJItiz3PPGtb/OhaE+F7C4HeoXkKKh3M8nAmGxY72fabvdnGl54l++h5I3TRK3R5fBZxqgUuIfISKS87Uct2kjh5MkToPGlia5iAReCS8aeD6i1O3vaGoRy48KkeOY1IHPllRK4KzyUErM0vHaglgePkaAII3dHlOyf4WQI3YvdJJHv70vzTvnOIr4s0cerxXBfNsyeE7pkLo04ErAfAQ2QkG3nOGl+Nx8tObZdvHwL8GZ0PR6xUBNLBtxz+JEBZhCqTqs9RG9K60fhH16kSuGRxFDbc6C5pqChpWBtbEpyduaV8pNh6+Up7d+b1Nd/c6L5W8Un5pgPfO/RPrpMQzBADTSw9/0+2rPk+MbhhrMdwd47c6HZX4AL/T0LQSyv6wajjvyVHSx41ixO/udGdWLUgMVtuNUngVomc5lB7x+RtL0jJjw2Df9f12NLtC1wjIDlK6eD37El7k/23+3OMI7bKta33XrytfbPHJU4eMbfse9h+y4YfXd8S/ND+ViP3ELQafdReXtey0/Of9lv39mzX86v81H5735lhb92t89zobq2sY17WQ9I69FZ7KaU3Nlt7n1BpY9TYfvI3c6yXi1fsLT9e9t8wQuje0Lt8b6txe2lLjW21Wfps2e/Zbu0rbdfvM2zWPmZ+9+JPvi1c6pglPx72a3/ab4ROS+wD66WmldLvNbTVbu1T8tPzIe2t/Zz83eOQc/PiIfnz8pFjtjwROgu1S/dIzSqlPNLIVtstv5LPni9pb8vfKeO93Ms8PDm0/Hr6KGPXviN0WmIXrm81aS9VTROP+Kjt9fbU68t43+wt7Zzy3su3zkNiV6/tfUu+Pf304pDm+a2rROfyOalBpdS1zdvz07KXxnt7pTi/MGfh0+J9My/+wvDN1RVysx4Q70PibS+n3LNryT/bjvBM8Vty6HHR5ibF4O1LG1u5nhtdSeMD71JjttLf2bDJtyXmlMubvS0Wu8ffsPCO3RqLdxwj9hC6EUoXrLE25VuRk/x62H5jI8X2Zv/KtpA4SnHMys8ajxTrzDmEbibdALatDTnrgKxGkvKwMlgd65M/a+wz6zcS00z/T5x6Ywhdj9Ch8yPN+JTaqgZd5SflmHy1eKTxlbE8MX8aa8X7tLYcm53LSFyzYyjzHX1H6EZJHbJupBGfUmk155O91tonu4zpCTwx71lZUZORuFbE0WPxNI/QPVE5cGykCZ/SemrMnq08/7S39JHXlWO73lOsrXjSeC+XFXG34pN8r4jbEpcU8445hG4HdUef1iZsHRCNvbS2ZccxxetNaZiXMFaw18S2Ip4yf807QqehFWitpgHLsKVmtNhMe2qbPTv1+jK+me/Jby+2mf5r29ZYVvDTxLYinpqd9huh0xILsF7ThDncXjNabGbbb/ZmG7ufKYceI68YrbwixrcqprfsEbq3BBfutxyQkUa02LWmPRKP1Xb0fVbOK5lpYlwZ19vaInRvCS7Yr2m+HM5JTZhjXvFMXCw838Rm9beyhpoYV8b1hnu5F6EraQR71zRfGbpnI5a2rPHk2Epbeezmp5XXak6aOFfH5tUfCJ0XSUc7msYr3Xo3YW0vfUeJrcxb826Nf4WPmrfGp2WthsXq2Cz5SHsQOonO4jlN45WhrWzC7Gs01ry+jFf7nmyM+tPa9lxvjdGDkTYPTaw74tPm01uP0PUILZjXNF0Zzs4G3Om7ZKB5t3Ie8WGxvYuhJtZdMY4w16zhf2FYQ8t5rabhStfezSfF4e2rzEPz/iZGaW+OwZrniO3sIz+tvvJ+61MT664Yrbn19nGj6xGaMK9puNL9bc1X5vbmPfMs+eSxN3alvVb7ZYySfe85Tby7YvTOubTHja6kMfld02xlKLMbT4prtu8yz967FGdvrzSvydEag8aHFKtlThPzzjgtuY3u4UY3SurlOk2zZVe7m263/8xh5nM0R0v9Utyj9mfkqIl5Z5wzcq9tInQ1EedvTbNl17c3Xc5T+0xcLDxbfkY4W/2N2G7F5TGuiXt3rB759mzwo2uPkHFe02jZhabhWvY1NpLflp00p7WV9qz4jxTzqP9eblYfPbuj8VnXaeLeHas1R8s+hM5CTdijabTSzGjTjdofsdezNWKjzGHley/2Viy9nGbZbcXjOa6JvcfBM64IthA6pypomqx0OdpwFvs925LN3t4yh93vHnlINqT8onDSxB8lZomr9xxC95KopsFKV5pms/rI/mpfI/bqPdnWjc8RHnXeUfhoYo8Sc81yxTdCZ6SsabDShbbZrH5Kn9p3bYxa+1HWW9hGYqOJP1LcO+rPb12V1DXNVZr+eqOVLHa/31BDTQ703h9/IHSKU6dprmx2dpNl+5bYcozlM9srx255tzKKxESTQ6S4d/cQP7oOVkDTYMmkR5P1fNY+eut7qdb2eutPmbdyicZDk0e02Hf3CkI3UIFdDSb5bTWytEdKtWVP2hN97hYWmjxurKNHnyF0HYqjTTajwVq+R3y19tbpjtiq90T/Hs29ziMiC00uEeOvGe/65s/oBPKjTRaxwcqY6jzKOSH946bqPEcTiMpDk0/UHEZrMHsdQveC8CnNdUqc1lJoBKH0EZWLJp+oOZScI7wjdI0q9JqtbrDW+npdwx3DBgIt5j1TkWuiySlyHr0arJ5H6AzEywbrNWaeL/cYXLKlIpC5VsPiZ+QaaPOJnItYhE2T/DLiAbzUdGWDSesezKr/yolkv4zjydetYxKTVs7RWWlyip5Lqwa7x//cHcCX/Gsa+ktcRnJN7Cz8oguDJqfouYzUcdcabnQP5FvNVzZaa82DuR9DpY0fE40PyY/WVsNF6GEpfynw6Gw0eUXPRapDlDludIsroWnwXmietnq+Vs+n3Cz5JVGILgyavKLnsrovrP74ZYSV3KJ9qdE1B2NRWNPcWHM9RRA0+Z2S07RmcDSM0DnCTKbK5mw1dRov1zmHcKS5FqteMqdw1OR3Sk692kSa50fXSNVoxCI1vuYANcxvHU7xW3JITCQuW5OqnGvyOyWnKsXwn9zoDCUabdzUtK21afzLTd3i0ivHScw0OZ6UV69GEecRuohVUcR04gHRCEBGcVqemhxPyy3X5KQnQqesltTAsxpW8qkMf+tySx6zmM4EocnzxPxmsptlm79H90BW06jl9lbTSvZae5JdaV/2K+3Pa3Y/R/KoYzwhrzpmTZ4n5lfne9I3v4xwqpa1cVuHozVehmv1WdqY+Z5yGMmjjiF6XnW86VuT54n5PeV80hg/uj5UKzWipnEfTKiGVvpSBWZcbM3nVAHQ5HtqjsZWCLONH10bpfBuXo29Rkg/hiMeGGuOEXP5Abvxocn31BwbqR83jNAJJRtp5NEGHrElhPJjatTnj00TP6y5RctDg0iT88l5aphEXovQCdXpNbO2gXv2hFD+PaX1+e+NE16s+UTKQYtFk/PJeWq5RF+P0HUqJDW2tZElm61wrL5a9t6MW+JP/iLlYMlfk/fpuVr4RN7DLyM2VCcfgt7Byes2hPjoshfv46a/BqPl0YpTGtfkfkO+EosT57jRDVRNavKvNLXEoIXwBjaavG/It1XL08cRuoEK9pr95gbv5f6E7xYemtxvyfmpnjeMIXSDVZSa/sYml/KVkN3AQpv7DTlLNb1hDqEbrGKv+W9p9l6eLVxfzP+WnFs1vWkcoVNUUxKB05teyk1CdHreZW4aBjflXTK49R2hU1S2dxBObP5eTi08J+bayiWNj3K4LW+JyU1zCJ2ymtKBOOkQSHlISE7KUcqjnBtlcWPuJYeb3/l7dI7VTQcm+mEYPdQ1luh51fF6fn85d0+OO21xozPQl8Qi6qGQYpYQRM1Hilkz1+Nye/4aVievReiM1ZMOSKTDIcUppR4pBynOt3MSn68weMvwhP386HpClYwxSoe4ZfJLh1vi8yUOrV64aZwb3YtqRj0oUlytdL94sCVOX+TR6o0bxrnR3VDFf+UgHVwpTQ71Tzrw+Mnjhi9udC+rKInLqgMjxSCltyo+KYadcy1uX+eysyazfHOjm0V2gd3WQe255iCP/wXhHkvmzyDAjc6hTpLgzBAVyZ+UzoxYJH+R5ySGcIpcOVts3Ohs3IZ3pQPldXCkwykF5OVf8nHLHKxuqeTPPLjR/eRh/uqJ0JsD1LPdCvqNz5bNW8ZbTGF2S4V/5sGN7iePaV/pYGkPUesw9oLU+unZYx4CpxPgRudYwVFh6gnRqJ069J7dev2XvyXGcLyvMxA655pKB+jJVT5U2n2lrWyjHONdJiDxhqfM7sRZhG5C1aRD5OmOA/mOZqtOcH3HNeLuPyMGdXpMKw7KCh+n14H4IZAJcKPLJCY8WzeGN64QuDf0fu6V6gPnn6xO/+JGN7GCnocl2fK0NzFtTEMgHAFudItKIt0epBAQN4nO+zmpLrB/zzeKBf4e3aJK1IemdcDqdYvCww0EribAje7q8pLcCIHWP3TSXv7BM0Iw/hr+jC5+jYgQAhB4SQChewmQ7XcTkG57d2d+V3YI3V31JBsDAX48NUA7bAtCd1jBCHc9AW5165l7e0TovIli70gC3OqOLNtw0PzWdRgVC79AQLq9IYbndgB/j86hdtLhcDA/ZIJDOISJRR8lwI1OKHwEARPCM00hiH1sUt3h1+cXcQU3ur+qIjV2xKK9iUnKlUNsIysxrS3CuCay5vtTNzpNQ67BH9/LVw/mql75Kt/VnX+10K1q1tVF2+nvKwdzde98heuu3r1O6FY36K7CRfF78wHd0Us389zZs1cI3Y6GfCrajiaNknvisSP/pzp4je1kextLr5pY7RwrdCub8Iamg5fuiKzk1Yrshr5r5bZ6/Dihm9mA1saaGVOvIawxl3Znxu8RXxnrincrDynXGTZXsLjFxzFCZ22Up0JJDZnXe/rLNnc/R/LOMXrmr/Gb/e96avO25qbxY/Wxi2FEv+GFTtMQLcCtRvGw3fJ52niLUc7Dg1XPR/a16zmao2ceO3zu4rvTb2ihG22CJ4B1M76x9WT/C2M1wzJnK0/JZml/9ftoPrPiH/E/y/dq1jv8hRW6kcLXwMpGsOyv7fH9k0DJt5yxsG7ZKu2ueh+Jf0W8UeJYxX2ln5BCN1LwDKlsQM2+vJ+njUDJPVvQ8n+ykW2teo7EvDLOXjwrY1lVgxV+wgldr9AZSlnw0T1578xnGdcsP9HzHY1vBateDXqx7ogxYkw9jtHnQwldr8AJZt14I3veFKH298bWzr0zObUYjfhs7V3Bqhcfsa2owhofRwld3Xi9Rh1BWNsc2XPbmpkce7Z38pdi2xlX7q/o8eU4T3ge8z/T5NV4XnZOKO5ojDUT6YCN2szrkm3JXpqr/ee9M59STDP9etnexc0r/tV2jrjRPR2E0UZ92rsa8un+PFhLNnbUKFo8rR45Jc5W/FHGw/yf40gFtcBKh2fHAbLEGn3PbSylXjupZ6Q8ovfU6vjCCJ134qkJaAQfqm9ZUgd7HU4SXnuW83eG+dG1dxieCt7b84Tvyc7Tui+PeXOV7O2oR7R4RnrtxJhH8lq15phfRqRCexyKp4bxsLuqYN5+nnh4+pht3zPWL/eBJ8eIto650ZXwyoacfZBKX2UMJ73vYDTqczVfKa7VsWh76OTYtbl6rz/mRlcmngueGjP9N3+Xa7zerbZnHRprPF48ajt1ntHiq+Pl+5sEjrzR1aXKh41DVpOZ952ZZw9W9rWdbG/WsxXn6jis+bXiT/ZOycGa+5t9R97o6oTL4udil2P1er5tBDLbvBvGmQTP6ASuELoScnn4yoNZjpfreW8TKPnlVXDMJPY8U01aNUjjTzXbE2ksr+GFTipsD2XdEHUT1PM9ezfP12zKXOFU0oj9jtg91ye80KWw8yF8e+Dq/dnuE5p67dOa08akfHMuM/JOfmfYzTF/7QlPfcWPELqcVj6oXoemZSf5yb6y796zZau37828NsbS14p438RXxsq7jkCqLex/MjtK6HLouYizDqtkN/vOseRnazzP73hKecyKJyKHkVxPE4fEeUd9R1hGXHOk0GWQ5aFaVXSrnzLWHP/I0+pvxLbnGmt+njFg6xeB1DfU5BePo4XuVxq//hwvjUUUh4gxlfy076ceohT3LbW4KRdt/2nXXyN0ZeL1Ibylscscd7zXXHfEgM9xAqnvqdk/eV0pdHUr1MVG+GpCv3/XzH5fcd/IicKQ6kQ/93vxE0JXY2gd4i82TItFzYzvMwmcKN4zSH9S6FogpUN/sghKebVY3DyeeLTqeaIwSPncXEdNbgjdIC2LWLQO06DL35ZZYvjNCANXEpDE7kTx9i4SQudNtLCHMBUwDnpFGA4q1mCo1/5/Rgzmz7KPErjxH0JSTt4/XZzWNgjdaRUj3iUEvi4MSyAvdILQLYSNq1gEpBtQrEjHo5Fy+rJ4I3TjPcTKjxH4sjDcVmqE7raKko+KgHQDUhkKtFjK6avijdAFalBC2UMAYdjDfaVXhG4lbXxBYBEBxPsnaITuJw++Pkrga8LwtR9hEbqPHmzSvp+AJN73Z/8zQ4TuJw++PkxAEoYbb0A35tRqX4SuRYZxCFxAQBLvC9IbTgGhG0bFwi8QkIThxhvQjTk99SlC90SFMQhcREAS74vSFFNB6EQ8TH6RgCQMN96Absyp7luEribCNwQ6BE4UBkm8O+leMY3QXVFGkvAmcKMwSDmdKN6amiN0GlqshcC/CNwuDLcVGqG7raLk40ZAugG5OVlsSMrpZvFG6BY3Gu7uIXCzMNxTpX9mgtDdVlHycSUg3YBcHS00JuV0q3gjdAsbDFf3EbhVGG6rFEJ3W0XJx52AdANyd7bIoJTTjeKN0C1qLNzcS+BGYbitWgjdbRUlnykEpBvQFIcLjEo53SbeCN2ChsLFHQS+JAypYjeJHUJ3xxkkCwiYCEjibTIYdBNCF7QwhBWTgCQMN92AMv1bckLockV5QuCjBCTxvgUJQndLJcljGQFJGG65AZUwb8gJoSsryjsEPkpAEu8bkCB0N1SRHJYTkIThhhtQDfT0nBC6uqJ8Q+CjBCTxPh0JQnd6BYl/GwFJGE6/AT1BPTknhO6pooxBwIHAicIgibcDkm0mELpt6HF8A4EbhUHK6UTxTn2G0N1w2sghLIFThSEsUGNgCJ0RHNsgkAlIN6C85rSnlNOJ4o3QndaBxHscgROF4TjInYARug4gpiEwQkC6AY3sj7hGyuk08UboInYYMV1H4DRhuK0ACN1tFSWfbQSkG9C2oF46lnI6SbwRupeNwHYIjBI4SRhGczplHUJ3SqWI8wgC0g3oiAQegpRyOkW8EbqHwjIEgTcEbhAGTf4niB1Cp6koayHwUQKSeJ+ABKE7oUrEeBwBSRhOuAFpgUfPCaHTVpT1EPgoAUm8oyNB6KJXiPiOJSAJQ/QbkAV65JwQOktF2QOBjxKQxDsyEoQucnWI7XgCkjBEvgFZwUfNCaGzVpR9EHAgEFUYpNQk8Zb27ZxD6HbSx/cnCJwoDG8KE1G8Ebo3FWUvBBwIRBSGXlqniTdC16so8xBwIHCaMLxNOZp4I3RvK8p+CDgQiCYMvZROixeh61WUeQg4EbjhVpcEblTkRtc54RXNIHQiHiYhsI5AJGGos9YIXN4bSdgRulwVnhBYQCDS4R9J1yJwyW60PP8+kixrIACBNQSSsEQQCevtMkLsT5VC6J6oMAaBiQSSGFiFZGJY/zBtjSuqwGVeCF0mwRMCQQjsuNXdKnC5pAhdJsETAgsJRLnV3S5wuaT8MiKT4AmBxQSkH/esAqRJweIjxSzFrfG/ci03upW08QWBAASsAhcgdHMI3OjM6NgIgfcEpNuRRZCkiJI9i00pRslfpDludJGqQSwQmEDAIm4pjBsELuPkRpdJ8ITAJgKSoFhFKqXy5gYnxbQJ0yu33Ohe4WMzBOIRsIrjbeJWVoYbXUmDdwhsIiCJzKhwcYNrF48bXZsNMxAIQyCJWEsMR4WwTqZlr153wzdCd0MVyeEKAkl4NKKlWVsC+pLA5bwRukyCJwSCE8i3OgROXyj+jE7PjB0QmEagd9uyiFyy2bM7LaEghrnRBSkEYUDAm8DXxa3kyY2upME7BAIQ8BAoDxsBULiFwI3ODSWGILCfAAL3XANudM9cGIXAVgJawUrrtXu2JrjYOTe6xcBxBwFPAojbGE1udGOcWAWB5QQkEeMGpysHNzodL1ZDYCsBSfy2BhbceXihy39JMjhHwoPAFAIImw9WfnT14YgVgYDlL7kK5piCgJrAEULHQVHXNcwGahemFJ8O5G+Rsh85FFzlI1VMjqVXT2op82PWj8ARN7oy3d7hKdfyvo8AddrHHs+/Ewh1o0vhaQ4IN4LfC7p7ZLR+1G53pb7lP5zQJfyjh6UsFQenpLH2nXqt5Y03PYGQQpfSsByenD6il0nMe1KfeWyx7E8grNClVN8cpowK0csk3j2pxTt+7N5LILTQZTQehyzbQvgyifbTk3f2AvdMgucOAkcIXQYz4wBm2189iDOZJrZf5Zr7imcMAkcJXUY2+3BmP/l58mFdzeoGZjkHnvcQOFLoSvy7DnIZQ35fJYiRcs65p+eq/EufvENghMDxQlcmGVUAyhhve0fcbqvonflcJXRliRC9kobfO8LmxxJL6whcK3Q1QoSvJtL/RtT6jFhxBoHPCF2rHAggf7bW6g3G7yHweaGTSnmTCHI7kyrN3O0EEDqnCu8QRcTLqXiYgQAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQisJ/D/jvUZ9DuR3UYAAAAASUVORK5CYII=",
					evento:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATsAAAE+CAYAAADyEbd0AAAEGWlDQ1BrQ0dDb2xvclNwYWNlR2VuZXJpY1JHQgAAOI2NVV1oHFUUPrtzZyMkzlNsNIV0qD8NJQ2TVjShtLp/3d02bpZJNtoi6GT27s6Yyc44M7v9oU9FUHwx6psUxL+3gCAo9Q/bPrQvlQol2tQgKD60+INQ6Ium65k7M5lpurHeZe58853vnnvuuWfvBei5qliWkRQBFpquLRcy4nOHj4g9K5CEh6AXBqFXUR0rXalMAjZPC3e1W99Dwntf2dXd/p+tt0YdFSBxH2Kz5qgLiI8B8KdVy3YBevqRHz/qWh72Yui3MUDEL3q44WPXw3M+fo1pZuQs4tOIBVVTaoiXEI/MxfhGDPsxsNZfoE1q66ro5aJim3XdoLFw72H+n23BaIXzbcOnz5mfPoTvYVz7KzUl5+FRxEuqkp9G/Ajia219thzg25abkRE/BpDc3pqvphHvRFys2weqvp+krbWKIX7nhDbzLOItiM8358pTwdirqpPFnMF2xLc1WvLyOwTAibpbmvHHcvttU57y5+XqNZrLe3lE/Pq8eUj2fXKfOe3pfOjzhJYtB/yll5SDFcSDiH+hRkH25+L+sdxKEAMZahrlSX8ukqMOWy/jXW2m6M9LDBc31B9LFuv6gVKg/0Szi3KAr1kGq1GMjU/aLbnq6/lRxc4XfJ98hTargX++DbMJBSiYMIe9Ck1YAxFkKEAG3xbYaKmDDgYyFK0UGYpfoWYXG+fAPPI6tJnNwb7ClP7IyF+D+bjOtCpkhz6CFrIa/I6sFtNl8auFXGMTP34sNwI/JhkgEtmDz14ySfaRcTIBInmKPE32kxyyE2Tv+thKbEVePDfW/byMM1Kmm0XdObS7oGD/MypMXFPXrCwOtoYjyyn7BV29/MZfsVzpLDdRtuIZnbpXzvlf+ev8MvYr/Gqk4H/kV/G3csdazLuyTMPsbFhzd1UabQbjFvDRmcWJxR3zcfHkVw9GfpbJmeev9F08WW8uDkaslwX6avlWGU6NRKz0g/SHtCy9J30o/ca9zX3Kfc19zn3BXQKRO8ud477hLnAfc1/G9mrzGlrfexZ5GLdn6ZZrrEohI2wVHhZywjbhUWEy8icMCGNCUdiBlq3r+xafL549HQ5jH+an+1y+LlYBifuxAvRN/lVVVOlwlCkdVm9NOL5BE4wkQ2SMlDZU97hX86EilU/lUmkQUztTE6mx1EEPh7OmdqBtAvv8HdWpbrJS6tJj3n0CWdM6busNzRV3S9KTYhqvNiqWmuroiKgYhshMjmhTh9ptWhsF7970j/SbMrsPE1suR5z7DMC+P/Hs+y7ijrQAlhyAgccjbhjPygfeBTjzhNqy28EdkUh8C+DU9+z2v/oyeH791OncxHOs5y2AtTc7nb/f73TWPkD/qwBnjX8BoJ98VQNcC+8AACN9SURBVHgB7V2N0SW5bbxTKSgn4Fgck2NxAs7KFiTxlsuP+CNBEuT0Vqlm3gzRaDSAvvetdu/++AO/oAAUgAJQAApAASgABaAAFIACUAAKQAEoAAWgABSAAlAACkABKAAFoAAUgAJQAApAASgABaAAFIACUAAKQAEoAAWgABSAAlAACkABKPC6An++XuCX6vuf//qP/5Pq/c///l/0WxII755WAMN/eXs1g+PKg/FxyuD5qwrA7C7t7KjJ9cqF8fVUwbPXFIDZXdjRSKMr5cPwihK4vqoAzO7Czq4wuyIDTK8ogetrCsDsLuvoSqMrUsDwihK4vqQAzO6yblrMrjYry/meBDVG7z2eQYHbFIDZXdQxzbgsBqVh1HJY8OrzuIcCmRWA2WXuTsNNMiqvMUlYdVovbh2LeyiQSQGYXaZuCFwkc5oxJAm30JnBLxi4QoHTCvztNAHkP6uAxcgshni2CmSHAroC+GbX0ai33BZT6ECFPepxIvAoXhx+XUBUrhoT91BglwIwu0ZpbelPLLzEKZKPlKfIFJmvYOIKBXYogB9j/60yLbpl2S1ndjRuRQ6Lkb1c/wpNgZlHAZjdP3rhXWDv+VXttpiTN/cKTC8HnIcCKxT49I+xs6a1wxgkjivzS3lpEFfmXjHowIQCn/1mpy2zZTQiMCx5TpzRzOzl2k/ojZzrFfik2UUuaiSWp92aGXmwcBYKfEGBT/0Y6zGm2kwscfX5yMHhcq/K13Ln8pdzu3iUfLhCgVEFPvPNTlvaWsB2gdvP9dly78EvMdp1BaaWs32v1Z6BY8sZn6FAT4FPmJ1nIbnl5p7Xonry1HG4hwJQYL0Cz5ud1YDIzDRD096vb9eZDFrdVo3PsEdWKPAvBZ42O+sSastcD4t21pqzxvTeaxy8eNJ5qmdHTRIHvIMCEQo8aXaeBV1hHK+Yg6cOz9mIwQUGFPAq8Nz/G2tdulmTs+RZlWMWVxsSS20aRuT71fVGcgVWXgWeMjvrkkYtjyXfaC4JexTTMoZSXkv8rjMrNdhVA/LsVeAZs7MuafSSWPKO5JRwR/C0sZLyabFZ3q/QJUtt4DGvwJO/Z8fJsmIZLJjZjSQ7P66f7XOqo/yvfYfPUOCJb3aWZbWY0sw4aBy8+Tk8L45WE5dHi7vpfbRmN9UOrr8UuN7sLMu6a9g1Lh4eHJYH41ebf95x+D9PvvUkSr+3VPlGNc+b3e7h1kzEyofDscZL48thSzGedxEcKd9KnlEcPbrg7FkF/n42/Vx2bRkyDjRxPslL02ykI6vq6eGu4D9SM2LuU+Bqs5Pk7i2KdD7qHeXVFvKU4Wm8PBqc1LfmGVlTjYv79xS49sdYachPLWI9HhK/ck7iycVLMQW3d+XwemelZ6P5JczId5Y6s9cQqQewfinw7De7XyWeuaOFsizeDnYRPG4xiJpnRN07+oMcexT41J+z2yPpryz14v16+uuOW0bu+a9I+90sFtWg1WFng5NQ4JwCT5rd7IJHtkMzikxc67pvN7msutYa436vAk+aHUl407BbuWrG2Y6OFbeN8+Zp4/EZCmRU4FmzI7Fp2UcXPrJZFvOI5jmCd/u3OUvPLL2w4ODMfQpca3aeoR1Z/OhWevjO5h6pdye/2foQDwVGFLjW7KhYz4KOGMCIoFKMxvcUR42XVBPeQYFbFLj2z9nVAntN4vRye/mWWi28vdgWzJL/lqukwYv13tKX0zyv/mZXxKMB9gyxtAwF88arty6PZjfqAc5QoFbgCbMrBXmWl4zBaw4lz+zVw3M2FxefgQPHDc+hwAoFnjI7EoiW2LPIrxiepw6PPiuG7hTmV+s+pXe2vM+ZXRHYM9geoyj4EVcPx4h8wIACX1bgWbOjpnrMhAzvhOl5OHKD6uEdkY/jgedQILMCT5sdCU/L7Vlwj3FENdbDr83p4TuTp82b9bNHj6w1gNcaBZ43uyKbZ9FpYbA0RTlcocAbCnzG7KhdZHhe09vVZg+vEU6r8Uc47Yz5ev07tc6a68p/n93Ob12Ua9eiUB5Pbdazu/hnHXLwggKkwBVmZ13qVS0t+XeYhmR4xGMHh1U6AhcKnFQgrdkVgzkpTps7k9lY9YE5tl3E568qkPLvxloX+VTTdhiIpIH07a/V5DTXlo/3s4e/ppk3N86/pUA6s5MGNpv0nkX0co/QYQW/CF5eLXrne7VJ3Hrne7h49q4CqX6MlYY1YwuI7xeWKGNfWk5SH6R3GecKnNYokOqbXTvAWskzQ+zNtZILhz3DcUabwmcmf8HIcI3QIkMd4DCnQJpvdpbFihzaHpaFAyc3xfYwufNZn89okLUm8IICpECab3bSkp0wEYmPNjqRfEd4jOYfyaVpkeH9qB4ZuINDnAIp/gZFxiWjBRldkoz1SCNDfLNwHtVcqg/voAApkOKbnbRomYZf4smNUwR/b15PTi82V2f0814No1x7WNF8gZdfgeNmJw1w1iGVOPdaPluHJ581lwezrUnLMYO9IpfGt82Jz28qALMb7Kt3oWcXzprPkseKVaSxYJazvas3Xw/DyqGXyxrby4tn7yhw1Ox6g1mkvWVApRpKLfV1tC5rHg3fikOcNay6Luu9J3+L6eVTcnnj2rz4/IYCMLugPpbFssCNLp+WQ8PV4gt3Daecm71a+bR5dvFr8+Lz3QocMztp0G8dZqmmdkxGatTwJUwttvCTMMqZ6KuVW5v3BNeWAz7fo0CKP3pyj1wyU8/yjSy4B79mas01il/nGrmnvCO5rXWNcELMewrA7IJ76lncTMs6YjbB0rn/TdKUnzTMpGO0JsCLU+CI2UnDmWHpIuS11iFpEcHDgm/lGsHHgkF8vJwsdVpy48y7Chwxu3fl/L0y68LSos4uay+XBbMX93sV5z4RNw8/S73nqkHm0wqkMjvPYJ8WzprfU9PuZfVws9a74pyHJ2m4W8cVNQMzXoHt/2+sNIieoY6XYj2iVHudXdKBw2hjuHMlT3u+PNeuq3C1vOW9lr+co+tojTUG7t9RAGa3uZfWZe0tqhTbnpfOUsnt+Z4MGkYvpn1mydPGaJ89vFbk1/jhfU4F0pjdl4bSsqw9PaS4+rx0jsawPtuOpRbbnrd+lnJaMdpzVq4rcrdc8Dm/Aql+zy6/XDEMLctnXWRiZMHTmFM+T04Nr32/At9a94rcbX34nF+BrWa3cpnyS/07Q8uijuilxbR5dxtBdL62nt9V/v2Tps3vp/HpNQW2mt1r4s3WY1nUyAVt80Vie7WIzE11tbVxfCLzcjnwPKcCW3/Pjhs066DmlHCeFaeLFbnWT8Iq56QzIzkpZgaz8LLmls5ZeUTmlPjgXR4FYHZJemFd0h7dsrgaBp3TzvTw6VnJwb1vn3vzePHbfPVna+7InHV+3OdU4BNmZx1+S4tWLcgox5rPKAZXd43NndGeezhF5Ct8rHkjc5bcuOZU4Emzsw76bEuiF2WEd+EwEivVX3ClM553Vn4n8kbn9OiCs/sUeMbsrMu0StqohfHWQXm9MR4NouqinFaekTmteaNzejTG2T0KbDM7adBHB03C3CNfP8toPQUtW12z9ZS66GqtLSKnNVfhF5GzYOGaT4Erzc47xKdkn1mebDXO1NLTX6tvJp+G3eNTns3kLRi45lTgKrObGeLT8nuXaHWtNR9PrjpuVlMtryeXhmXh6slnwcOZXAocNzvLgEUMcpGd8kXiFVzr1VJvwVrBk8vvycVhFN7WqyWnlsuCofHRcmjxeH+HAqnNLnqQI/Ci2mpZsCi+llylLmtOD2bB7l21fL08WkwvT/ush9uewee3FEhpdjPDzA3xDCa1vMWdxavHaAV2i1nn0+49tc3kKTy0fCWHdq7gSdeCJZ3BuzcVSGd2owMtDbEXU8LixsCbg8OZeT7Cm8vnqScirycfx5l7HsGPw8bzexQ4bnYkFQ3jyLBrQ+zF1PCsbfXmteJy56J4t/ieOiI4ePK1XHufIzj1cPHsTgVSmJ1XOssQexbHguflSOc9HEbwKWYV95qPtY5ZLtY8Nbf2fpZDi4fP7yhwldl5BtmyOB682ZZb+Hhy7OROvDz8Z7h58tR6zeSscXD/rgLbzI4kHB1kivUMsyWPB4/yR/2ycJNyneJNnDzcZ3ha88zkkDTGuzcVSG923oG2LIoXc0XrLTylvCdrsHIf5ajhj+JKeuLd+wqkNjvvUGtLQu30Yq4eAQtnjsPJWjy8R3i2+CMYnG54/k0FUprdyGC3y9Fr5whuDyfqmYWzlutkTR7+J3lqGuL9NxRIZ3ajS6Et3ijuyBhoXEYwpZidtfV4WOs9zbPHHc++o0Aas5tZBG3ZZrCto6BxsOKUc4WzBbecLbEnrhaehVcGvoULrt9RIMV/XWxm+LUlm8G2jAHl1zhYcLgzFv4r83O82ucWniUmA9/CBdfvKLD1mx3J2g66Z0l6bWnx2jOz+C1e+azlLedGrhxnLScXN8JhNEbjWONm4Fvzwf3bChz9Zjc77NpizeJzrdfycnGW56s4W3JHnCH+1hpIx5VaRtQDjHcUOGZ21oUYlXoF/unl1GrKZBwa17qvmXjXvHD/lgLbf4yNkk9bEM+yWThp+TgMjgeHx52v8blYOmOJr7FW30tc29zZuLf88PluBf5+N/0+++il8SwsMYrO36/yjqdFC4uGdKacv6M6sLxJgWM/xs6IJC3OyWWh3DvySzkkbWY0n42VONfYxD9rDTVP3N+nwJVmt1Nmy+LtMrmdda/IZTU8ym3RfQVHYL6rwHVmJy2BZ5ksLZVylfjonAVXu57Kq/HS3nt4W/TX8uE9FCgKXGd2hfjqq2XRPIu7mu+r+NQHSy9erR91xSlwldlJQ7/beHbn87Rc0smDs+LsKLfRuBU1APNOBa4yu10Sa4u10ui03Ls0yJgH2mTsyj2cYHbOXq00OieV6/6Ii2RWVl0JQ8Lxaojz31HgGrOTBty6KN9p652VevoozcOd1YP1agWuMbvVQhR8aYk8y1jwcNUVqHWt77VIqVdaLN5/T4Hrzc6zHJnaeyvvUQ09xkTaWPUhXA/2KH/E3a/AFWaXYZity3f/SOSpwKN5hhnJoxyY9BS4wux6xFc8w8KsUHUOE4Y3px+ifylwtdl5FuFXybjLpIClh3TGco7qwj+wMnU3F5erzW6XlNZF28Xnq3msfSDDg+l9dUr4utObHYaWb94X31gNj7TB7HxxQvia05sdTx1vvqoAGZ7V9GB4X52Sn3Vfa3bWYf9ZMp68ooB1BsjwYHqvdH28jmvNbrxkRL6kgNXwqGYY3kud99eS2ux2DufOXP42IUJSgAzPanros6Tk2++u/W9QYGjfHsyR6sjwLHNRzlgNcoQLYvIpkPqbXQa5sBAZumDn4OlXMT07Ok7erADM7uLuYVn7zYPh9XX5+lOY3dcn4NH6yfCspkf/0MA/OB4dhKqstGaH4au65Ly1LrkTdsnx1X32aLGayxIBAWpWIK3ZmSvAQSigKADDUwT6yGuYXcJGW75hWM5kKs1jOCt4U34rh9u0XaHXi5hp/+iJdTBfbApqWqcAzZXFzMoZzOG6XuxGxje73YoH5CuL2IO6cTmleno1zj7zaLSb22xtiOcVgNnx2ix/41m65WQ+loC0t+oPw3tjOGB2b/TxiiokczllKBKnWlTid4pjzQP34wrA7Ma1OxIpLZx1cY8QT5zUo5ukf+ISQe0fCsDsMAZQ4B8KkOFZTQ+Gd+fIwOwu6pu0ZNZFPV2uxFOqbxdviV/Ngbhm4Ftzwr2sAMxO1ifNWyzWvlZYDY8YoS/7+jKbCWY3q2CCeM9yJqD7zx8ZOR5ZzMOjaRbOnKZ4/i8FYHYXTAKW6UyTyPCspkc9Qp/O9MmaFWZnVerQOW2BrMt4iD6bVuKt1cyCLnohcW1TZuPe8vvyZ5hd4u5ri+NZwsRldqlptXeDFj70aJ2N+0JZroKG2SVt1xcWxmMgGdpEfK2cv9C/DD3xcIDZedRKdNa6dIkou6lkNQyr9sQ/aw3uZjwQALO7sInWZbuhNK2WrGah8a61z1pDzfEL939+ocjMNXoXwbNkmetuuWk6ZK5b415qzVxD4fjyFd/sLurul5fFaign2mntC9WQuY4T2u3MiW92O9Xu5LIOv3WhOimueXS7Flb+1JAv9DPb4OGbXbaOdPh8ZTGsdZKpeIylI+nxR7fzPy7gAAF8sxsQLTJEG3qrAURyOo2ladLyO6WRl2fLu3w+xb/k/8oVZne409LCfHkJJF2klq3UbJSTxLe8W8m75Pj6FWZ3eAKkBfr6AkjaeNrm0TEqp4dfOevhWWJwtSsAs7Nrtewkt2AY/u/9K5TQ82Vr9gfMbp22ZuSMZsdxKkXtXkqNT+GV8Vq08tRQYjLWcysnmF2CznFLsHPgOQ5WeXZxneVprWf2HKeHhz+HMcvtq/EwuwSd5xZgx7BzuWdk2cGb+K3gPlq3t2Yrdy/uKP8vxMHsEnSZG/yVg87ljJRjJf+W5456Ss6oujyco3KWGr54hdkl6Do39CsGnMu1SoYVNVi5ztS6i7eH4y5OVn1vOwezS9AxbuCjh5vLs0OC6Fp2cN6Zw9ob6DjeFZjduHZhkdygRw42l0MrouUwikN5Wiwt99fee7SFlv7pgNn5NQuP4IY8aqA5/F4h3pwebMrnxe9xfPmZR09o6ZsEmJ1PryWnuQGPGGYOuy1kNpc1D+WdzdVyf/GzVU9oae8+/q0ndq2uO7lzYWjpsHhxI2LVknps7XMcuzuRYHZ39k1lbVmAFQZlWVILN7XADxywaFlkgKZFCf4Ks+O1efqNZ5G8QliwsZw2VS1aFiRoWpToX2F2fV2ufqoNvWeBRoXYkWOU221xpKVVT633t9UeyRdmF6nmBVjWpYkoRcuFxfSprOlZ0EhXaFvU+HWF2f3S4om7bENuXdAnxN9QhEfPbLOwQR4xBcxOlOfsy+hh9SzKrsqja9zF+2Qe6qO1l9D3V6dgdr+0wN0iBayLuSj9s7BWXcnwYHp//AGze2gVpIG2LsZDcnyiFE9fpfn4glgwuwRd9gxsArpDFL5Q45AwAUGkrVXfLxsezC5g2LJDWBfhVB1fXsBIza19Jr2/qDnMLnLagAUFLlLga4YHs7toOG+nav3mcXudp/iPmNdIzKn6ZvPC7GYVTBL/paFNInkqGjP9p9iZ+FRCCGRgdoI4eAUFvqTA64YHs/vSNKPWJxXQTMrz2wca1s0Cwuxu7l7F3TPQVRhuH1egzAVdy71W8quGB7PTOo/3UCCxApIx9cyt96xXHuFK2L2Y7M9gdtk79BC/15bn1tZYDY/qe6lnMLtbJxa8oYCggGZo9F47U+BfMTyYXenow9fsw2pduodbdKw0q/Y0Q9nnSBMRZqcphPchCty+KCEiJAWxGh7Rv7mPf0+qP2gNKEBDyw0jPfcM9UB6hCRSoO43NxM13TIblrM1do2R/R5ml71DD/CzLNADZW4vQdNVe18T9pyluHK+mGSNlfUeZpe1Mwt40YBmG85sfBbIPg1ZjGUaaAFAxpniyvyTe4HnexWQBtprCJFYsypIXAjbW9ssn+zxml5Z+d/QR3yzyzo9i3jRMu0aTG1xd/FYJOU0rKbPdIKNAKWWzD3FN7uNAyGlKsPSOzMyQBIe5RjB7HHjnmn5d3DguJ16btHkFLfIvKtna5QrzG5UueA4aRFGh0fCJPqjuFrpWt6VuTVuO99bdNjJZ3euVfM1WgfMblS5BXHccowODYfXUh/Fb3HosyVnZL4eh5PPLPXv4Bel8Ww9UTwiNIPZRagYhMEN1szAcJgt5ZkchLUrT8s7w2dr7dFcZ3s2wmek1hM8e7XB7HqqHHrGDdLssHC4XJmefCuxOX4ZnnvrnuXs6clsLmu8R4MM/GF21s5uOMcNT8SgcNiWsur8UTiWvNnOzNTuqaXW2xMXxc+b35LXi+mp23oWZmdVasM5bmiiBoXDX11aFP/VPHv4OzTz6LODT6uDhZ+FlwWnzR35GWYXqeYkFjcwkUPC5ZikzoZHcmeTBL9YrZFVk9U8vLJZeEucLfFeTp7zMDuPWovPcoOyYki4XFElruAcxY3DWaWJVYtV+bl6R59L9Wg1SLGjfKxxMDurUhvOcYOyckC4nDPlruQ7w6sXu6J+ymPRYFXuXp3Rz6T6pLqkuGiOLR7MrlXk4GduSHYMCJfbKscOjlYulnOz9fZyaBqsyNnjQc80Lm3cCDcph4QnxbW8Ij/j78ZGqnkxVm8AMw7sjMRSPSO4Pc1anOicNb4lf31euu9hadzpfS9OynPyHczupPrJc980yJKU2tJKse07iyaR+Si/JWfLM+JzySvVc5PhwewipgIY6RSQFtRLtiy9FLc7n8Ql+h3V761vJCaad4sHs2sVweerFfAuJVfsToOz5OJ47noumRdpfkMNMLtd04I8SxWIMDnLwu7Ks1SsQXDJ8AYht4bB7LbKjWTRCuwwnx05onUB3k8FYHY/NUn3hJbN8q0jHfGFhGYNyKLnjhwLJVoCbf12N6vdCvIwuxWqAnOZAjNLBINb1pYrgGF2V7QJJFea3Aw2dcZioq90cFarkzrA7E6qj9yqAjPLpZnQSmy1sI8e0HqyUhaY3Up1ndg0CDML6EyX+viMDtpCjWJruKkFXUiu1WVU34UU/wkNs1ut8EL8maFqB3QhTRf0qppW4bqKu/zwjIYZSofZZeiCkUPksNVYGYyv5mOU469jEv9RXAnzr8S4+aGApPdpTWF2P9qV84E0RLOMa+zdA1nn9tYhcR3FlTC9/F46z+l5k14wu5cmMqCWMtQ7hrjk8tKWuI1gSnhebl8+P6L9Tr1gdjvVvigXDe4qExhdConPCKaEd1GrllMd0bYllUFrmF3bFXz+S4Ey5FGDWvD+SmC8kfKPYEp4RkqfOSbpW+soncsiFswuSycmeNRDp8GMDCXFeHL0OIzklXJG4/U44xmvQN0brRf1WR5x/RuY3XqNl2QYHaA6ThvSmjidrWPrd9K9J0fBkfJ48SSskg/XvgJerXsomfTHf4Oi16GDz6QBWzU4Us5WCisHD2bJIWF78SSskg9XXgFJ71pb6Ryh12f5bHvewOz26GzOwg3PjqHhcrfkNS5WnIIr4UVilXy4ygpImte9ks5RhvqsnHHPW/wYu0fnK7LQcGoDTIXQmd4gW2JbIXo4JUd7VvrM4UgxePdTgZEe/kTJ+QTf7JL1hRu23cvM8ajlKpwsZ+s4ui+x7XMvFofT4uKzroCmfa2156yeec8JmN0enc1ZuCGqB80MNnmQ4zIDy9XhzcXhzHD7cqymf62352wmTf+WiQy45FKgHvAIZhyetjx1bsLgcOpzuLcroOlf6+05a2ew5yR+z26PztdmoUHXBlwrrl6W+qwHl8Oo8XDvV0DrQa27dtaffW8Efozdq7eaTRqoevBUoOADEi8uFcfXg8VhcDnx3K6A1odae+0sZa3P21nsO4lvdvu0/lSm3uBbFqYWqYdRv8f9uAJaL2rttbPEoj4/zmptJMxurb5PoFuGvRTKDX0ERsmB65wCWi/qHmpniUl9fo7Z2mj8GLtW3yF0bsB2DxXHgyuqx8+D0YvncuH5mAJaP+oeaGeJQX1+jNG+KHyz26f1VZksg14K4gbeisHFF3xcYxTQ+lH3QTtLjOrzMQzXosDs1up7HbplyOuiegPvwejF1/i4j1FA60ndB+1sDKP9KDC7/ZqnzegZ8no56oKsGFx8jYX7eQUs/ah7YTlPrOqYeZZ7EGB2e3ROn8U65FRIb9Ct8b3Y9OJcStDSk7oflvNc/2+QCH+D4oYuLeZoHXJu0K3x9WItLunz8Jae1P2wnOf6f4vY+GZ3S6cW8LQOODfk1vh6qRaUAchKAUtP2n5YYrgZqFKnv8U3u/QtWkPQOuCUvV0OemaN78VSPH7FK2DpSdsPSwwxbePi2a9HxDe79Rqny2AdcCLeDrk1to1LJ8JjhCx9qXtiOd/r/82ywexu7t4A95khn4kdoIoQgwIjPRmJMVBJfwRml75FcQRnhtwSW39ziGMNJE6BkZ5YYijfi72E2XGT9Njz0SEfjXtMvlTljPZkNC5V8RNkYHYT4t0SOjrklrgXvwFk7qulJ8S/7os1po3LrMMIN5jdiGoXxVgHvV4OKs8S18ZcJMt1VC39oKLanljjerHXiaQQhtkpAt382jro9YKMxNys0Q3cR3tijSMN6hm4QZMRjjC7EdUuiLEMejvgIzEXSHEtRUs/qLiRPhZR2tjy/MUr/lDxRV21Dr/lXDvkIzEXSXcdVUs/qKiRPhYx2tjy/NUrvtk91lnLkrRDPhLzmGxpyrH0gsi2PaRn1lgunp6//Atm91B3LcPeLokW055/SK5UpWh9qMm2PZmJrXFfv4fZPdJhy8B7l6Q9/4hU6cqw9I5I9/phjeXi04mxkBD+GxQLxZ2B5oZ4dODbOA6/cG7Pl+e4ximg9aDO1PbDE0s4bXyN/ZV7fLO7vNOWoW8HXYtpz18uUTr6mv414V4vZuNr/C/dw+we73a7LNqitOcfl2dreZr2LZm2F7PxLf7XPsPsLu64NvzeZWnPXyxNOupar2rCvT7Mxtf4X72H2V3aec/wU4na+d6CXSpNKtqa7jXZXg888YTVw6hzfPkeZndh9y0LUA+9dL4+d6EUaSlLmrekez3wxBe8Hk55h+sff8DsHpyCeuilpanPPSjDkZIkvXuEej2IwOjl+vozmN1lE6AtQr082tnLSk9N16t13adSWARGwcL1pwIwu5+aPPFEW5zesj1R+OYiNJ1bOj3dvRiE2cNpc+Hz7wrA7H7X4+pPZQG05Snnri72MHlN45Yep3kUTpsPn38qALP7qcmVT7hlaouxnmvj8PlfCkSZkxeHsqN3c1MIs5vTL120tERYlvF2Sbr2UDmtvTiEzWH18uIZrwDMjtfmmjdlGaRFKmeuKSoJUUnTHkVOZy8OYXNYvbx4pisAs9M1Sn3CshCWM6mLPEDOa06cxl6cUiqHV97j6lcAZufXLGXE6FKlLOYQqRENOVMawaKyObxDkjyVFmZ3cTsti2E5c7EEIdRHjInTdQSLiuDwQgoEyD8VgNk9MAjcgmGB5OZyuklRnKYjWJSHw5M44N2YAjC7Md0QdakC0aYUjXeprFfQhtld0aafJLVvBNr7n4hvP4k2pVE8Uhm9OTNrMLszuodlnVm6MBJJgWa04QxpBWZS+Z6jBbN7rqXfLmiVGa3C/Xa39lYPs9urd0g27ltHAdfel3MvXVeY0QwmafvFPmSeKZhd5u6Am6jAjBlJRjSDS4QlbLEgvFyqAMxuqbwAj1ZgpRHNYMPgojsdjwezi9cUiMEKzJgQUZGMaCV2sAyAm1QAZjcpIMLjFZg1IGIkGRy9n82h4VMO/MqlAMwuVz9C2NAi37aMs+ZThJPqjsgh4RcOuOZUAGaXsy/TrLIbXoTxFJEkA4rKI+UoPHDNrcCfuel9l520pO3iec6eUlTiOMKp1aDGiMol5ajz4f4OBfDN7o4+DbMsi79zcUvOYdJMoFRDZE4pD0MNjy9QAN/skjZJW952IbXzdZltbP3Oeu/JZ8Vsz2k8IzlouVpu+HyfAjC7xD2Tlrm3nNL5xGX+Rq1XV30gukYtX50b93crALNL3D9tsXuLqsVkK7dXQ8sxuiZLzpYDPt+vAMwueQ+1RecWV4s7VTbHt+azgrslb80B9+8pALNL3lPr4nPLbI1fIQPHqc21kqOVQ8sJn99TAGZ3QU89ZiAttwfHI4uUs4ezikfJ5eVT4nB9WwGY3SX9HTGI00s/wnm0HadrHeWNuH0KwOz2aT2dadY8VhnCLK8RYVbVMsIFMXcoALO7o09/sTxhLH8lP3wDgzvcgMvTw+wubeAXTA/mdulwJqUNs0vaGAut1wwP5mbpOs6MKgCzG1UuWdyNxgdzSzZEj9OB2T3W4IymB1N7bMguLQdmd2njPLR3GSBMzdMVnIUCUAAKQAEoAAWgABSAAlAACkABKAAFoAAUgAJQAApAASgABaAAFIACUAAKQAEoAAWgABSAAlAACkABKAAFoAAUgAJQAApAASgABaAAFIACUAAKQAEoAAWgABSAAlAACkABKAAFoAAUgAJQAApAASgABaAAFIAC1yvw/+LWuIZ3UfhqAAAAAElFTkSuQmCC",
					gastos:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATsAAAE+CAYAAADyEbd0AAAEGWlDQ1BrQ0dDb2xvclNwYWNlR2VuZXJpY1JHQgAAOI2NVV1oHFUUPrtzZyMkzlNsNIV0qD8NJQ2TVjShtLp/3d02bpZJNtoi6GT27s6Yyc44M7v9oU9FUHwx6psUxL+3gCAo9Q/bPrQvlQol2tQgKD60+INQ6Ium65k7M5lpurHeZe58853vnnvuuWfvBei5qliWkRQBFpquLRcy4nOHj4g9K5CEh6AXBqFXUR0rXalMAjZPC3e1W99Dwntf2dXd/p+tt0YdFSBxH2Kz5qgLiI8B8KdVy3YBevqRHz/qWh72Yui3MUDEL3q44WPXw3M+fo1pZuQs4tOIBVVTaoiXEI/MxfhGDPsxsNZfoE1q66ro5aJim3XdoLFw72H+n23BaIXzbcOnz5mfPoTvYVz7KzUl5+FRxEuqkp9G/Ajia219thzg25abkRE/BpDc3pqvphHvRFys2weqvp+krbWKIX7nhDbzLOItiM8358pTwdirqpPFnMF2xLc1WvLyOwTAibpbmvHHcvttU57y5+XqNZrLe3lE/Pq8eUj2fXKfOe3pfOjzhJYtB/yll5SDFcSDiH+hRkH25+L+sdxKEAMZahrlSX8ukqMOWy/jXW2m6M9LDBc31B9LFuv6gVKg/0Szi3KAr1kGq1GMjU/aLbnq6/lRxc4XfJ98hTargX++DbMJBSiYMIe9Ck1YAxFkKEAG3xbYaKmDDgYyFK0UGYpfoWYXG+fAPPI6tJnNwb7ClP7IyF+D+bjOtCpkhz6CFrIa/I6sFtNl8auFXGMTP34sNwI/JhkgEtmDz14ySfaRcTIBInmKPE32kxyyE2Tv+thKbEVePDfW/byMM1Kmm0XdObS7oGD/MypMXFPXrCwOtoYjyyn7BV29/MZfsVzpLDdRtuIZnbpXzvlf+ev8MvYr/Gqk4H/kV/G3csdazLuyTMPsbFhzd1UabQbjFvDRmcWJxR3zcfHkVw9GfpbJmeev9F08WW8uDkaslwX6avlWGU6NRKz0g/SHtCy9J30o/ca9zX3Kfc19zn3BXQKRO8ud477hLnAfc1/G9mrzGlrfexZ5GLdn6ZZrrEohI2wVHhZywjbhUWEy8icMCGNCUdiBlq3r+xafL549HQ5jH+an+1y+LlYBifuxAvRN/lVVVOlwlCkdVm9NOL5BE4wkQ2SMlDZU97hX86EilU/lUmkQUztTE6mx1EEPh7OmdqBtAvv8HdWpbrJS6tJj3n0CWdM6busNzRV3S9KTYhqvNiqWmuroiKgYhshMjmhTh9ptWhsF7970j/SbMrsPE1suR5z7DMC+P/Hs+y7ijrQAlhyAgccjbhjPygfeBTjzhNqy28EdkUh8C+DU9+z2v/oyeH791OncxHOs5y2AtTc7nb/f73TWPkD/qwBnjX8BoJ98VQNcC+8AABuMSURBVHgB7Z3bkSQ3c0aHf/Bd7sgByRU5oUc5IVckB+SOLJAIktjBoDOBxD1RdRix0dWovOFk4uvq2SH59cU/EIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgMJPAbzODEessgf/+t3/+P62Cf/nP/6HXGhzWX0GAA3B5m0sCp20N4dPIsP5kAojdpd3tEbl0qwheSoPrNxBA7C7r8qjI5dtF9HIivH8qAcTuos7OFrq4dQQvkuD1yQR+f/LmnrI3q8iVRMsa4ynM2AcEcgI82eVEnL23iFRJ5NLtlGJZY6TxuIbATQQQO6fdKglTWnKPSGmxe2KltXANAc8E+BrrrDuaEOVlIkw5Ed5DoEzgH+Xb3N1JYFTo/vc//lX9peJ0H5pQWvOnsbiGwC0E+BrroFM9IpMLVi50//Tv/1XtrZQ3j+sADyVAYAoBnuymYOwPIglOa7Rc6IK/tNYaF3sIPIkAYneom0HkLELHk9ahBpH2cQT4C4oDLd0hcpavsQe2TkoIHCPAk91m9DWhC09yrU9zvcLWmmczKtJBYCoBnuym4hwLNiI+PYJXE96x3eANAV8EeLJz1I8gPgiQo4ZQyqMIIHab22l5ekP0NjeFdK8ggNgdaLNF8EJZiN6B5pDysQSqv3j62J072VjP11arWJa2KOWdEbeUk3sQOEmAJ7uT9P/IHQRmt8hIQncYA+khsJwAYrccsS1Bi+ghVjamWEEgJcDX2JSGo+uaoPU+DWpxe+M5QkYpECgSQOyKeM7f1MQpVNYqUFqs1jjnqfxVgbafWn237re2L+6XCSB2ZT5u7koHu+XQSv5xcy1xos+p19I+emq6ae89+8PnmwBi983C9ZV2yC2HVfMNG7b4ewBT2sOM+m7hMGOvb43BX1Bc0vkVh3FFzBU4e4SudW8hR0+eFfsl5hoCPNmt4bokqnQYa4da8gnF1fyWbKAxqFZ7GsayD0uc1pipPdd3EODJ7o4+dVWpHXKLQHQlnOik1R5ThD2M7KPkG3LX8sc6eL2HAGJ3T69eU2lJaEZFLoVYi1WqI43D9R0EELs7+tRcpXZQS080zUkUh5Bby6+4/FrW/GrC9CuAcFHbc+m+Vo+QhiXnBPiZnfMGpeVJB086qJJdiBNttftprvw6+ubr6XstrsU3xBn1T2tJr7W4wSatTbNLbdK4XN9FALG7qF/5YdQOYW4XtxjttfvRzvIaY6W2pbiSvcU3+pVip3GifVyz+Fl8cpsYn9d7CCB2l/RKOrTaASzZSvdGEaR11OKntmleyS/aSvdS313XsZ5d+cgzlwA/s5vL83i0E8IQco7klXyjsEj3jkOmgCsJ8P+guLJtbUVH4Qhe6bUWpVdgev1m16HFG10P+7PwG82D/xoCfI1dw3VqVElEpEMn2YVCJNvWArXYrXHyWqS4uU1LDilei7/FdqQ+S3xs1hDgyW4NVzdRZx3MPI5VVHK/GphW+zxe9LfWl/pH33StJ07qz7UfAvzMzk8vxEq8HrYgDJI45JsI9Wt70NbzGCffW/Z4sj5y2wkgdnZWbiw9HcAW0asBnLWv1SK6On6NE/f7CCB2fdyu8JolHpbNWkRvtUiE+CM5NN+dHC2ssekjgNj1cdvipR0+KXmLreQ/a60mDKvqnBV3VpxZPIkzjwBiN4/llkg1MdlSRCVJ7SkvCMpMUSnF6uFVilfZOrcdE0DsnDbnCQeuRWhabGPLAiONUyq48VrKIa2F+FrcmJvX+wjwqycX9Uw7mLUttB7c3jxSHSFWa34pTr5Witlav1ZjyBFj5Tbpvbw23vskgNj57MuUqkqCUEog+cVDX/LT7uVCodlZ16X6om9vnbNrjPXw6ocAX2P99GKokt5Dbk0aBCb+sfqkdrPq04QuxB/NIflr+dK9cX0HAZ7s7ujTlH/la9ZWowDk4hDXQ5783ozcafw03opcaXyun0GAJ7tn9PHILoL4pH9qRYyI0i6hk2rUctf2y31fBHiy89WPoWrCQS0dTOkgSwlLMST71WtaPdb9tNYncdRqaI2N/TkC/FdPzrEvZpYOl/VwS75pMmuc1KcWM7UN16UcUizNXrKtxc9rie+lWK15YyzNL97n1R8Bvsb668nyisKhlw5+KXE43CsPuFSPtBZqnFVHKU7pXokT9/wS4Gus3950VxYPqiYWMXB+P/rF+/lrbp/fj+9rcaJd6VXLNSN2KS/3nksAsbuot0EAWg57sNVEQ9p2i63kH9Za6tNiaHXMiK3lZP35BBC7wz3WDvassqJArM4T6o25emsPNWoxtPXeXBa/kHMHN0st2IwTQOzGGTZHGDlAJUEoFRLFYiS3JX7JpvderL3XP/jN3PeMekb2gm8fAf42to9bk9fMgxYTzzhwo3X11GDJGeJGu54ckVH6GuPFNWvc3C/4W31jLl59EODJblEfpEMyM1WIP3roJH+tbsl25n7yWLvz5fm1917r0upl/ZsAT3bfLIauNJEYCvqHczhcpdg3Hb7SPnJOM/cl5bXE7/XL98J7HwT4PbuBPoTDEP8MhCm6hvilgykdyGJAZze1va3cl5YzRSPlt/ilMbj2RYCvsQ39kA5Ag7tomh6gUvxgp90P62kcMdHhRa32UFZpb6Nll/JqsXt8tFis+yHA19hKL2YPfkmUtFypj2YTt5HaxrXTr1rNea2SXW7TupfWmJJ9yDlaR2vd2M8ngNhlTLVhz8ya3rYcFC1/GkOziUWltnHtxGtrnSX7nj1J8UpxJPvAreRzgis5+wggdn9w04a8D+nY4dBqyQ+cZpfXnPvl91e9r9Wn1VXy03y0PUixtBiSbYir2Ws5WfdL4JVipw32SJtmHQqtNim+ZivtQ/KX7EbWrPXUainFqfnG+qUYkq9kF2NI9vEer/cReI3YlYa6p20rD4JWq5ZTs9f2pcXR7GvrLfmtuWsxa3Ek/9RHup/uM7VN17m+l8Bjxa42zD0t23UAtNpL+TUf6z5LsdMYvXms8dNc4dqSL48t+QQbaT3PF97n8SQb1u4j8Cixsw6ztU2nhl7bh6Uezde659l2lpprOXfuaUa9tf1w/wyBq8VuxSHwMuza3lrq02LsGLWWOq31rNzPinqt+8JuD4HrxG72wHsd8tn73DNO78ridXbe1QX7bt2L3YpD731IV+zZPhJYthDwPkste3m6rUuxm33YvQ/k7P0+fWi97c/7fHnjdaoeF/9u7IrD7nkAV+z31ACRFwK3EDgmdrMPPOJ2y8hRJwTOENgqdgjcmSaTFQIQ+PraInazRO5tT29hvxo7zyyeerC0Xjx1v0/b13KxGx0Qr4d6dF/aIHndr1Yv6xC4hcBysWsF4fWwnxK3wEPKHda8smrtOfYQ2EHAhdh5PLSSwMxoiMe9ztgXMSDgncBysdOeTDwe+hUC53Gf3ofypvro7z3dWi52GgoPX8MQN607rEPgeQSOid0JlCvELexj9ad7iC/V7uED40QfyQmBHgKPFjtJIHog5T6rxS3PV3qP4JXocA8C3wS2iJ32ZPJdxpyrN4ibRGrVvqVcrEHgVgLb/kMA2oEcfUrS4o40ZLSmkdwl3xV7LeXjXp2A11mpV/4+iy1PdjOxrjjwDOzMDhELAj4JbBO7ICg9QtXjY0GNwFkoYQOB5xDYJnYasiBmqfAgbhop1iEAgREC235mF4pcJWQSgFRApfu3rmkMn7pfT32S2MPdU4fKtRx/siuXZ7/L0NlZYQmBNxL4x85NzxakEC/+2bkPj7mkpw6PdVITBE4RuOrJbrZYnoI+kjcwQNhGCOL7VgKuxQ5xe+tYsm8IzCewXexKTyaI21iDwxMfDMcY4v1cAlt/ZvdcjOwMAhDwTgCx894hoT6e3gQoLEGgQgCxqwC67TZ/eXFbx6h3F4EjYseTya72kgcCEIgEjohdTJ6/8lSSE9Hf84Ghs+EOBCQCrsROKpC1dgJ8aLQzq3nAtEbI//1jYseTif/hoEIIPInAMbHTIPIJqpFhHQIQGCHgTuxGNvM239LTMR8ab5sG9lsjgNjVCHEfAhB4BIGjYld6MnkEXTYBAQi4IXBU7DQKfAXTyHyulz4w4PjJi5X3Etj+HwI4gfpph74kcDlfae8t/nk83kPgVgJb/7PsGqTZB1KKp+Vm/RyBm0RXmqmb6j/XZT+Z3T7ZheGyDpM0iH4QU4lG4HTfrPOl1c/6XQTcil0J4+lDUqqNe/cQYI7u6dWMSq8QO4ZyRquJAYF3E3DxM7vQAgTt3YN44+75GnxX11z+6sldCKkWAhC4gQBid0OXqBECEBgm4OZrbNgJX2WH+0mASQT4ijoJpKMwjxQ7BtXRhDkupfbhyhw5bl5Haa7ELtSfDmA6bOm6ts/UXrNhHQKRADMVSbzj1Z3YSdgZSokKazMI1GaLD9AZlH3EcC92DKOPQXlyFczYk7v7vbcrfqn4u1yunk6gJjwn9h9r4invBP15OV0/2cUh07bbOny1eFoe1tsJtPYmZvDeo959xf3xeo7Atb9nx9CdG5o3Z/Yuxm/uTW3v14pdbWPch8AqAgjeKrJr47oVu9JA8VS3diiIDoEnEnArdk+EzZ6eQ6D0YfycXT5rJ9f9bezMp7qZsZ41Fu27WXn4T/TJsp9gc6K29u7gEQjwZMccQEAgYBUxiygK4Vk6QMCl2DFAByaBlB8ErIL34ciCSwIuxU4jxfBpZFhfRcAyc3w4r6I/N+5VYjd360SDgI0Agmfj5N0KsfPeIeq7hgBPeL5bhdj57g/VOSFgebpzUiplKAQQOwUMyxDICVgEj6e7nJqf94idn15QyQUEELwLmqSUiNgpYFiGwAgBnvBG6K3xRezWcCXqgwlYnu7C9hE8X0OA2PnqB9VcQsAqeJds5xVlInavaDObXEHAIng83a0g3xcTsevjhhcE/iSA4N0zCIjdPb2i0osJ8IR3vnmI3fkeUMHlBCxPd5dv8RHlI3aPaCObOE3AIng83Z3tEmJ3lj/ZH0QAwfPdTMTOd3+o7oEEeMI701TE7gx3sj6UgOXp7qFbd78txM59iyjwNgIWwePpbn9XEbv9zMn4AgIInr8mI3b+ekJFLyLAE96+ZiN2+1iT6WUELE93AQmCt2cwELs9nMnyUgJWwXspnq3bRuy24ibZGwlYBI+nu/WTgditZ0wGCHwheOeHALE73wMqgMAvAjzh/UIx/QKxm46UgBCQCVie7mRPVmcQQOxmUCQGBIwELILH050RZqMZYtcIDHMIjBJA8EYJ9vn/3ueGFwT2EXjrk84N+7YI975JKWd6tdjdMEzl9nEXAmcJhDN0i+DxNfbsrJAdAtcTuOWhAbG7ftTYAAQgYCGA2FkoYQMBCBQJ3PB096qf2d3ys4XiVHETAhDoIvBbl9diJ+1TArFaDJ7wEKgQ0M5mdPN8RvkaG7vEKwQgUCXgWcxqxSN2NULchwAEfhAoCV7tye9HoM1vELvNwEkHAQicIYDYneFOVghcTeDGpzvE7uqRo3gIQMBKALGzksIOAhD4QeC2pzvE7kf7eAMBCDyVAGL31M6yLwhsIFB6utuQvikFYteEC2MIQMBKwNuvoSB21s5hBwEIXE0Asbu6fRQPgfMEbvkqi9idnxUqgAAENhBA7DZAJgUE3krA08/tELu3TiH7hsDLCCB2L2s424XACgI3/NwOsVvReWJCAALuCCB27lpCQRCAwAoCiN0KqsSEAATcEUDs3LWEgiDwLAJe/kYWsXvWXLEbCBwj4P0vKRC7Y6NBYghAYCcBxG4nbXJBAALHCCB2x9CTGAIQ2EkAsdtJm1wQgMAxAojdMfQkhgAEdhJA7HbSJhcEIHCMAGJ3DD2JIQCBnQQQu520yQWBlxLw8IvFiN1Lh49tQ+BtBBC7t3Wc/UJgIQHP/xYFYrew8YSGAAS+CZz+KovYffeCKwhA4MEEELsHN5etQeAEgdJX2ZNPd4jdiWkgJwQgsJ0AYrcdOQkh8HwCpae7U7tH7E6RJy8EILCVAGK3FTfJIACBUz+3Q+yYPQhAYAkBb19lEbslbSYoBCDgjQBi560j1AOBFxA48VUWsXvBYLFFCEDg6+t3IMwlMPqJ5e3nHHPpvDPa6EwEarfORah7xv5nTA5iN0hxdiPTeLcO+CDSR7infZyxoTQec9FHFLHr4/aVDl9niKpbmoMBr+I6bpD2a2UxaR7mwk4asbOz+tMyHbRG1yHzmJfhHsK4xDn2ZknwStCYm7mogPrjNn9BUWf0p0UYqjhYRpclZh5qWLKxS4N66YeXOlrauLvm31qK22WrQTjx6aXVsotFKc8JHqV63nSPuWjrtsZr5wzzZFfomdaggsvWW97r2wpjYzLv3L3Xt7FVP1LxM7sfOL7fzBwY7dNrRo4YQ8vxvSOuZhCIvGfEkno2K36II8WfUfetMfgaK3RuZOBGBmwkb9jGSG4BA0sJgZO9GcntZSa0PeysD7FLBjpcak3JzD7ezm6alzo+NvrCBS+98FJHzwhotc8+N6XaELuEjtaQxOTjcnWzPNb0AeHBC175t9a1ek5rI6DVu7Mufmb3d5e0ZmhNLDWpNVbIocUL6z3xtLpZX0tA62PI2tNHLV7rXITcWqy1RPxE58mucQi1gekZZG0MZuTQYmg5Wf8k0NJTjXdLjM8Kfq7MyKHF+Jlp/juNw856Xi92WhOkdkuNafGXYpbWRvNJ/qV83Psm0NJXiXOL/3dW29VoPsnflrnfSuOxs5ZX/56d1gCppVJTWvylmLW1ED/PIdWhxcl9NTvWfxJo4Zb3Q+rZz+jj76T68jpKWST/kv1T7r1a7KxNzAdpx0CnteXDmdeT2nK9j0Deh7xPKyuRZjCvZ2X+G2O/9musdTDzAbL6xWHI/eN6eB2NZfUv1ZDWw7W9JzlTay8i49w/rofX0VhW/1INaT0zrrWadtaA2BU6mTdCa1geIvfL70vve2P3+kk1sGYTmry/K3vQG9vil+9jZf+1enbW8MqvsRr4UrMtPqFxvc2z+uZ19OYr7fWt93K2Eoect9Un95NiS2sr58JSu1TTrWuvFDtLs9LhtAxFam+Jr9lY4ljqyeP3+OQxeP+TgIWppZ8/o8rvLHEs9cjR37H6OrGzDIRlsNLxaLVPfaXrEK8lZoutlI+1vq+vJW6tPSzFivdaY1rmwnIeYv7bX18ndq0NKw1D6/C15i4Na15XybY1L/Z1Ajn/1GN1L0rxS3WlNb7xGrHLul4apMx0y9tSPa2D3Wq/ZYMOkli4pH0o2ad2K7dWypPWV7JbWZ/H2K8Su3QILM0o2TNEFoLY3ECgNOcz6l8d31rjq8SuBsUqYFa7Wj7r/VK+dJBKdtZc2H0SSLmmvHPL1C6/t+K9NZ/VbkWNpZi760LslG6UhlpxWbq8ezCWbuaBwU/1R8vrbX49tByxa+yCNlyNYZaZ1+rjEPxED4+fPJ787jViVxvqmkh4GAKtxtrePNR+aw0a83Q/FpvU/sR1rcZVM7Qqbg/D14hdCxytQbWBacmB7X0EtLk4vRNtLr3We4oXYneKPHkh8GICmkCvRILYraRLbAi8mIC3J0vE7rJhPPGJeBmireXSj624h5IhdkP4cIaADwI3ie6pWhE7H7M6tYpTwzR1EwS7moC3r7ABJmJ39UjJxXscNLlSVmcRoOd1klf9f2Pzhr7xCSZnUG8xFisJhH68cQ5LTEszepLVVWKXAy5BzW15/00Abt8suPom8PS54Gvsd6+5ggAEHkzApdidfNQNvT6d/8HzxtY2EvA2x6frcSl2YR4CmJ1wLI/wFpuVs6zl38lp5f68x9Y4a33ZtR9LfovNrnpP5XErdhGINmDxPq8/CTDUP3mMvoPnKMG//D2cY/diF1AFUOmfOfj7opwa/lN5+yi9z+tUf07lvbHDLv8n2bNBtgxE+glU8kvtZtcrxdNqyevQ7NKYuU96723XPbw0nxNcLbVoNqt7fYJHaU9X/+pJaWPpvRT6qcan9bReW2u22KUsWut4on3gUeMW7lu4We1mcazV3ZLHsr+WeB5tr/gauxNcOkClAUjtVtZXylOqT6qp1V6K8cS1Vi4l+1K/ZrIr5SnVJ9XQai/FuGENsRvoUmngBsL+cm2J32L7KwEXZgItfFtszQUkhi3xW2yTFI+8fJ3YWT7F0gGp2ae2MyekFrdW18xaiPVJoMa/1r/PiLaVWty0rpptyJja2yq41+p1YtfTqtpAhKGyDJY1dy1WXk/NPuTNfay1vMXOwifnXPPJ7UdYhli1eLV6RvI/wfcVfxsrNao2OMEnH54eHym3ttYT3+Ij7UWr4c3rvSwtfvkstXDuid/j01LTjbaIXaVr+ZBahiiGzH3jevraEi/4pTGtvqlPmpvrTwK9TK1+IaOlHyPxrL6WOj4J3bvyWrELLesdCqvfzLGQBtNah+Q7s7YnxRphavWdySvvrbWG3G9mTV5j8TM7Q2fyAdo9KFK+vCZtG5KvZsu67akrcJL472a9O9/t8/HqJzttaLWmSsMlDb3m37M+klPy7anhjT4tfc05t/j2sM3zhRgtOSX/njpu83m92M0YlJZBsw6INJCteaQY1vxvt5vBujWGhbnU09Y8UgxL7tttELs/OjhzWFpjpQNUGsLWuKVYaU6udQIzmbfGSqsq9bI1bilWmvOJ14jd311tHZrgZhmcWtxajJq/NJS1mJIPazKBVfxLcS39K/nLO7HNq+b7hHXELulizwAFd8twJmnMlz31rKrFXPQDDT31oaeW0BLm4usLscsOZ+8wzRqo0/kzHLz9m8DpvpzO/4RBQOyELo4MVgzX8km6O1+skdc2Arv7tDtfG437rBE7pWczBk0JPX25RVinJ39ZQObi3oYjdpXeeR9uhK7SwAW3vc9E2DJz8dl4xO6TyceKx+FmmD/atH2BudiOfCghYteAz8twI3QNTdtg6mEumIl6oxG7OqMPi1PDzUB/tMLNAjPhphVqIYidiqZ+Y8eAI3D1PnizYC68deSvehC7SX2ZOeAI3KSmOAjDXDhowt8lIHaLemEdcoRtUQOchmUunDaGsiAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAAAQgAAEIQAACEIAABCAAAQhAAAIQgAAEIAABCEAAAhCAwFwC/w+T/a3Nhu2oagAAAABJRU5ErkJggg=="
				}
			}
		}
		
		$scope.getClassRadioButton = function() {
			if($rootScope.solicitudJson.idProducto != undefined) {
				switch($rootScope.solicitudJson.idProducto) {
					/* case ID_PRODUCTO.prestamoPersonal: return "css-orange-custom"; */
					case ID_PRODUCTO.consumo: return "css-yellow-custom";
					case ID_PRODUCTO.italika: return "css-blue-custom";
					case ID_PRODUCTO.telefonia: return "css-green-custom";
					case ID_PRODUCTO.tarjetaCredito: return "css-greenS-custom";
					case ID_PRODUCTO.tarjetaAztecaProducto: return "css-cafeTaz-custom";
					default: return "css-orange-custom"; 
				}
			} else {
				return "css-orange-custom";
			}
		}
		
		$scope.getClassLabel = function() {
			if($rootScope.solicitudJson.idProducto != undefined) {
				switch($rootScope.solicitudJson.idProducto) {
					/* case ID_PRODUCTO.prestamoPersonal: return "css-orange-custom"; */
					case ID_PRODUCTO.consumo: return "css-label-yellow-custom";
					case ID_PRODUCTO.italika: return "css-label-blue-custom";
					case ID_PRODUCTO.telefonia: return "css-label-green-custom";
					case ID_PRODUCTO.tarjetaCredito: return "css-label-greenS-custom";
					case ID_PRODUCTO.tarjetaAztecaProducto: return "css-label-cafeTaz-custom";
					default: return "css-label-orange-custom"; 
				}
			} else {
				return "css-label-orange-custom";
			}
		}
		
		$scope.setEstilo = function(){
			if($rootScope.solicitudJson.idProducto != $rootScope.canalActual){
				$rootScope.categoriaLinea.linea= "";
				$rootScope.categoriaLinea.lineaDes= "";
				$rootScope.categoriaLinea.subLinea= "";
				$rootScope.categoriaLinea.subLineaDes= "";
				$rootScope.categoriaLinea.montoDeseado = "";
				
				$scope.obtenerImagenDestinoPrestamo();
				
				/**
				 * Se agregan estulos para el préstamo destino
				 **/
				$scope.ppDestino = {
		 			catalogoDestino: LINEA_DE_PRODUCTO_PRESTAMO,
		 			catalogoCatDestino: [],
		 			catDestino: "",
		 			catSubDestino: ""
			 	}
				
				$rootScope.canalActual = $rootScope.solicitudJson.idProducto;
				$scope.foliioPre.folio = "";
				$scope.folioCUPre = "";
				$scope.campanaTDC = "";
				if ($rootScope.solicitudJson.banderaOCR != 1)
					$scope.validacionOCR();
				$rootScope.solicitudJson.campana = "";
				$scope.foliioPre.check = false;
				$rootScope.modoPrueba=false;
				//$rootScope.canalTerceros=false;
				switch($rootScope.solicitudJson.idProducto){
					case ID_PRODUCTO.prestamoPersonal:
						//evento CAMBACEO 
						$rootScope.addEvent( BITACORA.SECCION.cambaceo.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.prestamosPersonales.id, 0, BITACORA.SECCION.cambaceo.guardarEnBD );
						
						$compile($("#pago").html($scope.pagoOportuno.texto).contents())($scope);
						var pp = generalService.getArrayValue("montoPlazoPP");
						$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = pp.monto;
						$rootScope.solicitudJson.cotizacion.plazo = pp.plazo;
						$rootScope.solicitudJson.cotizacion.idPlazo = pp.idPlazo;
						generalService.setArrayValue("montoPlazoPP", null);
						$scope.existePlazo = false;
						$scope.calculaMonto();
						$scope.sliderListener();
						$scope.calculaPlazos(pp.monto)
						$rootScope.tasas = "";
						generalService.setArrayValue("solicitudRecuperada", false);
						break;
					case ID_PRODUCTO.consumo:
						//evento CAMBACEO 
						$rootScope.addEvent( BITACORA.SECCION.cambaceo.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.creditoElektra.id, 0, BITACORA.SECCION.cambaceo.guardarEnBD );
						
						var textoPagoOpertuno = $scope.pagoOportuno.texto.replace(/fOrange/g,'fConsumo');					
						$compile($("#pago").html(textoPagoOpertuno.replace(/nota/g,'notaConsumo') ).contents())($scope);	
						resetPlazo();
						 $rootScope.tasas = MODEL_TASAS_JSON["TASAS CONSUMO - ITALIKA - TELEFONIA.TASAS CONSUMO - ITALIKA - TELEFONIA.CATALOGO"];
						 $scope.lineaDeProducto = LINEA_DE_PRODUCTO_CONSUMO;
						break;
					case ID_PRODUCTO.italika:
						//evento CAMBACEO
						$rootScope.addEvent( BITACORA.SECCION.cambaceo.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.italika.id, 0, BITACORA.SECCION.cambaceo.guardarEnBD );
						
						var textoPagoOpertuno = $scope.pagoOportuno.texto.replace(/fOrange/g,'fItalika');					
						$compile($("#pago").html(textoPagoOpertuno.replace(/nota/g,'notaItalika')).contents())($scope);
						
						if(!$scope.seCotizoItalika)
							resetPlazo();
						$rootScope.tasas = MODEL_TASAS_JSON["TASAS CONSUMO - ITALIKA - TELEFONIA.TASAS CONSUMO - ITALIKA - TELEFONIA.MOTOS"];
						$scope.lineaDeProducto = LINEA_DE_PRODUCTO_ITALIKA;
						break;
					case ID_PRODUCTO.telefonia:
						//evento CAMBACEO 
						$rootScope.addEvent( BITACORA.SECCION.cambaceo.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.creditoElektraTelefonia.id, 0, BITACORA.SECCION.cambaceo.guardarEnBD );
						
						var textoPagoOpertuno = $scope.pagoOportuno.texto.replace(/fOrange/g,'fTelefonia');					
						$compile($("#pago").html(textoPagoOpertuno.replace(/nota/g,'notaTelefonia')).contents())($scope);
						resetPlazo();
						$rootScope.tasas = MODEL_TASAS_JSON["TASAS CONSUMO - ITALIKA - TELEFONIA.TASAS CONSUMO - ITALIKA - TELEFONIA.TELEFONIA PREPAGO"];
						$scope.lineaDeProducto= LINEA_DE_PRODUCTO_TELEFONIA;
						break;
					case ID_PRODUCTO.modatelas:
						resetPlazo();
						$rootScope.modoPrueba=true;
						//$rootScope.canalTerceros=true;
						break;
					case ID_PRODUCTO.tarjetaCredito:
//I-MODIFICACION (mensaje para pre aprobados TDC)
						modalService.confirmModal("Aviso", ["Notifícale al Cliente que al obtener la tarjeta de crédito no podrá disponer de otro crédito de Banco hasta nuevo aviso."], 
													                "Rechazar Tarjeta", "Aceptar Tarjeta", "verdeCred","btn gris", "btn verdeCred").then(
													                		function(exito){
													                			resetPlazo();
													                			$scope.showSeccionTab(0); 
																			 },function(error){
																				 $rootScope.solicitudJson.idProducto = ID_PRODUCTO.prestamoPersonal;
																				 $scope.setEstilo();
																			 }
																		);
//						resetPlazo();
//						$scope.showSeccionTab(0);
//I-MODIFICACION (mensaje para pre aprobados TDC)
	//					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto=$scope.montoLimite;
						break;
				};			
			}
		};
				
		
		$scope.setPlazoConsumo = function(monto){	
			
	 		$scope.radioPlazo=new Array();		 		
	 		var long = $rootScope.tasas.length;
	 		var indexPlazo = 0;
	 		var esPlazo = false;	 			 			 			 			 			 	
	 		
	 		for (var i=0; i<long; i++){		 			
	 			if(parseInt(monto) >= parseInt($rootScope.tasas[i].MONTOINI.valor) && parseInt(monto) <= parseInt($rootScope.tasas[i].MONTOFIN.valor) ){	 				
	 				if ($rootScope.tasas[i].PLAZO.valor == 52){
	 					$scope.radioPlazo.push( {radioId:indexPlazo+1, estilo:"", radioValue:parseInt($rootScope.tasas[i].PLAZO.valor), radioLabel:$rootScope.tasas[i].PLAZO.valor,spanId:"opc-cuanto-"+(indexPlazo+1),disable:false, tasas: $rootScope.tasas[i] });		 							 					 					
	 					break;
	 				}
	 			}		 					 					 						 						 					 					 		
	 		}
	 			 		
	 		
	 	};
		
		$scope.calculaPlazosConsumo = function(monto){	
			var plazosAntriores = $scope.radioPlazo.toString()
	 		$scope.radioPlazo=new Array();		 		
	 		var long = $rootScope.tasas.length;
	 		var indexPlazo = 0;
	 		var esPlazo = false;	 			 			 			 			 			 	
	 		
	 		for (var i=0; i<long; i++){		 			
	 			if(parseInt(monto) >= parseInt($rootScope.tasas[i].MONTOINI.valor) && parseInt(monto) <= parseInt($rootScope.tasas[i].MONTOFIN.valor) ){	 				
	 				if (buscaPLazos(monto, $rootScope.tasas[i].PLAZO.valor)){
	 					$scope.radioPlazo.push( {radioId:indexPlazo+1, estilo:"", radioValue:parseInt($rootScope.tasas[i].PLAZO.valor), radioLabel:$rootScope.tasas[i].PLAZO.valor,spanId:"opc-cuanto-"+(indexPlazo+1),disable:false, tasas: $rootScope.tasas[i] });		 							 				
	 					indexPlazo++;
	 					esPlazo = true;
	 				}
	 			}		 					 					 						 						 					 					 		
	 		}
	 		
	 		if(esPlazo){
	 			$scope.radioPlazo[indexPlazo-1].estilo = "ultimo";
	 			if (plazosAntriores != $scope.radioPlazo.toString()){
	 				var index2 =  $scope.radioPlazo.map(function(d){
						return d["radioId"];
				    			
					}).indexOf ($rootScope.solicitudJson.cotizacion.idPlazo);
					if (index2 == -1){
						if (PLAZOS_DEFAULT == 1){
							$rootScope.solicitudJson.cotizacion.idPlazo = $scope.radioPlazo[indexPlazo-1].radioId;
							$rootScope.solicitudJson.cotizacion.plazo = $scope.radioPlazo[indexPlazo-1].radioValue;
						}else{
							$rootScope.solicitudJson.cotizacion.idPlazo = $scope.radioPlazo[0].radioId;
							$rootScope.solicitudJson.cotizacion.plazo = $scope.radioPlazo[0].radioValue;
						}
					}
	 			}
	 			
	 		}
	 	};
	 	
	 	
	 	
	 	function buscaPLazos(monto, plazo){
	 		var montoPlazo = generalService.multitasas("PRESTAMOS PERSONALES.PRESTAMOS PERSONALES BAZ - TOPES.PLAZOS POR MONTO-PRODUCTO",tipoTasa);
	 		for (var i=0; i<montoPlazo.length; i++){		 			
	 			if(parseInt(monto) >= parseInt(montoPlazo[i]["MONTO MINIMO"].valor) && parseInt(monto) <= parseInt(montoPlazo[i]["MONTO MAXIMO"].valor) && $rootScope.solicitudJson.idProducto == montoPlazo[i]["IDPRODUCTO"].valor ){
	 				var plazosArray = montoPlazo[i]["PLAZO MAXIMO"].valor;
	 				plazosArray = plazosArray.split(",");
	 				var index = plazosArray.map(function(d){
	 					return d}
	 				).indexOf (plazo);
	 				if (index != -1){
	 					return true;
	 				}else{
	 					return false;
	 				}			
	 			}		 					 					 						 						 					 					 		
	 		}
	 		
	 	}
	 	
		function resetPlazo(){
			if($scope.isCanalInterno){
				var pp = {};
				if( generalService.getArrayValue("montoPlazoPP") ==null){
					var pp = {
							monto:$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto,
							plazo: $rootScope.solicitudJson.cotizacion.plazo,
							idPlazo: $rootScope.solicitudJson.cotizacion.idPlazo
						};
				}else
					var pp = generalService.getArrayValue("montoPlazoPP");
				
				
				generalService.setArrayValue("montoPlazoPP", pp);
				generalService.setArrayValue("presupuesto", null);
				try{
					if(!$scope.presupuestoC3)
						angular.element("[ng-controller='presupuestoCambaceoController']").scope().init();
				}catch(e){}
			}
			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche= 0;
			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = 0;
			$rootScope.solicitudJson.cotizacion.plazo=52;
			$rootScope.solicitudJson.cotizacion.idPlazo=52;
			$scope.radioPlazo=new Array();
//			$scope.existePlazo = false;
						
			$scope.calculaMonto();
		}
		
		$scope.sliderListener = function(){
			
				
		 		var fooCallback = function( uiValue ){
			 		/* BUG JQUERY TIMEOUT */
					$timeout( function(){ 
							if(uiValue > 20000){
								uiValue = redondearValor(uiValue, 500);
							}
						
			 				angular.element( document.getElementById( "simulador" ) ).scope().uiSlider( uiValue );
			 			}, 0
			 		);
		 		};		 				 		 
		 		var objTmp = arrayPlazoMonto[0];
		 		var tope = generalService.multitasas("PRESTAMOS PERSONALES.PRESTAMOS PERSONALES BAZ - TOPES.TOPE CLIENTES NUEVOS.VALOR.valor",tipoTasa);
		 		array_temp_values[0] = parseInt(objTmp.MONTO.valor);		 				 		
		 		var indexMonto = 1; 
		 		var long = arrayPlazoMonto.length;
		 		for (var i = 1; i <long ;i++){		 			
		 			if(objTmp.MONTO.valor == arrayPlazoMonto[i].MONTO.valor)
		 				continue;
		 			objTmp = arrayPlazoMonto[i];
		 			array_temp_values[indexMonto] = parseInt(arrayPlazoMonto[i].MONTO.valor);
		 			if(array_temp_values[indexMonto] == tope)
		 				break;
		 			indexMonto++;
		 		}
		 		_min = Math.min.apply( null, array_temp_values );
		 		_max = Math.max.apply( null, array_temp_values )
		 		_step = array_temp_values[1] - array_temp_values[0];
				
		 		if($rootScope.sucursalSession != undefined){
		 			if($rootScope.consultaFuncionalidad.limiteMaximoPP <= _max || ($rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento != "" && $rootScope.consultaFuncionalidad.limiteMaximoEdadPP <= _max && generalService.validaEdad($rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento))){
		 				_max = generalService.validaEdad($rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento)?$rootScope.consultaFuncionalidad.limiteMaximoEdadPP:$rootScope.consultaFuncionalidad.limiteMaximoPP;
		 			}
		 			
		 			if($rootScope.consultaFuncionalidad.limiteMinimoPP >= _min){
		 				_min = generalService.validaEdad($rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento)?$rootScope.consultaFuncionalidad.limiteMinimoPP:$rootScope.consultaFuncionalidad.limiteMinimoPP;
		 			}
				}
		 		
		 		$scope.minPrestamo = _min;
		 		$scope.maxPrestamo = _max;
		 		
		 		/* INIT SLIDER */
		 		var sliderTmp = slider( _min, _max, _step, $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto, 
		 								'.amount div', array_temp_values, fooCallback );	
			
	 	};
	 	
	 	$scope.uiSlider = function ( valor ){
	 		$scope.calculaPlazos( valor );
	 		$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = valor;
	 		$scope.calculaMonto();
	 	};
	 	
	 	
	 	$scope.uiSlider2 = function ( valor ){
	 		if(montoAntInvertir != valor || $scope.banderaCambio){
	 			montoAntInvertir=valor;
	 			$scope.montoInvertir=valor;
	 			$scope.montoLimite = Math.round((parseInt(valor) * .7));
//	 			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto=$scope.montoLimite;
//	 			if($scope.cambios < 1){
//	 				$scope.cambios++;
//	 				$scope.sliderListener3();
//	 			}else
//	 				$scope.cambios=0;
	 				
	 		}else
	 			console.log(valor);
	 	};
	 	
	    $scope.sliderListener2 = function(){
//	    	$scope.montoInvertir = $scope.montoLimite;
	 		var fooCallback = function( uiValue ){
		 		/* BUG JQUERY TIMEOUT */
				$timeout( function(){ 
		 			angular.element( document.getElementById( "invertirDiv" ) ).scope().uiSlider2( uiValue );
		 		}, 1);
	 		};		 				 		 
    
	 		_min = 10000;
	 		_max = 300000;
	 		_step = 10000;
	        var arreglo = [];
	 		arreglo[0] = _min;
	 		for (var i = 1; i <30 ;i++){
	 			arreglo[i] = (arreglo[i - 1] + 10000);
			}
	 		
	 		
	 		$scope.minInvertir = _min;
	 		$scope.maxInvertir = _max;
	 		
	 		/* INIT SLIDER */
	 		var sliderTmp = slider( _min, _max, _step, $scope.montoInvertir, 
	 								'.amount1 div',arreglo, fooCallback, "#sliderInvertir" );	
		
	 	};
	 	
	 	$scope.uiSlider3 = function ( valor ){
	 		if(montoAntLimite != valor || $scope.banderaCambio){
//	 			$scope.banderaCambio=false;
	 			montoAntLimite=valor;
	 			$scope.montoLimite=valor;
		 		$scope.montoInvertir = Math.round((parseInt(valor) / 7)) * 10;
//		 		$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto=valor;
//		 		if($scope.cambios < 1){
//	 				$scope.cambios++;
//	 				$scope.sliderListener2();
//		 		}else
//		 			$scope.cambios=0;
	 		}else
	 			console.log(valor);
	 	};
	 	
	    $scope.sliderListener3 = function(){
//	    	$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = $scope.montoInvertir;
	 		var fooCallback = function( uiValue ){
		 		/* BUG JQUERY TIMEOUT */
				$timeout( function(){
					angular.element( document.getElementById( "limiteDiv" ) ).scope().uiSlider3( uiValue );
		 		}, 1);
	 		};		 				 		 
	
	 		_min = 7000;
	 		_max = 210000;
	 		_step = 7000;
	        var arreglo = [];
	 		arreglo[0] = _min;
	 		for (var i = 1; i <30 ;i++){
	 			arreglo[i] = (arreglo[i - 1] + 7000);
			}
	 		
	 		
	 		$scope.minLimite = _min;
	 		$scope.maxLimite = _max;
	 		
	 		/* INIT SLIDER */
	 		var sliderTmp = slider( _min, _max, _step, $scope.montoLimite, 
	 								'.amount2 div',arreglo, fooCallback, "#sliderLimite" );	
		
		}; 	
	 	
	 	

	 	$scope.calculaPlazos = function(monto){		
	 		if ($rootScope.solicitudJson.idProducto !=  ID_PRODUCTO.prestamoPersonal && !$rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){	 			
				$scope.calculaPlazosConsumo(monto);
			}else{
				var plazosAntriores = $scope.radioPlazo.toString();
		 		$scope.radioPlazo=new Array();		 		
		 		var long = arrayPlazoMonto.length;
		 		var indexPlazo = 0;
		 		var esPlazo = false;
		 		for (var i=0; i<long; i++){		 			
		 			if(monto == arrayPlazoMonto[i].MONTO.valor ){
		 				if (buscaPLazos(monto, arrayPlazoMonto[i].PLAZO.valor)){
		 					$scope.radioPlazo.push( {radioId:indexPlazo+1, estilo:"", radioValue:parseInt(arrayPlazoMonto[i].PLAZO.valor), radioLabel:arrayPlazoMonto[i].PLAZO.valor,spanId:"opc-cuanto-"+(indexPlazo+1),disable:false});		 							 				
		 					indexPlazo++;
		 					esPlazo = true;
		 				}
		 			}else if( esPlazo )
		 				break;		 					 					 						 						 					 					 		
		 		}
		 		if(esPlazo){
		 			$scope.radioPlazo[indexPlazo-1].estilo = "ultimo";
		 			if (plazosAntriores != $scope.radioPlazo.toString()){
		 				
		 				var index2 =  $scope.radioPlazo.map(function(d){
							return d["radioId"];
					    			
						}).indexOf ($rootScope.solicitudJson.cotizacion.idPlazo);
						if (index2 == -1){		 				
			 				if (PLAZOS_DEFAULT == 1){
			 					$rootScope.solicitudJson.cotizacion.idPlazo = $scope.radioPlazo[indexPlazo-1].radioId;
			 					$rootScope.solicitudJson.cotizacion.plazo = $scope.radioPlazo[indexPlazo-1].radioValue;
			 				}else{
			 					$rootScope.solicitudJson.cotizacion.idPlazo = $scope.radioPlazo[0].radioId;
			 					$rootScope.solicitudJson.cotizacion.plazo = $scope.radioPlazo[0].radioValue;
			 				}
						}
		 			}
		 		}
			}
	 	};
		
//	 	$rootScope.$watch("solicitudJson.cotizacion.idPeriodicidad",function(){
//	 		if (parseInt($rootScope.solicitudJson.cotizacion.idPeriodicidad))
//	 			$scope.calculaMonto();
//	 	}, true		                				
//	 	);
//	 	
//	 	$rootScope.$watch("solicitudJson.cotizacion.idPlazo",function(){
//	 		if (parseInt($rootScope.solicitudJson.cotizacion.idPlazo))
//	 			$scope.calculaMonto();
//	 	}, true		                				
//	 	);
	 	
	 	$scope.calculaMonto=function(){		 		
	 		$scope.existePlazo = false;
	 		if ($rootScope.solicitudJson.idProducto ==  ID_PRODUCTO.prestamoPersonal){
	 			
		 		if(arrayPlazoMonto != undefined){
		 			var monto = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;	 			
			 		var periodicidad = $rootScope.solicitudJson.cotizacion.idPeriodicidad;
			 		var plazo = $rootScope.solicitudJson.cotizacion.plazo;		 				 				 	
			 		for (var i = 1; i <= arrayPlazoMonto.length;i++){
						if (monto        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.MONTO["+i+"].valor",tipoTasa) &&
							periodicidad == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PERIODICIDADID["+i+"].valor",tipoTasa) &&
							plazo        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PLAZO["+i+"].valor",tipoTasa)){ 						
						   var tasaNormal = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA NORMAL["+i+"].valor",tipoTasa));
						   var tasaPuntual = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA PUNTUAL["+i+"].valor",tipoTasa));
						   var idProducto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PRODUCTOID["+i+"].valor",tipoTasa);
						   var montoNormal = monto * tasaNormal;
						   $rootScope.solicitudJson.cotizacion.montoTotal = parseFloat(monto) + parseFloat(montoNormal);
						   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses = parseInt($rootScope.solicitudJson.cotizacion.montoTotal - monto);
						   $rootScope.solicitudJson.cotizacion.pagoNormal = Math.round(parseFloat($rootScope.solicitudJson.cotizacion.montoTotal / plazo));
						   var montoPuntual = monto * tasaPuntual;
						   var montoTotalPuntual = monto + montoPuntual;
						   $rootScope.solicitudJson.cotizacion.pagoPuntual = Math.round(parseFloat(montoTotalPuntual / plazo));
						   $rootScope.solicitudJson.cotizacion.ultimoAbono = parseInt($rootScope.solicitudJson.cotizacion.montoTotal - $rootScope.solicitudJson.cotizacion.pagoNormal * (plazo - 1));
						   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto = idProducto;
						   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].cantidad = 1;
						   $scope.existePlazo= true;	 					 
						   i=9999;
						}
			 		}
		 		}
	 		}else{	 			
	 			
	 			var monto = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;	 			
	 			var periodicidad = $rootScope.solicitudJson.cotizacion.idPeriodicidad;
	 			var plazo = $rootScope.solicitudJson.cotizacion.plazo;	
	 			var tasasJson = "";
	 			var index2 =  $scope.radioPlazo.map(function(d){
					return d["radioValue"];
			    			
				}).indexOf (plazo);
				if (index2 != -1){
					tasasJson  = $scope.radioPlazo[index2].tasas
					var tasaNormal  = parseFloat(tasasJson["TNORMAL"].valor);
					var tasaPuntual = parseFloat(tasasJson["TPUNTUAL"].valor);
					var montoNormal = monto * tasaNormal;
				    var idProducto = tasasJson["MECANICA"].valor;
					$rootScope.solicitudJson.cotizacion.montoTotal = parseFloat(monto) + parseFloat(montoNormal);
					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses = parseInt($rootScope.solicitudJson.cotizacion.montoTotal - monto);
					$rootScope.solicitudJson.cotizacion.pagoNormal = parseInt(parseFloat($rootScope.solicitudJson.cotizacion.montoTotal / plazo));
					var montoPuntual = monto * tasaPuntual;
					var montoTotalPuntual = monto + montoPuntual;
					$rootScope.solicitudJson.cotizacion.pagoPuntual = Math.round(parseFloat(montoTotalPuntual / plazo));
					$rootScope.solicitudJson.cotizacion.ultimoAbono = parseInt($rootScope.solicitudJson.cotizacion.montoTotal - $rootScope.solicitudJson.cotizacion.pagoNormal * (plazo - 1));
					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto = idProducto;
					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].cantidad = 1;			
					$scope.existePlazo = true;
					i=9999;
				}
	 		}
	 		if( !$scope.existePlazo ){			 						 		
	 			$rootScope.solicitudJson.cotizacion.montoTotal = 0.0;				
	 			$rootScope.solicitudJson.cotizacion.pagoNormal = 0.0;				
	 			$rootScope.solicitudJson.cotizacion.pagoPuntual = 0.0;
	 			$rootScope.solicitudJson.cotizacion.ultimoAbono = 0.0;
	 			
	 			if($rootScope.solicitudJson.idProducto !=  ID_PRODUCTO.prestamoPersonal){
	 				$rootScope.solicitudJson.cotizacion.idPlazo = 52;
		 			$rootScope.solicitudJson.cotizacion.plazo = 52;
		 			$scope.existePlazo = true;
	 			}else{
	 				$rootScope.solicitudJson.cotizacion.idPlazo = 0.0;
		 			$rootScope.solicitudJson.cotizacion.plazo = 0.0;
	 			}
	 			
	 			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses = 0.0;
	 			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto = "0";
	 			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].cantidad = 0.0;
	 		}
	 	};
	
	 	$scope.validadias = function(dia){
	 	   if (!dia){
		  	   var vAnno="";
		 	   var vMes="";
		 	   $scope.vDia=$scope.nDia;
		 	   if (parseInt($scope.nMes) && parseInt($scope.nAnno)){
		 		  vAnno=$scope.nAnno;
		 		  vMes=$scope.nMes;
		           $scope.aniobisiesto(vAnno,vMes);
		           $scope.nDia=$scope.vDia;
		 	   }
	 	   }
	 	   
	 	  if (parseInt($scope.nDia) && parseInt($scope.nMes) && parseInt($scope.nAnno)){
	 		  $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento = $scope.nDia + "/" + $scope.nMes + "/" + $scope.nAnno;
	 		  $scope.sliderListener();
	 		  $scope.validaCantidad($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText,2)
	 	  }
	 	   
	  	};
	 		 	
	 	$scope.aniobisiesto = function(vAnno,vMes){
	 		$scope.days=[];
	 		if ((vAnno % 4 == 0) && ((vAnno % 100 != 0) || (vAnno % 400 == 0))) {
	 			if (vMes == "02"){
	 				$scope.days = dias.slice(0,29);
	 				if ($scope.vDia>"29")
	 					$scope.vDia="29";
	 			}
	 		}else{
	 			if (vMes == "02"){
	 				$scope.days = dias.slice(0,28);
	 				if ($scope.vDia>"28")
	 					$scope.vDia="28";
	 			}
	 		}
	 		if (vMes=="04"||vMes=="06"||vMes=="09"||vMes=="11"){
	 			$scope.days = dias.slice(0,30);
	 			if ($scope.vDia>"30")
	 				$scope.vDia="30";
	 		}
	 		if (vMes=="01"||vMes=="03"||vMes=="05"||vMes=="07"||vMes=="08"||vMes=="10"||vMes=="12")			    		
	 			$scope.days = dias;
	 	};
		
	 	$scope.creaCodigo=function(){
	 		$scope.rString = securityService.getRandomHex(6);
	 		$scope.image = document.getElementById("captcha1").getContext("2d");
	 		$scope.image.font = "15px Arial";
	 		$scope.image.strokeStyle="red";
	 		$scope.image.fillText($scope.rString,0,15);	
	 	};
	 	
	 	$scope.validaApellidos = function(aPaterno, aMaterno, origen, tipo){
	 		var validaXPaterno = false;
	 		var validaXMaterno = false;
	 		
	 		if($rootScope.faseGeneraRechazo == 1 || $rootScope.faseGeneraReactivado == 1 || $rootScope.faseGeneraMigracionSuc == 1){
	 			$scope.check1SolicitarModel = true;
				$scope.check2SolicitarModel = true;
				$scope.manejoErroresMaterno = false;
				$scope.manejoErroresPaterno = false;
				$scope.esObligatorio = false;
			}else{
		 		if(aPaterno != undefined && aPaterno.length >= 1){
		 			if(aPaterno.length >= 2 && aPaterno[0] == "X" && aPaterno[1] == "X"){
		 				$scope.manejoErroresPaterno = true;
		 				$scope.esObligatorio = true;
						$scope.forSimulador.$invalid = true;
						validaXPaterno = true;
		 			}else{
		 				if(!$scope.check1SolicitarModel && !$scope.check2SolicitarModel){
		 					if($rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno.length > 0 && $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno.length > 0){
				 				$scope.esObligatorio = false;
				 				$scope.forSimulador.$invalid = false;
				 				$scope.manejoErroresPaterno = false;
		 					}else{
				 				$scope.esObligatorio = true;
				 				$scope.forSimulador.$invalid = true;
		 					}
		 				}else{
		 					if($rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno.length > 0){	
				 				$scope.esObligatorio = false;
				 				$scope.forSimulador.$invalid = false;
				 				$scope.manejoErroresPaterno = false;
		 					}else{
				 				$scope.esObligatorio = true;
				 				$scope.forSimulador.$invalid = true;
		 					}	
		 				}
		 			}
		 		}else if($scope.check1SolicitarModel){
		 			$scope.manejoErroresPaterno = true;
	 				$scope.esObligatorio = true;
					$scope.forSimulador.$invalid = true;
		 		}
		 		
		 		if(aMaterno != undefined && aMaterno.length >= 1){
		 			if(aMaterno.length >= 2 && aMaterno[0] == "X" && aMaterno[1] == "X"){
		 				$scope.manejoErroresMaterno = true;
		 				$scope.esObligatorio = true;
						$scope.forSimulador.$invalid = true;
						validaXMaterno = true;
		 			}else{
		 				if(!$scope.check1SolicitarModel && !$scope.check2SolicitarModel){
		 					if($rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno.length > 0 && $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno.length > 0){	
				 				$scope.esObligatorio = false;
				 				$scope.forSimulador.$invalid = false;
				 				$scope.manejoErroresMaterno = false;
		 					}else{
				 				$scope.esObligatorio = true;
				 				$scope.forSimulador.$invalid = true;
		 					}
		 				}else{
		 					if($rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno.length > 0){	
				 				$scope.esObligatorio = false;
				 				$scope.forSimulador.$invalid = false;
				 				$scope.manejoErroresMaterno = false;
		 					}else{
				 				$scope.esObligatorio = true;
				 				$scope.forSimulador.$invalid = true;
		 					}	
		 				}
		 			}
		 		}else if($scope.check2SolicitarModel){
		 			$scope.manejoErroresMaterno = true;
	 				$scope.esObligatorio = true;
					$scope.forSimulador.$invalid = true;
		 		}
		 		
		 		if($rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno != undefined && $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno.length > 0 && tipo == 1 && !validaXPaterno){
 					$scope.manejoErroresPaterno = false;
 				}else if(($rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno == undefined || $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno == "") && origen == 1 && tipo == 1){
 					$scope.manejoErroresPaterno = true;
 				}else if($scope.forSimulador.apPaterno.$touched && tipo == 1){
 					$scope.manejoErroresPaterno = true;
 				}
 				
 				if($rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno != undefined && $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno.length > 0 && tipo == 2 && !validaXMaterno){
 					$scope.manejoErroresMaterno = false;
 				}else if(($rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno == undefined || $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno == "") && origen == 1 && tipo == 2){
 					$scope.manejoErroresMaterno = true;
 				}else if($scope.forSimulador.apMaterno.$touched && tipo == 2){
 					$scope.manejoErroresMaterno = true;
 				}
 				
 				if(!$scope.check1SolicitarModel && !$scope.check2SolicitarModel && (validaXPaterno || validaXMaterno)){
 					$scope.esObligatorio = true;
					$scope.forSimulador.$invalid = true;
 				}
 				
 				if($scope.forSimulador.nombre.$invalid || $scope.forSimulador.apPaterno.$invalid || $scope.forSimulador.apMaterno.$invalid || $scope.forSimulador.genero.$invalid || $scope.forSimulador.lugarNacimiento.$invalid || $scope.forSimulador.celular.$invalid || $scope.forSimulador.nDia.$invalid || $scope.forSimulador.nMes.$invalid || $scope.forSimulador.nAnno.$invalid){
 					$scope.forSimulador.$invalid = true;
 				}
			}
	 	}
	 	
	 	$scope.ocrIFE = function(response) {
	 		if($scope.isTienda) {
	 			if($scope.doctoIdentificacion == 1) {
	 				try {	 				
		 				if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.tarjetaCredito) {
		 					$scope.nacionalidades = [{id:1, descripcion:"Mexicana"}, 
		 					                         {id:2, descripcion:"Extranjera"}];
		 					$scope.nacionalidad.deshabilitado = false;	 					
		 					modalService.tipoIdentificacionOficialModal($scope.nacionalidades);
		 				} else {	 						 				
		 					$rootScope.waitLoaderStatus = LOADER_SHOW; 
			 				$rootScope.aplicarOCR_IFE('ocrDiv','respuestaComponente');
		 				}		 				
			 		} catch(e) {
		            	modalService.alertModal("Error al capturar imagen", [e], null, null, null);           	 
		            }
	 			} 
	 		} 
	 	};
	 	
	 	/**
	 	 * Función de callback para el componente de OCR.
	 	 */
	 	$scope.respuestaComponente = function(response) {
	 		// Se realiza la limpieza previa, para quitar "residuos" de una ejecución anterior.
	 		limpiarDatosOCR();
	 		
	 		if(typeof response !== "undefined") {
	 			// Se realiza una transformada de ¿whiplash? para lograr que se pinte los datos extraídos. 
		 		if(typeof response.persona !== "undefined") {
		 			response.mensaje = response.persona;
		 		}

		 		// ¿Qué trajo el viento?
		 		$rootScope.loggerIpad("respuestaComponente", null, response);
	 			
	 			// El componente pudo extraer datos.
		 		if(response.codigo == 0) {
		 			// Si trae una Ñ, por el encoding, hay que realizar el cambio.
			 		response = JSON.parse(JSON.stringify(response).replace(/Ã‘/g, "Ñ"));
		 			
		 			// Variable para una posible fecha de nacimiento.
		 			var possibleBday;
		 			
		 			// Variable que funciona como marca si no se encuentra alguna propiedad.
		 			var notFound = "not found!"
		 			
		 			// Estructura JSON para ir colocando los campos que se evalúan.
		 			var extractedData = {
		 				vigencia: "",
		 				nombre: "",
		 				patronimico: "",
		 				matronimico: "",
		 				folioCentral: "",
		 				calle: "",
		 				cp: "",
		 				genero: "",
		 				fechaNacimiento: "",
		 				curp: "",
		 				claveElector: "",
		 				folioIdentificacion: "",
		 				colonia: ""
		 			};
		 			
		 			try {
		 				// Se tiene un objeto persona.
			 			if(typeof response.persona !== "undefined") {
			 				// Alguna respuesta trae un JSON hecho cadena, así que hay que parsearlo.
			 				if(typeof response.persona === "string") {
			 					// Se quita el primer caracter si no es una llave; es un parásito.
			 					if(response.persona.length > 1 && response.persona[0] != "{") {
			 						response.persona = response.persona.substring(1);
			 					}
			 					
			 					// Se parsea el JSON.
			 					response.persona = JSON.parse(response.persona);
			 				}
			 				
			 				// Extrayendo el año de vigencia.
			 				if(typeof response.persona.anioVigencia !== "undefined") {
			 					extractedData.vigencia = response.persona.anioVigencia;
			 				} else if(typeof response.persona.Vigencia !== "undefined") {
			 					extractedData.vigencia = response.persona.Vigencia;
			 				} else {
			 					extractedData.vigencia = notFound;
			 				}
			 				
			 				// Extrayendo el nombre.
			 				if(typeof response.persona.nombre !== "undefined") {
			 					extractedData.nombre = response.persona.nombre; 
			 				} else if(typeof response.persona.Nombre !== "undefined") {
			 					extractedData.nombre = response.persona.Nombre;
			 				} else {
			 					extractedData.nombre = notFound;
			 				}
			 				
			 				// Extrayendo el apellido paterno.
			 				if(typeof response.persona.apPaterno !== "undefined") {
			 					extractedData.patronimico = response.persona.apPaterno; 
			 				} else if(typeof response.persona.ApellidoPaterno !== "undefined") {
			 					extractedData.patronimico = response.persona.ApellidoPaterno;
			 				} else {
			 					extractedData.patronimico = notFound;
			 				}
			 				
			 				// Extrayendo el apellido materno.
			 				if(typeof response.persona.apMaterno !== "undefined") {
			 					extractedData.matronimico = response.persona.apMaterno; 
			 				} else if(typeof response.persona.ApellidoMaterno !== "undefined") {
			 					extractedData.matronimico = response.persona.ApellidoMaterno;
			 				} else {
			 					extractedData.matronimico = notFound;
			 				}
			 				
			 				// Extrayendo el folio central.
			 				if(typeof response.persona.FolioCentral !== "undefined") {
			 					extractedData.folioCentral = response.persona.FolioCentral;
			 				} else {
			 					extractedData.folioCentral = notFound;
			 				}
			 				
			 				// Extrayendo la calle.
			 				if(typeof response.persona.calle !== "undefined") {
			 					extractedData.calle = response.persona.calle;
			 				} else if(typeof response.persona.Calle !== "undefined") {
			 					extractedData.calle = response.persona.Calle;
			 				} else {
			 					extractedData.calle = notFound;
			 				}
			 				
			 				// Extrayendo el código postal.
			 				if(typeof response.persona.cp !== "undefined") {
			 					extractedData.cp = response.persona.cp;
			 				} else if(typeof response.persona.CP !== "undefined") {
			 					extractedData.cp = response.persona.CP;
			 				} else {
			 					extractedData.cp = notFound;
			 				}
			 				
			 				// Extrayendo género.
			 				if(typeof response.persona.genero !== "undefined") {
			 					extractedData.genero = response.persona.genero;
			 				} else if(typeof response.persona.Sexo !== "undefined") {
			 					extractedData.genero = response.persona.Sexo;
			 				} else {
			 					extractedData.genero = notFound;
			 				}
			 				
			 				// Extrayendo la fecha de nacimiento.
			 				if(typeof response.persona.fechaNacimiento !== "undefined") {
			 					extractedData.fechaNacimiento = response.persona.fechaNacimiento; 
			 				} else if(typeof response.persona.FechaNacimiento !== "undefined") {
			 					extractedData.fechaNacimiento = response.persona.FechaNacimiento;
			 				} else if(typeof response.persona.fechaNAcimiento !== "undefined") {
			 					extractedData.fechaNacimiento = response.persona.fechaNAcimiento;
			 				} else {
			 					extractedData.fechaNacimiento = notFound;
			 				}
			 				
			 				// Extrayendo la CURP.
			 				if(typeof response.persona.curp !== "undefined") {
			 					extractedData.curp = response.persona.curp;
			 				} else if(typeof response.persona.Curp !== "undefined") {
			 					extractedData.curp = response.persona.Curp;
			 				} else {
			 					extractedData.curp = notFound;
			 				}
			 				
			 				// Extrayendo la clave de elector.
			 				if(typeof response.persona.claveElector !== "undefined") {
			 					extractedData.claveElector = response.persona.claveElector;
			 				} else if(typeof response.persona.claveLector !== "undefined") {
			 					extractedData.claveElector = response.persona.claveLector;
			 				} else if(typeof response.persona.ClaveElector !== "undefined") {
			 					extractedData.claveElector = response.persona.ClaveElector;
			 				} else {
			 					extractedData.claveElector = notFound;
			 				}
			 				
			 				// Extrayendo el folio de identificación.
			 				if(typeof response.persona.folio !== "undefined") {
			 					extractedData.folioIdentificacion = response.persona.folio; 
			 				} else if(typeof response.persona.Folio !== "undefined") {
			 					extractedData.folioIdentificacion = response.persona.Folio; 
			 				} else {
			 					extractedData.folioIdentificacion = notFound;
			 				}
			 				
			 				// Extrayendo la colonia.
			 				if(typeof response.persona.colonia !== "undefined") {
			 					extractedData.colonia = response.persona.colonia;
			 				} else if(typeof response.persona.Colonia !== "undefined") {
			 					extractedData.colonia = response.persona.Colonia;
			 				} else {
			 					extractedData.colonia = notFound;
			 				}
			 			}
		 			} catch(x) {}
		 				 			
		 			// Se obtuvo un año de vigencia.
		 			if(extractedData.vigencia != "" &&  extractedData.vigencia != notFound && 
		 					!isNaN(parseInt(extractedData.vigencia))) {
		 				var fechaVigOCR = "31/12/" + extractedData.vigencia;
		 				
		 				generalService.setArrayValue('fechaVigenciaIFE', fechaVigOCR);

		 				$rootScope.solicitudJson.cotizacion.clientes[0].fechaVigenciaIdentificacion = 
		 					REGEX_FECHA.test(fechaVigOCR) ? fechaVigOCR : "";
		 			} else {
		 				$rootScope.solicitudJson.cotizacion.clientes[0].fechaVigenciaIdentificacion = "";
		 			}
		 			
		 			// Se obtuvo un nombre.
		 			if(extractedData.nombre != "" && extractedData.nombre != notFound) {
		 				$rootScope.solicitudJson.cotizacion.clientes[0].nombre = extractedData.nombre.trim();
		 			}
		 			
		 			// Se obtuvo un apellido paterno.
		 			if(extractedData.patronimico != "" && extractedData.patronimico != notFound) {
		 				$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno = 
		 					extractedData.patronimico.trim();
		 			}
		 			
		 			// Se obtuvo un apellido materno.
		 			if(extractedData.matronimico != "" && extractedData.matronimico != notFound) {
		 				$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno = 
		 					extractedData.matronimico.trim();
		 			}
		 			
		 			// Se obtuvo un folio central.
		 			if(extractedData.folioCentral != "" && extractedData.folioCentral != notFound) {
		 				// Se respalda el Folio Central para su posterior uso.
	 					$rootScope.folioDigitalizacion = extractedData.folioCentral.trim();
		 			} else { 
		 				// Es AyPad.
	 					if(configuracion.so.ios) {
	 						$rootScope.folioDigitalizacion = -999;
	 					} else {
	 						// Para que se ponga vacío al momento de consumir HOMÓNIMOS
	 						$rootScope.folioDigitalizacion = undefined;
	 					}
		 			}
		 			
		 			// Habemus calle.
		 			if(extractedData.calle != "" && extractedData.calle != notFound) {
		 				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle = 
		 					extractedData.calle.substring(0,49).replace(REGEX_TEXTO, "");
		 			}
		 			
		 			// Habemus código postal.
		 			if(extractedData.cp != "" && extractedData.cp != notFound && extractedData.cp.length == 5) {
		 				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp = extractedData.cp;
		 			}
		 			
		 			// Habemos género.
		 			if(extractedData.genero != "" && extractedData.genero != notFound) {
		 				switch(extractedData.genero) {
			 				case 'M':
			 					$rootScope.solicitudJson.cotizacion.clientes[0].idGenero = "F";
			 					$rootScope.solicitudJson.cotizacion.clientes[0].genero = 
			 						$scope.getDescripcionCatalogo('F', $scope.generos);
			 					break;
			 				case 'H': 	 					
			 					$rootScope.solicitudJson.cotizacion.clientes[0].idGenero = "M";
			 					$rootScope.solicitudJson.cotizacion.clientes[0].genero = 
			 						$scope.getDescripcionCatalogo('M', $scope.generos);
			 					break;
			 				default: // Nothing to do.
		 				}
		 			}
		 			
		 			// Variable que determina si ya se ha obtenido una fecha de nacimiento válida.
		 			var fnOk = false;
		 			
		 			// Habemus fecha de nacimiento.
		 			if(extractedData.fechaNacimiento != "" && extractedData.fechaNacimiento != notFound) {
		 				try {
		 					var fnArray = extractedData.fechaNacimiento.split("/");
			 				
			 				fnOk = desglosaFechaNacimiento(fnArray[0] + fnArray[1] + fnArray[2]);
		 				} catch(x) {console.log("What happened, Miss Simone?");}
		 			}

		 			// Se intenta configurar el estado de nacimiento, con base a la CURP.
		 			if(extractedData.curp != "" && extractedData.curp != notFound) {
		 				try {
		 					var cveEdo = extractedData.curp.substring(11, 13).toUpperCase();
			 				var catalogoEdos = 
			 					MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.CATALOGO ESTADOS"];
			 				
			 				for(var i in catalogoEdos) {
			 					if(catalogoEdos[i].CLAVE.valor.toUpperCase() == cveEdo) {
			 						// Se configura la descripción del lugar de nacimiento.
			 						$rootScope.solicitudJson.cotizacion.clientes[0].lugarNacimientoDes = 
			 							catalogoEdos[i].ETIQUETA.valor;
			 						// Se configura el identificador del lugar de nacimiento.
			 						$rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento = 
			 							parseInt(catalogoEdos[i].ID.valor);
			 						break;
			 					}
			 				}
			 				
			 				// Se intenta obtener una fecha de nacimiento.
		 					possibleBday = extractedData.curp.substring(4, 10);
		 					
		 					// Se intenta sacar una fecha de nacimiento válida.
			 				if(!fnOk && !generalService.isEmpty(possibleBday) && !isNaN(parseInt(possibleBday))) {
			 					fnOk = desglosaFechaNacimiento(possibleBday);
			 				}
		 				} catch(x){console.log("What happened, Miss Simone?");}
		 			}
		 				 			
		 			// Habemus clave de elector.
		 			if(extractedData.claveElector != "" && extractedData.claveElector != notFound) {
		 				// Se configura la clave de elector del cliente.
		 				$rootScope.solicitudJson.cotizacion.clientes[0].claveElector = 
		 					generalService.checkLength(extractedData.claveElector, 18);
		 				
		 				if(!fnOk) {
		 					try {
		 		 				// Se obtiene una fecha de nacimiento mediante la subcadena de la clave de elector.
		 			 			possibleBday = claveElector.substring(6, 12);
		 			 			
		 			 			// A ver si se puede obtener una fecha de nacimiento.
		 			 			desglosaFechaNacimiento(possibleBday);
	 		 				} catch(x) {console.log("What happened, Miss Simone?");}
		 				}
		 			}
		 			
		 			// Habemus folio de identificación.
		 			if(extractedData.folioIdentificacion != "" && extractedData.folioIdentificacion != notFound) {
		 				// Se configura el folio de identificación del cliente.
			 			$rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion = 
			 				generalService.checkLength(extractedData.folioIdentificacion, 13);
		 			}
		 			
		 			// Habemus colonia.
		 			if(extractedData.colonia != "" && extractedData.colonia != notFound) {
		 				try {
		 				// Se configura la colonia.
				 		$rootScope.ocrColonia = extractedData.colonia.replace("COL ",'').toUpperCase().trim();
		 				} catch(x) {console.log("What happened, Miss Simone?");}
		 			}
		 			
		 			// Se configura la bandera que indica que se hizo OCR.
		 			$rootScope.ocrCapturado = true;
		 			
		 			// Se configuran los identificadores de registros en bóveda y las imágenes obtenidas.
		 			if(response.nombres != null && response.nombres.length > 0 
		 					&& response.imagenes != null && response.imagenes.length > 0) {
		 				generalService.setArrayValue('nomsImgIFE',response.nombres);
		 				generalService.setArrayValue('imgsIFE', response.imagenes);
		 			}
		 			
		 			// Se activa la bandera para indicar que se realizó OCR.
		 			$rootScope.solicitudJson.banderaOCR = 1;

		 			// Se desbloquean los campos del formulario.
		 			$scope.bloqueaInput = false;
		 		}	 			
	 		}
	 		
	 		/**
	 		 * Se guarda en una variable la concatenacion de todos los datos que se van a validar
	 		 * en el caso de que hayan sido editados en el simulador, la solicitud se va a ir
	 		 * por el flujo de Call Center. 
	 		 */
	 		$scope.ocrIfeOld = concatenaOCR($rootScope.solicitudJson.cotizacion.clientes[0], true);

	 		// Bye, bye Spinner!
	 		$rootScope.waitLoaderStatus = LOADER_HIDE; 
	 	};
	 	
	 	
	 	/**
	 	 * Funcion que realiza la concatenacion y lo guarda en una variable para revisar si esos datos fueron modificados
	 	 * una vez que se hizo OCR, si se edita un dato la solicitud se manda a flujo de callcenter
	 	 */	
	 	function concatenaOCR(persona, fechaNac) {
	 		var concatenaCadena; 
	 		
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].nombre;
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno;
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno;
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].genero;
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].idGenero;
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].lugarNacimientoDes;
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento;
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion;
	 		
	 		if(fechaNac) {
	 			concatenaCadena = concatenaCadena + $scope.nDia + "/" + $scope.nMes + "/" + $scope.nAnno;
	 		} else {
	 			concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento;
	 		}
	 		
	 		return concatenaCadena;
	 	};
	 	
	 	$scope.limpiardatosIdentificacion = function(bandera) {
	 		if(bandera == 1) {
	 			$scope.folioIdent.obligatorio = true;
				$scope.claveElector.obligatorio = true;
				
				if($rootScope.solicitudJson.banderaOCR == 1) {
		 			$scope.bloqueaInput = false;
		 		} else {
		 			if($scope.ocrRequired) {
		 				$scope.bloqueaInput = true;
		 			} else {
		 				$scope.bloqueaInput = false;
		 			}
		 		}
	 		} else if(bandera == 0 || bandera == 2) {
	 			$scope.folioIdent.obligatorio = false;
				$scope.claveElector.obligatorio = false;
				
				$scope.bloqueaInput = false;
	 		} 
	 		
	 		
	 		
			

	 		/**
	 		 * Esta validacion funciona para habilitar un mensaje en la vista que indica que se deben verificar el folio y la clave que extrajo el OCR
	 		 */
	 		$rootScope.ocrCapturado = $scope.doctoIdentificacion == 1 && $rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion != '' &&
	 		$rootScope.solicitudJson.cotizacion.clientes[0].claveElector != '' ? true : false;
	 		
	 	};
	 	
	 	
	 	function limpiarDatosOCR() {
 			$scope.nAnno = "";
 			$scope.nMes = "";
 			$scope.nDia = "";
	 		$rootScope.solicitudJson.cotizacion.clientes[0].fechaVigenciaIdentificacion = "";
	 		$rootScope.solicitudJson.cotizacion.clientes[0].nombre = "";
	 		$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno = "";
	 		$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno = "";
	 		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle = "";
	 		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp = "";
	 		$rootScope.solicitudJson.cotizacion.clientes[0].idGenero = "";
	 		$rootScope.solicitudJson.cotizacion.clientes[0].genero = "";
	 		$rootScope.solicitudJson.cotizacion.clientes[0].lugarNacimientoDes = "";
	 		$rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento = "";
	 		$rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion = "";
	 		
	 		// Se agrega este, que no se limpiaba.
	 		$rootScope.solicitudJson.cotizacion.clientes[0].claveElector = "";
	 		
	 		// Se vuelve el formulario a su forma pristina y sin haber sido tocado.
	 		$scope.forSimulador.$setPristine();
	 		$scope.forSimulador.$setUntouched();
	 	};
	 	
	 	/** fn: aammdd */
	 	function desglosaFechaNacimiento(fn){
	 		var cont = 0;
	 		
	 		if( fn.length == 6){
	 			var annio="", mes="", dia="";
		 		
		 		try{
		 			var anioActual = new Date().getFullYear().toString().substring(2);
					var anioFN = fn.substring(0,2);
					
					if( generalService.isEmpty($scope.nAnno)  ){
						if(generalService.isNumeric(anioFN)){
							if( parseInt(anioActual) < parseInt(anioFN) )
								annio = "19" + anioFN;				
							else
								annio = "20" + anioFN;
							
							$scope.nAnno = annio;
							cont++;
						}
						
					}else
						cont++;
					
										
					mes = fn.substring(2,4);
					if( generalService.isEmpty($scope.nMes)  ){
						if(generalService.isNumeric(mes)){
							var _mes = parseInt(mes);						
							if( _mes > 0 && _mes < 13){
								$scope.nMes = mes;
								cont++;
							}
						}												
					}else
						cont++;
					
					dia = fn.substring(4,6);
					if( generalService.isEmpty($scope.nDia) ){
						
						if( generalService.isNumeric(dia) ){
							var _dia = parseInt(dia);
							if( _dia > 0 && _dia < 32){
								$scope.nDia = dia;
								cont++;
							}
						}
						
					}else
						cont++;
																											
					
		 		}catch(e){
		 			$scope.nAnno=null;
		 			$scope.nMes=null;
		 			$scope.nDia=null;
		 			
		 		}
		 		
	 		}
	 			 		
	 		return (cont == 3)? true:false;							
	 	};
	 	
	 	
		
		$scope.getDescripcionCatalogo = function(id, lista){				
			return generalService.descripcionCatalogo(id, lista);
		};
		
		$scope.validaCodigo=function(forSimulador){
        //evento CAMBACEO 
			$rootScope.addEvent( BITACORA.SECCION.cambaceo.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.solicitar.id, 0, BITACORA.SECCION.cambaceo.guardarEnBD );
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) != -1){
				continuaValidaCodigo(forSimulador);
			}else if(contadorCel == 0){
				var num = {
						numTelefono: $scope.celular1.valor.split("(").join("").split(")").join("").split(" ").join(""),
					}

					$rootScope.waitLoaderStatus = LOADER_SHOW;
					solicitudService.validarNumTel(num).then(
							function(data) {
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								if(data.data.codigo == RESPONSE_CODIGO_EXITO){
									var jResponse = JSON.parse(data.data.respuesta);
									
									if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){							
										continuaValidaCodigo(forSimulador);	
									}else{
										$scope.celular1.valor="",
										$rootScope.message("AVISO ", ["Captura nuevamente el número de teléfono del cliente."],"Aceptar",null,"bgAzul", "azul");
									}
								}else{
									contadorCel++;
									$rootScope.message("AVISO ", ["Verifíca que el número telefónico este capturado correctamente."],"Aceptar",null,"bgAzul", "azul");
								}							
							}, function(error){
									$rootScope.waitLoaderStatus = LOADER_HIDE; 
									$rootScope.message("AVISO", [ ERROR_SERVICE, "Error "+jResponse.codigo],"Aceptar",null,"bgRojo", "rojoR");	
								}
							);
			}else{
				continuaValidaCodigo(forSimulador);
			}	
		};
		
		function continuaValidaCodigo(forSimulador){
			if($rootScope.solicitudJson.idProducto == 24){
				$rootScope.categoriaLinea = mapearDestinoJson($scope.ppDestino,$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto);
			}
			
			var bandAccesoMoto = 0;
			
			if($scope.doctoIdentificacion != 1) {
				/**
				 * Limpiar datos del OCR IFE/INE cuando se selecciona la opcion de pasaporte
				 */
				generalService.setArrayValue('nomsImgIFE', null);
	 			generalService.setArrayValue('imgsIFE', null);
				$rootScope.solicitudJson.banderaOCR = 0;
		 		$rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion = '';
		 		$rootScope.solicitudJson.cotizacion.clientes[0].claveElector = '';
			}
			/*
			if($rootScope.sucursalSession.idCanal == 10){
				var detCantidadMoto = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].cantidad;
				var detProductoMoto = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto;
				var detMontoMoto = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;
				var detEngancheMoto = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche;
				
				if(detCantidadMoto > 0 && detProductoMoto != "0" && detMontoMoto > 0 && detEngancheMoto >= 0){
					bandAccesoMoto = 0;
				}else{
					bandAccesoMoto = 1;
				}
				
			}
			*/
			if(bandAccesoMoto == 0){
//				if ($scope.origen=="TIENDA")
					$scope.consultaHomonimo();
//				else{
//					$scope.recaptcha=document.getElementById('recaptcha').value;
//					if ($scope.rString == $scope.recaptcha){		
//						$scope.consultaHomonimo();
//					}else{
//						$scope.image.clearRect(0,0,65,21);
//						$scope.creaCodigo();
//						document.getElementById('recaptcha').value='';
//						document.getElementById('recaptcha').focus();
//						$scope.endCotizador = false;
//						$scope.forSimulador.$invalid=true;
//					}
//				}
			}else{
				$rootScope.message( "Datos inválidos", ["Favor de seleccionar un producto del catálogo."] , "Aceptar",null,null,null,null,null,null);
			}
		};
		
		$scope.consultaHomonimo=function(){
			var fechaSel = $scope.nAnno + "/" + $scope.nMes + "/" + $scope.nDia;
			var fechaMin = yy75 + "/" + mm + "/" + dd;
			if (($scope.nAnno == yyyy && $scope.nMes > mm) || ($scope.nAnno == yyyy && $scope.nMes == mm && $scope.nDia > dd)){										
				$rootScope.message( "Datos inválidos", ["El cliente no cumple con la edad mínima requerida por las políticas internas, por lo cual, no es posible continuar con el proceso."] , "Aceptar", null, null, "botonSimulador",null,"GENERAL","EDAD MINIMA");
				$scope.endCotizador = false;
			}else{
				if (fechaSel <= fechaMin){										
					$rootScope.message( "Datos inválidos", ["El cliente supera la edad máxima definida en las políticas internas, por lo cual, no es posible continuar con el proceso."] , "Aceptar", null, null, "botonSimulador",null,"GENERAL","EDAD MAXIMA");
					$scope.endCotizador = false;
				}else{
					$scope.endCotizador = true;
					
					if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal)					
						$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto=$("#slider").slider( "value");
					if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.tarjetaCredito)
						$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto=$scope.montoLimite;
					
					$rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento=$scope.nDia + "/" + $scope.nMes + "/" + $scope.nAnno;
					generalService.calculaPorcentaje($rootScope)
					$rootScope.solicitudJson.tipoCampania = CASO_CELULAR;
					if (CASO_CELULAR == 3){
						$rootScope.solicitudJson.envioCelular = 1;
					}
					if (!$scope.celular1.valor && CASO_CELULAR != 1){
						modalService.telefonoModal(CASO_CELULAR).then(
							function(exito) {
								$scope.celular1.valor = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
								$timeout( function(){ 
						 			$scope.homonimos();
						 		}, 100);
							}, function(error) {
								$scope.celular1.valor = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
								$timeout( function(){ 
						 			$scope.homonimos();
						 		}, 100);
							}
						);
					}else{
						$scope.homonimos();
					}
				}
			}
		};
						
		$scope.actualizaCaptcha = function(){
			$scope.image.clearRect(0,0,65,21);
			$scope.creaCodigo();
			document.getElementById('recaptcha').value='';
			document.getElementById('recaptcha').focus();
			$scope.endCotizador = false;
			$scope.forSimulador.$invalid=true;
		}
				
	 	$scope.homonimos = function(){	 			 			 		
			$scope.endCotizador = true;
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			validateService.limpiaMascaras();						
			
//			if($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto==ID_PRODUCTO.modatelas+"" && $rootScope.sucursalSession.idCanal == CANALES.modatelas)
//				$scope.modatelas = true;
//			else
//				$scope.modatelas = false;
			
			if(generalService.isProdModatelas($rootScope)){
//				   $scope.modatelas = true;
//OLD_MOD				   $rootScope.solicitudJson.idProducto=ID_PRODUCTO.consumo;
//OLD_MOD				   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto=ID_PRODUCTO.modatelas+""
				   $rootScope.solicitudJson.cotizacion.idPlazo=6;
				   $rootScope.solicitudJson.cotizacion.plazo=100;
				   
			}else if($rootScope.solicitudJson.idProducto != ID_PRODUCTO.tarjetaCredito){
				$rootScope.solicitudJson.cotizacion.clientes[0].idNacionalidad = 0;				
				$rootScope.solicitudJson.cotizacion.clientes[0].nacionalidadDes = "";
			}
				
			var tipoBus= $rootScope.consultaFuncionalidad.habilitarBusquedaFoneticaCambaceo;
			
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) != -1 || !isProduccion || ($rootScope.campanasPreaprobados($rootScope.solicitudJson.campana) || $rootScope.promocionCampanas($rootScope.solicitudJson.campana) || $rootScope.promocionCampanas($scope.campanaTDC)) || $scope.bloqueaDatosreac)
				tipoBus='1';
// I-MODIFICACION TDC (NUEVOS CONTRATOS PARA TDC)
			
			if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
				$scope.respaldoJson.idProducto = $scope.productoSeleccionado;
				$rootScope.solicitudJson.cotizacion.plazo = 0;
				$rootScope.solicitudJson.cotizacion.montoTotal = 0;
				$scope.respaldoJson.tarjetasCredito =  
				{"tarjetaOro": {
			    	"limiteCreditoComprobable":0.0,
			    	"limiteCreditoNoComprobable": isNaN($scope.limiteCredito)? 0.0 : parseFloat($scope.limiteCredito),
			    	"numeroTarjeta":"-",
			    	"estatusDomicializacion":"-",
			    	"numeroCuenta":"-",
			    	"estadoEntrega":0,
			    	"campana": $scope.campanaTDC,
			    	"estadoCampana" : $scope.statusCampanaTDC,
			    	"socioElektra": $scope.foliioPre.empleadoEkt
			    	}
				};
				if ($scope.respaldoJson.contratos.contrato.length == 4){
					$scope.respaldoJson.contratos.contrato[3].descripcion =  "Contrato de la Tarjeta de Crédito "+ $rootScope.camelize($rootScope.descTarjetas($scope.respaldoJson.idProducto).desc);
					$scope.respaldoJson.contratos.contrato[2].descripcion = "Solicitud de la Tarjeta de Crédito "+ $rootScope.camelize($rootScope.descTarjetas($scope.respaldoJson.idProducto).desc);
					var contratos = CONTRATOS_TARJETAS[0];
					contratos.descripcion = contratos.descripcion + " " + $rootScope.camelize($rootScope.descTarjetas($scope.respaldoJson.idProducto).desc);
					$scope.respaldoJson.contratos.contrato.push(contratos);
					$scope.respaldoJson.contratos.contrato.push(CONTRATOS_TARJETAS[1]);
					$scope.respaldoJson.contratos.contrato.push(CONTRATOS_TARJETAS[2]);					
				}
				
			}
// F-MODIFICACION TDC (NUEVOS CONTRATOS PARA TDC)

			
// Inicio - Verificamos que el Genero no este vacío 
			
			if($rootScope.solicitudJson.cotizacion.clientes[0].genero == ""){
				
				switch($rootScope.solicitudJson.cotizacion.clientes[0].idGenero){
				case 'F': 
					$rootScope.solicitudJson.cotizacion.clientes[0].genero = $scope.getDescripcionCatalogo('F',$scope.generos);
					break;
				case 'M': 	 					
					$rootScope.solicitudJson.cotizacion.clientes[0].genero = $scope.getDescripcionCatalogo('M',$scope.generos);
					break;
				}
				
			}
			
// Fin - Verificamos que el Genero no este vacío
			
			
//			$scope.ocrIfeNew = concatenaOCR($rootScope.solicitudJson.cotizacion.clientes[0], false);
			
//			$rootScope.solicitudJson.tipoIdentificacion = $scope.doctoIdentificacion;
			$rootScope.solicitudJson.marca = 5011;
			
			$rootScope.solicitudJson.datosCambaceo = {
					"datosCambaceo": 0,
					"clientePresente": 0,
					 "fechaClientePresente": ""
			}
			
			$rootScope.solicitudJson.contratos.contrato[0].statusFirma = STATUS_CONTRATO.SIN_FIRMA;
			$rootScope.solicitudJson.contratos.contrato[1].statusFirma = STATUS_CONTRATO.SIN_FIRMA;
			
			$scope.respaldoJson = $rootScope.solicitudJson;
			
			var consulta = $rootScope.consultaFuncionalidad.habilitarBusquedaFoneticaCambaceo;
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) != -1 )
				var consulta='1';
				
			var x = {
					solicitudJson: JSON.stringify($scope.respaldoJson),
					busquedaFonetica: consulta,
					consulta: '0', 
					tipoIdentificacion: 0,
					statusOcr: 0,
					// Estadísticas para OCR.
					folioDigitalizacion: $rootScope.folioDigitalizacion != undefined ? 
							$rootScope.folioDigitalizacion : "" 
			}
			
			renapoFirst(x);
	 	};
	 	
	 	function notRequiredCURP(curpValida) {
			if (!!!curpValida) {
				try {
					$rootScope.solicitudJson.cotizacion.clientes[0].curp = '';
					$scope.placeholderCURP = "Verifica que la CURP capturada sea válida (este dato es opcional)";
					
					$timeout(function() { $scope.forSimulador.curp.$touched = false; }, 0);
				} catch(Q) { console.log('¡Órale! ¿Por qué no hacemos una tranza?'); }
			}
		}
	 	
	 	/**
		 * Función para consultar la correctez de una CURP.
		 */
		function validaCURP(curp) {
			// Es una cadena de 18 caracteres.
			if(typeof curp === 'string' && curp.length == 18) {
				let pieces = [
					'^([A-Z][AEIOUX][A-Z]{2}\\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\\d|3[01])[HM]',
					'(?:AS|B[CS]|C[CLMSH]|D[FG]|G[TR]|HG|JC|M[CNS]|N[ETL]|OC|PL|Q[TR]|S[PLR]|T[CSL]|VZ|YN|ZS)',
					'[B-DF-HJ-NP-TV-Z]{3}[A-Z\\d])(\\d)$'
				];
				
				let CURP_VALIDA = RegExp(pieces.join(''));
				
				// Tiene formato de CURP.
				if(CURP_VALIDA.test(curp)) {
					/**
					 * El match devuelve un arreglo de la siguiente manera:
					 * 0 - Toda la CURP.
					 * 1 - La CURP menos el último dígito.
					 * 2 - El último dígito.
					 */
					var fragmentos = curp.match(CURP_VALIDA);
					
					var digitoVerificador = function(curp17caracteres) {
						if(typeof curp17caracteres === 'string' && curp17caracteres.length == 17) {
							var diccionario = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ";
							var lngSuma = 0.0, lngDigito = 0.0;
							
							for(var i = 0; i < 17; i++) {
								lngSuma += diccionario.indexOf(curp17caracteres.charAt(i)) * (18 - i);
							}
							
							lngDigito = 10 - (lngSuma % 10);
							
							return lngDigito == 10 ? 0 : lngDigito;
						}
					};
					
					return fragmentos[2] == digitoVerificador(fragmentos[1]);
				}
			}
			
			return false;
		}
	 	
	 	function algunasConsideraciones(objeto) {
	 		// Es un JSON.
	 		if (objeto && typeof objeto === 'object') {
	 			// Se eligió sólo apellido paterno.
	 			if ($scope.check1SolicitarModel && !$scope.check2SolicitarModel) { // Esto, por si las flies.
	 				if (objeto.apellidoMaterno) {
	 					objeto.apellidoMaterno = '';
	 				}
	 			}
	 			
	 			// Se eligió sólo apellido materno.
	 			if ($scope.check2SolicitarModel && !$scope.check1SolicitarModel) { // Esto, por si las flies.
	 				if (objeto.apellidoMaterno) {
	 					objeto.apellidoPaterno = objeto.apellidoMaterno;
	 					objeto.apellidoMaterno = '';
	 				}
	 			}
	 		}
	 	}
	 	
	 	function porFavorHazmeFeliz(response) {
	 		// Es un JSON.
	 		if (response && typeof response === 'object') {
	 			let fails = Object.getOwnPropertyNames(response);
	 			
	 			if (Array.isArray(fails) && fails.length > 0) {
	 				// Se eligió sólo apellido materno.
		 			if ($scope.check2SolicitarModel && !$scope.check1SolicitarModel) { // Esto, por si las flies.
		 				// Trae apellido paterno y no trae apellido materno.
		 				if (fails.includes('apellido_paterno') && !fails.includes('apellido_materno')) {
		 					// Convertimos apellido paterno en materno.
		 					response.apellido_materno = response.apellido_paterno;
		 					// Borramos la llave de apellido paterno.
		 					delete response.apellido_paterno;
		 				} else if (fails.includes('apellido_paterno') && fails.includes('apellido_materno')) {
		 					/**
		 					 * Si trae ambos apellidos, sabiendo que la consulta se hizo de forma cruzada, hay que 
		 					 * realizar un switch de propiedades.
		 					 */
		 					
		 					let temp = response.apellido_materno;
		 					response.apellido_materno = response.apellido_paterno;
		 					response.apellido_paterno = temp;
		 				} else { console.log('A ver, a ver, ¿qué pasó aquí?'); }
		 			}
	 			}
	 		}
	 	}
	 	
	 	function renapoFirst(renapoCambaceoParams) {
	 		// Si el usuario es un provilegiado, se consume directamente el servicio de homónimos.
	 		if (($rootScope.userSession && $rootScope.userSession.noEmpleado && typeof TEST_EMPLOYEES === 'string'
	 			&& TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString())) != -1 || TIPO_BUSQUEDA == 1) {
	 			ejecutarConsultaRenapoCambaceo(renapoCambaceoParams);
	 			
	 			return;
	 		}
	 		
	 		let nombre, apellidoPaterno, apellidoMaterno, fechaNacimiento, sexo, entidadFederativa, curp;
	 		
	 		if ($rootScope.solicitudJson && $rootScope.solicitudJson.cotizacion 
				&& Array.isArray($rootScope.solicitudJson.cotizacion.clientes)
				&& $rootScope.solicitudJson.cotizacion.clientes[0]) {
	 			let cliente = $rootScope.solicitudJson.cotizacion.clientes[0];
	 			
	 			nombre = cliente.nombre;
	 			apellidoPaterno = cliente.apellidoPaterno;
	 			apellidoMaterno = cliente.apellidoMaterno;
	 			fechaNacimiento = cliente.fechaNaciomiento;
	 			sexo = cliente.idGenero;
	 			entidadFederativa = cliente.idLugarNacimiento;
	 			
	 			curp = validaCURP(cliente.curp) ? cliente.curp : '';
	 			
	 			if (typeof fechaNacimiento === 'string' && fechaNacimiento.length > 0) {
	 				let split = fechaNacimiento.split('/');
	 				
	 				fechaNacimiento = '';
	 				
	 				if (Array.isArray(split) && split.length == 3) {
	 					if (!isNaN(+split[0] + +split[1] + +split[2])) {
	 						split[0] = ('00' + +split[0]).slice(-2);
	 						split[1] = ('00' + +split[1]).slice(-2);
	 						split[2] = ('0000' + +split[2]).slice(-4);
	 						
	 						fechaNacimiento = split[2] + '-' + split[1] + '-' + split[0];
	 					}
	 				}
	 			}
	 		}
	 		
	 		if (nombre && (apellidoPaterno || apellidoMaterno) && fechaNacimiento && sexo && entidadFederativa) {
	 			let input = { nombre, apellidoPaterno, apellidoMaterno, fechaNacimiento, sexo, entidadFederativa, curp };
	 			
	 			algunasConsideraciones(input);
	 			
	 			solicitudService.primeroConsultaRENAPO(input).then(
 		 			function(success) {
 		 				if (success && success.data && success.data.codigo == RESPONSE_CODIGO_EXITO) {
 		 					let response;
 		 					
 		 					try {
 		 						response = JSON.parse(success.data.respuesta);
 		 					} catch(Q) { console.log('La respuesta no es parseable'); }
 		 					
 		 					if (response && response.codigo == 2) { //Éxito rotundo.
 		 						ejecutarConsultaRenapoCambaceo(renapoCambaceoParams);
 		 						
 		 						return;
 		 					} else if (response && response.codigo == 99) {
 		 						if (response.data) {
 		 							porFavorHazmeFeliz(response.data);
 		 							
 		 							let name, patronymic, matronymic, birthday, gender, state_of_birth;
 		 							
 		 							// Todo es falso, a priori.
 		 							name = patronymic = matronymic = birthday = gender = state_of_birth =false;
 		 							
 		 							// Se activarán las banderas correspondientes.
 		 							for (let prop in response.data) {
 		 								switch(prop) {
 		 									case 'nombre': name = true; break;
 		 									case 'apellido_paterno': patronymic = true; break;
 		 									case 'apellido_materno': matronymic = true; break;
 		 									case 'fecha_nacimiento': birthday = true; break;
 		 									case 'sexo': gender = true; break;
 		 									case 'estado_nacimiento': state_of_birth = true; break;
 		 									default: console.log('Ah, esto no estaba mapeado.');
 		 								}
 		 							}
 		 							
 		 							if ($rootScope.solicitudJson && $rootScope.solicitudJson.cotizacion 
 		 								&& Array.isArray($rootScope.solicitudJson.cotizacion.clientes)
 		 								&& $rootScope.solicitudJson.cotizacion.clientes[0]) {
 		 								let cliente = $rootScope.solicitudJson.cotizacion.clientes[0];
 		 								
 		 								if ($scope.forSimulador) {
 		 									if (name) {
 		 										if ($scope.nombre && $scope.nombre.campo) {
 		 											cliente.nombre = response.data.nombre;
 		 											$timeout(function() { // Para que Angular 'note' el cambio.
 		 												$scope.forSimulador[$scope.nombre.campo].$invalid = true;
 		 											});
 		 										}
 		 									}
 		 									
 		 									if (patronymic) {
 		 										if ($scope.aPaterno && $scope.aPaterno.campo) {
 		 											cliente.apellidoPaterno = response.data.apellido_paterno;
 		 											$timeout(function() { // Para que Angular 'note' el cambio.
 		 												$scope.forSimulador[$scope.aPaterno.campo].$invalid = true;
 		 											});
 		 										}
 		 									}
 		 									
 		 									if (matronymic) {
 		 										if ($scope.aMaterno && $scope.aMaterno.campo) {
 		 											cliente.apellidoMaterno = response.data.apellido_materno;
 		 											$timeout(function() { // Para que Angular 'note' el cambio.
 		 												$scope.forSimulador[$scope.aMaterno.campo].$invalid = true;
 		 											});
 		 										}
 		 									}
 		 									
 		 									if (birthday) {
 		 										if ($scope.mDia && $scope.mMes && $scope.mAnio) {
 		 											let fecha_renapo;
 		 											
 		 											try {
 		 												fecha_renapo = response.data.fecha_nacimiento.split('/');
 		 											} catch(x) { console.log('No se puede partir la fecha.'); }
 		 											
 		 											if (Array.isArray(fecha_renapo) && fecha_renapo.length == 3) {
 		 												if (+$scope.nDia != +fecha_renapo[0]) {
 		 													$scope.nDia = +fecha_renapo[0].toString();
 		 													$timeout(function() { // Para que Angular 'note' el cambio.
 		 														$scope.forSimulador[$scope.mDia.campo].$invalid = true;
 		 													});
 		 												}
 		 												
 		 												if (+$scope.nMes != +fecha_renapo[1]) {
 		 													$scope.nMes = +fecha_renapo[1].toString();
 		 													$timeout(function() { // Para que Angular 'note' el cambio.
 		 														$scope.forSimulador[$scope.mMes.campo].$invalid = true;
 		 													});
 		 												}
 		 												
 		 												if (+$scope.nAnno != +fecha_renapo[2]) {
 		 													$scope.nAnno = +fecha_renapo[2].toString();
 		 													$timeout(function() { // Para que Angular 'note' el cambio.
 		 														$scope.forSimulador[$scope.mAnio.campo].$invalid = true;
 		 													});
 		 												}
 		 											}
 		 										}
 		 									}
 		 									
 		 									if (gender) {
 		 										if ($scope.genero) {
 		 											cliente.idGenero = response.data.sexo == 'H' ? 'M' : 
 		 												response.data.sexo == 'M' ? 'F' : cliente.idGenero;
 		 											// El ng-change ejecutaría esta acción, también, pero... ¡qué rayos!
 		 											cliente.genero = $scope.getDescripcionCatalogo(cliente.idGenero, 
 		 													$scope.generos);
 		 											$timeout(function() { // Para que Angular 'note' el cambio.
 		 												$scope.forSimulador[$scope.genero.campo].$invalid = true;
 		 											});
 		 										}
 		 									}
 		 									
 		 									if (state_of_birth) {
 		 										cliente.idLugarNacimiento = response.data.estado_nacimiento;
 		 										// El ng-change ejecutaría esta acción, también, pero... ¡qué rayos!
 		 										cliente.lugarNacimientoDes = $scope.getDescripcionCatalogo(
 		 											cliente.idLugarNacimiento, $scope.lugaresNacimiento);
 		 										$timeout(function() { // Para que Angular 'note' el cambio.
	 												$scope.forSimulador.lugarNacimiento.$invalid = true;
	 											});
 		 									}
 		 								}
 		 								
 		 								if (validaCURP(response.data.curp)) {
 		 									cliente.curp = response.data.curp;
 		 								}
 		 							}
 		 						}
 		 						
 		 						$rootScope.waitLoaderStatus = LOADER_HIDE;
 		 						
 		 						$rootScope.message("¡Atención!",
 		 							["Verifica que los datos de tu cliente, extraídos del Registro Nacional de Población" 
 		 								+ ", sean correctos."], "Aceptar");
 		 						
 		 						$scope.endCotizador = contador_renapo-- ? false : true;
 		 						
 		 						return;
 		 					} else if (response && response.codigo == 661) { 
 		 						$rootScope.waitLoaderStatus = LOADER_HIDE;
 		 						
 		 						$rootScope.message("¡Atención!",
 		 							["La persona no fue encontrada en el Registro Nacional de Población.",
 		 								"Por favor, verifique los datos ingresados."], "Aceptar");
 		 						
 		 						$scope.endCotizador = contador_renapo-- ? false : true;
 		 						
 		 						return;
 		 					} else { console.log('No fue un código 2 ni un código 99 ni un código 661'); }
 		 				}
 		 				
 		 				// Se había subido el spinner, so, hay que bajarlo 'para abajo'.
 						$rootScope.waitLoaderStatus = LOADER_HIDE;
 						// Se había activado esta bandera, so, hay que desactivarla.
 						$scope.endCotizador = false;
 						
 						$rootScope.message('Modelo de Originación Centralizada', 
 							['Se tuvo un inconveniente al consumir el servicio para consultar el RENAPO.', 
 								'Favor de contactar al administrador del sistema.'], 
 							'Aceptar'
 						);
 		 			}, function(unsuccess) {
 			 			// Se había subido el spinner, so, hay que bajarlo 'para abajo'.
 						$rootScope.waitLoaderStatus = LOADER_HIDE;
 						// Se había activado esta bandera, so, hay que desactivarla.
 						$scope.endCotizador = false;
 						
 						$rootScope.message('Modelo de Originación Centralizada', 
 							['Se tuvo un inconveniente al consumir el servicio para consultar el RENAPO.', 
 								'Favor de contactar al administrador del sistema.'], 
 							'Aceptar'
 						);
 		 			}
 		 		);
	 		} else {
	 			// Se había subido el spinner, so, hay que bajarlo 'para abajo'.
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				// Se había activado esta bandera, so, hay que desactivarla.
				$scope.endCotizador = false;
				
				$rootScope.message('Modelo de Originación Centralizada', 
					['No se pudieron reunir todos los elementos para consumir el servicio para consultar el RENAPO.', 
						'Favor de contactar al administrador del sistema.'], 
					'Aceptar'
				);
	 		}
	 	}
	 	
	 	function ejecutarConsultaRenapoCambaceo(x) {
	 		if(generalService.isEmpty($rootScope.solicitudJson.idSolicitud)){
				clienteUnicoService.consultaRenapo( x ).then(
						function(data){
							// $rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								if( !generalService.isEmpty(data.data.respuesta.ticket) ){
			            			sessionService.getObjSessionId( data.data.respuesta.ticket ).then(
			        					function(data){ // EXITO
			        		               	if(data.data.codigo == RESPONSE_CODIGO_EXITO){
			        		                		$rootScope.inSession = true;
			        		                		$rootScope.userSession = data.data.respuesta.datosUsuario;  
			        		                		$rootScope.sucursalSession = data.data.respuesta.datosSucursal;		                		                		
			        		                		
			        		               		var key = generalService.keyEmpBase64();	        		                		
			        		               		securityService.setKeys(key, key);
			        		               		
			        		               		/**
									    		 * Servicio para consulta la funcionalidad por sucursal
									    		 * Se ejecuta en caso de no tener una sesion activa
									    		 * La regla para este caso es que solo hay caso de exito
									    		 **/
			        		               		loginService.consultaFuncionalidad({idPais:data.data.respuesta.datosSucursal.idPais, idSucursal:data.data.respuesta.datosSucursal.idSucursal, idCanal:data.data.respuesta.datosSucursal.idCanal}).then(
		        		               				function(objetoFuncionalidad) {
		        		               					if(objetoFuncionalidad.data.codigo == RESPONSE_CODIGO_EXITO) {
		        		               						var jsonResponseFuncionalidad = JSON.parse(objetoFuncionalidad.data.respuesta);
		        		               						if(jsonResponseFuncionalidad.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
		        		               							/**
			    												 * En caso de exito se mapea el objeto "consultaFuncionalidad" y continua al Menu
			    												 **/
		        		               							$rootScope.consultaFuncionalidad =  jsonResponseFuncionalidad.data;
		        		               						}else{
		        		               						}
		        		               					}else{
		        		               				  }
		        		               				}, function(error) {
		        		               				}
			        		               		);
			        		               	}
			        	    			},function(error){ // ERROR
			        	    				tmpModatelas();
			    	    	                $rootScope.waitLoaderStatus = LOADER_HIDE;
			        	    			}
			            			);
								}
								
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								var jResponse = JSON.parse(data.data.respuesta);
								
								switch(jResponse.codigo){
								case RESPONSE_ORIGINACION_CODIGO_EXITO:
									$scope.endCotizador = false;
									$rootScope.solicitudJson = jResponse.data;
									
									try{
										if(($rootScope.solicitudJson.idProducto == PRODUCTOS.consumo.ID.valor || $rootScope.solicitudJson.idProducto == PRODUCTOS.italika.ID.valor || $rootScope.solicitudJson.idProducto == PRODUCTOS.telefonia.ID.valor || $rootScope.solicitudJson.idProducto == PRODUCTOS.prestamoPersonal.ID.valor) &&
											(($rootScope.presupuestoC3Servicio != null && $rootScope.presupuestoC3Servicio != "" && $rootScope.presupuestoC3Servicio.fcFolioParam != "" && $rootScope.presupuestoC3Servicio.fcFolioParam != undefined && $rootScope.presupuestoC3Servicio.fcFolioParam.length > 0) || ($rootScope.categoriaLinea != null && $rootScope.categoriaLinea != "" && $rootScope.categoriaLinea.linea != "" && $rootScope.categoriaLinea.subLinea != undefined && $rootScope.categoriaLinea.linea > 0 && $rootScope.categoriaLinea.subLinea > 0 && $rootScope.categoriaLinea.montoDeseado != undefined && $rootScope.categoriaLinea.montoDeseado != "" && $rootScope.categoriaLinea.montoDeseado.replace(/[,$]/g,"").trim() > 0))
										){
											var jsonRequest = {
												"idSolicitud": $rootScope.solicitudJson.idSolicitud, 
												"idPais": $rootScope.solicitudJson.idPais,
												"idCanal": $rootScope.solicitudJson.idCanal,
												"idSucursal": $rootScope.solicitudJson.idSucursal,
												"idPresupuesto": ($rootScope.presupuestoC3Servicio != undefined)?$rootScope.presupuestoC3Servicio.fcFolioParam:0,
												"idLinea": ($rootScope.categoriaLinea.linea != undefined)? $rootScope.categoriaLinea.linea:0 ,
												"idSubLinea": ($rootScope.categoriaLinea.subLinea != undefined)? $rootScope.categoriaLinea.subLinea:0,
												"idProducto": $rootScope.solicitudJson.idProducto,
												"montoDeseado": ($rootScope.categoriaLinea.montoDeseado != undefined) ? $rootScope.categoriaLinea.montoDeseado.replace(/[,$]/g,"").trim() : 0 
											};
											
											$rootScope.presupuestoC3Servicio = undefined;
											$rootScope.categoriaLinea = {linea: 0,lineaDes: "",subLinea: 0,subLineaDes: "",montoDeseado: ""};
											
											$rootScope.waitLoaderStatus = LOADER_SHOW;
											solicitudService.guardarPresupuesto(jsonRequest).then(
												function(data) {
													$rootScope.waitLoaderStatus = LOADER_HIDE;
													/**
													 * Se crea esta función para parametrizar la funcionalidad cuando entra a la función por producto
													 **/
													continuaFlujoHomonimos();
													
											}, function(error) {
												$rootScope.waitLoaderStatus = LOADER_HIDE;
											});
										}else{
											continuaFlujoHomonimos();
										}
									}catch(e){
										continuaFlujoHomonimos();
										$rootScope.loggerIpad("No se guardó presupuesto", e);
									}
			                		break;
								case 316:
									$scope.endCotizador = false;
									$rootScope.message("Aviso ", ["Se encontró una solicitud en proceso, por lo cual no " +
											"se puede originar una nueva solicitud de cambaceo"],"Aceptar",null,null,null,null);
									break;
								case 661:
									$scope.endCotizador = false;
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									$rootScope.message("Aviso ", ["Por favor verifica los datos de tu cliente debido a que no se encuentra en el Registro Nacional de Población."],"Aceptar",null,null,null,null);
									break;
								case 820:
									var fechaTotal = generalService.getFechaRecuperacionSolicitudRechazada(jResponse.data.diasRechazo, 61);
									$rootScope.message( "AVISO", ["Infórmale a tu cliente que tiene una solicitud rechazada, podrá solicitar una nueva hasta el " +
											"día: "+fechaTotal], "Aceptar", "/simulador", null, null, null, null, null);
									break;
								case 912:
									$scope.endCotizador = false;
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									$rootScope.message("Aviso ", ["Por políticas internas no es posible continuar con el proceso"],"Aceptar",null,null,null,null);
									break;
								case 4003:
									modalService.confirmModal("Solicitud en Proceso", ["Tiene una solicitud de cambaceo en proceso ¿Desea recuperarla y continuar?"], 
											"NO", "SI").then(
													function(exito){
														$scope.recuperaSolicitud(jResponse.data);
													},function(error){
														$scope.endCotizador = false;										  														
													}
											);
									break;
								case 4006:
									$scope.endCotizador = false;
									$rootScope.message("Aviso",["Infórmale a tu cliente que tiene una solicitud rechazada previamente, para poder " +
											"solicitar una nueva es necesario que acuda a sucursal para continuar con su trámite"],"Aceptar",null,null,null,null,null,null);
									break;
								default:
										$scope.endCotizador = false;
										$rootScope.message("Aviso", ["Se produjo un error al generar la solicitud. Favor de " +
												"intentar nuevamente"],"Aceptar",null,null,null,null,null,null);
								}
							
							
							}else{
		// I-MODIFICACION TDC (LIMPIAR CAMPOS)					
								if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto))
									$scope.solicitudJson.idProducto = ID_PRODUCTO.tarjetaCredito;
		// F-MODIFICACION TDC (LIMPIAR CAMPOS)	
								tmpModatelas();
								$scope.endCotizador = false;
								$rootScope.loggerIpad("Respuesta Servicio originación de cambaceo", generalService.displayMessage(data.data.descripcion));
								$rootScope.message("Error " + data.data.codigo, [generalService.displayMessage(data.data.descripcion)], "Aceptar");	
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								
								// Desconfigurar el campo de folioCentral.
								$rootScope.folioDigitalizacion = undefined;
							}
						}, function(error){
		// I-MODIFICACION TDC (LIMPIAR CAMPOS)						
							if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto))
								$scope.solicitudJson.idProducto = ID_PRODUCTO.tarjetaCredito;
		// F-MODIFICACION TDC (LIMPIAR CAMPOS)							
							tmpModatelas();
							$scope.endCotizador = false;
							$rootScope.waitLoaderStatus = LOADER_HIDE; 	
							
							// Desconfigurar el campo de folioCentral.
							$rootScope.folioDigitalizacion = undefined;
						}
					);
			}else{
				envioDocumentosEnLinea($scope.arrCambaceo, 0);
			}
	 	}
	 	
	 	function continuaFlujoHomonimos(){
	 		if($scope.isTienda)
				newFlowRelease();
			else
				generalService.locationPath("/ochoPasos");
	 	}
	 	
	 	/**
	 	 * Esta función se encarga de invocar el servicio que genera el Aviso de Privacidad después del
	 	 * Rechazo de RENAPO o INE.
	 	 * Una vez invocado no se puede hacer mucho, ni en caso de éxito, ni en caso de error.
	 	 * Es un método silente, entonces, no hay que dar Feedback al usuario.
	 	 */
	 	function generarAvisoPrivacidadRechazoRENAPO() {
	 		// Se toma la firma del Aviso de Privacidad.
	 		var b64FirmaAviso = $rootScope.imgPrivacidad.replace("data:image/png;base64,", "").trim();
	 		
	 		// Se construye el JSON de entrada para el consumo del servicio.
	 		var x = {
	 			"jsonSolicitud": JSON.stringify($rootScope.solicitudJson),
	 			"fotoB64": b64FirmaAviso ? b64FirmaAviso : ""	 			
	 		};
	 		
	 		// Se realiza el consumo sigiloso.
	 		solicitudService.generarAvisoPrivacidadRechazoRENAPO(x).then(
					function(data) {
						// Se deja constancia en los logs.
						$rootScope.loggerIpad("generarAvisoPrivacidadRechazoRENAPO", data);
					}, function(error) {
						// Se deja constancia en los logs.
						$rootScope.loggerIpad("generarAvisoPrivacidadRechazoRENAPO", error);
					}
				);
	 	};
	 	
	 	var tmpModatelas = function(){
	 		if(generalService.isProdModatelas($rootScope)){
	 			$rootScope.solicitudJson.idProducto=ID_PRODUCTO.modatelas;
	 			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto="0";
	 		}
	 	};
	 	
	 	
	 	var validaHuella = function(cuArray){
	 		$rootScope.waitLoaderStatus = LOADER_SHOW;
	 		if (configuracion.origen.tienda )
				$rootScope.verificarHuella( 'simulador', 'responseVerificarHuellaIpad', cuArray );
			
			else{
				if( generalService.isProduccion() ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					modalService.huellaModal("bgAzul");
				}else{
					var response = { 
							codigo : VALIDA_HUELLA_RESPONSE.EXITO,
							matches: cuArray
							//matches: ["1-53-365-3608","1-1-4737-239","1-1-4737-244","1-1-4737-267","1-1-4737-268","1-1-4737-273","1-1-4737-282","1-1-4737-286","1-1-4737-289","1-1-4737-312"]
					}	
					$scope.responseVerificarHuellaIpad(response);
				}
					
			}
	 	};
	 	
	 	$scope.responseEnvioFirmas = function( responseIPAD )
		{

			try{
				
				if( responseIPAD.codigo == 0 ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					// $rootScope.message("CONTRATOS",[ "Correcto para guardar
					// firmas." + JSON.stringify(responseIPAD)], "Aceptar",
					// null);
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Error al encolar archivos." + JSON.stringify(responseIPAD)], "Aceptar", null);
					
				}
				
			}catch(e){
				console.log(e.message);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("CONTRATOS",[ "Error al encolar archivos."+e.message], "Aceptar", null);
				console.error( e.message );
				
			}
		};
	 	
	 	
			 	
	 	$scope.abrirDialogo = function(){		
	 		$rootScope.waitLoaderStatus = LOADER_HIDE;
	 		modalService.huellaModal("bgazul");
	 	};
			 	
		$scope.responseVerificarHuellaIpad = function( response ){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.loggerIpad("responseVerificarHuellaIpad", null, response);
				
				switch(response.codigo){
					case VALIDA_HUELLA_RESPONSE.EXITO:	
						
						if(codigoRespuestaHomonimos == 307){
						
							if(Array.isArray(response.matches)){
								response.matches = $.unique(response.matches);
							}else{
								response.matches = response.matches.replace(/(\[)|(\]| )/g,'').split(",");
							}
						
							getHomonimosBsqFonetica(response.matches);
							
						}else{
							if( $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id  && 
								     ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente ||
//								      $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazLigada ||		 
								      $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.certificadoItalikaActivado) && !generalService.isEmpty($rootScope.solicitudJson.diaPago) )
								
								if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazLigada){
									generalService.locationPath("/liberacion");
								}else{
									tarjetaService.checkInvetario($rootScope.solicitudJson);
								}
									
							
							else
								$scope.agregarIdentificacionOficial(generalService.getPathSection($rootScope.solicitudJson,$rootScope.sucursalSession.idCanal));
//								generalService.locationPath( generalService.getPathSection($rootScope.solicitudJson,$rootScope.sucursalSession.idCanal) );
						}
											
						break;
											
					case VALIDA_HUELLA_RESPONSE.ERROR:
						$scope.endCotizador = false;
						$rootScope.message("Error "+response.codigo,[ "Error al validar la huella."], "Aceptar");
						break;
						
					case VALIDA_HUELLA_RESPONSE.ERROR_COMPONENTE:
						$scope.endCotizador = false;
						$rootScope.message("Error "+response.codigo,[ "Error en componente de huella."], "Aceptar");
						break;
						
					case VALIDA_HUELLA_RESPONSE.COMPONENTE_CANCELADO_PORUSR:	
						$scope.endCotizador = false;
						break;
						
					case VALIDA_HUELLA_RESPONSE.NO_SE_ENCONTARON_HUELLAS:
						flujoCallCenter();											
						break;
						
					case VALIDA_HUELLA_RESPONSE.NO_HAY_COINCIDENCIAS:
						flujoCallCenter();	
						break;
						
					default:
						$scope.endCotizador = false;
						$rootScope.message( "Componete de huella", ["Código "+response.codigo+" no definido. "], "Aceptar");					
						break;
						
				}
										
							
		};
		
		
		
		function flujoCallCenter(){
			if($rootScope.promocionCampanas($scope.campanaTDC) || 
               $rootScope.promocionCampanas($rootScope.solicitudJson.campana) || 
			   $rootScope.campanasPreaprobados($rootScope.solicitudJson.campana) || 
			   ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto) && !CLIENTE_NUEVO_TDC) || 
			   $scope.bloqueaDatosreac){
							$rootScope.message( "AVISO", ["Por favor, antes de comenzar tu proceso de crédito debes acudir con un asesor financiero a realizar un mantenimiento de biométricos"], "Aceptar", "/menuWrapper");
							$rootScope.waitLoaderStatus = LOADER_HIDE; 
					}else{
				generalService.esValidoFlujoCallCenter($rootScope.solicitudJson);
			generalService.setArrayValue("pasoCallCenter", 'init')
			generalService.setArrayValue("encolarImagenes", true);
			generalService.setArrayValue("cusArray", cusArray);
			generalService.setArrayValue("pathOrigen", 'simulador');
			generalService.locationPath("/callCenter");
			}
		}
		
						
		
	 	
		function getHomonimosBsqFonetica(ctesUnicosArray) { // DATOS HOMONIMOS
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var requestJson = {
					tienda: $rootScope.sucursalSession.idSucursal,
					arrayCtesUnicos: ctesUnicosArray
			};

			clienteUnicoService.getHomonimosBsqFonetica(requestJson).then(
					function(data) {
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jsonResponse = JSON.parse(data.data.respuesta);
							
							if(jsonResponse.data != null){
								var clienteUnico = jsonResponse.data[0].fipais+ "-" + jsonResponse.data[0].ficanal + "-" + jsonResponse.data[0].fisucursal + "-" + jsonResponse.data[0].fifolio;
							}

							if(jsonResponse.codigo == HOMONIMOS.bloqueo 
									|| jsonResponse.codigo == HOMONIMOS.autSinLiberar 
									|| jsonResponse.codigo == HOMONIMOS.investigacion 
									|| jsonResponse.codigo == HOMONIMOS.autyLiberada) {

								var jsonActualizaMarca = {
										jsonSolicitud: $rootScope.solicitudJson, 
										marca: 1021,
										cu: jsonResponse.data[0].fipais+ "-" + jsonResponse.data[0].ficanal + "-" + jsonResponse.data[0].fisucursal + "-" + jsonResponse.data[0].fifolio
									};

								actualizaMarcaSol(jsonActualizaMarca);
							} else if(jsonResponse.codigo == HOMONIMOS.noCoincide 
									|| jsonResponse.codigo == HOMONIMOS.bloqueo 
									|| jsonResponse.codigo == HOMONIMOS.autSinLiberar 
									|| jsonResponse.codigo == HOMONIMOS.investigacion 
									|| jsonResponse.codigo == HOMONIMOS.rechazo 
									|| jsonResponse.codigo == HOMONIMOS.autyLiberada 
									|| jsonResponse.codigo == HOMONIMOS.sinCredito) {
								generalService.homonimosData=jsonResponse;
								generalService.locationPath("/homonimos");
							} else if(jsonResponse.codigo == HOMONIMOS.homonimoReact) {
								/*
								 * Se encontró homónimo con Línea de Crédito para flujo de 
								 * Reactivados.
								 * Antes se usaba la variable CLIENTE_REACTIVADO_LCR.
								 */
								generalService.homonimosData=jsonResponse;
								generalService.locationPath("/homonimos");
							} else if(jsonResponse.codigo == HOMONIMOS.previoLCR) {								
								/*
								 * Infórmale a tu cliente que no es posible generar su solicitud de 
								 * crédito en esta sucursal debido a que ya tiene una LCR asociada. 
								 * La tienda que le corresponde es: {sucursal}.
								 */
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								// CLIENTE_REACTIVADO_GESTORA
//I-MODIFICACION (mensaje para pre aprobados TDC)
								if($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
									$rootScope.message("Aviso ", 
											["Notifícale a tu Cliente que tiene una tarjeta de crédito pre-aprobada, debe tramitarla en su Sucursal Gestora", "Cliente Único: " + clienteUnico], "Aceptar", null, null, null, null
										);
								}else{
//I-MODIFICACION (mensaje para pre aprobados TDC)
								$rootScope.message("Aviso ", 
									[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], "Aceptar", null, null, null, null
								);
								}
							} else if(jsonResponse.codigo == HOMONIMOS.empleado) {
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message("Aviso ", 
									["Lo sentimos, no es posible otorgar créditos a empleados."], 
									"Aceptar", null, null, null, null
								);
							} else if(jsonResponse.codigo == HOMONIMOS.lcrCancelada){								
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message("Aviso ", ["Infórmale a tu cliente que ya tiene una línea de crédito cancelada por lo que no es posible generar una nueva.", "No es necesario comunicarte a soporte técnico", "Cliente Único: " + clienteUnico], "Aceptar", null, null, null, null);
							} else if(jsonResponse.codigo == HOMONIMOS.previoPP) {
								/*
								 * Infórmale a tu cliente que no es posible generar su solicitud de 
								 * crédito en esta sucursal debido a que ya tiene un producto de 
								 * Presta Prenda asociado. La tienda que le corresponde es: 
								 * {sucursal}. 
								 */
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message("Aviso ", 
									[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], "Aceptar", null, null, null, null
								);
							}else {
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								
								switch(jsonResponse.codigo) {
									case HOMONIMOS.errorConsulta:
										// Ha ocurrido un error al consultar homónimos.
										$rootScope.message("Error", 
											[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], 
											"Aceptar", null, null, null, null
										);
										break;
									case HOMONIMOS.waitXtime:
										/* Favor de esperar {días} días para iniciar una nueva 
										 * solicitud.
										 */
										$rootScope.message("AVISO", 
											[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], 
											"Aceptar", null, null, null, null
										);
										break;
									case HOMONIMOS.homonimoSucc:
										/*
										 * Se encontró homónimo con alguna solicitud en proceso. 
										 * Favor de acudir a la sucursal {sucursal}.
										 */
										$rootScope.message("AVISO", 
												[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], 
												"Aceptar", null, null, null, null
											);
										break;
									case HOMONIMOS.homonimoExtr:
										// Se encontró homónimo con cliente extranjero.
										$rootScope.message("AVISO", 
												[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], 
												"Aceptar", null, null, null, null
											);
										break;
									default:
										$rootScope.message("Datos erróneos", 
											["error: " + jsonResponse.codigo], 
											"Aceptar", null, null, null, null, 
											"GENERAL", "ERROR GENERAL"
										);
								}
							}
						} else {
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							
							$rootScope.loggerIpad("Respuesta Servicio getHomonimosBsqFonetica", 
								generalService.displayMessage(data.data.descripcion));
							$rootScope.message("Error " + data.data.codigo, 
								[generalService.displayMessage(data.data.descripcion)], "Aceptar");
						}
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE; 
					}
			);
		};
		
		var actualizaMarcaSol = function(jsonActualizaMarca){
			solicitudService.actualizaMarca(jsonActualizaMarca).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						$rootScope.message("Aviso ", ["Infórmale a tu cliente que ya cuenta con una línea de crédito, por lo cual, no es posible continuar con la solicitud.",
							"Cliente Único: " + jsonActualizaMarca.cu], "Aceptar", "/", null, null, null);
					} else {
						$rootScope.loggerIpad("Respuesta Servicio actualizaMarca", generalService.displayMessage(data.data.descripcion));
						$rootScope.message("Error " + data.data.codigo, [generalService.displayMessage(data.data.descripcion)], "Aceptar");
					}								
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                $rootScope.message("Aviso ", ["Infórmale a tu cliente que ya cuenta con una línea de crédito, por lo cual, no es posible continuar con la solicitud.",
	                	"Cliente Único: " + jsonActualizaMarca.cu], "Aceptar", "/", null, null, null);
				}
			);
		}
		
		$scope.dialogo = function (){
			if($scope.cTerminos2 == false){
				document.getElementsByName( $scope.terminosCondiciones.campo )[0].checked = true;
				$scope.cTerminos2 = true;
				$scope.muestraAviso(true,2)
			}else{
				$rootScope.solicitudJson.aceptaTerminos = 0;
				$scope.cTerminos2 = false;
			}
		}
		
		$scope.muestraAviso = function (cheked,opc){
			if (opc == 1)
				cheked = document.getElementsByName( cheked )[0].checked;
			$rootScope.avisosAceptados = false;
			if(cheked){
				if($scope.forSimulador.celular.$valid)
					validateService.limpiaMascaras();
				else
					$rootScope.solicitudJson.cotizacion.clientes[0].celular= "";
				$rootScope.solicitudJson.aceptaTerminos = 1;
				$rootScope.modoPrueba=false;
//				$rootScope.canalModatelas=false;
				$rootScope.montoInvertirInicial=$scope.montoInvertir;
				
//				if(configuracion.so.windows || configuracion.so.ios)
					$scope.modalAvisosWindows();
//				else
//					generalService.locationPath("/avisos");
					
			}else{
				$rootScope.solicitudJson.aceptaTerminos = 0;
				$scope.obligarAvisos();
			}
		};
		
		$scope.checkPromocion={value:false};		
		
		$scope.validaPromocion=function(){
			$rootScope.solicitudJson.promocionCelular=$scope.checkPromocion.value?1:0;
			$rootScope.solicitudJson.promocionCorreo=$scope.checkPromocion.value?1:0;
		};					
		
		$scope.modalAvisosWindows=function(){
			modalService.avisosWin("bgazul")
			.then(
					function(exito){
						$scope.init(true);
						$scope.obligarAvisos();
					},function(error){
						$scope.init(true);
						$scope.cTerminos2=$rootScope.solicitudJson.aceptaTerminos=0;
						document.getElementsByName( $scope.terminosCondiciones.campo )[0].checked = false;
						$scope.obligarAvisos();
//						var checkk = document.getElementById("ns2")
//						var i = checkk.className.replace(/checked/g,'');
//						checkk.removeAttribute("class");
//						var tipo = document.createAttribute("class");
//		    			tipo.value = i;             		         
//		    			checkk.setAttributeNode(tipo);
//		    			checkk.removeAttribute('checked');
//						$scope.checkAvisos =0;
					});
		};
		
	 	
	 	
	 	$scope.agregarIdentificacionOficial = function(_path){
			if (configuracion.origen.tienda && _path != "/simulador" && _path != null)	
				documentosService.encolarDocSimulador(_path, "commoCtrlDivId", "responseEnvioImg1Ipad","responseEnvioImg2Ipad", "commoCtrlDivId", "responseEnvioFirmaAP","responseEnvioFirmaBuro");				
				
			else{
				if(_path != null)
                	generalService.locationPath(_path);
			}
		};
		
		
		$scope.removeNacionalidad = function(idNacionalidad){
	 		var index = $scope.nacionalidades.map(function(d){
						return d['id'];
					}).indexOf(idNacionalidad);		
	 			
	 		$scope.nacionalidades.splice(index, 1); 			
		};
		
		
		$scope.bloqueaNacionalidad = function(idNacionalidad){	 		 		
	 		$scope.nacionalidad.deshabilitado = true; 			
		};
		
		$scope.rechazoBuroSimulador=function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	solicitudService.actualizaProducto({idSolicitud:$rootScope.solicitudJson.idSolicitud, idProducto:$rootScope.solicitudJson.idProducto}).then(
				function(data){
//					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							configuracion.estatus.opcion=0;
							$rootScope.solicitudJson = j.data;
							$scope.agregarIdentificacionOficial("/ochoPasos");
							
						}else{
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$rootScope.message("Actualiza Producto",["Error al actualizar producto. Código de error: " + j.codigo], "Aceptar");
						}
					}else{
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Actualiza Producto " + data.data.codigo, [generalService.displayMessage(data.data.descripcion)], "Aceptar");
					}
						
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 					
				}
			);
		};
		
		
		$scope.catalogoItalika = function(){	
			validateService.limpiaMascaras();
			generalService.locationPath("/catalogoItalika");
		}
		
		$scope.regresaValor = function(inicial, cambio){
			function isFloat(n) {
			    return n === +n && n !== (n|0);
			}

			function isInteger(n) {
			    return n === +n && n === (n|0);
			}
			switch(true){
			case (typeof inicial == 'string'): 
				inicial = String(cambio);
				break
			case isFloat(inicial):  
				inicial = parseFloat(cambio);
				break
			case isInteger(inicial):  
				inicial = parseInt(cambio);
				break
			default:
				inicial = String(cambio);
				break
					
			}
			return inicial;
		}
		
		$scope.cargarPresupuestoC3 = function(){
			var presC3=generalService.getArrayValue("presupuestoC3");
			$scope.presupuestoC3=presC3;
			generalService.setArrayValue("presupuestoC3", null);
			if(presC3){
	//			$rootScope.solicitudJson.cotizacion=presC3.fiNotienda;
				
				if(presC3.fcFolioParam){
					if (presC3.fcFolioParam.length > 0){
						var presupuesto = {id:presC3.fcFolioParam.toString(),monto:null,enganche:null,porcentajeEnganche:0,montoaFinanciar:null, montoTotal:null, sucursal:null, plazo:null };
						generalService.setArrayValue("presupuesto", presupuesto);
						$rootScope.presupuesto = presupuesto;
					}
				}								
				
				
				if (presC3.Producto == PRODUCTOS_C3.prestamoPersonal ){									    
					$rootScope.solicitudJson.idProducto = ID_PRODUCTO.prestamoPersonal;
					$scope.setEstilo();
				}
				
	//			$rootScope.solicitudJson.cotizacion=presC3.fcNegocio; 
	//			$rootScope.solicitudJson.cotizacion=presC3.fnTasa;
	//			$rootScope.solicitudJson.cotizacion=presC3.fcCteFisMor;  
				
				if(presC3.fnTotalVenta)
					$rootScope.solicitudJson.cotizacion.montoTotal = $scope.regresaValor($rootScope.solicitudJson.cotizacion.montoTotal, presC3.fnTotalVenta); //gio con intereses
				if(presC3.fnEnganche)
					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche = $scope.regresaValor($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche,presC3.fnEnganche); 
				if(presC3.fiPlazo)
					$rootScope.solicitudJson.cotizacion.plazo=$scope.regresaValor($rootScope.solicitudJson.cotizacion.plazo, presC3.fiPlazo);
				if(presC3.fiPlazo)
					$rootScope.solicitudJson.cotizacion.idPlazo=$scope.regresaValor($rootScope.solicitudJson.cotizacion.idPlazo, presC3.fiPlazo);
				if(presC3.fnAboPuntual)
					$rootScope.solicitudJson.cotizacion.pagoPuntual=$scope.regresaValor($rootScope.solicitudJson.cotizacion.pagoPuntual, presC3.fnAboPuntual);
				if(presC3.fnPAbo)
					$rootScope.solicitudJson.cotizacion.pagoNormal=$scope.regresaValor($rootScope.solicitudJson.cotizacion.pagoNormal, presC3.fnPAbo);
				if(presC3.fnUAbo)
					$rootScope.solicitudJson.cotizacion.ultimoAbono=$scope.regresaValor($rootScope.solicitudJson.cotizacion.ultimoAbono, presC3.fnUAbo); 
				if(presC3.fiprodid)
					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto=$scope.regresaValor($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto, presC3.fiprodid);
				if(presC3.fnProdPrecio)
					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto=$scope.regresaValor($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto, presC3.fnProdPrecio); 
				if(presC3.fnSobreprecio)
					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses=$scope.regresaValor($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses, presC3.fnSobreprecio); 
				if(presC3.fcCteNombre)
					$rootScope.solicitudJson.cotizacion.clientes[0].nombre = $scope.regresaValor($rootScope.solicitudJson.cotizacion.clientes[0].nombre,presC3.fcCteNombre);
				if(presC3.fcCteAPaterno)
					$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno =$scope.regresaValor($rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno , presC3.fcCteAPaterno);
				if(presC3.fcCteAMaterno)
					$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno =$scope.regresaValor($rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno , presC3.fcCteAMaterno);	 
				if(presC3.fcCteDirCalle)
					$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle =$scope.regresaValor($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle, presC3.fcCteDirCalle);
				if(presC3.fcCteDirNoExt)
					$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroExterior=$scope.regresaValor($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroExterior, presC3.fcCteDirNoExt);
				if(presC3.fcCteDirNoInt)
					$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroInterior=$scope.regresaValor($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroInterior, presC3.fcCteDirNoInt);
				if(presC3.fcCteCP)
					$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp=$scope.regresaValor($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp, presC3.fcCteCP);
				if(presC3.fcCteColonia)
					$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=$scope.regresaValor($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia,presC3.fcCteColonia);
				if(presC3.fcCteSexo)
					$rootScope.solicitudJson.cotizacion.clientes[0].idGenero=$scope.regresaValor($rootScope.solicitudJson.cotizacion.clientes[0].idGenero,presC3.fcCteSexo);
				if(presC3.fcCteTel)
					$scope.celular1.valor=$scope.regresaValor($rootScope.solicitudJson.cotizacion.clientes[0].celular, presC3.fcCteTel);
				if(presC3.fdCteFecNac){
					if(parseInt(presC3.fdCteFecNac.split('/')[0]) < 10)
						presC3.fdCteFecNac = "0"+presC3.fdCteFecNac;
					$rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento=presC3.fdCteFecNac.substr(0,10);
					$scope.nDia=$rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento.split('/')[0];
					$scope.nMes=$rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento.split('/')[1];
					$scope.nAnno=$rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento.split('/')[2];
				}
				if(!isNaN(presC3.fnIngMensual))
					$rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo.push({"idTipo":1,"tipoDes":"INGRESO","idConcepto":4,"conceptoDes":"NO COMPROBABLES","monto":parseFloat(presC3.fnIngMensual)});
				if(presC3.fcCteRFC)
					$rootScope.solicitudJson.cotizacion.clientes[0].rfc=$scope.regresaValor($rootScope.solicitudJson.cotizacion.clientes[0].rfc, presC3.fcCteRFC);
				
				if(presC3.fcNegocio){
					cargaUnProductoC3(presC3.fcNegocio, presC3);
				}
				
				$scope.sliderListener();
			
				$scope.mueveDatos(); 
			}
		}
		
		function cargaUnProductoC3(finegocio, objetosC3Completo){
			try{
				$rootScope.loggerIpad("Presupuesto C3", objetosC3Completo);
				
				for(var i=0;i<$scope.radioProducto.length;i++){
					if($scope.radioProducto[i].negocio.toLowerCase() === finegocio.trim().toLowerCase()){
						$rootScope.solicitudJson.idProducto = $scope.radioProducto[i].radioValue;
						break;
					}
				}

				var productos = CANAL_PRODUCTOS[$rootScope.sucursalSession.idCanal];
				$scope.cargapagina(productos, true);
				
			}catch(e){
				$rootScope.loggerIpad("Presupuesto C3", "Error En el Presupuesto");
			}
		}
		
		$scope.mueveDatos = function( presC3 )
		{
			
			// DATOS HOGAR
			var cont = 0;
			var contCampo = 0;
			var arregloOpcionales = generalService.recorrerOpcionalesPorSeccion( "DATOS HOGAR" );
			for (var a=0; a < arregloOpcionales.length; a++){
				if (arregloOpcionales[a].opcional == false)
					cont++;
			}
			var porcentajeCampo = 0;
			if(cont > 0)
				porcentajeCampo = parseInt(100 / cont);
			
			if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle != "")
				contCampo++;
			if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroExterior != "")
				contCampo++;
			if(parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp) > 0)
				contCampo++;
			else
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp = "";
			if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia != "")
				contCampo = contCampo + 3;
			var porcentaje = porcentajeCampo * contCampo;
			$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje = parseInt(porcentaje.toFixed(0));	
			
			//DATOS BASICOS
			var cont = 0;
			var contCampo = 0;
			var arregloOpcionales = generalService.recorrerOpcionalesPorSeccion( "DATOS BASICOS" );
			for (var a=0; a < arregloOpcionales.length; a++){
				if (arregloOpcionales[a].opcional == false)
					cont++;
			}
			var porcentajeCampo = 0;
			if(cont > 0)
				porcentajeCampo = parseInt(100 / cont);
			
			if ($rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil != 0){
				var estadoCivil = generalService.construirCatalogo("CATALOGO ESTADO CIVIL");
				var indexEstadoCivil = estadoCivil.map(function(data){
					return data['id'];
				}).indexOf($rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil);
				
				if(indexEstadoCivil == -1)
					$rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil = 0;
				else
					contCampo++;
			}
			if ($rootScope.solicitudJson.cotizacion.clientes[0].idPuesto != 0){
				var ocupaciones=generalService.construirCatalogo("CATALOGO OCUPACION");
				var indexOcupaciones = ocupaciones.map(function(data){
					return data['id'];
				}).indexOf($rootScope.solicitudJson.cotizacion.clientes[0].idPuesto);
				
				if(indexOcupaciones == -1)
					$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto = 0;
				else
					contCampo++;
			}
			if ($rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento != 0){
				var estados = generalService.construirCatalogo("CATALOGO ESTADOS");
				var indexEstados = estados.map(function(data){
					return data['id'];
				}).indexOf($rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento);
				
				if(indexEstados == -1)
					$rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento = 0;
				else
					contCampo++;
			}
			var porcentaje = porcentajeCampo * contCampo;
			$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = parseInt(porcentaje.toFixed(0));
		};
		$scope.showSeccionTab=function(opc){
			switch(opc){
				case 0:
					$scope.tabs[0].activa=true;
					$scope.tabs[1].activa=false;
					$scope.showLimite=false;
					$scope.showInvertir=true;
//					resetPlazo();
//					$rootScope.tasas = "";
					$timeout( function(){						
						$scope.sliderListener2();
					},0);
					break;
				case 1:
					$scope.tabs[0].activa=false;
					$scope.tabs[1].activa=true;
					$scope.showInvertir=false;
					$scope.showLimite=true;
					$timeout( function(){
						$scope.sliderListener3();
					},0);
					break;
			}
		}

		$scope.cambiaTarjeta=function(id){
// I-MODIFICACION TDC (comentar para habilitar boton ekt)
//			id = 0;
// F-MODIFICACION TDC (NUEVOS CONTRATOS PARA TDC)		comentar para habilitar boton ekt
			var ind=null;
			for(var i=0; i < $scope.productosTarjetas.productos.length; i++){
				if($scope.productosTarjetas.productos[i].id == id){
					ind=i
					break;
				}
			}
// I-MODIFICACION TDC
			$scope.productoSeleccionado = $scope.productosTarjetas.productos[ind].producto;
			for(var i=0; i < $scope.productosTarjetas.productos.length; i++){
				$scope.productosTarjetas.productos[i].estilo=true;
			}
			for(var i=0; i < $scope.productosTarjetas.productos.length; i++){
				if($scope.productosTarjetas.productos[i].id==id){
					$scope.productosTarjetas.productos[i].estilo=false;
					break;
				}
			}
		}
		$scope.activaFolio = function(){
			console.log($scope.foliioPre);
		}
		
		$scope.validarFolio =  function(){
			if ($scope.foliioPre.folio.length >= 18){
				$scope.consultaPreaprobadosXCU();
			}
		}
		
//I - VALIDACION CLAVE ELECTOR
		$scope.validarClaveElector =  function(){
			if ($scope.solicitudJson.cotizacion.clientes[0].claveElector!=undefined && $scope.solicitudJson.cotizacion.clientes[0].claveElector.length >= 18 && $rootScope.consultaFuncionalidad.deshabilitarINERENAPO){
					if($scope.respCE.length < 18){
						$scope.respCE = $scope.solicitudJson.cotizacion.clientes[0].claveElector;
						$scope.solicitudJson.cotizacion.clientes[0].claveElector = "";
						$scope.menCE = "Captura nuevamente la clave de Elector";
						$scope.forSimulador.claveElector.$touched = true;
					}else{
						if($scope.solicitudJson.cotizacion.clientes[0].claveElector.localeCompare($scope.respCE)!=0){
							$scope.menCE = "La clave de elector no coincide, por favor ingrésalos nuevamente"
							$scope.solicitudJson.cotizacion.clientes[0].claveElector = "";
							$scope.respCE = "";
						}else{
							$scope.bandCE = true;
							$scope.menCE = "";
						}
					}
			}
		}
//F - VALIDACION CLAVE ELECTOR
		
		$scope.validarEmpleado = function(){
			if ($scope.foliioPre.empleadoEkt.length >= 6 && generalService.isNumeric($scope.foliioPre.empleadoEkt)){
				$scope.consultaEmpleado();
			}
		}
		
		$scope.consultaPreaprobadosXCU = function(){ 
			$scope.folioCUPre = "";
			$scope.folioCUPreTDC = "";
			$scope.validacionOCR();
			if (!$scope.foliioPre.check || $scope.validaCU())
				console.log($scope.foliioPre.check);
			else{
			var folio=$scope.foliioPre.folio;			
			if(!$rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
				folio = pad($scope.foliioPre.folio.substr(0,2), 3) + pad( $scope.foliioPre.folio.substr(2,2), 3) + pad( $scope.foliioPre.folio.substr(4,4), 4)  + pad( $scope.foliioPre.folio.substr(8,8), 8);
			}else{
//I - MODIFICACION CONVERTIR FOLIO A FORMATO DECIMAL
			folio = $scope.foliioPre.folio.toString().replace("TDC","001");
			var sucursal = (String)(parseInt("0x"+folio.substring(6, 10)));
			var folioCU = (String)(parseInt("0x"+folio.substring(10, 18)));
				
			folio = folio.substring(0, 6) + pad( sucursal, 4) +  pad(folioCU, 8);
			$scope.folioCUPreTDC = "1-" + parseInt(folio.substring(4, 6)) +"-"+ sucursal +"-"+ folioCU;
			console.log($scope.folioCUPreTDC);
//F - MODIFICACION CONVERTIR FOLIO A FORMATO DECIMAL
			}
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			 var x = { 
					 folio: folio
					 ,producto: ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)) ? $scope.productoSeleccionado : $rootScope.solicitudJson.idProducto
					 };
		    tarjetaService.consultaPreaprobadosXCU(x).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var j = JSON.parse(data.data.respuesta);
								if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO || (j.codigo == RESPONSE_REAC_EXITO && $rootScope.consultaFuncionalidad.campanaReactivado ) || j.codigo == HOMONIMOS.homonimoReact){
/*I-MODIFICAICON PREAPROBADOS 
* se valida respuesta de folio de campañas winback, invitados y preaprobados 
*/									var codigo = "";
									if (j.codigo == RESPONSE_REAC_EXITO || j.codigo == HOMONIMOS.homonimoReact ){
										codigo = j.codigo;
										j = j.data;
										j.lstResponse = [];
										j.lstResponse.push({campana: j.campana});
									}else{
/*F-MODIFICAICON PREAPROBADOS */
										j = JSON.parse(j.data);
									}
									
									/*I-MODIFICAICON PREAPROBADOS CAPTACION*/
									if( $rootScope.campanasPreaprobadosCaptacion(j.lstResponse[0].campana)){
										if($rootScope.canalesCaptacion($rootScope.sucursalSession.idCanal)){
											$scope.moverDatos(j, codigo);
										}else{
											modalService.alertModal("AVISO",["Los clientes Pre Aprobados de Captacion se deberan ingresar por la opcion disponible en ADN."],"Aceptar",null,null,null,null);
										}
									}else{
										$scope.moverDatos(j, codigo);
									}
									/*F-MODIFICAICON PREAPROBADOS CAPTACION */
									
								}else if(j.codigo == HOMONIMOS.previoLCR){
									$rootScope.message("Aviso ", 
											[j.descripcion, "Cliente Único: " + parseInt($scope.foliioPre.folio.substr(0,2)) + "-"+ parseInt( $scope.foliioPre.folio.substr(2,2)) + "-" + parseInt( $scope.foliioPre.folio.substr(4,4))  + "-" +  parseInt( $scope.foliioPre.folio.substr(8,8))], "Aceptar", null, null, null, null
										);
									limpiarDatosSolicitudTDCOro(true);
								}else{
									limpiarDatosSolicitudTDCOro(true);
									if($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
										modalService.alertModal("AVISO",[j.descripcion],"Aceptar","verdeCred","verdeCred","verdeCred",null);
									}else{
										modalService.alertModal("AVISO",["El cliente único capturado no corresponde a un pre aprobado / inactivo, por favor, captura los datos del cliente para comenzar con su proceso de crédito."],"Aceptar",null,null,null,null);
									}
								}
							}else{
								limpiarDatosSolicitudTDCOro(true);
								if($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
									modalService.alertModal("AVISO",[data.data.descripcion],"Aceptar","verdeCred","verdeCred","verdeCred",null);
								}else{
									modalService.alertModal("AVISO",["El cliente único capturado no corresponde a un pre aprobado / inactivo, por favor, captura los datos del cliente para comenzar con su proceso de crédito."],"Aceptar",null,null,null,null);
								}
							}
							
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 
			                validateService.error(error);
							
						}
					);
			}
		    };
		    //Consultar Empleado
			$scope.consultaEmpleado = function(){			
				$rootScope.waitLoaderStatus = LOADER_SHOW; 
					
				var x = {
					numeroEmpleado: $scope.foliioPre.empleadoEkt					
				};
								
					
				tarjetaService.consultaEmpleado( x ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								if (j.data.EmpleadoActivo == "true"){
									console.log("empleado valido");
								}else{
									modalService.alertModal("AVISO",["Empleado no valido"],"Aceptar","verdeCred","verdeCred","verdeCred",null);
									$scope.foliioPre.empleadoEkt = "";
								}
							}else{
								modalService.alertModal("AVISO",["Empleado no valido"],"Aceptar","verdeCred","verdeCred","verdeCred",null);
								$scope.foliioPre.empleadoEkt = "";
							}
						}else{
							modalService.alertModal("",[data.data.respuesta]);
							$scope.foliioPre.empleadoEkt = "";
						}
						
					}, function(error){
			               $rootScope.waitLoaderStatus = LOADER_HIDE; 
			               modalService.alertModal("Error "+error.status, [error.statusText]);
			               $scope.foliioPre.empleadoEkt = "";
					}
				);
			};
			$scope.moverDatos = function(listaCU, codigo){
		    	for(var i = 0;i < listaCU.lstResponse.length; i++){
					if ($rootScope.promocionCampanas(listaCU.lstResponse[i].campana)){
						if ($rootScope.validaHuellaCu(listaCU.infoClienteUnico)){
						var folio=$scope.foliioPre.folio;
						$scope.bloqueaDatosreac = true; 
						$scope.ocrRequired = false;
						$scope.obligarAvisos();
						$rootScope.solicitudJson.cotizacion.clientes[0].nombre          = listaCU.lstResponse[i].nombre.trim(); 
						$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno = listaCU.lstResponse[i].apepat.trim();
						$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno = listaCU.lstResponse[i].apemat.trim();
						$scope.campanaTDC = listaCU.lstResponse[i].campana;
						$scope.statusCampanaTDC =listaCU.lstResponse[i].status;
						$scope.limiteCredito = listaCU.lstResponse[i].filim_cred;
						$scope.mueveDatosCU(listaCU.infoClienteUnico[0]);
						if($rootScope.productosSIPA($rootScope.solicitudJson.idProducto)){
							$scope.folioCUPre = parseInt($scope.foliioPre.folio.substr(0,2)) + "-"+ parseInt( $scope.foliioPre.folio.substr(2,2)) + "-" + parseInt( $scope.foliioPre.folio.substr(4,4))  + "-" +  parseInt( $scope.foliioPre.folio.substr(8,8));
							$rootScope.solicitudJson.campana = $scope.campanaTDC;
							$rootScope.solicitudJson.observaciones = $scope.limiteCredito;
						}else{
							$scope.folioCUPre = $scope.folioCUPreTDC;
						}
						}else{
							$rootScope.message( "AVISO", ["Por favor, antes de comenzar tu proceso de crédito debes acudir con un asesor financiero a realizar un mantenimiento de biométricos"], "Aceptar", "/menuWrapper");
						}
					}
/*I-MODIFICAICON PREAPROBADOS 
* se valida respuesta de folio de campañas winback, invitados y preaprobados 
*/
					if ($rootScope.campanasPreaprobados(listaCU.lstResponse[i].campana)){
						$scope.bloqueaDatosreac = true; 
						$scope.ocrRequired = false;
						$scope.obligarAvisos();
						var folio=$scope.foliioPre.folio;			
						$scope.folioCUPre = parseInt($scope.foliioPre.folio.substr(0,2)) + "-"+ parseInt( $scope.foliioPre.folio.substr(2,2)) + "-" + parseInt( $scope.foliioPre.folio.substr(4,4))  + "-" +  parseInt( $scope.foliioPre.folio.substr(8,8));
						var clienteUnico = JSON.parse(listaCU.infoClienteUnico)
						if ($rootScope.validaHuellaCu(clienteUnico)){
							$scope.mueveDatosCU(clienteUnico[0]);
							$rootScope.solicitudJson.campana = listaCU.lstResponse[i].campana;
						}else{
							$rootScope.message( "AVISO", ["Por favor, antes de comenzar tu proceso de crédito debes acudir con un asesor financiero a realizar un mantenimiento de biométricos"], "Aceptar", "/menuWrapper");
						}		
					}
					if(codigo == HOMONIMOS.homonimoReact ){
						$scope.bloqueaDatosreac = true; 
						$scope.ocrRequired = false;
						$scope.obligarAvisos();
						var folio=$scope.foliioPre.folio;			
						$scope.folioCUPre = parseInt($scope.foliioPre.folio.substr(0,2)) + "-"+ parseInt( $scope.foliioPre.folio.substr(2,2)) + "-" + parseInt( $scope.foliioPre.folio.substr(4,4))  + "-" +  parseInt( $scope.foliioPre.folio.substr(8,8));
						var clienteUnico = JSON.parse(listaCU.infoClienteUnico)
						$scope.mueveDatosCU(clienteUnico[0]);
//						if ($rootScope.validaHuellaCu(clienteUnico)){
//							$rootScope.solicitudJson.campana = listaCU.lstResponse[i].campana;
//						}else{
//							$rootScope.message( "AVISO", ["Por favor, antes de comenzar tu proceso de crédito debes acudir con un asesor financiero a realizar un mantenimiento de biométricos"], "Aceptar", "/menuWrapper");
//						}		
					}
/*F-MODIFICAICON PREAPROBADOS */ 
				}
		    }
		    
		    
		    $scope.mueveDatosCU = function( setJson )
			{
		    	$rootScope.solicitudJson.cotizacion.clientes[0].foto = FOTO_ENVIADA;
		    	$rootScope.solicitudJson.cotizacion.clientes[0].huella = HUELLA_ENVIADA;
		    	$rootScope.solicitudJson.cotizacion.clientes[0].curp= setJson.fcCurp;
		    	$rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion = setJson.fcFolioIdentificacion
//		    	$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico = setJson.fiPais + "-" +  setJson.fiCanal + "-"+ setJson.fiSucursal+ "-" + setJson.fiFolio;
		    	$rootScope.solicitudJson.cotizacion.clientes[0].rfc =  setJson.fcRfc;
		    	if( !generalService.isEmpty(setJson.sexo) ){	 
	 				switch(setJson.sexo){
	 				case 'F': 
	 					$rootScope.solicitudJson.cotizacion.clientes[0].idGenero = "F";
	 					$rootScope.solicitudJson.cotizacion.clientes[0].genero = $scope.getDescripcionCatalogo('F',$scope.generos);
	 					break;
	 				case 'M': 	 					
	 					$rootScope.solicitudJson.cotizacion.clientes[0].idGenero = "M";
	 					$rootScope.solicitudJson.cotizacion.clientes[0].genero = $scope.getDescripcionCatalogo('M',$scope.generos);
	 					break;
	 				}
	 			}
		    	
		    	desglosaFechaNacimientoPreaprobado(setJson.fcFechaNacimiento.substr(2,2)+ setJson.fcFechaNacimiento.substr(5,2)  + setJson.fcFechaNacimiento.substr(8,2));
		    	
				$rootScope.solicitudJson.cotizacion.clientes[0].nombre=setJson.fcNombre;
				$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno=setJson.fcApellidoPaterno;
				$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno=setJson.fcApellidoMaterno;
				
				// DATOS HOGAR
				var cont = 0;
				var contCampo = 0;
				var arregloOpcionales = generalService.recorrerOpcionalesPorSeccion( "DATOS HOGAR" );
				for (var a=0; a < arregloOpcionales.length; a++){
					if (arregloOpcionales[a].opcional == false)
						cont++;
				}
				var porcentajeCampo = 0;
				if(cont > 0)
					porcentajeCampo = parseInt(100 / cont);
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle = (setJson.fcCAlle==null?"":setJson.fcCAlle).toString();
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroExterior = (setJson.fcNumeroExterior==null?"":setJson.fcNumeroExterior).toString();
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroInterior = (setJson.fcNumeroInterior==null?"":setJson.fcNumeroInterior).toString();
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp = (setJson.fcCodigoPostal==null?"":setJson.fcCodigoPostal).toString();
//				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = setJson.fccolonia==null?"":setJson.fccolonia;
				if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle != "")
					contCampo++;
				if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroExterior != "")
					contCampo++;
				if(parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp) > 0)
					contCampo++;
				else
					$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp = "";
				if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia != "")
					contCampo = contCampo + 3;
				var porcentaje = porcentajeCampo * contCampo;
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje = parseInt(porcentaje.toFixed(0));
				
				// OTROS DATOS
//				$rootScope.solicitudJson.cotizacion.clientes[0].celular = (setJson.fctelefono==null?"":setJson.fctelefono).toString();
//				$rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion = setJson.fcfolio_IDENTIFICACION;
//				$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto = setJson.fiocupacion;
//				$rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova = (setJson.fcClienteAlnova==null?"":setJson.fcClienteAlnova).toString();
//				$rootScope.solicitudJson.cotizacion.clientes[0].clienteTienda = setJson.fiIdNegocio + "-" + setJson.fiIdTienda + "-" + setJson.fiIdCliente + "-" + setJson.fiDigitoVerificador;
				
				// DATOS BASICOS
				var cont = 0;
				var contCampo = 0;
				var arregloOpcionales = generalService.recorrerOpcionalesPorSeccion( "DATOS BASICOS" );
				for (var a=0; a < arregloOpcionales.length; a++){
					if (arregloOpcionales[a].opcional == false)
						cont++;
				}
				var porcentajeCampo = 0;
				if(cont > 0)
					porcentajeCampo = parseInt(100 / cont);
				$rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil = ( setJson.fiEdoCivil == null || setJson.fiEdoCivil == "" ? 0 : parseInt(setJson.fiEdoCivil) );
				$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto = ( setJson.fiOcupacion == null || setJson.fiOcupacion == "" ? 0 : parseInt(setJson.fiOcupacion) );
//				$rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento = ( setJson.fidedo == null || setJson.fiedo == "" ? 0 : parseInt(setJson.fidedo) );
				if ($rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil != 0){
					var estadoCivil = generalService.construirCatalogo("CATALOGO ESTADO CIVIL");
					var indexEstadoCivil = estadoCivil.map(function(data){
						return data['id'];
					}).indexOf($rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil);
					
					if(indexEstadoCivil == -1)
						$rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil = 0;
					else
						contCampo++;
				}
				if ($rootScope.solicitudJson.cotizacion.clientes[0].idPuesto != 0){
					var ocupaciones=generalService.construirCatalogo("CATALOGO OCUPACION");
					var indexOcupaciones = ocupaciones.map(function(data){
						return data['id'];
					}).indexOf($rootScope.solicitudJson.cotizacion.clientes[0].idPuesto);
					
					if(indexOcupaciones == -1)
						$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto = 0;
					else
						contCampo++;
				}
				if ($rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento != 0){
					var estados = generalService.construirCatalogo("CATALOGO ESTADOS");
					var indexEstados = estados.map(function(data){
						return data['id'];
					}).indexOf($rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento);
					
					if(indexEstados == -1)
						$rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento = 0;
					else
						contCampo++;
// F-MODIFICACION TDC 
				}
// I-MODIFICACION TDC				
				
				var porcentaje = porcentajeCampo * contCampo;
				$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = parseInt(porcentaje.toFixed(0));
				
			};
			
			
			//TODO: limpiar datos Solicitud ORO
			function limpiarDatosSolicitudTDCOro(prestamo){
				$scope.campanaTDC = "";
				var solicitudTmp = $rootScope.solicitudJson;
				var cotizacion = {idPLazo: $rootScope.solicitudJson.cotizacion.idPlazo,
								  plazo: $rootScope.solicitudJson.cotizacion.plazo,
								  monto: $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto,
								  montoText: $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText};
				
				generalService.buildSolicitudJson($rootScope, null);
				$rootScope.fotoCte = "data:image/png;base64,"+$rootScope.imgUsuario;
				$rootScope.cp = "";
				$rootScope.solicitudJson.idProducto = solicitudTmp.idProducto;			
				$scope.celular1.valor = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
				$scope.nDia = null;
				$scope.nMes = null;
				$scope.nAnno = null;
				
				$scope.forSimulador.nombre.$touched  = false;
				$scope.forSimulador.apPaterno.$touched  = false;
				$scope.forSimulador.genero.$touched  = false;
				$scope.forSimulador.lugarNacimiento.$touched  = false;
				$scope.forSimulador.nacionalidad.$touched  = false;
				
				$scope.forSimulador.$submitted  = false;
				
				$scope.forSimulador.nDia.$touched = false;
				$scope.forSimulador.nMes.$touched = false;
				$scope.forSimulador.nAnno.$touched = false;
				if (prestamo){
					if($scope.doctoIdentificacion == 1) {
						$scope.forSimulador.fotoIdentificacion.$touched = false;
						$scope.forSimulador.claveElector.$touched = false;
					}
					$scope.forSimulador.celular.$touched = false;
					$scope.cTerminos2=0
					$rootScope.solicitudJson.aceptaTerminos=0;
					document.getElementsByName( $scope.terminosCondiciones.campo )[0].checked = false;
					$scope.bloqueaInput = true;
					$scope.bloqueaDatosreac = false; 
					$scope.foliioPre.check = false;
					$scope.foliioPre.folio = "";
					$scope.folioCUPre = "";
					if($scope.ocrRequired) {
						$scope.bloqueaINEPass = true;				
					} else {
						$scope.bloqueaINEPass = false;
					}
					$scope.foliioPre.folio = "";
					$scope.folioCUPre = "";
					$scope.foliioPre.check = false;
					$rootScope.solicitudJson.cotizacion.clientes[0].genero = "";
					$rootScope.solicitudJson.cotizacion.clientes[0].idGenero = "";
					$rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento = "";
					$rootScope.solicitudJson.cotizacion.clientes[0].lugarNacimientoDes = "";
					$rootScope.solicitudJson.cotizacion.idPlazo = 100;
					$rootScope.solicitudJson.cotizacion.plazo = 100;
					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = $scope.minPrestamo;
					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText = $scope.minPrestamo;
					$scope.validaCantidad($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].montoText,2);
					$rootScope.solicitudJson.campana = "";
					$scope.validacionOCR();
				}
			}
			$scope.cambioTDC = function(producto){
				for(var i=0; i < $scope.productosTarjetas.productos.length; i++){
					if($scope.productosTarjetas.productos[i].producto == producto){
						ind=i
						break;
					}
				}
			} 
			
			$scope.regresaClases = function(){
				switch($rootScope.solicitudJson.idProducto){
				case ID_PRODUCTO.prestamoPersonal:							
					return 'icon tCenter naranja';
					break;
				case ID_PRODUCTO.consumo:	
					 return 'icon tCenter consumo';
					break;
				case ID_PRODUCTO.italika:
					return 'icon tCenter italika';
					break;
				case ID_PRODUCTO.telefonia:
					return 'icon tCenter telefonia';
					break;
				case ID_PRODUCTO.tarjetaazteca:
					return 'icon tCenter naranja';
					break;
				case ID_PRODUCTO.modatelas:
					return 'icon tCenter naranja';
					break;
				case ID_PRODUCTO.tarjetaWaldos:
					return 'icon tCenter naranja';
					break;
				case  $rootScope.descTarjetas($rootScope.solicitudJson.idProducto).id:
					return 'icon tCenter verdeCred';
					break;
				case  ID_PRODUCTO.tarjetaAztecaProducto:
					return 'icon tCenter cafeTaz';
					break;
				default:
					return 'icon tCenter naranja';
					break;
				};			
			}
			
			function pad (n, length) {
			    var  n = n.toString();
			    while(n.length < length)
			         n = "0" + n;
			    return n;
			}
// F-MODIFICACION TDC			
/*********************************************************************
I - Identificar los datos rechazados por el INE
/********************************************************************/
			$scope.validaCamposC360 = function(arrCampos){
				try{

					for (i = 0 ; i < arrCampos.length; i++){ 
						var indexProducto = CAMPOS_360.map(function(d){
							return d["id360"];	
						}).indexOf (arrCampos[i].field);
						if( indexProducto !=-1 ){
							$scope.forSimulador[CAMPOS_360[indexProducto].nombre].$invalid = true;
//							var elemento = document.getElementsByName(CAMPOS_360[indexProducto].nombre);
//							elemento[0].value = "";
						}		
					}
				
				}catch(e){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message( "Datos inválidos", [" No se encontró el cliente favor de validar"] , "Aceptar",null,null,null,null,null,null);
				}
			}
/*********************************************************************
F - Identificar los datos rechazados por el INE
/********************************************************************/
/*********************************************************************
I-Llamar buscador de SIPA
/********************************************************************/
			$scope.busquedaSipa = function(){
				modalService.busqiedaSipaModal("bgAzul");
			}	
/*********************************************************************
F-Llamar buscador de SIPA
/********************************************************************/	
			
/*********************************************************************
I - Recupera solicitud
/********************************************************************/
			$scope.recuperaSolicitud = function(data){
				$rootScope.solicitudJson = data;
				
				var selected = {
						originalObject: {
							idSolicitud : $rootScope.solicitudJson.idSolicitud,
							idEstatusSeguimiento: $rootScope.solicitudJson.idSeguimiento,
							fiStatusLcrID: $rootScope.solicitudJson.idEstatusLCR,
							tipoPersona: "", 
							nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre,
							apellidoPaterno: $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno,
							apellidoMaterno: $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
							celular: $rootScope.solicitudJson.cotizacion.clientes[0].celular, 
							marca: $rootScope.solicitudJson.marca,
							cu: $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
							diasRechazo: $rootScope.solicitudJson.diasRechazo,
							idCondicio: $rootScope.solicitudJson.idCondicion,
							idStstusLCR: $rootScope.solicitudJson.idEstatusLCR,
							idMotivoBloqueo: $rootScope.solicitudJson.idMotivoBloqueo,
							creditoInmediato: $rootScope.solicitudJson.creditoInmediato
						}
				}
				
				generalService.setArrayValue("selectedBusqueda", selected);
				generalService.locationPath("/recuperaSolicitud");
			}			
/*********************************************************************
F - Recupera solicitud
/********************************************************************/	
				
/*********************************************************************
I - validacion de ocrObligatorio por sucursal
/********************************************************************/			
			$scope.validacionOCR = function(){
				// Se configura esta bandera, para validaciones.
				try {
					$scope.ocrRequired = $rootScope.consultaFuncionalidad.ocrobligatorio;
				} catch(x) {
					$scope.ocrRequired = false;
				}
				$scope.obligarAvisos();
				$scope.bloqueaDatosreac = false; 
			}
			
			function desglosaFechaNacimientoPreaprobado(fn){
		 		var cont = 0;
		 		
		 		if( fn.length == 6){
		 			var annio="", mes="", dia="";
			 		
			 		try{
			 			var anioActual = new Date().getFullYear().toString().substring(2);
						var anioFN = fn.substring(0,2);
							if(generalService.isNumeric(anioFN)){
								if( parseInt(anioActual) < parseInt(anioFN) )
									annio = "19" + anioFN;				
								else
									annio = "20" + anioFN;
								
								$scope.nAnno = annio;
								cont++;
							}					
						mes = fn.substring(2,4);
							if(generalService.isNumeric(mes)){
								var _mes = parseInt(mes);						
								if( _mes > 0 && _mes < 13){
									$scope.nMes = mes;
									cont++;
								}
							}												
						dia = fn.substring(4,6);
							if( generalService.isNumeric(dia) ){
								var _dia = parseInt(dia);
								if( _dia > 0 && _dia < 32){
									$scope.nDia = dia;
									cont++;
								}
							}
																												
						
			 		}catch(e){
			 			$scope.nAnno=null;
			 			$scope.nMes=null;
			 			$scope.nDia=null;
			 			
			 		}
			 		
		 		}
		 			 		
		 		return (cont == 3)? true:false;							
		 	};
/*********************************************************************
F - validacion de ocrObligatorio por sucursal
/********************************************************************/
		 	
		 	$scope.validaCU = function(){
		 		var folio=$scope.foliioPre.folio;
		 		if(!$rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
					folio = pad($scope.foliioPre.folio.substr(0,2), 3) + pad( $scope.foliioPre.folio.substr(2,2), 3) + pad( $scope.foliioPre.folio.substr(4,4), 4)  + pad( $scope.foliioPre.folio.substr(8,8), 8);
				}else{
					folio = $scope.foliioPre.folio.toString().replace("TDC","001");
					var sucursal = (String)(parseInt("0x"+folio.substring(6, 10)));
					var folioCU = (String)(parseInt("0x"+folio.substring(10, 18)));
					folio = folio.substring(0, 6) + pad( sucursal, 4) +  pad(folioCU, 8);
					$scope.folioCUPreTDC = "1-" + parseInt(folio.substring(4, 6)) +"-"+ sucursal +"-"+ folioCU;
					console.log($scope.folioCUPreTDC);
				}
		 		if (parseInt(folio.substr(0,3)) == "001"){
		 			if (parseInt(folio.substring(0,3)) > 0 && parseInt(folio.substring(3,6)) > 0 && parseInt(folio.substring(6,10))  > 0 && parseInt(folio.substring(10,18))  > 0){
			 			return false;
			 		}else{
			 			modalService.alertModal("AVISO",["Formato de folio inválido, favor de verificar."],"Aceptar",null,null,null,null);
			 			$scope.foliioPre.folio = "";
			 			return true;
			 		}
		 		}else{
		 			var aux= "Formato de folio inválido, favor de verificar que pais sea 01.";
		 				if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto))
		 					aux= "Formato de folio inválido, el folio debe iniciar con TDC.";
		 			modalService.alertModal("AVISO",[aux],"Aceptar",null,null,null,null);
		 			$scope.foliioPre.folio = "";
		 			return true;
		 		}		
		 		
		 	}
		 	
		 	
		 	function envioDocumentosEnLinea(doc, index){
					var digitDocRequest = {
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							extensionImg: (doc[index].formatoImagen != undefined && doc[index].formatoImagen != "")?doc[index].formatoImagen:"jpg",
							imagenB64: doc[index].documento,
							idDocumento: doc[index].idDocumento,										
							consecutivoPersona: "0",
							porcentaje: 100,
							envioSinBody: false // si se omite o va en false, se usará el servicio con body.
					};	   			    	

				$rootScope.waitLoaderStatus = LOADER_SHOW;
				documentosService.digitalizar( digitDocRequest ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
		
						if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
							var responseJson = JSON.parse(data.data.respuesta);														
							
							if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								if(index < (doc.length-1)){
									index = index + 1;
									$rootScope.solicitudJson = responseJson.data;
									envioDocumentosEnLinea(doc, index);
								}else{
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									$rootScope.solicitudJson = responseJson.data;
									generalService.locationPath("/ochoPasos");
								}	
							}else{
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message($scope.titulo.texto,["Ocurrió un error al guardar el documento. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafe", "cafeD");
							}
						}else{
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$rootScope.message($scope.titulo.texto,["Error en la respuesta del servicio al digitalizar el documento. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafe", "cafeD");
						}
						
					}, function(error){
			            $rootScope.waitLoaderStatus = LOADER_HIDE;	                
					}
				);
			};
			
			function newFlowRelease (){
		 		$rootScope.waitLoaderStatus = LOADER_SHOW;
				  var x = {
						  idSolicitud : $rootScope.solicitudJson.idSolicitud,
						  idSeguimiento: $rootScope.solicitudJson.idSeguimiento,
						  marca: MARCAS_SOLICITUD.nuevoFlujoLiberacion
				  }
				  solicitudService.actualizarSolicitud(x).then(
						function(data){
							 $rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var responseJson = JSON.parse(data.data.respuesta);	
								if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									$rootScope.nuevoFlujoLiberacion = true;
									envioDocumentosEnLinea($scope.arrCambaceo, 0);
								}else{
									$rootScope.nuevoFlujoLiberacion = false;
									envioDocumentosEnLinea($scope.arrCambaceo, 0);
								}
								
							}else{
								$rootScope.message("Aviso ", ["Error al actualizar la solicitud. Favor de volver a intentar"],"Aceptar",null,null,null,null);
							}
						}, function(error){
							 $rootScope.waitLoaderStatus = LOADER_HIDE;
							$rootScope.message("Aviso ", ["Error en el servicio para actualizar la solicitud"],"Aceptar",null,null,null,null);				
						});
		 	};
			
	});
	
});      