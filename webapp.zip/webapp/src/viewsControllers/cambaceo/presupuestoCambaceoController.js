define(["app"], function (app) {
	
	app.controller('presupuestoCambaceoController',function($scope, $rootScope, $timeout, generalService, solicitudService, modalService) {
				
		$rootScope.presupuesto = {};
		
		$scope.init = function(){															
			$scope.showIpad=configuracion.so.ios;
			generalService.setArrayValue("solicitudRecuperada", true);
			
			if( generalService.isDefined( generalService.getArrayValue("presupuesto") ) )
				$rootScope.presupuesto = generalService.getArrayValue("presupuesto");		
			else
				$rootScope.presupuesto = {id:null,monto:null,enganche:null,porcentajeEnganche:0,montoaFinanciar:null, montoTotal:null, sucursal:null, plazo:null };				
			
				
		};
		
		
		$scope.validaMonto = function(){
			if( generalService.isEmpty( $rootScope.presupuesto.monto ) || parseInt( generalService.cleanValue( $rootScope.presupuesto.monto) ) == 0)
				reset();
		}
		
		$scope.calculaEnganche = function(porcentaje){
			
			if( generalService.isEmpty( $rootScope.presupuesto.monto ) )
				reset();
				
			else{
				var enganche = 0;
				var monto = parseInt( generalService.cleanValue( $rootScope.presupuesto.monto) );
				
				if(monto == 0)
					reset();
					
				else{
					if(porcentaje){
						
						$rootScope.presupuesto.porcentajeEnganche = ($rootScope.presupuesto.porcentajeEnganche==null || $rootScope.presupuesto.porcentajeEnganche.toString().length == 0) ? 0:parseInt($rootScope.presupuesto.porcentajeEnganche);
//						if( !generalService.isEmpty($rootScope.presupuesto.porcentajeEnganche) ){
							
							if($rootScope.presupuesto.porcentajeEnganche > 90)
								$rootScope.presupuesto.porcentajeEnganche = 90;
								
							$rootScope.presupuesto.enganche = Math.ceil( ($rootScope.presupuesto.porcentajeEnganche * monto) / 100 );
							enganche = $rootScope.presupuesto.enganche;
							
//							if( enganche > 1)
								calculaMontoAfinanciar(monto,enganche);
							
//							else 
//								reset();
								
//						}else
//							reset();													
							
						
						
					}else{
						
						enganche = ($rootScope.presupuesto.enganche==null || $rootScope.presupuesto.enganche.toString().length == 0) ? 0:parseInt(generalService.cleanValue( $rootScope.presupuesto.enganche));
//						if(  !generalService.isEmpty( $rootScope.presupuesto.enganche ) ){
							
//							enganche = parseInt(generalService.cleanValue( $rootScope.presupuesto.enganche));	
							
							if(enganche < monto){
								
								$rootScope.presupuesto.porcentajeEnganche =  parseFloat( (enganche * 100) / monto ).toFixed(2);
								
								if($rootScope.presupuesto.porcentajeEnganche > 90 ){
									$rootScope.presupuesto.porcentajeEnganche = 90;
									$scope.calculaEnganche(true);
								}else{
									if($rootScope.presupuesto.porcentajeEnganche == 0){
										$rootScope.presupuesto.enganche = enganche = 0;
										//reset();
									}
									$scope.calculaEnganche(true);
									//calculaMontoAfinanciar(monto,enganche);
								}
									
								
							}else 
								reset();
							
//						}else
//							reset();																			
						
					}
				}												
				
			}			
			
		};
		
		$scope.ocrPresupuesto = function(){
			$scope.objetoOCR = {};			
			$rootScope.ocrCodigoQR("btnPresupuestoDiv", "respuestaOCR", $scope.objetoOCR );	
		};
		
		$scope.respuestaOCR = function( data )
		{
			$rootScope.loggerIpad("respuestaOCR", null, data);
				/* SUCCESS */
				if( data.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
										
					if(configuracion.so.ios)
						$rootScope.presupuesto.id = parseInt(data.respuesta.substring(10));
					else
						$rootScope.presupuesto.id = data.respuesta;
					
					$scope.getDatosPresupuesto();
					
				}else if( data.codigo == 1 )/* INTENTOS SOBRECARGADOS */
					modalService.alertModal( "AVISO", [data.mensaje], "Aceptar" );
					
				else /* CODIGO 2 - ERROR GRAVE */
					modalService.alertModal( "ERROR", [data.mensaje], "Aceptar" );
				
		};/* END RESPUESTA CAMARA FUNCTION */
		
	    
		$scope.getDatosPresupuesto= function(){				
			
			
			if( !generalService.isEmpty($rootScope.presupuesto.id) && $rootScope.presupuesto.id.length>5){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				
				
				
				solicitudService.datosPresupuesto( {idPresupuesto:$rootScope.presupuesto.id} ).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){								
								var jResponse = JSON.parse(data.data.respuesta);	
								
								if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									
									$rootScope.presupuesto.monto = jResponse.data.totalVtaSinIntereses;
									$rootScope.presupuesto.enganche = jResponse.data.enganche;
									
									
									$rootScope.presupuesto.plazo = 52;
									$rootScope.solicitudJson.cotizacion.plazo = $rootScope.presupuesto.plazo;
									$rootScope.solicitudJson.cotizacion.idPlazo= $rootScope.presupuesto.plazo;
									$scope.$parent.existePlazo = true;
									
//									angular.forEach( $scope.$parent.radioPlazo, function(plazo, key){
//										if(plazo.radioValue == jResponse.data.plazoVta)	{
//											$rootScope.presupuesto.plazo = jResponse.data.plazoVta;
//											$rootScope.solicitudJson.cotizacion.plazo = $rootScope.presupuesto.plazo;
//											$rootScope.solicitudJson.cotizacion.idPlazo= $rootScope.presupuesto.plazo;
//											$scope.$parent.existePlazo = true;
//										}										
//											
//										
//									});
																																																						
									$scope.calculaEnganche(false);
									
								}else
									$rootScope.message( "Código de Error "+jResponse.codigo, ["Error al obtener los datos del presupuesto."], "Aceptar" );
									
														
							}else
								$rootScope.message( "Código de Error" + data.data.codigo, [generalService.displayMessage(data.data.descripcion)], "Aceptar");							
							
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 		                						
						}
					);
			}
	    	
		};
		
		
		function calculaMontoAfinanciar(monto, enganche){
						
			generalService.setArrayValue("presupuesto", $rootScope.presupuesto);
				
			$rootScope.presupuesto.montoaFinanciar = monto - enganche;  //sumar la tasa		
//			$scope.$parent.calculaPlazos(monto - enganche)
//			var montoEnviar = monto - enganche;
			//$scope.$parent.calculaPlazosConsumo(montoEnviar.toString());
//			$scope.$parent.setPlazoConsumo(montoEnviar.toString());
//			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = monto - enganche;			
//			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche = !isNaN(enganche)?parseFloat(enganche):0;
			
												
			$scope.$parent.calculaMonto();						
			
//			if($scope.$parent.existePlazo){
//				$timeout(function(){
//					$rootScope.solicitudJson.cotizacion.plazo = $rootScope.presupuesto.plazo;
//					$rootScope.solicitudJson.cotizacion.idPlazo= $rootScope.presupuesto.plazo;
//				},500);
//			}

		}
		
		
		function reset(){
			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = 0;
			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche = 0;
			
			$rootScope.presupuesto.enganche = null;
			$rootScope.presupuesto.porcentajeEnganche = 0;
			$rootScope.presupuesto.montoaFinanciar = null;						
//			$scope.calculaEnganche(true);
						
 			$scope.$parent.setEstilo();
		};
						
		
		
		
	});
	
});   