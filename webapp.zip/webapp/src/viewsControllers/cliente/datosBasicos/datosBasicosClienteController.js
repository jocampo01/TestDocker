'use strict';
define(["app"], function (app) {
	app.factory( 'GlobalVariablesService', function(){
	
	    function getArrayYears( fecha, mm, dd ){
	    		var fechaAnno = mm;
	    		var fechaValida = fecha.split('/')[1]; 
	    		var aaNacimiento = fecha.split('/')[2];
	    		var array_years = [];
	        var anno = new Date().getFullYear();
	        
	        if (fechaAnno < fechaValida){ anno = (parseInt(anno) - 1 ).toString(); };
	        
	        for( var year = 0; (anno - year) >= aaNacimiento; year++ ){
	        		var cadenaAnno = (parseInt(year) < 10 ? '0' : '') + (year.toString());
	        		
	        		if(parseInt(cadenaAnno) == 0)
	        			cadenaAnno="0";
	        		array_years.push(cadenaAnno);	        	
	        }
	        return array_years;
	    }
	
	    function getArrayDays()
	    {
	    		var array_days = [];
	    		
	        for( var day = 0; day < 31; day++ ){
	        	array_days.push( ( day < 10 ? '0' + day : day )  );
	        }
	
	        return array_days;
	    }
	
	    function getArrayMonths(){ return ( ["0","01","02","03","04","05","06","07","08","09","10","11"] );}
	    function getMonthByYear(){}
	
	    return {
	        getArrayYears: getArrayYears,
	        getArrayDays: getArrayDays,
	        getArrayMonths: getArrayMonths,
	        getMonthByYear: getMonthByYear
	    };
	
	});
	
	app.controller( 'datosBasicosClienteController', function ( $rootScope,  GlobalVariablesService, $scope, generalService, solicitudService, TermometroController,
														modalService, buroService, $timeout, messageData, validateService, MapService,MapConstants, MapBazService, securityService, clienteUnicoService, $interval) {
		
		
		/** INICIO DE DATOS BÁSICOS **/
		var cont = 0;
		var ddB = "";
		var mmB = "" ;
		var yyyy = "";
		var yy75 = "";
		var aaaa = "";
		var CONCEPTO = [];
		var fechaDiaB = "";
		var fechaDia1 = "";
		var edadMinima = "";
		var edadMaxima = "";
		var numObjEncolados = 0;
		var contadorCel = 0;
		var porcentajeantH = 0;
		var porcentajeant = 0;
		var consultarBuro = -1;
		var matrizTmp = 0;
		var buroTmp = 0;
		var tipoOcupaciones=[];		
		var ingresoMinimo = null;
		var formaEnvioBiometricos = true;
		var servicioEnvioImgDocIpad = "clienteUnico";
		var functionCallbackEnvioHuellaIpad = "responseEnvioHuellaIpad";
		var functionCallbackEnvioFotoIpad = "responseEnvioFotoIpad";
	 	var descCatalog = new Object();
	 		descCatalog[3] = "COMPROBABLES";
	 		descCatalog[4] = "NO COMPROBABLES";
	 	var fechaDiaB = new Date();
		var aaB = fechaDiaB.getFullYear();
	
		$scope.cargo  = 0;
		$scope.cargo2  = 0;	
		$scope.ocrIFE = false;
		var biometricosEnviados = $rootScope.solicitudJson.cotizacion.clientes[0].huella == HUELLA_ENVIADA && $rootScope.solicitudJson.cotizacion.clientes[0].foto == FOTO_ENVIADA;
		$scope.botonDBVisible = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje == 100;
		$scope.botonDHVisible = !generalService.cambaceoPrecalificado($rootScope.solicitudJson.marca) &&  biometricosEnviados &&
								($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje == 100 || ($rootScope.solicitudJson.consultasRealizadasEvaluacion > 0));
		//$scope.mostrarBotonDB = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje == 100?true:false;
		//s$scope.mostrarBotonDH =  $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje == 100?true:false;
		$scope.guardarFoto = false;
		$scope.guardarHuella = false;
		$scope.enviaOchoPasos = true;
		$scope.testShow = false;
		$rootScope.ofertaMCO = $rootScope.solicitudJson.tipoOferta;
		$scope.bloqueaSeccionB = ($rootScope.solicitudJson.cotizacion.clientes[0].bloqueado == 1 || $rootScope.solicitudJson.cotizacion.clientes[0].editable == 1 )?true:false;
		$scope.porcentajeQF =  (($rootScope.solicitudJson.cotizacion.clientes[0].porcentaje + $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje)/2).toFixed(0) == 100;
		/**Inicia PEPS**/
		$scope.fechaNaci = { nDia : '', nMes : '', nAnnio : ''};
		
		if(!$rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS)
			$rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS=arrayPEPS;
		
		for (var i = 0; i < $rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS.length; i++){
			if ($rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].numero == 1)
				$scope.cargo = $rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].status;
			else
				$scope.cargo2 = $rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].status;
		}
		
		$scope.validarStatus = function(check){
			if(check == 1){
				$rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[check-1].status = $scope.cargo?1:0;
			}else if(check == 2){
				$rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[check-1].status = $scope.cargo2?1:0;
			}
		}
		
		/**Termina PEPS**/
		
	/** Se declara el objeto para la sección del conyuge*/
		var fechaSeleccionada = $rootScope.solicitudJson.cotizacion.clientes[0].datosConyuge != undefined && $rootScope.solicitudJson.cotizacion.clientes[0].datosConyuge != null && $rootScope.solicitudJson.cotizacion.clientes[0].datosConyuge.fechaNaciomiento != undefined? $rootScope.solicitudJson.cotizacion.clientes[0].datosConyuge.fechaNaciomiento.split('/') :"";
		
		if( fechaSeleccionada.length == 3 ){
			$scope.nDiaConyuge = fechaSeleccionada[0];
			$scope.nMesConyuge = fechaSeleccionada[1];
			$scope.nAnioConyuge = fechaSeleccionada[2];
		}else{
			$scope.nDiaConyuge = '';
			$scope.nMesConyuge = '';
			$scope.nAnioConyuge = '';
		}
		/** Sección conyuge **/
		
		if ($rootScope.solicitudJson.banderaOCR == 1){
			angular.forEach( $rootScope.solicitudJson.documentos.documento, function(doc){																																	
				if( doc.idDocumento == 1 && doc.idTipoDocumento == 1)
					$scope.ocrIFE = true;
			});
		}
		
		/** FIN VARIABLES DE DATOS BÁSICOS **/
		
		
		
	    /** INICIA DATOS HOGAR **/
		$scope.combos = {};
		$scope.gralAddress = {};
	    $scope.completeAddress = '';
		$rootScope.coloniaOpcional = "";
		$scope.zipCodeAnterior = "";
		$scope.nAnio=$scope.nMes="";
		$scope.mapasGoogleShow = true;
		$scope.mapasBancoShow = false;
		$scope.muestraColoniaOpc=false;
	    $rootScope.activaErrores = false;
	    $rootScope.banderaIsFoundCP = false;
	    $rootScope.consultaPrimeraVez = true;
		$scope.confTipoWindows = configuracion.so.windows;
		$scope.esProduccion = generalService.isProduccion();
		$scope.isBazDigital = generalService.isBazDigital();
		$scope.vistaDatosUsuario=configuracion.datosUsuario.opcion=0;
		$rootScope.nombreCamel=generalService.camelize($rootScope.solicitudJson.cotizacion.clientes[0].nombre);
		$rootScope.apellidoPaternoCamel=generalService.camelize($rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno);
		$rootScope.apellidoMaternoCamel=generalService.camelize($rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno);
		$scope.bloqueaSeccion = ($rootScope.solicitudJson.idSeguimiento != STATUS_SOLICITUD.malZonificada.id && ($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado == 1 || $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].editable==1))?true:false;
		$scope.pageClass = generalService.calculaVistas($rootScope.paginaActual,$rootScope.paginaAnterior,$rootScope.recuperaSolicitud);
		$scope.esCambaceo = ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.generadaCambaceo)?true:false;
		$scope.respuestaBuro = $rootScope.codigoBuro;
		$rootScope.recargarInformacionQF = false;
		$scope.mostrarOferta = false;
		$scope.quickFixes = true;
		
		var json_T = $rootScope.solicitudJson.cotizacion.clientes;
		var zona_T = json_T[0].domicilios[0].zonificacion;
		var upu_address = [ '', '', '', '', '', '', ''];
		var fechaDia = new Date();
		var dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
		var mm = ((fechaDia.getMonth() + 1) < 10 ? '0' : '') + (fechaDia.getMonth() + 1); 
		var aa = fechaDia.getFullYear();
		
		if(!$rootScope.solicitudJson.avales[0].datosHogar.zonificacion){
			$rootScope.solicitudJson.avales[0].datosHogar.zonificacion = {};
		}
	    		   
	    $scope.init = function()
	    {
	    	/*\Se agrega un evento para la bitacora\*/
			//(datos del Cliente)
	    	$rootScope.addEvent( BITACORA.SECCION.datosCliente.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, porcentajeUnificada($rootScope.solicitudJson), BITACORA.SECCION.datosCliente.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
	    	$scope.configFullScreen();
	    	$scope.showDatosHogar = false;
	    	generalService.setRespaldoDom($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0]);
	    	$scope.showSeccionMapa = generalService.validateShowMapa();
	    	$scope.ejecutaSucursalInfo();	    		    	
	    	
	    	if( generalService.existeSolicitud( $rootScope.solicitudJson ) ){
	    		// Se realiza una verificación del estado civil.
				maritalStatusCheck();
	    		
	    		if( messageData ){
	    			var estados = generalService.construirCatalogo("CATALOGO ESTADOS");
		    		
		    		/**
		    		 * En algunos casos, el idLugar de nacimiento no estaba llegando correctamente, trayendo valores
		    		 * fuera del rango. Se tenían algunas reactivaciones de clientes nacidos en el extranjero que no
		    		 * debieron llegar hasta este punto.
		    		 */
		    		if ($rootScope.solicitudJson && $rootScope.solicitudJson.cotizacion 
		    			&& Array.isArray($rootScope.solicitudJson.cotizacion.clientes) 
		    			&& $rootScope.solicitudJson.cotizacion.clientes[0]) {
		    			let id = +$rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento || 0;
		    			let ok = false;
		    			
		    			if (id) {
		    				if (Array.isArray(estados) && estados.length > 0) {
		    					for (let e of estados) {
		    						if (e.id == id) {
		    							ok = true;
		    							break;
		    						}
		    					}
		    				}
		    			}
		    			
		    			if (!ok) {
		    				$rootScope.waitLoaderStatus = LOADER_HIDE;
		    				
		    				$rootScope.message('Aviso', 
		    					['El identificador de lugar de nacimiento ' + id + ' parece no ser válido.',
		    						'Por favor, contacte al administrador del sistema.'
		    					], 'Aceptar', '/');
		    				
		    				return;
		    			}
		    		}
	    			
	    			generalService.setRespaldo($rootScope.solicitudJson);
	    			/** INICIA DATOS BASICOS**/
	    			$scope.initBasicos();	
	    			/**TERMINA DATOS BASICOS **/
	    			
	    			$scope.setContentPage();
	    			
	    			if($rootScope.ocrColonia != null)
	    				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.ocrColonia;
	    			setYears();
				setMonths();
				
				//var estados = generalService.construirCatalogo("CATALOGO ESTADOS");//["Aguascalientes", "Baja California", "Baja California Sur", "Campeche", "Chiapas", "Chihuahua", "Coahuila de Zaragoza", "Colima", "Distrito Federal", "Durango", "Guanajuato", "Guerrero", "Hidalgo", "Jalisco", "Mexico", "Michoacan de Ocampo", "Morelos", "Nayarit", "Nuevo Leon", "Oaxaca", "Puebla", "Queretaro de Arteaga", "Quintana Roo", "San Luis Potosi", "Sinaloa", "Sonora", "Tabasco", "Tamaulipas", "Tlaxcala", "Veracruz-Llave", "Yucatan", "Zacatecas"];
				
				$scope.ocupaciones = generalService.construirCatalogo("CATALOGO OFICIOS");
				var clases = generalService.construirCatalogo("CATALOGO CLASE VIVIENDA");
				var viviendas = generalService.construirCatalogo("CATALOGO TIPO DE DOMICILIO");
				var antiguedadEmpresa=generalService.construirCatalogo("CATALOGO ANTIGUEDAD");
				var estadoCivil = generalService.construirCatalogo("CATALOGO ESTADO CIVIL");											
				var tipoOcupaciones=generalService.construirCatalogo("CATALOGO OCUPACION");
				var cargosPublicos=generalService.construirCatalogo("CATALOGO CARGOS PUBLICOS");
				var parentesco = generalService.construirCatalogo("CATALOGO PARENTESCO");
				
				$scope.combos = {
						"estados":estados,
						"estadoCivil":estadoCivil,
						"ocupaciones": [],
						"filterTipoOcupaciones":tipoOcupaciones,
						"cargosPublicos":cargosPublicos,
						"parentesco":parentesco,
						"annosVigencia":$scope.annosVigencia,
						"clases": clases,
						"viviendas": viviendas,
						"antiguedadEmpresa": antiguedadEmpresa
				};
				
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].antiguedadDes = validaCaracteres($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].antiguedadDes);
				$scope.datosHogar.telefono = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].telefono;
				
				/*$timeout(function(){ 
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$scope.showPage = messageData;
					$scope.convertir();
					 
				});*/
				
				$rootScope.flujoEfectivo = new Array();
    			
    			var variableFlujoEfectivo = JSON.stringify($rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo);
    			
    			angular.forEach(CONCEPTO, function(valueArray){	
    				var ingresoGasto = null;
    				angular.forEach(JSON.parse(variableFlujoEfectivo), function(valueJson){								
    					if(valueArray.id == valueJson.idConcepto)
    						ingresoGasto = valueJson;
    				});
    				
    				if( ingresoGasto == null || ingresoGasto.monto==0)							
    					$rootScope.flujoEfectivo.push({"idTipo": parseInt(valueArray.tipo), "tipoDes":valueArray.tipoDesc, "idConcepto": valueArray.id, "conceptoDes":valueArray.descripcion, "monto": "" });
    				else{
    					ingresoGasto.conceptoDes=valueArray.descripcion;
    					$rootScope.flujoEfectivo.push(ingresoGasto);
    					}
    			});
				
				$timeout(function(){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$scope.convertir();
					
					/*Datos Basicos*/
					if($rootScope.solicitudJson.cotizacion.clientes[0].porcentaje > 0){
						cuentatext('datosBasicos',null,true,$scope);
						$scope.porcMayor=true;
					}
					
					generalService.flujoEfectivo = JSON.stringify($rootScope.flujoEfectivo, function (key, val) { 
						if (key == '$$hashKey')  
							return undefined; 
						return val; 
					});
					/*Datos Hogar*/
					
					
					if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje > 0){
						cuentatext('datosHogar',null,true,$scope);
						$scope.porcMayor=true;
					}
			    	if(zona_T.latitud == ""  && zona_T.longitud == ""){			    		
			    		$scope.datosConexion();
			    	}
					if(!$scope.showSeccionMapa && ($scope.confTipoWindows) && ($rootScope.consultaFuncionalidad.tipoCartografiaZonificacion)){
						$scope.cargarIdCartografia();
					}else if($scope.mapasBancoShow && !$scope.mapasGoogleShow ){
						$scope.showSeccionMapa = false;
					}
					$scope.showDatosHogar = messageData;
				}, TIME_OUT_VIEW_MODEL);
				
			}
	    }else
	    		$rootScope.message(SIN_SOLICITUD.titulo, [SIN_SOLICITUD.texto], "Aceptar", "/");
	    
	    };/* END INIT FUNCITON */
	    
	    
	    $scope.initBasicos = function(){
	    		
	    		$scope.IngComp = false;
			$scope.cambioTipoEmpleo=false;
			$scope.cargaVista();										
			//generalService.setRespaldo($rootScope.solicitudJson);
			
			edadMinima = generalService.getDatafromCategory("SIMULADOR", "EDAD MINIMA", "VALOR.valor" );
			edadMaxima = generalService.getDatafromCategory("SIMULADOR", "EDAD MAXIMA", "VALOR.valor" );
			
			fechaDiaB = new Date();
			yyyy = new Date().getFullYear()- edadMinima;
			yy75 = new Date().getFullYear()- edadMaxima;
			fechaDia1 = new Date();
			aaaa = fechaDiaB.getFullYear();
			ddB = (fechaDiaB.getDate() < 10 ? '0' : '') + fechaDiaB.getDate();
			mmB = ((fechaDiaB.getMonth() + 1) < 10 ? '0' : '') + (fechaDiaB.getMonth() + 1); 
			$scope.radioPlazo=new Array();
			$scope.days = dias;
			
			/** Variable para usar como catalogo en la seccion de conyuge **/
			$scope.daysConyuge = dias;
			$scope.months = meses;			 				
			$scope.years = [];
			
			for(var i=(new Date().getFullYear()- edadMinima);i >= new Date().getFullYear() - 75;i--)
				$scope.years.push(""+i);

			$scope.testShow = messageData;
								
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) > -1 ){
				cuentatext('datosBasicos',1).toString();
				$rootScope.solicitudJson.cotizacion.clientes[0].huella = HUELLA_ENVIADA;
				$scope.enviarArchivoHuella = false;
				generalService.setRespaldo($rootScope.solicitudJson);
			}
				
		
			//Bloquea la foto después de la primera captura.
			$scope.permiteCapturarFoto = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].foto);
			if($rootScope.solicitudJson.idSeguimiento == 3 && $rootScope.solicitudJson.marca == 5011){
				$scope.btnFoto = false;
				$scope.btnHuella = false;
				$scope.cargo = false;
				$scope.cargo2 = false;
				$scope.isCambaceo = true;
			}
	    }
	    
	    $scope.habilitarDB = function(){
	    	
	    	if($scope.botonDBVisible){
	    		$scope.botonDBVisible = false;
	    		/*\Se agrega un evento para la bitacora\*/
				//(Datos del Cliente)
				$rootScope.addEvent( BITACORA.SECCION.datosCliente.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.EditarDatosBasicos.id, porcentajeUnificada($rootScope.solicitudJson), BITACORA.SECCION.datosCliente.guardarEnBD );					
				/*\Se agrega un evento para la bitacora\*/		
	    	}else
	    		$scope.botonDBVisible = true;
	    }
	    
	    $scope.habilitarDH = function(){
	    	
	    	if($scope.botonDHVisible){
	    		$scope.botonDHVisible = false;
	    		
	    		/*\Se agrega un evento para la bitacora\*/
				//(Datos del Cliente)
				$rootScope.addEvent( BITACORA.SECCION.datosCliente.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.EditarDireccion.id, porcentajeUnificada($rootScope.solicitudJson), BITACORA.SECCION.datosCliente.guardarEnBD );
				/*\Se agrega un evento para la bitacora\*/	
	    	}
	    	else
	    		$scope.botonDHVisible = true;
	    }
	    
	    $scope.convertir = function(){
			
			/*Datos basicos*/
			$rootScope.fotoanterior1 = $rootScope.fotoCte;
			$rootScope.fotoAnterior = $rootScope.solicitudJson.cotizacion.clientes[0].foto;
			//$scope.datosAnterioresBasicos = JSON.stringify(DatosAnterioresArreglo('datosHogar', 'buro'));
			//$scope.datosAnterioresMBasicos = JSON.stringify(DatosAnterioresArreglo('datosHogar', 'cincom'));
			//$scope.datosRespaldoSurfing=DatosAnterioresArreglo('datosHogar', 'edicion');
			/*Datos basicos*/
			
			$scope.datosAnterioresBuro = JSON.stringify(DatosAnterioresArreglo('informacionGeneral', 'buro'));
			$scope.datosAnterioresMatriz = JSON.stringify(DatosAnterioresArreglo('informacionGeneral', 'cincom'));
			$scope.datosRespaldoSurfing = DatosAnterioresArreglo('informacionGeneral', 'edicion');
		}
		
		$scope.$watch( 'mostrarOferta', function(nuevoValor) {
			if(nuevoValor){
				$timeout(function(){
					console.log( "Mostrar Oferta desde Watch 2" + nuevoValor );
					$scope.mostrarOferta = false;
		     		$scope.saveZone();
					$scope.saveStreetView();
					$rootScope.MostrarOfertas();
				}, TIME_OUT_1SEG);
			}
		});
	    
		$rootScope.$watch( 'recargarInformacionQF', function(nuevoValor) {
			if(nuevoValor){
			 	console.log( "Mostrar Oferta desde Watch" + nuevoValor );
				$rootScope.recargarInformacionQF = false;
	     		$scope.saveZone();
				$scope.saveStreetView();
				$rootScope.MostrarOfertas();
			}
		});
	    	
	    
	    $scope.inicializarMapa = function(initialize, camaraAnglesJson){
		    MapService.createMap( 'map', 'streetView', initialize );
		    if(!$scope.showSeccionMapa){
		    	/*\Se agrega un evento para la bitacora\*/
				//(Datos del Cliente)
				$rootScope.addEvent( BITACORA.SECCION.datosCliente.id, BITACORA.SUBSECCION.zonificar.id, BITACORA.ACCION.proceso.id,porcentajeUnificada($rootScope.solicitudJson), BITACORA.SECCION.datosCliente.guardarEnBD );
				/*\Se agrega un evento para la bitacora\*/
		   } 
		   if (camaraAnglesJson)
		    	$timeout(function (){MapService.updateCameraSV(camaraAnglesJson);}, 100)
	    }

	    
	    /**Ws Maps que consulta el id de cartografia para los mapas**/
	    $scope.cargarIdCartografia = function(){		    	
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	solicitudService.consultaIdCartografia($rootScope.solicitudJson.idSolicitud).then(	    	
	    			function(data){	    				
	    				if(data.data.codigo == RESPONSE_CODIGO_EXITO){	    						    						
	    						$scope.responseCartografia = JSON.parse(data.data.respuesta);
	    							if($scope.responseCartografia.xpIdCartografia == 0){	    								
	    								$rootScope.waitLoaderStatus = LOADER_HIDE;
	    								console.log("Se muestra mapa de google por default: "+$scope.responseCartografia.xpIdCartografia +"  ");	    							    								
	    							}else{
	    								$scope.objLatLong = {
	    										
	    										lat : $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud,
	    										lng : $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud
	    										
	    										}
	    								$scope.mapasGoogleShow = false;
	    								$scope.mapasBancoShow = true;
	    								$scope.crearMapa();
	    								$scope.actualizaPosicion($scope.objLatLong);
	    								$timeout(function(){$rootScope.waitLoaderStatus = LOADER_HIDE;}, TIME_OUT_5SEG);
	    								console.log("Se muestra mapa de banco por default: "+$scope.responseCartografia.xpIdCartografia +" CARTOGRAFIA GEOIT");	    								
	    							}
	    				}else{
	    					$rootScope.loggerIpad("Error en la respuesta del WS MAPS: "+data.data.descripcion);
							console.log("Error en la respuesta del WS MAPS: "+data.data.descripcion);
							$rootScope.waitLoaderStatus = LOADER_HIDE;
	    				}	    				
	    			}, function(e){
	    				$rootScope.loggerIpad("Error al consultar WS MAPS", e);
	    				console.error(e.message);
	    				$rootScope.waitLoaderStatus = LOADER_HIDE;
					}	    			
	    		);	    	
	    };	    
	    /** FIN Ws Maps que consulta el id de cartografia para los mapas **/
	    
	    
	    $scope.crearMapa=function(initializeMap){
	    	
	    	var pais, canal, sucursal = 1;
	   
	    	if ($rootScope.sucursalSession){
	    		
	    		if (!$rootScope.sucursalSession.idPais)
		    		pais = 1;
		    	else 
		    		pais = $rootScope.sucursalSession.idPais;
		    	if (!$rootScope.sucursalSession.idCanal)
		    		canal = 1;
		    	else 
		    		canal = $rootScope.sucursalSession.idCanal;
		    	if ($rootScope.sucursalSession){
		    		if (!$rootScope.sucursalInfo)
		    			sucursal = $rootScope.sucursalSession.idSucursal;
		    		else 
		    			sucursal = $rootScope.sucursalInfo.idSucursal;
		    	}
	    	}
	    	
	    	var initialize = {
	    			lat: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud,
	    			lng: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud,
	    			fnCallback:"callbackMap",
	    			direccion: {
	    				xDireccion : $scope.getCurrentAddress( true, true),
	    				idPais: pais,
	    				idEdo: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idEstado,
	    				idMun: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idDelegacion,
	    				cp: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp,
	    				idCol:$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.id,
	    				calle: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle
	    			},
	    			tienda: {
	    				xCveZon : "NOC",
	    				xPais:pais,
	    				xCanal:canal,
	    				xSucursal:sucursal,
	    			},	
	    			doOnFail: function(){
	    				alert("Error");
	    			},
	    			failOptions: {
	    				messageNoConnection: 'No hay mapas de banco', 
	    				timeout: 1 /* TIEMPO DE ESPERA EN SEGUNDOS, 5 SEGS POR DEFAULT */
	    				}
	    		};
			
	    	if ($scope.confTipoWindows || !$scope.esProduccion)
				MapBazService.createMap("mapasBanco", initialize)
		}
	    
	    $scope.actualizaPosicion=function(initializeMap){
			var latitud = initializeMap.lat;
			var longitud = initializeMap.lng;
			if ($scope.confTipoWindows || !$scope.esProduccion)
				MapBazService.updatePosition(longitud,latitud);
		}
	    
	    $scope.setContentPage = function(){
	    	
	    	if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
	    	
	    	$scope.labelTiempo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO TIEMPO."+$scope.origen+".valor"];
	    	$scope.labelMin = " " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO MIN."+$scope.origen+".valor"];
	    	generalService.setMapping(  MODEL_VISTAS_JSON );
	    	$scope._titulo			= generalService.getDataInput("DATOS HOGAR","TITULO"				, $scope.origen	);
	    	$scope._edificio		= generalService.getDataInput("DATOS HOGAR","EDIFICIO"				, null         	);  
	    	$scope._andador	        = generalService.getDataInput("DATOS HOGAR","ANDADOR"				, null         	);
	    	
	    	$scope.antiguedad={
					"tipoElemento"  : "select",
					"campo"         : "antiguedad",
					"marcaAgua"     : "Seleccione una opción",
					"visible"       : true,
					"deshabilitado" : false,
					"obligatorio"   : true,
					"buro"          : false,
					"cincom"        : false,
					"opcional"      : false,
					"estilo"        : "inpuSelect active",
					"imagen"        : "images/icon-form/calendario.png",
					"longMin"       : "",
					"longMax"       : "",
					"formato"       : "",
					"valor"         : "",
					"pattern"       : "",
					"texto"         : "",
					"colorModal"    : "",
					"colorSeccion"  : "",
					"CATALOGO"      : "catalogo"
				};

			$scope._calle           = generalService.getDataInput("DATOS HOGAR","CALLE"					, null         	);
			$scope._claseVivienda	= generalService.getDataInput("DATOS HOGAR","CLASE VIVIENDA"		, null         	);
			$scope._codigoPostal	= generalService.getDataInput("DATOS HOGAR","CODIGO POSTAL"			, null         	);
			$scope._colonia			= generalService.getDataInput("DATOS HOGAR","COLONIA"				, null         	);
			$scope._estado			= generalService.getDataInput("DATOS HOGAR","ESTADO"				, null         	);
			$scope._estado.deshabilitado=true;
			$scope._lote			= generalService.getDataInput("DATOS HOGAR","LOTE"					, null         	);
			$scope._manzana			= generalService.getDataInput("DATOS HOGAR","MANZANA"				, null			);
			$scope._delegacion		= generalService.getDataInput("DATOS HOGAR","MUNICIPIO"				, null         	);
			$scope._numeroExterior	= generalService.getDataInput("DATOS HOGAR","NUMERO EXTERIOR"		, null      	);
			$scope._numeroInterior	= generalService.getDataInput("DATOS HOGAR","NUMERO INTERIOR"		, null			);
			$scope._referencia		= generalService.getDataInput("DATOS HOGAR","REFERENCIA"			, null			);
			$scope._superManzana	= generalService.getDataInput("DATOS HOGAR","SUPERMANZANA"			, null			);
			$scope._telefonoCasa	= generalService.getDataInput("DATOS HOGAR","TELEFONO CASA"			, null			);
			$scope._tipoVivienda	= generalService.getDataInput("DATOS HOGAR","TIPO VIVIENDA"			, null			);
			$scope._etqDireccion	= generalService.getDataInput("DATOS HOGAR","ETIQUETA DIRECCION"	, $scope.origen	);
			$scope._etqHogar		= generalService.getDataInput("DATOS HOGAR","ETIQUETA HOGAR"		, $scope.origen	);
			$scope._etqMapa			= generalService.getDataInput("DATOS HOGAR","ETIQUETA MAPA"			, $scope.origen	);
			$scope._etqReferencia	= generalService.getDataInput("DATOS HOGAR","ETIQUETA REFERENCIA"	, $scope.origen	);
			$scope._etqTelefono		= generalService.getDataInput("DATOS HOGAR","ETIQUETA TELEFONO"		, $scope.origen	);
			$scope._etqTiempo		= generalService.getDataInput("DATOS HOGAR","ETIQUETA TIEMPO"		, $scope.origen	);
			$scope._btnGuardar		= generalService.getDataInput("DATOS HOGAR","BOTON GUARDAR"			, $scope.origen	);
	    	
			/** Para el flujo de zonificación posterior a la evaluación se considerará opcional el campo referencia antes de realizar la primera evaluación. **/
			if($scope.showSeccionMapa){
				$scope._referencia.opcional = true;
			}
			if($scope.muestraColoniaOpc){
				$scope._colonia.obligatorio = true;
			}
			
			$scope.datosHogar = { telefono: ""};
	    	
	    		    	
	    };	    
	    
	    
		var solicitudResp = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0];
	    
		$scope.getCurrentAddress = function( propagate, baz, resetUbicacion){
	    	
		    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0] = (resetUbicacion)? solicitudResp : $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0];
		    	
		    	var addressObject = $scope.gralAddress;
		    	var address = $scope.completeAddress;
		    	var street = validaCaracteres($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle); //addressObject.street;
		    	var extnum = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroExterior; //addressObject.extnum;
		    	var intnum = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroInterior; //addressObject.intnum;
		    	var zipcode = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp; //;
		    	var suburb = null;
		    	
		    	if( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc )
		    		suburb = validaCaracteres($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc); //addressObject.suburb;
		    	else
		    		suburb = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia; //addressObject.suburb;
		    	
		    	var town = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].estado; //
		    	var del = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].delegacion; //
		    	
		    	if ( street !== '' && street ) {
		    		upu_address[0] = street;
		    		address += street;            
		    	}
	
		    	if( extnum !== '' && extnum ){
		    		upu_address[1] = extnum;
		    		address += ' ' + extnum;
		    	}
		    	
		    	if( intnum !== '' && intnum){
		    		upu_address[2] = intnum;
		    		address += ', ' + intnum;
		    	}
	
		    	if( zipcode !== '' && zipcode ){
		    		upu_address[3] = zipcode;
		    		address += ', ' + zipcode;
		    	}
		    	
		    	if( suburb !== '' && suburb ){
		    		upu_address[4] = suburb;
		    		address += ', ' + suburb;
		    		}
		    	
		    	if( del !== '' && del ){
		    		upu_address[5] = del;
		    		address += ', ' + del;
		    	}
		    	
		    	if(baz)
		    		return address;
	
		    	if( town !== '' && town ){
		    		upu_address[6] = town;
		    		address += ', ' + town;
		    		refreshMap( address );
		    	}
		    	
		    	$scope.gralAddress.completeAddress = address;
	    	
	    };/* END GET_CURRENT_ADDRESS FUNCTION */
	    
	    

	    $scope.suburbEvent = function( flag, coloniaOpcional ){
		    	
	    		var id=0;
	    		
	    		if(coloniaOpcional == undefined)
		    		coloniaOpcional = "";
		    	if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc == "NO SE ENCUENTRA COLONIA"){
		    		$rootScope.coloniaOpcional = coloniaOpcional;
		    		$scope.muestraColoniaOpc=true;
		    		id = 999;
		    	}else{
		    		$scope.muestraColoniaOpc=false;
		    		id = 0;
		    		$rootScope.coloniaOpcional=""
		    	}
		    	
		    	if(typeof $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc === "undefined"){
		    		$rootScope.objetoColoniaSeleccionado.delegacion = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].delegacion; 
		    		$rootScope.objetoColoniaSeleccionado.idEstado = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idEstado;
		    		$rootScope.objetoColoniaSeleccionado.descEstado = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].estado;
		    		$rootScope.objetoColoniaSeleccionado.idDelegacion = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idDelegacion;
		    	}else{
		    		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].delegacion = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.delegacion; 
			    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idEstado = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.idEstado);
			    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].estado = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.descEstado;
			    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idDelegacion = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.idDelegacion);
		    	}
		    	
		    	if(id == 999){
		    		var coloniaDesc = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc;
		    		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.coloniaOpcional;
		    		}
		    	if( flag && $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc != "")
		    		$scope.getCurrentAddress( true );
		    	if(id == 999)
		    		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = coloniaDesc;
	    	
	    };/* END SUBURB_EVENT FUNCTION */
	    
	    
	    
	    $scope.getStreetViewURL = function(){
	    		console.log( url );
	        convertImgToBase64( url, function( base64Img ){});
	        setTimeout( function(){
	        }, 10);
	    };/* END GET_STREET_VIEW_URL FUNCTION */

	    
	    
	    
	    $scope.blockCP = false;
	    $rootScope.serviceModuleLocation = function( zipcode, dataType){
	    	
		    	if ( $scope.formHogar.cp.$valid && zipcode != "" && zipcode != $scope.zipCodeAnterior){
		    		$rootScope.coloniaOpcional = "";
		    		$scope.muestraColoniaOpc=false;
		    		$scope.zipCodeAnterior = zipcode;
		    		
			    	if( zipcode != "" && zipcode != -1 && zipcode != 0 ){
			    		var len = 0;
			    		
			    		if( zipcode ){
			    			len = zipcode.length;
			    		}else{
			    			resetFields( false );
			 }
			    	if( len == 5 && $scope.blockCP == false){
			    		$scope.blockCP = true;
			    		$scope.zonification = true;

		    		solicitudService.consultaCP( zipcode ).then(
		    				function( data ){
		    					$rootScope.loggerIpad("Respuesta Servicio Código Postal", data);
		    					$scope.zonification = false;			    								    					
		    					
		    					if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
		    						try{
		    							var responseJson = JSON.parse(data.data.respuesta);	
		    							if(responseJson.codigo == 2){
		    								$scope.isInputDisabled = true;
		    								resetFields( false );
		    								$scope.blockCP = false;
		    								var resp = JSON.parse(generalService.getRespaldoDom());
		    								if(resp.cp == ""){
		    									generalService.setRespaldoDom($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0]);
		    									}
		    								dynamicSelectSuburb( responseJson.data.listaColonias.length, responseJson.data.listaColonias, dataType, zipcode );
		    								$scope.mostrarOferta = true;
		    								}else{
		    									$scope.isInputDisabled = false;
		    									resetFields( true );
		    									var foo = function(){
		    										$scope.blockCP = false;
		    										};
		    										$rootScope.message("Datos del Hogar", [ "El código postal es inválido." ], "Aceptar", null, $scope._titulo.colorModal , $scope._titulo.colorSeccion, foo,"GENERAL", "ERROR CP" );
											}
										}catch( e ){
											$rootScope.loggerIpad("Error Servicio Código Postal", e);
											console.error( e.message  );
											$scope.blockCP = false;
										}
									}else{
										$scope.blockCP = false;										
		
									}	
								}, function( error ){
									$rootScope.loggerIpad("Error Servicio Código Postal", error);
									$scope.blockCP = false;
									$scope.zonification = false;
									resetFields( true );
								});
		    		}else{
		    			resetFields( false );
		    		}
		    		
		    	}else{
		    		resetFields( true );
		    	}
	    	}	    	
	    };/* END SERVICE_MODULE_LOCATION FUNCTION */
	    
	   
	    function resetFields( flag ){
	    	
	    	if( flag ){
	    		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp = "";
		    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = "";
		 }
	    	
	    	$scope.combos.colonias = [];
	    	if( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc )
	    		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = "";
	    		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].delegacion = ""; 
            $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idEstado = 0;
            $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].estado = "";
            $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idDelegacion = 0;
            	    	
	    };/* END RESET_FIELDS FUNCTION */
	    
	    function dynamicSelectSuburb( numRegistros, registros, dataType, zipcode ){
	    		$rootScope.loggerIpad("Detalle Parámetros a Zonificar", {num:numRegistros, registros:registros, tipoDato:dataType, cp:zipcode});
	    		try{
	    			var numColonias = 0;
	    			var colonias = [];
	    			
		    		if( parseInt(numRegistros) > 0 ){
		    			$scope.coloniaInfoEncontrada=false;
		    			var coincidencias=0;
		    			var objetoCoincidencia=null;
		    			var idColonia = 0;
		    			var descColonia = "";
		    			var idEstado = 0;
		    			var descEstado = "";
		    			var idDelegacion = 0;
		    			var delegacion = "";
		    			
		    			for( var i = 0; i < parseInt(numRegistros); i++ ){
		    				if( parseInt(registros[i].paisID) == 1 ){
	    						numColonias++;
		    					var dataObj = {
		    						"id": i,
		    						"idEstado": registros[i].edoID,
		    						"desc": registros[i].descColonia,
		    						"descEstado": registros[i].descEdo,
		    						"delegacion": registros[i].descPoblacion,
		    						"idDelegacion": registros[i].poblacionID
		    					};
		    					
		    					for(var j=0;j<RANGOSCP.length;j++){
		    						if(parseInt(zipcode) >= RANGOSCP[j].rangoInicial && parseInt(zipcode) <= RANGOSCP[j].rangoFinal && RANGOSCP[j].id === dataObj.idEstado){
		    							colonias.push( dataObj );
		    							break;
		    						}
		    					}
		    				
		    					if( dataType != null && dataType != "" ){
		    						if( dataObj.desc === dataType ){
		    							$scope.coloniaInfoEncontrada=true;
		    							idColonia = dataObj.id;
		    							descColonia = dataObj.desc;
		    							idEstado = dataObj.idEstado;
		    							descEstado = dataObj.descEstado;
		    							idDelegacion = dataObj.idDelegacion;
		    							delegacion = dataObj.delegacion;
		    								
		    							$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = colonias[i];		    						
		    						}
		    					}
	    					}
	    				}
		    			
	    				if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia == "" && coincidencias == 1){
	    					$scope.coloniaInfoEncontrada=true;
	    					$rootScope.ocrColonia=dataType=objetoCoincidencia.desc;
	    					$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=objetoCoincidencia;
	    				}
	
		    			var dataObj = {
							"id": 999,
							"idEstado": colonias[0].idEstado,
							"desc": "NO SE ENCUENTRA COLONIA",
							"descEstado": colonias[0].descEstado,
							"delegacion": colonias[0].delegacion,
							"idDelegacion": colonias[0].idDelegacion
		    			};
	    				
	    				colonias.push( dataObj );
		    	}
	    		
    			if(!$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia && $scope.coloniaInfoEncontrada){
    				var dataObj = {
    						"id": idColonia,
    						"idEstado": idEstado,
    						"desc": descColonia,
    						"descEstado": descEstado,
    						"delegacion": delegacion,
    						"idDelegacion": idDelegacion
    					};
    				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = dataObj;
    			}
	    			
	    		if ( numColonias > 0 ){
		    		
	    			$scope.combos['colonias'] =  colonias;
		    		
		    		if( dataType != null && dataType != ""){
		    			
		    			if(!$scope.coloniaInfoEncontrada){
		    				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=colonias[colonias.length - 1];
		    			}
		    			
		    			$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].delegacion = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.delegacion; 
		                $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idEstado = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.idEstado);
		                $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].estado = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.descEstado;
		                $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idDelegacion = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.idDelegacion);
		    			
		    			$timeout( function(){
		    				var latitud = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud;
		    				var longitud = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud;
		    				
		    				
		    				var fHeading=parseFloat( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.heading );
		    				var fPitch=parseFloat( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.pitch );
		    				var fZoom=parseFloat( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.zoom );
		    				var fov= parseFloat( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.fov)

		    	    		if (isNaN(longitud) || longitud == "" || longitud == null ){
		    	    			if($scope.muestraColoniaOpc){
		    	    				$scope.suburbEvent(true, $rootScope.coloniaOpcional);
		    	    			}else{
		    	    				$scope.getCurrentAddress()
		    	    			}
		    	    		}else{
			    			    var initialize = {
			    			    	country: 'MX',
		    						lat: parseFloat(latitud),
		    						lng: parseFloat(longitud),
		    						typeMoving: MapConstants.CENTER_MARKER,
		    						//clickableMoveMaker: false,
		    						enableFullScreen: true,
		    						sv: true,
		    						markerRadio: 6,
		    						svOptions: {
		    							messageNoneView: 'No hay vista de calle en este punto.',
		    							enableFullScreen: true,
		    							enableSatelliteView: true,
		    							satelitalZoom: 20
		    						},	doOnFail: function(){
		    							$scope.mapasGoogle(false);
		    							$scope.mapasGoogleShow = false;
		    							$scope.mapasBancoShow = true;
		    							$rootScope.message( "Datos del Hogar", ["No existe una conexión a Google."], "Aceptar", null, "bgRosa" , "rosa"  );		    									    							
		    						},
		    						 failOptions: {
		    							messageNoConnection: "No existe una conexión a Google.",
		    							timeout: 1
		    						}
		    					};
			    			    
			    				var camaraAnglesJson={
		    						fov: fov,
		    						heading: isNaN(fHeading)?0:fHeading,
		    						pitch: isNaN(fPitch)?0:fPitch,
		    			    		zoom: isNaN(fZoom)?1:fZoom
		    					};
			    				$scope.inicializarMapa(initialize, camaraAnglesJson);
			    				$scope.actualizaPosicion(initialize);
		    	    		}
		    			}, 100 );

			    		var objetoColonia=$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia;
			    		if(!$scope.coloniaInfoEncontrada){
		    				$scope.muestraColoniaOpc=true;
		    				$rootScope.coloniaOpcional=dataType;
			    		}
		    			$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=dataType;
		    			generalService.setRespaldo($rootScope.solicitudJson);
	    				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=objetoColonia;
	    				$rootScope.objetoColoniaSeleccionado=objetoColonia;
	    				$scope.showAddress = $rootScope.coloniaOpcional != ""? $rootScope.coloniaOpcional : $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc;
		    		}
	    		}else{
					$scope.isInputDisabled = false;
					resetFields( true );
	    		}	    			    			    			
	    	}catch(e){
	    		$rootScope.loggerIpad("Detalle del Error al Zoonificar", e);
	    		$rootScope.message( "Datos del Hogar", ["Código postal inválido."], "Aceptar", null, "bgRosa" , "rosa"  );
	    	}
	    	
	    };	    

	    function convertImgToBase64( url, callback, outputFormat ){

	        var img = new Image();
	        img.crossOrigin = 'Anonymous';

	        img.onload = function(){
	            var canvas = document.createElement('CANVAS');
	            var ctx = canvas.getContext('2d');
	            canvas.height = img.height;
	            canvas.width = img.width;
	            ctx.drawImage(img,0,0);
	            var dataURL = canvas.toDataURL( outputFormat || 'image/png');
	            callback( dataURL );
	            canvas = null; 
	        };

	        img.src = url;

	    };/* END CONVERT_IMG_TO_BASE64 FUNCTION */
    

		function refreshMap( stringAddress ){
		    	
		    	var zipcode = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp;
		    	
		    	if($scope.mapasGoogleShow){
		    		console.log("Se consulta geocoding de google");
		    		MapService.geolocation( stringAddress);
		    	}else{
		    		$scope.actualizaDireccion(stringAddress)
		    	}
	
		};/* END REFRESH_MAP FUNCTION */

	    function refresh( marker ){
	    		$scope.gralAddress.latitude = marker.latitude;
	        $scope.gralAddress.longitude = marker.longitude;  
	        $scope.autentiaMarker = marker;
	        
	        $scope.map.control.refresh( {
	            latitude: marker.latitude, 
	            longitude: marker.longitude
	        });
	    
	    };/* END REFRESH FUNCTTION */

	    var setMonths = function(){
	    		$scope.array_months = GlobalVariablesService.getArrayMonths();
	    	};/* END SET_MONTHS FUNCTION */

	    var setYears = function(){
	    		$scope.array_years = GlobalVariablesService.getArrayYears( $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento, mm, dd );
	    	};/* END SET_YEARS FUNCTION */
	    
	    	$scope.validaAnno = function(){
		    	var fechaNac = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento;
		    	var fechaAnno = mm;
		    	var fechaValida = fechaNac.split('/')[1];
		    	if (fechaAnno < fechaValida){
		    		var aaCompara = (parseInt(aa) - 1 );
		    	}else
		    		var aaCompara = parseInt(aa);
		    	var anioNac = fechaNac.split('/')[2];
		    	var mesNac = fechaNac.split('/')[1];
		    	var numMes = ["0","01","02","03","04","05","06","07","08","09","10","11"];
		    	
		    	if ( (parseInt($scope.nAnio) + parseInt(anioNac)) == aaCompara ){
		    		var slice = 13 - (parseInt(mesNac) - mm);
		    		if (slice >= 13){
		    			slice = slice - 12 ;	    			
		    		}
		    		
		    		$scope.array_months = numMes.slice(0,slice);

		    		if(parseInt($scope.nMes) > parseInt($scope.array_months[slice - 1]))
		    			$scope.nMes = $scope.array_months[slice - 1];
		    	}else{
		    		$scope.array_months = numMes;
		    	}
	    	};/* END VALIDA_ANNO FUNCTION */
	    
	    	$scope.functionAntiguedad = function(){
		    	var mes = $scope.nMes;
		    	var anio = $scope.nAnio;
		    	
		    	if( !anio ){
		    		anio = ( new Date().getFullYear() );
		    	}
		    	
		    	if( !mes ){
		    		mes = ( (new Date().getMonth() + 1) < 10 ? "0" + (new Date().getMonth() + 1)  : (new Date().getMonth() + 1) );
		    	}
		    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].antiguedad = "01/" + mes  + "/" + anio;
	    	};/* END ANTIGUEDAD FUNCTION */
	    
	    	$scope.muestraMeses = function(){
		    	
		    	var anio = $scope.nAnio;
		    	var fechaNac = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento;
		    	var anioNac = fechaNac.split('/')[2];
		    	var mesNac = fechaNac.split('/')[1];
		    	var months = GlobalVariablesService.getArrayMonths();
		    	
		    	if( anio == anioNac ){
		    		$scope.array_months = months.slice( parseInt(mesNac) - 1 , months.length );
		    		$scope.nMes = "Mes";
		    	}else{
		    		$scope.array_months = GlobalVariablesService.getArrayMonths();
		    	}
		    			        	
	    	};/* END MUESTRA_MESES FUNCTION */
	    
	    $scope.saveStreetView = function(){
		    	var obj = MapService.getDataPosition();
		    	
		    	if(obj != null && !$scope.mapasBancoShow){
			    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud = "" + obj.latitude;
			    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud = "" + obj.longitude;
	
			    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.heading = "" + obj.heading;
			    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.pitch = "" + obj.pitch;
			    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.zoom = "" + obj.zoom;
			    
			    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.fov = "" + obj.fov;
		    	}else{
		    		if ($scope.mapasBancoShow && ($scope.confTipoWindows || !$scope.esProduccion) ){
			    		$scope.mapaPosition= JSON.parse(MapBazService.getDataPosition());
			    	
			    		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud = "" + $scope.mapaPosition.xpUbicacion.xpCoordY;
				    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud = "" + $scope.mapaPosition.xpUbicacion.xpCoordX;
				    	
				    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.heading = "" + 30;
				    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.pitch = "" + 0;
				    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.zoom = "" + 2;
				    
				    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.fov = "" + 45;
			    	}
		    	}
	    			    		
	    };/* END SAVE_STREET_VIEW FUNCTION */
	    
	    $scope.aniobisiesto = function( vAnno,vMes ){
	    		$scope.arrayDias=[];
			  
			  if ( (vAnno % 4 == 0) && ( (vAnno % 100 != 0) || (vAnno % 400 == 0) ) ) {
				  
				  if (vMes == "02"){
					  
					  $scope.arrayDias = GlobalVariablesService.getArrayDays().slice( 0, 29 );
					  
					  if( $scope.vDia ){
						  if ($scope.vDia>"29"){
							  $scope.vDia="29";
						  }
					  }
				  }
				  
			  }else {
				  if (vMes == "02"){
					  
					  $scope.arrayDias = GlobalVariablesService.getArrayDays().slice( 0, 28 );
					  
					  if( $scope.vDia ){
					  
					  	if ( $scope.vDia>"28"){
						
					  		$scope.vDia="28";
					  
					  	}
					  }
				  }
			  }
			  
			  if ( vMes=="04"||vMes=="06"||vMes=="09"||vMes=="11" ){
				  $scope.arrayDias = GlobalVariablesService.getArrayDays().slice( 0, 30 );
				  
				  if( $scope.vDia ){
					
					  if ($scope.vDia>"30"){
						  $scope.vDia="30";
					  }
					  
				  }
			  }
			  
			  if ( vMes=="01"||vMes=="03"||vMes=="05"||vMes=="07"||vMes=="08"||vMes=="10"||vMes=="12" ){			    		
				  $scope.arrayDias = GlobalVariablesService.getArrayDays();
			  }
		};

		
		var fechaDia = new Date();
	    	var fechaPos = new Date();
	    	fechaPos.setDate( fechaDia.getDate() + 1 );
	    	var dd = ( fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
	    	var mm = ( ( fechaDia.getMonth() + 1 ) < 10 ? '0' : '' ) + ( fechaDia.getMonth() + 1 ); 
	    	var aa = fechaDia.getFullYear();	    	
	    	var ddPos = ( fechaPos.getDate() < 10 ? '0' : '') + fechaPos.getDate();
	    	var mmPos = ( ( fechaPos.getMonth() + 1 ) < 10 ? '0' : '') + ( fechaPos.getMonth() + 1 );
	    	var aaPos = fechaPos.getFullYear();
    	
	    
	    
	    $scope.validadiasProxima = function(){
	    	
	    	var vAnno="";
	    	var vMes="";
	    	    	
	    	if( angular.isNumber( $scope.nAnio ) ){
	    		if( $scope.nAnio == aaPos ){
	    			$scope.array_months = GlobalVariablesService.getArrayMonths().slice( 0, mm );
	    			
	    			if( parseInt( $scope.nMes ) > mm ){
	    				$scope.nMes = mm;
	    			}
	    		}else{
	    			$scope.array_months = GlobalVariablesService.getArrayMonths();
	    		}
	    		
	    		}
	    	
	 	};
	 	
	    
	    $scope.validar = function(form){
    		var flag=true;
				
    		try{						
	    		var obj = MapService.getDataPosition();
	    		if((obj != null || obj !=undefined) && !$scope.mapasBancoShow){
	    			if (isNaN(obj.latitude) || obj.latitude == "" || obj.latitude == null || obj.latitude == 0 || isNaN(obj.longitude) || obj.longitude == "" || obj.longitude == null || obj.longitude == 0)
	    				flag=false;
	    		}else{
	    			$scope.mapaPosition= JSON.parse(MapBazService.getDataPosition());
	    			var latBaz = $scope.mapaPosition.xpUbicacion.xpCoordY;
	    			var longBaz = $scope.mapaPosition.xpUbicacion.xpCoordX;
	    			if (isNaN(latBaz) || latBaz == "" || latBaz == null || latBaz == 0 || isNaN(longBaz) || longBaz == "" || longBaz == null || longBaz == 0)
	    				flag=false;
	    			else
	    				$scope.saveStreetView();
	    		}
    		}catch(e){
    			flag=false;
    		} 	
    	
    		return flag;
    	
    };
	    
	    
	    //funcion que reemplaza caracteres especiales 
	    
	    function validaCaracteres (str)
	    {
	            var from = ['Ñ'];
	            var to = ['N'];
	            //var str = st.toLowerCase();
	          
	            if(typeof str !== 'string'){
	            	console.log("solo letras")
	            } else {
	            for (var i = 0, c = from.length; i < c; i++)
	            {
	            	var rgx = new RegExp(from[i],'g');
	            	str = str.replace(rgx,to[i]);
	            };
	            }
	            
	            return str;
	    };
	    
	    
	    $scope.saveZone = function(){
	    
	    	var jsonTM = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia;
	    	
	    	console.log( jsonTM );
	    	
	    	if( jsonTM.hasOwnProperty( 'desc' ) ){
        		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].delegacion = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.delegacion; 
                $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idEstado = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.idEstado);
                $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].estado = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.descEstado;
                $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idDelegacion = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.idDelegacion);
                $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc;
	    	}else{
        		$rootScope.serviceModuleLocation( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp, $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia );
	    	}
	    
	    };
	    
	    $scope.getDescripcionCatalogoDH = function(id, lista,fechaAnt){
	    	if(fechaAnt){
				var mmAnt=null;
				var aaAnt=null;
				var tiempo=null;
				var fechaInicial=new Date();
				switch(id){
					case 1:
						tiempo = 6;
						break;
					case 2:
						tiempo = 12;
						break;
					case 3:
						tiempo = 36;
						break;
					case 4:
						tiempo = 60
						break;
					case 5:
						tiempo = 61
						break;
					case 6:
				}
				fechaInicial.setMonth(fechaDia.getMonth() - tiempo);
				mmAnt = ((fechaInicial.getMonth() + 1) < 10 ? '0' : '') + (fechaInicial.getMonth() + 1); 
				aaAnt = fechaInicial.getFullYear();
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].antiguedad="01/"+mmAnt+"/"+aaAnt;
			}
			return generalService.descripcionCatalogo(id, lista);
		};
		
		
		$scope.datosConexion = function(){
			var x = 0;
			var y = 0;
			
			if( zona_T.latitud == "" || isNaN(zona_T.latitud) ){
							
				console.log( 'Default location' );			
				
					if($rootScope.sucursalInfo.sucursal != null){
						if($rootScope.sucursalInfo.sucursal.xpUbicacion){
							if($rootScope.sucursalInfo.sucursal.xpUbicacion.xpCoordY)
								x = parseFloat($rootScope.sucursalInfo.sucursal.xpUbicacion.xpCoordY);
							if($rootScope.sucursalInfo.sucursal.xpUbicacion.xpCoordX)
								y = parseFloat($rootScope.sucursalInfo.sucursal.xpUbicacion.xpCoordX);
						}
					}else{
						x = 19.4284706;
						y = -99.1276627;
					}
				if(isNaN(x) || isNaN(y)){
					x = parseFloat( localStorage.getItem( 'latitude' ) );
					y = parseFloat( localStorage.getItem( 'longitude' ) );
				}			
			}else{
				x = parseFloat( zona_T.latitud );
				y = parseFloat( zona_T.longitud );			
				
			}
			 var initialize = {
						country: 'MX',
						lat: x,
						lng: y,
						typeMoving: MapConstants.CENTER_MARKER,
						enableFullScreen: true,
						sv: true,
						markerRadio: 6,
						svOptions: {
							messageNoneView: 'No hay vista de calle en este punto.',
							enableFullScreen: true,
							enableSatelliteView: true,
							satelitalZoom: 20
						},	doOnFail: function(){
							$scope.mapasGoogle(false);
							$scope.mapasGoogleShow = false;
							$scope.mapasBancoShow = true;
							$rootScope.message( "Datos del Hogar", ["No existe una conexión a Google."], "Aceptar", null, "bgRosa" , "rosa"  );
						},
						 failOptions: {
							messageNoConnection: 'No hay google maps!!! :c', /* MSJ A MOSTRAR EN LOS DIVS EN CASO DE NO CONTAR CON CONEXIÓN, TIENE MENSAJE POR DEFAULT EN CASO DE NO IR ESTE TAG */
							timeout: 1 /* TIEMPO DE ESPERA EN SEGUNDOS, 5 SEGS POR DEFAULT */
						}
					};
			 
			 $scope.inicializarMapa(initialize);
			 $scope.crearMapa(initialize);
		}
		
		$scope.getSucursalInfo=function(){
			console.log("ME EJECUTE SUCRSAL")
			$rootScope.sucursalInfo = {"idSucursal":null,"sucursal":null};
			solicitudService.getSucursal(PROCESOS.PIZ).then(
		 			function(data){
		 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){		 						 						 					
		 					var responseJson = JSON.parse(data.data.respuesta);
		 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
		 						if(responseJson.data){
		 							if(responseJson.data.xpUbicacion){
		 								$rootScope.sucursalInfo.sucursal=responseJson.data;
		 								$rootScope.sucursalInfo.idSucursal=$rootScope.sucursalSession.idSucursal;
		 							}
		 						}
							}
		 				}
		 			}, function(error){                     	 												
		 			}	
				);
		};
		
		$scope.ejecutaSucursalInfo=function(){
			if(!$rootScope.sucursalInfo){
				if(!$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud)
					$scope.getSucursalInfo();
			}else if(!$rootScope.sucursalInfo.idSucursal && !$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud)
				$scope.getSucursalInfo();
			else if($rootScope.sucursalInfo.idSucursal!=$rootScope.sucursalSession.idSucursal && !$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud)
				$scope.getSucursalInfo();
		}
				
		$scope.configFullScreen = function(){
			
			 var foo = function(){
	    		  
				 var latitud = $scope.map.markers[0].latitude;
				 var longitud = $scope.map.markers[0].longitude;
	    		  
			 };		
			
		};
		
		
	    $scope.map = {
	        zoom: 18,
	        markers: [],
	        control: {},
	        options: {
	            scrollwheel: true, //false
	            streetViewControl: false,
	            panControl: false,
	            zoomControl: false,
	        },
	        panorama: null
	    };

	    $scope.map.markers[0] = $scope.autentiaMarker;

	    if( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc ){
			$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc;
		}
		
		$scope.cargaAntiguedad=function(){
			if ($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].antiguedad != ""){ 
				var cargadoMM = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].antiguedad.split('/')[1];
				var cargadoAA = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].antiguedad.split('/')[2];
				if (cargadoMM > mm){
					var mmAux = parseInt(mm) + 12;
					var aaAux = parseInt(aa) - 1;
					$scope.nMes = ((mmAux - cargadoMM) < 10 ? '0' : '') + (mmAux - cargadoMM);
					if($scope.nMes == "00")
						$scope.nMes="0";
					$scope.nAnio = ((aaAux - cargadoAA) < 10 ? '0' : '') + (aaAux - cargadoAA);
					if($scope.nAnio == "00")
						$scope.nAnio="0";
				}else{
					$scope.nMes = ((mm - cargadoMM) < 10 ? '0' : '') + (mm - cargadoMM);
					if($scope.nMes == "00")
						$scope.nMes="0";
					$scope.nAnio = ((aa - cargadoAA) < 10 ? '0' : '') + (aa - cargadoAA);
					if($scope.nAnio == "00")
						$scope.nAnio="0";
				}
				$scope.validaAnno();
				
				
				
				
			}
		};
				
		
		$scope.actualizaDireccion=function(stringAddress){
			var jsonAddress={
					xDireccion : stringAddress,
					idPais:1,
					idEdo:$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idEstado,
					idMun:$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idDelegacion,
					cp: parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp),
					idCol:$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.id,
					calle:validaCaracteres($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle)
			};
			if($scope.confTipoWindows || !$scope.esProduccion)
				MapBazService.geolocation(jsonAddress);
		}
		
		$scope.getDataPosition=function() {
			if ($scope.confTipoWindows || !$scope.esProduccion)
				$scope.mapaPosition=MapBazService.getDataPosition();
		};
		$scope.mapasGoogle = function(bandera){
			$scope.mapasGoogleShow = bandera;
			$scope.mapasBancoShow = !bandera;
			if ($scope.mapasBancoShow){
				$scope.crearMapa();
			}
		}
		
		$scope.callbackMap = function(){
			$scope.mapaPosition= JSON.parse(MapBazService.getDataPosition());
			if ($scope.mapasBancoShow)
				MapService.updatePosition($scope.mapaPosition.xpUbicacion.xpCoordY, $scope.mapaPosition.xpUbicacion.xpCoordX );
		}
		
		/**Nueva Funcionalidad**/
		$scope.cssPrincipalUno = "height:100%;width:80%;border: 1px solid #dfe0df;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: flex-start;";
		$scope.cssBorderUno = "height:100%;width:100%;";
		$scope.cssUno = "height: 2.5em;width: 20em;margin: 9em 0 0 -8.75em;z-index: 5;-webkit-transform: rotate(-90deg);text-align: center;border:0;";
		
		$scope.cssPrincipalDos = "height:100%;width:80%;border: 1px solid #dfe0df;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: flex-start;";
		$scope.cssBorderDos = "height:100%;width:100%;";
		$scope.cssDos = "height: 2.5em;width: 20em;margin: 9em 0 0 -8.7em;z-index: 5;-webkit-transform: rotate(90deg);text-align: center;border:0;";
		
		$scope.cambiaDatos = function(accion, variable){
			if(accion == 1){
				if(variable == 1){
					$scope.cssPrincipalUno = "height:100%;width:80%;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: flex-start;";
					$scope.cssBorderUno = "flex-direction: column;display: flex;align-items: flex-start;align-content: center;justify-content: center;height:auto;width:592%;border: 1px solid #dfe0df;margin: 0 0 0 -9.8em;";
					$scope.cssUno = "height: 2.5em;width: 15em;margin: 0 0 0 0;z-index: 5;-webkit-transform: rotate(0deg);position: relative;text-align: center;border:0;";
				}
				
				if(variable == 2){
					$scope.cssPrincipalDos = "height:100%;width:80%;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: flex-start;";
					$scope.cssBorderDos = "flex-direction: column;display: flex;align-items: flex-start;align-content: center;justify-content: center;height:auto;width:592%;border: 1px solid #dfe0df;";
					$scope.cssDos = "height: 2.5em;width: 15em;margin: 0 0 0 0;z-index: 5;-webkit-transform: rotate(0deg);position: relative;text-align: center;border:0;";
				}
			}
			
			if(accion == 2){
				if(variable == 1){
					$scope.cssPrincipalUno = "height:100%;width:80%;border: 1px solid #dfe0df;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: flex-start;";
					$scope.cssBorderUno = "height:100%;width:100%;";
					$scope.cssUno = "height: 2.5em;width: 20em;margin: 9em 0 0 -8.75em;z-index: 5;-webkit-transform: rotate(-90deg);text-align: center;border:0;";
				}
				
				if(variable == 2){
					$scope.cssPrincipalDos = "height:100%;width:80%;border: 1px solid #dfe0df;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: flex-start;";
					$scope.cssBorderDos = "height:100%;width:100%;";
					$scope.cssDos = "height: 2.5em;width: 20em;margin: 9em 0 0 -8.7em;z-index: 5;-webkit-transform: rotate(90deg);text-align: center;border:0;";
				}
			}
		}

		

		
		function obtenerDistanciaMetros(lat1,lon1,lat2,lon2){
			var rad = function(x) {return x*Math.PI/180;}
			var 	R = 6378137; //Radio de la tierra en km
			var dLat = rad( lat2 - lat1 );
			var dLong = rad( lon2 - lon1 );
			
			var a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLong/2) * Math.sin(dLong/2);
			var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
			var d = R * c;
			
			return d.toFixed(3); //Retorna tres decimales
		 }
		
	   	    
		$scope.cargaVista=function(){
			if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
			$scope.estadoCivil         = {"tipoElemento":"select","campo":"edoCivilCliente","marcaAgua":"Estado civil","visible":true,"deshabilitado":false,"obligatorio":true,"buro":false,"cincom":true,"opcional":false,"estilo":"inpuSelect","imagen":"images/icon-form/estadoCivil.png","valor":"","CATALOGO":"catalogo"}
			$scope.lugarNacimiento     = {"tipoElemento":"select","campo":"lugarNacCliente","marcaAgua":"Estado de nacimiento (Opcional)","visible":false,"deshabilitado":false,"obligatorio":false,"buro":false,"cincom":true,"opcional":true,"estilo":"inpuSelect","imagen":"images/icon-form/unicacion.png","valor":"","CATALOGO":"catalogo"}
			$scope.ocupacion           = {"tipoElemento":"select","campo":"ocupacion","marcaAgua":"Ocupación","visible":true,"deshabilitado":false,"obligatorio":true,"buro":false,"cincom":true,"opcional":false,"estilo":"inpuSelect active","imagen":"images/icon-form/ocupacion.png","valor":"","CATALOGO":"catalogo"}
			$scope.folioIdent          = {"tipoElemento":"tel","campo":"fotoIdentificacion","marcaAgua":"Folio ID","visible":true,"deshabilitado":false,"obligatorio":true,"buro":false,"cincom":false,"opcional":false,"estilo":"inpuText","imagen":"images/icon-form/identificacion.png","longMin":"13","longMax":"13","formato":"NIP","valor":"","CATALOGO":"catalogo"}
			$scope.titulo = {"tipoElemento":"titulo","campo":"textoTitulo","marcaAgua":"undefined","visible":true,"estilo":"mainHeader naranja","imagen":"images/header/datosBasicos.png","valor":"","texto":"Datos Básicos","colorModal":"bgNaranja","colorSeccion":"naranja","CATALOGO":"catalogo"}
			var array = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS BASICOS.INGRESOS"];
			$scope.datosFE = new Array(array.length);		
			for (var i=1;i <= array.length;i++){
				var descripcion = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS BASICOS.INGRESOS.MARCAAGUA["+i+"].valor"];
				var tipo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS BASICOS.INGRESOS.ID TIPO["+i+"].valor"]; 
				var tipoDesc = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS BASICOS.INGRESOS.TIPO["+i+"].valor"];
				var long_min = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS BASICOS.INGRESOS.LONGMIN["+i+"].valor"];
				var long_max = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS BASICOS.INGRESOS.LONGMAX["+i+"].valor"];
				var opcional = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS BASICOS.INGRESOS.OBLIGATORIO["+i+"].valor"];
				var visible = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS BASICOS.INGRESOS.VISIBLE["+i+"].valor"];
				var campo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS BASICOS.INGRESOS.CAMPO["+i+"].valor"];
				var disabled = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS BASICOS.INGRESOS.DISABLED["+i+"].valor"];
				var cincom = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS BASICOS.INGRESOS.CINCOM["+i+"].valor"];
				var idConcepto = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS BASICOS.INGRESOS.IDENTIFICADOR["+i+"].valor"];
				var buro = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS BASICOS.INGRESOS.BURO["+i+"].valor"];
				var formato = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS BASICOS.INGRESOS.FORMATO["+i+"].valor"];
				CONCEPTO.push({id:parseInt(idConcepto), descripcion:descCatalog[parseInt(idConcepto)], tipo:tipo, tipoDesc:tipoDesc});
				$scope.datosFE[CONCEPTO[i-1].id] = {img:'images/icon-form/'+ campo +'.png', opcional: opcional, visible:visible, longmin:long_min, longmax:long_max, buro:buro, cincom:cincom, descJson:campo.toUpperCase(), formato:formato, descripcion:descripcion };
			}								
			
			$scope.etiquetaCivil       = {"tipoElemento":"etiqueta","campo":"etiquetaCivil","marcaAgua":"undefined","visible":true,"estilo":"tLeft","valor":"","texto":"¿Cuál es su estado civil?","CATALOGO":"catalogo"}
			$scope.etiquetaEstado      = {"tipoElemento":"etiqueta","campo":"etiquetaEstado","marcaAgua":"undefined","visible":false,"estilo":"tLeft","valor":"","texto":"¿Dónde nació?","CATALOGO":"catalogo"}
			$scope.etiquetaOcupacion   = {"tipoElemento":"etiqueta","campo":"etiquetaOcupacion","marcaAgua":"undefined","visible":true,"estilo":"tLeft","valor":"","texto":"¿Cuál es su ocupación?","CATALOGO":"catalogo"}
			$scope.etiquetaIngresos    = {"tipoElemento":"etiqueta","campo":"etiquetaIngresos","marcaAgua":"undefined","visible":true,"estilo":"tLeft","valor":"","texto":"¿Cuál es el monto de sus ingresos mensuales?","CATALOGO":"catalogo"}
			$scope.etiquetaFolio       = {"tipoElemento":"etiqueta","campo":"etiquetaFolio","marcaAgua":"undefined","visible":true,"estilo":"tLeft","valor":"","texto":"* Verifica el folio que se extrajo de la identificación","CATALOGO":"catalogo"}
			$scope.btnFoto             = {"tipoElemento":"submit","campo":"btnFoto","marcaAgua":"undefined","visible":true,"estilo":"btn naranja","imagen":"ready png","valor":"","texto":"Fotografía del Cliente","CATALOGO":"catalogo"}
			$scope.btnHuella           = {"tipoElemento":"submit","campo":"btnHuella","marcaAgua":"undefined","visible":true,"estilo":"btn naranja","imagen":"ready png","valor":"","texto":"Huellas del Cliente","CATALOGO":"catalogo"}
			$scope.btnGuardar          = {"tipoElemento":"submit","campo":"btnGuardar","marcaAgua":"undefined","visible":true,"estilo":"btn naranja","imagen":null,"valor":"","texto":"Guardar","CATALOGO":"catalogo"}
			$scope.montoMinimo         = {"tipoElemento":"validacion","campo":"VALIDACION","marcaAgua":"undefined","valor":"","texto":"999","CATALOGO":"catalogo"}
			
			$scope.APaterno            = {"tipoElemento":"text","campo":"apPaterno","marcaAgua":"Apellido Paterno","visible":true,"deshabilitado":false,"obligatorio":true,"estilo":"inpuText active","imagen":"images/icon-form/apaterno.png","longMin":"0","longMax":"50","formato":"LMP","valor":"","CATALOGO":"catalogo"}
			$scope.AMaterno            = {"tipoElemento":"text","campo":"apMaterno","marcaAgua":"Apellido Materno","visible":true,"deshabilitado":false,"obligatorio":false,"estilo":"inpuText active","imagen":"images/icon-form/amaterno.png","longMin":"0","longMax":"50","formato":"LMP","valor":"","CATALOGO":"catalogo"}
			$scope.nombre              = {"tipoElemento":"text","campo":"nombre","marcaAgua":"Nombre(s)","visible":true,"deshabilitado":false,"obligatorio":true,"estilo":"inpuText active","imagen":"images/icon-form/nombre.png","longMin":"0","longMax":"50","formato":"LMP","valor":"","CATALOGO":"catalogo"}
			$scope.mMes                = {"tipoElemento":"select","campo":"nMes","marcaAgua":"Mes ","visible":true,"deshabilitado":false,"obligatorio":true,"estilo":"inpuSelect active","imagen":null,"valor":"","CATALOGO":"catalogo"}
			$scope.mDia                = {"tipoElemento":"select","campo":"nDia","marcaAgua":"Día","visible":true,"deshabilitado":false,"obligatorio":true,"estilo":"inpuSelect active","imagen":"images/icon-form/calendario.png","valor":"","CATALOGO":"catalogo"}
			$scope.mAnio               = {"tipoElemento":"select","campo":"nAnno","marcaAgua":"Año","visible":true,"deshabilitado":false,"obligatorio":true,"estilo":"inpuSelect active","imagen":null,"valor":"","CATALOGO":"catalogo"}
			$scope.relacion            = {"tipoElemento":"select","campo":"parentesco","marcaAgua":"Parentesco","visible":true,"deshabilitado":false,"obligatorio":true,"buro":false,"opcional":false,"estilo":"inpuSelect active","imagen":"images/icon-form/iconParentesco.png","valor":"","CATALOGO":"catalogo"}
			$scope.cargoUno            = {"tipoElemento":"select","campo":"cargoUno","marcaAgua":"Cargo","visible":true,"deshabilitado":false,"obligatorio":true,"buro":false,"opcional":false,"estilo":"inpuSelect active","imagen":"images/icon-form/iconCargo.png","valor":"","CATALOGO":"catalogo"}
			$scope.cargoDos            = {"tipoElemento":"select","campo":"cargoUno","marcaAgua":"Cargo","visible":true,"deshabilitado":false,"obligatorio":true,"buro":false,"opcional":false,"estilo":"inpuSelect active","imagen":"images/icon-form/iconCargo.png","valor":"","CATALOGO":"catalogo"}
			$scope.labelCargoUno       = generalService.getDataInput("DATOS BASICOS","TEXTO CARGO UNO"               ,"VALOR");
			$scope.labelCargoDos       = generalService.getDataInput("DATOS BASICOS","TEXTO CARGO DOS"               ,"VALOR");
			$scope.labelEspCargo       = {"tipoElemento":"etiqueta","campo":"etiquetaEspecificaC","marcaAgua":"undefined","visible":true,"estilo":"tLeft","valor":"","texto":"Especifica el cargo","CATALOGO":"catalogo"}
			$scope.labelEspCargoDos    = {"tipoElemento":"etiqueta","campo":"etiquetaEspecificaCD","marcaAgua":"undefined","visible":true,"estilo":"tLeft","valor":"","texto":"Especifica el cargo","CATALOGO":"catalogo"}
			$scope.labelParentesco     = {"tipoElemento":"etiqueta","campo":"etiquetaParentesco","marcaAgua":"undefined","visible":true,"estilo":"tLeft","valor":"","texto":"Parentesco","CATALOGO":"catalogo"}
			$scope.labelPaterno        = {"tipoElemento":"etiqueta","campo":"etiquetaPaterno","marcaAgua":"undefined","visible":true,"estilo":"tLeft","valor":"","texto":"Apellido Paterno","CATALOGO":"catalogo"}
			$scope.labelMaterno        = {"tipoElemento":"etiqueta","campo":"etiquetaMaterno","marcaAgua":"undefined","visible":true,"estilo":"tLeft","valor":"","texto":"Apellido Materno","CATALOGO":"catalogo"}
			$scope.labelNombre         = {"tipoElemento":"etiqueta","campo":"etiquetaMaterno","marcaAgua":"undefined","visible":true,"estilo":"tLeft","valor":"","texto":"Nombre (s)","CATALOGO":"catalogo"}
			$scope.labelFecha          = {"tipoElemento":"etiqueta","campo":"etiquetaFecha","marcaAgua":"undefined","visible":true,"estilo":"tLeft","valor":"","texto":"¿Fecha de nacimiento?","CATALOGO":"catalogo"}
			$scope.labelDependencia    = {"tipoElemento":"label","campo":"labelDependencia","marcaAgua":"undefined","visible":true,"estilo":"tLeft","valor":"","texto":"Dependencia","CATALOGO":"catalogo"}
			$scope.labelArea           = {"tipoElemento":"label","campo":"labelAreaAdscrito","marcaAgua":"undefined","visible":true,"estilo":"tLeft","valor":"","texto":"Área a la que está adscrito","CATALOGO":"catalogo"}
			$scope.dependencia         = {"tipoElemento":"text","campo":"nombreDependencia","marcaAgua":"Nombre de la dependencia","visible":true,"deshabilitado":false,"obligatorio":true,"buro":false,"opcional":false,"estilo":"inpuText active","imagen":"images/icon-form/dependencia.png","longMin":"0","longMax":"255","formato":"LM","valor":"","CATALOGO":"catalogo"}
			$scope.area                = {"tipoElemento":"text","campo":"nombreArea","marcaAgua":"Nombre del área","visible":true,"deshabilitado":false,"obligatorio":true,"buro":false,"opcional":false,"estilo":"inpuText active","imagen":"images/icon-form/area.png","longMin":"0","longMax":"255","formato":"LM","valor":"","CATALOGO":"catalogo"}
			$scope.btnSolicitar        = generalService.getDataInput("SIMULADOR","BOTON SOLICITAR"       ,$scope.origen);
			
			
			ingresoMinimo = parseInt($scope.montoMinimo.texto);

			$scope.etiquetaVigencia = {
				texto: "Vigencia de Identificación oficial"	
			};
			$scope.vigenciaIdent = {
					marcaAgua : "Vigencia de Identificación",
					opcional : false,
					obligatorio: false,
					buro: false,
					cincom: false,
					estilo: "inpuSelect",
					imagen: "images/icon-form/calendario.png",
					deshabilitado: false
					
					
			};

			var tiempoVigencia = 20; // MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.CONSTANTES.VIGENCIA IDENTIFICACION.VALOR.valor"];
			$scope.annosVigencia  = [];
			var i = 0;
			for(var a = aaB/* - tiempoVigencia*/; a < aaB + tiempoVigencia; a++){
				$scope.annosVigencia[i]=a;
				i++;
			}
		}
		
		
		
		
		$scope.validaApellidos = function(aPaterno, aMaterno){
	 		if(generalService.isEmpty(aPaterno) && generalService.isEmpty(aMaterno) || !generalService.isEmpty(aPaterno) && !generalService.isEmpty(aMaterno)){
	 			$scope.APaterno.opcional = false;
	 			$scope.AMaterno.opcional = true;
	 		}else if(generalService.isEmpty(aPaterno) && !generalService.isEmpty(aMaterno)){
	 			$scope.APaterno.opcional = true;
	 			$scope.AMaterno.opcional = false;
	 		}else if(!generalService.isEmpty(aPaterno) && generalService.isEmpty(aMaterno)){
	 			$scope.APaterno.opcional = false;
	 			$scope.AMaterno.opcional = true;
	 		}
	 	}
		
		/** Inicia Peps **/
		$scope.validadias = function(dia,peps){
		 	   if (!dia){
			  	   var vAnno="";
			 	   var vMes="";
			 	   $scope.vDia=$scope.fechaNaci.nDia;
			 	   if (parseInt($scope.fechaNaci.nMes) && parseInt($scope.fechaNaci.nAnnio)){
			 		  vAnno=$scope.fechaNaci.nAnnio;
			 		  vMes=$scope.fechaNaci.nMes;
			          $scope.aniobisiesto(vAnno,vMes);
			          $scope.nDia=$scope.vDia;
			 	   }
		 	   }
		 	  if (parseInt($scope.fechaNaci.nDia) && parseInt($scope.fechaNaci.nMes) && parseInt($scope.fechaNaci.nAnnio))
		 		  $rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[peps].fechaNacimiento = $scope.fechaNaci.nDia + "/" + $scope.fechaNaci.nMes + "/" + $scope.fechaNaci.nAnnio;
		 	   
		  	};
		 		
		/** Termina Peps**/
		$scope.aniobisiesto = function(vAnno,vMes){
			$scope.days=[];
			if ((vAnno % 4 == 0) && ((vAnno % 100 != 0) || (vAnno % 400 == 0))) {
				if (vMes == "02"){
					$scope.days = dias.slice(0,29);
					if ($scope.vDia>"29")
						$scope.vDia="29";
					}
			}else{
				if (vMes == "02"){
					$scope.days = dias.slice(0,28);
					if ($scope.vDia>"28")
						$scope.vDia="28";
					}
				}
			if (vMes=="04"||vMes=="06"||vMes=="09"||vMes=="11"){
				$scope.days = dias.slice(0,30);
				if ($scope.vDia>"30")
					$scope.vDia="30";
				}
			if (vMes=="01"||vMes=="03"||vMes=="05"||vMes=="07"||vMes=="08"||vMes=="10"||vMes=="12")			    		
				$scope.days = dias;
			};
		
		/** Funciones que se ocupan para la fecha del conyuge Cuando es febrero y cuando es bisiesto para armar la fecha con dia, mes y año **/
		
		$scope.validadiasConyuge = function(diaConyuge){
	 	   if (!diaConyuge){
		  	   var vAnnoConyuge="";
		 	   var vMesConyuge="";
		 	   $scope.vDiaConyuge=$scope.nDiaConyuge;
		 
		 	   if (parseInt($scope.nMesConyuge) && parseInt($scope.nAnioConyuge)){
		 		  vAnnoConyuge=$scope.nAnioConyuge;
		 		  vMesConyuge=$scope.nMesConyuge;
		          $scope.aniobisiestoConyuge(vAnnoConyuge,vMesConyuge);
		          $scope.nDiaConyuge=$scope.vDiaConyuge;
		 	   }
	 	   }
	 	  
	 	   if (parseInt($scope.nDiaConyuge) && parseInt($scope.nMesConyuge) && parseInt($scope.nAnioConyuge))
	 		  $rootScope.solicitudJson.cotizacion.clientes[0].datosConyuge.fechaNaciomiento = $scope.nDiaConyuge + "/" + $scope.nMesConyuge + "/" + $scope.nAnioConyuge;	   
	  	};		 
		  	
		  	
	 	$scope.aniobisiestoConyuge = function(vAnnoConyuge,vMesConyuge){
	 		$scope.daysConyuge=[];
	 		if ((vAnnoConyuge % 4 == 0) && ((vAnnoConyuge % 100 != 0) || (vAnnoConyuge % 400 == 0))) {
	 			if (vMesConyuge == "02"){
	 				$scope.daysConyuge = dias.slice(0,29);
	 				if ($scope.vDiaConyuge>"29")
	 					$scope.vDiaConyuge="29";
	 			}
	 		}else{
	 			if (vMesConyuge == "02"){
	 				$scope.daysConyuge = dias.slice(0,28);
	 				if ($scope.vDiaConyuge>"28")
	 					$scope.vDiaConyuge="28";
	 			}
	 		}
	 		
	 		if (vMesConyuge=="04"||vMesConyuge=="06"||vMesConyuge=="09"||vMesConyuge=="11"){
	 			$scope.daysConyuge = dias.slice(0,30);
	 			if ($scope.vDiaConyuge>"30")
	 				$scope.vDiaConyuge="30";
	 		}
	 		
	 		if (vMesConyuge=="01"||vMesConyuge=="03"||vMesConyuge=="05"||vMesConyuge=="07"||vMesConyuge=="08"||vMesConyuge=="10"||vMesConyuge=="12")			    		
	 			$scope.daysConyuge = dias;
	 	};
		
		
		
		$scope.cargaVigencia = function(){
			$scope.vigenciaIdentificacion="";
			if ($rootScope.solicitudJson.cotizacion.clientes[0].fechaVigenciaIdentificacion != ""){
				var annoVigencia=parseInt($rootScope.solicitudJson.cotizacion.clientes[0].fechaVigenciaIdentificacion.split('/')[2]);
				if(annoVigencia >= aaB)
					$scope.vigenciaIdentificacion = annoVigencia;
			}
		}
		
		$scope.validarBotonHuella=function(){
			$scope.bloqueaHuellaCallCenter=false;
			if($rootScope.solicitudJson.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.SE_HIZO_MANTENIMIENTO_BIOM )
				$scope.bloqueaHuellaCallCenter=true;
		};
		
		$scope.validarBotonHuella();
		
		$scope.fechaVigencia = function(vigencia){
			if(parseInt(vigencia))
				$rootScope.solicitudJson.cotizacion.clientes[0].fechaVigenciaIdentificacion = "31/12/" + vigencia;
			if (vigencia < aaB)
				$scope.vigenciaInvalida=true;
			else
				$scope.vigenciaInvalida=false;
		}
		
		
		/** Se agrega solo la bandera "showDetails" para el boton de "mas" o "menos" **/
		$scope.getDescripcionCatalogo = function(id, lista){
			$scope.showDetailsCY = ($rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil == 2 || $rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil == 4)?true:false;
			var descCatalogo = generalService.descripcionCatalogo(id, lista);
			return descCatalogo.substring(0,20);				
		};
		/****/
		
		$scope.getDescripcionCatalogo1 = function(id, lista){
			var descCatalogo = generalService.descripcionCatalogo(id, lista);
			return descCatalogo;				
		};
		
		$scope.buscarOficio = function( idTipoTrabajo )
		{
			if(idTipoTrabajo != 0){
				var oficios = []; 
				$scope.combos.ocupaciones = [];
				
				$scope.ocupaciones.map(function( data, index ){
					
					var tipoEmpleoStr = data['tipoEmpleo'];
					var arregloIdsEmpleo = tipoEmpleoStr.split( "," );
					
					if( arregloIdsEmpleo.indexOf( idTipoTrabajo.toString() ) > -1 ){
						try{
							if(!(($rootScope.solicitudJson.cotizacion.clientes[0].idTipoTrabajo == 2 || $rootScope.solicitudJson.cotizacion.clientes[0].idTipoTrabajo == 3) && $scope.ocupaciones[index].id == 47))
								oficios.push( $scope.ocupaciones[index] );
						}catch(e){
							oficios.push( $scope.ocupaciones[index] );
						}
					}
					
				});
				
				$scope.combos.ocupaciones = oficios;
				
				if( oficios.length == 1 ){
					$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto = parseInt(oficios[0].id);
					$rootScope.solicitudJson.cotizacion.clientes[0].puestoDes = oficios[0].descripcion;
					$rootScope.solicitudJson.cotizacion.clientes[0].idPuestoCU = parseInt(oficios[0].idClienteUnico);
					$rootScope.solicitudJson.cotizacion.clientes[0].puestoCUDes = oficios[0].descripcion;
					$rootScope.solicitudJson.cotizacion.clientes[0].idPuestoSPCU = parseInt(oficios[0].idAdnCu);
					$rootScope.solicitudJson.cotizacion.clientes[0].puestoSPCUDes = oficios[0].descripcion;
				}else{
					if($scope.cambioTipoEmpleo){
						$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto = -1;
						$rootScope.solicitudJson.cotizacion.clientes[0].puestoDes = "";
						$rootScope.solicitudJson.cotizacion.clientes[0].idPuestoCU = 0;
						$rootScope.solicitudJson.cotizacion.clientes[0].puestoCUDes = "";
						$rootScope.solicitudJson.cotizacion.clientes[0].idPuestoSPCU = 0;
						$rootScope.solicitudJson.cotizacion.clientes[0].puestoSPCUDes = "";
					}
				}
			}
			$scope.cambioTipoEmpleo=true;
			
			
		};
		
		$scope.guardarInfoCambaceo = function (){
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			var jsonSolicitud = { jsonSolicitud: JSON.stringify($rootScope.solicitudJson)}; 
			
			solicitudService.guardarDatosCambaceo(jsonSolicitud).then(
						function(data) {
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var j = JSON.parse(data.data.respuesta);							
								if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									switchearMarcas();
								}else{
									$rootScope.message("Nueva Originación Centralizada", 
											["Algo ha ido terriblemente mal al guardar la información del cambaceo.", "Favor de volver a entrar a la sección"], 
											"Aceptar"
										);
								}
							}
						}, function(error) {
							$rootScope.waitLoaderStatus = LOADER_HIDE;
						}
				);
			
		
		}
		
		function switchearMarcas (){
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			var marca = $rootScope.solicitudJson.marca;
							
			switch(marca){
				case 5012:
					var jsonSolicitud = {
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							idSeguimiento: STATUS_SOLICITUD.generada.id,
							marca: STATUS_SOLICITUD.generada.marca.enProceso
					};
					actualizarSolicitudCambaceo(jsonSolicitud);
					break;
				case 5013:
					$scope.idMarca = generalService.consultaHistoricoMarcas([STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescate,
					         					    					  STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescateFDos,
					        											  STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescateFCuatro,
					        											  117,93,120,123,126,5026,5027]);
					var jsonSolicitud = {
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						idSeguimiento: STATUS_SOLICITUD.generada.id,
						marca: $scope.idMarca
					};
					if($scope.idMarca != 0)
						actualizarSolicitudCambaceo(jsonSolicitud);
					else{
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Nueva Originación Centralizada", 
								["Error del sistema, favor de volver a intentarlo nuevamente."], 
								"Aceptar","/cambaceo"
							);
					}	
					break;
				case 5014:
					var jsonSolicitud = {
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							idSeguimiento: STATUS_SOLICITUD.preautorizada.id,
							marca: STATUS_SOLICITUD.preautorizada.marca.fico
					};
					actualizarSolicitudCambaceo(jsonSolicitud);
					break;
				case 5015:
					var jsonSolicitud = {
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						idSeguimiento: STATUS_SOLICITUD.pendienteProceso.id,
						marca: STATUS_SOLICITUD.generada.marca.enProceso
					};
					actualizarSolicitudCambaceo(jsonSolicitud);
					break;
			}
		};
		
		var actualizarSolicitudCambaceo = function(jsonSolicitud){
			
			
			solicitudService.actualizarSolicitud(jsonSolicitud).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);							
							if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){									
								var marca = $rootScope.solicitudJson.marca;
								switch(marca){
								case 5012:
									$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.generada.id;
									$rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.enProceso;
									break;
								case 5013:
									$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.generada.id;
									$rootScope.solicitudJson.marca = $scope.idMarca;
									break;
								case 5014:
									$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.preautorizada.id;
									$rootScope.solicitudJson.marca = STATUS_SOLICITUD.preautorizada.marca.fico;
									break;
								case 5015:
									$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.pendienteProceso.id;
									$rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.enProceso;
									break;
								}
								
								$rootScope.solicitudJson.contratos.contrato[0].statusFirma = STATUS_CONTRATO.SIN_FIRMA;
								$rootScope.solicitudJson.contratos.contrato[1].statusFirma = STATUS_CONTRATO.SIN_FIRMA;
								
								solicitudService.validaFolioCallCenter(JSON.parse($scope.solicitudJsonString), $scope.responseJsonData)
								.then(
										function(data){
											if(data == null){
												generalService.locationPath("/ochoPasos");
											}else
												generalService.locationPath(data);
										},function(error){
											
										}
									);
								}else{
									$rootScope.message("Nueva Originación Centralizada", 
											["Algo ha ido terriblemente mal al cambiar los status.", "Favor de volver a entrar a la sección"], 
											"Aceptar"
										);
								}
							}
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
					}
			);
			
		}
		
		$scope.cargaIdsExternos = function( idOficio )
		{
			
			$scope.ocupaciones.map( function( data, index ){
				
				if( data['id'] == idOficio ){						
					$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto = parseInt($scope.ocupaciones[index].id);
					$rootScope.solicitudJson.cotizacion.clientes[0].puestoDes = $scope.ocupaciones[index].descripcion;
					$rootScope.solicitudJson.cotizacion.clientes[0].idPuestoCU = parseInt($scope.ocupaciones[index].idClienteUnico);
					$rootScope.solicitudJson.cotizacion.clientes[0].puestoCUDes = $scope.ocupaciones[index].descripcion;
					$rootScope.solicitudJson.cotizacion.clientes[0].idPuestoSPCU = parseInt($scope.ocupaciones[index].idAdnCu);
					$rootScope.solicitudJson.cotizacion.clientes[0].puestoSPCUDes = $scope.ocupaciones[index].descripcion;
				}
				
			});
			
		};
		
		
		$scope.fotoCliente = function(){		
			/*\Se agrega un evento para la bitacora\*/
			//(datos Cliente)
			$rootScope.addEvent( BITACORA.SECCION.datosCliente.id, BITACORA.SUBSECCION.capturaFoto.id, BITACORA.ACCION.iniciarDigitalizacion.id, 0, BITACORA.SECCION.datosCliente.guardarEnBD );  
			/*\Se agrega un evento para la bitacora\*/
			if(configuracion.origen.tienda){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$rootScope.tomarRostro('fotoCteDiv','respuestaFotoIpad');

			}								
		};
		
		$scope.huellaCliente = function(){
			/*\Se agrega un evento para la bitacora\*/
			//(Datos del Cliente)
			$rootScope.addEvent( BITACORA.SECCION.datosCliente.id, BITACORA.SUBSECCION.capturaHuellas.id, BITACORA.ACCION.iniciarDigitalizacion.id, 0, BITACORA.SECCION.datosCliente.guardarEnBD );  
			/*\Se agrega un evento para la bitacora\*/
			
			//Se mandan a BD los eventos almacenados en memoria
			$rootScope.enviaEventos();
			
			if(configuracion.origen.tienda){
				$rootScope.waitLoaderStatus = LOADER_SHOW;									
				$timeout(function(){ $rootScope.capturarHuella('huellaCteDiv','4,5,6,7', 'respuestaHuellaIpad'); }, TIME_OUT_1SEG);
				
				
			}else{
				$scope.respuestaHuellaIpad({"codigo":0,"huellas":"<Fingerprints> <HuellasPlatino> <huellaPlatino> <idHuella>4</idHuella> <mano>1</mano> <dedo>2</dedo> <cadenaHuella>30820776308206DF048206A6308206A23034302F0201030201020410A6FA3B7933624C88B5F94214C007BC6C0410479D6AD1B9A811D2A7A70040339F131702030200000201010482066000F88101C82AE3735CC041704002AAA7C66950553802DF25FA7351E56DC74F2C14678C9802E4783DC38A2C798F00E82124EF187D6B93548D2BB788592CB1B6C6D944FC8CF832A909C60F8C02912922F0D316C8D878660D293A8A7BE803BE591EE50D8506FD003E959C9B5E1DF8C691F76FF9122D25B81CB4CCA61A838BFFAAD8EA33602D5AC82AD47C7D5FCBFBFD7186C7DBBB9525EDA1279D794B9A1E2138D7155B5D3B107662EB9C4BF73127B763FECA99D32094429B3299C8EF72702533BC6B582A03C27256D279D70E14A06835D8601B5A98FAC9DDE65F15292BCF6EC0538E545AF977330B918D710CD83127BC1E7EB13B72C00575B1614CBB676501C0B53D6A868EBC85C33F91FACB90100F7A861387BD450FAF1CCF3DFC07E79BB08055FC0AE35F485FAE5E0CD113BF528464DE14B451A4F56316A0053E8AB37FD77B213337D3CD51D7C4AF4EF7EB805EC3F0E95E4C8B93D7EEEB06D278FE4D5C8BFDB89ADAE9FE9B6B917B4153DB40BD2B3C47306A02C274D138F88F4C2B734AC83D73EC1C287E536F00F88201C82AE3735CC0410D4510F4ED2BBF52C3C486A6CDCF9A1F1553F3854B80780B0844102088895A7708A606AEE92BAC5EC35FBCB999E23A7AE6B18F9AF1CA3C42A56CDAA4D493F789894B72E0F0E7CF6CBA442EC0150964884B9393ADCE51ECF64645736034B8D5057851D939C7B2EC6DDA034BE6FF52D9B4452BD56A2D07AFF63E2C98FB45485B2BBC05041815FA94A78DFDAB79C17832191EAD643F9C4D06304B57720A8BB06B0D3F76A74788ECB7E1AAA77715F520C31B350EE1C5639EFBE926AD08D36AF831BF8C36460A11AF01FE37AC2C6779423BAD96E8E93ABB47D0A7B17294C066735C351A28FCD0EA1A1E33D2614F56C15B54682AFFC78FCAA7CF89698E6C047EC0408E3E1F32556EA78372974EE4C279A2101EBFCFE75E962094EDD5036B5ED4E2FD7141E9E9AA3C1E1482F8395FC9A4341C90E8EFF66CD91C6752C1A8268C31AF9C8EA9328EF10C21BDCED21F375DA86749AA879CB9D4F1CADBDAC0229A34197942412A09C0A2EB2F20B21D8D3C36D14C0154E0D236FC6A70E6337D8CFC6F00F88201C82AE3735CC041020AE5B0B579F7DC490A7329547707D5B2BDDF7D7ED6DE622A24DD4215D456C52F67D95AB3C986EADB5C03409F6612364F6BE7E1B0DAC0EDB390856DD8EEF87B0A9DF163EA1A309AE130224B14025473A14D8A18FB2A45E08F8159C84356FD61AD57CE7E8270A5BCF5E3E270D395CA2A0242B22B05D04AA36422F141A81283FCBA09FB347D621A477ED2335797FF775EDABBE357DBF82FA1594F9F25EB5002110204946152430AA5A7A2F2E0C168695DAC0527755F4E031BB8001C34FFA0029F831BB8DFBD97453E2C6583A7572A5D3A3AA032478199B77966DDEB36C9CA089E06D75373186B9DFC0E2D1CE8F7A17A3646DD5CB4901755AB9A37981338312999DA9480A94706FC48B748FAF2DF7B6D9B4CCE487E749D14CB44D42A569A0C1A1C2CD0D0F2DDE18F5BC3BA188B025F06DB4E0666CDEC4AAE33C5CCA9A445319C90A7F09E7745D058ABAE276E23788A52A9C97010BF17F67C10A7C900E0B60DEB49409FEBA774E57D268301F21965D4B23463909FF1BCF2F7B46808E36F00E82801C82AE3735CC04154EF4D7229F753C37D1110030CF7E54BD70798E16CBC5A2281DBDEE5D570CF79593D1B47FBD5643BE1F132A6A220EB8E9F57CC8BD3E6844DD48BD28F1E693635F219036AA1A23FF5F9E13B94DFC9B19B5E1C0F4CB89311224DCF4FAB2366C4C83613A87ACD7E4509F8198757B398B534E77763F08A7AAB5160279BD8175EACDEA85043534AFB8F720B915FCA3EBFE61879E224691C432489B66AAB015E17D9E0ADC69FE3419A99303B24B7DD3C60940E3BB09CEF6EB142BE23C4313786758A57EF1675DFB64D1611A44A8AAB3F4594EF18F1452E4ECC38D83AA03BD35E5914539A3A08F990E579C4BBD9923D2144F244552A59EEB6315893C14B9BF4C4E2D273D58C482D61CE9EC8961B91686F3AFA108BDC573B6D28D8AB26AF48CD54E5348D7D6F0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000201000201000400031100AB5523C980E7473FA885619ED019316F031100A1C21100CAA111D28B020090270750C4170D3130303232333139353634375A300D06092A864886F70D0101040500038181000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000</cadenaHuella> </huellaPlatino> <huellaPlatino> <idHuella>5</idHuella> <mano>1</mano> <dedo>1</dedo> <cadenaHuella>30820776308206DF048206A6308206A23034302F0201030201020410A6FA3B7933624C88B5F94214C007BC6C0410479D6AD1B9A811D2A7A70040339F131702030200000201010482066000F87E01C82AE3735CC041071BC34E4CF91DD3DECF41FF38A501D7C0BB1B670CF80B721C3750A81818B6EF1163F159A6E907F4391BA69465C63C68E05DE5712BBA51D938D0D9F0E2D70B086A60D152E685884F4F05558E2342C074AD8A365FC3B4037FA2E912D0DB11ACE3708F9399B00F4B552F5EBBD282D6235264102B932A60B99787CCC5403D7CBF24F376598EF1432288CDDBC754E3CDF63AC4866ACF140AA174299748731C3AA1BA9525A1302433F9837C6BFAA338A4ECF82C282C8F0BB66AD64C60297336F33EB3C309F577DB98C66A0698D9CD1C2EFE587FE3DF2E1A1EA198CF1AA03439B9503AB5D4089D3FA8AE0C992A77538ADDF07ED9DF8FB25CDE94796AFB243C0353E7B200B35E546EBDD826CFA4DB21D5CFD033AE304D29549BAECAFCF185ABD70B990D205E4D015CAC2D4AEAEB0CF689D0A397F88280462307E3C26C1487DCE7B8D339B5CF9514E7FCD7DEB8E33C659E3D10DC6FDA18035332FBABC4578A2043FE9276814B80AF656AA17BFBE27900734A66C1B039CD61EE4B9C6F00F88101C82AE3735CC04113B5F220285DFCE67369E2B36357E22895595A85FEC3A15843F37FD174207B09F384D74F6D6932054F11526948764C90B8DAFBE42850AB46A58271AB5982E162EDAAD163E32FD5F1886CF01A7A70A298635CF50CA211877AB9264D14AFFC126A900D53EE1FE0B4164631F43BF33D2723030307BFC70913DCF7F87E03449D3D009E5C84A5AFB6B2605073FF046F30C522E8DC1E07971DDC3DE80002B5370B9440E1134ABF3687B4FA21A28D8EE433DBA30F1419086BF48E2D8DD89CA6189AC1096E289851566056A8E1A05B9C11CBBB742A09B85BA315024F9761E008333EF1960B2E27B0CE5601754BE1E675141BCE69B088D20B4C37FFD87AD00036C30038AE400DFB1BE686C39F10529D692443C498ED440B881525CD3278EEF8660DBFB0436E5E9BFFD4BBA4ACD9BD3EFAF5CBD2DC835381B9F83024B46148FF84838022745A20477299A07452590A4AE340E47359BC135BEFD7B1ABC31DD7B410B136B68182B63BE16703A2B3CDF5818DED34A0D9F1D63B1419536B176A596F00F86801C82AE3735CC0411562CAB56FCE9130B0381E3DB93C6215777E310FB13101BAEB234E141A5AD71095F6035A7F9AD5EF9BC6228BEC1C0F860CA58E7816E9754811937C27498AA9BC04BF66D2B4CF855B6111BD3A1444152C0B53260BABBDE3074BF80A166D3E5E237600E81C26B99CCC16119EF15EEB65C08809F5F7978F16FD24781E1CCA623101B734FC77A39F804FE20CB0826142B30FAF8A839145227C7A569F2C43E9DE5690769DEE54089A0894F9E86DD70746B5C5CA0FEAEA12FB246B1AE92EC463F47811846044CFC8D86227982964381D64C67CAB0BF8FDE652AF0F1549D139E77252AB6900B0EE1DAC492A9D3303C7BF2F42D49F195389C3B2DFF1E6A8C03A3C87851B414C02EB12AF4521F4FF627D13027334321A801D9BBB5D273895BAD16B80B703779F2D8150FA116F8832E53FCB32B6F4DDDCDE1E476941B658D3C8CD110C9EE356236DEDEA9F972DADEBD1F345CFAA86330598114B36B4C812A03B030ED202C1D36F00E87601C82AE3735CC0413709AB7130E1145592F59971323E5D6507783A54F7674FE6FE8FB1BFEF647B64DF5DD731EFD275FD2EC13B03644638EAC11968553725E1077D112A7DCB7A92F73ADF0D357DA9002020DF49C54276F0925137A3266CF66CD074927658FE2296C9A52E2227F90F8705813560D38D8F8E53B2F76AB119DD3AEFEC2841DD980EA530EAB7694688AA197927EBB84FC38944908E051D2EE49134FC6BCDCFCCD3A3ABCE9108E1CD0945EC55EBF932A8BB750CC31E17C6859400E965061A42B1D8AB5643F9E9993D1A3CE3549BE26F0D283C3959F59832FF872442146A084BE4090563D18214DF814AFD582DFDF9EB3CD38DF6D8E18C7664061DADE3E375F0DA2964BEF215543C8602DC506C41CE51AFE5871CCAA612EBAC0C6E5BF38A4EA8E69A2EF485987FEF3F928F6E944EC05C0D8DDC7884FFD9D4848D183EF4C1B0E7E241062C943A079F18E20555A5C8BDE57EF16D680205D5E88AAB66B7402C89644AF5E7BC3ECE2CD48D523459633649A6AED9841A6F0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000201000201000400031100AB5523C980E7473FA885619ED019316F031100A1C21100CAA111D28B020090270750C4170D3130303232333139353634375A300D06092A864886F70D0101040500038181000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000</cadenaHuella> </huellaPlatino> <huellaPlatino> <idHuella>6</idHuella> <mano>2</mano> <dedo>1</dedo> <cadenaHuella>30820776308206DF048206A6308206A23034302F0201030201020410A6FA3B7933624C88B5F94214C007BC6C0410479D6AD1B9A811D2A7A70040339F131702030200000201010482066000F88001C82AE3735CC0410AEFA19FF0F2AD1ED5D474831EC60A25197F9FC97494FCEEE77CC574650CB859B255F952A24F7037EE271387B3B698D6FEA199F9FEB6A8C940B6ACAA6C3041BA9092BD35D1424A8984F891C121350EECBD75BE18D47DE1591589A3542855A5B55A1F7D8588F6E34A13A65B71D5787429F24F17F57F986D591F0DAE0F7F577A49D6EE63E4F30016D606CBCBC36BDE4AFC059F2F588C47D53EFDB52A5D74D1FC5EAA69DF2745A8BD41E1C79F2B515425A605B3D3EDF60437D49ABCC49F5E38EE9308C179126BC97722C00F3801793164FCEF1D8FEAB632CE7E005922F700BC7C2FD94C65A2D1125DB91CD6B2EA309958811CADDE421ED273836154D7F8D4BD8283D63896ED5D89DCFF75AD5C2F111D3E12700296F41BFAB34D57355332FE727C962F3F9EF411C4ABDA5A5403D5E34491F20E864FBF865FBC60DD30665A0C7701F1580170AA501716E1CDD2A14D576BD8889EC692A85C7304862F5733BE638F8011685CC9B7BCDC048E4EF13DFD2680D4228DF4AD622E8199CD4E6F00F87001C82AE3735CC0410D4510F46D2FBF52C370B55D95D4BAB97FBE162388289BCFA15EBD4968CD0E6521B36E6B15004F1D2628DF79ED30D677E58345F1798BEE4F48D4AD133BC0BD2422287FD7DE9FD2E691D229D0B3FBB79C7ECB4D4F52D6D86A56EC0F2A9C712449EE120E95854F9A6E7A9D202C167840ADFA73AF098516B8B66FF04A33DD97CC0A7F86F810B28DA78B412A076FCC0B50122C078207C21034736A20F64D13A6BC3078D4AEDBB69784CC0695A991538E5377C696146B74E7473C23F74EE7ADF3A1E685F8DA433B18212BF91C9E7197AF6BC294E6CD58E96742B164D8EB9BD888CF3D18A074CD51499185C3DA711103977365DA79999FA10EA758C6259AEF2CEEFE274F13A5971F790B716117E45B8DA1A6378DBD15B98AB628A3250F90C27D307FF72D216E7C1BE1689A8A7638022D175B5F34A21D1C5AB0302DCBC3111A6238C7A72E4CFDFEC0715B965B433DA607E3F473155B0F35AED02A96C2139EA9807409C73FAF62B7E22CED891C6F00F88001C82AE3735CC0413709AB7130FE145592D634CBBEE65F3B77B67615BF7FB3FBB4ECAD8A23D1D71706583DFFFEB69C886A18E5E170373F9A0092299BF2459A2769DE796C429F62B1D6BAC9746A1724931A26AEEE85AC80B768B3F81645372C11376D7FFE552B651E0510A02E21BBAC9E496FAB9EDD5099C112AEFED2CFCEE9C71BA3EA2B5108A9851346A37E3DEF012A9327E974F769B4ABC52067B0DD97B39A18B30ADDE480DEF860958503D4177876ADFE82A921BC133509C2BB6593B70711BD1ADE7C85C920B13947318AE557DD96BCF4DDE778BF5B05C9F440645E8DBFCB3536EAE84C49D2C1FAD1301E1B53CFC3B5A3D30CA741A39CE4F7DB8AACEF44CA372FC4995F5BE53F271AA4990AAA155A54C6977A360A4C805E870FFAFB13F40C793A0B0C62E3A673327C368F739F9AB77A9C5F002E53B68CE411D61A96B064640B085C459E33A9ECBD7016697A4AB99845F931A097FCCB100CC3A26529B3448D1498867A544CCFB56D747FBA10FC08016F781AAEBB5575286564B1C24599359BB26F00E87F01C82AE3735CC0410E17A161D462B2862322DA5024B92D549FA7B772D138A3ABDB9388C999E48E39EF96321E8EEE2E2FB2E472788B9213DE3517EC3077FC60FCD9D27731CE7AB8AA086D368A6482B5BEC2FE268B1A9DAB2641B5672A114E83BAA8DBB575275CE986DA270D014BF130888200A0B742294690E8E08F19D68BD42B10210AC13451E3B5C219A8D6B10B41B440CED53777282E99D9CF7F97DFA4FB89A5BCC326048A963F0F4ED87153ADBF07F2F99BDEA8663856D4E88016F4A75EC7A6B229F2810EF540450C493317EACC26628143D97DB1AB9583A65F4003FB38FAEAF03AC338AEDF9DF0722A354F164776573D4B3A8391FB02D004962774BDDEF2914F11204C1F34CD2E3F092EF8BAA441FF1F871ABE630C9ACB78950A1EC87707FA98FE3556B871610248FFC0C8AC113CA3FE9472435D34253791D89B5BA12D1B17823B558C120273A3919B0A623BD9B5E0C3D1F7B3A9E6DC85C1A09F81D37C924B8CD8BEADF1475C2F13E53F8E403096EFEED1F20AD9F36A7AF42BEF5778BBF66F0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000201000201000400031100AB5523C980E7473FA885619ED019316F031100A1C21100CAA111D28B020090270750C4170D3130303232333139353634375A300D06092A864886F70D0101040500038181000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000</cadenaHuella> </huellaPlatino> <huellaPlatino> <idHuella>7</idHuella> <mano>2</mano> <dedo>2</dedo> <cadenaHuella>30820776308206DF048206A6308206A23034302F0201030201020410A6FA3B7933624C88B5F94214C007BC6C0410479D6AD1B9A811D2A7A70040339F131702030200000201010482066000F88201C82AE3735CC041161B9D8259F3BE6FB2952F74C3F139AC2B719508363DA0EE52BD6FCAFD301A0C617308A6938B39B22113E438D6294BFA0E39AC73ADD5CF82A5AABA21E5EE34B210E16DC9B79C3B2129C5C2092B65C9205A9B153649D3A81D99E1D080B0EF4FFE3BAFC28C578F0D8C1D963DB3967C32C7C014F3717351B150BA9468FB6055BA24661E8A0018F9838087CE8173BDAF11C1CAF951B009FC53BD9661103CC40224A367C5879338FD4F30EC57E99BA4A3FA19EA383181BCDE6830123ECCBA8ABE820EF5598FFED6308EFE0BCB513784A217403BDA9097D7642D7F07E28052A89228C189AC28CCCA742FB0AB26B49CBC44F9CEE3F476FF5CF538CD1E27E80E14FF4253CBFC9E2B4FE5D2064EC8503A77FA9A110100C24C91A14A19255FC5C6B91CCA45CE92AE104D6ADC61DAAC5533D31A805DDA4C8C514FC27F427407503FE8FD31C3D2B0231CD61AFD2F29661D2BA3117E3ACD0FD6C40B66A603AEFAF8B55A746F82CC5CE6D149AE1A454FA9FE41499274C4F3FF7B31FE7FD3ACA78ACB6F00F88001C82AE3735CC04103516E8E53E10056DD898DF83AFD16A428E7C91A3DD6B979BEE850E329FF637BDCB1A65D03BEAB3DE1535B0AA4857C378D2B9EB13D4582A2E0BEB43969867C8A92D2DB67013A84597ED62E62E55C5E2A59D609AC00EF93F34E4B53121CD4622FBA54F24DFBE9393B60E860C4E437149C2E0CDDD9EF316734E2202D24D166D30A3E0026301940FA1C9C503F776BA9FDAF686B50BC711CFF4E5D7942C03CD5CF7FDF309306791E8FB5A90CDF5BB6024E94C8BE7F5A39872BC6414A72AD9D3CED73E7F8E0BCEECEFA2E2F27B7432D3D4D77FD17ED42BE548779960A4D8AE957B6F750315A5CCBFC6E80E19A9E580CEE38B5EC6C744B6D1F4577404BC915C78B6F5E9B40ED6CB8AD094F99C9624F1564D48A6080C60FF90036991606E0ED0165722F7760C925DD9ECC8A12C70A5C27321ACFB5449FF16D64B0BD3B5049116D78AF7FF23E57BF9AC28086211181B59CCE12063DBD5B55C4527F31B7A5E277D683AB499064DBDC59EF3AF2F0102B30E3C866FCC2376D38433D25BB656F00F87801C82AE3735CC0410E17A1619470B28623BC3BFB54EA5DE1C20D06995694A9547490363A87916BC79BC956E15C0DDEA9576789C882472E29E792C24C2AA9E13423897CD5E36ED343C5D5D810E25D1CEFDAFCEB5D5376927669ED92E94ECC5D61594118F260C1A450C25907C8E828A8F303384BB4C1858DB05DBAE09253CC69075052FA4DAF9537060F8669F964FFA1B9E9B86FD4284F8B238EB6E5A2785E018ED2B0F6D0FB320B6FF7F44D1BB70DA402117DBC86963394494A061EA16DA92FCB452966618B2D87C1785F6E3A6A2A85AF54F0064EF49C74300ACE5109A963C0CB05DC4E9F961AE8DD2294CBADE280C0512EEB385A4791B365D45515BFD06F39C6FABB53CEBE9604660864D0776AA1CF552AEBF4D87E7188D0CBE0AF17B4CECDC7E2539DD662C861C039A7B258C55709E919CF0D8C6964B1FBCC1AD3F8C80D90CE1FF4A15ED27BB35049F772B8A6A402962F346B5414C72C928BE79CDD77C73E2231D4CD59B2E81BAC99263D6938EDB75E3735C4085B6EB3C5D06F00E88101C82AE3735CC0413709AB7170D31455925315DC967A2A3220DC36335A0B7458093C19EA0A7FA4FCD0A1B68DD3B3E3ED8EADC113CB0D8B099437636F51431ECBD83C8393AAF7E10C32EA88F0DFD3B873275DE5DF66912CD09989EF785F92BA80B474697325E2A0CDDF000E26147974EA1D88A0E798BFA053ABC6528CCD87DB4F2BF5C53B262EC8CDDFA070A4005BD5468AE066B87C2DF404CBF6175D4E5C9ED339C2B80E00CB862D35B3AEA6F2983403F5237F5D1D78EA78DCB2CF4511E13D04F4D07EA0EA66B30E9AE9129755A77F627AEFCBCD11BC52FF0BB46D9A40E68A32E237F61B31AF6CFC3A454945AFC0C343D76C9E6A9ED51AF19A90964810A77B55A64BB162240722482DC5563005663E6E7A12ED1BA6EB379ED635CB3492F51D1D8EDADD56FE70ABAE68F439ACB4FE172E5D0D6C5FF8E6608A8D179235A2AAFEA4B2FA90C8FD4A859E182F385A5885FB4AEF0FF4266699E218D5B5F82644964CE07AD9D1B58A4D3200697E6EF11C4B0A62D4070260EA75B9D71E655321BA34DF9079166F0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000201000201000400031100AB5523C980E7473FA885619ED019316F031100A1C21100CAA111D28B020090270750C4170D3130303232333139353634375A300D06092A864886F70D0101040500038181000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000</cadenaHuella> </huellaPlatino> </HuellasPlatino> <HuellasOT> <huellaOT> <idHuella>4</idHuella> <mano>1</mano> <dedo>2</dedo> <cadenaHuella>00F88101C82AE3735CC041704002AAA7C66950553802DF25FA7351E56DC74F2C14678C9802E4783DC38A2C798F00E82124EF187D6B93548D2BB788592CB1B6C6D944FC8CF832A909C60F8C02912922F0D316C8D878660D293A8A7BE803BE591EE50D8506FD003E959C9B5E1DF8C691F76FF9122D25B81CB4CCA61A838BFFAAD8EA33602D5AC82AD47C7D5FCBFBFD7186C7DBBB9525EDA1279D794B9A1E2138D7155B5D3B107662EB9C4BF73127B763FECA99D32094429B3299C8EF72702533BC6B582A03C27256D279D70E14A06835D8601B5A98FAC9DDE65F15292BCF6EC0538E545AF977330B918D710CD83127BC1E7EB13B72C00575B1614CBB676501C0B53D6A868EBC85C33F91FACB90100F7A861387BD450FAF1CCF3DFC07E79BB08055FC0AE35F485FAE5E0CD113BF528464DE14B451A4F56316A0053E8AB37FD77B213337D3CD51D7C4AF4EF7EB805EC3F0E95E4C8B93D7EEEB06D278FE4D5C8BFDB89ADAE9FE9B6B917B4153DB40BD2B3C47306A02C274D138F88F4C2B734AC83D73EC1C287E536F00F88201C82AE3735CC0410D4510F4ED2BBF52C3C486A6CDCF9A1F1553F3854B80780B0844102088895A7708A606AEE92BAC5EC35FBCB999E23A7AE6B18F9AF1CA3C42A56CDAA4D493F789894B72E0F0E7CF6CBA442EC0150964884B9393ADCE51ECF64645736034B8D5057851D939C7B2EC6DDA034BE6FF52D9B4452BD56A2D07AFF63E2C98FB45485B2BBC05041815FA94A78DFDAB79C17832191EAD643F9C4D06304B57720A8BB06B0D3F76A74788ECB7E1AAA77715F520C31B350EE1C5639EFBE926AD08D36AF831BF8C36460A11AF01FE37AC2C6779423BAD96E8E93ABB47D0A7B17294C066735C351A28FCD0EA1A1E33D2614F56C15B54682AFFC78FCAA7CF89698E6C047EC0408E3E1F32556EA78372974EE4C279A2101EBFCFE75E962094EDD5036B5ED4E2FD7141E9E9AA3C1E1482F8395FC9A4341C90E8EFF66CD91C6752C1A8268C31AF9C8EA9328EF10C21BDCED21F375DA86749AA879CB9D4F1CADBDAC0229A34197942412A09C0A2EB2F20B21D8D3C36D14C0154E0D236FC6A70E6337D8CFC6F00F88201C82AE3735CC041020AE5B0B579F7DC490A7329547707D5B2BDDF7D7ED6DE622A24DD4215D456C52F67D95AB3C986EADB5C03409F6612364F6BE7E1B0DAC0EDB390856DD8EEF87B0A9DF163EA1A309AE130224B14025473A14D8A18FB2A45E08F8159C84356FD61AD57CE7E8270A5BCF5E3E270D395CA2A0242B22B05D04AA36422F141A81283FCBA09FB347D621A477ED2335797FF775EDABBE357DBF82FA1594F9F25EB5002110204946152430AA5A7A2F2E0C168695DAC0527755F4E031BB8001C34FFA0029F831BB8DFBD97453E2C6583A7572A5D3A3AA032478199B77966DDEB36C9CA089E06D75373186B9DFC0E2D1CE8F7A17A3646DD5CB4901755AB9A37981338312999DA9480A94706FC48B748FAF2DF7B6D9B4CCE487E749D14CB44D42A569A0C1A1C2CD0D0F2DDE18F5BC3BA188B025F06DB4E0666CDEC4AAE33C5CCA9A445319C90A7F09E7745D058ABAE276E23788A52A9C97010BF17F67C10A7C900E0B60DEB49409FEBA774E57D268301F21965D4B23463909FF1BCF2F7B46808E36F00E82801C82AE3735CC04154EF4D7229F753C37D1110030CF7E54BD70798E16CBC5A2281DBDEE5D570CF79593D1B47FBD5643BE1F132A6A220EB8E9F57CC8BD3E6844DD48BD28F1E693635F219036AA1A23FF5F9E13B94DFC9B19B5E1C0F4CB89311224DCF4FAB2366C4C83613A87ACD7E4509F8198757B398B534E77763F08A7AAB5160279BD8175EACDEA85043534AFB8F720B915FCA3EBFE61879E224691C432489B66AAB015E17D9E0ADC69FE3419A99303B24B7DD3C60940E3BB09CEF6EB142BE23C4313786758A57EF1675DFB64D1611A44A8AAB3F4594EF18F1452E4ECC38D83AA03BD35E5914539A3A08F990E579C4BBD9923D2144F244552A59EEB6315893C14B9BF4C4E2D273D58C482D61CE9EC8961B91686F3AFA108BDC573B6D28D8AB26AF48CD54E5348D7D6F0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000</cadenaHuella> </huellaOT> <huellaOT> <idHuella>5</idHuella> <mano>1</mano> <dedo>1</dedo> <cadenaHuella>00F87E01C82AE3735CC041071BC34E4CF91DD3DECF41FF38A501D7C0BB1B670CF80B721C3750A81818B6EF1163F159A6E907F4391BA69465C63C68E05DE5712BBA51D938D0D9F0E2D70B086A60D152E685884F4F05558E2342C074AD8A365FC3B4037FA2E912D0DB11ACE3708F9399B00F4B552F5EBBD282D6235264102B932A60B99787CCC5403D7CBF24F376598EF1432288CDDBC754E3CDF63AC4866ACF140AA174299748731C3AA1BA9525A1302433F9837C6BFAA338A4ECF82C282C8F0BB66AD64C60297336F33EB3C309F577DB98C66A0698D9CD1C2EFE587FE3DF2E1A1EA198CF1AA03439B9503AB5D4089D3FA8AE0C992A77538ADDF07ED9DF8FB25CDE94796AFB243C0353E7B200B35E546EBDD826CFA4DB21D5CFD033AE304D29549BAECAFCF185ABD70B990D205E4D015CAC2D4AEAEB0CF689D0A397F88280462307E3C26C1487DCE7B8D339B5CF9514E7FCD7DEB8E33C659E3D10DC6FDA18035332FBABC4578A2043FE9276814B80AF656AA17BFBE27900734A66C1B039CD61EE4B9C6F00F88101C82AE3735CC04113B5F220285DFCE67369E2B36357E22895595A85FEC3A15843F37FD174207B09F384D74F6D6932054F11526948764C90B8DAFBE42850AB46A58271AB5982E162EDAAD163E32FD5F1886CF01A7A70A298635CF50CA211877AB9264D14AFFC126A900D53EE1FE0B4164631F43BF33D2723030307BFC70913DCF7F87E03449D3D009E5C84A5AFB6B2605073FF046F30C522E8DC1E07971DDC3DE80002B5370B9440E1134ABF3687B4FA21A28D8EE433DBA30F1419086BF48E2D8DD89CA6189AC1096E289851566056A8E1A05B9C11CBBB742A09B85BA315024F9761E008333EF1960B2E27B0CE5601754BE1E675141BCE69B088D20B4C37FFD87AD00036C30038AE400DFB1BE686C39F10529D692443C498ED440B881525CD3278EEF8660DBFB0436E5E9BFFD4BBA4ACD9BD3EFAF5CBD2DC835381B9F83024B46148FF84838022745A20477299A07452590A4AE340E47359BC135BEFD7B1ABC31DD7B410B136B68182B63BE16703A2B3CDF5818DED34A0D9F1D63B1419536B176A596F00F86801C82AE3735CC0411562CAB56FCE9130B0381E3DB93C6215777E310FB13101BAEB234E141A5AD71095F6035A7F9AD5EF9BC6228BEC1C0F860CA58E7816E9754811937C27498AA9BC04BF66D2B4CF855B6111BD3A1444152C0B53260BABBDE3074BF80A166D3E5E237600E81C26B99CCC16119EF15EEB65C08809F5F7978F16FD24781E1CCA623101B734FC77A39F804FE20CB0826142B30FAF8A839145227C7A569F2C43E9DE5690769DEE54089A0894F9E86DD70746B5C5CA0FEAEA12FB246B1AE92EC463F47811846044CFC8D86227982964381D64C67CAB0BF8FDE652AF0F1549D139E77252AB6900B0EE1DAC492A9D3303C7BF2F42D49F195389C3B2DFF1E6A8C03A3C87851B414C02EB12AF4521F4FF627D13027334321A801D9BBB5D273895BAD16B80B703779F2D8150FA116F8832E53FCB32B6F4DDDCDE1E476941B658D3C8CD110C9EE356236DEDEA9F972DADEBD1F345CFAA86330598114B36B4C812A03B030ED202C1D36F00E87601C82AE3735CC0413709AB7130E1145592F59971323E5D6507783A54F7674FE6FE8FB1BFEF647B64DF5DD731EFD275FD2EC13B03644638EAC11968553725E1077D112A7DCB7A92F73ADF0D357DA9002020DF49C54276F0925137A3266CF66CD074927658FE2296C9A52E2227F90F8705813560D38D8F8E53B2F76AB119DD3AEFEC2841DD980EA530EAB7694688AA197927EBB84FC38944908E051D2EE49134FC6BCDCFCCD3A3ABCE9108E1CD0945EC55EBF932A8BB750CC31E17C6859400E965061A42B1D8AB5643F9E9993D1A3CE3549BE26F0D283C3959F59832FF872442146A084BE4090563D18214DF814AFD582DFDF9EB3CD38DF6D8E18C7664061DADE3E375F0DA2964BEF215543C8602DC506C41CE51AFE5871CCAA612EBAC0C6E5BF38A4EA8E69A2EF485987FEF3F928F6E944EC05C0D8DDC7884FFD9D4848D183EF4C1B0E7E241062C943A079F18E20555A5C8BDE57EF16D680205D5E88AAB66B7402C89644AF5E7BC3ECE2CD48D523459633649A6AED9841A6F0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000</cadenaHuella> </huellaOT> <huellaOT> <idHuella>6</idHuella> <mano>2</mano> <dedo>1</dedo> <cadenaHuella>00F88001C82AE3735CC0410AEFA19FF0F2AD1ED5D474831EC60A25197F9FC97494FCEEE77CC574650CB859B255F952A24F7037EE271387B3B698D6FEA199F9FEB6A8C940B6ACAA6C3041BA9092BD35D1424A8984F891C121350EECBD75BE18D47DE1591589A3542855A5B55A1F7D8588F6E34A13A65B71D5787429F24F17F57F986D591F0DAE0F7F577A49D6EE63E4F30016D606CBCBC36BDE4AFC059F2F588C47D53EFDB52A5D74D1FC5EAA69DF2745A8BD41E1C79F2B515425A605B3D3EDF60437D49ABCC49F5E38EE9308C179126BC97722C00F3801793164FCEF1D8FEAB632CE7E005922F700BC7C2FD94C65A2D1125DB91CD6B2EA309958811CADDE421ED273836154D7F8D4BD8283D63896ED5D89DCFF75AD5C2F111D3E12700296F41BFAB34D57355332FE727C962F3F9EF411C4ABDA5A5403D5E34491F20E864FBF865FBC60DD30665A0C7701F1580170AA501716E1CDD2A14D576BD8889EC692A85C7304862F5733BE638F8011685CC9B7BCDC048E4EF13DFD2680D4228DF4AD622E8199CD4E6F00F87001C82AE3735CC0410D4510F46D2FBF52C370B55D95D4BAB97FBE162388289BCFA15EBD4968CD0E6521B36E6B15004F1D2628DF79ED30D677E58345F1798BEE4F48D4AD133BC0BD2422287FD7DE9FD2E691D229D0B3FBB79C7ECB4D4F52D6D86A56EC0F2A9C712449EE120E95854F9A6E7A9D202C167840ADFA73AF098516B8B66FF04A33DD97CC0A7F86F810B28DA78B412A076FCC0B50122C078207C21034736A20F64D13A6BC3078D4AEDBB69784CC0695A991538E5377C696146B74E7473C23F74EE7ADF3A1E685F8DA433B18212BF91C9E7197AF6BC294E6CD58E96742B164D8EB9BD888CF3D18A074CD51499185C3DA711103977365DA79999FA10EA758C6259AEF2CEEFE274F13A5971F790B716117E45B8DA1A6378DBD15B98AB628A3250F90C27D307FF72D216E7C1BE1689A8A7638022D175B5F34A21D1C5AB0302DCBC3111A6238C7A72E4CFDFEC0715B965B433DA607E3F473155B0F35AED02A96C2139EA9807409C73FAF62B7E22CED891C6F00F88001C82AE3735CC0413709AB7130FE145592D634CBBEE65F3B77B67615BF7FB3FBB4ECAD8A23D1D71706583DFFFEB69C886A18E5E170373F9A0092299BF2459A2769DE796C429F62B1D6BAC9746A1724931A26AEEE85AC80B768B3F81645372C11376D7FFE552B651E0510A02E21BBAC9E496FAB9EDD5099C112AEFED2CFCEE9C71BA3EA2B5108A9851346A37E3DEF012A9327E974F769B4ABC52067B0DD97B39A18B30ADDE480DEF860958503D4177876ADFE82A921BC133509C2BB6593B70711BD1ADE7C85C920B13947318AE557DD96BCF4DDE778BF5B05C9F440645E8DBFCB3536EAE84C49D2C1FAD1301E1B53CFC3B5A3D30CA741A39CE4F7DB8AACEF44CA372FC4995F5BE53F271AA4990AAA155A54C6977A360A4C805E870FFAFB13F40C793A0B0C62E3A673327C368F739F9AB77A9C5F002E53B68CE411D61A96B064640B085C459E33A9ECBD7016697A4AB99845F931A097FCCB100CC3A26529B3448D1498867A544CCFB56D747FBA10FC08016F781AAEBB5575286564B1C24599359BB26F00E87F01C82AE3735CC0410E17A161D462B2862322DA5024B92D549FA7B772D138A3ABDB9388C999E48E39EF96321E8EEE2E2FB2E472788B9213DE3517EC3077FC60FCD9D27731CE7AB8AA086D368A6482B5BEC2FE268B1A9DAB2641B5672A114E83BAA8DBB575275CE986DA270D014BF130888200A0B742294690E8E08F19D68BD42B10210AC13451E3B5C219A8D6B10B41B440CED53777282E99D9CF7F97DFA4FB89A5BCC326048A963F0F4ED87153ADBF07F2F99BDEA8663856D4E88016F4A75EC7A6B229F2810EF540450C493317EACC26628143D97DB1AB9583A65F4003FB38FAEAF03AC338AEDF9DF0722A354F164776573D4B3A8391FB02D004962774BDDEF2914F11204C1F34CD2E3F092EF8BAA441FF1F871ABE630C9ACB78950A1EC87707FA98FE3556B871610248FFC0C8AC113CA3FE9472435D34253791D89B5BA12D1B17823B558C120273A3919B0A623BD9B5E0C3D1F7B3A9E6DC85C1A09F81D37C924B8CD8BEADF1475C2F13E53F8E403096EFEED1F20AD9F36A7AF42BEF5778BBF66F0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000</cadenaHuella> </huellaOT> <huellaOT> <idHuella>7</idHuella> <mano>2</mano> <dedo>2</dedo> <cadenaHuella>00F88201C82AE3735CC041161B9D8259F3BE6FB2952F74C3F139AC2B719508363DA0EE52BD6FCAFD301A0C617308A6938B39B22113E438D6294BFA0E39AC73ADD5CF82A5AABA21E5EE34B210E16DC9B79C3B2129C5C2092B65C9205A9B153649D3A81D99E1D080B0EF4FFE3BAFC28C578F0D8C1D963DB3967C32C7C014F3717351B150BA9468FB6055BA24661E8A0018F9838087CE8173BDAF11C1CAF951B009FC53BD9661103CC40224A367C5879338FD4F30EC57E99BA4A3FA19EA383181BCDE6830123ECCBA8ABE820EF5598FFED6308EFE0BCB513784A217403BDA9097D7642D7F07E28052A89228C189AC28CCCA742FB0AB26B49CBC44F9CEE3F476FF5CF538CD1E27E80E14FF4253CBFC9E2B4FE5D2064EC8503A77FA9A110100C24C91A14A19255FC5C6B91CCA45CE92AE104D6ADC61DAAC5533D31A805DDA4C8C514FC27F427407503FE8FD31C3D2B0231CD61AFD2F29661D2BA3117E3ACD0FD6C40B66A603AEFAF8B55A746F82CC5CE6D149AE1A454FA9FE41499274C4F3FF7B31FE7FD3ACA78ACB6F00F88001C82AE3735CC04103516E8E53E10056DD898DF83AFD16A428E7C91A3DD6B979BEE850E329FF637BDCB1A65D03BEAB3DE1535B0AA4857C378D2B9EB13D4582A2E0BEB43969867C8A92D2DB67013A84597ED62E62E55C5E2A59D609AC00EF93F34E4B53121CD4622FBA54F24DFBE9393B60E860C4E437149C2E0CDDD9EF316734E2202D24D166D30A3E0026301940FA1C9C503F776BA9FDAF686B50BC711CFF4E5D7942C03CD5CF7FDF309306791E8FB5A90CDF5BB6024E94C8BE7F5A39872BC6414A72AD9D3CED73E7F8E0BCEECEFA2E2F27B7432D3D4D77FD17ED42BE548779960A4D8AE957B6F750315A5CCBFC6E80E19A9E580CEE38B5EC6C744B6D1F4577404BC915C78B6F5E9B40ED6CB8AD094F99C9624F1564D48A6080C60FF90036991606E0ED0165722F7760C925DD9ECC8A12C70A5C27321ACFB5449FF16D64B0BD3B5049116D78AF7FF23E57BF9AC28086211181B59CCE12063DBD5B55C4527F31B7A5E277D683AB499064DBDC59EF3AF2F0102B30E3C866FCC2376D38433D25BB656F00F87801C82AE3735CC0410E17A1619470B28623BC3BFB54EA5DE1C20D06995694A9547490363A87916BC79BC956E15C0DDEA9576789C882472E29E792C24C2AA9E13423897CD5E36ED343C5D5D810E25D1CEFDAFCEB5D5376927669ED92E94ECC5D61594118F260C1A450C25907C8E828A8F303384BB4C1858DB05DBAE09253CC69075052FA4DAF9537060F8669F964FFA1B9E9B86FD4284F8B238EB6E5A2785E018ED2B0F6D0FB320B6FF7F44D1BB70DA402117DBC86963394494A061EA16DA92FCB452966618B2D87C1785F6E3A6A2A85AF54F0064EF49C74300ACE5109A963C0CB05DC4E9F961AE8DD2294CBADE280C0512EEB385A4791B365D45515BFD06F39C6FABB53CEBE9604660864D0776AA1CF552AEBF4D87E7188D0CBE0AF17B4CECDC7E2539DD662C861C039A7B258C55709E919CF0D8C6964B1FBCC1AD3F8C80D90CE1FF4A15ED27BB35049F772B8A6A402962F346B5414C72C928BE79CDD77C73E2231D4CD59B2E81BAC99263D6938EDB75E3735C4085B6EB3C5D06F00E88101C82AE3735CC0413709AB7170D31455925315DC967A2A3220DC36335A0B7458093C19EA0A7FA4FCD0A1B68DD3B3E3ED8EADC113CB0D8B099437636F51431ECBD83C8393AAF7E10C32EA88F0DFD3B873275DE5DF66912CD09989EF785F92BA80B474697325E2A0CDDF000E26147974EA1D88A0E798BFA053ABC6528CCD87DB4F2BF5C53B262EC8CDDFA070A4005BD5468AE066B87C2DF404CBF6175D4E5C9ED339C2B80E00CB862D35B3AEA6F2983403F5237F5D1D78EA78DCB2CF4511E13D04F4D07EA0EA66B30E9AE9129755A77F627AEFCBCD11BC52FF0BB46D9A40E68A32E237F61B31AF6CFC3A454945AFC0C343D76C9E6A9ED51AF19A90964810A77B55A64BB162240722482DC5563005663E6E7A12ED1BA6EB379ED635CB3492F51D1D8EDADD56FE70ABAE68F439ACB4FE172E5D0D6C5FF8E6608A8D179235A2AAFEA4B2FA90C8FD4A859E182F385A5885FB4AEF0FF4266699E218D5B5F82644964CE07AD9D1B58A4D3200697E6EF11C4B0A62D4070260EA75B9D71E655321BA34DF9079166F0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000</cadenaHuella> </huellaOT> </HuellasOT> <HuellasHom> <huellaHom> <tipoHuella>1</tipoHuella> <idHuella>4</idHuella> <mano>1</mano> <dedo>2</dedo> <CadenasHuellasHom> <cadenaHuellaHom> <tacto>1</tacto> <cadenaHuella>464D52002032300000FE0000000000000165018800C500C5010000005625810F0095526380F5013B826040D000B25F5D80E700F9525A80C400E1025A812A010F8F5940E001327F59809300DB0F58411C00C54B5780BE00D767574104011A8C5580F8016E7C55411F00B7495480CD012F7A5440AA00AB085180DA00B8AF51412F00E2974B40BA00816249809F0089084980E000F8A24481120168854240C10123744141220148943E4126013B97378125015B8F37813301169935007601471934013301432D34013600FF3C32012E01613C32013601063C31006F00DF702D01180161882A00D101168C290133015E38290134014D3329012F015B37280000</cadenaHuella> </cadenaHuellaHom> </CadenasHuellasHom> </huellaHom> <huellaHom> <tipoHuella>1</tipoHuella> <idHuella>5</idHuella> <mano>1</mano> <dedo>1</dedo> <CadenasHuellasHom> <cadenaHuellaHom> <tacto>1</tacto> <cadenaHuella>464D52002032300001460000000000000165018800C500C501000000563140DE00C38364807200E4926480E8008E4760406800566C5E804200F98B5D80A60123715C808C01215F5C808200D28C5B80FE0076985A80E800584E5A809900BE785880A600620257406801434857808800720A5680FE00CC875580BC00565F554092003F6553406200DB8353809F015B675380FC00894453808F00CE1E5240420130A05280E600789F5140CC00A48C5180BA00E47851809900D81B4F809F0105694E80DD00869A4780BF00EF7A46405300FA924540A900C67444809B0151654440F80106283D408300F3333A404400AB1939804F014BAB35409F01640E3500F100354633004400991732006101535132009000DD1E3000CC0035AB2F008F00E4242E008400FC132D00360120922C00B000B68B2C004000C5792C00E10035A52B0089003562290000</cadenaHuella> </cadenaHuellaHom> </CadenasHuellasHom> </huellaHom> <huellaHom> <tipoHuella>1</tipoHuella> <idHuella>6</idHuella> <mano>2</mano> <dedo>1</dedo> <CadenasHuellasHom> <cadenaHuellaHom> <tacto>1</tacto> <cadenaHuella>464D52002032300000CE0000000000000165018800C500C501000000561D80E700975A5F80840083175D40BC010F8F5C80B100DE7E5B408600B0755A40A900B47459812301364459809D00DF7E5880FB01069A5840C5005C685740BA00B6085680F700DF555640A00108875640B60051045580B1006F095441050090AA54811C009654518120008EA45040F50062584E40CD0136974B80A500E5194A80E60174464A8086011F83478120007D4D4640FF013A414340E700FF984141290136474080B6003D6A370141012F9E2C0000</cadenaHuella> </cadenaHuellaHom> </CadenasHuellasHom> </huellaHom> <huellaHom> <tipoHuella>1</tipoHuella> <idHuella>7</idHuella> <mano>2</mano> <dedo>2</dedo> <CadenasHuellasHom> <cadenaHuellaHom> <tacto>1</tacto> <cadenaHuella>464D52002032300001700000000000000165018800C500C5010000005638807400B68B62812000CE8D5E40600051195C80610069825C40E200B48C5B40A301029B5B80E80132715B80C501324E5A80F500FE7C554092010E985580A50051695540A50070715440D100D87B54806200752154407A00E48F5440A301329D5380F900C68B52809E0130A85280E5008E3F5140C700B03A5040A6011CA55040E80084924C810D009C914B80CA013D0B4B40D10140044B80C100C0384A80BE0076A04940A60106A149812900AD914940970060054840B000EFA24580BE00D83D44409701139B4440A001163D4340B600A4904041070095913E80C100C93C3E40C400FE4B3D80CC012F5E3D407C007881394105008B963980B600EDA23740B401404E3600C500CD3135013500BA993400D80141143400AD008A7F3400E801405F3300630039783200DE0148672D00B7009C942C00C500F8482C013400AA9A2B00B3008BA12B009500356529004400837C280000</cadenaHuella> </cadenaHuellaHom> </CadenasHuellasHom> </huellaHom> </HuellasHom> <HuellasRequestDTO> <HuellasWSQ> <huellaWSQ> <idHuella>7</idHuella> <CadenasHuellasHom> <cadenaHuellaHom> <tacto>1</tacto> <cadenaHuella><![CDATA[/6D/qAB6TklTVF9DT00gOQpQSVhfV0lEVEggMzU3ClBJWF9IRUlHSFQgMzkyClBJWF9ERVBUSCA4ClBQSSA1MDAKTE9TU1kgMQpDT0xPUlNQQUNFIEdSQVkKQ09NUFJFU1NJT04gV1NRCldTUV9CSVRSQVRFIDEuMDAwMDAw/6QAOgkHAAky0yXNAArg8xmaAQpB7/GaAQuOJ2TNAAvheaMzAAku/1YAAQr5M9MzAQvyhyGaAAomd9oz/6UBhQIALANkYAN4cwNkYAN4cwNkYAN4cwNkYAN4cwNsugOCeQN18QONhwNv7QOGTwN1HQOMiQNtAgOCzwNuEwOEFwNzRwOKVQN2VQON/wNifAN2LwNnrAN8aANmjgN7EQNlyAN6IwN3owOPkQNrMAOAoAOCqgOcywN9JwOWLgOHSwOiWgODrAOeAgOOAgOqaQOHOwOiRwOJnwOlJQOK8AOmugOULwOx0gOHgwOinQOPLwOr0wOEQgOetQOLnAOniAOOOwOqrQOfVQO/MwOOwwOrUQOMnAOovANvKwOFZwN2OwON4AOF0AOglAOGrQOhnAOHYAOicwOC1wOdAQOClAOcsgOADgOZqwOIwQOkGgOGsgOhogOCZwOcfAOIWwOjoAOFDwOfrAOCMwOcPQOH5AOjEgODqwOeAQOa1AO5ywOAVAOZ/gPRxQP7ugOTbQOw6QP4EwIdxQN85AOV3wOOmgOrIAO0pAPYxQPa0QIaQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP+iABEA/wGIAWUCTSUEPEUCKUH/pgCKAAAAAwQDBg0KBhAVJQAAAAABs7Wxsra3ArC4B66vubq7AwYICQoLq6ytvL2+4gQFDA1mqKmqv8CjpqfBwsQOD6Slw8XHycrQ2dze4OHjEBI6QUpVa255i5qfoKHGyMzOz93fET5GR01ZYW9yc3V3eHt9gIGJioyNjpKTlpuiy9LU1dfb5ejr7v+jAAMA6dOnTp0+r6f2fR9XTp06dOnT6/r+v6+nTp0+r6fo+nyw9/8Aw+D/AL6dOn0/T8n+X93833vxf+9On1fr+nh/X/R97uUP6v8A7p0/Z8/+34fwdyh3KPctfyf+dPr/AF/Px/B/H3MXcwdy99/6un1/P9GH4f5e5Z7mrua+5Q+bp0+f5vV/b9/uW+5p7m7uXfk6dPn/AN/8fw/0/wAPcndy3/F06dP1/p/s9P4/7/5+5N/N/wA9Pp+f6Bx9nP8AH5/R+np9H/H/AF+r4vk+X5fm+b5fsG5wc3Wd+egz75lvR+fQ/lOO58PlCI3b8XqPkCfjV7PWPWIPnwc1ObhPF78oNvClfVPCTlPw0P8AoHbLHwYYNigbeOdh4iWTxk1xd2Ok8efr9uOmGT1k6CL+AidUkRbqT48oBPUWi+GbqR8vG+IDxRCzRBe2GiRmGato0J7LPLxhAkwnRX2a0MHqMQqP1TBUWuZPPVFiGu4Y5wI6qtlggZom73xDTXRipib90BFGBW3tcV0Q8WdfuJXKioVpXUVoODG+222CLhqPmdZdFUtSPJ9RyfFCEYC831HB9ySMS1uL3HHHlIcwJGKbqNDkJiS0YJRvfrQXfyqak9S8D1GkyavzQKMrd1qlvCOY8nOIdV4W0JEZ3+FfLkGrbEO+dxtbIWNWlwa5dZnHjuZTaUCzxjp4vwwwiMIUFMy6zz9pYoTicc+8XnrPO2comMnDx44v1nHIgyzy7yC7aZqSzRCRVUGpComUIIS1a6CDliaJ1JUtDwaYUh9EME5CeDSH+0SSSTqcEkFPfhVt17dqhHQT7iVLQYC7bOIhSnPZyQl4NUZ22tfiXYrGFsV8WlExECDrSsyTIEknXARyZSctD67zLMYEWfNwbk2Na4OZBdBl1qjS2LuzwQdkvECBNUxIZdZDvCve90ohCuqOfKrVqMVThAi7J3ERTKvDCYi5Szg5VkGZUHU4UWRKghaiGwQycTikFpXUhASilToOhdTkK1ncwfuJaUISBC2l6KKE9kApGS/beZDUbsSjF1KdmL6ymqVgmcI3ESzteCYl3w1znnODgkKFqLb2rOhkqK5bxhOQrabQWOko2kYYO9bQpi6HjHd44WqU60pPE+GG/dfjYQCV1IK2VWzLTBdBXIMpViDavFVjS4wBQww4O5U3RztFXUrKynBrk6TcBByBe2qEKoGJQbGhugsTAmRGhXQCCQjB0H7r9hRdEhX9pEKS0u21oowiGDbEqzDlgrbHvrI4KU4m1yERAZDElny1vhaBBs2jLUmxGNtEFylcmd5hlJsHwVzqHswkKuJwOlRggr2FmychtJhKZdK1+YthcrcGJLO0HFVnTna8ZCztATT4Y6bBwqO1gqhl1pKaEwzho74uZ8RAMwXR4m4yoh6KS5Iei6iUKghTjRb6QdCQqIdGvU1FGiIcIJdaX3FsOg3K5JOHB7UycIh7HtizqiFjtd4LpWeK7CGxvijuRetlk7hOECouIJLzWRYg4rXVnCRMGBB1mzjhJUOTDK4zei7ky0ceANxevJ3yZflf2Nz5tqUQFjEb8f1BsOspZPFmiLMmXxfk9EaY3QDejBmcv0ez0W0potgLURi/0fnK0nBTR1CJt58FrqVoLicN0g6SxhrBxi5siH0LRBomQMsqMaKeuKMQUda0GhoQuoz+6etIFaK9qBcQF7hpCCB2qHcF1Q7EFEQ4RKWy1XkvWhWy3G0wgSyZazye+HiCI4XrVVzCREPwjwVz52xGDwIx3Y1Wkzxg8MsYwxaHB0oEuvZ600lw+ot4xy8/gnhYoQbnKWOXrlymeF1p3mzFHx4s8DA6TEQZLnNhmDci8MYmOOFt9tSiCU5CiZvXWRFXhKWIURrQcGIUO50HQtCBC6l1L7iuSNIL9pKIghj2HRCdOu0mjy7ntISChOofaXsqPSV2EGBC6lsLiVNFSuTrW8mZBRnf51VxVQndXl7ej4nVyrIdO55d/Pf3o6rcLOKseGLUPWqVmsOq855cpJjSaRYLRzmvFF7ji4Th2xr6PeUwdTp0DiN/vZbgdTlmiiD+n0YzqSNZIREb8OT6lJdBOmQfQbngEwxV8dS0HUgVpX2iXdyze7iQcrYu/bJRCYidpJTRgMrB9qZ2yrD8Kx2pAp4yygrbEl3aAxT6iC4eaMMnU66uGaC4IkrXJs94swIg7LBmhotY6HuIqmhq4J6LZAhJIKVoWqDvy4GXBgl1csLcayTAVIgnrK332zaqvbHiHk3GfVPCoM1lO+tYZw01MFFQdSxzLoQZk9pi1HUZZx2FFFCRj2tfVxEF/wBtGEQY9x1UJiFtLk5Byg+15RZUrMbMUsE4h4Y7FxjmrUzeJ2ePqa8xViN2/XHr9vt5yCrPy8tSvF/ju3QGwU8rk+/08PLy8s4Xwcnsrjn8HwDw8PfbDgaLSSvLD0v7PjWdI1r0+jxy58+NpQTnrLN5Gfj9nHMJKh0xh4xwPt9tlQlHTjzfCMPV7/5GzeDN2D83L+vjlL4pRdPAoLCefFB315hzQsXU7WTGYVSDrJCBCdHUetR1JfbJIJ92RabTnD9qcqW9lvyZHaQ6twafeHM7YTTXhNf8/Lejsqg+FfPHh8VYOuMDhGOHw/H7+JC0oKuKyvtf4bi5Oshgmzv/ANebqNuRicZ4fo8IDaiGoniuZcpbC1lAVuINHVxqL1CVcKQrkImssUQqPBWlYYQcmqSS61mSo8IRBR0LSuFq/HfnuxbFIE3Ej37eXv8ALBEEpXJpbv52vTxBcnShlh7EMnWUTFErn8d0WczDv22s+DGHUakFSu5oxxRbrX7xKweBDdtc974Q5tXafO3qxwC3+19i8+fh3+b4xv5ZHWfHvHtvkSwz2ZY8fPKpeOX4q64mL7Nvxx9PyfDsiSY9Xjzv9PC86lOXLjfv/PjjImNSzeuEc47/AEmI1nC8yeDfDV4YLSrYhVJs6BWurQIe3GRCKXWZkcM8HQQRWonw9fDzFS6oStM32GffflaIJT6uNLHju3MZB1T73MqG9fmnMLU3BAiLbnL/ALUqCdpiAYM4NqWhOD1JfbVD2IEOSoJ7DC0QyW1nCCoidlsoJhIQFsbvvoRBq51m3L180CDMW1kYljEUXfvVy3+Pp8IVC8fDhrnP257qvTHwzbVbLnf+VuUVfzo2psO/1cfzZwNzOVqYv5/Fxb1QTqKfBvPjOSwJUbJIe/dh4SUISutYOWjLJNBN1RaQY8/MOUDrLItuv8U7xqSCKQQtGGt5JJBeQn1l3UEIhHtKNED90pUgp/dR0FE9hQKh4otqlBaHoexIMjDA9kB7PRwQVcQU7FyYVMXWpwrFwaWdPrcsWo1PDyqdSENL1cQ+GYOuCsEX0ErZCToRlDgk64DELw5ZynR0kOQ5RC44pJlpJECawb83rCNxBgOEmx3eAbUW0OEDz4eL7HCQQNPXvbWYcI0eyrJ2JBILQfdP75So6C7C0QG0StrCCxekbY45ZVYyix2Vq9dCB31WqMuPLlKkVs2tFt3CU9U85bJm2XsxYv4+rDXNssr/AB3NEbspbU7378c88z47wdbQuMb/ABqs5EG6FVSlGIqQTcayd5Uh4BWqLK2LjCKIRcqvAwtnnBQSB0xogYF3o8K68QHeYK0HVxLJVSk9junCE8XBW0wCRER2O9EaKNR6kF/AvsIE0ih7DBJKVFtSNCUCltNC7kNBxK2GAiUCVsKITImjnaRk8GjyTrTQCHRBDOdRl4CIIdCNZCCIKRSbUnCCDOLUK2JgU1YeAbjQiHGFa6CCbiE4QIUg0WqugoFJyVqdAhB6RDrXDrQkDvmdsFUd1hxa/wBwqhRK7EUCgfsoFav/pgCRAQACAQICAgoGBRMqEQkJAACztQECsgO2BLcFBgcICQoLDA2xDg9psLi5EBFqr7oSExUhJykrMTM0NTY3OkNERa2uFBYXGBsiIyQlJiosLS4vMDI4OTs8PT9AQkZISUpLTE5QUlNWWFmsu7y9GR0gKD5BR01PVFVcvr/AwcIcUVdaW2Gpq8MaHh9eYGJjpKr/owADAf8A8IOcB0ZmsxOwFa14ttLM14cW85KIPXiBHIrOvAXrqtwi8PHN57yZJZ4O4OuZeUl1buLfEz1G89XU3995TK5/8f7/AO3nvdbEt658Zn/j/j+O/qRjdef/AG/09Hju7+rRdD8f8P8AXcd5M1mupr8e++8GK5j3+g4FAwDUjtYEywqztuWN4vBgE2PkMHc0m1OgxaY82EcJxYR2F83RozxKua2U8bEZkhA33MxKMiZ3lMCjGTca9bmcLVu06+F4zB73zudrLyMHqdczw79r11wKtzx6+fbkzEgsQ6u0NYQl7Ha0FMyjOvC8xjseGcmhM9AIw3XRsdB7mtYekUJ2syZ8tizInIMZ2PFyUsY7yPXwgEej1zeUphnhmghjw7/B3E10Osv0dTckct065df4G5o6wPRcHw2sNMy/R6J/5beec9df5/7/AMV4ZKUPQxHdlh1SdfH47/j37iZcGt+Pn/h8m9jEtrU7+OblzrYKcTMBRl83aHc0oxh2MIxOgbHoZhTg5uj2ZIljTDkCYJfF3AW7xoHOM28AsyS3xgcCnOvXMyC70Y5M6ZNoRJnBmr3EEaNayZ3I0Fay/Ad4MAaua7xoacXuJfqJuI90Ew6OxhZ0UIzOfK4eLmmnByWCsJrwOo5hMsDeWaoUNXwAlkaY7wyvVZmDw69Y6wNfj6+JL3hTle+5euu1QsLMXr8edrRm7mdWX59TdnYl5vzx3Z1Cy5l7WFJV0bVojADkDCG5o7pg+UfMG+jCmI9jGGDmYaMPFYQYU8VmY6PRwUKLwQLSJTwJdGPP6J/O/A4pon8P5/y6u4C4QJknhedxi4McXk3jegvXW3gJGsvRiYSnkG4h2HK/I9zY/NV8i/KSFPIjAIU9Da8jMW7hF4XE2FXwMZxcOTp1itPDKyxM+Hn6672izOdb+RibhwVnU+RXcy8Lom4CFwuE6udzmLku8lefe6OiX133S0wp5LoEvmaPdFHrvzWPpBBjxNDRKeJCGEoOljEw8EitNNvPJA8etuXsVvOM8y4ZJmXfMgwTv1N6pHQvwHfeHS2PpkE8hT2G07oN2Haro8lieVApY9AbjS8dWGgF8rKLoc8M3OrAhm88fBFTMJrxu8xUbHeMyJDXqnLVYefWdaOeSWXYG80XPyTMN5DBE19GY77IMC/DXwjuYxYzOf5a9ebSHf4a8yNLnveKaCTPc/sPK/Oehoxwcbytna6DocCWNNCcnJhxnggdWh8LTeahkgXScXMJevMpwETisYRi3ytIRywhHcuwqy960wIL15FFEOx0PIL3NxD5RLYjyGOh0aWLDmi1cIcrzbTTfAIYA6NAFZ68W87BvMd5ZSsAeAtwJ4NG9q89euaF4MM9fOfyM0blYxnfk6KFXqsHjZm6bZk3hRgp68AsIx8IZeZCNnoONu1zfkdHmdzsx5kafUIdjC/KwNaul4EWBocRzg0vi3CFwPG87wRgEfDPApLQvWjeS2E1L5DBbzqrHemE66ww8DCXocTZm6eBRs8Ox2DScU0ZfJImx7oU7D5QPpMSmnsDysNj0XicgAojwAmcOaXg5yWpNc9+u80yteHhDgEVJ5+QLTSahwEjggXvQVsi56wN5o5xZzNqPINLDkG47rU+oQe1flDQ+keoHAeY26ZjxHODKz0HazMYnai5hwYaCHychMBV4d7gSkNTyFJ0dqJ0O6MPKsSL0YEYdjteYRAfJlpDsuJLWPII0gQ5oFX169eCMyxhPj68CZUC76ueDmAy+wspe9jwcCzqEIblsjlP4pB6Mz4+Aj2j49+ueTDCS+RtSPF0PXDukTsYUeo4OwIeVphHyu55JtHrDkqUZpObRWVOLRCiK8lpo8Sjkxi/H8gnFWK57/Rq+Urw+ROQYKXypDXq8za90qbhl1m+g9fHz/6f7f7devTXPXw8/wDv/r/r/wD3iclrPh/6/wBs34nMmfP/AKejX/8AR5HfF7/D+X8+/I8XIy8+P/r/AM6w5FM8Nf8Ajq80tPDP+v8AG88mOE/368zPVjLzrQcAjLgZDgVkzFSjijfjixo45vX5M3nwlxuXwc/y/wDGRzsN71v0fwy5iR4PyePx6+Hx5l0PHr4zq9+Zeoci494AvapcM9mclzXO1/wvU65Xv6dfB8Otj3876/xvz5rPhfLX0ejzizr/ABOKzrnNZn+rxPDPh43L/j8ffrwPP1t/l8nn1nj1vgrnx9HyXPR/POeDnHyfJ46+jxHeWxn8vG3wy8CKpc6kOL4N2GTnd0tBAN+deq2rgNxnvbczUwPDrqT5JYU3vavv1zBeOt96tvhmDx76W86t8zCmfEO0iR6MX8jR5EoznsMCQPIBNTyMz4Z8hRPP1z2EJYkOZCOTw8Y8nBG9fRb0dDJHk0QHqIcClcjmEOZFpemZkRq3lcyMMwSjgW0nUU4hna9HJrLrMOhhoOzOYRueL0DBCzsAo/CkSnomcgQ6JdEOwmZZDPRsI2PIhWZkznlqL1A1lnBi6dTXV5F2TwbhxZr4ZihzdZZRA5XCK+CvLNzVlhzuMdVjyWE77hkjx1oTrfRmZZM6oBvdbGX1hzFhGjoUbLfIwmfTf8mZ9MhRDnZnMZa9mSsrryZmBGXk6dbyket8nM1QNfF45muUC/PDhYXk6346+fJvMJT1CHDXLdh2BVwiseILVtMd5VgMad4BCut9MwMlvWFO925zRxzTCWc1plxteWXBZNfoGh+82HkaKOwirR2ZhEbe0IL1I8ki3M4zyG+uTQ6ELFbXjmFNPXw654kCEzrM9iS+ubB5kS/Fewznv+Pr4WdhWc9+rSQ4MbjLVibyIudTBzGxhkOIYGvC1eI0DA8b5sSGHyuDsfyHpq0HaYE8itPNY50DlZZNSKcXOWE1hd8ru7ZYBxu4s1Ll68c+Hgd9qeHQvr4PhCIb0JrdzU5mXVnW89CMIseTkms69Y0m++rHVyxjwzCro6nNRlwOjGjYPF2nQ7nh9IAxmPMzhaXmCNXA5BeuVZmHIzq26XnlqrDMJ5+/iXffMxvPW+Wc+HV18bmXJy65z11/nNbORZTMmvblR16vQSrnVpORXXw18bdDcZw6xWDwSFZ7+/r2AxDOqhxNDBlOhsTtY4P8z0yi06MM25zfaV1svsWMzr1+O3msEu3sYA+Ez5BGKPMrNOpzJmNtuDklXm8PIhANXsAhveBMxFy0vEYxjg4DCB6ZmOHkjEdF4rFaGnmLHDnouhHPYGH9qssb7HrQdrL1QOwnj4qeDzzWcE15l3nWXkejjLHkIAtavGwsrOdemWI+MDiqEznXssIuseiTJF6DnOXY8ieDRT2kKzTvzGruNHFUwuHtYh0Njb2P/wBsfStngPQomvocnkz19Hj3w5mLzL9BnnnBr1+SjsafH0PY0XO/Pbctr5PB8rHx7CKJZ0UYzMz6QmjzOBxaSZB6BB0CjgtsWDTxSGGHzHyuh6h5X/q7DtuW1no0dY/J17C9S0HiEJ8kb8NeZXXvzPDwfSfOdCOQp5sWPg9ToTOWC8yMW/ILHXBwcMYekxwcgmQ7WIQhg4OGB0CkwdLuEy+R+YdzcpMkehZTQcyOoS+jXhdjmHJhnrCOpxSyhlnhfBacsfRDjZ1j4XC043Z4MzCx5MLnhcTijLI6HNY2djMxz2OM3GGDiRIUsOFtGYtPBKJkwcUGmntaKei6OD039780o6CXB8h3y3q3F5t3rQMOVwswnX0c8zLMxz6M8QcrRHw5B1rr4ZnoHk0ZOuufR25KP43Q8RhCZY8ykgxIcTBldh0fBXAb80EzgicMwxfUYdDS+sb5ODYdoQoe5sWnsuMIHZm4sDyFLnwOJASM8Dk0d8IfJHmZ63Dqva/w1l9FgZ75b0Iq95zBq23tUjnoVlgdhS0dAjThwcmnBxI6K9FwRTkRwnkP6XuhLoPIxHD29W2BeeY5pM5HoaJV82PXXvpjyIX59Rf4HNVfP4mR5mme9sjydFXmqU+Qw4y+W1p6OjWQg8zBHBxdjCHJ0GEXmaB8t8wLRpRuf1n5TaR2uDRj3UR/3KNx3RzveQ4fhImGna6P33Q3MTa9D210Tgmw4P2imEE0XY8hHCey8nYcDee2I0x0OBzH2VSkSG90HkP3BjhHc0JuE+q8DCN8jGTYiPtFNCaGEwc0+uURHRg/0I+w7EcODPppRg9g4iIZhQ0PkR9cYQpoSMBNh2uh9opjDA6FOhowRH6yQ2GE3EdoxMEE+u6EESlShhDYMSJnB/WQ2pgyNMKEybE0brW37N5EzaEbRwlNNuHq9Vmb9oaRiMPKDbWfWCDS0ZhkiREoiO5M3es6qPrkMDQ1m2IwSG8TN3NZcT6ZSUxHYTJhE0aQyAliw9ZpBjGCMMxvJBjh0aEdZZM+wwog4IU7nDgyQYEzD1jajTaDEg0cGNsuMBfpmhjNItpCI4MESXkbXDA9ZojSQiJRkhmihiZEjZGj6iOEhG6vJmCcAmpLvARp+ikGIxpGWi2iZNCnrNazDcHsFCMGxGiMMlDMwPbIOwghnTJBEq8w3kPXNg6IaNJDUY0h7RGALe1iYcajduHafWNDiQaREhafAlDstmYkyRzH7qiYbSDB6pjwOtuM/eIMKNtlJT7rvI6OGiFAR2HtMNrg0aGZo1l4AoI0e2YYkNErUdVjHDR99EaGN1ZRhIfgMlBTbduVjRTD7JzaKaG1CzC+0aEaNCGmRCWOVhYffdg0wSGVC4rTTh+u9qMDMu5lu8C7DR/qIcTeURM0LhXi0fRcNPEoSXmjKRgaZ9lo7CO/NMaNgw+kfLaNESjR3NP0CLtOTQmaG0tyAGH10cHzDBbLiqR+oYdrsdqmHAwUsKH11j8whSNxsdVjsPWNhDi7HQhGLLAPrPzCDEgxClX6jTg8rhKSJHNAEX1iO8o4lFJTMqXFct/VO1wcGNXFSB9V3nptNXMtgTMfYT03YU0TMuEX6pT/AElZhhz+pgLG/sPN+ap7b6r9oj6rH7r5gKg//6MAAwHzApYd1ke6b3D3Nofce6rMPMw9r3SR6hvfZNHou9p/MbHsv8RHeXwv3Ti073Y6Hvmxp3sy/fOS8Hm/bflm9fbMARp0cAwp2g/YIUdq7Dm+06Ghyew9koww0XmcT2FaAo0Ox7LPqvB2mhGna7w+o4dCIbDa9j7QaEIkdrg3O9+oOFCmg2GhQYaY7V/rs3O53FP3wYgeo+XPsMDc/wBBT7ApodptXyN+sxgR4tH9xsXDQ0GjxfsK4NmXjeHR3GCOh65zflEWLAj9N0XsPUYRoX6CxYw2uhydhsKSL6zo4YUbGjYXtNFrWB9Z2kV5puYVlAI/RdjvXYYNGjaOYCufYMEdrDgm1ZmBCMA+mwpow6GgUw2L1uECZhZA+itIuGGjtDYMvrCXeDC/SOTveTCW67LvLl+hcCnYqw2nElmMpczOtwCPqsIoQix4tKxWFtZb6xZdhT9NgUDDBFDQhcI6Zetxclwp+kvRwEIUxJqwmXrd20L9IwYIR4BGrEHLEMtX1gRy59t3ujV3dx1dZdy3Myp6obiMMNFGy44znV1zkuXcuMY2f1FLQaEcPEALuwu5nN3d0sQ+U8QpgBvXQoMO0M51l9bu6X55YtEeDwSMuyEzlhdgQItP9JRvNFDAUaDHBd3cIxoJmn1XBDQjuMGGBGZi6urmLRo/RcPA35YYZdwLlhGZbPnmCiLgoOZGiNNWWU5UP6nQwaBsHBToBoxmXVscsL9VisIbQ2LAIu5YlkcXT9EMXTCg5EdCgIxojAjH1XY0b3R4ky0GGFMD6QU4IYOQFNNkXZdxw/PCBAXa+QjFhZFwEfoMCBhdhyYYKCnLMxoPorDCf0OjAAuEV+iaFG87Gmg0c5aD7DR6S7WAGx+ieuUrD4TabH2j5zgOJ67uejuXBH3lph3OJRsO1+B949w5nqPJ+YeU5n5zmfuPMGOB+48wFSnc9nmAsg/cew+YBzno9H8j/wB3+95H6GGjsf1v7nBg7qF4P9z2jwf7XcwpH/IT/J5H5H3HucjzAIaeYBC3i+YQ+XzALIfsdE4Pwn+Zxf7DY7HD/e7V2PdPmw5HdPvyz8Th+c++fOcFP7CB9k0NrD0zaUes+Vj6RQYPiOih+xp9wNh849k+eQpge4va8AjAjD87DB7xGnsd7osPbflryftH/u+y+qfbPK7iG13P03o/teLRoR+AKOhA/U7k0D4jg0aP6CisrCGj9h+YwIAENh+ljHQ+Jw0whCg/M6NMzFX33yBggQ2HvnQgQmcHuPqOCZgQjwfwBDeQDB+B4hHRj7p/QEaKNCL7z6RHYH52mGFj+pziwv8AYRjR9c9VwC/pIFLAp/tOjD/BwwNj+kNwfqaMNH1z+oFWB3Vh+0DzDWCx/cUd1aeYO/ljHYvwA9hH4mmO8+A2JTgWiAB8DvYaAENCP3hw4YEYbXMKfuGFKKYYKKVoi/ddBhgjLhhzmGh7yR0EGA7lWA/cOCaOWFBM5ykQfvuCOGgNFgpH3hpwN0BG7uwipcRfvDDDhYQwxlsv3DcmjWc5YEHOWXGiPuOhREjFdirQZlj7abkjSpZCXFdpb7TgoYtJFhd3COcwl5bMntCU6KMJlSzRQiy4nsmw0MZbiy4i5y3fV1bw/XYbGOww65gBFp6jEbfZNxSQUjRYBd4vKUZ91w4biRq+t9bL6zVxecH2CkdBFDNxhQF3MyxuNv2DAbmhtbiRXGc3Fjeh9goHY03nUq0wtE1KE+yUG9NUQ8ADOsHVuhyQT2DBTuW2slEbaCuqntPAwOLxmDV3fW2MMjb94wjDLcdZd2ZNh9Ypww2NMEWWiqWGbYifCaIAU04PuOjjJkUmbgdQdbbYfaDBsGhxeRl3d2QwR9pwUOjhMxrIYafdN7scJDOgGj9tYR2LsY4SBnBkh9g3DsdCGmTBgYnuBtOBvLtERwe0FJRgiUiZ8M5g2kND6zocDaRRFSGD3ynoaWH4RMJtdiIFPN+yP7WncG4ca3fvOAhh7R+A2FEOh+E4kd5sPtlGwjTvBhg0ftvEwaODAfpdh/YckwUxoBNhCPtu1dHyu9+ecg2OApNzTycGj9opphsaKKHY7TYes7jYm8/E7GgNCOiPA+47Ajg2MH5x7DgjSRdDiEfedgYadhsYxp+y7ncaDRSYGjDuP6yni6O9p2mwpo9gpwBTgp2Efum9wwGgHDQ6G8+ocza7TYwCNFP4DYfgU4ARjEo3jAYYMHsMPTfIeybHtMOj95o2vA4Pvg00drwd5T67Ggp5uhsSPvGDQ4tDR2OD8bsdj7b8tw739h+8itPwO9hTRHA/4n23/wCGP73u7nu+F9JpaVVV9VcPmBs49J/GeYBA08iflP8A2H/sntNHR/Gf9X5iH535b+M8qf2vMj8J8p0H3yh0fzOg/OfrHModBo9I+q81KNp+E8jxMGBKfvtDocih/tNhHc0J9tw0Q0HmZINHvpg9IKfiOZo+0OwwjtE4oLT7p2m4SPvuwjuNyRND8RQm8YUfeNjhKHAnwvJNo4afcPInBPcTBsWJAYjCLhhWfdeDRub0Eo+EowR0KD4CBscXgf1v7miPdXndUMY4PhOw5HdUFHE9w9NpVf7hw4aYfiNp/wAn4H/B4vYfgNhhopwfnN67l+I2BofmTYf4P/I/G/tcJT+x7px9JwaEMH6Dusj9btaNp+lwvdYEP+ZsO6wfMEjS/wDY/U71/esPidzTR/mffdjougAAbV910dHYvYw/S4XYf3nDPdYv6AAA4MPhNgYYuh+ZXY7X4k4saP0DTsDR+6bynsP0GHge+/KKNjo+68nabQp0feKDccmIG1+u+kxHZZsf0FG12OH2j5wRowf2GhDQA2HxPFyp7byORTwaPymjS0f82BD4na6MDaUfCdzMB3ShsdxRTsNjsPyujoOH8xTsdh7z80/sOTwcDD4jR3ndYLho/OtP/wAvwG4o4J/e+YBEDzAIc/kKeaYae5sN76xvNxsfur81/Ksdrh5q/AaG45P3l8gcX2TYcDgfmf2PF0H038LHifhWPa4fuEI8n8zgp0De/jf8j1zu6D/o+ow/+lj/AJnmAQx8wbNp5gGwP8Xuvj/oYf2v+L5gECeT3UztfMAsT5gJrP8AE8wE4v6zzAWe91e+YGtf/6E=]]></cadenaHuella> <detalles> <NFIQ>2</NFIQ> <profundidad>8</profundidad> <alto>392</alto> <ancho>357</ancho> <PPP>500</PPP> </detalles> </cadenaHuellaHom> </CadenasHuellasHom> </huellaWSQ> <huellaWSQ> <idHuella>2</idHuella> <CadenasHuellasHom> <cadenaHuellaHom> <tacto>1</tacto> <cadenaHuella><![CDATA[/6D/qAB6TklTVF9DT00gOQpQSVhfV0lEVEggMzU3ClBJWF9IRUlHSFQgMzkyClBJWF9ERVBUSCA4ClBQSSA1MDAKTE9TU1kgMQpDT0xPUlNQQUNFIEdSQVkKQ09NUFJFU1NJT04gV1NRCldTUV9CSVRSQVRFIDEuMDAwMDAw/6QAOgkHAAky0yXNAArg8xmaAQpB7/GaAQuOJ2TNAAvheaMzAAku/1YAAQr5M9MzAQvyhyGaAAomd9oz/6UBhQIALAOa5wO54gOa5wO54gOa5wO54gOa5wO54gOtUgPP+wO7iQPhCwO2uQPbRQO7EwPgfQOvlAPSsgOuagPRTAOb/QO7MAO7rQPhNQOs9QPPjQOWYwO0dwOXlgO15wOiUQPCyAOiAAPCZgOWbAO0ggOg2APBAwO+8APlIAPekgIatQO5vQPe4wPG2QPungPYmgIZ/gP7ZgIeKwPMZgP1RwPorgIb7AO6VAPfmQPMkQP1ewO57APfGwO7vgPhSwPFMQPsoQPYowIZ/wPENAPrcgPlogIbjgOhLQPBaQOaagO5TAO+7QPlHQPBJQPnxgOxHAPUiAO5pAPexQPPPAP4rgPDcwPqiQPCzAPpwQPH4QPv2gPKKwPymgO/hwPl1QPFjgPtEQO9lAPjfgO+FQPkGQO2uQPbRAPOSwP3jgPCkQPpewIgWAIm0AO9LwPjBQIkKgIrZgOplQPLgAOzlAPXfgPyrgIdHwIbfAIg+wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP+iABEA/wGIAWUCSZYEOX0CKUH/pgCOAAABAgIEBQsICg4VLQAAAACzAbWytgKxt7gDB6+wuQQFBggJCgyuurvYCw2srby9vsAOpqeoqaqrv8HCDxARgYyhpczT1NXW19kTSlVYWWlydHh5ipqjpMPEx8rQ0tsSFBUYGiJIUVRWV2tsbXFzdXZ6fH6Ah4mLjY+QkpSZm5ydn6CixcbJy87P0dr/owADAOnTp06dOnTp06dOnTp06fR9H0fR9PT6enTp83y/R/7+b5v/AD8//wB06dPn/J5f8/8AD8H5fm+np0+f4/vfB8Hwfz/0fH8/Tp04/a+7937f8P8AB2fo6dPny/e+1937n7v8X+v6OnT5s/3/ALf8n8v3Pf8Av/N06fJy/j9/3/g/m9/+38/T6fz/AB/0/wBX9f8Ad8Hv/wB/ydOnyfL5/v8A+nw/2fe/y+Xp9HyfL/12Ffi/xX/fT5/zfJ8v/Phyt6Pj/L+rCdBOcL50cN0rmpCtRHd8Lil/P307vLaZoeunL4aF5bTfwogLCefqlFxukeGaHnHJZ04ymsvWuNL0sZR70RBOx+ML2RJhbOU+zRvUTFXc1CcOrrqEOkso3QrBfU3LUWDBxIo5O2DTUotKARMAfrF4MDD12RPp5OhVuFORR2HMoe6TCzUFc41NXtmyjdHYLp0ilnhWml6yq/tj1vY9bZPU4QGBvgHQBm4adqOktD2HKIBCKzevLGM2rOFGA841lspC1G6OK2NRoNRhDCLWuaicnNpRQZJJrtkogoxOYMtTp2Ws0CKNqJ1nqq6ZtVkJrW2siy0ahqRMynXEqTCIWZYLazwwE1KZEFtk5DwCEyDEKQmhSQuJjekUihCZWj1vM1wKJilp1xqFFIedHGttAiGmz6pgIAMCOBa/K7MHvNIQ1XRHCTBuZ7UdcNwpb433NApT1WvO2SjsSDaJ3MoxjRSNrdGgUqZnc0Cc0ZKyRrauxQ1DE1XcIaagFKuWMSWxECmHEmyWglPkzNzG6xNJNGMrI8RNCa0iYrL1hQTeEUzzzN00MDW+thZ4QbhlbxW0zynY9jDCaN/sN9QD6idRwZLToJ8O2dY2bjITTTm0512uUME01nba1EQ6QCd9orS2IJVU9g7OuswMQsobaBEmMZzrltDHsfJ1KkN0FWDWRQUzEJkXRsvRy6ZKxLna2nQgiIhvYVepsUstubabBjUbXFUxCG7V2il4VmGyN5qgJE97mjcVQ0fWj6jUeRtvrE28BvhCCktRvcPB0EzaOgpGA5b2TIRQE8K43UJ4BQc4ttiZR9Ukxrep4u9UOEUcp12RF6DBlHdGy9dM5TNQbeOhVSDJtzUY8s6TWzgzcuDZaLCIlMQniZ2o0ObViIxOZQacJwmUep52TbcXeGVJ1jNcwxGD2xKdqEv7B+mz9eR6hHWIToN9TwFAgYbmmKyepm6s0KNDwMZjB6jB7nSSgpVhvFsmMG9Qba8ux0BEYGJPq0xFDUmyfbVSiSkK0YvPz/8AHj484yCsTCMZvx9nMXjdTFYq8X6fP4e3wyvpHa5Wc7T4vXybjM/Jz5qDbPn5aZlI/F6vRDRg9Wb9fdQzy82SmDB6jTvdnZW9HH2vhN4Gs+XZZE/tFfIB7hDdBCe+UanMD32lOggb3ZlJwkitd2StaU6MRGxxnZQnqKTjCniWKNRKnGOde1zAhk0jW8hDeBMJzjp2tVltN0sr7I5kCvDTavGT1vi6VtaXKjjeNh3Q6VvVyPIubKzgITCVG2NQoVolm2W0NRcarbaUGorUlRO8aHloUk4OL05GD+q+Ao90wH1DU7I4BQoQjhZCE0J74mhFGyHG6pNXCFCCu07+2g3g6G05+qVDTdGpnE5dj5Gxy0bI7vw+00iwhqHtfo7+Xn8ZFI62Zsa0z+LTx5XEKZ83Or1uvPSH3d11Ommfq3W9NVFWuL41/Fzi5sNJYOqzt+Du/Hz3tWvWJ7eXZ8Pj+NPbIZLu8Ct3n3zuBT38u7O8Hn9LjdKy4zexabNPA1iu87QLMo/3H5IvCgaOBSJFaHwabwYrcIlMggUBvhwnZqGOtjbGEqVZ4PE0BsWZWZUvcJ6oc1TkxY1GDFGD3mEWETSTEQ03nRzaz2xhDraBuaPWIwFMscaONroUecihkmLYYOydphmLgTwdJDePApNJv7kMpKt1tqYQ2+sEKIP2Xi+qRMdHwz43gZDOqWoTJlybrcrQ2ClR6t0ZVcRQgnx9cbIynTusS7TcrkbM8pWSmKSUuYy8sh2VgRlGyIUWcMhlNOe4RSybZn2xvbs03S2Zvh2rxiEPueMvVN5HfsHi28GFLTWMQTwkgGjFmso/0npR+4O3ND8kimXCnraIUp/XMDgMR7xbLw8fZyqm+st2+Pt4zV9UCjn5tO9aKr3kitf/AG8vbcqjaJ3T8bexWunXbKYi1/WopnXF1aamvf49ugK210kmvs/34yixsaeDT8PZWycp9Tcc/YPA3jo7/kE5mTF4Nh5wiHvGm2u5WluYeIhocVTkZtgTikyKCI2uzaaZI5tO8BpqG6HB4A612GLQoafvNS0W+udTKHuxlblA8qPe9O+/plW9Fbb2s/V8XJTHb55tuhd2mV83VepcoNjZkn6m68/w+XsyxKHH0W488/CTScWiyz5qNOVbTEYtVCOeXJdirXEij00tPep5xdGxy4H6q8/C8JvY4G4O2X3XhVjGcIR23bamDc6N3kRDextNoWYNoxdAFCrQ8jws3R6zAQNRDTRvCg4Yp6xO9/eaeeSbf1hHWCDyRmFHAdXLuvRopD3XjshCcuy4mJ2Luly7Uggxzm5m6MVp05GzPur6c6NNBnE7C3pt66FGoiuJbjpbjQBsvXY5icu4QNRbLvxHYmZbRZ14zrMC1ZoXivt9WLKNwCzvxPE2PU4mzWlaucXrcodM3sE8GihZRtZgTnrODJEUOtkzJQ62MGfZbGih7jTwl8G3qdGM2vKUN0ajg1VpvCYNp3cXYTAbcWxi6GoQxDWbx5tOQArMby/ZlcY6Aw2wvNZobZHLOdpdZex4ZT3+XuznZKc1r3jPCfKiMZQIjlHPtfKuWhsdTCLHq9Lb/HE7WnhCrOkqrxlNoRVRp6w3RQJEU5PyO+dG1PuXh0aOt1lMtH2WwfAgs6MDfaZerKHvfGuiG7PL0ZbQ9a8/bSSufp0vjJ26d3daG7zXjD2g9JrGb8PDvq8TScuwUO/i/N2bRxbzZNTy9ta+2dhho/N2w/Dx8vf2Q9pWUE+vtVXsYijjkclWRW2OgIyt4ZXs+1PY6Car2JkaMxjU1JSIeLl0KD1PaaxFAe5vWJ/UaH7riqEeRkRKGfYf6h7j1NPqZVPVavAkoIb4Orq6PVOb25xxcJkiBG2r8KNXUitWu28xFxRRxfjuhQ5gGp7e7LdLV8rlGReJHsGFuLiXx8fRpGIxNWibdvr8vfNXjDoJw4yXZWR8Gy2lneGcAkrUbe2EUGUsFXubwanA4FGAmKOp0ENjT8joYPyCLKYtXD//pgCKAQACAQICAggJCBcdFQcFAACztQECsgO2BLcFBgcICQsMsQoNDg8QabC4uRESExRqrq+6FRYXGRocHyAhIyQnKCkqKywtLz5HrK0YHR4iJSYuMDEyNTc4Oj1BQkRFS0xPUFVYWaq7vBs0Njk7PD9ARklNTlJTV12nqau9vzNDSEpRVFxeZKi+wP+jAAMB7Ww63rdp1O1i8SG4d4EcFMN4jsazwzghTh5JoxDa6zLwTdz7zY0nDw53lwsY7n0a/wAb1cMTg+j6de76lhLWO17v9vP9P/H/AFjVmeHn+n6e76te+zn3Zzw19H1d38uZPQCZd/P6v+POMNfT4d7w593co82fw+nmdAEDXv8ARHjnvcGue1uOs+A8Zg7Fp2kd9x2OA4FG83sYPW72MeLWSJmO8SXockrJTgjvzObLw1mJt155Cc0vDwSPdk74MDcaw1gnOFO9oMHeR6Lp08MN9BhMg9jLXtaTsNDrvYgciG54IkNGjgbs8sm1p6PSJDszOZoUnDN93OLgSO/n/wA+jnrmGnhvaIUN89c83a3O/wBOWMbIb8y7O/XPfr6M5N/1UE7jw/jfovhqRnd6e/Pcej6uAY/kY9Ov+/1HEO6rvu5A8+cc5zq8nJAzZ2tr5DyMeLvXyDyWmGjwdGml3kI7Eo3GpM+I1g0Ixo36szAiPAy+Ho1wwyzJu1ua5oGPBzgwzu8OhdG0vMdwYJnndqdNy8ly3xsHoYOgR7c8DY9KvkDQ7DcR5LHDTuUNzg2ho4OTEI6N3vJb4Qpiu8Yc7Cx5Z153eYyzos1Jlsy4eGbNNQDjbgUhxDQo6wwZ8r22z+R+6eLOjonB2PYbXabyGDQh0JztaReXhHUu8HFmt3DxotZseRnaI8kMLeWjoNGH1ntl31joACnqNp41Ivqkd44aDDvdpou+/RDBZTw9HPvhGEbg7/RMy4CUu553eYggG8pjG+YkN5FvnnM5kDoFwwOg6DpNgw8Zntxn4jY6PqjxNCijrMB1HA4D3bXqfRq3ew6EcGrg4tOYkR6iwb72jpsIGusehpKUlnW0QPUHtZyHYeVjoR4kNrxYmFg0bkvWja8O/POmine2lETQ3+jPd3S3RhvUzz1WEeed6ZzztDM5+FO/XnPOVbO7z5vaU1zj3+Hp7jnuGlpv0Hh6XO4o07p6J/H0u9jTqPMz38GEdXmxXpdWDLOp2PS0wj2xz8Qp48wN70XbuTfmXnodzMnE2jRmOgO47jMW0hEd3O0piZY27bxaJl5xhtvAkM881k2uhRmZi8iFMetFgnYeQcPYYI9r2ODqdzyb2Ezx1HRjBhu7nneHR4F24GEZe4yEIxrXgOc5ji1h0LDZ3ZjtvMs9Fszbre9lqmpff3ehXam7Po/j6YO52hnunp795oRTMvu5FBHMToGEuAdjEXPWxo6zJB6iNMO19I0+MOkXYPQZQpgQ4ZLNjFmdxqMcMFvfzhHRb6Dzvdox5u859wlODNu1y5vnbWb1HeEuapk1IO0IUxUKTa7GE1vmjtHDSll8DapFvqDF8XYxo8Z4mjyFHa+h43Y9LRsekYeV2p0OeCm5gRdhZvUcOEju7vqQp0y7+6NlGEhv1vPOGCBvKQUp1i7Q2FjfSQQnnzDg5oozjJxaCL1lMMPIweVcvbhv2HqfUDeR5HlHI0aPHPo0OzMS8JDJwaC2nQ35IUZxm+kjEq3rShyPUUx7Aho9bhh5XtgGPY+QNAhxIyzDRwYO4d5zswYIhu9BQUQgb3JnR2O4mdzF35ndz7yEzqlm8yZjDR3kIOy4cSs9wznzOtuPd3vJwWa92eRQJGPA0MZicmB8JCl7dk9VeL0HBhwPWLdo8mXB2HWjoQ4EHOFHodGAOep2c9Tw8QxTXqHN4vk0qOHrGNPbFHUeQrw15+B4r19Ph6eY8Rhnu/jrnvXiRj6J/wBfT/LWZN5DMM/8eHhmHQYPT/Cf893gCbzBrP8Anw1q297izw/29HfdDvXZ9X0+FonEiPo78jTvMMvObelpQJkgm6ymnKXRwNt6Z4mAA6zCKJxHQxnsaG/tscrnP7zqRj03z9Dmw6nXwvI93/7rxBPRrfnc/wDOvAynn88deef+tb3NPp//AL092dfR9V5eFzXu8Du/ln/fz2u64n1fw9N9/wDD6b73O5x3f7M8P4fVHuvoT0fSa/8A53Zp4EM692v+/PI7iLM58L7vPA4kavuonem5NDwQzyJlI4OKFZdDeYGjD0uwp7LIdTT5GOYdrZe04hCBGHYk1uPYMNY8iITvu74rca5scHIr+PeUHXd3QQ3mwvacCFPeph4hDN0AHBoJ33F6UaGEF3m02HlXynW6XhexwnU7F8YBZ/8AauR67sLg9WcwjnnRxAUjzOgFzCZcxd4tZgeAWdAXHmXSm8jpYvQ6IwXpCc+6ZjE3GjDWGHoKG4EHgbCGA3EGEI+u9BTQeVcPSU+qnbJAQuHUuLHjeWDDnbe81bPDRuXnc3M6zWuc58y96ZZcslzw1vegg5Z/LnZuLz3CTXmeHnc7in0c6Twzzycs6xz6eeb3FJMtz+Nsb2hgisHNm83Ao9d+oGcPBojhp7H1Gnscp4hBO2AIUPXkNtvKzO28nDNxvGbYW7+ee42EVOBV5Kcc/A3Gdl4ecd7nJ33svNruKZm4TPPv7k6AvuQc28HTLGjWJubSgb15+gh1Brcz5zpacMeRtDk6I6HI0tweIfKPqkB7Wp6xdDlmMYq8gwseRrMuwc7xhcYBRwS0jL0eBrLMDZZ0GjlTL0CsSk3Edi4JfQQyhCZ7Gkt5EY6HI2vjfE+yeJ9Y7YHmw8SbA688yjReQUMbviGbppOfd0L3c4RhLvPHMMMY53jLhoJHe4tuFXmXvazduHWzPJJeZm3NvFSZlx4uwKZnJ5Q6Sj7g+o/We1uY+Mot8QUMOKQhrrFj1Bm08diQ4tEY+F09DQREKODgid2sV6WN5jh3uxfTGMeRjXacTeeVgeJOo2EKPdPZWPjIQ/edTR1EzkhHpI5ZkPFcbmekc94ubOLTcDiRZzOasI8GEUM5pNoOCOro8Qzex8TSnSR0etoDxZOl0GD5F8psOp9Zp7Zm7PI33Zj1C3qYeszzI0cgnPv7nDwNFwsOpCXRnqaAPHlPKRw8mNd3lZnY+JT5H2HsY+ofKxXte2MHxXkncdKPhnnMw67t5gnBVmubzg4FJZ5++FPAAQzrHxa50elIZXxZDxtX5Q6jgPU04PEdb/q9r6ZfIvOlhxyNrM3noSGbEFOLG8sEp3Ck5sLtjwQaSkXei88HNQOJCOcicmNzJA5J6xo9iQo6XDodJ6xses7a8Nh1Xz5pi3k84lEcnQak1q6zzmvEzzix5vhq9BrrmZEzr39BBFyNZzvMIVmEHeYM3owehgjAzTyHW4Rg9mWMHravpaGAFL1sKfIYex8pHY+M7YJh2WNaw6tVjk4mmVgW8QvWjm9hV+lo4DBjOcbORfOemMy8m8zvoToYEz32x68zOTB1PlTaf2HwvbXvqDjPjaJnmdBRz5pHPnvik7hJbniRvF16PPz6i1zPPzelnnzV874uG+6PPui8sjBu6OCUQjsTpUvByKSs+ueRg+sfA0+R8wL6nmAUtOBT295oewfiY+yn4WhH65/SeU2JTH7yMT+Z/AJjIibDiw0H74gmSijpTeIw+4wSraE8TsNgj8TbBuMRN7o4dwwMnwJkmSNtrE9cojkj9ooayUJ9ZgjsftkyDeabUX13AnwsEEpTCU7WjekIUIj9oQdl6DwORCCIkPeEvKECZ8g7BNBoY/ZEGWBFo8ZtSXkgie6wUsrKaCU8SiOFjdJgfbDLYINjDI9ZmjDRTBM0e5rBzTmW3kaHc7mGg1m281kh7ZM0RghQnYRMMZeQwUPtrczTzS2a2lNHWUUMuMvI37g5rNs5t6kyeN0abc85kftlzIojBhsetGkEojB9ohEtzba3qlvI2ETMMy8l5gJ7bFuJbZWtEdibTYI0wjcRj7YWLcS6zgww6TJDNZCIInuKtZg0EEGjkkYkItzWXQ+4wFJlZluNxHqMIhlIpEfcLzLtSgsyW29bRkW5kFuOD2hpbFiuS1EpjCG0ShtlxQoofaSswDF25JkdzomGGQ1lzMDMIe40RjAHMvMMweSRvMFBUjD3AihCOWWay8sIcDAhkjktiD9l3Zl3Y5JqtHBERLzLjmWqCe2UYYRywWro3OHDLcljmWRh9shMsuLLL3mwwMKzAtowfYcGACKWZcuTrzc1hc1mZdZ+ycHRWireTa25S4uYWMPfNwNBG3iRCZZdg5QYfcYRmZcU3oLLvLmBYMPcfIEVNqRbHLLZlVhR7SdjTgBMCGaAZkMAop8jowg1nYxuatAksIy1t/qHDFsirBSOBhT7RvNjTGiO7MC6BilDYw9x2ux3tBsuOXIGSA0MB/raYhS5ckXOEopf+xxQoDAEYRj9t6HY4NlxysytEXRjH3T64BuaDBD/ALtO4I/MfWaYDtYBo+8fYP0nidAKcH43Y0bnRgBFYn6XYwCD+J3BsN4U/oegPvvqOD1X8hTDi6H5nRp6Wj8zsf8AB0P2nsHbImhT+46T+4w9R+w0PMAgb23b+xjDQ6//owADAfMC755gFLPMA455gH4fWOl+A+Ze2SIf6P8A9PbKnQ7Q/wDK/wDt9p6SOH3j13avS/IH+TCOjH3H5j334iNHkfK/cfjdr9lwaO99k+Vw7XofE/M07CPwntNBRsz/AIsNx7Bh+RWmEcr777zCBGABxP8AuwIr/ioTKF3Fo9g+ZhoFB7D0HwBS6MODwNr8xGBDAR2v1z3SgmYBTR1FODeuj8TlzorA6GHYfAUABADC7Xrdr8JMtFDlhd9JseKp7q0zLqGYDSBFdx2HwhTBhM4VfKw0WG09pYBeMubFD2Q98jQCrQFsA3u8IfKEXCwLcZiocnDD5iKrCAxWMHyZ4nuFFKrhcsAHDDYxwu098WGFyrlWWUFlOxWOHNBR8NmFVy5ZczC4QI0FBCJdLAj7oCYVy5csszA2GGMWEIpGI0e4KmFcuXKhmBFXrAjCij2xohFcuXKwYAuV0zCKwIr8JDBHMVcuYYLisMEWiNMNh9pIFKqsWEaBXDAgLAwxX3yBFVdmSLkAayRDBo0AYPeYRVjQDAFoAaYq7COX4kIqxgAUBFXARixwsAPiKVXNMAcGAwxwU4I/KRViRWiMTDhwAWGxKPgIqrBw4KWg0ACGx+800UEcB0BFVYU/dY4AIRXiEXGcHyPlNhuYQpjT8ro+Uw0AEKdz8SuA0ORQEIQ+6+wYYEP0HQ6Bsf1P2T7S+QNH/IAjD9b22b5hQFfMBDD/AKj+x7a9h+47dJ/O+YC0XzCCC+YBYj6z2yz21hvf8H/Vw/5uwPsH33BH3TYe6UwP1rggB67yU+BCBcfed79pw/rIwItP2HpfdWmmBR5Xc07H4Gmggf8AkI04NH7DD31hTyPZfiCBsX2yPwEdC9r9d+ZgQhR7JuPeTY4UPZYUHykaAj7QaHxlK+6RfuBCnQo7GmLCLD3imG5fYNGj5HYlNEX1EI0fA7Q2qsfGaBH5TcRweobl+NhowMPkWimFnwmhgjFfG7Qww+QdwQ6TaEaDQ+Q0NjQ9JHCq/I8GJoR4sDQNj953r0qhGAH5ADg6Kpeiv5F4MDAK0fpVgRgbH52G0wxQ/E9JHaABhp3v6HQ0DR/OYCld7AD8xHQ/Y9axf1FOwAo7ZZp0Np+Y8qu1+d7A3n7T/wAP7WHWfQ/sfWfMVwi+YCV2BT+whCFGw/SAGhQfQ7AA2AYY/nIgBHQGCP5h3Xdl2bG6fxuGFEylmCyKRMH4naCUpd3d2DCZHQ/ANGDYy7AC7iUP9DwKGGwAjdsYI/iTamCOYFiS5nCQWD8r0I1mGxptzAjLTR+N2m5pqylVLiXbm00fjSjQw0TLA3lrLNCFPxmhvzcdCZznXKkZdtBk0X7bxFpyszLuJFlmrcTN1bH5hoaM1ejsHMBppq6fgaR0MGQiQvOtIFxhreHRuGYn3xKNbppwEFDJBwOH3zR2JTBjrqTXXIGhG8jbQ0R+a9qWrSwsovmtWiMRj8jhEcW5LurLEc3FtWOie88hjDKGZZM4Lc2wzTTGj+gaSMIwsNidL/OJG6ua5vnd3ec2Jwdz8RvQSJfPnd8+dsEKOL+BpJmg0My3BEoifeHcRKMuuc5yRGEMMEjh/AUa4VaDKJk6Eh+AyGM5jnKEzaJmFFESH2TqSNoyxVWWZuIicj3DyPNjnLnOuuSN3qNsMJQ/9hbwMVznOWGQYYIi4YfgRjbTnK2OCrdqaH4RopVhkIYcG5/GkIqmj/e05uMUvJTHBTufiOti51bsbluCOBhBw/0DSrCJTGnR/sSAqphKfoY3HKoZE0dqfOMaLu72J1v9gF/ndjvdBhQ4HcYfyZpMGg5/8O1NCjgf1Owo6koo/tAHyn+Rufzvlf1v+DtaNjokPyv7zxvbVn6nidD22L2751v1z9Th/wDT6h/W0cnD21D21j23RxO2oPMBBLGLGli7sxXKx3OHzBBIeufvaKf6h/8AbR2uCNH4Wg9QSIiP3SGHxm0gw+4mwgbTrOgafiacFND64j8qYcEHyOwcPxlECmk/mfmWgg6Jo+U3nxAnqmjhMFCU/aKFw4EfVIUj8JGl2CPlYlGcZ+VjAw4TqeDdI/AbA2pT5BowU/CQCNJGmnRNE2pWSFNHxLR0mw0IkEgUjD7r7CQjofG5poYj5DNGSZJmmB77TRQ0PY0JAgOh77Fooo9REUibn33BCmh6xwiFC/hHYcmhjofGaO5IeswUj9w2ET18wiEfhYGxInqsGEzLifdCIhBOvJASKFGH2jsYw0DgiYzhD+cjDNIxOKRFIsI/jOo/tYFXGHQ0NZpgRh8xwV5GlqU/sUGG0/Sp87DRj1EMP5TpRBYFLR87vafwHE3kdiCC4Xa/O6EaYEacO8/ndg7SgNGK4Yf3m90f7jiaD2zz4z86fuPGf3PbYHmArV9h8waeqr/8eg/QBse2vX9x/kRcNH7j9xRof+n9pgwsIR/W8j6GPBw/ndhtYGA2H9LSvJ2OjD8ocDD/AHuCkh/i6PF/K+sflOowlDh/tXBTS4H6GBHikek/COjTldr9BHQADDufzP7x5Do7T+swwpWgcD9DsDafqcGDD+1aHR+h6FDen0ENj+ppYu1/SOADYf4sMPF/O6LRh0P0q/5uAA3n5jQ4sNh/c7wf9F7a4PEfoO1tNHti3yHkfMK0R5gJWe3GfyHrO9/zND53sML855Bp7a1phCg/ef0uHrMEO2vO2Pel0egp8wCEPmAQcweYCFD/AEfMAsp5gnU//6E=]]></cadenaHuella> <detalles> <NFIQ>1</NFIQ> <profundidad>8</profundidad> <alto>392</alto> <ancho>357</ancho> <PPP>500</PPP> </detalles> </cadenaHuellaHom> </CadenasHuellasHom> </huellaWSQ> </HuellasWSQ> </HuellasRequestDTO> </Fingerprints>","mensaje":"Se generaron Las Huellas Correctamente","nombreHuellas":["","","dfdad24f-7edc-40a5-91e5-194d3f88b4d8"]});
			}
		};
		
		$scope.respuestaHuellaIpad = function(response){
			$rootScope.loggerIpad("respuestaHuellaIpad", null, response);
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			
			if(response.codigo == ENROLAMIENTO_HUELLA.EXITO){
				/*\Se agrega un evento para la bitacora\*/
				//(Datos del Cliente)
				$rootScope.addEvent( BITACORA.SECCION.datosCliente.id, BITACORA.SUBSECCION.capturaHuellas.id, BITACORA.ACCION.finCapturaBiometricos.id, 1, BITACORA.SECCION.datosCliente.guardarEnBD );  
				/*\Se agrega un evento para la bitacora\*/

				var porcentajeFoto = cuentatext('datosBasicos',1).toString();
				
				if(response.nombreHuellas.length == 0 && response.identificador.length > 0) {
					response.nombreHuellas = ["", "", response.identificador];
				}
				
				$scope.archivoHuella = response.nombreHuellas;
				$scope.enviarArchivoHuella = true;
				
				$scope.huellaAnterior = $rootScope.solicitudJson.cotizacion.clientes[0].huella;
				$rootScope.solicitudJson.cotizacion.clientes[0].huella = HUELLA_ENCOLA;
				$scope.objetoEnviar = "huella";
				$scope.manoEnviar = 1;
				$scope.dedoEnviar = 2;
				//$scope.cadenaEnviar = $scope.manoEnviar + "-" + $scope.dedoEnviar + "-" + response.nombreHuellas;
				$scope.cadenaEnviar = $scope.manoEnviar + "-" + $scope.dedoEnviar + "-XXXXXXXXXXXXXXXXXX,2-1-YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY";
				
				if(response.huellas != undefined && response.huellas != ""){
					$scope.huellasCliente = response.huellas;
					$scope.enviarArchivohuella = true;
					$rootScope.solicitudJson.cotizacion.clientes[0].huella = "1";
				}
			}else{

				if(response.codigo == ENROLAMIENTO_HUELLA.HUELLA_EMPLEADO){
					/*\Se agrega un evento para la bitacora\*/
					//(Datos del Cliente)
					$rootScope.addEvent( BITACORA.SECCION.datosCliente.id, BITACORA.SUBSECCION.capturaHuellas.id, BITACORA.ACCION.finCapturaBiometricos.id, 0, BITACORA.SECCION.datosCliente.guardarEnBD );  
					/*\Se agrega un evento para la bitacora\*/
					
					solicitudService.cancelarSolicitud({idSolicitud:$rootScope.solicitudJson.idSolicitud});
					modalService.alertModal("ERROR",["Las huellas proporcionadas son de un empleado"],"Aceptar",$scope.titulo.colorModal, $scope.titulo.colorSeccion).closePromise.then(
							function(exito){
								//Flujo para reiniciar
								$scope.reiniciaCotizacion();																			
							},function(error){
								
								//Solo por alguna falla
								$scope.reiniciaCotizacion();
							}
					 );
				}else{
					/*\Se agrega un evento para la bitacora\*/
					//(Datos del Cliente)
					$rootScope.addEvent( BITACORA.SECCION.datosCliente.id, BITACORA.SUBSECCION.capturaHuellas.id, BITACORA.ACCION.finCapturaBiometricos.id, -1, BITACORA.SECCION.datosCliente.guardarEnBD );  
					/*\Se agrega un evento para la bitacora\*/
					$scope.enviarArchivoHuella = false;
					
					$rootScope.message('Componente Huella', [angular.toJson(response)]);
			}
				}
			
			
		};
		
		$scope.reiniciaCotizacion = function()
		{
			generalService.cleanRootScope($rootScope);
			generalService.buildSolicitudJson($rootScope, null);
			
			generalService.locationPath("/simulador");
			
		};/* END REINICIA COTIZACION FUNCTION */
					
		$scope.respuestaEnvioHuellasIpad = function(response){
			$rootScope.waitLoaderStatus = LOADER_HIDE;				
		};
		
		$scope.respuestaFotoIpad = function(response){
			$rootScope.loggerIpad("respuestaFotoIpad", null, response);
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			try{
				if(response.codigo == RESPONSE_CODIGO_EXITO_IPAD){
					/*\Se agrega un evento para la bitacora\*/
					//(Datos del Cliente)
					$rootScope.addEvent( BITACORA.SECCION.datosCliente.id, BITACORA.SUBSECCION.capturaFoto.id, BITACORA.ACCION.finDigitalizacion.id, 1, BITACORA.SECCION.datosCliente.guardarEnBD );					
					/*\Se agrega un evento para la bitacora\*/
					var porcentajeFoto = cuentatext('datosBasicos',1).toString();
				
					$scope.archivoFoto = response.archivo; 
					$scope.enviarArchivoFoto = true;
				
					$rootScope.fotoanterior1 = $rootScope.fotoCte;
					$rootScope.fotoCte = 'data:image/png;base64,' + response.cadenaJPG;
					$rootScope.fotoCteOriginal=response.cadenaJPG;
					$scope.cadenaEnviar = response.cadenaJPG;
					$scope.objetoEnviar = "foto";
					$scope.manoEnviar = null;
					$scope.dedoEnviar = null;
					$rootScope.fotoAnterior = $rootScope.solicitudJson.cotizacion.clientes[0].foto;
					$rootScope.solicitudJson.cotizacion.clientes[0].foto = FOTO_ENCOLA;
																																	
					
				}else{
					/*\Se agrega un evento para la bitacora\*/
					//(Datos del Cliente)
					$rootScope.addEvent( BITACORA.SECCION.datosCliente.id, BITACORA.SUBSECCION.capturaFoto.id, BITACORA.ACCION.finDigitalizacion.id, -1, BITACORA.SECCION.datosCliente.guardarEnBD );					
					/*\Se agrega un evento para la bitacora\*/
					$scope.enviarArchivoFoto = false;
				}
				
				

			}catch(e){
				$rootScope.message($scope.titulo.texto,[e], "Aceptar", null);
				$scope.enviarArchivoFoto = false;
			}
			
			$rootScope.$apply();
		};
		

					
		$scope.archivarFoto = function()
		{				
			$rootScope.enviarImagen(
					$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
					$scope.archivoFoto,
					servicioEnvioImgDocIpad,
					constantesIpad.descFotoCte,
					'commoCtrlDivId',
					{	
							ruta: null,
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							cadena: $rootScope.fotoCte.split(",")[1],
							tipoCadena: "foto",
							nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
							foto: $rootScope.fotoCteOriginal
					},	
					functionCallbackEnvioFotoIpad
			);
			
		};
		
		$scope.archivarHuella = function()
		{
											
			$rootScope.enviarImagen(
					$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
					$scope.archivoHuella[2],
					servicioEnvioImgDocIpad,
					constantesIpad.descHuellaCte,
					'commoCtrlDivId',
					{	
						ruta: null,
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						cadena: $scope.archivoHuella[2],
						tipoCadena: "huella",
						nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
						foto: $rootScope.fotoCteOriginal
					},
					functionCallbackEnvioHuellaIpad
			);
			
		};
		
		$scope.regresarFoto = function(){
			$rootScope.fotoAnterior = $rootScope.solicitudJson.cotizacion.clientes[0].foto;
			$rootScope.fotoanterior1 = $rootScope.fotoCte;
		};
		
		$scope.error = function( porcentajeant ){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			$rootScope.solicitudJson.cotizacion.clientes[0].huella = $scope.huellaAnterior;
			$rootScope.solicitudJson.cotizacion.clientes[0].foto = $rootScope.fotoAnterior;
			$rootScope.fotoCte = $rootScope.fotoanterior1;
			$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = porcentajeant;
		};
		
		$scope.SetFOTO = function(){
			
			$rootScope.waitLoaderStatus = LOADER_SHOW; 						
			var porcentajeFoto = cuentatext('datosBasicos',1).toString();
			var biometrico = {
					ruta: null,
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					cadena: $scope.cadenaEnviar,
					tipoCadena: $scope.objetoEnviar,
					porcentaje: porcentajeFoto
			};
			
			//var $scope.porcentajeant = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje;
			
			clienteUnicoService.setBiometrico( biometrico ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);							
						if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							$rootScope.waitLoaderStatus = LOADER_HIDE;

							$scope.huellaAnterior = $rootScope.solicitudJson.cotizacion.clientes[0].huella;

							$scope.regresarFoto();
							$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje + parseInt(porcentajeFoto);
							if ($rootScope.solicitudJson.cotizacion.clientes[0].porcentaje > 100)
								$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = 100;
							generalService.setRespaldo($rootScope.solicitudJson);
							generalService.flujoEfectivo = $rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo;
							
						}else if(j.codigo == RESPONSE_CODIGO_ERROR_ID){
							$scope.error( porcentajeant );
							$rootScope.message($scope.titulo.texto,[j.descripcion], "Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion,null,null,null);
						}else{
							$scope.error( porcentajeant );
							$rootScope.message($scope.titulo.texto,["Error al enviar la foto."], "Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion,null,null,null);
						}
					}else{
						$scope.error( porcentajeant );
						$rootScope.message($scope.titulo.texto,["Error en la respuesta del servicio para guardar la foto del cliente. Por favor, reintente nuevamente."], "Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion);
					}
				}, function(error){
					$scope.error( porcentajeant );						
				}
			);
						
		};
		
		/**
		 * Se valida en un funcion que usa una directiva en el modal que es 'ngChange'
		 * Si se introduce ingresos comprobables, se eliminan los ingresos no comprobables
		 * Si se introduce ingresos no comprobables, se eliminan los ingresos no comprobables
		 * Se valida que si el obheto de 'flujoEfectivo' tiene menos de 2 posiciones, no se hace ninguna acción
		 * Si tienen el objeto 'flujoEfectivo' mas de 2 posiciones entonce y si el index es 0, se le suma 1 y la variable monto se resetea
		 * Si tienen el objeto 'flujoEfectivo' mas de 2 posiciones entonce y si el index es 1, se le resta 1 y la variable monto se resetea
		 * Al final solo uno de los montos debe estar lleno y el otro vacio
		 **/
		$scope.validaIngresosUnicos =  function(index){
			if($rootScope.flujoEfectivo.length == 2){
				if(index == $rootScope.flujoEfectivo.length-1){
					$rootScope.flujoEfectivo[index-1].monto = "";
				}else{
					$rootScope.flujoEfectivo[index+1].monto = "";		
				}
				if(index==0){
					$scope.IngComp = true;
				}else{
					$scope.IngComp = false;
				}
			}
		}
		
		//* Función que muestra el modal informativo del comprobante de ingresos *//
		$scope.muestraInfo =  function (){
			$scope.headerIngresos= "¿Qué documentos pueden ser comprobantes de ingresos?";
			var texto = "";
								
			modalService.muestraInfoModalDB($scope.headerIngresos, "bgNaranja", texto).then( 
							function(estatus) {
								console.log = "Modal informativo";																											
							}, function(error) {
								$rootScope.waitLoaderStatus = LOADER_HIDE;									
							}
						);								
		};
		
		
		
		/** Se ejecuta el servicio para validar el estatus del folio de callcenter del Coacreditado **/
		function validaEstatusCallCenter(solicitudJsonString, responseJson,consultarBuro){
			if($scope.enviarArchivoHuella && !envioHuellasEnLinea){
				numObjEncolados++
				$scope.archivarHuella();
			}
																
			generalService.setArrayValue("numObjEncolados", numObjEncolados);																								
																											
			solicitudService.validaFolioCallCenter(JSON.parse(solicitudJsonString), responseJson.data).then(
				function(data){
					if(data == null){
						if ($scope.enviaOchoPasos)																														
							buroService.consultaBuro( $scope.titulo.colorModal, "btn gris","btn naranja", null, null,consultarBuro, null );
					}else
						generalService.locationPath(data);
				},function(error){
					
				}
			);
		}
		
		
		/** INICIA Envío de biométricos **/
		var envioHuellasEnLinea = false;
		$scope.continuarBiometricos = function (form){
			var tipoCadena="", cadena="";
			var esEnviarBiometricos = false;
			
			if($scope.enviarArchivoFoto){
				tipoCadena = "foto";
				cadena = $rootScope.fotoCte;
				esEnviarBiometricos = true;
			}else if($scope.enviarArchivohuella){
				tipoCadena = "huella";
				cadena = $scope.huellasCliente;
				esEnviarBiometricos = true;
				envioHuellasEnLinea = true;
			}
			
			(esEnviarBiometricos)?$scope.guardarBiometricosOnline(tipoCadena, cadena.replace("data:image/png;base64,","").trim(), form):iniciarGuardado(form);

		};
		
		/** Elige los contratos que se enviarán en linea **/
		$scope.guardarBiometricosOnline = function(tipoCadena, cadena, form) {
			var request = {
				idSolicitud: $rootScope.solicitudJson.idSolicitud,
				cadena: cadena,
				tipoCadena: tipoCadena,
				porcentaje: "100",
				rechazoFirma: "0"
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			clienteUnicoService.setBiometrico(request).then(
				function(data) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							
							if($scope.enviarArchivoFoto){
								$scope.enviarArchivoFoto = false;
								$rootScope.solicitudJson.cotizacion.clientes[0].foto = FOTO_ENVIADA;
								$scope.continuarBiometricos(form);
							}else if($scope.enviarArchivohuella){
								$scope.enviarArchivohuella = false;
								$rootScope.solicitudJson.cotizacion.clientes[0].huella = HUELLA_ENVIADA;
								if($rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion != undefined && $rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion != ""){
									var parser = new DOMParser();
									var xmlDoc = parser.parseFromString(cadena,"text/xml");
									
									var x = {
										nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre,
										apellidoPaterno: $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno,
										apellidoMaterno: $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
										claveElector: $rootScope.solicitudJson.cotizacion.clientes[0].claveElector,
										numeroEmision: $rootScope.solicitudJson.cotizacion.clientes[0].numeroEmision,
										cic: "",
										ocr: $rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion,
										folioDigitalizacion: $rootScope.solicitudJson.evidencia,
										huellaIzquierda: xmlDoc.getElementsByTagName("Fingerprints")[0].getElementsByTagName("HuellasRequestDTO")[0].getElementsByTagName("HuellasWSQ")[0].getElementsByTagName("huellaWSQ")[1].getElementsByTagName("CadenasHuellasHom")[0].getElementsByTagName("cadenaHuellaHom")[0].getElementsByTagName("cadenaHuella")[0].textContent,
										huellaDerecha: xmlDoc.getElementsByTagName("Fingerprints")[0].getElementsByTagName("HuellasRequestDTO")[0].getElementsByTagName("HuellasWSQ")[0].getElementsByTagName("huellaWSQ")[0].getElementsByTagName("CadenasHuellasHom")[0].getElementsByTagName("cadenaHuellaHom")[0].getElementsByTagName("cadenaHuella")[0].textContent,
										ine2_0: "1"
									}

									$rootScope.waitLoaderStatus = LOADER_SHOW;
									clienteUnicoService.validaHuellaINE(x).then(
										function(data) {
											console.log(data.data.respuesta);
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											iniciarGuardado(form);
										}, function(error) {
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$rootScope.message("Error", ["Error en el Servicio de Cliente Único"], "Aceptar");
										}
									);
								}else{
									iniciarGuardado(form);
								}
							}else{
								iniciarGuardado(form);
							}
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}
					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'guardaFirmasBiometricosOS'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};
		
		/** TERMINA ENVÍO de BIOMÉTRICOS **/
		
		
		/** INICIA GUARDAR SECCIÓN **/
		
		$scope.contunuar = function(form){
			if($rootScope.solicitudJson.marca == 5011 || (($scope.enviarArchivoHuella || ($rootScope.solicitudJson.cotizacion.clientes[0].huella == HUELLA_ENVIADA  || $rootScope.solicitudJson.cotizacion.clientes[0].huella == HUELLA_ENCOLADO_IPAD)) && ($scope.enviarArchivoFoto || ($rootScope.solicitudJson.cotizacion.clientes[0].foto == FOTO_ENVIADA || $rootScope.solicitudJson.cotizacion.clientes[0].foto == FOTO_ENCOLADO_IPAD))) || !configuracion.origen.tienda){
				if(($rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil == 2 || $rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil == 4) && 
						$rootScope.solicitudJson.cotizacion.clientes[0].datosConyuge != null && $rootScope.solicitudJson.cotizacion.clientes[0].datosConyuge != undefined && $rootScope.solicitudJson.cotizacion.clientes[0].datosConyuge.celular != "" && contadorCel == 0){
					
						var num = "";
						try{
							num = { numTelefono: $rootScope.solicitudJson.cotizacion.clientes[0].datosConyuge.celular.split("(").join("").split(")").join("").split(" ").join(""), }
						}catch(e){}
						if(num != undefined && num != ""){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							solicitudService.validarNumTel(num).then(
								function(data) {
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									if(data.data.codigo == RESPONSE_CODIGO_EXITO){
										var jResponse = JSON.parse(data.data.respuesta);
										
										if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO)							
											$scope.verificaDireccion(form);	
										else{
											$rootScope.solicitudJson.cotizacion.clientes[0].datosConyuge.celular = "",
											$rootScope.message("AVISO ", ["Captura nuevamente el número de teléfono del cliente."],"Aceptar",null,"bgNaranja", "naranja");
										}
									}else{
										contadorCel++;
										$rootScope.message("AVISO ", ["Verifíca que el número telefónico este capturado correctamente."],"Aceptar",null,"bgNaranja", "naranja");
									}							
								}, function(error){
										$rootScope.waitLoaderStatus = LOADER_HIDE; 
										$rootScope.message("AVISO", [ ERROR_SERVICE, "Error "+jResponse.codigo],"Aceptar",null,"bgRojo", "rojoR");	
									}
								);
						}else{
							$scope.verificaDireccion(form);
						}
					
				}else{
					$scope.verificaDireccion(form);
				}
			} else {
				if ($rootScope.solicitudJson && $rootScope.solicitudJson.cotizacion 
					&& Array.isArray($rootScope.solicitudJson.cotizacion.clientes) 
					&& $rootScope.solicitudJson.cotizacion.clientes[0]) {
					let cte = $rootScope.solicitudJson.cotizacion.clientes[0]; 
					
					if (+cte.foto == 0) { // No tiene foto
						try {
							// Con jQuery se le remueve la clase deshabilitadora, si la tuviera.
							$('#open-fotografia').removeClass('pasoDeshabilitado');
						} catch(mr) {
							console.log('Pues, se hizo lo que se pudo, ~manito.');
						}
					}
					
					if (+cte.huella == 0) { // No tiene huella
						try {
							// Con jQuery se le remueve la clase deshabilitadora, si la tuviera.
							$('#open-huella').removeClass('pasoDeshabilitado');
						} catch(danger) {
							console.log('Pues, se hizo lo que se pudo, ~manito.');
						}
					}
				}
				
				$rootScope.message("AVISO ", ["Para continuar con el proceso de solicitud de crédito es necesario capturar Foto y Huella"],"Aceptar",null,"bgNaranja", "naranja");
			}
		
		}
		
		$scope.verificaDireccion = function(form){
			var domResp = JSON.parse(generalService.getRespaldoDom());
			if(!$rootScope.isMexico && !$scope.showSeccionMapa && !$scope.mapasBancoShow){
					modalService.alertModal("Aviso",["Estás zonificando fuera de territorio Mexicano, favor de validar nuevamente"],"Aceptar",$scope.titulo.colorModal, $scope.titulo.colorSeccion).closePromise.then(
							function(exito){
								//Regresamos al punto anterior
								$scope.getCurrentAddress(null, null, 1);																										
							},function(error){
								//Actualizamos posicion
								$rootScope.serviceModuleLocation(domResp.cp, domResp.colonia);
							}
					 );
				
			}else if(($rootScope.cpActual != domResp.cp && !$rootScope.activaErrores) && !$scope.showSeccionMapa){
			
				modalService.modalAceptaZonificacion("Prueba Descripción", "bgRosa",  1, null, "Prueba").then( 
						function(estatus) {
							if(estatus == 1){
								$rootScope.activaErrores = true;
							}else{
								if(domResp.cp != $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp){
									$rootScope.cpActual = domResp.cp;
									$rootScope.solicitudJson.cotizacion.clientes[0].domicilios = [domResp];    			
									$rootScope.serviceModuleLocation(domResp.cp, domResp.colonia);
								}else{
									$scope.getCurrentAddress(null, null, 1);
								}
							}
						}, function(error) {
						}
					);
			}else{
				$scope.continuarBiometricos(form);
			}
	};
		
		function iniciarGuardado(form){
		
			if(!$scope.showSeccionMapa){
				/*\Se agrega un evento para la bitacora\*/
				//(Datos del Cliente)
				$rootScope.addEvent( BITACORA.SECCION.datosCliente.id, BITACORA.SUBSECCION.zonificar.id, BITACORA.ACCION.continuar.id, porcentajeUnificada($rootScope.solicitudJson), BITACORA.SECCION.datosCliente.guardarEnBD );
				/*\Se agrega un evento para la bitacora\*/
			}else{
				/*\Se agrega un evento para la bitacora\*/
				//(Datos del Cliente)
				$rootScope.addEvent( BITACORA.SECCION.datosCliente.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.continuar.id, porcentajeUnificada($rootScope.solicitudJson), BITACORA.SECCION.datosCliente.guardarEnBD );
				/*\Se agrega un evento para la bitacora\*/
			}
			
			//Se mandan a BD los eventos almacenados en memoria
			$rootScope.enviaEventos();
			
			/** Obtener el json con la información actualizada **/
			$scope.actualizacionDatos = DatosAnterioresArreglo('informacionGeneral','edicion');
			
			if($scope.ocrIFE && $rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion != '' && $rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion.length != $scope.folioIdent.longMax){
				$rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion = $rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion.substring(0, 13);
			}

			
			$rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo  = new Array();
			var campoCargado = 0;
			angular.forEach( $rootScope.flujoEfectivo, function(ig){				
				try{	
					$scope.datosFE[ig.idConcepto].opcional = true;
					var monto = parseInt(generalService.cleanValue( ig.monto ));
					if( monto > 0)
						campoCargado = ig.idConcepto;
					else{
						ig.monto = "";
						if(campoCargado == 0)
							campoCargado = ig.idConcepto;
					}
				}catch(e){ }									
			});
			
			$scope.datosFE[campoCargado].opcional = false;
			
			
			/** modificacion para producto de rescate prestamo personal  **/
			if($rootScope.solicitudJson.marca == 117 && generalService.consultaHistoricoMarcas([5013])==5013){
				$rootScope.solicitudJson.consultaBuro = 0;
			}
			
			$timeout(function(){ 
				
			switch (reglasGuardado()){
			case "esMigracion":
				$scope.muestraMensaje(form);
				break;
			case "esSurfing":
				obtenerCamposValidados();
				$scope.muestraMensaje(form);
				break;
				default:
					cargarConfiguracion(form);
				break;
			}
			
			}, 1);
					
		}
		
		function reglasGuardado(){
			
			var validarDatosRespaldo=JSON.stringify($scope.datosRespaldoSurfing);
			var validaNuevosDatos=JSON.stringify($scope.actualizacionDatos);
			var esSurfing = $rootScope.solicitudJson.consultaBuro == 1 && ( validarDatosRespaldo != validaNuevosDatos && $rootScope.solicitudJson.consultasRealizadasEvaluacion != 1) ;
			var esMigrada = $rootScope.solicitudJson.solicitudMigrada == SOLICITUD_MIGRADA && ( $rootScope.solicitudJson.cotizacion.clientes[0].bloqueado == 0 || $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado == 0 ); 
			
			if(esMigrada)
				return "esMigracion"
			else if( esSurfing ){
				return "esSurfing";	
			}else
				return "continuar";
		}

		
		/** Si la solicitud cuanta con un cambio de sucursal entonces mestrar el mensaje conrrespondiete e invocamos la funsión para el guardar la sección.. **/
		$scope.muestraMensaje = function(form){
			var esMigradda = false;
			$scope.mensaje = ["Esta solicitud está siendo monitoreada centralmente,"," Hemos detectado que se ha realizado una edición de datos en el (los) campo (s): ",$scope.mostrar,"Por favor verifica que los datos sean correctos, ya que una vez guardada la información no podrás volver a editarla."];
			
			if($rootScope.solicitudJson.solicitudMigrada == SOLICITUD_MIGRADA){
				$scope.mensaje = ["¿Estás seguro que deseas guardar la sección?","Una vez guardada no podrás volver a editar la información del cliente"];
				esMigradda = true;
			}
				
			modalService.confirmModal("Advertencia", $scope.mensaje , "Revisar información","Guardar",$scope.titulo.colorModal,$scope.titulo.colorSeccion,$scope.titulo.colorSeccion,null,null)
			.then(
				  function(confirm){
					  if($scope.surfingDB || esMigradda)
						  $rootScope.solicitudJson.cotizacion.clientes[0].bloqueado = 1;
					  
					  if($scope.surfingDH || esMigradda)
						  $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado = 1;
					  
						$timeout(function(){ 
							cargarConfiguracion(form); 
						}, 1);
				},function(cancel){
					console.log("Revisar");
				}
			);
		};
		
		var obtenerCamposValidados= function(){
			var camposEditados=[];
			var validarDatosRespaldoTemp = $scope.datosRespaldoSurfing;
			var validaNuevosDatosTemp = $scope.actualizacionDatos;
			var campos=[
			{nombreCampo:"edoCivilCliente",descripcion:" Estado civil", DB:true},
			{nombreCampo:"tipoTrabajo",descripcion:" Tipo de empleo", DB:true},
			{nombreCampo:"ocupacion",descripcion:" Ocupación", DB:true},
			{nombreCampo:"INGCOMPROBABLES",descripcion:"Ingresos comprobables", DB:true},
			{nombreCampo:"INGNOCOMPROBABLES",descripcion:"Ingresos no comprobables", DB:true},
			{nombreCampo: "calle",descripcion: "Calle", DH:true}, 
			{nombreCampo: "manzana",descripcion: "Manzana", DH:true}, 
			{nombreCampo: "supermanzana",descripcion: "Supermanzana", DH:true},
			{nombreCampo: "lote",descripcion: "Lote", DH:true}, 
			{nombreCampo: "andador",descripcion: "Andador", DH:true}, 
			{nombreCampo: "edificio",descripcion: "Edificio", DH:true}, 
			{nombreCampo: "numext",descripcion: "Número Exterior", DH:true}, 
			{nombreCampo: "numint",descripcion: "Número interior", DH:true}, 
			{nombreCampo: "cp",descripcion: "Código postal", DH:true}, 
			{nombreCampo: "colonia",descripcion: "Colonia", DH:true},
			{nombreCampo: "coloniaTexto",descripcion: "Colonia manual", DH:true},
			{nombreCampo: "del",descripcion: "Delegación", DH:true}, 
			{nombreCampo: "edo",descripcion: "Estado", DH:true},  
			{nombreCampo: "antiguedad",descripcion: "Antigüedad", DH:true}, 
			{nombreCampo: "vivienda",descripcion: "Tipo vivienda", DH:true}, 
			{nombreCampo: "tel",descripcion: "Teléfono", DH:true},
			{nombreCampo: "referencia",descripcion: "Referencia",DH:true}
			];
			
			//Valida todos los campos que hallan sido editados
			validaNuevosDatosTemp=validaCamposEditados(validaNuevosDatosTemp,validarDatosRespaldoTemp);
			
			//Genera json para mostrar el mensaje
			for(var x=0; x < validaNuevosDatosTemp.length; x++){
				for(var j=0; j<campos.length;j++){
					if( campos[j].nombreCampo == validaNuevosDatosTemp[x].nombreCampo ){
						if(campos[j].DB)
							$scope.surfingDB = true;
						if(campos[j].DH)
							$scope.surfingDH = true;
						camposEditados.push(campos[j].descripcion);
					}
				}
			}
			
			//Convertimos a String los campos obtenidos
			var cadena=JSON.stringify(camposEditados);
			$scope.mostrar=cadena.replace(/(\[)|(")|(\])/g,'');
			
		}
		
		function cargarConfiguracion(form){
			
			var validate = $scope.validar();
			
			if(!form.$valid)
				return;			
			
			if($rootScope.coloniaOpcional != "")
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=$rootScope.coloniaOpcional;
			
			else if( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc == "NO SE ENCUENTRA COLONIA" )
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = "";
			
			$scope.saveZone();
			$scope.saveStreetView();
			porcentajeantH = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje;
			validateService.limpiaMascaras();
			
			if ($scope.vigenciaInvalida && $scope.ocrIFE){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message($scope.titulo.texto,["La identificación no está vigente. Favor de solicitar e ingresar una nueva identificación para continuar con el proceso."], "Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion,null,null,null);
			}else{
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				
				consultarBuro = -1;
				buroTmp = $rootScope.solicitudJson.consultaBuro;
				matrizTmp = $rootScope.solicitudJson.consultaMatriz;
				$scope.montoCorrecto = true;
				
				angular.forEach( $rootScope.flujoEfectivo, function(ig){				
					try{	
						var monto = parseInt(generalService.cleanValue( ig.monto ));
						if( monto > ingresoMinimo){
							ig.monto = monto;
							ig.conceptoDes = descCatalog[ ig.idConcepto ];
							$rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo.push(ig);
						}else{
							if(parseInt(monto))
								$scope.montoCorrecto = false;
						}
							
					}catch(e){ }		
					
				});
				
				if($scope.montoCorrecto){
					porcentajeant = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje;
					$scope.datosActualesBuro = JSON.stringify(DatosAnterioresArreglo('informacionGeneral','buro'));									
					$scope.datosActualesMatriz = JSON.stringify(DatosAnterioresArreglo('informacionGeneral','cincom'));
					$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje  = cuentatext('datosHogar');
					
					if($rootScope.solicitudJson.marca == 5011){
						$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = parseInt(cuentatext('datosBasicos'));
					}else if(configuracion.origen.tienda){
						$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = parseInt(((cuentatext('datosBasicos') + cuentatext('datosBiometricos'))/2).toFixed());
					}else{
						$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = parseInt((cuentatext('datosBasicos')).toFixed());
					}
					
					
					if (offLine){				
						$rootScope.cargaDocumentos();
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.porcentajes.secciones[0].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje; 
						generalService.locationPath("/ochoPasos");
					}else{
						if ($scope.datosAnterioresBuro != $scope.datosActualesBuro || $rootScope.solicitudJson.consultasRealizadasEvaluacion == 1){
							$rootScope.solicitudJson.consultaBuro = 0;
							$rootScope.solicitudJson.consultaMatriz = 0;
							consultarBuro = 1;
						}else if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idAntiguedad == 1 && $rootScope.consultaFuncionalidad.habilitarReglaAntiguedadDomicilio){
							$rootScope.solicitudJson.consultaBuro = 0;
							$rootScope.solicitudJson.consultaMatriz = 0;
							consultarBuro = 1;
						}else{
							if( $rootScope.solicitudJson.consultaBuro == 1 ){
								if ( $scope.datosAnterioresMatriz != $scope.datosActualesMatriz ){
									$rootScope.solicitudJson.consultaMatriz = 0;
									consultarBuro = 0;
								}											
							}else
								consultarBuro = 1;
						}
						
						/** Inicia PEPS **/
						for (var i = 0; i < $rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS.length; i++){
							if ($rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].status == 0)
								$rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i]=arrayPEPS[i];
							if ($rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].guardado){
								continue;
							}else{
								$rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].guardado = "0";
							}
						}
						/** Termina PEPS **/
						
						if($rootScope.solicitudJson.marca == 5011){
							$scope.enviarArchivoHuella = false;
							//generalService.setRespaldo($rootScope.solicitudJson);
							
							if($rootScope.solicitudJson.cotizacion.clientes[0].porcentaje == 83 ||
									$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje == 67)
								$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = 100;
						}
						
						$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].domicilioActual=1;
						
						if(!validate && $scope.showSeccionMapa){
							$scope.obtenerCoordenadas();
						}else{
							guardarSolicitud();
						}
					}
					
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message($scope.titulo.texto,["Ingreso Comprobable/No comprobable debe ser mayor a $1000"], "Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion,null,"DATOS BASICOS","INGRESO COMP MIN");
				}
			}
		}
		
		var guardarSolicitud = function(){
			var celCliente = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
			celCliente = celCliente.split("(").join("").split(")").join("").split(" ").join("");
			$rootScope.solicitudJson.cotizacion.clientes[0].celular = celCliente;
			var secciones = "1,2";
			if($scope.enviarArchivoFoto){
				$rootScope.solicitudJson.cotizacion.clientes[0].foto = FOTO_ENVIADA;
			}
			
			// Se realiza una verificación del estado civil.
			maritalStatusCheck();
			
			if(!$rootScope.ejecutarEncuentaPreaprobado){
				$rootScope.solicitudJson.banderaOfertaCP=1;
			}
			
			var solicitudJsonString = generalService.delete$$hashKey($rootScope.solicitudJson);
			
			solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: "1,2" },PROCESOS.PSC ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						if( data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO ){
							$rootScope.ocrColonia=null;
							var responseJson = JSON.parse(data.data.respuesta);	
							if( generalService.isDefined(responseJson.data.cotizacion.clientes[0].porcentaje) && generalService.isDefined(responseJson.data.cotizacion.clientes[0].domicilios[0].porcentaje) ){
								/*\Se agrega un evento para la bitacora\*/
								//(datos del Cliente)
								$rootScope.addEvent( BITACORA.SECCION.datosCliente.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.guardar.id, porcentajeUnificada(responseJson.data), BITACORA.SECCION.datosCliente.guardarEnBD );
								/*\Se agrega un evento para la bitacora\*/
							}
							
							switch(responseJson.codigo){
								case RESPONSE_ORIGINACION_CODIGO_EXITO:							
									$rootScope.solicitudJson = responseJson.data;
									generalService.setRespaldo($rootScope.solicitudJson);
									generalService.flujoEfectivo = $rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo;
									$rootScope.porcentajes.secciones[0].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje;
									$rootScope.porcentajes.secciones[1].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje;
									$rootScope.calculaDocumentos();
									
									if(generalService.cambaceoPrecalificado($rootScope.solicitudJson.marca)){
										$scope.solicitudJsonString = solicitudJsonString;
										$scope.responseJsonData = responseJson.data;
										//consultaBuro = consultarBuro;
										$scope.guardarInfoCambaceo();
									}else{
										if(formaEnvioBiometricos){
											validaEstatusCallCenter(solicitudJsonString, responseJson,consultarBuro);
										}else{
										
											if($scope.enviarArchivoFoto){
												numObjEncolados++
												$scope.archivarFoto();
											}
												
											
											if($scope.enviarArchivoHuella){
												numObjEncolados++
												$scope.archivarHuella();
											}
																								
											generalService.setArrayValue("numObjEncolados", numObjEncolados);																								
	
											validaFolioCallCenter(solicitudJsonString,responseJson.data);
										}
									}
									
									break;
								case PRESTA_PRENDA_SUCURSAL_GESTORA:
									limpiarJson(responseJson);
									break;
								case LCR_CLIENTE_CUENTA_CON_LCR:
									generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
									generalService.locationPath("/ficha");
									break;
								case STATUS_SOLICITUD.malZonificada.guardarSeccion:
									var excepciones = [ SECCION_HOGAR.toString() ];
									
									$rootScope.porcentajes.secciones[1].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje;
									$rootScope.solicitudJson = responseJson.data;
									$rootScope.calculaDocumentos();
									
									generalService.setDataBridge( {esMalZonificada:true} );
									generalService.bloqueoSecciones( $rootScope.solicitudJson, excepciones );
									validaFolioCallCenter(solicitudJsonString,responseJson.data);
									break;
								case BURO_NO_EXISTE_SUCURSAL_CERCANA:
									limpiarJson(responseJson);
									break;
								case ERROR_SOL_RECHAZADA:
									var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
									var marca = $rootScope.solicitudJson.marca;
									var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],"Aceptar", "/simulador",  $scope.titulo.colorModal , $scope.titulo.colorSeccion,buildJsonDefault);
									break;
								default:
									$scope.mensajeErrror = "Se presentó un problema al guadar las sección unificada, favor de volver a intentar";
									reiniciar();
									break;	
							}
						}else{
							$scope.mensajeErrror = "Se presentó un problema en la comnicación al puente al guadar las sección unificada, favor de volver a intentar";
							reiniciar();
						}
					}, function(error){
						$scope.mensajeErrror = "Se presentó un error al guadar las sección unificada, favor de volver a intentar";
						reiniciar();
						});
		}
		
		var reiniciar = function(){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			$rootScope.solicitudJson.consultaBuro = buroTmp;
			$rootScope.solicitudJson.consultaMatriz = matrizTmp;
			$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje = porcentajeantH;
			$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = porcentajeant;
			$rootScope.message(" Aviso ",[$scope.mensajeErrror], "Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion);
			
			if( $rootScope.solicitudJson.consultaBuro == 1 && $scope.existeEdicion )
				$rootScope.solicitudJson.cotizacion.clientes[0].bloqueado=0;
			
		}
		
		var limpiarJson = function(responseJson){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			generalService.cleanRootScope($rootScope);
			generalService.buildSolicitudJson($rootScope, null);
			$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",$scope.titulo.colorModal, $scope.titulo.colorSeccion);
		}
		
		/** TERMINA GUARDAR SECCIÓN **/
		
		var validaFolioCallCenter = function(json,response){
			$scope.quickFixes=true;
			solicitudService.validaFolioCallCenter(json,response).then(
					function(data){
						if(data == null){
							if ($scope.enviaOchoPasos)																														
								buroService.consultaBuro( $scope.titulo.colorModal, "btn gris","btn naranja", null, null,consultarBuro, null );
						}else
							generalService.locationPath(data);
					},function(error){});
			}
		
		function maritalStatusCheck() {
			// Se tiene una solicitud con un objeto cotización.
			if ($rootScope.solicitudJson && $rootScope.solicitudJson.cotizacion) {
				// Se tiene un arreglo clientes y está definido el índice 0.
				if (Array.isArray($rootScope.solicitudJson.cotizacion.clientes) 
					&& $rootScope.solicitudJson.cotizacion.clientes[0]) {
					let cliente = $rootScope.solicitudJson.cotizacion.clientes[0];
					let id = +cliente.idEstadoCivil || 0;
					
					cliente.estadoCivil = ''; // Se desconfigura la descripción.
					cliente.idEstadoCivil = 0; // Se desconfigura el id.
					
					// Si el idEstadoCivil tiene algo mayor de 0.
					if (id > 0) {
						try {
							let maritalStatus = generalService.construirCatalogo("CATALOGO ESTADO CIVIL") || [];
							
							for (let s of maritalStatus) {
								if (s.id == id) {
									cliente.estadoCivil = s.descripcion || '';
									cliente.idEstadoCivil = cliente.estadoCivil ? s.id : 0;
									
									break;
								}
							}
						} catch(Q) { console.log('¿Por qué no se pudo construir el catálogo?'); }
					}
				}
			}
		}
		
		$scope.obtenerCoordenadas = function(){
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			let calle = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle;
			let numExt = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroExterior;
			let colonia = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia;
			let cp = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp;
			let delegacion = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].delegacion;
			let estado = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].estado;
			
			let domicilio = {"xpCadenaBuscar": calle +"," + numExt + "," + colonia + "," + cp + "," + delegacion + "," + estado}
			
			solicitudService.busquedaGPS(domicilio).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == 1){
						let responseJson = JSON.parse(data.data.respuesta);
						if(responseJson.xpDatos != null){
							let datosUbicacion = JSON.parse(responseJson.xpDatos);
							
							$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud = "" + datosUbicacion.xpInfo.xpUbicacion.xpCoordY;
					    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud = "" + datosUbicacion.xpInfo.xpUbicacion.xpCoordX;
					    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.heading = "" + 30;
					    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.pitch = "" + 0;
					    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.zoom = "" + 2;
					    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.fov = "" + 45;
					    	
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							
							consultarBuro = -1;
							buroTmp = $rootScope.solicitudJson.consultaBuro;
							matrizTmp = $rootScope.solicitudJson.consultaMatriz;
							$scope.montoCorrecto = true;
							
							angular.forEach( $rootScope.flujoEfectivo, function(ig){				
								try{	
									var monto = parseInt(generalService.cleanValue( ig.monto ));
									if( monto > ingresoMinimo){
										ig.monto = monto;
										ig.conceptoDes = descCatalog[ ig.idConcepto ];
										$rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo.push(ig);
									}else{
										if(parseInt(monto))
											$scope.montoCorrecto = false;
									}
										
								}catch(e){ }		
								
							});
							
							if($scope.montoCorrecto){
								porcentajeant = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje;
								$scope.datosActualesBuro = JSON.stringify(DatosAnterioresArreglo('informacionGeneral','buro'));									
								$scope.datosActualesMatriz = JSON.stringify(DatosAnterioresArreglo('informacionGeneral','cincom'));
								$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje  = cuentatext('datosHogar');
								
								if($rootScope.solicitudJson.marca == 5011){
									$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = parseInt(cuentatext('datosBasicos'));
								}else if(configuracion.origen.tienda){
									$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = parseInt(((cuentatext('datosBasicos') + cuentatext('datosBiometricos'))/2).toFixed());
								}else{
									$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = parseInt((cuentatext('datosBasicos')).toFixed());
								}
								
								
								if (offLine){				
									$rootScope.cargaDocumentos();
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									$rootScope.porcentajes.secciones[0].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje; 
									generalService.locationPath("/ochoPasos");
								}else{
									if ($scope.datosAnterioresBuro != $scope.datosActualesBuro || $rootScope.solicitudJson.consultasRealizadasEvaluacion == 1){
										$rootScope.solicitudJson.consultaBuro = 0;
										$rootScope.solicitudJson.consultaMatriz = 0;
										consultarBuro = 1;
									}else if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idAntiguedad == 1 && $rootScope.consultaFuncionalidad.habilitarReglaAntiguedadDomicilio){
										$rootScope.solicitudJson.consultaBuro = 0;
										$rootScope.solicitudJson.consultaMatriz = 0;
										consultarBuro = 1;
									}else{
										if( $rootScope.solicitudJson.consultaBuro == 1 ){
											if ( $scope.datosAnterioresMatriz != $scope.datosActualesMatriz ){
												$rootScope.solicitudJson.consultaMatriz = 0;
												consultarBuro = 0;
											}											
										}else
											consultarBuro = 1;
									}
									
									/** Inicia PEPS **/
									for (var i = 0; i < $rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS.length; i++){
										if ($rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].status == 0)
											$rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i]=arrayPEPS[i];
										if ($rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].guardado){
											continue;
										}else{
											$rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].guardado = "0";
										}
									}
									/** Termina PEPS **/
									
									if($rootScope.solicitudJson.marca == 5011){
										$scope.enviarArchivoHuella = false;
										//generalService.setRespaldo($rootScope.solicitudJson);
										
										if($rootScope.solicitudJson.cotizacion.clientes[0].porcentaje == 83 ||
												$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje == 67)
											$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = 100;
									}
									
									$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].domicilioActual=1;
									
										guardarSolicitud();
									
								}
								
							}else{
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message($scope.titulo.texto,["Ingreso Comprobable/No comprobable debe ser mayor a $1000"], "Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion,null,"DATOS BASICOS","INGRESO COMP MIN");
							}
						}else{
							$rootScope.message("Aviso", [ "La respuesta del servicio centralizado es nula" ], "Aceptar", null,  "bgRosa" , "rosa");
							return;
						}
					}else{
						$rootScope.message( "Nueva Originación Centralizada", ["Error al consumir el servicio centralizado."], "Aceptar");
					}							
				}, function(error){
					$rootScope.waitLoaderStatus = LOADER_HIDE;																		
				}
			);
		}
	});
	
});
