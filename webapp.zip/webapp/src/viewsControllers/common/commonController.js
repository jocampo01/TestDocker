'use strict';

define(["app"], function (app) {

	app.controller("commonController", function ($timeout, $rootScope, $scope, sessionService, modalService, generalService,  documentosService, securityService,
												 solicitudService, recomiendaService, tarjetaService, constantesTDC, clienteUnicoService, generalServiceOS, obligadoSolidarioService, buroService) {

		var _numObjEncolados = 0;
		var filtroDocsHuellaFoto = "";
		var tipoTasa = tipoTasas.prestamoPersonal.id;
		
		// Bandera para validar si se deben enviar o borrar las huellas capturadas.
		var realizarEnvioHuellas = undefined;
		
		$rootScope.isItEnoughAndNecessarilyOld = tieneEdadParaEndeudarse;
		
		$rootScope.callBack = null;
		$scope.numDocsRequeridos = 2;
		 $rootScope.contratosResponseCita = true;
		 $rootScope.documetosResponseCita = true;

		if (configuracion.origen.tienda)
			$rootScope.validarTienda = true;
		else
			$rootScope.validarTienda = false;

		if( configuracion.origen.portalWeb ){
			sessionService.getObjSession().then(
					function(data){
		                	if(data.data.codigo == RESPONSE_CODIGO_EXITO){
		                		$rootScope.inSession = true;
		                		$rootScope.userSession = data.data.respuesta.datosUsuario;
		                		$rootScope.sucursalSession = data.data.respuesta.datosSucursal;

		                		var key = generalService.keyEmpBase64();

		        			    $timeout(function(){
		        			    	securityService.setKeys(key, key);
		        			 	}, TIME_OUT_1SEG);

		                	}else
		                		localStorage.removeItem('paths');

					}, function(error){
						localStorage.removeItem('paths');
				    }
			);
		}




		$scope.loadDataSession = function(dataSession){

				generalService.setArrayValue('ticket',dataSession.idSession);
		        $rootScope.inSession = true;
		        $rootScope.userSession = dataSession.datosUsuario;
		        $rootScope.sucursalSession = dataSession.datosSucursal;

		        var key = generalService.keyEmpBase64();

			    $timeout(function(){
			    	securityService.setKeys(key, key);
			 	}, TIME_OUT_1SEG);


		};


		$rootScope.message = function(titulo, listaTexto, labelButton, path, cssTitulo, cssBoton, doFunction, seccion, parametroDialogoModel, spiner ){
			modalService.alertModal(titulo, listaTexto, labelButton, cssTitulo, cssBoton, seccion, parametroDialogoModel, spiner).closePromise.then(
													function(exito){
														if(path != null){
															if(configuracion.so.ios && path == "/menuWrapper"){
																$rootScope.executeAction("regresaMenu", "responseWrapper",{nombre:"mostrarMenu"});
															}else{
																if(path == "/simulador" || path == "/"){
																	generalService.cleanRootScope($rootScope);
																	generalService.buildSolicitudJson($rootScope, null);
																}
																
																generalService.locationPath(path);
															}
														}

														if( doFunction )
															doFunction();
													},function(error){
														console.log(error);
													}
											 );
		};

		$rootScope.messageConfirm = function(titulo, listaTexto, labelCancelButton, labelOkButton,
											cssTitulo, cssBtnCancel, cssBtnOk, path, doFunction,doFunctionError,seccion,parametroDialogoModel ){

			modalService.confirmModal(titulo, listaTexto, labelCancelButton, labelOkButton,
					cssTitulo, cssBtnCancel, cssBtnOk, seccion, parametroDialogoModel ).then(
													function(exito){
														if(path != null)
															generalService.locationPath(path);
														if( doFunction )
															doFunction();
													},function(error){
														if( doFunctionError )
															doFunctionError();
														console.log(error);
													}
											 );
		};


		$rootScope.cargaDocumentos = function(){

			$rootScope.validaCadena = function(textoValor){
				var valorCampoArr = textoValor.split(".");
				var cadenaValor = ""
				var restoCadena = false;
				$scope.siEntro = false;
				var cadenaFaltante = ""
					for (var p=0; p < valorCampoArr.length; p++){
						if (restoCadena){
							cadenaFaltante = cadenaFaltante + "." +  valorCampoArr[p];
						}else{
							cadenaValor = cadenaValor + "." + valorCampoArr[p];
							var arregloVariable = eval( "( $rootScope.solicitudJson" + cadenaValor + ")" );
						}
						if (typeof arregloVariable == 'object'){
							if (Array.isArray(arregloVariable) && !restoCadena){
								restoCadena = true;
								p++
								cadenaFaltante = valorCampoArr[p];
							}
						}
					}
				$rootScope.creaArregloValores(cadenaValor, cadenaFaltante);
				if ($rootScope.valoresAval == [])
					$rootScope.valoresAval =  "";
				return $scope.siEntro;
			}
			$rootScope.creaArregloValores = function(cadenaValor, restoCadena){
				var valorCampoArr = restoCadena.split(".");
				var cadenaValor1 = cadenaValor;
				var resto = false;
				var cadenaFaltante = "";
				var cadenaObjeto = eval( "( $rootScope.solicitudJson" + cadenaValor + ")" );
				for (var p=0; p < cadenaObjeto.length; p++){
					resto = false;
					var cadenaValor1 = cadenaValor;
					cadenaValor1 = cadenaValor1 + "[" + p + "]";
					for (var t = 0; t < valorCampoArr.length; t++){
						if (resto){
							cadenaFaltante = cadenaFaltante + "." + valorCampoArr[t]
						}else{
							cadenaValor1 = cadenaValor1 + "." + valorCampoArr[t];
							try {
								var arregloVariable = eval( "( $rootScope.solicitudJson" + cadenaValor1 + ")" );
								if (typeof arregloVariable == 'object' && !resto){
									if (Array.isArray(arregloVariable)){
										cadenaValor = cadenaValor1;
										resto = true;
										t++
										cadenaFaltante = valorCampoArr[t];
									}
								}
							}
							catch(err) {
								resto = false;
								$rootScope.valoresAval = "";
								$rootScope.valorReal = $rootScope.valoresAval;
								IdPersonaAval = $rootScope.solicitudJson.cotizacion.clientes[0].idPersona;
								consecutivoClienteAval = $rootScope.solicitudJson.cotizacion.clientes[0].consecutivoPersona;
								validacionValores(p);
							}
						}
					}
					if (resto)
						$rootScope.creaArregloValores(cadenaValor, cadenaFaltante);
					else{
						try {
							$rootScope.valoresAval =  eval( "( $rootScope.solicitudJson" + cadenaValor1 + cadenaFaltante + ")" );
							$rootScope.valorReal = $rootScope.valoresAval;
							IdPersonaAval = $rootScope.solicitudJson.cotizacion.clientes[0].idPersona;
							consecutivoClienteAval = $rootScope.solicitudJson.cotizacion.clientes[0].consecutivoPersona;
							validacionValores(p);
							$scope.siEntro = true;
						}
						catch(err) {
							$rootScope.valoresAval = "";
							$rootScope.valorReal = $rootScope.valoresAval;
							IdPersonaAval = $rootScope.solicitudJson.cotizacion.clientes[0].idPersona;
							consecutivoClienteAval = $rootScope.solicitudJson.cotizacion.clientes[0].consecutivoPersona;
							validacionValores(p);
							$scope.siEntro = true;
						}
						console.log($rootScope.valoresAval);
					}
				}
			}



			$scope.tipoAval2 = false;
			$scope.avales = false;
			var documentosArray ="";
			var r = 0;
			$scope.llenaArreglo = function(){
				$scope.numDocsRequeridos++
				switch(documentosArray[r]){
				case IDENTIFICACION_OFICIAL.id :
					documentos.push( {"idDocumento":IDENTIFICACION_OFICIAL.id, "documentoDes":IDENTIFICACION_OFICIAL.descripcion, "status":STATUS_PENDIENTE, "idTipoPersona": idTipoPersonaAval, "consecutivoPersona": consecutivoClienteAval  , "idPersona": IdPersonaAval }	);
					break;
				case COMP_DOMICILIO.id:
					documentos.push( {"idDocumento":COMP_DOMICILIO.id, "documentoDes":COMP_DOMICILIO.descripcion, "status":STATUS_PENDIENTE, "idTipoPersona": idTipoPersonaAval, "consecutivoPersona": consecutivoClienteAval  , "idPersona": IdPersonaAval}	);
					break;
				case COMP_PROPIEDAD.id:
					documentos.push( {"idDocumento":COMP_PROPIEDAD.id, "documentoDes":COMP_PROPIEDAD.descripcion, "status":STATUS_PENDIENTE, "idTipoPersona": idTipoPersonaAval, "consecutivoPersona": consecutivoClienteAval  , "idPersona": IdPersonaAval}	);
					break;
				case COMP_ARRAIGO_DOMICILIARIO.id:
					documentos.push( {"idDocumento":COMP_ARRAIGO_DOMICILIARIO.id, "documentoDes":COMP_ARRAIGO_DOMICILIARIO.descripcion, "status":STATUS_PENDIENTE, "idTipoPersona": idTipoPersonaAval, "consecutivoPersona": consecutivoClienteAval  , "idPersona": IdPersonaAval}	);
					break;
				case COMP_ARRAIGO_LABORAL.id:
					documentos.push( {"idDocumento":COMP_ARRAIGO_LABORAL.id, "documentoDes":COMP_ARRAIGO_LABORAL.descripcion, "status":STATUS_PENDIENTE, "idTipoPersona": idTipoPersonaAval, "consecutivoPersona": consecutivoClienteAval  , "idPersona": IdPersonaAval}	);
					break;
				case COMP_INGRESOS.id:
					documentos.push( {"idDocumento":COMP_INGRESOS.id, "documentoDes":COMP_INGRESOS.descripcion, "status":STATUS_PENDIENTE, "idTipoPersona": idTipoPersonaAval, "consecutivoPersona": consecutivoClienteAval  , "idPersona": IdPersonaAval}	);
					break;
				case IDENTIFICACION_OFICIAL_AVAL.id:
					documentos.push( {"idDocumento":IDENTIFICACION_OFICIAL_AVAL.id, "documentoDes":IDENTIFICACION_OFICIAL_AVAL.descripcion, "status":STATUS_PENDIENTE, "idTipoPersona": idTipoPersonaAval, "consecutivoPersona": consecutivoClienteAval  , "idPersona": IdPersonaAval}	);
					break;
				case COMP_DOMICILIO_AVAL.id:
					documentos.push( {"idDocumento":COMP_DOMICILIO_AVAL.id, "documentoDes":COMP_DOMICILIO_AVAL.descripcion, "status":STATUS_PENDIENTE, "idTipoPersona": idTipoPersonaAval, "consecutivoPersona": consecutivoClienteAval  , "idPersona": IdPersonaAval}	);
					break;
				case COMP_PROPIEDAD_AVAL.id:
					documentos.push( {"idDocumento":COMP_PROPIEDAD_AVAL.id, "documentoDes":COMP_PROPIEDAD_AVAL.descripcion, "status":STATUS_PENDIENTE, "idTipoPersona": idTipoPersonaAval, "consecutivoPersona": consecutivoClienteAval  , "idPersona": IdPersonaAval}	);
					break;
				case COMP_INGRESOS_AVAL.id:
					documentos.push( {"idDocumento":COMP_INGRESOS_AVAL.id, "documentoDes":COMP_INGRESOS_AVAL.descripcion, "status":STATUS_PENDIENTE, "idTipoPersona": idTipoPersonaAval, "consecutivoPersona": consecutivoClienteAval  , "idPersona": IdPersonaAval}	);
					break;
				}
			}



			var DocumentosReq =  generalService.multitasas("PRESTAMOS PERSONALES.SERVICIOS.DOCUMENTO REQUERIDO",tipoTasa);
			var tipoPersona = generalService.multitasas("PRESTAMOS PERSONALES.SERVICIOS.DOCUMENTOS TIPO PERSONA",tipoTasa);
			var idTipoPersonaAval = 0;
			var documentos = $rootScope.solicitudJson.documentos.documento;
			console.log(documentos);


			function buscaTipoPersona(documentosArrays, $scope){
				for  (var y = 0; y < tipoPersona.length; y++){
					var DocumentosValores = tipoPersona[y].DOCUMENTOS.valor
					var tipoPersonaArray = DocumentosValores.split(",");
					for  (var n = 0; n < tipoPersonaArray.length; n++){
						if (tipoPersonaArray[n] == documentosArrays ){
							if (tipoPersona[y]["TIPO PERSONA"].valor == "CLIENTE"){
								idTipoPersonaAval = 1;
							}else{
								idTipoPersonaAval = 3;
								$scope.tipoAval2 = true;
							}
						}
					}

				}
				return idTipoPersonaAval;
			}
			if (documentos == null)
				documentos = [];
			console.log(documentos);
			function validaDocumento(w){
				var documentosValor = DocumentosReq[i]["DOCUMENTO"].valor;
				documentosArray =  documentosValor.split(",");
				var agregaDoc = true;
				var idTipoPersonaAval = 0;

				for (r = 0; r < documentosArray.length; r++){
					agregaDoc = true;
					var h = 0;
					agregaDoc = revisaExistencia(documentosArray[r], agregaDoc, 3, 1);
					if (agregaDoc){
						idTipoPersonaAval =  buscaTipoPersona(documentosArray[r], $scope);
						if ($scope.tipoAval2 && $scope.avales){
							$scope.llenaArreglo();
						}
						else if($scope.tipoAval2){
							var avaleslongitud = $rootScope.solicitudJson.avales
							for (var t = 0; t < avaleslongitud.length; t++){
								consecutivoClienteAval = $rootScope.solicitudJson.avales[w].consecutivoPersona;
								IdPersonaAval = $rootScope.solicitudJson.avales[w].idPersona;
								$scope.llenaArreglo();
							}
						}else{
							$scope.llenaArreglo();
						}

					}
				}
			}

			function revisaExistencia(documentosArrays, agregaDoc1, comparar, asignar){
				if (documentos.length > 0){
					for (var h = 0; (h < documentos.length && agregaDoc1 == true) ; h++){
						if (documentosArrays == documentos[h].idDocumento ){
							agregaDoc1 = false;
							if (asignar == 3 ){
								documentos[h].status = asignar
							}else{
								if (documentos[h].status == comparar){
									documentos[h].status = asignar;
								}
							}
							if (documentos[h].consecutivoPersona != consecutivoClienteAval ){
								agregaDoc1 = true;
							}
						}else{
							agregaDoc1 = true;
						}
					}
				}else{
					agregaDoc1 = true;
				}
				return agregaDoc1;
			}



			function  validacionValores(w){
				var agregaDoc2 = true;
				var documentosValor = DocumentosReq[i]["DOCUMENTO"].valor;
				documentosArray =  documentosValor.split(",");
				switch(DocumentosReq[i]["OPERACIÓN"].valor){
				case "=":
				case "==":
					if (DocumentosReq[i]["CONDICION"].valor == $rootScope.valorReal){
						efectivo = true;
						validaDocumento(w);
					}else
						if (!efectivo){
							for (var u = 0; u < documentosArray.length; u++){
								revisaExistencia(documentosArray[u], agregaDoc2, 1, 3);
							}
						}
					break;
				case "!=":
					if (DocumentosReq[i]["CONDICION"].valor != $rootScope.valorReal){
						efectivo = true;
						validaDocumento(w);
					}else
						if (!efectivo){
							for (var u = 0; u < documentosArray.length; u++){
								revisaExistencia(documentosArray[u], agregaDoc2, 1, 3);
							}
						}
					break;
				case ">":
					if ( $rootScope.valorReal > DocumentosReq[i]["CONDICION"].valor ){
						efectivo = true;
						validaDocumento(w);
					}else
						if (!efectivo){
							for (var u = 0; u < documentosArray.length; u++){
								revisaExistencia(documentosArray[u], agregaDoc2, 1, 3);
							}
						}
					break;
				case ">":
					if ( $rootScope.valorReal < DocumentosReq[i]["CONDICION"].valor ){
						efectivo = true;
						validaDocumento(w);
					}else
						if (!efectivo){
							for (var u = 0; u < documentosArray.length; u++){
								revisaExistencia(documentosArray[u], agregaDoc2, 1, 3);
							}
						}
					break;
				case ">=":
					if ($rootScope.valorReal >= DocumentosReq[i]["CONDICION"].valor){
						efectivo = true;
						validaDocumento(w);
					}else
						if (!efectivo){
							for (var u = 0; u < documentosArray.length; u++){
								revisaExistencia(documentosArray[u], agregaDoc2, 1, 3);
							}
						}
					break;
				case "<=":
					if ($rootScope.valorReal <= DocumentosReq[i]["CONDICION"].valor){
						efectivo = true;
						validaDocumento(w);
					}else
						if (!efectivo){
							for (var u = 0; u < documentosArray.length; u++){
								revisaExistencia(documentosArray[u], agregaDoc2, 1, 3);
							}
						}
					break;
				}
			}




			for (var i=0; i < DocumentosReq.length; i++) {

				var consecutivoClienteAval = 0;
				var IdPersonaAval = "";
				var valorCampo  = DocumentosReq[i]["CAMPO"].valor
				$rootScope.valoresAval = "";
				var efectivo = false;
				var cadena1 = $rootScope.validaCadena(valorCampo);
				if(!cadena1){
					$rootScope.valoresAval = "";
					$rootScope.valorReal = $rootScope.valoresAval;
					validacionValores();
				}
				IdPersonaAval = $rootScope.solicitudJson.cotizacion.clientes[0].idPersona;
				consecutivoClienteAval = $rootScope.solicitudJson.cotizacion.clientes[0].consecutivoPersona;
				valorCampo = valorCampo.replace(/clientes/g, "clientes[" + 0 +"]" );
				valorCampo = valorCampo.replace(/domicilios/g, "domicilios[" + 0 +"]" );
				valorCampo = valorCampo.replace(/avales/g, "avales[" + 0 +"]" );
				valorCampo = valorCampo.replace(/detallesCotizacion/g, "detallesCotizacion[" + 0 +"]" );
				$rootScope.valorReal = eval( "( $rootScope.solicitudJson." + valorCampo + ")" )
			}
			documentos.sort(function (a, b) {
				  if (parseInt(a.idDocumento) > parseInt(b.idDocumento)) {
				    return 1;
				  }
				  if (parseInt(a.idDocumento) <  parseInt(b.idDocumento)) {
				    return -1;
				  }
				  // a must be equal to b
				  return 0;
				});

			$rootScope.solicitudJson.documentos.documento = documentos;
			$rootScope.calculaDocumentos();
		}




		$rootScope.calculaDocumentos = function(){
    		var numDocsCapturados = 0;
    		$scope.numDocsRequeridos = 0;
    		var existeDoc = false;

    		if( generalService.existeSolicitud($rootScope.solicitudJson) ){

		    		if($rootScope.solicitudJson.documentos.documento!=null){
			    		angular.forEach( $rootScope.solicitudJson.documentos.documento, function(doc, key){
							if(doc.idDocumento==IDENTIFICACION_OFICIAL.id  && generalService.documentoValido(doc.status) ){
								numDocsCapturados++;

							}else if(doc.idDocumento==COMP_DOMICILIO.id &&  generalService.documentoValido(doc.status) ){
								numDocsCapturados++;

							}else if(doc.idDocumento==COMP_PROPIEDAD.id &&  generalService.documentoValido(doc.status) ){
								numDocsCapturados++;

							}else if(doc.idDocumento==COMP_ARRAIGO_DOMICILIARIO.id &&  generalService.documentoValido(doc.status) ){
								numDocsCapturados++;

							}else if(doc.idDocumento==COMP_ARRAIGO_LABORAL.id &&  generalService.documentoValido(doc.status) ){
								numDocsCapturados++;

							}else if(doc.idDocumento==COMP_INGRESOS.id && generalService.documentoValido(doc.status) ){
								numDocsCapturados++;

							}else if(doc.idDocumento==IDENTIFICACION_OFICIAL_AVAL.id  && generalService.documentoValido(doc.status) ){
								numDocsCapturados++;

							}else if(doc.idDocumento==COMP_DOMICILIO_AVAL.id  && generalService.documentoValido(doc.status) ){
								numDocsCapturados++;

							}else if(doc.idDocumento==COMP_PROPIEDAD_AVAL.id && generalService.documentoValido(doc.status) ){
								numDocsCapturados++;

							}else if(doc.idDocumento==COMP_INGRESOS_AVAL.id && generalService.documentoValido(doc.status) ){
								numDocsCapturados++;
							}
							if (doc.status != 3)
								$scope.numDocsRequeridos++;
							var DocumentosReq1 =  generalService.multitasas("PRESTAMOS PERSONALES.SERVICIOS.SECCION DOCUMENTO",tipoTasa);
							for (var i = 0; i < DocumentosReq1.length; i++){
								var tipoDocumentoSarray = DocumentosReq1[i]["DOCUMENTO"].valor;
								var tipoDocumentoArray = tipoDocumentoSarray.split(",");
								for  (var n = 0; n < tipoDocumentoArray.length; n++){
									if (tipoDocumentoArray[n] == doc.idDocumento ){
										validaEstatus();
									}
								}
							}
							function validaEstatus(){
								switch(DocumentosReq1[i]["SECCION"].valor){
								case "1" :
									if ($rootScope.solicitudJson.cotizacion.clientes[0].porcentaje == "100" && doc.status == 2)
										doc.status = 4;
									break;
								case "2" :
									if ($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje == "100" && doc.status == 2)
										doc.status = 4;
									break;
								case "3" :
									if ($rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje == "100" && doc.status == 2)
										doc.status = 4;
									break;
								case "4" :
									if ($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje == "100" && doc.status == 2)
										doc.status = 4;
									break;
								case "5" :
									if ($rootScope.solicitudJson.avales[0].porcentaje == "100" && doc.status == 2)
										doc.status = 4;
									break;
								case "6" :
									if ($rootScope.solicitudJson.referencias.porcentaje == "100" && doc.status == 2)
										doc.status = 4;
									break;
								case "7" :
									if ($rootScope.solicitudJson.documentos.porcentaje == "100" && doc.status == 2)
										doc.status = 4;
									break;
								case "8" :
									if ($rootScope.solicitudJson.contratos.porcentaje == "100" && doc.status == 2)
										doc.status = 4;
									break;
								}
							}
//			    		}

						});

		    		}

	    		if( numDocsCapturados > 0){
	    			var porcentajeExp = (numDocsCapturados * 100) / $scope.numDocsRequeridos;
	    			$rootScope.solicitudJson.documentos.porcentaje =  porcentajeExp > 100 ? 100: parseInt( porcentajeExp.toFixed(0) );
	    		}else
	    			$rootScope.solicitudJson.documentos.porcentaje = 0;

    		}
		};
//		});



		$rootScope.responseEnvioImg1Ipad = function(responseIPAD){
			$rootScope.loggerIpad("responseEnvioImg1Ipad", null, responseIPAD);
		};

		$rootScope.responseEnvioImg2Ipad = function(responseIPAD){
				$rootScope.loggerIpad("responseEnvioImg2Ipad", null, responseIPAD);

				if(responseIPAD.codigo == RESPONSE_CODIGO_EXITO_IPAD){

					var idIFE = new Array();
					idIFE.push(IDENTIFICACION_OFICIAL.id);
					generalService.setArrayValue("IdentificadoresDocs",idIFE);

					var ifefrente = IDENTIFICACION_OFICIAL.descripcion + " " + CLIENTE.descripcion +" " + generalService.getDatafromCategory("SIMULADOR", "ETIQUETA FRENTE", "VALOR.valor" );
					var ifereverso = IDENTIFICACION_OFICIAL.descripcion + " " + CLIENTE.descripcion +" " + generalService.getDatafromCategory("SIMULADOR", "ETIQUETA REVERSO", "VALOR.valor" );

					$rootScope.executeAction( "moduloTracker",
								  "executeActionResponseExp",
								  {
									nombre:"envioDocumentos",
									idCliente:$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
									mostrarSpinner:0,
									filtroDocumentos: ifefrente +","+ifereverso
								  }
								);

				}
	 	};


	 	$rootScope.responseEnvioFirmaAP = function(responseIPAD){
	 		$rootScope.loggerIpad("responseEnvioFirmaAP", null, responseIPAD);
		};


		$rootScope.responseEnvioFirmaBuro = function(responseIPAD){
			$rootScope.loggerIpad("responseEnvioFirmaBuro", null, responseIPAD);

	 		if(responseIPAD.codigo == RESPONSE_CODIGO_EXITO_IPAD){
	 				$rootScope.executeAction( "moduloTracker",
							  "executeActionResponseOff",
							  {
								nombre:"envioDocumentos",
								idCliente:$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
								mostrarSpinner:0,
								filtroDocumentos: FIRMA_PRIVACIDAD.descripcion+","+FIRMA_BURO.descripcion
							  }
							);

			}
		};
		
		$rootScope.responseHuellaINE = function(response) {			
		$rootScope.loggerIpad("responseHuellaINE", response);

		// Se "clona" la solicitud, para no afectar los datos originales de la solicitud.
		var solicitud = JSON.parse(JSON.stringify($rootScope.solicitudJson));
		
		// ¿Fue una respuesta exitosa?
		if(response.codigo == ENROLAMIENTO_HUELLA.EXITO) {				
			solicitud.marca = STATUS_SOLICITUD.generada.marca.huellasINEAprobado;
			solicitud.huellaExistenteINE = "1";
			
			$rootScope.solicitudJson.huellaExistenteINE = "1";
		} else { // No se obtuvo una respuesta exitosa.
			solicitud.marca = STATUS_SOLICITUD.generada.marca.huellasINERechazado;
			solicitud.huellaExistenteINE = "0";
			
			$rootScope.solicitudJson.huellaExistenteINE = "0";
		}

		solicitudService.actualizarSolicitud(solicitud).then(
				function(data) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;

					// Con cualquier tipo de respuesta, se regresa la marca a su estado original.
					if(data.data.codigo != undefined) {
						// Hay documentos para encolar.
						if(!generalService.isEmpty(filtroDocsHuellaFoto)) {
							// Se deben borrar las huellas.
							if(typeof realizarEnvioHuellas !== "undefined" && !realizarEnvioHuellas) {
								// ¿Las huellas van en la cadena de encolados?
								if(filtroDocsHuellaFoto.indexOf(constantesIpad.descHuellaCte) >= 0) {
									// Se borran las huellas.
									$rootScope.executeAction( "moduloTracker",
										"executeActionResponseOff",
										{
											nombre: "borrarEncolados", 
											idCliente: $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
											idDocumentos: constantesIpad.descHuellaCte
										}
									);
									
									var encolados = filtroDocsHuellaFoto.split(",");
									
									filtroDocsHuellaFoto = "";
									
									// Se recorre la cadena de encolados.
									for(var i in encolados) {
										// Si no es la descripción de huellas, se agrega.
										if(encolados[i].trim() != constantesIpad.descHuellaCte) {
											filtroDocsHuellaFoto += encolados[i].trim() + ",";
										}
									}
									
									// Procesada la cadena, si se agregó algo, se debe eliminar la coma del final.
									if(filtroDocsHuellaFoto.length > 0) {
										filtroDocsHuellaFoto = 
											filtroDocsHuellaFoto.substr(0, filtroDocsHuellaFoto.length - 1);
									}
								}							
							}
							
							// Todavía hay documentos que enviar.
							if(!generalService.isEmpty(filtroDocsHuellaFoto)) {
								// Se envían los documentos que estén encolados.
								$rootScope.executeAction( "moduloTracker",
									"executeActionResponseOff",
									{
										nombre: "envioDocumentos", 
										idCliente: $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
										mostrarSpinner: 0, 
										filtroDocumentos: filtroDocsHuellaFoto
									}
								);
								
								// Se limpia la variable de doctos.
								filtroDocsHuellaFoto = "";
								
								// Se indefine la bandera de encolamiento de huellas.
								realizarEnvioHuellas = undefined;
							}
						}
					}
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					// Se limpia la variable de doctos.
					filtroDocsHuellaFoto = "";
					
					// Se indefine la bandera de encolamiento de huellas.
					realizarEnvioHuellas = undefined;
					
					modalService.alertModal("Error " + error.status, [error.statusText]);
				}
		);
}

		var senfBackFunction = function(numObjEncolados) {
			if(numObjEncolados == _numObjEncolados 
					&& !generalService.isEmpty(filtroDocsHuellaFoto)) {
				// Variable para saber en dónde se ejecuta el código.
				var dispositivo = $rootScope.solicitudJson.tipoDispositivo;
				
				// Es el gruaper de  Aypad.
				if(dispositivo == "iPad") {					
					// Existe folio de INE/IFE para una validación.
					if($rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion != "") {
						// Las huellas del cliente no se han pedido, ni se han cotejado contra el INE. 
						if($rootScope.solicitudJson.cotizacion.clientes[0].huella != "1"
								&& $rootScope.solicitudJson.huellaExistenteINE == "") {
							realizarEnvioHuellas = true;
						} else {
							realizarEnvioHuellas = false;
						}
						
						$rootScope.executeAction("moduloTracker", "responseHuellaINE",
							{
								nombre: "validacionINE",
								idCliente: $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
								type: "huellasINE",
								service: "huellasINE",
								ocr: $rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion,
								idSucursal: $rootScope.sucursalSession.idSucursal,
								tipoBusqueda: 2,
								formatoHuella: "wsq",
								indiceDerecho: "",
								indiceIzquierdo: ""
							}
						);					
					} else { // No existe folio, quizás el usuario presenta PASSPORT.
						// Entonces, sólo se envían los documentos.
						$rootScope.executeAction( "moduloTracker",
							"executeActionResponseOff",
							{
								nombre: "envioDocumentos", 
								idCliente: $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
								mostrarSpinner: 0, 
								filtroDocumentos: filtroDocsHuellaFoto
							}
						);
					}

					generalService.setArrayValue("numObjEncolados", 0);
					// filtroDocsHuellaFoto = "";
					_numObjEncolados = 0;
				
				} else if(dispositivo == "Windows") { // Es el gruaper de Güindous.
					// TODO Aquí iría el códice para el wrapper de Windows.
					// Por ahora sólo se envían los documentos.
					$rootScope.executeAction( "moduloTracker",
						"executeActionResponseOff",
						{
							nombre: "envioDocumentos", 
							idCliente: $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
							mostrarSpinner: 0, 
							filtroDocumentos: filtroDocsHuellaFoto
						}
					);
				} else {} // Nothing to do. It's web.
			}
		};
		
		/** INICIA_OS-FLUJO COACREDITADO **/		
		$scope.responseEncoladoHuellaOS = function(response) {
			$rootScope.loggerIpad("responseEncoladoHuellaOS", null, response);
			
			try {
				if(response.codigo == 0) {
					// Se aumenta el contador de encolados.
					_numObjEncolados++;
					
					// Se agrega la descripción de lo que se encoló.
					filtroDocsHuellaFoto += generalService.isEmpty(filtroDocsHuellaFoto) ? "Huella OS" : ",Huella OS";					
				} else {
					console.log("Algo fue mal con las huellas del Coacreditado.");
				}
				
				// Si se tiene algo para enviar, pues, que fluya.
				if(_numObjEncolados > 0 && filtroDocsHuellaFoto.length > 0) {
					$rootScope.executeAction( "moduloTracker",
						"executeActionResponseOff",
						{
							nombre: "envioDocumentos", 
							idCliente: $rootScope.solicitudOSJson.cotizacion.clientes[0].idPersona,
							mostrarSpinner: 0, 
							filtroDocumentos: filtroDocsHuellaFoto
						}
					);
				}
			} catch(x) {
				$rootScope.message("AVISO", ["Error al encolar archivos."], "Aceptar", null, null, 
						null, null, "GENERAL","ERROR COMPONENTE");
			}
		};
/** TERMINA_OS-FLUJO COACREDITADO **/

		$scope.responseEnvioFotoIpad = function( responseIPAD ){
			$rootScope.loggerIpad("responseEnvioFotoIpad", null, responseIPAD);
			try{
				_numObjEncolados++;
				if( responseIPAD.codigo == 0 ){
					if( !generalService.isEmpty(filtroDocsHuellaFoto) )
						filtroDocsHuellaFoto += ",";

					filtroDocsHuellaFoto += constantesIpad.descFotoCte;

				}


				senfBackFunction(parseInt(generalService.getArrayValue("numObjEncolados")));

			}catch(e){
				$rootScope.message("AVISO",[ "Error al encolar archivos."], "Aceptar", null,null,null,null,"GENERAL","ERROR COMPONENTE");
				console.error( e.message );

			}


		};

		$scope.responseEnvioHuellaIpad = function(responseIPAD) {
			$rootScope.loggerIpad("responseEnvioHuellaIpad", null, responseIPAD);
			
			try{
				_numObjEncolados++;
				
				if(responseIPAD.codigo == 0) {
					if(!generalService.isEmpty(filtroDocsHuellaFoto))
						filtroDocsHuellaFoto += ",";

					filtroDocsHuellaFoto += constantesIpad.descHuellaCte;
				}

				senfBackFunction(parseInt(generalService.getArrayValue("numObjEncolados")));
			} catch(e) {
				$rootScope.message("AVISO", ["Error al encolar archivos."], "Aceptar", null, null, 
						null, null, "GENERAL","ERROR COMPONENTE");
				console.error( e.message );
			}
		};
		
		$rootScope.loggerIpad = function( funcion,Json,respuesta ){
        	try{
	        	var codigo="";
	        	var mensaje="";

	        	if (respuesta){
	        		if (respuesta.mensaje){
	            		mensaje = respuesta.mensaje;
	            	}

	        		try{
	        			codigo = respuesta.codigo;
	        		}catch(e){
	        		}

	        	}


		    	if (!Json){
		    		var json = {
		    				"Solicitud": $rootScope.solicitudJson.idSolicitud,
		    				"IdPersona": $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
		    				"IdFuncion": funcion,
		    				"Codigo"   : codigo,
		    				"mensaje"  : mensaje
		    		}

		    	}else{
		    		var json = {
		    				"Solicitud": $rootScope.solicitudJson.idSolicitud,
		    				"IdPersona": $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
		    				"IdFuncion": funcion,
		    				"Peticion": Json
		    		}
		    	}
		    	
		    	if(validarGrabarLog(funcion)){
			    	solicitudService.loggerFront( json ).then(
						function(data){
						}, function(error){
						}
					);
		    	}
        	}catch( e ){
        			console.log("Error loggerIpad: " + e);
	        }
		}
		
		$rootScope.loggerServicios = function( funcion,json ){
        	try{
		    	var json = {
		    		"Solicitud": $rootScope.solicitudJson.idSolicitud,
		    		"IdFuncion": funcion,
		    		"json": json
		    	}
		    	
		    	if(validarGrabarLog(funcion)){
			    	solicitudService.loggerFront( json ).then(
						function(data){
						}, function(error){
						}
					);
		    	}
        	}catch( e ){
        			console.log("Error loggerServicios: " + e);
	        }
		}
		
		var validarGrabarLog = function(funcion){
			var guardarLog=true;
			try{
				if(funcion in LOGS_FRONT.funcion){
					guardarLog = LOGS_FRONT.funcion[funcion];
				}
			}catch(e){
				guardarLog=true;
			}
			return guardarLog;
		};
		
// I-MODIFICACION SIPA (FUNCION PARA VALIDAR CLIENTES SIPA)
		$rootScope.productosSIPA = function(idProducto){
	    	var indexProducto=PRODUCTOS_SIPA.indexOf(idProducto);
			if( indexProducto !=-1 && $rootScope.consultaFuncionalidad.solicitudesSIPA)
				return true;
			else
				return false;
	    }
		
		$rootScope.validaHuellaCu = function(listaCU){
			for (var i = 0; i < listaCU.length; i++){
				if (listaCU[i].fiStatusHuellas != 0)
					return true
				
			}
			return false;
		}
// F-MODIFICACION SIPA (FUNCION PARA VALIDAR CLIENTES SIPA)
// I-MODIFICACION TDC (FUNCIONES PARA VALIDAR TDC)
		 $rootScope.productosTarjetas = function(idProducto){
		    	var indexProducto=PRODUCTOS_TARJETAS.indexOf(idProducto);
				if( indexProducto !=-1 )
					return true;
				else
					return false;
		    }
		 $rootScope.productosTarjetasD = function(idProducto){
		    	var indexProducto=PRODUCTOS_TARJETAS.indexOf(idProducto);
				if( indexProducto !=-1 )
					return true;
				else
					return false;
		    }
		 
		 $rootScope.promocionCampanas = function(campana){
		    	var indexProducto=CAMPANAS.indexOf(campana);
				if( indexProducto !=-1 )
					return true;
				else
					return false;
		    }
		 $rootScope.campanasPreaprobados = function(campana){
			 var indexProducto=CAMPANAS_REACTIVADOS_ARR.indexOf(campana);
				if( indexProducto !=-1 )
					return true;
				else
					return false;
		 }
		 $rootScope.campanasConvivencia = function(campana){
			 var indexProducto=CAMPANA_COMVIVENCIA.indexOf(campana);
				if( indexProducto !=-1 )
					return true;
				else
					return false;
		 }
		 
		 $rootScope.campanasEsc_Ctes = function(campana){
			 var indexProducto=CAMPANA_ESC_CTES.indexOf(campana);
				if( indexProducto !=-1 )
					return true;
				else
					return false;
		 }
		 
		 $rootScope.campanasPreaprobadosCaptacion = function(campana){
			 var indexProducto=CAMPANAS_PREAPROBADO_CAPTACION_ARR.indexOf(campana);
				if( indexProducto !=-1 )
					return true;
				else
					return false;
		 }
		 $rootScope.campanasSipa = function(campana){
			 var indexProducto=CAMPANAS_PREAPROBADO_SIPA_ARR.indexOf(campana);
				if( indexProducto !=-1 )
					return true;
				else
					return false;
		 }
		 
		 $rootScope.canalesCaptacion = function(canal){
			 var indexProducto=CANALES_PREAPROBADO_CAPTACION_ARR.indexOf(canal);
				if( indexProducto !=-1 )
					return true;
				else
					return false;
		 }
		 
		 $rootScope.campanaNvoPreaprob = function(campana){
			 var indexProducto=CAMPANAS_NVOPREAP.indexOf(campana);
				if( indexProducto !=-1 )
					return true;
				else
					return false;
		 }
//*********************************************************************************
//*I- valida si el cliente es un preaprobado de remesas o tarjetas                *
//*********************************************************************************
		 $rootScope.validaPreAprobados=function(){
			 if ($rootScope.productosTarjetas( $rootScope.solicitudJson.idProducto ) &&  $rootScope.promocionCampanas($rootScope.solicitudJson.tarjetasCredito.tarjetaOro.campana)){
				 return true;
			 }else if($rootScope.productosSIPA( $rootScope.solicitudJson.idProducto) && $rootScope.promocionCampanas($rootScope.solicitudJson.campana)){
				 return true;
			 }else{
				 return false;
			 }
		 }
//*********************************************************************************
//*F- valida si el cliente es un preaprobado de remesas o tarjetas                *
//*********************************************************************************		 
		 $rootScope.descTarjetas = function(id, contrato){
			 try{
				 if (contrato.indexOf('ng-include') > -1){
					 contrato = contrato.substr(28,99) 
					 contrato = contrato.replace("</div>", "");
					 contrato= contrato.replace(/[^A-Za-z.]/g, "")
				 }
			 }catch(e){
				 
			 }
			 
			 var indexProducto = PRODUCTOS_TARJETAS_DES.map(function(d){
				 return d["id"];
					
			 }).indexOf (id);
			 
			 if( indexProducto !=-1 ){
				 PRODUCTOS_TARJETAS_DES[indexProducto].reca = $rootScope.RECA(id, contrato);
				 return  PRODUCTOS_TARJETAS_DES[indexProducto];
			 }else
				 return {id: 99, desc: "" , reca: ""};
		    }
		 
		 $rootScope.RECA = function(id, contrato){
			 var indexProducto = PRODUCTOS_TARJETAS_RECA.map(function(d){
				 return d["id"];
					
			 }).indexOf (id);
			 
			 if( indexProducto !=-1 ){
				 var recas =   PRODUCTOS_TARJETAS_RECA[indexProducto].RECA;
				 var index = recas.map(function(d){
					 return d["id"];
				 }).indexOf (contrato);
				 if( index !=-1 ){
					 return recas = recas[index].reca
				 }else{
					 return "";
				 }
				 
			 }else{
				 return "";
			 } 
		 }
		 $rootScope.camelize =function(desc){
			 return generalService.camelize(desc);
		 }
		 $rootScope.archivafirmasTarjeta = function(domiciliacion, firma){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$scope.contadorArchivarFirmas++;
				
				var descripcion = "";
				var etiqueta = "";
				var descEncolado = ""
				if (domiciliacion){
					descripcion = FIRMA_DOMICILILACION_TARJETA.descripcion;
					etiqueta =  FIRMA_DOMICILILACION_TARJETA.etiqueta;
					descEncolado = FIRMA_DOMICILILACION_TARJETA.descEncolado;
				}else{
					descripcion = FIRMA_ACUSE_TARJETA.descripcion;
					etiqueta =  FIRMA_ACUSE_TARJETA.etiqueta;
					descEncolado = FIRMA_ACUSE_TARJETA.descEncolado;
				}
//				descripcion = FIRMA_SEGURO_CLIENTE.descripcion;
//				etiqueta =  FIRMA_SEGURO_CLIENTE.etiqueta;
				$scope.imgFirma = firma;
				if (!firma){
					console.log("No hay firma");
				}else{
			    	$scope.b64Firma = firma.replace("data:image/png;base64,","").trim();
			    	if($scope.origen == "TIENDA"){
				    	$rootScope.enviarImagen(
				    			$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
				    			"",
				    			DESC_CONTRATO_TARJETA,
				    			etiqueta,
				    			'moduloTracker',
				    			{	
				    				ruta: null,
				    				idSolicitud: $rootScope.solicitudJson.idSolicitud,
				    				cadena:$scope.b64Firma,
				    				tipoCadena: descripcion,
				    				nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
				    				foto: $rootScope.fotoCteOriginal
				    			},	
				    			"responseArchivafirmasTarjeta"
				    	);
			    	}	
				}
			};
			$rootScope.responseArchivafirmasTarjeta = function( responseIPAD ){
				$scope.contadorRepsuestaFirmas++
				$rootScope.loggerIpad("responseEnvioFirmas1", null, responseIPAD);
				try{
					
					if( responseIPAD.codigo == 0 ){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.executeAction( "moduloTracker", "respuestaContratosDos",  
								  { nombre:"envioDocumentos", idCliente:$rootScope.solicitudJson.cotizacion.clientes[0].idPersona, mostrarSpinner:0, 
			                      filtroDocumentos: CONTRATOS_ENVIAR+","+FIRMA_PRIVACIDAD.descripcion+","+FIRMA_BURO.descripcion+","+FIRMA_DOMICILILACION_TARJETA.etiqueta+","+FIRMA_ACUSE_TARJETA.etiqueta});
//						+","+FIRMAR_CTE_CONTRATOS_TARJETA+","+FIRMA_ACUSE_TARJETA.etiqueta+","+FIRMA_DOMICILILACION_TARJETA.etiqueta });
					}else{
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("CONTRATOS",[ "Error al encolar archivos." + JSON.stringify(responseIPAD)], "Aceptar", null);
						
					}
					
				}catch(e){
					console.log(e.message);
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Error al encolar archivos."+e.message], "Aceptar", null);
					console.error( e.message );
				}
			}
			$rootScope.respuestaContratosDos = function(){
				$rootScope.contratosResponseCita = true;
				$rootScope.loggerIpad("respuestaContratos", null, respuesta);
				console.log(respuesta);
			}
			 $rootScope.sucursalesTarjetas = function(sucursal){
			    	var index=SUCURSALES.Tarjetas.indexOf(sucursal);
					if( index !=-1 )
						return true;
					else
						return false;
			    }
			 $rootScope.sucursalesTarjetasOro = function(sucursal){
			    	var index=SUCURSALES.TarjetasOro.indexOf(sucursal);
					if( index !=-1)
						return true;
					else
						return false;
			    }
			 $rootScope.sucursalesTarjetasEkt = function(sucursal){
			    	var index=SUCURSALES.TarjetasEkt.indexOf(sucursal);
					if( index !=-1 )
						return true;
					else
						return false;
			    }
// F-MODIFICACION TDC (FUNCIONES PARA VALIDAR TDC)
			 
			 
// I-MODIFICACION REACTIVADO (QUEMAR FOLIO)
	    $rootScope.actualizaReactivado = function(idSolicitud){ 
			    	var x = {
			    	 idSolicitud: idSolicitud,
			    	 estatus: QUEMAR_FOLIO
			    	};
			solicitudService.actualizaReactivado(x).then(
			function(data){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(data.data.codigo == RESPONSE_CODIGO_EXITO){
					console.log("Se quemó folio Reactivado")
				}else
					console.log("No quemó folio Reactivado")
			}, function(error){
				$rootScope.waitLoaderStatus = LOADER_HIDE; 
				validateService.error(error);
			});
	    };
// F-MODIFICACION REACTIVADO (QUEMAR FOLIO)

	    $rootScope.informeRecomendado = function(){
	    	if ($rootScope.solicitudJson.folioRecomendador == "" || $rootScope.solicitudJson.folioRecomendador == null){
	    		console.log("No guardo");
	    	}else{
	    		var x= {idSolicitud: $rootScope.solicitudJson.idSolicitud};
				console.log(x);
				recomiendaService.informeRecomendado(x).then(
					function(data) {
					}, function(error) {
						console.log(error);
						$rootScope.waitLoaderStatus = LOADER_HIDE; 
					});
	    	}
				
	    }
	    $rootScope.canalesPRG = function(canal){
	    	var index=CANALES_PRG.indexOf(canal);
			if( index !=-1)
				return true;
			else
				return false;
	    }
//I-MODIFICACION MARCAS CAMBACEO
		 $rootScope.esSolicitudCambaceo = function(marca){
			 var indexProducto=MARCAS_CAMBACEO_ARR.indexOf(marca);
				if( indexProducto !=-1 )
					return true;
				else
					return false;
		 }
//F-MODIFICACION MARCAS CAMBACEO
		 
		//este metodo valida el status de la linea de credito para la convivencia MOC-MOC
		 //recibe como parametros el cliente unico, el tipo de busqueda y el idSolicitud
		 //0 solo consulta solo el status de la solicitud, y 1 consulta el status de la solicitud
		 //y tambien el status de la LCR
		 $rootScope.consultarStatusLCR = function(clienteUnico, tipoBusqueda,idSolicitud){
			 $rootScope.waitLoaderStatus = LOADER_SHOW; 
			 var jsonRequest =  {
					 "clienteUnico": clienteUnico,
					 "tipoConsulta": tipoBusqueda,
					 "idSolicitud": idSolicitud
			 };
			 tarjetaService.consultaStatusLCR(jsonRequest).then(
					 function(data){
						 $rootScope.waitLoaderStatus = LOADER_HIDE; 
						 if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
							 var responseJson = JSON.parse(data.data.respuesta);
							 if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
								 if($rootScope.solicitudJson.tarjetasCredito != null && $rootScope.solicitudJson.tarjetasCredito != undefined){
									 var jsonStatusLCR = JSON.parse(responseJson.data);
									 
									 switch (jsonStatusLCR.codigo) {
									 case 126:
										 //Error al obtener la solicitud mediante su ID.
										 $rootScope.message("AVISO", [jsonStatusLCR.descripcion],"Aceptar","/ochoPasos");
										 break;
									 case CU_ERROR_GENERAL_EN_BD:
										 $rootScope.message("AVISO", [jsonStatusLCR.descripcion],"Aceptar","/ochoPasos");
										 break;
									 case CU_ERROR_RESPUESTA_DE_BD_NO_CONTROLADA:
										 $rootScope.message("AVISO", [jsonStatusLCR.descripcion],"Aceptar","/ochoPasos");
										 break;
									 case LCR_ERROR_OBTENER_ESTATUS_LCR:
										 $rootScope.message("AVISO", [jsonStatusLCR.descripcion],"Aceptar","/ochoPasos");
										 break;
									 case LCR_CAPACIDAD_DE_PAGO_INSUFICIENTE:
										 generalService.buildSolicitudJson($rootScope, null);
										 $rootScope.message("AVISO", [jsonStatusLCR.descripcion],"Aceptar","/simulador");
										 break;
									 case CONVIVENCIA_LCR_LIBERADA:
										 //si cae en este caso se debe de mostrar el cotizador
										 $rootScope.resultadoConsultaLCR = jsonStatusLCR;
										 
										 var jsonStatus = JSON.parse($rootScope.resultadoConsultaLCR.data);
										 var capacidadPagoTDC = jsonStatus.capacidadDePagoDisponible;
										 var limiteCredito = $rootScope.solicitudJson.observaciones;
//										 if(limiteCredito >= constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[0].limiteCredito && capacidadPagoTDC >= constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[0].capacidadPago){
										 modalService.modalCotizadorTDC();
//									 }else{
//										 
//										 $rootScope.waitLoaderStatus = LOADER_SHOW;
//					     				 solicitudService.cancelarSolicitud({idSolicitud:$rootScope.solicitudJson.idSolicitud}).then(
//					     						 function(data){
//					     							$rootScope.waitLoaderStatus = LOADER_HIDE;
//					     							 if(data.data.codigo == RESPONSE_CODIGO_EXITO){
//					     								 $rootScope.message("AVISO", ["Informa a tu cliente que estamos cuidando su historial crediticio, por el momento no podemos procesar su solicitud"],"Aceptar","/simulador");
//					     							 }else{
//					     								 $rootScope.message("Aviso ", ["Error al cancelar la solicitud"],"Aceptar",null,null,null,null);
//					     							 }
//					     						 }, function(error){
//					     							 $rootScope.waitLoaderStatus = LOADER_HIDE;
//					     							 $rootScope.message("Aviso ", ["Error al cancelar la solicitud"],"Aceptar",null,null,null,null);	
//					     						 });
//									 }
										 generalService.locationPath("/ochoPasos");
										 break;
									 case CONVIVENCIA_LCR_AUTORIZADA_SIN_LIBERAR:
									 case CONVIVENCIA_LCR_CANCELADA:
									 case CONVIVENCIA_LCR_RECHAZADA:
									 case CONVIVENCIA_LCR_BLOQUEADA:
									 case CONVIVENCIA_LCR_AUTORIZADA:
									 case CONVIVENCIA_LCR_DEMANDA_MERCANTIL:
									 case LCR_CLIENTE_NO_CUENTA_CON_LCR:
									 case CONVIVENCIA_CLIENTE_SIN_LCR:
										 $rootScope.message("AVISO", [jsonStatusLCR.descripcion],"Aceptar","/simulador");
										 break;
									 default:
										 $rootScope.message("AVISO", ["Error inesperado"],"Aceptar",null,null, null);
									 break;
									 }
								 }else{
									 $rootScope.message("Aviso",["Error en la etiqueta tarjetasCredito del JSON"], "Aceptar", null, null, null);
									 $scope.closeThisDialog();
								 }
							 }else{
								 $rootScope.message("AVISO", [responseJson.descripcion],"Aceptar",null,null, null);
							 }
						 }else{
							 $rootScope.message("AVISO", [data.data.descripcion],"Aceptar",null,null, null);
						 }
					 }, function(error){
						 $rootScope.waitLoaderStatus = LOADER_HIDE; 
						 $rootScope.message("AVISO", ["Error inesperado"],"Aceptar",null,null, null);
					 }	
			 );
		 };
		 
		 /*
		  * Función que detona el envío en linea de las firmas del Aviso y del Buró
		  * Se valida que se tengan los B64 para prepararse para el envío 
		  */
		 $rootScope.SendSignOnLine = function(avisoEnviado, _path){
				var imgFirma = "";
				if(!avisoEnviado){
					var descripcion = "firmaAviso";
					imgFirma = $rootScope.firmaPrivacidad;
				}else{
					var descripcion = "firmaBuro";
					imgFirma = $rootScope.firmaBuro;
				}
					
				if (!generalService.isEmpty(imgFirma)){
					var cadenaFirma = imgFirma.replace("data:image/png;base64,","").trim();
					if(configuracion.origen.tienda){
						var biometrico = {
								ruta: null,
								idSolicitud: $rootScope.solicitudJson.idSolicitud,
								cadena: cadenaFirma,
								tipoCadena: descripcion,
								porcentaje: 100
						}
						$scope.sendContracts(biometrico, _path);
					}
				}else{
					$rootScope.loggerIpad("La firma del:" + descripcion + "esta vacia", null);
					generalService.locationPath("/ochoPasos");
				}
		 	};
			
		 	$scope.sendContracts = function(biometrico, _path){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$scope.respaldoBio = biometrico;
				clienteUnicoService.setBiometrico( biometrico ).then(
					function(data){
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								if($scope.respaldoBio.tipoCadena == "firmaAviso"){
									if(j.data != null && j.data.idContrato == FIRMA_PRIVACIDAD_ID){
										$rootScope.solicitudJson.contratos.contrato[0].digitalizado = j.data.digitalizado;
									}
									var avisoEnviado = true;
									$rootScope.solicitudJson.contratos.contrato[0].statusFirma = STATUS_CONTRATO.ENVIAD0;
									if($rootScope.isFirmaUnica){
										prepararFirmasB(_path, true);
									}else{
										$rootScope.SendSignOnLine(avisoEnviado, _path);
									}
								}else if(_path != null){
									if(j.data != null && j.data.idContrato == FIRMA_BURO_ID){
										$rootScope.solicitudJson.contratos.contrato[1].digitalizado = j.data.digitalizado;
									}
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									$rootScope.solicitudJson.contratos.contrato[1].statusFirma = STATUS_CONTRATO.ENVIAD0;
									generalService.locationPath(_path);
								}
							}else if(j.codigo == RESPONSE_CODIGO_ERROR_ID){
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message("Error",[j.descripcion], "Aceptar", "/simulador", "bgCafeZ","cafeZ",null,null,null);
							}else{
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message("Error",["Error al enviar los contratos. Por favor, espere unos minutos para reintentar"], "Aceptar", null, "bgCafeZ","cafeZ",null,null,null);
							}
						}else{
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$rootScope.message("Error",["Error en la respuesta del servicio para guardar el contrato del cliente. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafeZ","cafeZ");
						}
					},function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Error",["Servicio no disponible para enviar el contrato, favor de comunicarse con soporte."], "Aceptar", "/simulador", "bgCafeZ","cafeZ");
					});
		 	};
		 	
		 	
		 	function envioDocumentosEnLinea (doc, index, _path, tipoFormato){
				var jsonTmp = JSON.parse(JSON.stringify($rootScope.solicitudJson));
				jsonTmp.documentos.documento[0].status = 4
				
				var digitDocRequest = {
						idSolicitud: jsonTmp.idSolicitud,
						extensionImg: (tipoFormato != "")?tipoFormato:"jpg",
						imagenB64: doc[index].documento,
						idDocumento: doc[index].idDocumento,										
						consecutivoPersona: "0",
						porcentaje: 100,
						envioSinBody: false // si se omite o va en false, se usará el servicio con body.
				};		    			    	
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				documentosService.digitalizar( digitDocRequest ).then(
					function(data){
						if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
							var responseJson = JSON.parse(data.data.respuesta);														
							
							if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){								
								if(index < (doc.length-1)){
									index = index + 1;
									$rootScope.solicitudJson = responseJson.data;
									envioDocumentosEnLinea(doc, index, _path, tipoFormato);
								}else{
									$rootScope.solicitudJson = responseJson.data;
									validarEnvioFirmas(_path);
								}
							}else{
								validarEnvioFirmas(_path);
							}
						}else{
							validarEnvioFirmas(_path);
						}
						
					}, function(error){
			            $rootScope.waitLoaderStatus = LOADER_HIDE;	                
						validarEnvioFirmas(_path);
					}
				);
			};
			
			var plantillaTicket = false;
			$rootScope.generarPlantillaImpresion = function(tipoPlantilla, solicitudJson, userSession, sucursalSession, jsonCotizacion, jsonOferta){		 		
				tipoPlantilla = (tipoPlantilla == 2 && $rootScope.solicitudJson.aceptaConsultaBuro == 1)?3:tipoPlantilla;
				
				var x = {
	 				"capacidadPago": (jsonCotizacion != undefined)?jsonCotizacion.capacidadePago:jsonOferta.capacidadePago,
	 				"clienteUnico": (solicitudJson.cotizacion.clientes[0].clienteUnico === "")?"0-0-0-0":solicitudJson.cotizacion.clientes[0].clienteUnico,
	 				"empleado": userSession.noEmpleado,
	 				"pais": sucursalSession.idPais,
	 				"canal": sucursalSession.idCanal,
	 				"sucursal": sucursalSession.idSucursal,
					"cotizacion": {
						"folio": "",
						"fecha": "",
						"datoDeEnvio": "",
						"idSolicitud": solicitudJson.idSolicitud,
						"sucursal": sucursalSession.idSucursal,
						"tipoOferta": tipoPlantilla,
						"canalEnvio": 1,
						"montoSolicitado": (jsonCotizacion != undefined)?jsonCotizacion.monto:jsonOferta.monto,
						"plazoSolicitado": (jsonCotizacion != undefined)?jsonCotizacion.plazo:jsonOferta.plazo,
						"periodicidad": (jsonCotizacion != undefined)?jsonCotizacion.idPeriodicidad:jsonOferta.idPeriodicidad,
						"producto": (jsonCotizacion != undefined)?jsonCotizacion.producto:jsonOferta.producto,
						"sku": (jsonCotizacion != undefined)?jsonCotizacion.sku:jsonOferta.sku,
						"abonoNormalSolicitado": (jsonCotizacion != undefined)?jsonCotizacion.pNormal:jsonOferta.pNormal,
						"abonoPuntualSolicitado": (jsonCotizacion != undefined)?jsonCotizacion.pPuntual:jsonOferta.pPuntual,
						"montoMaximo": (jsonOferta != undefined)?jsonOferta.montoMax:0.0,
						"plazoMaximo": (jsonOferta != undefined)?jsonOferta.plazoMax:"0",
						"abonoNormalMaximo": (jsonOferta != undefined)?jsonOferta.pNormalMax:0.0,
						"abonoPuntualMaximo":(jsonOferta != undefined)?jsonOferta.pPuntualMax:0.0,
						"folioCotizacion": ""
					}
		 		}
		 		
		 		$rootScope.waitLoaderStatus = LOADER_SHOW;
		 		solicitudService.obtenerDatosTicket(x, "CYEE").then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jResponse = JSON.parse(data.data.respuesta);
							
							if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								
								/**
								 * Se preparan las variables que estaran dentro de los tickets
								 **/
								var nombreCliente = ((solicitudJson.cotizacion.clientes[0].nombre==undefined)?"":solicitudJson.cotizacion.clientes[0].nombre)+" "+((solicitudJson.cotizacion.clientes[0].apellidoPaterno==undefined)?"":solicitudJson.cotizacion.clientes[0].apellidoPaterno)+" "+((solicitudJson.cotizacion.clientes[0].apellidoMaterno==undefined)?"":solicitudJson.cotizacion.clientes[0].apellidoMaterno);
						 		var cuCliente = solicitudJson.cotizacion.clientes[0].clienteUnico;
								var vendedor = userSession.nombre+" "+userSession.apellidoPaterno+" "+userSession.apellidoMaterno;
								var tienda = sucursalSession.idSucursal+" "+sucursalSession.nombreSucursal;
								var entidad = (($rootScope.sucursalSession.estado=="Distrito Federal")?"Ciudad de Mexico":$rootScope.sucursalSession.estado).toUpperCase();
								var fechayHora = new Date().toLocaleDateString() + " " + new Date().toLocaleTimeString();
								var fechaOnly = new Date().toLocaleDateString();
								var descripcion = "Prestamo Personal";
								
								var diaActual = (new Date().getUTCDate());
						 		var mesActual = ((((new Date().getMonth()+1)+"").length == 1)?("0"+(new Date().getMonth()+1)):(new Date().getMonth()+1));
						 		var mesActualNum = ((((new Date().getMonth()+1)+"").length == 1)?("0"+(new Date().getMonth()+1)):(new Date().getMonth()+1));
						 		var anioActual = (new Date().getFullYear());
						 		
						 		var entradaCarta = {};
						 		var entradaTicket = {}
						 		
						 		/**
						 		 * Se valida el mes para convertirlo a cadena.
						 		 **/
						 		switch (mesActual){
						 			case "01":
						 				mesActual = "Enero";
						 				break;
						 			case "02":
						 				mesActual = "Febrero";
						 				break;
						 			case "03":
						 				mesActual = "Marzo";
						 				break;
						 			case "04":
						 				mesActual = "Abril";
						 				break;
						 			case "05":
						 				mesActual = "Mayo";
						 				break;
						 			case "06":
						 				mesActual = "Junio";
						 				break;
						 			case "07":
						 				mesActual = "Julio";
						 				break;
						 			case "08":
						 				mesActual = "Agosto";
						 				break;
						 			case "09":
						 				mesActual = "Septiembre";
						 				break;
						 			case "10":
						 				mesActual = "Octubre";
						 				break;
						 			case "11":
						 				mesActual = "Noviembre";
						 				break;
						 			case "12":
						 				mesActual = "Diciembre";
						 				break;
						 		}
					 			
					 			/**
					 			 * Esta plantilla se ocupa solo en la cotización.
					 			 **/
					 			var plantillaCotizacion = (jsonCotizacion != undefined)?
					 				"<TICKET>" +
					 				"<IMG PATH='C:\\ADN\\ArqWebView\\Sandbox\\OfflineWebApps\\Credito\\webapp\\images\\banco.jpg' POSX='20' POSY='0' WIDTH='30' HEIGHT='20' LANSCAPE='H'></IMG>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='15' FONTTYPE='B'>PRESUPUESTO</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='14' FONTTYPE='B'>PRESTAMOS PERSONALES</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<BOX HEIGHT='7' BORDERWIDTH='0.5'></BOX>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>INFORMACION GENERAL</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TABLE>" +
					 					"<ROW>" +
					 						"<HEADER ALIGN='LEFT' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Asesor de Credito:</HEADER>" +
					 						"<HEADER ALIGN='LEFT' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>"+vendedor+"</HEADER>" +
					 					"</ROW>" +
					 					"<ROW>" +
					 						"<CELL ALIGN='LEFT' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Tienda:</CELL>" +
					 						"<CELL ALIGN='LEFT' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>"+tienda+"</CELL>" +
					 					"</ROW>" +
					 					"<ROW>" +
					 						"<CELL ALIGN='LEFT' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Fecha presupuesto:</CELL>" +
					 						"<CELL ALIGN='LEFT' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>"+fechayHora+"</CELL>" +
					 					"</ROW>" +
					 					"<ROW>" +
					 						"<CELL ALIGN='LEFT' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Valido hasta:</CELL>" +
					 						"<CELL ALIGN='LEFT' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>"+fechaOnly+"</CELL>" +
					 					"</ROW>" +
					 				"</TABLE>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<BOX HEIGHT='7' BORDERWIDTH='0.5'></BOX>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>CREDITO PERSONAL SOLICITADO*</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='14' FONTTYPE='B'> $"+jsonCotizacion.monto.toLocaleString().replace(".",",")+"</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='8'>A pagar en:</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='12' FONTTYPE='B'>"+jsonCotizacion.plazo+" semanas de $"+jsonCotizacion.pNormal+"</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='8'>Con tu beneficio de pago puntual: $"+jsonCotizacion.pPuntual+" semanales</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>SIN COMPROBANTE DE INGRESOS!</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='6' FONTTYPE='B'>SOLO IDENTIFICACION OFICIAL INE / IFE O PASAPORTE!</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>Si tu identificacion no  coincide  con  el domicilio actual</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>deberas presentar un Comprobante  de  Domicilio  no mayor</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>a 3 meses</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='10' FONTTYPE='B'>PAGA MENOS!</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>Pagando puntual, anticipando pagos o abonando a capital,</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>para mas informacion consulta a tu asesor.</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>Puedes realizar tus pagos en cualquier sucursal de Banco</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>Azteca, Chedraui, Telecomm o mediante la App digital</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<BOX HEIGHT='0.3' BORDERWIDTH='0.1'></BOX>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='7'>La presente cotizacion es de caracter informativo.</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='7'>*  La  autorizacion   esta  sujeta  a  cumplir  requisitos  de</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='7'>contratacion. CREDIMAX (Credito Personal) es un producto</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='7'>de  Banco   Azteca,  S.A.,   Institucion   de  Banca  Multiple. </TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='7'>Consulta    requisitos,   tasas,    comisiones,   terminos   y</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='7'>condiciones   de   contratacion   en   tu   sucursal  o  visita</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='7'>www.bancoazteca.com.mx</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Al Pago  Puntual,  aplica  una  Tasa Global</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Anual  Fija  del  "+jResponse.data.tasaGlobalAnual+"  sin  IVA,  con  un</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>CAT  (Costo anual Total)  del  "+jResponse.data.cat+"  sin</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>IVA.</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Al  Pago  Normal,  aplica  una Tasa  Global</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Anual  Fija  del  "+jResponse.data.tasaGlobalAnualNormal+"  sin IVA,  con  un</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>CAT  (Costo Anual Total) del  "+jResponse.data.catNormal+"  sin</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>IVA.</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<IMG PATH='C:\\ADN\\ArqWebView\\Sandbox\\OfflineWebApps\\Credito\\webapp\\images\\cbimage.jpg' POSX='20' POSY='0' WIDTH='30' HEIGHT='20' LANSCAPE='H'></IMG>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='TAHOMA' FONTSIZE='7' FONTTYPE='B'>Ademas de tu credito, Pide tu Tarjeta Azteca!, con ella</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='TAHOMA' FONTSIZE='7' FONTTYPE='B'>podras   comprar   donde   sea   a   comodos   pagos</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='TAHOMA' FONTSIZE='7' FONTTYPE='B'>semanales.</TEXT>" +
					 			"</TICKET>":"";

					 			/**
					 			 * Dependiendo del tipo de oferta es la leyenda que se muestra
					 			 * El primero es para Rescate
					 			 * El segundo es para Verificación.
					 			 **/
					 			var tipoInfoCliente = "";
					 			if($rootScope.sinObligadoSolidario || $rootScope.rescatePPGarantias || $rootScope.rescatePPObligado || $rootScope.requiereObligado || $rootScope.rescatePP || $rootScope.rescatePPFaseI || $rootScope.rescatePPFaseII || $rootScope.prestamoGarantias || $rootScope.rescateFaseIII || $rootScope.recuperaSolicitudBuro){
					 				tipoInfoCliente = "<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>IMPORTANTE</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>La aprobacion del credito esta sujeta al resultado</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>de la visita en su domicilio y de la validacion de</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>Co-acreditado o Garantias</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>";
					 			}else if(generalService.masterFunction($rootScope.solicitudJson)){
					 				tipoInfoCliente = "<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>IMPORTANTE</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>La aprobacion del credito esta sujeta al resultado</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>de la visita en su domicilio</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>";
					 			}
					 			
					 			/**
					 			 * Esta plantilla se ocupa en las ofertas del crédito.
					 			 **/
					 			var plantillaOferta = (jsonOferta != undefined)?
					 				"<TICKET>" +
					 				"<IMG PATH='C:\\ADN\\ArqWebView\\Sandbox\\OfflineWebApps\\Credito\\webapp\\images\\banco.jpg' POSX='20' POSY='0' WIDTH='30' HEIGHT='20' LANSCAPE='H'></IMG>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='15' FONTTYPE='B'>PRESUPUESTO</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='14' FONTTYPE='B'>PRESTAMOS PERSONALES</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<BOX HEIGHT='7' BORDERWIDTH='0.5'></BOX>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>INFORMACION GENERAL</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TABLE>" +
					 					"<ROW>" +
					 						"<HEADER ALIGN='LEFT' FONTTYPE='B'>Nombre:</HEADER>" +
					 						"<HEADER ALIGN='LEFT' FONTTYPE='B'>"+nombreCliente+"</HEADER>" +
					 					"</ROW>" +
					 					"<ROW>" +
					 						"<CELL ALIGN='LEFT' FONTTYPE='B'>No. Cliente Unico:</CELL>" +
					 						"<CELL ALIGN='LEFT' FONTTYPE='B'>"+cuCliente+"</CELL>" +
					 					"</ROW>" +
					 					"<ROW>" +
					 						"<CELL ALIGN='LEFT'>Asesor de Credito:</CELL>" +
					 						"<CELL ALIGN='LEFT'>"+vendedor+"</CELL>" +
					 					"</ROW>" +
					 					"<ROW>" +
					 						"<CELL ALIGN='LEFT'>Tienda:</CELL>" +
					 						"<CELL ALIGN='LEFT'>"+tienda+"</CELL>" +
					 					"</ROW>" +
					 					"<ROW>" +
					 						"<CELL ALIGN='LEFT'>Fecha presupuesto:</CELL>" +
					 						"<CELL ALIGN='LEFT'>"+fechayHora+"</CELL>" +
					 					"</ROW>" +
					 					"<ROW>" +
					 						"<CELL ALIGN='LEFT'>Valido hasta:</CELL>" +
					 						"<CELL ALIGN='LEFT'>"+fechaOnly+"</CELL>" +
					 					"</ROW>" +
					 				"</TABLE>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<BOX HEIGHT='7' BORDERWIDTH='0.5'></BOX>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>CREDITO PERSONAL AUTORIZADO*</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TABLE>" +
					 					"<ROW>" +
					 						"<HEADER ALIGN='LEFT' FONTFAMILY='Tahoma' FONTSIZE='7' FONTTYPE='B'>SOLICITADO                 :</HEADER>" +
					 						"<HEADER ALIGN='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7' FONTTYPE='B'> </HEADER>" +
					 						"<HEADER ALIGN='LEFT' FONTFAMILY='Tahoma' FONTSIZE='7' FONTTYPE='B'>|            MAXIMO AUTORIZADO</HEADER>" +
					 					"</ROW>" +
					 					"<ROW>" +
					 						"<CELL ALIGN='LEFT' FONTTYPE='B'>$"+jsonOferta.monto+"</CELL>" +
					 						"<CELL ALIGN='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7' FONTTYPE='B'> </CELL>" +
					 						"<CELL ALIGN='LEFT' FONTTYPE='B'>|            $"+jsonOferta.montoMax+"</CELL>" +
					 					"</ROW>" +
					 					"<ROW>" +
					 						"<CELL ALIGN='LEFT' FONTTYPE='B'>A pagar en:</CELL>" +
					 						"<CELL ALIGN='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7' FONTTYPE='B'> </CELL>" +
					 						"<CELL ALIGN='LEFT' FONTTYPE='B'>|            A pagar en:</CELL>" +
					 					"</ROW>" +
					 					"<ROW>" +
					 						"<CELL ALIGN='LEFT' FONTTYPE='B'>"+jsonOferta.plazo+" semanas de $"+jsonOferta.pNormal+"</CELL>" +
					 						"<CELL ALIGN='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7' FONTTYPE='B'> </CELL>" +
					 						"<CELL ALIGN='LEFT' FONTTYPE='B'>|            "+jsonOferta.plazoMax+" semanas de $"+jsonOferta.pNormalMax+"</CELL>" +
					 					"</ROW>" +
					 					"<ROW>" +
					 						"<CELL ALIGN='LEFT' FONTTYPE='B'>Con tu beneficio de pago</CELL>" +
					 						"<CELL ALIGN='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7' FONTTYPE='B'> </CELL>" +
					 						"<CELL ALIGN='LEFT' FONTTYPE='B'>|            Con tu beneficio de pago</CELL>" +
					 					"</ROW>" +
					 					"<ROW>" +
					 						"<CELL ALIGN='LEFT' FONTTYPE='B'>puntual: $"+jsonOferta.pPuntual+" semanales</CELL>" +
					 						"<CELL ALIGN='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7' FONTTYPE='B'> </CELL>" +
					 						"<CELL ALIGN='LEFT' FONTTYPE='B'>|            puntual: $"+jsonOferta.pPuntualMax+" semanales</CELL>" +
					 					"</ROW>" +
					 				"</TABLE>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>SIN COMPROBANTE DE INGRESOS!</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='6' FONTTYPE='B'>SOLO IDENTIFICACION OFICIAL INE / IFE O PASAPORTE!</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>Si tu identificacion no  coincide  con  el domicilio actual</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>deberas presentar un Comprobante  de  Domicilio  no mayor</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>a 3 meses</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='10' FONTTYPE='B'>PAGA MENOS!</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>Pagando puntual, anticipando pagos o abonando a capital,</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>para mas informacion consulta a tu asesor.</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>Puedes realizar tus pagos en cualquier sucursal de Banco</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='7'>Azteca, Chedraui, Telecomm o mediante la App digital</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<BOX HEIGHT='0.3' BORDERWIDTH='0.1'></BOX>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='7'>La presente cotizacion es de caracter informativo.</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='7'>*  La  autorizacion   esta  sujeta  a  cumplir  requisitos  de</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='7'>contratacion. CREDIMAX (Credito Personal) es un producto</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='7'>de  Banco   Azteca,  S.A.,   Institucion   de  Banca  Multiple. </TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='7'>Consulta    requisitos,   tasas,    comisiones,   terminos   y</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='7'>condiciones   de   contratacion   en   tu   sucursal  o  visita</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='7'>www.bancoazteca.com.mx</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Al Pago  Puntual,  aplica  una  Tasa Global</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Anual  Fija  del  "+jResponse.data.tasaGlobalAnual+"  sin  IVA,  con  un</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>CAT  (Costo anual Total)  del  "+jResponse.data.cat+"  sin</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>IVA.</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Al  Pago  Normal,  aplica  una Tasa  Global</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Anual  Fija  del  "+jResponse.data.tasaGlobalAnualNormal+"  sin IVA,  con  un</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>CAT  (Costo Anual Total) del  "+jResponse.data.catNormal+"  sin</TEXT>" +
					 				"<TEXT ALIGNH='JUSTIFY' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>IVA.</TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<IMG PATH='C:\\ADN\\ArqWebView\\Sandbox\\OfflineWebApps\\Credito\\webapp\\images\\cbimage.jpg' POSX='20' POSY='0' WIDTH='30' HEIGHT='20' LANSCAPE='H'></IMG>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT></TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='TAHOMA' FONTSIZE='7' FONTTYPE='B'>Ademas de tu credito, Pide tu Tarjeta Azteca!, con ella</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='TAHOMA' FONTSIZE='7' FONTTYPE='B'>podras   comprar   donde   sea   a   comodos   pagos</TEXT>" +
					 				"<TEXT ALIGNH='CENTER' FONTFAMILY='TAHOMA' FONTSIZE='7' FONTTYPE='B'>semanales.</TEXT>" +
					 			"</TICKET>":"";
					 			
					 			/**
					 			 * Se prepara la entrada para determinar que tickey se va a imprimir.
					 			 **/
					 			entradaTicket.ListaTickets = [
				 					{
				 						"Aplicacion": "MOC",
				 						"Contenido": (tipoPlantilla==1)?plantillaCotizacion:plantillaOferta,
				 						"NoCopias": 1
				 					}
				 				]

						 		var entrada  = entradaTicket;
						 		
						 		$rootScope.imprimir('moduloTracker', 'printResponse', entrada, false);
	 	
							}else{
								$rootScope.message("AVISO ", ["Error al realizar la impresión de ticket, por favor reintente nuevamente."],"Aceptar",null,"bgRojo", "rojoR");
							}
						}else{
							$rootScope.message("AVISO ", ["Ocurrió un inconveniente, por favor intente nuevamente."],"Aceptar",null,"bgRojo", "rojoR");
						}						
					}, function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE; 
						$rootScope.message("AVISO", [ ERROR_SERVICE, "Ocurrió un inconveniente, por favor intente nuevamente."],"Aceptar",null,"bgRojo", "rojoR");	
					}
				);
			}
			
			function obtieneCadenasImprimir(mensaje, numSaltos){
				var longMax = numSaltos;
				var inicioCadena = 0;
				var cadenaFinal = [];
				
				for(var i=0;i<mensaje.length;i++){
					if(i == longMax){
						for(var j=i;j>=0;j--){
							if(mensaje[j] == " "){
								cadenaFinal.push(mensaje.substring(inicioCadena, j));
								inicioCadena = j+1;
								longMax = j+numSaltos;
								break;
							}
						}
					}else if(i == mensaje.length - 1){
						cadenaFinal.push(mensaje.substring(inicioCadena, mensaje.length));
					}
				}
				
				return cadenaFinal;
			}

			$rootScope.plantillaImpresionSurtimiento = function(jsonEntrada){
				if(jsonEntrada != undefined && jsonEntrada != ""){
					var entradaTicket = {};
	
		 			/**
		 			 * Esta plantilla se ocupa en las ofertas del crédito.
		 			 **/
		 			var plantillaTicketSurtimiento = 
		 				"<TICKET>" +
		 				"<IMG PATH='C:\\ADN\\ArqWebView\\Sandbox\\OfflineWebApps\\Credito\\webapp\\images\\banco.jpg' POSX='14' POSY='0' WIDTH='40' HEIGHT='30' LANSCAPE='H'></IMG>" +
		 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='15' FONTTYPE='B'>Felices Fiestas!</TEXT>" +
		 				"<TEXT></TEXT>";
		 			
		 			var arregloNombres = obtieneCadenasImprimir(jsonEntrada.nombre,21); 
		 			for(var i=0;i<arregloNombres.length;i++){
		 				if(i == 0){
		 					plantillaTicketSurtimiento = plantillaTicketSurtimiento + "<TEXT ALIGNH='LEFT' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Nombre: "+arregloNombres[i]+"</TEXT>";
		 				}else{
		 					plantillaTicketSurtimiento = plantillaTicketSurtimiento + "<TEXT ALIGNH='LEFT' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>"+arregloNombres[i]+"</TEXT>";
		 				}
		 			}
		 			
		 			plantillaTicketSurtimiento = plantillaTicketSurtimiento +
		 				"<TEXT ALIGNH='LEFT' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Cliente Unico: "+jsonEntrada.clienteUnicoCliente+"</TEXT>" +
		 				"<TEXT ALIGNH='LEFT' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Pedido: "+jsonEntrada.noPedido+"</TEXT>";
		 			
		 			if(jsonEntrada.folioPromo != undefined && jsonEntrada.folioPromo != ""){
		 				plantillaTicketSurtimiento = plantillaTicketSurtimiento +
		 					"<TEXT ALIGNH='LEFT' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>Folio: "+jsonEntrada.folioPromo+"</TEXT>";
		 			}
		 			
		 			plantillaTicketSurtimiento = plantillaTicketSurtimiento +
		 				"<TEXT></TEXT>" +
		 				"<TEXT></TEXT>";
		 				
		 			var arregloMensajes = obtieneCadenasImprimir(jsonEntrada.mensajeTicket,28); 
		 			for(var i=0;i<arregloMensajes.length;i++){
		 				plantillaTicketSurtimiento = plantillaTicketSurtimiento + "<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='9' FONTTYPE='B'>"+arregloMensajes[i]+"</TEXT>";
		 			}
		 				
		 				
	 				plantillaTicketSurtimiento = plantillaTicketSurtimiento + 
	 					"<TEXT></TEXT>" +
		 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='6' FONTTYPE='B'>Ademas participas en el gran concurso por $50,000.</TEXT>" +
		 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='6' FONTTYPE='B'>Permiso DGRT/1914/2019</TEXT>" +
		 				"<TEXT ALIGNH='CENTER' FONTFAMILY='Tahoma' FONTSIZE='6' FONTTYPE='B'>Terminos y condiciones en www.bancoazteca.com.mx</TEXT>" +
		 				"<TEXT></TEXT>" +
		 				"<TEXT></TEXT>" +
		 			"</TICKET>";
		 			
		 			
		 			
		 			/**
		 			 * Se prepara la entrada para determinar que tickey se va a imprimir.
		 			 **/
		 			entradaTicket.ListaTickets = [
	 					{
	 						"Aplicacion": "MOC",
	 						"Contenido": plantillaTicketSurtimiento,
	 						"NoCopias": 1
	 					}
	 				]
	
			 		var entrada  = entradaTicket;
			 		
			 		$rootScope.imprimir('moduloTracker', 'printResponse', entrada, false);
				}else{
					$rootScope.message("AVISO ", ["Parámetros inválidos, por favor verifique los datos de entrada."],"Aceptar",null,"bgAzul", "azul");
				}
			}
			
			function validarEnvioFirmas(_path){
				if($rootScope.isFirmaUnica && $rootScope.consultaFuncionalidad.flujoFirmaUnicaHabilitado){
					marcarSolFirmaUnica(_path);
				}else if(!generalService.isEmpty($rootScope.imgPrivacidad)){
					var avisoEnviado = false;
					$rootScope.SendSignOnLine(avisoEnviado, _path);
				}else if(!generalService.isEmpty($rootScope.imgBuro)){
					avisoEnviado = true;
					$rootScope.SendSignOnLine(avisoEnviado, _path);
				}else if(_path != null){
					generalService.locationPath(_path);
				}
			};
			
			$rootScope.enviarIdentificacion = function(_path, tipoFormato){
				
				if($rootScope.digiDocIdOf != null && typeof $rootScope.digiDocIdOf != 'undefined'){
					if (typeof tipoFormato === 'undefined') {
						tipoFormato = $rootScope.digiDocIdOf.formato || 'jpg';
					}
					
					var arregloDocumentos = [];
					for(var j=0;j<2;j++){
						arregloDocumentos.push({idDocumento:1,documento:$rootScope.digiDocIdOf.imagenes[j],formatoImagen:tipoFormato});
					}
					envioDocumentosEnLinea(arregloDocumentos, 0, _path, tipoFormato);
				}else {
					validarEnvioFirmas(_path);
				}
				
			};
			
			
			$rootScope.generarDocsOs = function(){
				var solicitudOSJsonString = generalServiceOS.delete$$hashKey( $rootScope.solicitudOSJson );
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				obligadoSolidarioService.guardaSeccionOS( { solicitudOSJson: solicitudOSJsonString, seccion: 7 } ).then(
						function(data){			
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								if(data.data.respuesta != undefined){
									var jResponse = JSON.parse(data.data.respuesta);
									
									if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
										$rootScope.solicitudOSJson = jResponse.data;
										generalService.locationPath("/ochoPasos");
									}else {
										$rootScope.message("Aviso", ["Error inesperado, al validar los documentos."], "Aceptar", "/simulador", "bgAzul", "azul");
									}
								}else{
									$rootScope.message("Aviso", ["No se obtuvo una respuesta al validar los documentos. Favor de volver" +
											"a intentar"], "Aceptar", "/simulador", "bgAzul", "azul");
								}
								
							}else
								$rootScope.message("Aviso", ["Error en la respuesta del servicio para validar los documento(s)." +
										" Por favor, reintente nuevamente."], "Aceptar", "/simulador", "bgAzul", "azul");
								
							
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE;
			                $rootScope.message("Aviso", ["Servicio no disponible para generar los documentos" +
			                		"del Coacreditado"], "Aceptar", "/simulador", "bgAzul", "azul");
							
						}
					);
			};
			
			$rootScope.ejecutaBuro = function(){
				$rootScope.recuperaSolicitudBuro=false;
				$rootScope.paginaActual="ochoPasos";
				buroService.consultaBuro( null, null,null, null, null, 1, null );
			};

			$rootScope.ejecutarPortalCaptacion = function(idPais,idCanal,idSucursal,idSolicitud,idSeguimiento){
				var requestJson = {
									idPais: idPais,
									idCanal: idCanal,
									idSucursal: idSucursal,
									idSolicitud: idSolicitud,
									motivo: 0,
									reintentar: 1,
									numeroIntentos: $rootScope.aperturaCaptacion.numeroIntentos+1,
									porcentaje: 0,
									respuesta: "",
									tipoServicio : 2,
									idEmpleado : $rootScope.userSession.noEmpleado
								}; 
				
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				solicitudService.guardarSeccionGuardadito(requestJson,PROCESOS.PSC ).then(
						function(data) {
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var j = JSON.parse(data.data.respuesta);							
								if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									requestJson["idSeguimiento"] = idSeguimiento;
									$rootScope.guardaDatosIpad("AperturaGuardadito",JSON.stringify(requestJson));
									
//									Aquí se manda abrir el portal de captación
									/*\Se agregan eventos para la bitacora\*/
									$rootScope.addEvent( BITACORA.SECCION.surtimiento.id, BITACORA.SUBSECCION.aperturaGuardadito.id, BITACORA.ACCION.proceso.id, 0, BITACORA.SECCION.surtimiento.guardarEnBD );								
									/*\Se agregan eventos para la bitacora\*/
									//Se mandan a BD los eventos almacenados en memoria
									$rootScope.enviaEventos();
									
									if(configuracion.so.windows){
										window.location.assign(PORTAL_CAPTACION+'#/Externos=5' + idSolicitud);
									}else{
										$rootScope.executeAction( "surtimiento", "respuestaCaptacion", {nombre:"reLoadWebViewCaptacion"} );
									}
								}else{
									$rootScope.message("Nueva Originación Centralizada",["Inconveniente al aperturar portal Captación.", "Favor de volver a intentarlo."],"Aceptar","/simulador");
								}
							}
						}, function(error) {
							$rootScope.message("Nueva Originación Centralizada",["Inconveniente al aperturar portal Captación.", "Favor de volver a intentarlo."],"Aceptar","/simulador");
							$rootScope.waitLoaderStatus = LOADER_HIDE;
						}
					);
			};
			
			$rootScope.armaJsonCotizacion = function(){
				$rootScope.JsonCotizacion = { idSolicitud: $rootScope.solicitudJson.idSolicitud,
											  folio: "",
											  tipoOferta: 0,
											  fecha: "",
											  sucursal: $rootScope.solicitudJson.idSucursal,
											  canalEnvio: "",
											  datoDeEnvio: "",
											  montoSolicitado: 0,
											  plazoSolicitado: "",
											  periodicidad: "",
											  producto: $rootScope.solicitudJson.idProducto,
											  sku: "",
											  abonoNormalSolicitado: 0,
											  abonoPuntualSolicitado: 0,
											  montoMaximo: 0,
											  plazoMaximo: "",
											  abonoNormalMaximo: 0,
											  abonoPuntualMaximo: 0,
						   					};
			};
			
		$rootScope.MostrarOfertas = function(){
		    	$scope.quickFixes=true;
	    		if( $rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.verificacionCambaceo || 
	    			$rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.rescateCambaceo || 
	    			$rootScope.solicitudJson.marca == STATUS_SOLICITUD.preautorizada.marca.inmediatoCambaceo ){
	    				modalService.cambaceoModal("Alternativa de Crédito", null ).then(  function(exito){},function(error){});
	    		}else
	    			validacionesOferta();
	    }
	    
	    var validacionesOferta = function(){
	    		if(generalService.validarMostarTermometro($rootScope.solicitudJson)){
	    			if( generalService.validaConsultaBuro( $rootScope.solicitudJson )){
	    					if($rootScope.termometroHandler == BURO_RESPUESTAWS_OK){
	    						if( ($rootScope.onceOfert && $rootScope.solicitudJson.banderaOfertaCP == 0 ) || $rootScope.mostrarOfertaCotizador ){						
	    							$rootScope.onceOfert = false;
	    							$rootScope.mostrarOfertaCotizador = false;
	    							$scope.muestraModalCotizador();
	    						}
	    					}
	    			}
	    		}else if($rootScope.termometroHandler == BURO_RESPUESTAWS_OK &&  generalService.isCanalExterno($rootScope.sucursalSession.idCanal))
 				$rootScope.message("Aviso ",["Se Ocurrió un problema favor de comunicarse con soporte"], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
	    }
	    
	    $scope.muestraModalCotizador=function(){
		     if($rootScope.campanasPreaprobadosCaptacion($rootScope.solicitudJson.campana) && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal){
		    	 	ofertaTarjetasSIPAyPREAPROB();
		     	}else if($rootScope.campanaNvoPreaprob($rootScope.solicitudJson.campana)){
			  		$scope.nvoPreaprobados();
  			 	}/*Inicia bloque que evaluar si es Rescate\*/
		     	else if(generalService.esCandidatoRescateItalika($rootScope.solicitudJson.marca)){
		    		$scope.rescateItalika();
		    	}else if(generalService.esCandidatoRescateTelefonia($rootScope.solicitudJson.marca)){
		    			$scope.rescateTelefonia();
		    	}else if(generalService.esCandidatoRescateConsumo($rootScope.solicitudJson.marca)){
		    			$scope.rescateConsumo();
		     	}else if(generalService.esCandidatoRescatePrestamoFaseII($rootScope.solicitudJson.marca)){
		     			if($rootScope.solicitudJson.banderaOfertaCP == 0)
		     				$scope.rescatePrestamoFaseII();
				}else if(generalService.esCandidatoRescatePrestamo($rootScope.solicitudJson.marca)){
					if($rootScope.solicitudJson.banderaOfertaCP == 0){
	  					$scope.rescatePrestamo();
					}
				}else if($rootScope.rescateFaseIII){
						if($rootScope.solicitudJson.banderaOfertaCP == 0){
							switch($rootScope.solicitudJson.idProducto){
								case PRODUCTOS.consumo.ID.valor:
									$scope.rescateConsumoFaseIII();
									break;
								case PRODUCTOS.italika.ID.valor:
									$scope.rescateItalikaFaseIII();
									break;
								case PRODUCTOS.telefonia.ID.valor:
									$scope.rescateTelefoniaFaseIII();
									break;
								default:
									generalService.buildSolicitudJson($rootScope, null);
									$rootScope.message("Error ",["No es posible otorgar Rescate"], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
							}
						}
				}else if( generalService.esCandidatoRescateCreditoEnEfectivo($rootScope.solicitudJson.marca, $scope.esRescate) )
						rescateCreditoEnEfectivo();
		     	/*Finaliza bloque que evaluar si es Rescate\*/
		     	else {
		     		/*Inicia bloque que evalua las condiciones del flujo Normal\*/
		     		if(!$rootScope.rescatePPGarantias && !$rootScope.rescatePPObligado)
		     			ofertaFlujoClienteNuevo();
		     		/*Finaliza bloque que evalua las condiciones del flujo Normal\*/
		     	}
		};	 	
	 		 	
	 	var ofertaTarjetasSIPAyPREAPROB = function () {
	     	modalService.tarjetaModal("Cotizador", "bgAzul",$scope).then(
	    		function(estatus) {
	    			generalService.locationPath("/ochoPasos");
	    		}, function(exito) {
	    			if(exito){
	    				/* Se redirige a los ocho pasos para que se muestre el botón de volver a cotizar*/
	    				generalService.locationPath("/ochoPasos");
	    			}else{
	    				$scope.rechazarOferta();
	    			}
	    		}
	    	);};
	    	
	    	$scope.rechazarOferta = function(){
	    		//I - MODIFICACION PARA CLIENTES PRE APROBADOS CAPTACION
	    		var mensaje = "¿Estás seguro de que el Cliente no Acepta ";
	    		mensaje += $rootScope.solicitudJson.idProducto==PRODUCTOS.prestamoPersonal.ID.valor?"el Prestamo Personal?":"la Tarjeta de Crédito?";
	    		//F - MODIFICACION PARA CLIENTES PRE APROBADOS CAPTACION
	    		modalService.confirmModal("Notificación",[mensaje], "Si", "No", "bgAzul", "btn gris", "btn azul" ).then(
	    				function(exito){
	    					$scope.muestraModalCotizador();
	    					},function(error){
	    						console.log("Quemar Folio");
	    						$scope.quemarFolioPreaprobado(false)
	    					}
	    				);
	    		};
	 	
	 	$scope.quemarFolioPreaprobado = function(bandera){
	 		$rootScope.waitLoaderStatus = LOADER_SHOW;
			var cteUco = $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico.split("-");
			var quitarCampana = function (){
				x = {idSolicitud: $rootScope.solicitudJson.idSolicitud};
				solicitudService.quitarCampana( x ).then(
		 			function(data){
		 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
		 					$rootScope.waitLoaderStatus = LOADER_HIDE;
		 					var responseJson = JSON.parse(data.data.respuesta);
		 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
		 						$rootScope.solicitudJson = responseJson.data;
		 						$scope.muestraModalCotizador();
							}else {
								$rootScope.message("Error al rechazar la oferta ",[ $scope.mensajeError], "Aceptar",  "/simulador");
							}
		 				}else{
		 					$rootScope.message("Error",[generalService.displayMessage(data.data.descripcion)], "Aceptar",  "/simulador");
		 				}
		 			}, function(error){                     
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				$rootScope.message("Error al rechazar la oferta ",[ $scope.mensajeError], "Aceptar",  "/simulador");								
		 			}	
				);
			}
			
			var x = {	pais: cteUco[0], canal: cteUco[1], sucursal: cteUco[2], folio: cteUco[3], statusPromo: bandera ? QUEMAR_FOLIO_STATUS.aceptado : QUEMAR_FOLIO_STATUS.rechazado };
			 tarjetaService.quemarFolioPreaprobado(x).then(
						function(data){
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								if(bandera){
									console.log("Folio Quemado con Status de \"Aceptado\" correctamente");
								}else{

									//I - MODIFICACION PARA CLIENTES PRE APROBADOS CAPTACION							
									if($rootScope.productosTarjetas( $rootScope.solicitudJson.idProducto)){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										solicitudService.cancelarSolicitud({idSolicitud:$rootScope.solicitudJson.idSolicitud});
										generalService.cleanRootScope($rootScope);
										generalService.buildSolicitudJson($rootScope, null);
										generalService.locationPath("/simulador");
									}else if($rootScope.campanasPreaprobadosCaptacion($rootScope.solicitudJson.campana)){
										quitarCampana();
									}else if( $rootScope.productosSIPA($rootScope.solicitudJson.idProducto) && $rootScope.campanasSipa($rootScope.solicitudJson.campana) ){
										$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = parseInt($rootScope.solicitudJson.observaciones);
										$rootScope.solicitudJson.consultaBuro = 0;
										$rootScope.solicitudJson.consultaMatriz = 0;
										
										solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($rootScope.solicitudJson), seccion: SECCION_SOLICITUD } ).then(
									 			function(data){
									 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
									 					var responseJson = JSON.parse(data.data.respuesta);
									 					$rootScope.solicitudJson = responseJson.data;
									 					quitarCampana();
									 				}else{
									 				$rootScope.waitLoaderStatus = LOADER_HIDE;
									 					$rootScope.message("AVISO",[data.data.descripcion], "Aceptar",  "/simulador");
									 				}	
									 			}, function(error){                     
									 				$rootScope.waitLoaderStatus = LOADER_HIDE;
									 				$rootScope.message("Aviso ", ["Inconveniente al actualizar la solicitud. Favor de volver a intentar"],"Aceptar", "/simulador");								
									 			}	
											);
									}
								}							
							}else
							$rootScope.message("AVISO",[data.data.descripcion], "Aceptar",  "/simulador");
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 
			                $rootScope.message("AVISO",["Se presentó un problema favor de volver a intentar"], "Aceptar",  "/simulador");
							
						}
					);
	 	}
	 	
	 	$scope.nvoPreaprobados = function(){
	 		if($rootScope.ejecutarEncuentaPreaprobado){
		    	if($rootScope.solicitudJson.idProducto == PRODUCTOS.prestamoPersonal.ID.valor){
		    		modalService.cotizadorPP("Felicidades", null ).then( 
							function(exito){
//								if($rootScope.ejecutarEncuentaPreaprobado){
									modalService.preguntaPreaprobado("Felicidades",null).then( 
											function(exito){
												generalService.locationPath("/ochoPasos",true);
											}, function(error){
												generalService.locationPath("/ochoPasos",true);
											});
//								}else
//									generalService.locationPath("/ochoPasos",true);
							}, function(error){
								modalService.preguntaPreaprobado("Rechazado",null).then( 
										function(exito){
											$rootScope.quemarFolioPreaprobadoNvoPreap(QUEMAR_FOLIO_STATUS_NVOPREAP.rechazado,2);
										}, function(error){
											$rootScope.quemarFolioPreaprobadoNvoPreap(QUEMAR_FOLIO_STATUS_NVOPREAP.rechazado,2);
										});
								
					});
		    	}else if($rootScope.solicitudJson.idProducto == PRODUCTOS.consumo.ID.valor || $rootScope.solicitudJson.idProducto == PRODUCTOS.italika.ID.valor ||
		    			 $rootScope.solicitudJson.idProducto == PRODUCTOS.telefonia.ID.valor || $rootScope.solicitudJson.idProducto == PRODUCTOS.tarjetaAzteca.ID.valor){
			    		modalService.preAprobados("Felicidades", null ).then( 
								function(exito){
//									if($rootScope.ejecutarEncuentaPreaprobado){
										modalService.preguntaPreaprobado("Felicidades",null).then( 
												function(exito){
													generalService.locationPath("/ochoPasos",true);
												}, function(error){
													generalService.locationPath("/ochoPasos",true);
												});
//									}else
//										generalService.locationPath("/ochoPasos",true);
								}, function(error){
									modalService.preguntaPreaprobado("Rechazado",null).then( 
											function(exito){
												$rootScope.quemarFolioPreaprobadoNvoPreap(QUEMAR_FOLIO_STATUS_NVOPREAP.rechazado,2);
											}, function(error){
												$rootScope.quemarFolioPreaprobadoNvoPreap(QUEMAR_FOLIO_STATUS_NVOPREAP.rechazado,2);
											});
						});
		    	}
	 		}else
	 			generalService.locationPath("/ochoPasos",true);
	    }
	 	
	    $scope.rescateItalika = function(){
	    	
			if( generalService.esCandidatoRescateItalika($rootScope.solicitudJson.marca) || $scope.respuestaBuro==BURO_CLIENTE_APTO_PARA_PRODUCTO_DE_RESCATE_ITALIKA || 
				$scope.respuestaBuro==BURO_ITALIKA_COLOR_VALIDO_KO || $scope.respuestaBuro==BURO_ITALIKA_ROJO_CON_KO){
				
				modalService.rescateItalikaModal("En Banco Azteca te decimos SÍ", null ).then( 
						function(exito){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							var idSolicitud = $rootScope.solicitudJson.idSolicitud;
							  
							  buroService.actualizarProductoConsumo( idSolicitud ).then(
								function(data){
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									
									if( data.data.codigo != undefined ){
										
										var responseJson = JSON.parse(data.data.respuesta);
										
										if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
											$scope.respuestaBuro = null;
											
											$rootScope.capacidadesPagoProducto = responseJson.data.capacidadesPagoProducto;
											$rootScope.solicitudJson = responseJson.data.solicitud;
											$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO
											$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
											$rootScope.mostrarOfertaCotizador = false;
											$rootScope.onceOfert = true;
											
											if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.clienteAceptoProductoCosumo){
												$rootScope.requiereObligado = true;
												$rootScope.muestraOpcionOS = true;
											}
											$scope.muestraModalCotizador();	
											
										} else{
					    						generalService.cleanRootScope($rootScope);
					    						generalService.buildSolicitudJson($rootScope, null);
											$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
										} 
										
									}else {
										generalService.cleanRootScope($rootScope);
			    							generalService.buildSolicitudJson($rootScope, null);
										$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
									}
									
								}, function(error){
									generalService.cleanRootScope($rootScope);
			    						generalService.buildSolicitudJson($rootScope, null);
									$rootScope.message("Error ",[" Favor de intentar nuevamente se detectó un problema "], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
								}	  
							  );
						}, function(error){
							console.log("Se ejecuta la funsión de rechazo desde el controlador del modal");
				});
			}
	    }
	    
	    /** Producto de Rescate de Telefonia **/
		$scope.rescateTelefonia = function(){
			if( generalService.esCandidatoRescateTelefonia($rootScope.solicitudJson.marca) || $scope.respuestaBuro==BURO_CLIENTE_APT0_PARA_PRODUCTO_DE_RESCATE_TELEFONIA ){
				
				modalService.proResTelefoniaModal("En Banco Azteca te decimos SÍ", null ).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							
							/** Se agrega la marca intermedia **/
							switch($rootScope.opcTelefonia){
								case ENUM_TELEFONIA.SinObligadoSolidarioEngancheMenor: $rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.prodResTelefoniaSinOS;
								break;
								case ENUM_TELEFONIA.ConObligadoSolidario: $rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.prodResTelefoniaConOS;
								break;
								case ENUM_TELEFONIA.SinObligadoSolidarioEngancheMayor: $rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.prodResTelefoniaSinOSSegundaOferta;
								break;
							}
							
							solicitudService.actualizarSolicitud( $rootScope.solicitudJson ).then(
									 function(data){
										 if( data.data.codigo != undefined ){
											 var responseJson = JSON.parse(data.data.respuesta);
											 
											 if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){

													//Consumir el servicio de actualizar producto
													var jsonSolicitud = {
															idSolicitud: $rootScope.solicitudJson.idSolicitud,
															opcion: $rootScope.opcTelefonia
													}
													  
													  buroService.actualizarProductoConsumo( jsonSolicitud ).then(
														function(data){
															$rootScope.waitLoaderStatus = LOADER_HIDE;
															
															if( data.data.codigo != undefined ){
																var responseJson = JSON.parse(data.data.respuesta);
																
																if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
																	
																	$scope.respuestaBuro = null;
																	$rootScope.capacidadesPagoProducto = responseJson.data.capacidadesPagoProducto;
																	$rootScope.solicitudJson = responseJson.data.solicitud;
																	$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO
																	$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
																	$rootScope.mostrarOfertaCotizador = false;
																	$rootScope.onceOfert = true;
																	
																	if( $rootScope.solicitudJson.marca==STATUS_SOLICITUD.generada.marca.clienteAceptoProductoCosumo ){
																		$rootScope.requiereObligado = true;
																		$rootScope.muestraOpcionOS = true;
																	}
																	
																	$scope.muestraModalCotizador();	
																} else{
											    						generalService.cleanRootScope($rootScope);
											    						generalService.buildSolicitudJson($rootScope, null);
																	$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
																} 
																
															}else {
																generalService.cleanRootScope($rootScope);
									    							generalService.buildSolicitudJson($rootScope, null);
																$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
															}
															
														}, function(error){
															generalService.cleanRootScope($rootScope);
									    						generalService.buildSolicitudJson($rootScope, null);
															$rootScope.message("Error ",[" Favor de intentar nuevamente se detectó un problema "], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
														}	  
													  );
													
												} else{
							    						generalService.cleanRootScope($rootScope);
							    						generalService.buildSolicitudJson($rootScope, null);
													$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
												} 
											 
										 }else {
											generalService.cleanRootScope($rootScope);
			    							generalService.buildSolicitudJson($rootScope, null);
											$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
										}
									 }, function(error) {
											generalService.cleanRootScope($rootScope);
					    					generalService.buildSolicitudJson($rootScope, null);
											$rootScope.message("Error ",[" Favor de intentar nuevamente se detectó un problema "], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
									 }
							 );

						}, function(error){
							console.log("Se ejecuta la funsión de rechazo desde el controlador del modal");
						});
			}
	    }
		
		/** Producto de Rescate Consumo **/ 
	    $scope.rescateConsumo = function(){
	    	
		 if( generalService.esCandidatoRescateConsumo($rootScope.solicitudJson.marca) ){
					modalService.rescateConsumoModal("En Banco Azteca te decimos SÍ", $rootScope.solicitudJson.idProducto ).then( 
							function(exito){
								$rootScope.waitLoaderStatus = LOADER_SHOW;
								//Consumir el servicio de actualizar producto
								var idSolicitud = $rootScope.solicitudJson.idSolicitud;
								  
								  buroService.actualizarProductoConsumo( idSolicitud ).then(
									function(data){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										
										if( data.data.codigo != undefined ){
											var responseJson = JSON.parse(data.data.respuesta);
											
											if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
												
												$rootScope.capacidadesPagoProducto = responseJson.data.capacidadesPagoProducto;
												$rootScope.solicitudJson = responseJson.data.solicitud;
												$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO
												$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
												$rootScope.mostrarOfertaCotizador = false;
												$rootScope.onceOfert = true;
												
												if( $rootScope.solicitudJson.marca==STATUS_SOLICITUD.generada.marca.clienteAceptoProductoCosumo ){
													$rootScope.requiereObligado = true;
													$rootScope.muestraOpcionOS = true;
												}
												$scope.muestraModalCotizador();	
												
											} else{
						    						generalService.cleanRootScope($rootScope);
						    						generalService.buildSolicitudJson($rootScope, null);
												$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
											} 
										}else {
											generalService.cleanRootScope($rootScope);
				    							generalService.buildSolicitudJson($rootScope, null);
											$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
										}
									}, function(error){
										generalService.cleanRootScope($rootScope);
				    						generalService.buildSolicitudJson($rootScope, null);
										$rootScope.message("Error ",[" Favor de intentar nuevamente se detectó un problema "], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
									}	  
								  );
							}, function(error){
								console.log("Se ejecuta la funsión de rechazo desde el controlador del modal");
					});
				}
	    }
	    
	    $scope.rescatePrestamoFaseII = function(){			
			
			modalService.rescatePrestamoFaseIIModal("En Banco Azteca le decimos CÓMO SÍ a nuestros clientes", $rootScope.solicitudJson.marca ).then(
				function(estatus) {																												
					console.log("ok");
					generalService.locationPath("/ochoPasos");
				}, function(exito) {
					if(exito){
						generalService.locationPath("/ochoPasos");
					}
				}
			);
	    }
	    
	    /** Producto de Rescate de Prestamo Personal **/
		$scope.rescatePrestamo = function(){
				
				modalService.rescatePrestamoModal("En Banco Azteca te decimos SÍ", $rootScope.solicitudJson.marca ).then(
				function(estatus) {																												
					console.log("ok");
					generalService.locationPath("/ochoPasos");
				}, function(exito) {
					if(exito){
						generalService.locationPath("/ochoPasos");
					}
				});
	    }
		
		$scope.rescateConsumoFaseIII = function(){
			generalService.setArrayValue("21Rescate",null);
			
			modalService.rescateConsumoFaseIIIModal("En Banco Azteca le decimos CÓMO SÍ a nuestros clientes", $rootScope.solicitudJson.idProducto ).then( 
					function(exito){
						generalService.locationPath("/ochoPasos");
					}, function(error){
						generalService.locationPath("/ochoPasos");
			});
		}
		
		$scope.rescateItalikaFaseIII = function(){
			modalService.rescateItalikaFaseIIIModal("En Banco Azteca le decimos CÓMO SÍ a nuestros clientes", null ).then( 
					function(exito){
						generalService.locationPath("/ochoPasos");
					}, function(error){
						generalService.locationPath("/ochoPasos");
			});
	    }
		
		$scope.rescateTelefoniaFaseIII = function(){
			
			modalService.rescateTelefoniaFaseIIIModal("En Banco Azteca le decimos CÓMO SÍ a nuestros clientes", null ).then(
				function(data){
					generalService.locationPath("/ochoPasos");
				}, function(error){
					generalService.locationPath("/ochoPasos");
				});
		}
		
		var rescateCreditoEnEfectivo = function(){			
			$scope.muestraBoton = false;
			$scope.muestraAlertaNuevoBuro=false;
			$scope.muestraMensajeNuevoBuro=false;
			
			modalService.rescateCreditoEnEfectivo("En Banco Azteca le decimos CÓMO SÍ a nuestros clientes", $rootScope.solicitudJson.marca ).then(			
				function(estatus) {																												
					console.log("ok");
					if($rootScope.solicitudJson.idProducto!=ID_PRODUCTO.prestamoPersonal)
						$scope.showResumenMonto = false;
					$scope.calculaCPConsumo();
					$scope.validaEdicionSecciones();
					$scope.buildMenuList();
				}, function(exito) {
					if(exito){
						if($rootScope.solicitudJson.idProducto!=ID_PRODUCTO.prestamoPersonal)
							$scope.showResumenMonto = false;
						$scope.muestraAlertasNuevoCotizador();
						$timeout( loadProgressbar, 0 );
						$scope.calculaCPConsumo();
						$scope.validaEdicionSecciones();
						$scope.buildMenuList();
					}
				}
			);
	    }
		
		var ofertaFlujoClienteNuevo = function () {
	    	 if ( $rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal || $rootScope.solicitudJson.campana == CAMPANAS_REACTIVADOS.winback){
	     		if($rootScope.buroHandler != null && $rootScope.buroHandler.length > 0){
	     			$scope.muestraTermometro = true;
	    			modalService.cotizadorModalML("Cotizador", "bgAzul",$scope).then( 
	    				function(estatus) {																												
	    					console.log("ok");
	    					generalService.locationPath("/ochoPasos");
	    				}, function(exito) {
	    					if(exito){
	    						generalService.locationPath("/ochoPasos");
	    					}
	    				}
	    			);
	    		}else
	    			generalService.locationPath("/ochoPasos");
	     	} else {
				$scope.muestraTermometro = true;
	     		modalService.cotizadorModalMLC("Cotizador", "bgAzul",$scope).then( 
	    			function(estatus) {																												
	    				generalService.locationPath("/ochoPasos");
	    			}, function(exito) {
	    				if(exito){
	    					generalService.locationPath("/ochoPasos");
	    				}
	    			}
	    		);
	     	}
	    }			
			function marcarSolFirmaUnica(_path){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				  var x = {
						  idSolicitud : $rootScope.solicitudJson.idSolicitud,
						  idSeguimiento: STATUS_SOLICITUD.generada.id,
						  marca: STATUS_SOLICITUD.generada.marca.firmaUnica
				  }
				  solicitudService.actualizarSolicitud(x).then(
							function(data){
								 $rootScope.waitLoaderStatus = LOADER_HIDE;
								if(data.data.codigo == RESPONSE_CODIGO_EXITO){
									var responseJson = JSON.parse(data.data.respuesta);	
									if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
										prepararFirmaUnica(_path);
									}else{
										$rootScope.message("Aviso ", ["Error al actualizar la solicitud para el flujo de firma única" +
												", Favor de intentar nuevamente"],"Aceptar",null,null,null,null);
									}
									
								}else{
									$rootScope.message("Aviso ", ["Error en el servicio para actualizar la solicitud para el " +
											"flujo de firma única."],"Aceptar",null,null,null,null);
								}
							}, function(error){
								 $rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message("Aviso ", ["Error del servidor para actualizar la solicitud"],"Aceptar",null,null,null,null);				
							});
			};
			
			function prepararFirmaUnica(_path){
				if (!generalService.isEmpty($rootScope.firmaPrivacidad)){
					var cadenaFirma = $rootScope.firmaPrivacidad.replace("data:image/png;base64,","").trim();
					var biometrico = {
							ruta: null,
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							cadena: cadenaFirma,
							tipoCadena: "firmaAviso",
							porcentaje: 100
					}
					$scope.sendContracts(biometrico, _path);
				}else{
					$rootScope.loggerIpad("La firma del contrato esta vacia", null);
					generalService.locationPath("/ochoPasos");
				}
			};
			
			function guardarFirmaUnicaB(_path, jsonRequest){
				$rootScope.waitLoaderStatus = LOADER_SHOW; 						
				clienteUnicoService.guardarFirmaUnica( jsonRequest ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								if(jsonRequest[0].tipoCadena == "firmaAviso"){
									prepararFirmasB(_path, false);
								}else{
									$rootScope.solicitudJson.contratos.contrato[1].statusFirma = 1;
									generalService.locationPath(_path);
								}
							}else{
								$rootScope.message("Siete Pasos",[ "Error en el servicio para guardar la firma única" ], "Aceptar", "/ochoPasos");
							}
						}else
							$rootScope.message("Siete Pasos",["Error en el servidor para guardar la firma única"], "Aceptar", "/ochoPasos");
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 	                					
					}
				);
			
			};
			
			function prepararFirmasB(_path, firmaAvisoB){
				var jsonRequest = [];
				var timeStamphoraAvisoPrivacidad = $rootScope.responseFirmaUnica.horaAvisoPrivacidad;
				var timeStampTratamiento = $rootScope.timeStampTratamiento;
				var timeStampTransferencia = $rootScope.timeStampTransferencia;
				var timeStampBuro = $rootScope.responseFirmaUnica.horaBuroCredito;
				if(firmaAvisoB){
					jsonRequest = [
					                   {
											idSolicitud: $rootScope.solicitudJson.idSolicitud,
											numFirmas: 1,
											timeStampFirma: timeStamphoraAvisoPrivacidad,
											tipoCadena: "firmaAviso"
											
										},
										{
											idSolicitud: $rootScope.solicitudJson.idSolicitud,
											numFirmas: 2,
											timeStampFirma: timeStampTratamiento = (timeStampTratamiento != undefined)?timeStampTratamiento:timeStamphoraAvisoPrivacidad,
											tipoCadena: "firmaAviso"
											
										},
										{
											idSolicitud: $rootScope.solicitudJson.idSolicitud,
											numFirmas: 3,
											timeStampFirma: timeStampTransferencia = (timeStampTransferencia != undefined)?timeStampTransferencia:timeStamphoraAvisoPrivacidad,
											tipoCadena: "firmaAviso"
											
										}
									];
				}else{
					jsonRequest = [
						               {
										idSolicitud: $rootScope.solicitudJson.idSolicitud,
										numFirmas: 1,
										timeStampFirma: timeStampBuro,
										tipoCadena: "firmaBuro"
						               }
					              ];
				}
				
				guardarFirmaUnicaB(_path, jsonRequest);
			};
		 
		 /**
		  * Función que agrega elementos a la bitacora de la NOC
		  * */
			 $rootScope.addEvent = function( idSeccion, idSubSeccion, idAccion, porcentaje, agregar ){ 			 
				 	if( $rootScope.consultaFuncionalidad.habilitarBitacoraDeTiempos && agregar){
				
				 		DatosEvento.push({
				 			SECCIONID		:	idSeccion,
				 			SUBSECCIONID	:	idSubSeccion,
				 			ACCIONID		:	idAccion,
				 			PORCENTAJE 		:	porcentaje,
				 			EMPLEADO 		:	parseInt($rootScope.userSession.noEmpleado) ? parseInt($rootScope.userSession.noEmpleado) : 0,
				 			FECHAACCION 	:	getFechaAccion()})
				 		if(DatosEvento.length > DatosEvento_MAXIMUM_SIZE || idAccion == BITACORA.ACCION.guardar.id){
				 			 $rootScope.enviaEventos();
				 		}
				 	}
				 	console.log(DatosEvento);
				}
		 /**
		  * Funcion que llama al servicio para Eviar Eventos a la Bitacora de Tiempos
		  * */
			 $rootScope.enviaEventos = function(){
				 if( $rootScope.consultaFuncionalidad.habilitarBitacoraDeTiempos && PermitirEnvioDeEventosABD && DatosEvento != undefined &&  DatosEvento != null && DatosEvento.length > 0 && !generalService.isEmpty($rootScope.solicitudJson.idSolicitud)) {
					 PermitirEnvioDeEventosABD = false;
					 var jsonRequest =  {
							 jsonBitacora : makeJsonBitacora( $rootScope.solicitudJson.idSolicitud, $rootScope.solicitudJson.idPais, $rootScope.solicitudJson.idCanal, $rootScope.solicitudJson.idSucursal, $rootScope.solicitudJson.creditoInmediato, $rootScope.solicitudJson.tipoSolicitud )
					 };
//					 $rootScope.message("Bitacora", ["Se enviaron " + DatosEvento.length + " eventos."], "Aceptar");
					 resetDatosEvento();
//					 $rootScope.message("JsonBitacora", [JSON.stringify(jsonRequest.jsonBitacora)], "Aceptar");
					 solicitudService.enviaEventosDeBitacoraABD( jsonRequest, PROCESOS.PSC ).then(
							 function(data){
								 PermitirEnvioDeEventosABD = true;
								 if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
									 var responseJson = JSON.parse(data.data.respuesta);
									 if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
										 console.log("Resultado: "+JSON.stringify(responseJson));
									 }
								 }
							 }, function(error){
								 PermitirEnvioDeEventosABD = true;
							 }	
					 );
				 }
			 }
			 
			/**
			 * Función que valida si dados el día, mes y año, la edad es sufientemente apta según la edad mínima y máxima
			 * permitida.
			 * Algunas consideraciones serían, que si le manda un día de febrero, como si este tuviera 31 días, la fecha
			 * con la que se realizan las validaciones serían su equivalente de marzo. Es decir, si el año no es bisiesto
			 * y se le envía un 29, se genera la fecha como 1 de marzo, si se le envía un 30, entonces 02 de marzo y así
			 * sucesivamente.
			 */
			function tieneEdadParaEndeudarse(dia, mes, anio) {
				if (+dia && +mes && +anio) {
					let minima = generalService.getDatafromCategory("SIMULADOR", "EDAD MINIMA", "VALOR.valor");
					let maxima = generalService.getDatafromCategory("SIMULADOR", "EDAD MAXIMA", "VALOR.valor");
					
					let birthday = new Date(anio + '/' + mes + '/' + dia);
					
					if (birthday.toDateString() != 'Invalid Date') {
						minima = +minima;
						maxima = +maxima;
						
						if (!isNaN(minima + maxima)) {
							let edadMinima = new Date((+anio + minima) + '/' + mes + '/' + dia);
							let edadMaxima = new Date((+anio + maxima) + '/' + mes + '/' + dia);
							
							let today = new Date(); today.setHours(0, 0, 0, 0); // Sólo la fecha de hoy.
							
							return edadMinima <= today && today <= edadMaxima;
						}
					}
				 }
				 
				 return false;
			 }
			
			$rootScope.quemarFolioPreaprobadoNvoPreap=function(idMotivoQuemado,accionSolicitud,path,destinoORG){
				var jsonRequest = {
						  "idPais": $rootScope.solicitudJson.idPais,
						  "idCanal": $rootScope.solicitudJson.idCanal,
						  "idSucursal": $rootScope.solicitudJson.idSucursal,
						  "idSolicitud": $rootScope.solicitudJson.idSolicitud,
						  "clienteUnico": $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
						  "campana": $rootScope.solicitudJson.campana,
						  "idMotivoQuemado": idMotivoQuemado,
						  "opcionQuemado": $rootScope.preaprobadoEncontradoBD
						}
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				solicitudService.quemarFolioPreaprobado(jsonRequest,PROCESOS.PSC).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var jsonResponse = JSON.parse(data.data.respuesta);
								accionSolicitudPreaprobado(accionSolicitud,jsonResponse,path,destinoORG)
							}else
								$rootScope.message("Oferta",[" Ocurrió un error al quemar folio PREAPROBADO, favor de reintentar"], "Aceptar", null, null, null);
						}, function(error){
							$rootScope.waitLoaderStatus = LOADER_HIDE; 
							validateService.error(error);
						});
				
			};
			
			function accionSolicitudPreaprobado(accionSolicitud,jsonResponse,path,destinoORG){
				switch(accionSolicitud){
					//ACEPTO OFERTA PREAPROBADO
					case 1:
						if (jsonResponse.codigo == 2){
							$rootScope.seEjecutoLiberacionLCR=false;
							generalService.locationPath(path,destinoORG);
						}else
							$rootScope.message("Oferta",[" Ocurrió un error al quemar oferta PREAPROBADO, favor de reintentar"], "Aceptar", null, null, null);
					break;
					//RECHAZO OFERTA PREAPROBADO
					case 2:
						if (jsonResponse.codigo == 2)
							rechazaSolicitudPreaprobado();
						else
							$rootScope.message("Oferta",[" Ocurrió un error al rechazar oferta PREAPROBADO, favor de reintentar"], "Aceptar", null, null, null);
					break;
				}
				
			}
			
			function rechazaSolicitudPreaprobado(){
				$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.rechazada.id;
				$rootScope.solicitudJson.idMotivoRechazo = 44;
				$rootScope.waitLoaderStatus = LOADER_SHOW;
			      
				solicitudService.actualizarSolicitud( $rootScope.solicitudJson,PROCESOS.PSC ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						generalService.cleanRootScope($rootScope);
						generalServiceOS.cleanRootScope($rootScope);
						generalService.buildSolicitudJson($rootScope, null);
						generalService.buildSolicitudOSJson($rootScope, null);
			            generalService.locationPath("/simulador");	
					}, function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE; 
			        	modalService.alertModal("Error "+error.status, [error.statusText]);
					}
				);
			}
		});


	app.controller( 'waitLoaderController', function($scope,$rootScope,$timeout){

		$rootScope.waitLoaderStatus = LOADER_SHOW;

		$rootScope.$watch( 'waitLoaderStatus', function( newValue, oldValue ) {

			if(parseInt(newValue) == 0){
				$( '.contentLoader' ).hide();
				$( '.loader' ).hide();
			} else {
				$( '.contentLoader' ).show();
				$( '.loader' ).show();
			}

		});


	});

});
