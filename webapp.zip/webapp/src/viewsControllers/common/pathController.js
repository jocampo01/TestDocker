'use strict';

define(["app"], function (app) {
	
	app.controller('pathController',function($rootScope, $scope, messageData, modalService, generalService, solicitudService, clienteUnicoService,recuperaSolicitudService) {
											
		generalService.setArrayValue("solicitudRecuperada", false);
		generalService.setArrayValue("seCotizoItalika", false);
		var solicitudId = null;
		$rootScope.parametroCaptacion = null;
		
		/* TOLUCA */
		var go2simulator = false;
		
		var _escapeRegExp = function( string ) {                           	       	    		
			return string.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");                           	       	    	
		}

		var _replaceAll = function( string, find, replace ) {                           	       	    		
			return string.replace(new RegExp(_escapeRegExp(find), 'g'), replace);                 
		}
				
		
		$scope.init = function(){	
			
			if(messageData){
				if( generalService.getArrayValue("initAPP") ){
					if( configuracion.origen.tienda && configuracion.so.ios)									
						$rootScope.cargaDato("CargarVista","fondoDivId","cargarVistaFncResponse");
					else
						$scope.load();
				}else
					generalService.locationPath(generalService.getPathSection($rootScope.solicitudJson,$rootScope.sucursalSession.idCanal));
			
			}			
			
		};
						
		
		
		$scope.cargarVistaFncResponse = function(data){
			$rootScope.borraDato("CargarVista");
			
			if( generalService.isEmpty(data) )
				$scope.load();
			else
				generalService.locationPath(data);			
						
		};		
		
		$scope.load = function(){												
				generalService.setArrayValue("initAPP", false);															
				if( configuracion.origen.tienda  )
					$rootScope.cargaDato("AperturaGuardadito","fondoDivId", "aperturaGuardaditoFncResponse");						
				else
					generalService.locationPath("/login");
//					generalService.locationPath("/simulador");
			
		};
					
		$scope.aperturaGuardaditoFncResponse = function(requestJson){
			$rootScope.borraDato("AperturaGuardadito");
			if( generalService.isEmpty(requestJson) )
				$rootScope.cargaDato("IdSolicitudRecuperar","fondoDivId", "solicitudRecuperarFncResponse");
			else{
				requestJson = _replaceAll( requestJson, "'", "\"");
				$scope.requestJson = JSON.parse(requestJson);
				$scope.objectOriginalObject = {idSolicitud:$scope.requestJson.idSolicitud};
				$rootScope.cargaDato("ResponseCaptacion","fondoDivId","responseCaptacionFncResponse");
			}
		};
					
		$scope.solicitudRecuperarFncResponse = function(SolicitudRecuperadaObject){
			
			$rootScope.borraDato("IdSolicitudRecuperar");
			
			if( generalService.isEmpty(SolicitudRecuperadaObject) ){	
				
				if( configuracion.so.windows ){
					$scope.recuperacionC3Presupuesto();
					//generalService.locationPath("/menuWrapper");
				} else {
					/* TOLUCA */
					go2simulator = true;

					isTolucaProjectPresent();
				}
			}else{		
					$rootScope.cargaDato("CaptacionResp","fondoDivId","captacionRespFncResponse");
				
					SolicitudRecuperadaObject = _replaceAll( SolicitudRecuperadaObject, "'", "\"");
					SolicitudRecuperadaObject = JSON.parse(SolicitudRecuperadaObject);																										
																		
					solicitudId = SolicitudRecuperadaObject.idSolicitud;						
					
					generalService.setArrayValue("selectedBusqueda", { originalObject: SolicitudRecuperadaObject });
				
			}						
					
		};	
		
		$scope.responseCaptacionFncResponse = function(captacionObject){
			$rootScope.borraDato("ResponseCaptacion");
		
			if( generalService.isEmpty(captacionObject) ){
				generalService.setArrayValue("selectedBusqueda", { originalObject: $scope.objectOriginalObject });
				generalService.locationPath("/recuperaSolicitud");
			}else{
				captacionObject = _replaceAll( captacionObject, "'", "\"");
				captacionObject = JSON.parse(captacionObject);
				$rootScope.captacionObject = captacionObject;
				$rootScope.aperturaCaptacion={numeroIntentos:$scope.requestJson.numeroIntentos};
				if($rootScope.aperturaCaptacion.numeroIntentos < 2 && captacionObject.reintentar){
					$rootScope.ejecutarPortalCaptacion($scope.requestJson.idPais,
													   $scope.requestJson.idCanal,
													   $scope.requestJson.idSucursal,
													   $scope.requestJson.idSolicitud,
													   $scope.requestJson.idSeguimiento);
				}else{
					$scope.requestJson.motivo =  captacionObject.motivoRetorno;
					$scope.requestJson.reintentar =  captacionObject.reintentar?1:0;
					$scope.requestJson.porcentaje =  captacionObject.porcentaje;
					$scope.requestJson.respuesta =  captacionObject.datos?JSON.stringify(captacionObject.datos):"";
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					solicitudService.guardarSeccionGuardadito($scope.requestJson,PROCESOS.PSC ).then(
							function(data) {
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								if(data.data.codigo == RESPONSE_CODIGO_EXITO){
									var j = JSON.parse(data.data.respuesta);							
									if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
										if(captacionObject.motivoRetorno == 0 && (captacionObject.datos && !generalService.isEmpty(captacionObject.datos.cuenta))){
											marcarAperturarGuardadito(MARCAS_SOLICITUD.aperturarGuardadito.clienteLogro);
										}else{
											marcarAperturarGuardadito(MARCAS_SOLICITUD.aperturarGuardadito.clienteNoPudo);
										}
									}else{
										$rootScope.message("Nueva Originación Centralizada",["Inconveniente al aperturar portal Captación.", "Favor de volver a intentarlo."],"Aceptar");
									}
								}
							}, function(error) {
								$rootScope.message("Nueva Originación Centralizada",["Inconveniente al aperturar portal Captación.", "Favor de volver a intentarlo."],"Aceptar");
								$rootScope.waitLoaderStatus = LOADER_HIDE;
							}
						);
				}
			}
			
		};
		
		function marcarAperturarGuardadito(marca){
	 		var jsonSolicitud = {
					idSolicitud: $scope.requestJson.idSolicitud,
					idSeguimiento: $scope.requestJson.idSeguimiento,
					marca: marca
			};
	 		$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.actualizarSolicitud(jsonSolicitud,PROCESOS.PSC).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								switch(marca){
									case MARCAS_SOLICITUD.aperturarGuardadito.clienteLogro:
										if($scope.requestJson.idSeguimiento != STATUS_SOLICITUD.autorizada.id)
											guardarDatosLiberacion($rootScope.captacionObject.datos.cuenta);
										else{
											$rootScope.parametroCaptacion = {
													numTarjeta: $rootScope.captacionObject.datos.tarjeta,
													folioActivacionTaz:  $rootScope.captacionObject.datos.folioActivacion,
													cuenta: $rootScope.captacionObject.datos.cuenta,
													recuperar: true
											}
											$scope.objectOriginalObject["captacion"] = true;
											generalService.setArrayValue("selectedBusqueda", { originalObject: $scope.objectOriginalObject });
											generalService.locationPath("/recuperaSolicitud");
										}
										break;
									case MARCAS_SOLICITUD.aperturarGuardadito.clienteNoPudo:
										$scope.objectOriginalObject["captacion"] = true;
										generalService.setArrayValue("selectedBusqueda", { originalObject: $scope.objectOriginalObject });
										generalService.locationPath("/recuperaSolicitud");
										break;
								}
							}else{
								$rootScope.message("Aviso", ["Ocurrió un problema al actualizar la solicitud, favor de volver a reintentar"], "Aceptar");
							}
						}else{
							$rootScope.message("Aviso", ["Ocurrió un problema al actualizar la solicitud, favor de volver a reintentar"], "Aceptar");
						}
						
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Aviso", ["Ocurrió un problema al actualizar la solicitud, favor de volver a reintentar"], "Aceptar");
					}
			);
	 	}
		
		function guardarDatosLiberacion(cuentaSeleccionada){
			
			var r = {
				idSolicitud: $scope.requestJson.idSolicitud,
				numCuenta: cuentaSeleccionada,
				tipoCredito: DISPERSION_GUARDADITO   			
			};
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;										 												
			solicitudService.guardarDatosLiberacion(r).then(
				 function(data){
					 $rootScope.waitLoaderStatus = LOADER_HIDE;
					 
					 if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						 var responseJson = JSON.parse(data.data.respuesta);
						 
						 if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
							 if($scope.requestJson.respuesta != ""){
								 $scope.requestJson.respuesta = JSON.parse($scope.requestJson.respuesta);
								 $rootScope.parametroCaptacion = {
											numTarjeta: $scope.requestJson.respuesta.tarjeta,
											folioActivacionTaz:  $scope.requestJson.respuesta.folioActivacion,
											cuenta: $scope.requestJson.respuesta.cuenta,
											motivo: $scope.requestJson.motivo
									}
							 }
							 $scope.objectOriginalObject["captacion"] = true;
							 generalService.setArrayValue("selectedBusqueda", { originalObject: $scope.objectOriginalObject });
							 generalService.locationPath("/recuperaSolicitud");
						 }else{
							 $rootScope.message("Guardadito",[responseJson.descripcion],"Aceptar",null,"bgCafeZ", "cafeZ");
						 }
					 }else{
						 $rootScope.message("Guardadito", ["Error al Aperturar Cuenta Guardadito."],"Aceptar",null,"bgCafeZ", "cafeZ");
					 }
				 }, function(error){
					 $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
				 }
			);
		};
			
		$scope.captacionRespFncResponse = function(captacionObject){
				$rootScope.borraDato("CaptacionResp");
			
				if( generalService.isEmpty(captacionObject) )	
					$rootScope.parametroCaptacion = null;	
				else{	
					captacionObject = _replaceAll( captacionObject, "'", "\"");
					captacionObject = JSON.parse(captacionObject);
					$rootScope.parametroCaptacion = captacionObject;
				}
				generalService.locationPath("/recuperaSolicitud");
		};
		
		$scope.recuperacionC3Presupuesto=function(){
			$rootScope.obtenerInformacionSucursal("fondoDivId", "responseRecuperacionC3Presupuesto");
		};
				
		$scope.responseRecuperacionC3Presupuesto = function(presupuestoResponse){
			$rootScope.loggerIpad("responseRecuperacionC3Presupuesto", presupuestoResponse, null);
//			$rootScope.borraDato("presupuestoC3");
			
			if(!presupuestoResponse){	
				if( configuracion.so.windows )
					/* TOLUCA */
					isTolucaProjectPresent();
				else
					generalService.locationPath("/simulador");									
			}else if('fcFolioParam' in presupuestoResponse){						
//				presupuestoResponse = _replaceAll( presupuestoResponse, "'", "\"");
//				presupuestoResponse = JSON.parse(presupuestoResponse);																										
					
				generalService.setArrayValue("presupuestoC3", presupuestoResponse);
				generalService.locationPath("/simulador");
			}else{
				if( configuracion.so.windows )
					/* TOLUCA */
					isTolucaProjectPresent();
				else
					generalService.locationPath("/simulador");	
			}						
					
		};
		
		/**
		 * TOLUCA.
		 * Función de callback para la consulta de algún producto configurado por la offline de Toluca.
		 */
		$scope.goAhead = function(response) {
			// ¿Qué nos trajo el viento?
			$rootScope.loggerIpad("isThereMailFromToluca", null, {mensaje: response});

			if (configuracion.so.windows) {
				// Se borra la llave
				$rootScope.borraDato('FromTolucaWithLove');
			} else if (false && configuracion.so.ios) { // TODO El wrapper aún no está listo.
				// Hay que borrar la llave
				$rootScope.executeAction('', '', 
					{
						'nombre': 'redirectionToMoc',
						'carpeta': 'Credito',
						'ruta': 'webapp/index.html',
						'jump': false,
						'data': {
							'FromTolucaWithLove': ''
						}
					}
				);
			} else {
				console.log('¡Señor, yo tengo unos principios, y si no le gustan!... tengo otros.');
			}
			
			let mail = {};

			// Si el wrapper nos regresa una cadena.
			if (typeof response === 'string' && response.length > 0) {
				try {
					mail = JSON.parse(response);
				} catch(x) { console.log('The postman always rings twice.'); }
			} else if (typeof response === 'object') { // Quizás nos regresó un JSON.
				mail = response;
			} else { console.log(typeof response); /* Bueno, ¿qué chuchas nos regresó?*/ }

			if (mail && 'idProducto' in mail) {
				// Se asigna el producto al JSON de la solicitud.
				$rootScope.canalActual = parseInt(mail.idProducto);

				// Ya que sí hubo correo, se direcciona a Simulador.
				generalService.locationPath("/simulador");

				return;
			}

			if (go2simulator) {
				// Se dirige a la pantalla de Simulador
				generalService.locationPath("/simulador");
			} else {
				// Se dirige a la pantalla de menú Wrapper
				generalService.locationPath("/menuWrapper");
			}
		}

		/**
		 * TOLUCA.
		 * Función para verificar si hay un producto configurado por la offline de Toluca.
		 */
		function isThereMailFromToluca() {
			// Es tienda.
			if (configuracion.origen.tienda) {
				if (configuracion.so.windows) {
					$rootScope.cargaDato("FromTolucaWithLove", "fondoDivId", "goAhead", false);
				} else if (false && configuracion.so.ios) { // TODO El wrapper aún no está listo.
					// Se consulta si el MOC puso algo en el buzón.
					$rootScope.executeAction('fondoDivId', 'goAhead',
						{
							'nombre': 'validarLlaveTemporal',
							'atributo': 'FromTolucaWithLove'
						}
					);
				} else {
					console.log('Whaaaaaaaaat?!');
				}
			} else {
				if (go2simulator) {
					// Se dirige a la pantalla de Simulador
					generalService.locationPath("/simulador");
				} else {
					// Se dirige a la pantalla de menú Wrapper
					generalService.locationPath("/menuWrapper");
				}
			}
		}

		/**
		 * TOLUCA.
		 * Función para simular una respuesta, en caso de que la invocación del componente falle.
		 */
		$rootScope.$on("keepMovingNeverStop", function() {
			// Se invoca a la función de Callback con un código no exitoso.
			$scope.respuestaVersiones({codigo: 999});
		});

		/**
		 * TOLUCA.
		 * Función de callback para el componente que verifica las versiones.
		 */
		$scope.respuestaVersiones = function(response) {
			// Qué trajo el viento...
			$rootScope.loggerIpad("respuestaVersiones", null, {mensaje: response});

			// Hay respuesta y hay código de éxito de componente.
			if (response && response.codigo == 0) {
				// Se tiene un objeto offLine, en la respuesta y...
				if (response.offline && 
					// Está definida la versión parcial o la versión productiva de Toluca. 
					(response.offline.Originacion_Credito || response.offline.Originacion_Credito_Parcial)) {
					// Se configura una variable en rootScope para validaciones en distintos controladores.
					$rootScope.userSession.existeOfflineNuevoFlujoConsumo = true;

					// Como sí hay una versión de Toluca, se valida si hay correo por parte de ellos.
					isThereMailFromToluca();

					return;
				}
			}

			if (go2simulator) {
				// Se dirige a la pantalla de Simulador
				generalService.locationPath("/simulador");
			} else {
				// Se dirige a la pantalla de menú Wrapper
				generalService.locationPath("/menuWrapper");
			}
		}

		/**
		 * TOLUCA.
		 * Función para validar si se cuenta con una versión "nueva" para el flujo de consumo.
		 */
		function isTolucaProjectPresent() {
			// Es tienda. POR AHORA SÓLO PARA WINDOWS, ESTO DEBE QUITARSE CUANDO EL WRAPPER DE IPAD ESTÉ LISTO.
			if (configuracion.origen.tienda && configuracion.so.windows) {
				// Se invoca la validación de versiones.
				$rootScope.getOfflineVersions('fondoDivId', 'respuestaVersiones', {nombre: 'obtenerVersionesOffline'});
				
				return;
			}
			
			if (go2simulator) {
				// Se dirige a la pantalla de Simulador
				generalService.locationPath("/simulador");
			} else {
				// Se dirige a la pantalla de menú Wrapper
				generalService.locationPath("/menuWrapper");
			}
		}
	});
			
}); 