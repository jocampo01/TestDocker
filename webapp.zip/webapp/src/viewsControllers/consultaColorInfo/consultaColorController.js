'use strict';

define(["app"], function (app) {

	app.controller("consultaColorController", function ($scope, $rootScope, generalService, solicitudService, modalService, documentosService, clienteUnicoService, buroService) {
	
		/**
		 * Declaración de variables globales
		 **/
		$scope.showPage = true;
		$scope.cssPreguntasRadioButton = [];
		$scope.bloqueaBotonPregunta = true;
		var indexResp = undefined;
		var tiempoFinal = 0;
		var tiempoInicio = 0;
		
		/**
		 * Función que se manda a llamar cuando se carga la vista
		 * Contiene un manejo de errores globales (try/catch)
		 * Los errores que se presenten dentro de esta función se reflejaran en el LOG
		 * El manjeo de errores en esta funcion, solo contiene a las funciones cargaVista(), y obtienePreguntas() y evaluaMostrarPregunta()
		 * Si contiene el idsolicitud, continuara con el proceso. Si no, manda un mensaje indicandole que no esxiste una solicitud en proceso 
		 **/
		$scope.init = function(){
			$scope.cssPreguntasRadioButton = [];
			$scope.bloqueaBotonPregunta = true;
			indexResp = undefined;
			tiempoFinal = 0;
			tiempoInicio = 0
			
			try{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				
				if($rootScope.solicitudJson.idSolicitud != undefined){
					cargaVista();
				}else{
			    		var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
			    		$rootScope.message("Aviso ", ["No existe una solicitud en proceso"],"Aceptar","/simulador",null,null,buildJsonDefault);
			    	}
			}catch(e){
				$rootScope.loggerIpad("Error Controlador Datos Encuesta", {error:e.message, detalle: e.stack});
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				
				var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
				$rootScope.message("Aviso ", ["Hubo un error en el proceso, por favor, comuniquese con soporte"],"Aceptar","/simulador",null,null,buildJsonDefault);
			}
	    };
	    
	    /**
	     * Función para cargar la vista principal
	     * Se parametriza la layenda del titulo y sus estilos
	     * Se inicializa el boton para guardar la bateria con la leyenda 'Siguiente'
	     * Manda a llamar a la función 'obtienePreguntas()'
	     **/
	    function cargaVista(){
			$scope.titulo             = {tipoElemento:"titulo",campo:"textoTitulo",marcaAgua:"undefined",visible:true,estilo:"mainHeader azulD",imagen:"images/header/datosEmpleo.png",valor:"",texto:"Evaluación del Cliente",colorModal:"bgAzulD",colorSeccion:"azulD",CATALOGO:"catalogo"};
			$scope.btnGuardar         = {estilo:"btn azulD", texto:"Siguiente", visible:true}
			$scope.bloqueaSeccion = false;
			
			consultaMontosyPlazos();
		};
		
		function consultaMontosyPlazos(){
			buroService.getMontosPlazos($rootScope.solicitudJson.idSolicitud, respuestaMontosyPlazos );
		}
		
		var respuestaMontosyPlazos =  function( typeAuth ){
			var crearColoresCapacidadesPago = $rootScope.capacidadesPagoProducto;
			
			$scope.inmediatos = [];
			$scope.verificacion = [];
			$scope.rechazados = [];
			
			for(var i=0;i<crearColoresCapacidadesPago.length;i++){
				if($rootScope.solicitudJson.banderaIngresos){
					if(crearColoresCapacidadesPago[i].color==1 || crearColoresCapacidadesPago[i].color==2 || crearColoresCapacidadesPago[i].color==3 || crearColoresCapacidadesPago[i].color==7){
						$scope.inmediatos.push(crearColoresCapacidadesPago[i]);
					}else if(crearColoresCapacidadesPago[i].color==4 || crearColoresCapacidadesPago[i].color==5){
						$scope.verificacion.push(crearColoresCapacidadesPago[i]);
					}else if(crearColoresCapacidadesPago[i].color==6){
						$scope.rechazados.push(crearColoresCapacidadesPago[i]);
					}
				}else if(!$rootScope.solicitudJson.banderaIngresos){
					if(crearColoresCapacidadesPago[i].colorNC==1 || crearColoresCapacidadesPago[i].colorNC==2 || crearColoresCapacidadesPago[i].colorNC==3 || crearColoresCapacidadesPago[i].colorNC==7){
						$scope.inmediatos.push(crearColoresCapacidadesPago[i]);
					}else if(crearColoresCapacidadesPago[i].colorNC==4 || crearColoresCapacidadesPago[i].colorNC==5){
						$scope.verificacion.push(crearColoresCapacidadesPago[i]);
					}else if(crearColoresCapacidadesPago[i].colorNC==6){
						$scope.rechazados.push(crearColoresCapacidadesPago[i]);
					}
				}
			}
			
			$scope.banderaActivar = 0
			if($scope.inmediatos.length>0){
				$scope.banderaActivar++;
			}
			
			if($scope.verificacion.length>0){
				$scope.banderaActivar++;
			}
			
			if($scope.rechazados.length>0){
				$scope.banderaActivar++;
			}
		};
		
		$scope.continuarProceso = function(){
			generalService.locationPath("/estatus");
		}
	}) 
});