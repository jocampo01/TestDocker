'use strict';

define(["app"], function (app) {
	
	app.controller("contratosController", function ($timeout, $scope, $rootScope, solicitudService, generalService, modalService, buroService, messageData, validateService, documentosService, clienteUnicoService ) {
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		$rootScope.isOrigenModal = true;
		$scope.confTipoWindows = configuracion.so.windows;
		$scope.confTipoMuestra = false;
		$rootScope.imgPrivacidad = false;
		$scope.contratoAceptado=[];
		var csstabs = {on:"tab dos cafeLi active", off:"tab dos cafeLi"}; 
		$scope.tabFirmadoCSS =  csstabs.off;
		$scope.tabSinFirmaCSS =  csstabs.on;
		$scope.firmados = true;
		$scope.firmaDocumentos=false;
		$scope.requiereAval= false;
		$scope.muestraseguro = true;
		$rootScope.leyendaFirma = "DOCUMENTO FIRMADO ELECTRÓNICAMENTE";
		$rootScope.hayContratoBienes = false;
		$rootScope.avisoPendiente = false;
		$rootScope.buroPendiente = false;
		$rootScope.contratoCaratulaPendiente = false;
		$rootScope.solicitudPendiente = false;
		$rootScope.mostrarBienes = false;
		
		$rootScope.avisoActivo = false;
		$rootScope.buroActivo = false;
		$rootScope.contratoCaratulaActivo = false;
		$rootScope.solicitudActivo = false;
		$rootScope.bienesActivo = false;
		
		if (configuracion.origen.tienda)
			$rootScope.validarTienda = true;
		else
			$rootScope.validarTienda = false;
		
		$scope.showTipoPersona = function(TipoPersona){
			
			if(TipoPersona == 1){
				$scope.tabFirmadoCSS =  csstabs.on;
				$scope.tabSinFirmaCSS =  csstabs.off;
				$scope.firmados = true;
			}else{
				$scope.tabFirmadoCSS =  csstabs.off;
				$scope.tabSinFirmaCSS =  csstabs.on;
				$scope.firmados = false;
			}
		}
		$scope.validarTabs  = function(index){
			 if ($scope.firmados && $scope.documentos[index].statusFirma != STATUS_CONTRATO.SIN_FIRMA &&  $scope.documentos[index].idTipoPersona != 3){
				 return true;
			 }else if (!$scope.firmados && $scope.documentos[index].statusFirma == STATUS_CONTRATO.SIN_FIRMA && $scope.documentos[index].idTipoPersona != 3){
				 return true;
			 }else{
				 return false;
				 }
			 
		}
		
		$scope.validarTabsFaltantes  = function(index){
			if (index > 1){
				if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.prodResPrestamoConGarantias && !generalService.validardiaDePago()){
					 if ($scope.documentos[index].statusFirma == STATUS_CONTRATO.SIN_FIRMA 
							 && $scope.documentos[index].idTipoPersona != 3
							 && $scope.documentos[index].idContrato == FIRMA_BIENES.id){
						 $scope.faltantes = true;
						 return true;			
					 }else{
						 return false;
					 }
				}else{
					return false;
				}
			}else{
				 if (!$scope.faltantes && $scope.documentos[index].statusFirma != STATUS_CONTRATO.SIN_FIRMA &&  $scope.documentos[index].idTipoPersona != 3){
					 return true;
				 }else{
					 if ($scope.faltantes && $scope.documentos[index].statusFirma == STATUS_CONTRATO.SIN_FIRMA && $scope.documentos[index].idTipoPersona != 3){
						 return true;			
					 }else{
						 return false;
					 }
				 }
				}

		}	
		$scope.pageClass = generalService.calculaVistas($rootScope.paginaActual,$rootScope.paginaAnterior,$rootScope.recuperaSolicitud);
		$scope.bloqueaSeccion = $rootScope.solicitudJson.contratos.editable;
	    $scope.vistaDatosUsuario=configuracion.datosUsuario.opcion=0;
		$scope.labelTiempo=generalService.labelTiempo;
		$scope.labelMin=generalService.labelMin;
		$scope.firma1 = false;
		var cont = 0;
		$scope.nombreContrato;
		$scope.urlDoc;
		$scope.contratos = [];
		$scope.porcentaje = ($rootScope.solicitudJson.contratos.porcentaje==100)?true:false;
		$scope.contratosAceptados = 0;
		$scope.esContrato = false;
		$scope.esSolicitud = false;
		$scope.continuarSiguiente = false;
		$scope.imgAdhesion = "";
		$scope.imgPagare = "";
		$scope.imgContrato = "";
		$scope.esContratos = true;
		$scope.marcaSolicitud = $rootScope.solicitudJson.marca;
		$rootScope.marcas = false;
		$scope._nombreSolicitud;
		$scope._nombreContrato;
		$scope.imgFirma;
		$scope.b64Firma;
		
		var nombreMes = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio","Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
		$rootScope.anioActual = new Date().getFullYear();
		$rootScope.mesActual = nombreMes[new Date().getMonth()];
		$rootScope.diaActual = new Date().getDate();
		
		try {
			var munDelDecod = decodeURIComponent(escape($rootScope.sucursalSession.poblacion.trim()));
		}
		catch(err) {
			var munDelDecod = $rootScope.sucursalSession.poblacion.trim();
		}

		$rootScope.lugarActual = ($rootScope.sucursalSession.estado == "Distrito Federal")?munDelDecod+", Ciudad de México":munDelDecod+", "+$rootScope.sucursalSession.estado;
		
		$scope.creditoInmediato = ($rootScope.solicitudJson.creditoInmediato == 0)?false:true;
		$scope.solicitudStatus = $rootScope.solicitudJson.idSeguimiento;
		$scope.contratoSeleccionado;	
		
		$rootScope.doc_details = {
				file_url: $scope.urlDoc
		};
		
		$scope.init = function(){
			
			/*\Se agrega un evento para la bitacora\*/
//			(Contratos)
			$rootScope.addEvent( BITACORA.SECCION.contratos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, $rootScope.solicitudJson.contratos.porcentaje, BITACORA.SECCION.contratos.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
			var hayBienes = false;
			var contratos = $rootScope.solicitudJson.contratos.contrato;
			for(var i in contratos){
				if(contratos[i].idContrato == FIRMA_BIENES.id){
					hayBienes = true;
					$rootScope.mostrarBienes = true;
					$rootScope.hayContratoBienes = contratos[i].statusFirma == 0;
					break;
				}
			}
			
			if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.prodResPrestamoConGarantias){
				var tipoContrato = 16; //anexoBienes
				addAnexoBienes(tipoContrato);
			}
			
			$scope.showPage = true;
		
			if( messageData ){
				let configurarBanderas = function() {
					$scope.esContratosBasicos = false;
					$scope.firmaDocumentos = true;
					$scope.requiereAval = true;
					$scope.firmados = false;
				};
				
				let validacionesFormales = function() {
					let algoDistintoDeCero = generalService.consultaHistoricoMarcas(
							[MARCAS_SOLICITUD.envioContratosSmS, MARCAS_SOLICITUD.envioContratosEmail]
						);
						
						if (!$rootScope.hayContratoBienes) { // Bienes pendientes de firmar.
							if ($rootScope.tipoEnvioSeleccionado || 0 < algoDistintoDeCero) {
								if(!validarContratosBasicos()){
									if($rootScope.solicitudJson.contratos.contrato.length == 4 || hayBienes){
										$scope.esContratosBasicos = true;
										visorContratosFirmados();
									}else{
										configurarBanderas();
									}
									
									return;
								}
							}
						}
						
						$scope.esContratosBasicos = true;
						$scope.enviarAvisoBuro = false;
						($rootScope.isFirmaUnica)?flujoFirmaUnica():flujoFirmaAutografa();
						validarContratosBasicos();
					};
				
				if(generalService.validardiaDePago() || ($scope.solicitudStatus ==  STATUS_SOLICITUD.autorizada.id &&
						 ( $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.sinLiberar ||
						  $scope.marcaSolicitud == STATUS_SOLICITUD.mesaControl.marca.condicionadoMesa ||	 
					      $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.clienteVerdeJVC ||
						  $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.ejecutivo  ||
					      $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.expCompleto ||
					      $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.expValGerente ||
					      $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.tazEntregada ||
					      $scope.marcaSolicitud == STATUS_SOLICITUD.preautorizada.marca.fico)  /* <--CON EL TIEMPO QUITAR*/     
						) || $scope.solicitudStatus ==  STATUS_SOLICITUD.preautorizada.id ||  ($scope.solicitudStatus == STATUS_SOLICITUD.condicionada.id && $rootScope.solicitudJson.idCondicion == STATUS_SOLICITUD.condicionada.idCondicion.expIncompleto)){
								if($rootScope.consultaFuncionalidad.flujoFirmaUnicaHabilitado){
									// Esta solcitud nació como una solicitud de Cambaceo.
									if (bornAsCambaceo()) {
										// Se configuran las banderas.
										configurarBanderas();
									} else {
										validacionesFormales();
									}
								}else{
									configurarBanderas();
								}
					}else if(validarContratosBasicos()){
						$scope.esContratosBasicos = true;
						($rootScope.isFirmaUnica)?flujoFirmaUnica():flujoFirmaAutografa();
					}else{
						$scope.esContratosBasicos = true;
						visorContratosFirmados();
					}
				}else{/* END IF-ELSE MESSAGEDATA */
					$scope.firmaDocumentos=false;
					$scope.requiereAval= false;
				}
			
			$scope.cargaPagina();
			$timeout(function(){
				$scope.showPage = messageData;
			}, 1);
				
			$scope.setContentPage();

			/*confirmarFirmas();	Se comenta hasta que firmaUnica se vaya a parcial*/
			
			$scope.showMessageAviso = false;
			if($rootScope.solicitudJson.contratos.contrato[0].version > 0 && 
					$rootScope.solicitudJson.contratos.contrato[0].statusFirma == STATUS_CONTRATO.SIN_FIRMA)
				$scope.showMessageAviso = true;
			
		};/* END INIT FUNCITON */
		
		$scope.setContentPage = function()
	    {
	    	if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
	    	
	    	$scope.labelTiempo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO TIEMPO."+$scope.origen+".valor"];
			$scope.labelMin = " " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO MIN."+$scope.origen+".valor"];

	    	generalService.setMapping(  MODEL_VISTAS_JSON );
	    	
	    	$scope.txtRegresar = generalService.getDataInput("OCHO PASOS","TEXTO BOTON REGRESAR", $scope.origen);
	    	$scope._titulo = generalService.getDataInput("CONTRATOS","TITULO", $scope.origen);
	    	$scope._txtContratos = generalService.getDataInput("CONTRATOS","TEXTO CONTRATOS", $scope.origen);
	    	$scope._nombreSolicitud = generalService.getDataInput("CONTRATOS","TEXTO SOLICITUD CREDITO", $scope.origen);
	    	$scope._nombreContrato = generalService.getDataInput("CONTRATOS","TEXTO CONTRATO", $scope.origen);
	    	$scope._txtverDoc = generalService.getDataInput("CONTRATOS","TEXTO VER DOCUMENTO", $scope.origen);
	    	$scope._nombreAviso = generalService.getDataInput("AVISOS","TEXTO PRIVACIDAD", $scope.origen);
	    	$scope._nombreBuro = generalService.getDataInput("AVISOS","TEXTO BURO", $scope.origen);
	    	$scope._imgDocs = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.AVISOS.IMG DOCUMENTOS.URL.valor"];
	    	$scope._txtCheckContratos = generalService.getDataInput("CONTRATOS","TEXTO CHECK CONTRATOS", $scope.origen);
	    	$scope._titInfoContratos = generalService.getDataInput("CONTRATOS","TITULO INFO CONTRATOS", $scope.origen);
	    	$scope._infoInicialContratos = generalService.getDataInput("CONTRATOS","INFO INICIAL CONTRATOS", $scope.origen);
	    	$scope._infoInicialContratosAval = generalService.getDataInput("CONTRATOS","INFO INICIAL CONTRATOS", $scope.origen);
	    	$scope._infoListaContratos = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.CONTRATOS.INFO LISTA CONTRATOS"];
	    	$scope._infoFinalContratos = generalService.getDataInput("CONTRATOS","INFO FINAL CONTRATOS", $scope.origen);
	    	$scope._btnBorraFirma = generalService.getDataInput("CONTRATOS","BOTON BORRAR FIRMA", $scope.origen);
	    	$scope._btnContinuar = generalService.getDataInput("CONTRATOS","BOTON CONTINUAR", $scope.origen);
	    	$scope._docsPendientes = {texto: ""};
	    	$scope._docsFirmados = {texto: ""};
	    	$scope._docsPendientes.texto = "Docs. pendientes por firmar";
	    	$scope._docsFirmados.texto = "Docs. firmados";
	    	var str = $scope._infoInicialContratosAval.texto
	    	$scope._infoInicialContratosAval.texto = $scope._infoInicialContratosAval.texto.replace(/Cliente/g, "Aval");
			
	    	if ($rootScope.solicitudJson.contratos.contrato.length < 3){
	    		var index =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
	    			return d["id"];
	    			
	    		}).indexOf ("3");
	    		var index2 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
	    			return d["id"];
	    			
	    		}).indexOf ("4")
	    		if (index == -1 && index2 == -1){
	    			var firma1 = $rootScope.solicitudJson.contratos.contrato[0].statusFirma;
	    			var firma2 = $rootScope.solicitudJson.contratos.contrato[1].statusFirma;
	    		
	    			$rootScope.solicitudJson.contratos.contrato = 
	    				[{idContrato: "1",
	    					idPersona: "",
//	    					statusFirma: 1,
	    					statusFirma: $rootScope.solicitudJson.aceptaTerminos,
	    					descripcion: $scope._nombreAviso.texto,
	    					idTipoPersona: 1
	    				},
	    				{idContrato: "2",
	    					idPersona: "",
//	    					statusFirma: 1,
	    					statusFirma: $rootScope.solicitudJson.aceptaConsultaBuro,
	    					descripcion: $scope._nombreBuro.texto,
	    					idTipoPersona: 1
	    				},	
	    				{idContrato: "3",
	    					idPersona: "",
	    					statusFirma: firma1,
//	    					statusFirma: 1,
	    					descripcion: $scope._nombreContrato.texto,
	    					idTipoPersona: 1
	    				},
	    				{idContrato: "4",
	    					idPersona: "",
	    					statusFirma: firma2,
//	    					statusFirma: 1,
	    					descripcion: $scope._nombreSolicitud.texto,
	    					idTipoPersona: 1
	    				}
//	    				{idContrato: "3",
//	    					idPersona: "",
//	    					statusFirma: 0,
//	    					descripcion: $scope._nombreAviso.texto,
//	    					idTipoPersona: 3
//	    				},
//	    				{idContrato: "4",
//	    					idPersona: "",
//	    					statusFirma: 0,
//	    					descripcion: $scope._nombreBuro.texto,
//	    					idTipoPersona: 3}
	    				]
	    		}
	    	}
	    	var documentosFirmados = 0;
	    	$scope.totalPersona = 0;
	    	$scope.totalPersonaAval = 0;
	    	for(var i = 0; i < $rootScope.solicitudJson.contratos.contrato.length; i ++){
	    		if ($rootScope.solicitudJson.contratos.contrato[i].idTipoPersona == 1){
	    			$scope.totalPersona++
	    		}else{
	    			$scope.totalPersonaAval++
	    		}
	    		var firmaAval = 0;
	    		if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma != STATUS_CONTRATO.SIN_FIRMA /*|| $scope.contratoAceptado[i].firma == true*/){
	    			if ($rootScope.solicitudJson.banderaSolidario == 1){
	    				for(var e = 0; e < $rootScope.solicitudJson.contratos.contrato.length; e ++){
	    					if ($rootScope.solicitudJson.contratos.contrato[e].idContrato == $rootScope.solicitudJson.contratos.contrato[i].idContrato && $rootScope.solicitudJson.contratos.contrato[e].idTipoPersona == 3){
	    						if  ($rootScope.solicitudJson.contratos.contrato[e].statusFirma != STATUS_CONTRATO.SIN_FIRMA) 
	    							firmaAval = 1;
	    						else
	    							firmaAval = 2;
	    					}
	    				}
	    				
	    				switch (firmaAval){                                       
		                
		                case 0:
		                	$scope.contratoAceptado.push({firma: true, idContrato: $rootScope.solicitudJson.contratos.contrato[i].idContrato, idTipoPersona:  $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona});
	    					documentosFirmados++;
		                     break;
		                case 1: 
		                	$scope.contratoAceptado.push({firma: true, idContrato: $rootScope.solicitudJson.contratos.contrato[i].idContrato, idTipoPersona:  $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona});
	    					documentosFirmados++;
		                     break;
		                case 2:  
		                	$scope.contratoAceptado.push({firma: false, idContrato: $rootScope.solicitudJson.contratos.contrato[i].idContrato, idTipoPersona:  $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona});
	    					documentosFirmados++;
		                     break;
		    			}
	    				
	    				
//	    				if (firmaAval){
//	    					$scope.contratoAceptado.push({firma: true, idContrato: $rootScope.solicitudJson.contratos.contrato[i].idContrato, idTipoPersona:  $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona});
//	    					documentosFirmados++;
//	    				}else
//	    					$scope.contratoAceptado.push({firma: false, idContrato: $rootScope.solicitudJson.contratos.contrato[i].idContrato, idTipoPersona:  $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona});
	    					
	    			}else{
	    				$scope.contratoAceptado.push  ({firma: true, idContrato: $rootScope.solicitudJson.contratos.contrato[i].idContrato, idTipoPersona:  $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona});
	    				documentosFirmados++;
	    			}
	    		}else{
	    			$scope.contratoAceptado.push  ({firma: false, idContrato: $rootScope.solicitudJson.contratos.contrato[i].idContrato, idTipoPersona:  $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona});
	    		}
	    		if ($rootScope.solicitudJson.contratos.contrato[i].descripcion == "" || !$rootScope.solicitudJson.contratos.contrato[i].descripcion)
	    			switch ($rootScope.solicitudJson.contratos.contrato[i].idContrato){                                       
	                
	                case "1":
	                	$rootScope.solicitudJson.contratos.contrato[i].descripcion =  $scope._nombreAviso.texto;
	                     break;
	                case "2": 
	                	$rootScope.solicitudJson.contratos.contrato[i].descripcion =  $scope._nombreBuro.texto;
	                     break;
	                case "3":  
	                	$rootScope.solicitudJson.contratos.contrato[i].descripcion = $scope._nombreContrato.texto;
	                     break;
	                case "4":  
	                	$rootScope.solicitudJson.contratos.contrato[i].descripcion = $scope._nombreSolicitud.texto;
	                     break;
	    			}
	    			
	    	}
	    	if ($rootScope.solicitudJson.contratos.contrato.length == documentosFirmados){
	    		$scope.requiereAval= false;
	    		$scope.firmados = true;
	    	}
//	    		else
//	    		$scope.firmados = false;
	    	$scope.documentos = JSON.parse(generalService.delete$$hashKey($rootScope.solicitudJson.contratos.contrato));
	    	for (var i = 0; i < $scope.documentos.length; i++){
	    		if (!$scope.contratoAceptado[i].firma){
	    			$scope.documentos[i].statusFirma = STATUS_CONTRATO.SIN_FIRMA;
	    		} 
	    	}
	    	if(($rootScope.solicitudJson.contratos.contrato[0].statusFirma  == 0 || $rootScope.solicitudJson.contratos.contrato[1].statusFirma  == 0) && !$scope.firmaDocumentos){
	    		$scope.faltantes = true;
	    	}
	    		
	    };/* END SET_CONTENT_PAGE FUNCTION */	    
		
		var construirIframe = function()
		{
			
			var divIframe = $( '#contenedor' );
			var iframe = document.createElement('iframe');

			iframe.height= "100%";
			iframe.width = "100%";
			iframe.id = "iframe";
			iframe.src = "pdf/web/viewer.jsp?urlDoc='" + $scope.urlDoc + "'";//"pdf/webvi?" + ngDialogData.estiloTitulo;
			iframe.scrolling = "no";
			iframe.style.marginBottom = "15px";

			divIframe.append( iframe );
			
		};
		
		function confirmarFirmas(){
			var x = {
					idSolicitud: $rootScope.solicitudJson.idSolicitud
			}
			documentosService.recuperaFirmas( x ).then(
				function(data){
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var jResponse = JSON.parse(data.data.respuesta);
						var arrayContratos = $rootScope.solicitudJson.contratos.contrato;
						
						for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
							
								if(!generalService.isEmpty(jResponse.data[7].firmaContrato) && !generalService.isEmpty(jResponse.data[8].firmaContrato))
									$rootScope.solicitudJson.contratos.contrato[3].statusFirma = STATUS_CONTRATO.ENVIAD0;
								else
									$rootScope.solicitudJson.contratos.contrato[3].statusFirma = STATUS_CONTRATO.SIN_FIRMA;
							} 
							
						}
					
				}, function(error){
					$scope.recuperaFirmasOS(exitoLoad,recuperasolicitud);
				}
			);
		};
				
		$scope.cargaPagina = function(){
				if (configuracion.origen.tienda)
					$scope.origen="TIENDA";
				else
					$scope.origen="WEB";
			
				generalService.setMapping( MODEL_VISTAS_JSON );
				
				$scope.banderaModal = true;
				
				$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo más tarde";
				generalService.setRespaldo($rootScope.solicitudJson);
				$scope.showFirmaAval = false;
				$scope.click = false;
				
				if ($rootScope.solicitudJson.contratos.contrato[0].statusFirma == STATUS_CONTRATO.ENVIAD0 || $rootScope.solicitudJson.contratos.contrato[1].statusFirma == STATUS_CONTRATO.ENVIAD0 ||
						$rootScope.solicitudJson.contratos.contrato[0].statusFirma == STATUS_CONTRATO.FIRMADO_SIN_ENVIAR || $rootScope.solicitudJson.contratos.contrato[1].statusFirma == STATUS_CONTRATO.FIRMADO_SIN_ENVIAR){
					$scope.contratosAceptados = 2;
					$scope.esSolicitud = true;
					$scope.esContrato = true;
					$scope.Ipad = false;
					$scope.firma1 = false;							
				}else{
					$scope.firma1 = false;	
				}

				$scope.firma1Ant = $rootScope.solicitudJson.contratos.contrato[0].statusFirma;
				$scope.idPersona1Ant = $rootScope.solicitudJson.contratos.contrato[0].idPersona;
				$scope.firma2Ant = $rootScope.solicitudJson.contratos.contrato[1].statusFirma;
				$scope.idPersona2Ant = $rootScope.solicitudJson.contratos.contrato[1].idPersona;
				
				$rootScope.nombreCte = $scope.solicitudJson.cotizacion.clientes[0].nombre +" " +$scope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+" " +$scope.solicitudJson.cotizacion.clientes[0].apellidoMaterno;
				$rootScope.nombreSO = $scope.solicitudOSJson.cotizacion.clientes[0].nombre +" " +$scope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno+" " +$scope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno;
				if($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto >= MONTO_PP_AVAL){
					$scope.nombreAval = $scope.solicitudJson.avales[0].nombre +" " +$scope.solicitudJson.avales[0].apellidoPaterno +" " +$scope.solicitudJson.avales[0].apellidoPaterno
					$scope.showFirmaAval = true;							
				}
				
				$scope.contratos();
				$scope.marcasSoliciud();
		
		}
			
		$scope.marcasSoliciud = function (){			
			if((($scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.sinLiberar && $scope.solicitudStatus == STATUS_SOLICITUD.autorizada.id) || ($scope.marcaSolicitud == STATUS_SOLICITUD.mesaControl.marca.condicionadoMesa && $scope.solicitudStatus == STATUS_SOLICITUD.autorizada.id))
				||($scope.solicitudStatus == STATUS_SOLICITUD.condicionada.id && $rootScope.solicitudJson.idCondicion == STATUS_SOLICITUD.condicionada.idCondicion.expIncompleto)){
				$rootScope.marcas = true;
			} else if(($scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.expCompleto || $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.expValGerente) && $scope.solicitudStatus == STATUS_SOLICITUD.autorizada.id ){
				$rootScope.marcas = true;
			} else {
				$rootScope.marcas = false;
			}
				
		}	
			
		$scope.validaContratos = function(){			
			var totalPersona = 0;
			var contratosMuestra = true; 
			var contratosAval = true;
			var validaAval = false;
			$scope.muestraFirmaContrato = false;	
			for(var i = 0; i < $rootScope.solicitudJson.contratos.contrato.length; i ++){
				
	    		if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.SIN_FIRMA && !$scope.contratoAceptado[i].firma == true && $scope.contratoAceptado[i].idTipoPersona != 3){
	    			if (i == 0 || i == 1)
	    				continue;
	    			else
	    				contratosMuestra = false;

	    		}else{
	    			if ($scope.contratoAceptado[i].idTipoPersona == 3)
	    				validaAval = true;
	    			else
	    				if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma != STATUS_CONTRATO.SIN_FIRMA)
	    					totalPersona++
	    		}
	    	}
			//--------------------------------------------------------------------------------------------------------------------------
			if ( contratosMuestra && $scope.totalPersona != totalPersona){				
				$scope.muestraFirmaContrato = true;	
																				
				/*var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
					return d["idContrato"];
			    			
				}).indexOf (FIRMA_SEGURO_CLIENTE.id);
				if (index3 != -1){
					$scope.muestraseguro = false;
				}else{
					$scope.muestraseguro = true;
					}*/
				
				$scope.muestraseguro = true;
				
				var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
					return d["idContrato"];
			    			
				}).indexOf (FIRMA_PRIVACIDAD_ID);
				if (index3 != -1){
					if ($scope.contratoAceptado[index3].firma && $rootScope.solicitudJson.contratos.contrato[index3].statusFirma == STATUS_CONTRATO.SIN_FIRMA)
						$scope.avisoFirmado = true;
				}else{
					$scope.avisoFirmado = false;
					}
				
				
				var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
					return d["idContrato"];
			    			
				}).indexOf (FIRMA_SEGURO_CARTA.id);
				
				if($rootScope.validarTienda){
					if($rootScope.firmaCaratula && $rootScope.firmaSolicitud && !$scope.muestraseguro2 && $scope.muestraseguro ){
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:$rootScope.firmaCaratula});
					}
				}else{
					if( $scope.confTipoWindows && !$scope.muestraseguro2 && $scope.muestraseguro ){	
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						$rootScope.capturarFirmaWV("firmas","responseFirmaWV",{titulo: $scope.tituloFirma});
					}else{
						if(!$scope.muestraseguro2 && $scope.muestraseguro){
						modalService.firmas($scope.tituloFirma)
						.then(
								function(exito){
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
								},function(error){
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									$scope.responseFirmaWV({codigo: 1});
								});
						}
					}
				}
			}
			//--------------------------------------------------------------------------------------------------------------------------
			if (validaAval){ 
				for(var a = 0; a <$scope.contratoAceptado.length; a ++){
					if ($scope.contratoAceptado[a].idTipoPersona == 3){ 
						if($scope.contratoAceptado[a].firma){
							contratosAval = false;
						}else{
							for(var i = 0; i <$scope.contratoAceptado.length; i ++){
								if ($scope.contratoAceptado[a].idContrato == $scope.contratoAceptado[i].idContrato  && !$scope.contratoAceptado[i].firma &&  $scope.contratoAceptado[i].idTipoPersona == 1){
									contratosAval = false;								
								}
							}
						}
					}
				}
			}
			//--------------------------------------------------------------------------------------------------------------------------
			var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
				return d["idContrato"];
		    			
			}).indexOf (FIRMA_SEGURO_CLIENTE.id);
			if (index3 != -1){
				if ($scope.contratoAceptado[index3].firma && $rootScope.solicitudJson.contratos.contrato[index3].statusFirma == STATUS_CONTRATO.SIN_FIRMA){		
					$scope.muestraseguro = false;
					
					if($rootScope.validarTienda){
						if($rootScope.imgSeguroCliente && !$scope.firma1){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:$rootScope.imgSeguroCliente});
						}
					}else{
						if( $scope.confTipoWindows && !$scope.firma1){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							$rootScope.capturarFirmaWV("firmas","responseFirmaWV",{titulo:$scope.tituloFirma});
						}else{
							if(!$scope.firma1){
								modalService.firmas($scope.tituloFirma)
								.then(
										function(exito){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
										},function(error){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$scope.responseFirmaWV({codigo: 1});
										});
								}
						}
					}
				}/*else{
					$scope.muestraseguro = true;
					$scope.muestraFirmaContrato = false;
				}*/
			}
			//--------------------------------------------------------------------------------------------------------------------------
			var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
				return d["idContrato"];
		    			
			}).indexOf (FIRMA_SEGURO_CARTA.id);
			if (index3 != -1){
				if ($scope.contratoAceptado[index3].firma && $rootScope.solicitudJson.contratos.contrato[index3].statusFirma == STATUS_CONTRATO.SIN_FIRMA){	
					$scope.muestraseguro2 = true;
					
					if($rootScope.validarTienda){
						if($rootScope.imgSeguroCarta && !$scope.firma2){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							$scope.responseFirmaSeguro({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:$rootScope.imgSeguroCarta});
						}
					}else{
						if( $scope.confTipoWindows && !$scope.firma2){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							$rootScope.capturarFirmaWV("firmas","responseFirmaWV",{titulo:$scope.tituloFirma});
						}else{
							if(!$scope.firma2){
								modalService.firmas($scope.tituloFirma)
								.then(
										function(exito){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$scope.responseFirmaSeguro({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
										},function(error){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$scope.responseFirmaSeguro({codigo: 1});
										});
								}
						}
					}
				}
			}
			//--------------------------------------------------------------------------------------------------------------------------
			var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
				return d["idContrato"];
		    			
			}).indexOf (FIRMA_PRIVACIDAD_ID);
			if (index3 != -1){
				if ($scope.contratoAceptado[index3].firma && $rootScope.solicitudJson.contratos.contrato[index3].statusFirma == STATUS_CONTRATO.SIN_FIRMA)
					$scope.avisoFirmado = true;
				if($rootScope.validarTienda){
					if($rootScope.imgPrivacidad && !$scope.firma2){
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						$scope.responseFirmaSeguro({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:$rootScope.imgPrivacidad});
					}
				}else{
					if( $scope.confTipoWindows && !$scope.firma1){
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						$rootScope.capturarFirmaWV("firmas","responseFirmaWV",{titulo:$scope.tituloFirma});
					}else{
						if(!$scope.firma2){
							modalService.firmas($scope.tituloFirma)
							.then(
									function(exito){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$scope.responseFirmaSeguro({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
									},function(error){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$scope.responseFirmaSeguro({codigo: 1});
									});
							}
					}
				}
			}else{
				$scope.avisoFirmado = false;
			}
			//--------------------------------------------------------------------------------------------------------------------------
			var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
				return d["idContrato"];
		    			
			}).indexOf (FIRMA_BURO_ID);
			if (index3 != -1){
				if ($scope.contratoAceptado[index3].firma && $rootScope.solicitudJson.contratos.contrato[index3].statusFirma == STATUS_CONTRATO.SIN_FIRMA)
					$scope.buroFirmado = true;
				if($rootScope.validarTienda){
					if($rootScope.imgBuro && !$scope.firma3){
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						$scope.responseBuro({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:$rootScope.imgBuro});
					}
				}else{
					if( $scope.confTipoWindows && !$scope.firma2){
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						$rootScope.capturarFirmaWV("firmas","responseFirmaWV",{titulo:$scope.tituloFirma});
					}else{
						if(!$scope.firma2){
							modalService.firmas($scope.tituloFirma)
							.then(
									function(exito){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$scope.responseFirmaSeguro({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
									},function(error){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$scope.responseFirmaSeguro({codigo: 1});
									});
							}
					}
				}
			}else{
				$scope.avisoFirmado = false;
			}
			
			//--------------------------------------------------------------------------------------------------------------------------
			if (contratosAval && $rootScope.solicitudJson.banderaSolidario == 1 && $scope.totalPersonaAval > 0){
				$scope.muestraFirmaContratoAval = true;				
				if( $scope.confTipoWindows  ){
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					$rootScope.capturarFirmaWV("firmas","responseFirmaWV",{titulo: $scope.tituloFirma});
				}else{
					modalService.firmas($scope.tituloFirma)
					.then(
							function(exito){
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
							},function(error){
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$scope.responseFirmaWV({codigo: 1});
							});
				}
					
			}
		}
	    
		
		$scope.responseBuro = function(responseWV){
			$rootScope.loggerIpad("responseburo", null, responseWV);
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
//					if($scope.muestraFirmaContrato)
//				$scope.b64Firma = responseWV.img64;
//					else
//						$scope.b64Firma2 = responseWV.img64;
				$scope.firma3 = true;				
			}else{	
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(!$scope.muestraseguro){
					var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
						return d["idContrato"];
				    			
					}).indexOf (FIRMA_SEGURO_CLIENTE.id);
					if (index3 != -1){
						$scope.contratoAceptado[index3].firma = false;
						$scope.muestraseguro = true;
						$scope.muestraFirmaContrato = false;
					}
				}else{
					for (var l = 0; l < $rootScope.solicitudJson.contratos.contrato.length; l++){
						if ($rootScope.solicitudJson.contratos.contrato[l].statusFirma == STATUS_CONTRATO.SIN_FIRMA && $scope.contratoAceptado[l].firma == true){
							$scope.contratoAceptado[l].firma  = false;
							$scope.muestraFirmaContrato = false;	
						} 
						
					}
				} 
			}
						
							
		};
		$scope.responseFirmaWV = function(responseWV){
			$rootScope.loggerIpad("responseFirmaWV", null, responseWV);
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
//					if($scope.muestraFirmaContrato)
				$scope.b64Firma = responseWV.img64;
//					else
//						$scope.b64Firma2 = responseWV.img64;
				$scope.firma1 = true;	
				
			}else{	
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(!$scope.muestraseguro){
					var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
						return d["idContrato"];
				    			
					}).indexOf (FIRMA_SEGURO_CLIENTE.id);
					if (index3 != -1){
						$scope.contratoAceptado[index3].firma = false;
						$scope.muestraseguro = true;
						$scope.muestraFirmaContrato = false;
					}
				}else{
					for (var l = 0; l < $rootScope.solicitudJson.contratos.contrato.length; l++){
						if ($rootScope.solicitudJson.contratos.contrato[l].statusFirma == STATUS_CONTRATO.SIN_FIRMA && $scope.contratoAceptado[l].firma == true){
							$scope.contratoAceptado[l].firma  = false;
							$scope.muestraFirmaContrato = false;	
						} 
						
					}
				} 
			}
						
							
		};
		$scope.responseFirmaSeguro = function(responseWV){
			$rootScope.loggerIpad("responseFirmaSeguro", null, responseWV);
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
				$scope.b64FirmaSeguro = responseWV.img64;
				
				$scope.firma2 = true;				
			}else{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
					return d["idContrato"];
			    			
				}).indexOf (FIRMA_SEGURO_CARTA.id);
				if (index3 != -1){
					$scope.contratoAceptado[index3].firma = false;
					$scope.muestraseguro2 = false;
				}
				
			}
							
		};
					
		
		
		$scope.increment = function(id) {
			if ($scope.id == "canvas1"){
				$scope.firma1 = true;
			}
			
			$scope.$digest();
		};
		
		$scope.funcionMover=function(){
			if($scope.click)
				$scope.firma1=true;		
		}
		$scope.funcionMover2=function(){
			if($scope.click)
				$scope.firma2=true;		
		}
		
		$scope.miFuncion=function(){
			console.log(document.getElementById("canvas1"));
			console.log(document.getElementById("canvas1").toDataURL("image/png"));
			$scope.fasd = 2;
		}
		
		$scope.contratos = function(){
		    $('.contratos').each(function(){  
		        var highestBox = 0;
		        $('.texto').css('height', '');
		        $(this).find('.texto').each(function(){
		        	
		        	console.log( $(this).outerHeight() + " <-> " +  highestBox );
		        	
		            if( $(this).outerHeight() > highestBox){  
		                highestBox = $(this).outerHeight();  
		            }
		        })
		        $(this).find('.texto').height(highestBox);
		    });
		}
		
		/**
		 * Función que guarda los estatus de las firmas si se tuvo exito al guardar los archivos
		 **/
		$scope.guardar = function(){
			if(contadorVecesEntro){
				for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
					if($scope.aviso && $rootScope.solicitudJson.contratos.contrato[i].idContrato==="1"){
						$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.ENVIAD0;
					}else if($scope.buro && $rootScope.solicitudJson.contratos.contrato[i].idContrato==="2"){
						$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.ENVIAD0;
					}else if($scope.caratula && $rootScope.solicitudJson.contratos.contrato[i].idContrato==="3"){
						$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.ENVIAD0;
					}else if($scope.solicitudUno && $rootScope.solicitudJson.contratos.contrato[i].idContrato==="4"){
						$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.ENVIAD0;
					}else if($scope.solicitudDos && $rootScope.solicitudJson.contratos.contrato[i].idContrato==="4"){
						$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.ENVIAD0;
					}else if($scope.seguro && $rootScope.solicitudJson.contratos.contrato[i].idContrato==="5"){
						$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.ENVIAD0;
					}else if($scope.carta && $rootScope.solicitudJson.contratos.contrato[i].idContrato==="6"){
						$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.ENVIAD0;
					}else if($scope.bienes && $rootScope.solicitudJson.contratos.contrato[i].idContrato==="13"){
						$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.ENVIAD0;
					}else if($scope.acuseTaz && $rootScope.solicitudJson.contratos.contrato[i].idContrato==="8"){
						$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.ENVIAD0;
					}
				}
	   
				var firmadosDocs = 0;
				for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
					if($rootScope.solicitudJson.contratos.contrato[i].statusFirma == 1 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 2){
						firmadosDocs++;
					}
				}
				
				$rootScope.solicitudJson.contratos.porcentaje = parseInt(((firmadosDocs * 100) / $rootScope.solicitudJson.contratos.contrato.length).toFixed(0));
	
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($rootScope.solicitudJson), seccion: 8 } ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
	
						if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
							var responseJson = JSON.parse(data.data.respuesta);
							
							if(responseJson.codigo == 2){
								if ($scope.origen == "TIENDA" && (configuracion.so.ios || configuracion.so.windows)){
									$scope.enviaContratos();
								}
								
								$rootScope.solicitudJson = responseJson.data;
								/*\Se agrega un evento para la bitacora\*/
//								(Contratos)
								$rootScope.addEvent( BITACORA.SECCION.contratos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.guardar.id, $rootScope.solicitudJson.contratos.porcentaje, BITACORA.SECCION.contratos.guardarEnBD );
								/*\Se agrega un evento para la bitacora\*/
								
								$rootScope.porcentajes.secciones[7].porcentaje = $rootScope.solicitudJson.contratos.porcentaje;
								$rootScope.calculaDocumentos();
								if(generalService.productosQuickFixes()){
									generalService.locationPath( "/ochoPasos",true);
								}else{
									buroService.consultaBuro("bgRosa", "btn gris", "btn btnRosaD" );
								}
							}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
								var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
								$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
							}else{
								if(responseJson.codigo == ERROR_SOL_RECHAZADA){
									var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
									var marca = $rootScope.solicitudJson.marca;
									var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],
											"Aceptar", "/simulador",  "bgRosa" , "btnRosaD",buildJsonDefault);
								}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
									generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
									generalService.locationPath("/ficha");
								}else{
									$scope.DatosAntariores();
									$rootScope.message($scope._titulo.texto,["Error al guardar sección. Código " +
	                                 "de error [" + responseJson.codigo + "] no identificado."], 
	                                 "Aceptar", null, "bgRosa", "btnRosaD");
								}
							}
						}else{
							$scope.DatosAntariores();
							$rootScope.message($scope._titulo.texto,[generalService.displayMessage(data.data.descripcion)], "Aceptar", null, "bgRosa", "btnRosaD");
						}
						
					}, function(error){
						$scope.DatosAntariores();
		                $rootScope.waitLoaderStatus = LOADER_HIDE;
					}
				);
			}else{
				generalService.locationPath("/ochoPasos");
			}
		};
		
		
		$scope.enviaContratos = function(){
			 $rootScope.contratosResponseCita = false;
			$rootScope.executeAction( "firmas", "respuestaContratos",  
					  { nombre:"envioDocumentos", idCliente:$rootScope.solicitudJson.cotizacion.clientes[0].idPersona, mostrarSpinner:0, 
                      filtroDocumentos: CONTRATOS_ENVIAR+","+FIRMA_PRIVACIDAD.descripcion+","+FIRMA_BURO.descripcion });
		}
		$rootScope.respuestaContratos = function(respuesta){
			$rootScope.contratosResponseCita = true;
			$rootScope.loggerIpad("respuestaContratos", null, respuesta);
			console.log(respuesta);
		}
		$scope.visualizaDoc =  function (value,visualizar){
			$rootScope.isAviso = undefined;
			$rootScope.isBuro = undefined;
			$rootScope.isContratoCaratula = undefined;
			$rootScope.isSolicitud = undefined;
			$rootScope.isSeguroCliente = undefined;
			$rootScope.isSeguroCarta = undefined;
			$rootScope.isAcuseTaz = undefined;
			$rootScope.isBienes = undefined;
			
			$rootScope.contratoIndex = visualizar;
			$scope.contratoSeleccionado = value;
			
			var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
    			return d["idContrato"];
    			
    		}).indexOf (value);
			if (index3 >= 0)
				$scope.firma1Ant = $scope.documentos[index3].statusFirma 
//					$rootScope.solicitudJson.contratos.contrato[index3].statusFirma;
			$scope.muestraAvisos = false;
			switch (value){
            
			case "1": 
            	$scope.tituloAviso = generalService.getDataInput("CONTRATOS","TITULO MODAL CONTRATOS 1", $scope.origen);
				$scope.urlDoc = "AvisoPrivacidad.html";
				$rootScope.isAviso = true;
				$rootScope.title = "Firma Aviso de Privacidad";
				$scope.negacionCheck = {texto:"", visible: false, textoMensaje:"", botonAceptar: "Aceptar"};
                 break;
            case "2":  
            	$scope.tituloAviso = generalService.getDataInput("CONTRATOS","TITULO MODAL CONTRATOS 2", $scope.origen);
				$scope.urlDoc = "BuroCredito.html";
				$rootScope.isBuro = true;
				$rootScope.title = "Firma Buro de Crédito";
				$scope.negacionCheck = {texto:"", visible: false, textoMensaje:"", botonAceptar: "Aceptar"};
                 break;
            case FIRMA_CARATULA_CLIENTE.id:  
            	$scope.tituloAviso = $scope._nombreContrato;
            	$scope.tituloFirma = "Contrato, Carátula y Anexo de Comisiones";
            	$scope.urlDoc = "ContratoCaratulaCredito.html";
				$scope.muestraAvisos = true;
				$rootScope.isContratoCaratula = true;
				$rootScope.title = "Firma Contrato, Carátula y Anexo de Comisiones";
				$scope.negacionCheck ={texto:"No acepto Contrato, Carátula y Anexo de Comisiones", visible: true, textoMensaje: "l Contrato de Crédito.", botonAceptar: "Aceptar" };
                 break;
            case FIRMA_SOLICITUD_CREDITO.id:  
            	$scope.tituloAviso = $scope._nombreSolicitud;
            	$scope.tituloFirma = "Solicitud de Crédito";
            	$scope.urlDoc = "SolicitudCredito.html";
				$rootScope.isSolicitud = true;
				$rootScope.title = "Firma Mercadotecnia y Solicitud de Crédito";
				$scope.negacionCheck = {texto:$scope._txtCheckContratos.texto, visible: true, textoMensaje: " la Solicitud de crédito.", botonAceptar: "Aceptar"};
                 break;
            case FIRMA_SEGURO_CLIENTE.id:  
            	$scope.tituloAviso = {texto: "Certificado Seguro Vidamax"};
            	$scope.tituloFirma= "Acepto Seguro VidaMax";
				$scope.urlDoc = "Certificado Vidamax.html";
				$rootScope.isSeguroCliente = true;
				$rootScope.title = "Firma Seguro Vidamax";
				$scope.negacionCheck ={texto:"No acepto contrato de Seguro VidaMax", visible: true, textoMensaje:"l Seguro VidaMax.", botonAceptar: "Aceptar Seguro" }; 
                 break;
            case FIRMA_SEGURO_CARTA.id: 
            	$scope.tituloFirma="Carta Instrucción";
            	$scope.tituloAviso = {texto: "Carta Instrucción"};
            	$scope.urlDoc = "Carta de 14 semanas de atraso Vidamax.html";
				$rootScope.isSeguroCarta = true;
				$rootScope.title = "Firma Seguro Vidamax";
				$scope.negacionCheck = {texto:"No acepto Carta Instrucción", visible: true, textoMensaje:"l Atraso Vidamax.", botonAceptar: "Aceptar"} 
                break;
            case FIRMA_ACUSE_TAZ.id: 
            	$scope.tituloAviso = {texto:"Acuse de entrega de la Tarjeta de Crédito "};
              	$scope.tituloFirma = "Firma Acuse de entrega de la Tarjeta de Crédito ";              	              	
              	$scope.urlDoc = "acuseTaz.html";
              	$rootScope.isAcuseTaz = true;
              	$rootScope.title = "Acuse de entrega de la Tarjeta de Crédito";
              	$scope.negacionCheck = {texto:"No acepto Acuse de Tarjeta de Crédito", visible: true, textoMensaje:" Acuse de Tarjeta Azteca", botonAceptar: "Aceptar"};
    			$scope._btnNoAceptar = generalService.getDataInput("CONTRATOS","BOTON NO ACEPTAR", $scope.origen);
    			$scope._btnAceptar = generalService.getDataInput("CONTRATOS","BOTON ACEPTAR", $scope.origen);
    			$scope.txtModalContratos = generalService.getDataInput("CONTRATOS","TEXTO MODAL CONTRATOS", $scope.origen); 
                break; 	
            case FIRMA_BIENES.id:   
            	$scope.tituloAviso = {texto: "Anexo de Bienes"};
            	$scope.tituloFirma= "Acepto Anexo de Bienes";
				$scope.urlDoc = "AnexoBienes.html";
				$rootScope.isBienes = true;
				$rootScope.title = "Firma Anexo de Bienes";
				$scope.negacionCheck ={texto:"No acepto el contrato de Anexo de Bienes", visible: true, textoMensaje:"l Anexo de Bienes.", botonAceptar: "Aceptar" }; 
				break;    
            default:
            	$scope.tituloAviso = $scope._nombreSolicitud;
              	$scope.tituloFirma = "Contrato, Carátula y Solicitud de Crédito";              	              	
              	$scope.urlDoc = "SolicitudCredito.html";              	              	
              	$rootScope.title = "Firma Seguro Vidamax";
              	$scope.negacionCheck = {texto:"", visible: false, textoMensaje:"", botonAceptar: "Aceptar"} 
            	break;
       }/* END SWITCH */
			
			
			$timeout( function(){
				construirIframe();
			}, 100 );
			
			$scope._btnNoAceptar = generalService.getDataInput("CONTRATOS","BOTON NO ACEPTAR", $scope.origen);
			$scope._btnAceptar = generalService.getDataInput("CONTRATOS","BOTON ACEPTAR", $scope.origen);
			$scope.txtModalContratos = generalService.getDataInput("CONTRATOS","TEXTO MODAL CONTRATOS", $scope.origen);
			
			var imagenesArray = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";				
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
							
				
			modalService.pdfViewModal($scope.urlDoc, $scope.tituloAviso.texto, $scope._btnAceptar.texto, "Cerrar", null, $scope._btnAceptar.estilo, null, ($scope.creditoInmediato||$rootScope.marcas), $scope.esContratos, $scope.contratosAceptados, $scope.firma1Ant, $scope.txtModalContratos,imagenesArray, $scope.muestraAvisos, $scope.negacionCheck )
							.then(
									function(aceptar){
										$scope.responseViewPDF({codigo:RESPONSE_CODIGO_EXITO_IPAD});
										$scope.addOverflow();
									},function(noaceptar){
										$scope.responseViewPDF({codigo:1});			
										$scope.addOverflow();
									}
								);				
		};
		
		$scope.addOverflow=function(){
			$( "html" ).removeClass( "overflowHiddenHTML");
			$( "body" ).addClass( "overflowInitialHTML");
		}
		
		
		/** 
		 * Se continuan con los contratos en una nueva forma de enviarlos 
		 **/
		var contadorVecesEntro = 0;
		$scope.continuarContratos = function (){
			var esEncolarFirmas = false;
			var tipoCadena="", cadena="", esEncolarFirmas=false;
			
			if($rootScope.isAvisoWSD){
				tipoCadena="firmaAviso";
				cadena=$rootScope.imgPrivacidad;
				esEncolarFirmas = true;
				contadorVecesEntro++;
			}else if($rootScope.isBuroWSD){
				tipoCadena="firmaBuro";
				cadena=$rootScope.imgBuro;
				esEncolarFirmas = true;
				contadorVecesEntro++;
			}else if($rootScope.isContratoCaratulaWSD){
				tipoCadena="firmaCaratulaCliente"; 
				cadena=$rootScope.imgCaratula;
				esEncolarFirmas = true;
				contadorVecesEntro++;
			}else if($scope.firmaSolUnoWSD){
				tipoCadena="firmaSolicitudCreditoUno"; 
				cadena=$rootScope.imgSolicitud;
				esEncolarFirmas = true;
				contadorVecesEntro++;
			}else if($scope.firmaSolDosWSD){
				tipoCadena="firmaSolicitudCreditoDos"; 
				cadena=$rootScope.imgSolicitudDos;
				esEncolarFirmas = true;
				contadorVecesEntro++;
			}else if($rootScope.isSeguroClienteWSD){
				tipoCadena="firmaSeguro";
				cadena=$rootScope.imgSeguroCliente;
				esEncolarFirmas = true;
				contadorVecesEntro++;
			}else if($rootScope.isSeguroCartaWSD){
				tipoCadena="firmaSeguroAtraso";
				cadena=$rootScope.imgSeguroCarta;
				esEncolarFirmas = true;
				contadorVecesEntro++;
			}else if($rootScope.isBienesWSD){
				tipoCadena="firmaBienes";
				cadena=$rootScope.imgFirmaBienes;
				esEncolarFirmas = true;
				contadorVecesEntro++;
			}else if($rootScope.isAcuseTAZWSD){
				tipoCadena="firmaAcuseTaz";
				cadena=$rootScope.firmaAcuseTaz;
				esEncolarFirmas = true;
				contadorVecesEntro++;
			}
			
			if($scope.origen == "TIENDA"){
				if(esEncolarFirmas){
					$scope.guardarFirmasOnline(tipoCadena, cadena.replace("data:image/png;base64,","").trim());
				}else{
					$scope.guardar();
					
					
				}	
			} else{
				$scope.guardar();
				
			}
		};
		
		/** 
		 * Elige los contratos que se enviarán en linea 
		 **/
		$scope.guardarFirmasOnline = function(tipoCadena, cadena) {
			var request = {
				idSolicitud: $rootScope.solicitudJson.idSolicitud,
				cadena: cadena,
				tipoCadena: tipoCadena,
				porcentaje: "100"
			}
			
			if(request.tipoCadena == "firmaAviso"){
				request.tratamiento = $rootScope.solicitudJson.tratamientoDatos;
				request.transferencia = $rootScope.solicitudJson.transferenciaDatos;
			}
			
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			clienteUnicoService.setBiometrico(request).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							
							if($rootScope.isAvisoWSD){
								$rootScope.isAvisoWSD = false;
								$scope.aviso = true;
							}else if($rootScope.isBuroWSD){
								$rootScope.isBuroWSD = false;
								$scope.buro = true; 
							}else if($rootScope.isContratoCaratulaWSD){
								$rootScope.isContratoCaratulaWSD = false;
								$scope.caratula = true;
							}else if($scope.firmaSolUnoWSD){
								$rootScope.firmaSolUnoWSD = false;
								$scope.solicitudUno = true;
							}else if($scope.firmaSolDosWSD){
								$rootScope.firmaSolDosWSD = false;
								$scope.solicitudDos = true;
							}else if($rootScope.isSeguroClienteWSD){
								$rootScope.isSeguroClienteWSD = false;
								$scope.seguro = true;
							}else if($rootScope.isSeguroCartaWSD){
								$rootScope.isSeguroCartaWSD = false;
								$scope.carta = true;
							}else if($rootScope.isBienesWSD){
								$rootScope.isBienesWSD = false;
								$scope.bienes = true;
							}else if($rootScope.isAcuseTAZWSD){
								$rootScope.isAcuseTAZWSD = false;
								$scope.acuseTaz = true;
							}
							
							$scope.continuarContratos();
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}
					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'guardaFirmasBiometricosOS'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};
		
//		$scope.continuarContratos = function (){
//			if($scope.firma1){
//				if($scope.origen == "TIENDA"){
//					$scope.archivarFirma1();	
////					$scope.guardar();
//				} else{
//					$scope.guardar();
//				}
//				
//			}else{
//				if($scope.firma2){
//					if($scope.origen == "TIENDA"){
//						$scope.archivarFirma2();	
//					} else{
//						$scope.guardar();
//					}	
//				}else
//					if($scope.firma3){
//						if($scope.origen == "TIENDA"){
//							$scope.archivarFirma3();	
//						} else{
//							$scope.guardar();
//						}
//					}else
//						generalService.locationPath("/ochoPasos");
//			}			
//		};
		
		$scope.regresa = function (){
			
			/*\Se agrega un evento para la bitacora\*/
//			(Contratos)
			$rootScope.addEvent( BITACORA.SECCION.contratos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.cancelar.id, $rootScope.solicitudJson.contratos.porcentaje, BITACORA.SECCION.contratos.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
			
			generalService.locationPath("/ochoPasos");
		};
		
		$scope.cargaFirma = function (imgB64){
			
			var canvas = document.getElementById("canvas1");
			var ctx = canvas.getContext("2d");

			var image = new Image();
			image.onload = function() {
			    ctx.drawImage(image, 0, 0);
			};
			image.src = imgB64;
		};
		
		$scope.negacion = function (value){
			
			var foo = function (){
				$scope.noAceptaContratos = false;
			};
			
			if(value == true){
				var aviso = ["Por políticas internas y para continuar con la solicitud del crédito se requiere la aceptación de la solicitud de crédito y contrato."];
				$rootScope.message("Aviso", aviso, "Aceptar", null, "bgRosa", "btnRosaD", foo);
			}
		}
		
		
//archiva firmas nuevo
		$scope.archivarFirma1 = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$scope.contadorArchivarFirmas++;
			
			var descripcion = "";
			var etiqueta = "";
			var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
				return d["idContrato"];
		    			
			}).indexOf (FIRMA_SEGURO_CLIENTE.id);
			if (index3 != -1){
				descripcion = FIRMA_SEGURO_CLIENTE.descripcion;
				etiqueta =  FIRMA_SEGURO_CLIENTE.etiqueta;
			}else{
				descripcion = FIRMA_CARATULA_CLIENTE.descripcion;
				etiqueta =  FIRMAR_CTE_CONTRATOS;
			}
			
//			if( !$scope.confTipoWindows  ){
//				$scope.GetData1();
//				$scope.imgFirma = $scope.imageData1;
//		    	$scope.b64Firma = $scope.imgFirma.replace("data:image/png;base64,","").trim();
//			}
			$scope.imgFirma = $scope.b64Firma;
	    	$scope.b64Firma = $scope.imgFirma.replace("data:image/png;base64,","").trim();
	    	$rootScope.enviarImagen(
	    			$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
	    			"",
	    			DESC_FIRMA_BURO,
	    			etiqueta,
	    			'firmas',
	    			{	
	    				ruta: null,
	    				idSolicitud: $rootScope.solicitudJson.idSolicitud,
	    				cadena:$scope.b64Firma,
	    				tipoCadena: descripcion,
	    				nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
	    				foto: $rootScope.fotoCteOriginal
	    			},	
	    			"responseEnvioFirmas1"
	    	);
			
		};
			
		
		$scope.responseEnvioFirmas1 = function( responseIPAD ){
			$scope.contadorRepsuestaFirmas++
			$rootScope.loggerIpad("responseEnvioFirmas1", null, responseIPAD);
			try{
				
				if( responseIPAD.codigo == 0 ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					$rootScope.message("CONTRATOS",[ "Correcto para guardar firmas TRY." + JSON.stringify(responseIPAD)], "Aceptar", null);
					if ($scope.firma2)
						$scope.archivarFirma2();
					else
						$scope.guardar();
						
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Error al encolar archivos." + JSON.stringify(responseIPAD)], "Aceptar", null);
					
				}
				
			}catch(e){
				console.log(e.message);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("CONTRATOS",[ "Error al encolar archivos."+e.message], "Aceptar", null);
				console.error( e.message );
				
			}
		}
		$scope.archivarFirma2 = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$scope.contadorArchivarFirmas++;
			var descripcion = "";
			var etiqueta = "";
			var imagenCliente = "";
			var imagenAval = "";
//			if( !$scope.confTipoWindows ){
//				$scope.GetData2();
//				$scope.imgFirma2 = $scope.imageData2;
//				$scope.b64Firma2 = $scope.imgFirma2.replace("data:image/png;base64,","").trim();
//			}else{
			
			$scope.imgFirma2 = $scope.b64FirmaSeguro;
			$scope.b64Firma2 = $scope.imgFirma2.replace("data:image/png;base64,","").trim();
//				$scope.b64Firma2 = $scope.b64FirmaSeguro;
//			}
			var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
				return d["idContrato"];
		    			
			}).indexOf (FIRMA_SEGURO_CARTA.id);
			if (index3 != -1){
				descripcion = FIRMA_SEGURO_CARTA.descripcion;
				etiqueta = FIRMA_SEGURO_CARTA.etiqueta;
				imagenCliente = $scope.imgFirma2;
			}else{
				descripcion = FIRMA_CARATULA_AVAL.descripcion;
				etiqueta = FIRMA_CARATULA_AVAL.etiqueta;
				imagenAval = $scope.imgFirma2;
			}
			
			if ($scope.avisoFirmado){
				$scope.imgFirma2 = $rootScope.imgPrivacidad;
				$scope.b64Firma2 = $scope.imgFirma2.replace("data:image/png;base64,","").trim();
				$rootScope.enviarImagen(
						$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
						"",
						DESC_FIRMA_PRIVACIDAD,
						FIRMA_PRIVACIDAD.descripcion,
						'firmas',
						{	
							ruta: null,
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							cadena: $scope.b64Firma2,
							tipoCadena: "firmaAviso",
							nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
							foto: $rootScope.fotoCteOriginal
						},	
						"responseEnvioFirmas2"
				);
	    	}else{		
				$rootScope.enviarImagen(
						$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
						"",
						DESC_FIRMA_BURO,
						etiqueta,
						'firmas',
						{		
							ruta: null,
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							cadena: $scope.b64Firma2,
							tipoCadena: descripcion,
							nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
							foto: $rootScope.fotoCteOriginal
						},	
						"responseEnvioFirmas2"
				);
	    	}
		};
			
		$scope.responseEnvioFirmas2 = function( responseIPAD ){
			$scope.contadorRepsuestaFirmas++
			$rootScope.loggerIpad("responseEnvioFirmas2", null, responseIPAD);
			try{
					
				if( responseIPAD.codigo == 0 ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					$rootScope.message("CONTRATOS",[ "Correcto para guardar firmas TRY." + JSON.stringify(responseIPAD)], "Aceptar", null);
					if ($scope.firma3)
						$scope.archivarFirma3();
					else
						$scope.guardar();
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Error al encolar archivos." + JSON.stringify(responseIPAD)], "Aceptar", null);
						
				}
					
			}catch(e){
				console.log(e.message);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("CONTRATOS",[ "Error al encolar archivos."+e.message], "Aceptar", null);
				console.error( e.message );
					
			}
		}
		
		$scope.archivarFirma3 = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$scope.contadorArchivarFirmas++;
			if ($scope.buroFirmado){
				$scope.imgFirma3 = $rootScope.imgBuro;
				$scope.b64Firma3 = $scope.imgFirma3.replace("data:image/png;base64,","").trim();
				$rootScope.enviarImagen(
						$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
						"",
						DESC_FIRMA_BURO,
						FIRMA_BURO.descripcion,
						'firmas',
						{	
							ruta: null,
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							cadena:$scope.b64Firma3,
							tipoCadena: "firmaBuro",
							nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
							foto: $rootScope.fotoCteOriginal
						},	
						"responseEnvioFirmas3"
				);	
	    	}
		};
			
		$scope.responseEnvioFirmas3 = function( responseIPAD ){
			$scope.contadorRepsuestaFirmas++
			$rootScope.loggerIpad("responseEnvioFirmas3", null, responseIPAD);
			try{
					
				if( responseIPAD.codigo == 0 ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					$rootScope.message("CONTRATOS",[ "Correcto para guardar firmas TRY." + JSON.stringify(responseIPAD)], "Aceptar", null);
					$scope.guardar();
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Error al encolar archivos." + JSON.stringify(responseIPAD)], "Aceptar", null);
						
				}
					
			}catch(e){
				console.log(e.message);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("CONTRATOS",[ "Error al encolar archivos."+e.message], "Aceptar", null);
				console.error( e.message );
					
			}
		}
		
		$scope.enviarFirmasSolicitud = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$scope.contadorArchivarFirmas++;
								
			if($rootScope.imgSolicitud){
				var descripcion = FIRMA_SOLICITUD_CREDITO_UNO.descripcion;
				var etiqueta =  FIRMA_SOLICITUD_CREDITO_UNO.etiqueta;
				var firmaSolicitudUno = 1;
				$scope.imgFirma = $rootScope.imgSolicitud;
				if (!$scope.imgFirma){
					console.log("No hay firma");
				}else{
					$scope.b64Firma = $scope.imgFirma.replace("data:image/png;base64,","").trim();
			    	if(configuracion.origen.tienda){
			    		
			    		var biometrico = {
								ruta: null,
								idSolicitud: $rootScope.solicitudJson.idSolicitud,
								cadena:$scope.b64Firma,
								tipoCadena: descripcion,
								porcentaje: 100
						}
			    		
			    		$scope.enviarContratos(biometrico, firmaSolicitudUno);
			    		
			    	}
				}
				
			}
			if($rootScope.imgSolicitudDos){
				var descripcion = FIRMA_SOLICITUD_CREDITO_DOS.descripcion;
				var etiqueta =  FIRMA_SOLICITUD_CREDITO_DOS.etiqueta;
				var firmaSolicitudDos = 2;
				$scope.imgFirma = $rootScope.imgSolicitudDos;
				if (!$scope.imgFirma){
					console.log("No hay firma");
				}else{
					$scope.b64Firma = $scope.imgFirma.replace("data:image/png;base64,","").trim();
			    	if(configuracion.origen.tienda){
			    		
			    		var biometrico = {
								ruta: null,
								idSolicitud: $rootScope.solicitudJson.idSolicitud,
								cadena:$scope.b64Firma,
								tipoCadena: descripcion,
								porcentaje: 100
						}
			    		
			    		$scope.enviarContratos(biometrico, firmaSolicitudDos);
			    		
			    	}
				}
    		}
		};
		
		$scope.enviarContratos = function (biometrico, firmaSolicitud){
			$scope.biometrico = biometrico;
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			clienteUnicoService.setBiometrico( biometrico ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								$scope.contratoAceptado[$rootScope.contratoIndex].firma = true;
								generalService.setRespaldo($rootScope.solicitudJson);
								if(firmaSolicitud == 1)
									$scope.firmaSolicitudUnoEnviada = true;
								
								if(firmaSolicitud == 2)
									$scope.firmaSolicitudDosEnviada = true;
								
								if($scope.biometrico.tipoCadena == FIRMA_BIENES.descripcion)
									$scope.firmaBienesEnviada = true;
									
							}else{
								$rootScope.message("Error",["Error al enviar el contrato."], "Aceptar", null, "bgRosa" , "btnRosaD",null,null,null);
							}
						}else{
							$rootScope.message("Error",["Error en la respuesta del servicio para guardar el contrato del cliente. Por favor, reintente nuevamente."], "Aceptar", null, "bgRosa" , "btnRosaD");
						}
					},function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Error",["Servicio no disponible para enviar el contrato, favor de comunicarse con soporte."], "Aceptar", "/simulador", "bgRosa" , "btnRosaD");
					});
		};
		
//archiva firmas nuevo
		
		
//		$scope.archivarFirma = function()
//		{
//			$rootScope.waitLoaderStatus = LOADER_SHOW;
//			
//			$scope.GetData1();
//			$scope.imgFirma = $scope.imageData1;
//	    	$scope.b64Firma = $scope.imgFirma.replace("data:image/png;base64,","").trim();
//	    	
//			$rootScope.enviarImagen(
//					$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
//					"",
//					FIRMAR_CONTRATOS,
//					FIRMAR_CTE_CONTRATOS,
//					'canvas1',
//					{	
//						idSolicitud: $rootScope.solicitudJson.idSolicitud,
//						firmaAviso: "",
//						firmaBuro: "",
//		    			firmaCliente: $scope.b64Firma,
//		    			firmaAval: "",
//		    			nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
//						foto: $rootScope.fotoCteOriginal
//					},	
//					"responseEnvioFirmas"
//			);
//			
//			
//		};
//		
//		$scope.responseEnvioFirmas = function( responseIPAD )
//		{
//
//			try{
//				
//				if( responseIPAD.codigo == 0 ){
//					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					//$rootScope.message("CONTRATOS",[ "Correcto para guardar firmas TRY." + JSON.stringify(responseIPAD)], "Aceptar", null);
//					$scope.guardar();
//				}else{
//					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					$rootScope.message("CONTRATOS",[ "Error al encolar archivos." + JSON.stringify(responseIPAD)], "Aceptar", null);
//					
//				}
//				
//			}catch(e){
//				console.log(e.message);
//				$rootScope.waitLoaderStatus = LOADER_HIDE;
//				$rootScope.message("CONTRATOS",[ "Error al encolar archivos."+e.message], "Aceptar", null);
//				console.error( e.message );
//				
//			}
//			
//			
//		};
		
		$scope.verPdf = function (urlDoc, nombreArchivo){

			$rootScope.visualizaPdf("viewDoc", 
									urlDoc,
									nombreArchivo,
									$scope.firma1Ant==1||$scope.firma1Ant==2?false:true,
									false,
									"responseViewPDF");
		};
		
		$scope.responseViewPDF = function( responseIPAD )
		{
			$rootScope.loggerIpad("responseViewPDF", null, responseIPAD);
			try{
				
				var value = $scope.contratoSeleccionado;
				
				if( responseIPAD.codigo == 0 ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					//console.log(JSON.stringify(responseIPAD));
//					$rootScope.message("URL=>", ["URL=>"+$scope.urlDoc], "Aceptar", null);
					if ($rootScope.solicitudJson.contratos.contrato[ $rootScope.contratoIndex ].statusFirma != STATUS_CONTRATO.SIN_FIRMA || $scope.contratoAceptado[ $rootScope.contratoIndex ].firma != true){
						$scope.contratosAceptados++;
						$scope.Ipad = true;
						$scope.contratoAceptado[$rootScope.contratoIndex].firma = true;
						$scope.validaContratos();
					}
					
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					//$rootScope.message("CONTRATOS",[ "Error al visualizar el documento." + JSON.stringify(responseIPAD)], "Aceptar", null);
					if($scope.firma1Ant == 0)
					{
						if ($rootScope.solicitudJson.contratos.contrato[ $rootScope.contratoIndex ].statusFirma != STATUS_CONTRATO.SIN_FIRMA || $scope.contratoAceptado[ $rootScope.contratoIndex ].firma == true){
							$scope.contratosAceptados--;
							$scope.Ipad = false;
							 $scope.contratoAceptado[$rootScope.contratoIndex].firma = false;
							 $scope.validaContratos();
						}
						
					}
					
					
				}
				
			}catch(e){
				console.log(e.message);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("CONTRATOS",[ "Error al visualizar el documento."+JSON.stringify(e)], "Aceptar", null);
				console.error( e.message );
				
			}
			
			
		};
		
		$scope.visorPdfWeb = function (){
			var value = $scope.contratoSeleccionado;
			
			modalService.avisosModal($scope.tituloAviso, $scope.urlDoc, $scope._btnNoAceptar, $scope._btnAceptar, null,$scope._btnNoAceptar.estilo, $scope._btnAceptar.estilo, ($scope.creditoInmediato||$rootScope.marcas), $scope.esContratos, $scope.contratosAceptados, $scope.firma1Ant, $scope.txtModalContratos).then(
 					function(exito){
                        
 						if ($rootScope.solicitudJson.contratos.contrato[ $rootScope.contratoIndex ].statusFirma != STATUS_CONTRATO.SIN_FIRMA || $scope.contratoAceptado[ $rootScope.contratoIndex ].firma != true){
 							$scope.contratosAceptados++;
 							$scope.Ipad = true;
 							$scope.contratoAceptado[$rootScope.contratoIndex].firma = true;
 							$scope.validaContratos();
 						}
 						
 						
 					},function(error){
 						if($scope.firma1Ant == 0)
 						{
 							
 							if ($rootScope.solicitudJson.contratos.contrato[ $rootScope.contratoIndex ].statusFirma != STATUS_CONTRATO.SIN_FIRMA || $scope.contratoAceptado[ $rootScope.contratoIndex ].firma == true){
 								$scope.contratosAceptados--;
 								$scope.Ipad = false;
 								$scope.contratoAceptado[$rootScope.contratoIndex].firma = false;
 								$scope.validaContratos();
 							}
 						}
 						
 					}
 			);
		};
		
	    $scope.$on("$destroy", function() {
	    	$( "body" ).removeClass( "overflowInitialHTML");
	    });
	    
	    function addContrato(){
	    	$rootScope.hayContratoBienes = true;
	    	$rootScope.bienesActivo = true;
	    	$rootScope.mostrarBienes = true;
	    	flujoFirmaAutografaBienes();
	    };
	    
	    function sendContracts (tipoContrato){
	    	var descripcion = "";
	    	if(tipoContrato = 16){
	    		 var descripcion = FIRMA_BIENES.descripcion;
	    		 $scope.imgFirmaBienes = $rootScope.imgFirmaBienes;
				 if ($scope.imgFirmaBienes){
					 $scope.b64Firma = $scope.imgFirmaBienes.replace("data:image/png;base64,","").trim();
					 if(configuracion.origen.tienda){
						 var biometrico = {
								ruta: null,
								idSolicitud: $rootScope.solicitudJson.idSolicitud,
								cadena:$scope.b64Firma,
								tipoCadena: descripcion,
								porcentaje: 100
						 	}
						 $scope.enviarContratos(biometrico);
				    	}	
				 }else{ console.log("No hay firma"); }	    	
	    	}
	    };
		
		function flujoFirmaUnica(){
			modalService.visorContratos();
		};
		
		function flujoFirmaAutografa(){
			$scope.firmaAutografa = true;
			if ($scope.confTipoWindows){
				//Se prepara la petición para enviar al componente de firma autografa
				var jsonRequest = {};
				
				if(!$scope.enviarAvisoBuro){
					jsonRequest = {
							titulo: "Firma de Contratos",
							contratos: ["Carátula de crédito", "Solicitud de Crédito"],
							rutasHTML: ["credito\\webapp\\documents\\ContratoCaratulaCredito.html",
							            "credito\\webapp\\documents\\SolicitudCredito.html"],
							parrafos: [],
							tipoFirma: 1
					};
				}else{
					jsonRequest = {
							titulo: "Aviso de Privacidad y Consulta al Buró de Crédito",
							contratos: ["Aviso de privacidad", "Consulta al Buró de Crédito"],
							parrafos: [
										"<html><body><p style=\"text-align:justify;\">Reconozco que "+
										"cada una de las firmas electr&oacute;nicas que seran asentadas en los "+
										"documentos que se identifican a continuaci&oacute;n, son pruebas "+
										"inequivoca de la manifestaci&oacute;n expresa de mi voluntad, "+
										"reconociendo que no existe error, dolo o mala f&eacute; en la celebraci&oacute;n "+
										"de los actos que a continuaci&oacute;n se "+
										"indican.</p><br></body></html>",
										"<html><body><p style=\"text-align:justify;\">Reconozco ante Banco Azteca, S.A. Instituci&oacute;n de Banca M&uacute;ltiple, que he otorgado mi "+
										"autorizaci&oacute;n y manifiesto mi conformidad respecto de los documentos "+
										"(1 y 2) y que he otorgado mi consentimiento y aceptaci&oacute;n inequivoca respecto de los documentos numerales (3, 4 y 5), aceptando las obligaciones que a mi cargo derivan de los citados "+
										"documentos en t&eacute;rminos de las firmas electr&oacute;nicas que, de manera individual, y tras haber "+
										"le&iacute;do cada uno de los documentos antes "+
										"indicados, he asentado en cada uno de ellos de manera electr&oacute;nica, lo cual "+
										"convalido y ratifico a trav&eacute;s de la firma asentada en el presente documento."+
										"</p><br></body></html>"
							           ],
							tipoFirma: 1
					};
				}
				
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$rootScope.capturarFirma2WV("firma2Div","responseFirma2WV",jsonRequest);
			}else{
				$rootScope.contratosOriginacion = false;
            	modalService.modalFirmaUnica().then(
					    function(exito) {
					        if (exito != undefined) {
					            console.log("Terminé de firmar los contratos con firma única");
					        } else {
					            modalService.visorContratos();
					        }
					    },
					    function(error) {
					        if (error != undefined) {
					            console.log("Terminé de firmar los contratos con firma única");
					        } else {
					            console.log("Terminé de firmar los contratos con firma autografa");
					        }
					    }
					);
			}
			
		};
		
		function flujoFirmaAutografaBienes(){
			if(!$rootScope.isFirmaUnica){
				if ($scope.confTipoWindows){
					//Se prepara la petición para enviar al componente de firma autografa
					var jsonRequest = {
							titulo: "Anexo de Bienes",
							contratos: ["Anexo"],
							tipoFirma: 6
					};
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					$rootScope.capturarFirma2WV("firma2Div","responseFirma2WVBienes",jsonRequest);
				}else{
					$rootScope.contratosOriginacion = false;
	            	modalService.modalFirmaUnica().then(
						    function(exito) {
						        if (exito != undefined) {
						            console.log("Terminé de firmar los contratos con firma única");
						        } else {
						            modalService.visorContratos();
						        }
						    },
						    function(error) {
						        if (error != undefined) {
						            console.log("Terminé de firmar los contratos con firma única");
						        } else {
						            console.log("Terminé de firmar los contratos con firma autografa");
						        }
						    }
						);
				}
			}else{
				modalService.visorContratos();				
			}
			
		};
		
		$scope.responseFirma2WV = function(responseWV){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
				try{
					if($scope.enviarAvisoBuro){
						$rootScope.imgPrivacidad = responseWV.imgB64[0];
						$rootScope.firmaPrivacidad = "data:image/png;base64," + responseWV.imgB64[0].replace("data:image/png;base64,","");
						$rootScope.isAvisoWSD = true;
						$rootScope.imgBuro = responseWV.imgB64[1];
						$rootScope.firmaBuro = "data:image/png;base64," + responseWV.imgB64[1].replace("data:image/png;base64,","");
						$rootScope.isBuroWSD = true;
						modalService.visorContratos();
						return;
					}else{
						$rootScope.imgCaratula = responseWV.imgB64[0];
						$rootScope.imgSolicitud = responseWV.imgB64[1];
						$rootScope.imgSolicitudDos = responseWV.imgB64[2];
						$rootScope.firmaCaratula = "data:image/png;base64," + responseWV.imgB64[0].replace("data:image/png;base64,","");
						$rootScope.firmaSolicitud = "data:image/png;base64," + responseWV.imgB64[1].replace("data:image/png;base64,","");
						$rootScope.firmaSolicitudDos = "data:image/png;base64," + responseWV.imgB64[2].replace("data:image/png;base64,","");
						$rootScope.isContratoCaratulaWSD = true;
						$rootScope.firmaSolUnoWSD = true;
						$rootScope.firmaSolDosWSD = true;
					}
				}catch(e){console.log(e)}
				
				if ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.prodResPrestamoConGarantias) {
					addContrato();
				} else if($rootScope.avisoActivo || $rootScope.buroActivo){
					$scope.enviarAvisoBuro = true;
					flujoFirmaAutografa();
				}else{
					modalService.visorContratos();
				}
			}else if( responseWV.codigo == 2 ){
				$rootScope.message( "Nueva Originación Centralizada", ["Es necesario autorizar los términos y condiciones para continuar con la solicitud"], "Aceptar","/ochoPasos");
			}else{
				$rootScope.message( "Nueva Originación Centralizada", ["Ocurrio un error con el componente de firma"], "Aceptar","/ochoPasos");
			}
		};
		
		$scope.responseFirma2WVBienes = function(responseWV){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
				try{
					$rootScope.imgFirmaBienes = responseWV.imgB64[0];
					$rootScope.firmaBienes = "data:image/png;base64," + responseWV.imgB64[0].replace("data:image/png;base64,","");
					$rootScope.isBienesWSD = true;
				}catch(e){console.log(e)}
				if($rootScope.avisoActivo || $rootScope.buroActivo){
					$scope.enviarAvisoBuro = true;
					flujoFirmaAutografa();
				}else{
					modalService.visorContratos();
				}
				
			}else if( responseWV.codigo == 2 ){
				$rootScope.message( "Nueva Originación Centralizada", ["Es necesario autorizar los términos y condiciones para continuar con la solicitud"], "Aceptar","/ochoPasos");
			}else{
				$rootScope.message( "Nueva Originación Centralizada", ["Ocurrio un error con el componente de firma"], "Aceptar","/ochoPasos");
			}
		};
		
		/**
		 * Función que determina si la solicitud alguna vez tuvo la marca de generadaCambaceo.
		 * @return buleano. Verdadero si la marca se encuentra en el histórico. Falso en caso contrario.
		 */
		function bornAsCambaceo() {
			let marcaCambaceo = STATUS_SOLICITUD.generada.marca.generadaCambaceo;
			
			// Está definicio el histórico de marcas, como un arreglo no vacío.
			if (Array.isArray($rootScope.historicoMarcas) && $rootScope.historicoMarcas.length > 0) {
				for (let x of $rootScope.historicoMarcas) {
					if (x == marcaCambaceo) {
						return true;
					}
				}
			}
			
			return false;
		};
		
		function visorContratosFirmados(){
			modalService.visorSeccionContratos();
		};
		
		function validarContratosBasicos(){
			var hayContratosPendientes = false;
			
			if($rootScope.solicitudJson.contratos.contrato[0].statusFirma != STATUS_CONTRATO.ENVIAD0){
				$rootScope.avisoPendiente = true;
				$rootScope.avisoActivo = true;
			}
			if($rootScope.solicitudJson.contratos.contrato[1].statusFirma != STATUS_CONTRATO.ENVIAD0){
				$rootScope.buroPendiente = true;
				$rootScope.buroActivo = true;
			}
			if($rootScope.solicitudJson.contratos.contrato[2].statusFirma != STATUS_CONTRATO.ENVIAD0){
				$rootScope.contratoCaratulaPendiente = true;
				$rootScope.contratoCaratulaActivo = true;
			}
			if($rootScope.solicitudJson.contratos.contrato[3].statusFirma != STATUS_CONTRATO.ENVIAD0){
				$rootScope.solicitudPendiente = true;
				$rootScope.solicitudActivo = true;
			}
			
			var arrayContrato = $rootScope.solicitudJson.contratos.contrato;
			
			for(var i=0; i<4; i++){
				if(arrayContrato[i].statusFirma != STATUS_CONTRATO.ENVIAD0){
					hayContratosPendientes = true;
					break;
				}
			}
			return hayContratosPendientes;
		} ;
		
		function addAnexoBienes(tipoContrato){
			if(tipoContrato == 16){
	    		var addBienes =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
					return d["idContrato"];
				}).indexOf (FIRMA_BIENES.id);
				if (addBienes == -1){
					var jsonBienes = {
							idContrato: FIRMA_BIENES.id,
							idPersona: $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
							statusFirma: STATUS_CONTRATO.SIN_FIRMA,
							descripcion: FIRMA_BIENES.etiqueta,
							idTipoPersona: 1
						};
					$rootScope.solicitudJson.contratos.contrato.push(jsonBienes);
				}
	    	}
		};
	});
	
});

//"nGIRbhkJmdXXfPGtBXNJnlZ/MtO7gQEuml61hFo2EWa9WLhTSstG5u30+G+EqptbJDqAOUtBRx3sDlM8qSFyCYspB/s8w3l1cdZkhb5M8+MO3wc1v0dejZcWa9+6q9XTxJySg5osfBE62xTgP6K5GZcGppWLA4kUyuS1JXhbVgzevRVITNCK/fmhxPNE7tUQ">