'use strict';

var imagenes = new Array();

define(["app"], function (app) {
	
	app.controller('contratosOriginacionController', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService) {
		
		$scope.bloquearBtnAceptar = true;
		$scope.confTipoWindows = configuracion.so.windows;
		$scope.tituloHeader = "Aviso de Firma Única";
		var tipoFirma = undefined;
		$scope.usarFirmaUnica = false;
		$scope.init = function(){
			
		}
		
		
		$scope.verificarCheckbox = function(valor){
    		if(valor == 1 || valor == 2){
    			$scope.bloquearBtnAceptar = false;
    			if(valor == 1){
    				$rootScope.timeStampTratamiento = Date.now();
    			}else if(valor == 2){
    				$rootScope.timeStampTransferencia = Date.now();
    			}
    		}
    		$rootScope.solicitudJson.tratamientoDatos = ($scope.tratamiento1)? 1:0;
    		$rootScope.solicitudJson.transferenciaDatos = ($scope.tratamiento2) ? 1:0;
    	}
		
		$scope.btnGuadar = function (){
    		$rootScope.isFirmaUnica = ($scope.usarFirmaUnica)? true:false;
			$rootScope.solicitudJson.aceptaTerminos = 1;
			$scope.confirm();
		};
		
		function firmaUnica(){
			//Se prepara la petición para enviar al componente de firma única
			var jsonRequest = {
					titulo: "Aviso de Privacidad y Consulta a Buró de Crédito",
					contratos: ["Aviso de privacidad", "Caratula de buro"],
					rutasHTML: ["credito/webapp/documents/AvisoPrivacidad.html",
					            "credito/webapp/documents/BuroCredito.html"],
					parrafos: [
								"<html><body><p style=\"text-align:justify;\">Reconozco que "+
								"cada una de las firmas elctronicas que seran asentadas en los "+
								"documentos<br>que se identifican a continuacion, son pruebas "+
								"inequivoca de la manifestacion expresa de mi<br>voluntad, "+
								"reconociendo que no existe error, dolo o mala fe en la celebracion "+
								"de los actos que<br>a continuacion se "+
								"indican.</p><br></body></html>",
								"<html><body><p style=\"text-align:justify;\">Reconozco ante Banco Azteca, S.A. Institución de Banca Múltiple, que he otorgado mi"+
								"caautorización y manifiesto mi conformidad respecto de los documentos"+
								"documentos<br>que se identifican a continuacion, son pruebas "+
								"(1 y 2) y que he otorgado mi consentimiento y aceptación inequivoca respecto de los documentos numerales (3,4 y 5), aceptando las obligaciones que a mi cargo derivan de los citados"+
								"documentos en términos de las firmas electrónicas que, de manera individual, y trashaber"+
								"leído cada uno de los documentos antes"+
								"indicados, he asentado en cada uno de ellos de manera electrónica, lo cual"+
								"convalido y ratifico a través de la firma asentada en el presente documento."+
								"</p><br></body></html>"
					           ],
					tipoFirma: tipoFirma
			};
			
			if ($scope.confTipoWindows){
				//$scope.confirm();
				$rootScope.capturarFirma2WV("avisosDivId","responseFirma2WV",jsonRequest);
			}else{
				$rootScope.solicitudJson.aceptaTerminos = 1;
				$scope.confirm();
			}
			
			
			
		};
		
		$scope.responseFirma2WV = function(responseWV) {
		    $rootScope.waitLoaderStatus = LOADER_HIDE;
		    if (responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD) {
		        if ($rootScope.isFirmaUnica) {
		            $rootScope.firmaPrivacidad = "data:image/png;base64," + responseWV.imgB64[0].replace("data:image/png;base64,", "");
		            $rootScope.imgPrivacidad = responseWV.imgB64[0];
		            $rootScope.responseFirmaUnica = responseWV;
		            $scope.bloqueaInput = false;
		        } else {
		            $rootScope.imgPrivacidad = responseWV.img64;
		            $rootScope.firmaPrivacidad = "data:image/png;base64," + responseWV.imgB64[0].replace("data:image/png;base64,", "");
		            $rootScope.imgBuro = responseWV.img64;
		            $rootScope.firmaBuro = "data:image/png;base64," + responseWV.imgB64[1].replace("data:image/png;base64,", "");;
		        }
		    } else {
		        $scope.verAvisoPrivacidad = true;
		        $scope.verBuroCredito = false;
		    }
		};
		
		$scope.cerrar = function(){
			$scope.closeThisDialog();
			if($rootScope.isOrigenModal){
				generalService.locationPath("/ochoPasos");
				$rootScope.isOrigenModal = false;
			}else{
				$rootScope.actualizaTerminos();
				$rootScope.firmaUnica = undefined;
				$rootScope.message( "Nueva Originación Centralizada", ["Es necesario autorizar los términos y condiciones para continuar con la solicitud"], "Aceptar");
			}
		};
		
	});
});