'use strict';

define(["app"], function (app) {
	app.controller('visorSeccionContratosController', function($scope,  $rootScope, $location, $timeout, generalService, modalService){

		var tipoFirma = 1;
		var csstabs = {on:"tab dos cafeLi active", off:"tab dos cafeLi"};
		$scope.muestraTipoModalUnicaAutografa = true
		$scope.condicionMuestraContratos = $rootScope.contratosOriginacion;/** Variable para controlar que contrato se van a mostar, true AP y BC, false CC y SC**/
		$scope.bloquearBtnFirmar = true;
		var contadorVeces = 0;
	
		$scope.isAviso = true;
		$scope.isBuro = false;
		$scope.isCaratula = false;
		$scope.isSolicitud = false;
		/**
		 * Esta función la utilizan ambos flujos
		 **/
		$scope.init = function(){
			
			/**
			 * Estilos para los Tabs
			 **/
			$scope.tabSinFirmaCSS1 =  csstabs.on;
			$scope.tabSinFirmaCSS2 =  csstabs.off;
			$scope.tabSinFirmaCSS3 = csstabs.off;
			$scope.tabSinFirmaCSS4 = csstabs.off;
			$scope.tabSinFirmaCSS5 = csstabs.off;
			/**
			 * URL del contrato por default
			 * Esto aplica para estampar el html del contrato en la vista principal 
			 **/
			$scope.urlDoc = "AvisoPrivacidad.html";
			$scope.contratoView = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";
			
			/**
			 * La variable 'tabActivo' por default se toma el TAB de Aviso de Privacidad
			 * La variable 'visualizaContrato', true muestra el contrato en toda la pantalla, false, deja la vista de acuerdo al tipo de firma que se este realizando
			 **/
			$scope.tabActivo = 1;
			$scope.visualizaContrato = false;
			
			
			/** 
			 * Si es el primer bloque de contratos
			 * 'muestraContratos' Bander para habilitar el primer bloque de contratos a nivel de vista
			 * 'visualizaDoc' Se visualiza el primer documento AP por default
			 * 'tabActivo' El valor 1 corresponde al Aviso de Privacidad, esta variable es para dar estilo al TAB
			 * 'title' Titulo del PAD de firmas
			 **/
			$scope.muestraContratos = true;
			$scope.visualizaDoc("1");
			$scope.tabActivo = 1;
			$scope.title = "Firma Aviso Privacidad";
		};
		
		/**
		 * Esta función solo la utiliza la firma autografa
		 **/
		$scope.estilosTabs = function(tipoPersona){
			if(tipoPersona == 1){
				$scope.tabSinFirmaCSS1 =  csstabs.on;
				$scope.tabSinFirmaCSS2 =  csstabs.off;
				$scope.tabSinFirmaCSS3 = csstabs.off;
				$scope.tabSinFirmaCSS4 = csstabs.off;
				$scope.tabSinFirmaCSS5 = csstabs.off;
				$scope.tabActivo = 1;
				$scope.title = "Firma Aviso Privacidad";
			}else if(tipoPersona == 2){
				$scope.tabSinFirmaCSS1 =  csstabs.off;
				$scope.tabSinFirmaCSS2 =  csstabs.on;
				$scope.tabSinFirmaCSS3 = csstabs.off;
				$scope.tabSinFirmaCSS4 = csstabs.off;
				$scope.tabSinFirmaCSS5 = csstabs.off;
				$scope.tabActivo = 2;
				$scope.title = "Firma Consulta al Buró de Crédito";
			}else if(tipoPersona == 3){
				$scope.tabSinFirmaCSS1 =  csstabs.off;
				$scope.tabSinFirmaCSS2 =  csstabs.off;
				$scope.tabSinFirmaCSS3 = csstabs.on;
				$scope.tabSinFirmaCSS4 = csstabs.off;
				$scope.tabSinFirmaCSS5 = csstabs.off;
				$scope.tabActivo = 3;
				$scope.title = "Firma Contrato y Carátula de Crédito";
			}else if(tipoPersona == 4){
				$scope.tabSinFirmaCSS1 =  csstabs.off;
				$scope.tabSinFirmaCSS2 =  csstabs.off;
				$scope.tabSinFirmaCSS3 = csstabs.off;
				$scope.tabSinFirmaCSS4 = csstabs.on;
				$scope.tabSinFirmaCSS5 = csstabs.off;
				$scope.tabActivo = 4;
				$scope.title = "Firma Solicitud de Crédito";
			}else if(tipoPersona == 5){
				$scope.tabSinFirmaCSS1 =  csstabs.off;
				$scope.tabSinFirmaCSS2 =  csstabs.off;
				$scope.tabSinFirmaCSS3 = csstabs.off;
				$scope.tabSinFirmaCSS4 = csstabs.off;
				$scope.tabSinFirmaCSS5 = csstabs.on;
				$scope.tabActivo = 4;
				$scope.title = "Firma Anexo de Bienes";
			}
			
			/**
			 * Visualiza el documento dependiendo de la variable 'TipoPersona'
			 * 1 AP
			 * 2 BC
			 * 3 CC
			 * 4 SC
			 **/
			$scope.visualizaDoc(tipoPersona+"");
		}
		
		/**
		 * Esta función la utilizan ambos flujos
		 **/
		$scope.visualizaDoc =  function (id){
			switch (id){
				case "1":       	              	
		          	$scope.urlDoc = "AvisoPrivacidad.html";
		          	$scope.title = "Firma Aviso Privacidad";
				break;
				case "2":
					$scope.urlDoc = "BuroCredito.html";
					$scope.title = "Firma Consulta al Buró de Crédito";
				break;
				case "3":
					$scope.urlDoc = "ContratoCaratulaCredito.html";
					$scope.title = "Firma Contrato y Carátula de Crédito";
				break;
				case "4":
					$scope.urlDoc = "SolicitudCredito.html";
					$scope.title = "Firma Solicitud de Crédito";
				break;
				case "5":
					$scope.urlDoc = "AnexoBienes.html";
					$scope.title = "Firma Anexo de Bienes";
				break;
		        default:
		        	break;
			}
			
			/**
			 * Construye el Frame para incrustar un HTML dentro de otro HTML
			 **/
			$timeout( function(){construirIframe();}, 100 );
			
			/**
			 * Prepara el entorno para para agregar un html dentro de la vista principal
			 * 'contratoView' es la variable que contine la ruta del contrato
			 **/
			$scope.contratoView = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			
			/**
			 * 'muestraTipoModalUnicaAutografa' Variable para controlar el tipo de modal que se mostrará, true firma autografa, false, firma única
			 * 'contadorVeces' evita que al iniciar la vista, se visualice el contrato sin antes seleccionarlo
			 **/
			if(contadorVeces > 0){
				$scope.visualizaContrato = true;
			}else{
				contadorVeces++;
			}
		};
		
		/**
		 * Esta función la utilizan ambos flujos
		 **/
		var construirIframe = function(){
			/**
			 * Construye el frame con base al index principal
			 **/
			
			var divIframe = $( '#contenedor' );
			var iframe = document.createElement('iframe');

			iframe.height= "100%";
			iframe.width = "100%";
			iframe.id = "iframe";
			iframe.src = "pdf/web/viewer.jsp?urlDoc='" + $scope.urlDoc + "'";
			iframe.scrolling = "no";
			iframe.style.marginBottom = "15px";

			divIframe.append( iframe );
		};
		
		/**
		 * Esta función la utilizan ambos flujos
		 **/
		$scope.firmarContratos = function(numeroFirma){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			/**
			 * 'tipoFirma' contiene el número de firma, en caso de 
			 * 1 Firma normal
			 * 2 Segunda firma en el contrato de Solicitud de Crédito
			 * 3 Firma Única
			 **/
			tipoFirma = numeroFirma;
			
			/**
			 * Levanta el modal para firmar desde el iPad
			 **/
			modalService.firmas($scope.title).then(
				function(exito){
					$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
				},function(error){
					$scope.responseFirmaWV({codigo: 1, img64:null});
				}
			);
		}
		
		/**
		 * Esta función la utilizan ambos flujos
		 **/
		
		
		/**
		 * Esta función la utilizan ambos flujos
		 **/
		$scope.continuarSolicitud = function(){
			$scope.closeThisDialog();
			generalService.locationPath("/ochoPasos");
		}
		

		
		/**
		 * Esta función solo la utiliza la firma autografa
		 * Es para cerrar el modal sin nunguna accion
		 **/
		$scope.cancelar = function(){
			/*$rootScope.firmaPrivacidad = undefined;
			$rootScope.firmaBuro = undefined;
			$rootScope.firmaCaratula = undefined;
			$rootScope.firmaSolicitud = undefined;
			$rootScope.firmaSolicitudDos = undefined;
			$rootScope.firmaSolicitudDos = undefined;*/
			$scope.closeThisDialog();
			generalService.locationPath("/ochoPasos");
		};
		
		$scope.cerrar = function(){
			$scope.closeThisDialog();
			if($rootScope.isOrigenModal){
				generalService.locationPath("/ochoPasos");
				$rootScope.isOrigenModal = false;
			}else{
				$rootScope.actualizaTerminos();
				$rootScope.firmaUnica = undefined;
			}
		};
		
	});
});