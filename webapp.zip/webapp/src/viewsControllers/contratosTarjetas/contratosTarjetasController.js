'use strict';

define(["app"], function (app) {
	
	app.controller("contratosTarjetasController", function ($timeout, $scope, $rootScope, solicitudService, generalService, modalService, buroService, messageData, validateService, documentosService,tarjetaService, clienteUnicoService) {
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		$rootScope.imgPrivacidad = false;
		$scope.confTipoWindows = configuracion.so.windows;
		$scope.confTipoMuestra = false;
		$scope.vistos = false;
		$scope.preautorizado = false;
		$scope.contratoAceptado=[];
		var csstabs = {on:"tab tres cafeLi ", off:"tab tres cafeLi active"}; 
		$scope.tabFirmadoCSS =  csstabs.on;
		$scope.tabSinFirmaCSS =  csstabs.off;
		$scope.tabInformativosCSS = csstabs.off;
		$scope.firmados = true;
		$scope.firmaDocumentos=false;
		$scope.requiereAval= false;
		$scope.muestraseguro = true;
		
		if (configuracion.origen.tienda)
			$rootScope.validarTienda = true;
		else
			$rootScope.validarTienda = false;
		
		$scope.showTipoPersona = function(TipoPersona){
			
			if(TipoPersona == 1){
				$scope.tabFirmadoCSS =  csstabs.on;
				$scope.tabSinFirmaCSS =  csstabs.off;
				$scope.tabInformativosCSS = csstabs.off;
				$scope.firmados = 0;
			}else if (TipoPersona == 3){
				$scope.tabFirmadoCSS =  csstabs.off;
				$scope.tabSinFirmaCSS =  csstabs.on;
				$scope.tabInformativosCSS = csstabs.off;
				$scope.firmados = 1;
			}else{
				$scope.tabFirmadoCSS =  csstabs.off;
				$scope.tabSinFirmaCSS =  csstabs.off;
				$scope.tabInformativosCSS = csstabs.on;
				$scope.firmados = 2;
			}
		}
		$scope.validarTabs  = function(index){
			 if ($scope.firmados == 1 && ($scope.documentos[index].statusFirma == STATUS_CONTRATO.ENVIAD0 || $scope.documentos[index].statusFirma == STATUS_CONTRATO.FIRMADO_SIN_ENVIAR)  &&  $scope.documentos[index].idTipoPersona != 3){
				 return true;
			 }else{
				 if ($scope.firmados == 0 && $scope.documentos[index].statusFirma == STATUS_CONTRATO.SIN_FIRMA && $scope.documentos[index].idTipoPersona != 3){
					 return true;			
				 }else{
					 if ($scope.firmados == 2 && ($scope.documentos[index].statusFirma == STATUS_CONTRATO.INFORMATIVO || $scope.documentos[index].statusFirma == STATUS_CONTRATO.VISTO) && $scope.documentos[index].idTipoPersona != 3){
						 return true;			
					 }else{
						 return false;
					 }
				 }
			 }

		}		
		$scope.validarTabsFaltantes  = function(index){
			if (index > 1){
				return false;
			}else{
				 if ($scope.firmados == 1&& ($scope.documentos[index].statusFirma == STATUS_CONTRATO.ENVIAD0 || $scope.documentos[index].statusFirma == STATUS_CONTRATO.FIRMADO_SIN_ENVIAR)  &&  $scope.documentos[index].idTipoPersona != 3){
					 return true;
				 }else{
					 if ($scope.firmados == 0 && $scope.documentos[index].statusFirma == STATUS_CONTRATO.SIN_FIRMA && $scope.documentos[index].idTipoPersona != 3){
						 return true;			
					 }else{
						 if ($scope.firmados == 2 && $scope.documentos[index].statusFirma == STATUS_CONTRATO.INFORMATIVO && $scope.documentos[index].idTipoPersona != 3){
							 return true;			
						 }else{
							 return false;
						 }
					 }
				 }
				}

		}	
		$scope.pageClass = generalService.calculaVistas($rootScope.paginaActual,$rootScope.paginaAnterior,$rootScope.recuperaSolicitud);
		$scope.bloqueaSeccion = $rootScope.solicitudJson.contratos.editable;
	    $scope.vistaDatosUsuario=configuracion.datosUsuario.opcion=0;
		$scope.labelTiempo=generalService.labelTiempo;
		$scope.labelMin=generalService.labelMin;
		$scope.firma1 = false;
		var cont = 0;
		$scope.nombreContrato;
		$scope.urlDoc;
		$scope.contratos = [];
		$scope.porcentaje = ($rootScope.solicitudJson.contratos.porcentaje==100)?true:false;
		$scope.contratosAceptados = 0;
		$scope.esContrato = false;
		$scope.esSolicitud = false;
		$scope.continuarSiguiente = false;
		$scope.imgAdhesion = "";
		$scope.imgPagare = "";
		$scope.imgContrato = "";
		$scope.esContratos = true;
		$scope.marcaSolicitud = $rootScope.solicitudJson.marca;
		$rootScope.marcas = false;
		$scope._nombreSolicitud;
		$scope._nombreContrato;
		$scope.imgFirma;
		$scope.b64Firma;
		
		var nombreMes = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio","Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
		$rootScope.anioActual = new Date().getFullYear();
		$rootScope.mesActual = nombreMes[new Date().getMonth()];
		$rootScope.diaActual = new Date().getDate();
		
		try {
			var munDelDecod = decodeURIComponent(escape($rootScope.sucursalSession.poblacion.trim()));
		}
		catch(err) {
			var munDelDecod = $rootScope.sucursalSession.poblacion.trim();
		}

		$rootScope.lugarActual = ($rootScope.sucursalSession.estado == "Distrito Federal")?munDelDecod+", Ciudad de México":munDelDecod+", "+$rootScope.sucursalSession.estado;
		
		$scope.creditoInmediato = ($rootScope.solicitudJson.creditoInmediato == 0)?false:true;
		$scope.solicitudStatus = $rootScope.solicitudJson.idSeguimiento;
		$scope.contratoSeleccionado;	
		
		$rootScope.doc_details = {
				file_url: $scope.urlDoc
		};
		
		$scope.init = function(){
			$scope.showPage = true;
		
			if( messageData ){
				if( ($scope.solicitudStatus ==  STATUS_SOLICITUD.autorizada.id &&
					 ( $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.sinLiberar ||
				      $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.clienteVerdeJVC ||
					  $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.ejecutivo  ||
				      $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.expCompleto ||
				      $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.expValGerente ||
				      $scope.marcaSolicitud == STATUS_SOLICITUD.preautorizada.marca.fico )  /* <--CON EL TIEMPO QUITAR*/     
					) || $scope.solicitudStatus ==  STATUS_SOLICITUD.preautorizada.id ||  ($scope.solicitudStatus == STATUS_SOLICITUD.condicionada.id && $rootScope.solicitudJson.idCondicion == STATUS_SOLICITUD.condicionada.idCondicion.expIncompleto)){
						$scope.firmaDocumentos=true;
						$scope.requiereAval= true;
						$scope.firmados = false;
						$scope.preautorizado = true;
				}
//				else{
//					csstabs = {on:"tab dos cafeLi ", off:"tab dos cafeLi active"}; 
//					$scope.tabFirmadoCSS =  csstabs.off;
//					$scope.tabSinFirmaCSS = csstabs.on;
//					$scope.tabInformativosCSS = csstabs.off;
//					$scope.showTipoPersona(3);
//				}// END IF
			}else{/* END IF-ELSE MESSAGEDATA */
				$scope.firmaDocumentos=false;
				$scope.requiereAval= false;
			}
			$scope.cargaPagina();
			$timeout(function(){
				$scope.showPage = messageData;
			}, 1);
				
			$scope.setContentPage();
			 $scope.consultarCat();
			
		};/* END INIT FUNCITON */
		
		$scope.setContentPage = function()
	    {
	    	if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
	    	
	    	$scope.labelTiempo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO TIEMPO."+$scope.origen+".valor"];
			$scope.labelMin = " " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO MIN."+$scope.origen+".valor"];

	    	generalService.setMapping(  MODEL_VISTAS_JSON );
	    	
	    	$scope.txtRegresar = generalService.getDataInput("OCHO PASOS","TEXTO BOTON REGRESAR", $scope.origen);
	    	$scope._titulo = generalService.getDataInput("CONTRATOS","TITULO", $scope.origen);
	    	$scope._txtContratos = generalService.getDataInput("CONTRATOS","TEXTO CONTRATOS", $scope.origen);
	    	$scope._nombreSolicitud = generalService.getDataInput("CONTRATOS","TEXTO SOLICITUD CREDITO", $scope.origen);
	    	$scope._nombreContrato = generalService.getDataInput("CONTRATOS","TEXTO CONTRATO", $scope.origen);
	    	$scope._txtverDoc = generalService.getDataInput("CONTRATOS","TEXTO VER DOCUMENTO", $scope.origen);
	    	$scope._nombreAviso = generalService.getDataInput("AVISOS","TEXTO PRIVACIDAD", $scope.origen);
	    	$scope._nombreBuro = generalService.getDataInput("AVISOS","TEXTO BURO", $scope.origen);
	    	$scope._imgDocs = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.AVISOS.IMG DOCUMENTOS.URL.valor"];
	    	$scope._txtCheckContratos = generalService.getDataInput("CONTRATOS","TEXTO CHECK CONTRATOS", $scope.origen);
	    	$scope._titInfoContratos = generalService.getDataInput("CONTRATOS","TITULO INFO CONTRATOS", $scope.origen);
	    	$scope._infoInicialContratos = generalService.getDataInput("CONTRATOS","INFO INICIAL CONTRATOS", $scope.origen);
	    	$scope._infoInicialContratosAval = generalService.getDataInput("CONTRATOS","INFO INICIAL CONTRATOS", $scope.origen);
	    	$scope._infoListaContratos = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.CONTRATOS.INFO LISTA CONTRATOS"];
	    	$scope._infoFinalContratos = generalService.getDataInput("CONTRATOS","INFO FINAL CONTRATOS", $scope.origen);
	    	$scope._btnBorraFirma = generalService.getDataInput("CONTRATOS","BOTON BORRAR FIRMA", $scope.origen);
	    	$scope._btnContinuar = generalService.getDataInput("CONTRATOS","BOTON CONTINUAR", $scope.origen);
	    	$scope._docsPendientes = {texto: ""};
	    	$scope._docsFirmados = {texto: ""};
	    	$scope._docsPendientes.texto = "Docs. pendientes por firmar";
	    	$scope._docsFirmados.texto = "Docs. firmados";
	    	var str = $scope._infoInicialContratosAval.texto
	    	$scope._infoInicialContratosAval.texto = $scope._infoInicialContratosAval.texto.replace(/Cliente/g, "Aval");
			
	    	if ($rootScope.solicitudJson.contratos.contrato.length < 3){
	    		var index =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
	    			return d["id"];
	    			
	    		}).indexOf ("3");
	    		var index2 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
	    			return d["id"];
	    			
	    		}).indexOf ("4")
	    		if (index == -1 && index2 == -1){
	    			var firma1 = $rootScope.solicitudJson.contratos.contrato[0].statusFirma;
	    			var firma2 = $rootScope.solicitudJson.contratos.contrato[1].statusFirma;
	    		
	    			$rootScope.solicitudJson.contratos.contrato = 
	    				[{idContrato: "1",
	    					idPersona: "",
//	    					statusFirma: 1,
	    					statusFirma: $rootScope.solicitudJson.aceptaTerminos,
	    					descripcion: $scope._nombreAviso.texto,
	    					idTipoPersona: 1
	    				},
	    				{idContrato: "2",
	    					idPersona: "",
//	    					statusFirma: 1,
	    					statusFirma: $rootScope.solicitudJson.aceptaConsultaBuro,
	    					descripcion: $scope._nombreBuro.texto,
	    					idTipoPersona: 1
	    				},	
	    				{idContrato: "3",
	    					idPersona: "",
	    					statusFirma: firma1,
//	    					statusFirma: 1,
	    					descripcion: $scope._nombreContrato.texto,
	    					idTipoPersona: 1
	    				},
	    				{idContrato: "4",
	    					idPersona: "",
	    					statusFirma: firma2,
//	    					statusFirma: 1,
	    					descripcion: $scope._nombreSolicitud.texto,
	    					idTipoPersona: 1
	    				}
//	    				{idContrato: "3",
//	    					idPersona: "",
//	    					statusFirma: 0,
//	    					descripcion: $scope._nombreAviso.texto,
//	    					idTipoPersona: 3
//	    				},
//	    				{idContrato: "4",
//	    					idPersona: "",
//	    					statusFirma: 0,
//	    					descripcion: $scope._nombreBuro.texto,
//	    					idTipoPersona: 3}
	    				]
	    		}
	    	}
	    	var documentosFirmados = 0;
	    	$scope.totalPersona = 0;
	    	$scope.totalPersonaAval = 0;
	    	for(var i = 0; i < $rootScope.solicitudJson.contratos.contrato.length; i ++){
	    		if ($rootScope.solicitudJson.contratos.contrato[i].idTipoPersona == 1){
	    			$scope.totalPersona++
	    		}else{
	    			$scope.totalPersonaAval++
	    		}
	    		var firmaAval = 0;
	    		if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma != STATUS_CONTRATO.SIN_FIRMA && $rootScope.solicitudJson.contratos.contrato[i].statusFirma != STATUS_CONTRATO.INFORMATIVO/*|| $scope.contratoAceptado[i].firma == true*/){
	    			if ($rootScope.solicitudJson.banderaSolidario == 1){
	    				for(var e = 0; e < $rootScope.solicitudJson.contratos.contrato.length; e ++){
	    					if ($rootScope.solicitudJson.contratos.contrato[e].idContrato == $rootScope.solicitudJson.contratos.contrato[i].idContrato && $rootScope.solicitudJson.contratos.contrato[e].idTipoPersona == 3){
	    						if  ($rootScope.solicitudJson.contratos.contrato[e].statusFirma != STATUS_CONTRATO.SIN_FIRMA) 
	    							firmaAval = 1;
	    						else
	    							firmaAval = 2;
	    					}
	    				}
	    				
	    				switch (firmaAval){                                       
		                
		                case 0:
		                	$scope.contratoAceptado.push({firma: true, idContrato: $rootScope.solicitudJson.contratos.contrato[i].idContrato, idTipoPersona:  $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona});
	    					documentosFirmados++;
		                     break;
		                case 1: 
		                	$scope.contratoAceptado.push({firma: true, idContrato: $rootScope.solicitudJson.contratos.contrato[i].idContrato, idTipoPersona:  $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona});
	    					documentosFirmados++;
		                     break;
		                case 2:  
		                	$scope.contratoAceptado.push({firma: false, idContrato: $rootScope.solicitudJson.contratos.contrato[i].idContrato, idTipoPersona:  $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona});
	    					documentosFirmados++;
		                     break;
		    			}
	    				
	    				
//	    				if (firmaAval){
//	    					$scope.contratoAceptado.push({firma: true, idContrato: $rootScope.solicitudJson.contratos.contrato[i].idContrato, idTipoPersona:  $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona});
//	    					documentosFirmados++;
//	    				}else
//	    					$scope.contratoAceptado.push({firma: false, idContrato: $rootScope.solicitudJson.contratos.contrato[i].idContrato, idTipoPersona:  $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona});
	    					
	    			}else{
	    				$scope.contratoAceptado.push  ({firma: true, idContrato: $rootScope.solicitudJson.contratos.contrato[i].idContrato, idTipoPersona:  $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona});
	    				documentosFirmados++;
	    			}
	    		}else{
	    			$scope.contratoAceptado.push  ({firma: false, idContrato: $rootScope.solicitudJson.contratos.contrato[i].idContrato, idTipoPersona:  $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona});
	    		}
	    		if ($rootScope.solicitudJson.contratos.contrato[i].descripcion == "" || !$rootScope.solicitudJson.contratos.contrato[i].descripcion)
	    			switch ($rootScope.solicitudJson.contratos.contrato[i].idContrato){                                       
	                
	                case "1":
	                	$rootScope.solicitudJson.contratos.contrato[i].descripcion =  $scope._nombreAviso.texto;
	                     break;
	                case "2": 
	                	$rootScope.solicitudJson.contratos.contrato[i].descripcion =  $scope._nombreBuro.texto;
	                     break;
	                case "3":  
	                	$rootScope.solicitudJson.contratos.contrato[i].descripcion = $scope._nombreContrato.texto;
	                     break;
	                case "4":  
	                	$rootScope.solicitudJson.contratos.contrato[i].descripcion = $scope._nombreSolicitud.texto;
	                     break;
	    			}
	    			
	    	}
	    	if ($rootScope.solicitudJson.contratos.contrato.length == documentosFirmados){
	    		$scope.requiereAval= false;
	    		$scope.firmados = true;
	    		if ($scope.preautorizado){
	    			csstabs = {on:"tab dos cafeLi ", off:"tab dos cafeLi active"}; 
	    			$scope.tabFirmadoCSS =  csstabs.off;
	    			$scope.tabSinFirmaCSS = csstabs.on;
	    			$scope.tabInformativosCSS = csstabs.off;
	    			$scope.showTipoPersona(3);
	    		}
	    	}
//	    		else
//	    		$scope.firmados = false;
	    	$scope.documentos = JSON.parse(generalService.delete$$hashKey($rootScope.solicitudJson.contratos.contrato));
	    	for (var i = 0; i < $scope.documentos.length; i++){
	    		if (!$scope.contratoAceptado[i].firma){
	    			if ($scope.documentos[i].statusFirma == STATUS_CONTRATO.INFORMATIVO || $scope.documentos[i].statusFirma == STATUS_CONTRATO.VISTO){
	    				
	    			}else{
	    				$scope.documentos[i].statusFirma = STATUS_CONTRATO.SIN_FIRMA;
	    			}
	    		} 
	    	}
	    	if(($rootScope.solicitudJson.contratos.contrato[0].statusFirma  == 0 || $rootScope.solicitudJson.contratos.contrato[1].statusFirma  == 0) && !$scope.firmaDocumentos){
	    		$scope.faltantes = true;
	    	}
	    		
	    };/* END SET_CONTENT_PAGE FUNCTION */	    
		
		var construirIframe = function()
		{
			
			var divIframe = $( '#contenedor' );
			var iframe = document.createElement('iframe');

			iframe.height= "100%";
			iframe.width = "100%";
			iframe.id = "iframe";
			iframe.src = "pdf/web/viewer.jsp?urlDoc='" + $scope.urlDoc + "'";//"pdf/webvi?" + ngDialogData.estiloTitulo;
			iframe.scrolling = "no";
			iframe.style.marginBottom = "15px";

			divIframe.append( iframe );
			
		};
				
		$scope.cargaPagina = function(){
				if (configuracion.origen.tienda)
					$scope.origen="TIENDA";
				else
					$scope.origen="WEB";
			
				generalService.setMapping( MODEL_VISTAS_JSON );
				
				$scope.banderaModal = true;
				
				$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo más tarde";
				generalService.setRespaldo($rootScope.solicitudJson);
				$scope.showFirmaAval = false;
				$scope.click = false;
				
				if ($rootScope.solicitudJson.contratos.contrato[0].statusFirma == STATUS_CONTRATO.ENVIAD0 || $rootScope.solicitudJson.contratos.contrato[1].statusFirma == STATUS_CONTRATO.ENVIAD0 ||
						$rootScope.solicitudJson.contratos.contrato[0].statusFirma == STATUS_CONTRATO.FIRMADO_SIN_ENVIAR || $rootScope.solicitudJson.contratos.contrato[1].statusFirma == STATUS_CONTRATO.FIRMADO_SIN_ENVIAR){
					$scope.contratosAceptados = 2;
					$scope.esSolicitud = true;
					$scope.esContrato = true;
					$scope.Ipad = false;
					$scope.firma1 = false;							
				}else{
					$scope.firma1 = false;	
				}

				$scope.firma1Ant = $rootScope.solicitudJson.contratos.contrato[0].statusFirma;
				$scope.idPersona1Ant = $rootScope.solicitudJson.contratos.contrato[0].idPersona;
				$scope.firma2Ant = $rootScope.solicitudJson.contratos.contrato[1].statusFirma;
				$scope.idPersona2Ant = $rootScope.solicitudJson.contratos.contrato[1].idPersona;
				
				$scope.nombreCte = $scope.solicitudJson.cotizacion.clientes[0].nombre +" " +$scope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+" " +$scope.solicitudJson.cotizacion.clientes[0].apellidoMaterno;
				
				if($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto >= MONTO_PP_AVAL){
					$scope.nombreAval = $scope.solicitudJson.avales[0].nombre +" " +$scope.solicitudJson.avales[0].apellidoPaterno +" " +$scope.solicitudJson.avales[0].apellidoPaterno
					$scope.showFirmaAval = true;							
				}
				
				$scope.contratos();
				$scope.marcasSoliciud();
		
		}
			
		$scope.marcasSoliciud = function (){			
			if(($scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.sinLiberar && $scope.solicitudStatus == STATUS_SOLICITUD.autorizada.id)
				||($scope.solicitudStatus == STATUS_SOLICITUD.condicionada.id && $rootScope.solicitudJson.idCondicion == STATUS_SOLICITUD.condicionada.idCondicion.expIncompleto)){
				$rootScope.marcas = true;
			} else if(($scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.expCompleto || $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.expValGerente) && $scope.solicitudStatus == STATUS_SOLICITUD.autorizada.id ){
				$rootScope.marcas = true;
			} else {
				$rootScope.marcas = false;
			}
				
		}	
			
		$scope.validaContratos = function(){			
			var totalPersona = 0;
			var contratosMuestra = true; 
			var contratosAval = true;
			var validaAval = false;
			$scope.muestraFirmaContrato = false;	
			for(var i = 0; i < $rootScope.solicitudJson.contratos.contrato.length; i ++){
				
	    		if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.SIN_FIRMA && !$scope.contratoAceptado[i].firma == true && $scope.contratoAceptado[i].idTipoPersona != 3){
	    			if (i == 0 || i == 1)
	    				continue;
	    			else
	    				contratosMuestra = false;

	    		}else{
	    			if ($scope.contratoAceptado[i].idTipoPersona == 3)
	    				validaAval = true;
	    			else
	    				if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma != STATUS_CONTRATO.SIN_FIRMA)
	    					totalPersona++
	    		}
	    	}
			//--------------------------------------------------------------------------------------------------------------------------
			if ( contratosMuestra && $scope.totalPersona != totalPersona){				
				$scope.muestraFirmaContrato = true;	
																				
				var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
					return d["idContrato"];
			    			
				}).indexOf (FIRMA_SEGURO_CLIENTE.id);
				if (index3 != -1){
					$scope.muestraseguro = false;
				}else{
					$scope.muestraseguro = true;
					}
				
				var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
					return d["idContrato"];
			    			
				}).indexOf (FIRMA_PRIVACIDAD_ID);
				if (index3 != -1){
					if ($scope.contratoAceptado[index3].firma && $rootScope.solicitudJson.contratos.contrato[index3].statusFirma == STATUS_CONTRATO.SIN_FIRMA)
						$scope.avisoFirmado = true;
				}else{
					$scope.avisoFirmado = false;
					}
				
				
				var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
					return d["idContrato"];
			    			
				}).indexOf (FIRMA_SEGURO_CARTA.id);
				
				if($rootScope.validarTienda){
					if($rootScope.firmaCaratula && $rootScope.firmaSolicitud && !$scope.muestraseguro2 && $scope.muestraseguro ){
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:$rootScope.firmaCaratula});
					}
				}else{
					if( $scope.confTipoWindows && !$scope.muestraseguro2 && $scope.muestraseguro ){	
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						$rootScope.capturarFirmaWV("firmas","responseFirmaWV",{titulo: $scope.tituloFirma});
					}else{
						if(!$scope.muestraseguro2 && $scope.muestraseguro){
						modalService.firmas($scope.tituloFirma)
						.then(
								function(exito){
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
								},function(error){
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									$scope.responseFirmaWV({codigo: 1});
								});
						}
					}
				}
			}
			//--------------------------------------------------------------------------------------------------------------------------
			if (validaAval){ 
				for(var a = 0; a <$scope.contratoAceptado.length; a ++){
					if ($scope.contratoAceptado[a].idTipoPersona == 3){ 
						if($scope.contratoAceptado[a].firma){
							contratosAval = false;
						}else{
							for(var i = 0; i <$scope.contratoAceptado.length; i ++){
								if ($scope.contratoAceptado[a].idContrato == $scope.contratoAceptado[i].idContrato  && !$scope.contratoAceptado[i].firma &&  $scope.contratoAceptado[i].idTipoPersona == 1){
									contratosAval = false;								
								}
							}
						}
					}
				}
			}
			//--------------------------------------------------------------------------------------------------------------------------
			var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
				return d["idContrato"];
		    			
			}).indexOf (FIRMA_SEGURO_CLIENTE.id);
			if (index3 != -1){
				if ($scope.contratoAceptado[index3].firma && $rootScope.solicitudJson.contratos.contrato[index3].statusFirma == STATUS_CONTRATO.SIN_FIRMA){		
					$scope.muestraseguro = false;
					
					if($rootScope.validarTienda){
						if($rootScope.imgSeguroCliente && !$scope.firma1){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:$rootScope.imgSeguroCliente});
						}
					}else{
						if( $scope.confTipoWindows && !$scope.firma1){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							$rootScope.capturarFirmaWV("firmas","responseFirmaWV",{titulo:$scope.tituloFirma});
						}else{
							if(!$scope.firma1){
								modalService.firmas($scope.tituloFirma)
								.then(
										function(exito){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
										},function(error){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$scope.responseFirmaWV({codigo: 1});
										});
								}
						}
					}
				}else{
					$scope.muestraseguro = true;
					$scope.muestraFirmaContrato = false;
				}
			}
			//--------------------------------------------------------------------------------------------------------------------------
			var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
				return d["idContrato"];
		    			
			}).indexOf (FIRMA_SEGURO_CARTA.id);
			if (index3 != -1){
				if ($scope.contratoAceptado[index3].firma && $rootScope.solicitudJson.contratos.contrato[index3].statusFirma == STATUS_CONTRATO.SIN_FIRMA){	
					$scope.muestraseguro2 = true;
					
					if($rootScope.validarTienda){
						if($rootScope.imgSeguroCarta && !$scope.firma2){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							$scope.responseFirmaSeguro({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:$rootScope.imgSeguroCarta});
						}
					}else{
						if( $scope.confTipoWindows && !$scope.firma2){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							$rootScope.capturarFirmaWV("firmas","responseFirmaWV",{titulo:$scope.tituloFirma});
						}else{
							if(!$scope.firma2){
								modalService.firmas($scope.tituloFirma)
								.then(
										function(exito){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$scope.responseFirmaSeguro({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
										},function(error){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$scope.responseFirmaSeguro({codigo: 1});
										});
								}
						}
					}
				}
			}
			//--------------------------------------------------------------------------------------------------------------------------
			var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
				return d["idContrato"];
		    			
			}).indexOf (FIRMA_PRIVACIDAD_ID);
			if (index3 != -1){
				if ($scope.contratoAceptado[index3].firma && $rootScope.solicitudJson.contratos.contrato[index3].statusFirma == STATUS_CONTRATO.SIN_FIRMA)
					$scope.avisoFirmado = true;
				if($rootScope.validarTienda){
					if($rootScope.imgPrivacidad && !$scope.firma2){
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						$scope.responseFirmaSeguro({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:$rootScope.imgPrivacidad});
					}
				}else{
					if( $scope.confTipoWindows && !$scope.firma1){
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						$rootScope.capturarFirmaWV("firmas","responseFirmaWV",{titulo:$scope.tituloFirma});
					}else{
						if(!$scope.firma2){
							modalService.firmas($scope.tituloFirma)
							.then(
									function(exito){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$scope.responseFirmaSeguro({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
									},function(error){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$scope.responseFirmaSeguro({codigo: 1});
									});
							}
					}
				}
			}else{
				$scope.avisoFirmado = false;
			}
			//--------------------------------------------------------------------------------------------------------------------------
			var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
				return d["idContrato"];
		    			
			}).indexOf (FIRMA_BURO_ID);
			if (index3 != -1){
				if ($scope.contratoAceptado[index3].firma && $rootScope.solicitudJson.contratos.contrato[index3].statusFirma == STATUS_CONTRATO.SIN_FIRMA)
					$scope.buroFirmado = true;
				if($rootScope.validarTienda){
					if($rootScope.imgBuro && !$scope.firma3){
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						$scope.responseBuro({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:$rootScope.imgBuro});
					}
				}else{
					if( $scope.confTipoWindows && !$scope.firma2){
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						$rootScope.capturarFirmaWV("firmas","responseFirmaWV",{titulo:$scope.tituloFirma});
					}else{
						if(!$scope.firma2){
							modalService.firmas($scope.tituloFirma)
							.then(
									function(exito){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$scope.responseFirmaSeguro({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
									},function(error){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$scope.responseFirmaSeguro({codigo: 1});
									});
							}
					}
				}
			}else{
				$scope.avisoFirmado = false;
			}
			
			//--------------------------------------------------------------------------------------------------------------------------
			if (contratosAval && $rootScope.solicitudJson.banderaSolidario == 1 && $scope.totalPersonaAval > 0){
				$scope.muestraFirmaContratoAval = true;				
				if( $scope.confTipoWindows  ){
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					$rootScope.capturarFirmaWV("firmas","responseFirmaWV",{titulo: $scope.tituloFirma});
				}else{
					modalService.firmas($scope.tituloFirma)
					.then(
							function(exito){
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
							},function(error){
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$scope.responseFirmaWV({codigo: 1});
							});
				}
					
			}
		}
	    
		
		$scope.responseBuro = function(responseWV){
			$rootScope.loggerIpad("responseburo", null, responseWV);
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
//					if($scope.muestraFirmaContrato)
//				$scope.b64Firma = responseWV.img64;
//					else
//						$scope.b64Firma2 = responseWV.img64;
				$scope.firma3 = true;				
			}else{	
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(!$scope.muestraseguro){
					var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
						return d["idContrato"];
				    			
					}).indexOf (FIRMA_SEGURO_CLIENTE.id);
					if (index3 != -1){
						$scope.contratoAceptado[index3].firma = false;
						$scope.muestraseguro = true;
						$scope.muestraFirmaContrato = false;
					}
				}else{
					for (var l = 0; l < $rootScope.solicitudJson.contratos.contrato.length; l++){
						if ($rootScope.solicitudJson.contratos.contrato[l].statusFirma == STATUS_CONTRATO.SIN_FIRMA && $scope.contratoAceptado[l].firma == true){
							$scope.contratoAceptado[l].firma  = false;
							$scope.muestraFirmaContrato = false;	
						} 
						
					}
				} 
			}
						
							
		};
		$scope.responseFirmaWV = function(responseWV){
			$rootScope.loggerIpad("responseFirmaWV", null, responseWV);
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
//					if($scope.muestraFirmaContrato)
				$scope.b64Firma = responseWV.img64;
//					else
//						$scope.b64Firma2 = responseWV.img64;
				$scope.firma1 = true;	
				
			}else{	
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(!$scope.muestraseguro){
					var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
						return d["idContrato"];
				    			
					}).indexOf (FIRMA_SEGURO_CLIENTE.id);
					if (index3 != -1){
						$scope.contratoAceptado[index3].firma = false;
						$scope.muestraseguro = true;
						$scope.muestraFirmaContrato = false;
					}
				}else{
					for (var l = 0; l < $rootScope.solicitudJson.contratos.contrato.length; l++){
						if ($rootScope.solicitudJson.contratos.contrato[l].statusFirma == STATUS_CONTRATO.SIN_FIRMA && $scope.contratoAceptado[l].firma == true){
							$scope.contratoAceptado[l].firma  = false;
							$scope.muestraFirmaContrato = false;	
						} 
						
					}
				} 
			}
						
							
		};
		$scope.responseFirmaSeguro = function(responseWV){
			$rootScope.loggerIpad("responseFirmaSeguro", null, responseWV);
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
				$scope.b64FirmaSeguro = responseWV.img64;
				
				$scope.firma2 = true;				
			}else{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
					return d["idContrato"];
			    			
				}).indexOf (FIRMA_SEGURO_CARTA.id);
				if (index3 != -1){
					$scope.contratoAceptado[index3].firma = false;
					$scope.muestraseguro2 = false;
				}
				
			}
							
		};
					
		
		
		$scope.increment = function(id) {
			if ($scope.id == "canvas1"){
				$scope.firma1 = true;
			}
			
			$scope.$digest();
		};
		
		$scope.funcionMover=function(){
			if($scope.click)
				$scope.firma1=true;		
		}
		$scope.funcionMover2=function(){
			if($scope.click)
				$scope.firma2=true;		
		}
		
		$scope.miFuncion=function(){
			console.log(document.getElementById("canvas1"));
			console.log(document.getElementById("canvas1").toDataURL("image/png"));
			$scope.fasd = 2;
		}
		
		$scope.contratos = function(){
		    $('.contratos').each(function(){  
		        var highestBox = 0;
		        $('.texto').css('height', '');
		        $(this).find('.texto').each(function(){
		        	
		        	console.log( $(this).outerHeight() + " <-> " +  highestBox );
		        	
		            if( $(this).outerHeight() > highestBox){  
		                highestBox = $(this).outerHeight();  
		            }
		        })
		        $(this).find('.texto').height(highestBox);
		    });
		}
	
		$scope.guardar = function(){
			var porcentajeant = $rootScope.solicitudJson.contratos.porcentaje;
					
			$scope.DatosAntariores = function(){
				$rootScope.solicitudJson.contratos.contrato[0].statusFirma = $scope.firma1Ant;
                $rootScope.solicitudJson.contratos.contrato[0].idPersona = $scope.idPersona1Ant;
                $rootScope.solicitudJson.contratos.contrato[1].statusFirma = $scope.firma2Ant;
                $rootScope.solicitudJson.contratos.contrato[1].idPersona = $scope.idPersona2Ant;
                $rootScope.solicitudJson.contratos.porcentaje = parseInt(porcentajeant);
			}
			
			$rootScope.solicitudJson.contratos.porcentaje = cuentatext('contratosDiv');
			
			
			if ($scope.firma1 == true){	
				for(var i = 0; i < $rootScope.solicitudJson.contratos.contrato.length; i ++){
		    		if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.SIN_FIRMA && $scope.contratoAceptado[i].firma == true && $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona != 3){
		    			if (!($rootScope.solicitudJson.contratos.contrato[i].idContrato == FIRMA_SEGURO_CLIENTE.id || $rootScope.solicitudJson.contratos.contrato[i].idContrato == FIRMA_SEGURO_CARTA.id) ){
		    				$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.FIRMADO_SIN_ENVIAR;
		    				$rootScope.solicitudJson.contratos.contrato[i].idPersona = $rootScope.solicitudJson.cotizacion.clientes[0].idPersona;
		    			}
		    		}
//		    		else{
//		    			if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma != 0 && $scope.contratoAceptado[i].firma == true && $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona != 3){
//		    				$rootScope.solicitudJson.contratos.contrato[i].statusFirma = 0;
//		    				$rootScope.solicitudJson.contratos.contrato[i].idPersona = "";
//		    			}
//		    		}
				}
				var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
					return d["idContrato"];
					
				}).indexOf (FIRMA_SEGURO_CLIENTE.id);
				if (index3 != -1){
					$rootScope.solicitudJson.contratos.contrato[index3].statusFirma = STATUS_CONTRATO.FIRMADO_SIN_ENVIAR;
    				$rootScope.solicitudJson.contratos.contrato[index3].idPersona = $rootScope.solicitudJson.cotizacion.clientes[0].idPersona;
				}
			}
																
			if ($scope.firma2 == true){	
				for(var i = 0; i < $rootScope.solicitudJson.contratos.contrato.length; i ++){
		    		if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.SIN_FIRMA  && $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona == 3){
		    			
		    			$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.FIRMADO_SIN_ENVIAR;
						$rootScope.solicitudJson.contratos.contrato[i].idPersona = $rootScope.solicitudJson.cotizacion.clientes[0].idPersona;
		    		}
//		    		else{
//		    			if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma != 0  && $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona == 3){
//		    				$rootScope.solicitudJson.contratos.contrato[i].statusFirma = 0;
//		    				$rootScope.solicitudJson.contratos.contrato[i].idPersona = "";
//		    			}
//		    		}
		    	}
				
				if ($rootScope.solicitudJson.contratos.contrato[0].statusFirma == STATUS_CONTRATO.SIN_FIRMA && $scope.contratoAceptado[0].firma == true && $rootScope.solicitudJson.contratos.contrato[0].idTipoPersona != 3){
    				$rootScope.solicitudJson.contratos.contrato[0].statusFirma = STATUS_CONTRATO.FIRMADO_SIN_ENVIAR;
    				$rootScope.solicitudJson.contratos.contrato[0].idPersona = $rootScope.solicitudJson.cotizacion.clientes[0].idPersona;
				}
//		    		else{
//		    			if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma != 0 && $scope.contratoAceptado[i].firma == true && $rootScope.solicitudJson.contratos.contrato[i].idTipoPersona != 3){
//		    				$rootScope.solicitudJson.contratos.contrato[i].statusFirma = 0;
//		    				$rootScope.solicitudJson.contratos.contrato[i].idPersona = "";
//		    			}
//		    		}
//				}
				
				var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
					return d["idContrato"];
			    			
				}).indexOf (FIRMA_SEGURO_CARTA.id);
				if (index3 != -1){
					$rootScope.solicitudJson.contratos.contrato[index3].statusFirma = STATUS_CONTRATO.FIRMADO_SIN_ENVIAR;
					$rootScope.solicitudJson.contratos.contrato[index3].idPersona = $rootScope.solicitudJson.cotizacion.clientes[0].idPersona;
				}
				
			}
			if ($scope.firma3){
				if ($rootScope.solicitudJson.contratos.contrato[1].statusFirma == STATUS_CONTRATO.SIN_FIRMA && $scope.contratoAceptado[1].firma == true && $rootScope.solicitudJson.contratos.contrato[1].idTipoPersona != 3){
					$rootScope.solicitudJson.contratos.contrato[1].statusFirma = STATUS_CONTRATO.FIRMADO_SIN_ENVIAR;
    				$rootScope.solicitudJson.contratos.contrato[1].idPersona = $rootScope.solicitudJson.cotizacion.clientes[0].idPersona;
				}
			}
			var contador = 0;
    		var firmadosDocs = 0;
			if ($scope.vistos){
				for(var i = 0; i < $rootScope.solicitudJson.contratos.contrato.length; i ++){
					if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.INFORMATIVO)
						$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.VISTO;
				}
			}
				
    		
			for(var i = 0; i < $rootScope.solicitudJson.contratos.contrato.length; i ++){
    			if ($rootScope.solicitudJson.banderaSolidario == 1){
    				contador++;
    				if (!($rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.SIN_FIRMA || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.INFORMATIVO)){
    					firmadosDocs++;
    				}else if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.VISTO){
    					firmadosDocs++;
    				}		    				
    			}else{
    				if ($rootScope.solicitudJson.contratos.contrato[i].idTipoPersona != 3){
	    				contador++;
	    				if (!($rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.SIN_FIRMA || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.INFORMATIVO)){
	    					firmadosDocs++;
	    				}else if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.VISTO){
	    					firmadosDocs++;
	    				}	
    				}
    			}
    			if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.INFORMATIVO && $scope.vistos)
    				$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.VISTO;
    			
    		}
			
			
			    
    		$rootScope.solicitudJson.contratos.porcentaje = parseInt(((firmadosDocs * 100) / contador).toFixed(0));
			
			if (offLine){				
				$rootScope.cargaDocumentos();
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.porcentajes.secciones[7].porcentaje = $rootScope.solicitudJson.contratos.porcentaje;
				generalService.locationPath("/ochoPasos");
			}else{
				
				if(!generalService.isEmpty($rootScope.firmaCaratula) && $rootScope.isContratoCaratula == true){
					var biometrico = {
						ruta: null,
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						cadena: $rootScope.firmaCaratula.replace("data:image/png;base64,","").trim(),
						tipoCadena: FIRMA_CARATULA_CLIENTE.descripcion,
						porcentaje: 100
					}
					
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					clienteUnicoService.setBiometrico( biometrico ).then(
						function(data){
							
							if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
								var responseJson = JSON.parse(data.data.respuesta);
								
								if(responseJson.codigo == 2){
									for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
										if($rootScope.solicitudJson.contratos.contrato[i].idContrato === "4"){
											$rootScope.solicitudJson.contratos.contrato[i].statusFirma = 1;
											break;
										}
									}
									
									procesarFirma();
								}else{
									$rootScope.message("Error",["Ocurrió un error al guardar la solicitud, por favor, reintente."], "Aceptar", null, "bgRosa" , "btnRosaD");							
								}
							}else{
								$rootScope.message("Error",["Ocurrió un error al guardar la solicitud, por favor, reintente."], "Aceptar", null, "bgRosa" , "btnRosaD");
							}
				
						},function(error){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$rootScope.message("Error",["Ocurrió un error al guardar la solicitud, por favor, reintente."], "Aceptar", null, "bgRosa" , "btnRosaD");
						}
					);
				}else{
					procesarFirma();
				}
			
		}
		};
		
		function guardaFirmaFaltante(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($rootScope.solicitudJson), seccion: 8 } ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;

					if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
						var responseJson = JSON.parse(data.data.respuesta);
						
						if(responseJson.codigo == 2){
							if ($scope.origen == "TIENDA" && (configuracion.so.ios || configuracion.so.windows)){
								$scope.enviaContratos();
							}
							$rootScope.solicitudJson = responseJson.data;	
							$rootScope.porcentajes.secciones[7].porcentaje = $rootScope.solicitudJson.contratos.porcentaje;
							$rootScope.calculaDocumentos();
							buroService.consultaBuro("bgRosa", "btn gris", "btn btnRosaD" );
						}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
							var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
							$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
						}else{
							if(responseJson.codigo == ERROR_SOL_RECHAZADA){
								var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
								var marca = $rootScope.solicitudJson.marca;
								var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
								var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
								$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],
										"Aceptar", "/simulador",  "bgRosa" , "btnRosaD",buildJsonDefault);
							}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
								generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
								generalService.locationPath("/ficha");
							}else{
								$scope.DatosAntariores();
								$rootScope.message($scope._titulo.texto,[$scope.mensajeError], "Aceptar", null, "bgRosa", "btnRosaD");
							}
						}
					}else{
						$scope.DatosAntariores();
						$rootScope.message($scope._titulo.texto,["Error en la respuesta del servicio para guardar los datos de la sección de Contratos. Por favor, reintente nuevamente."], "Aceptar", null, "bgRosa", "btnRosaD");
					}
					
				}, function(error){
					$scope.DatosAntariores();
	                $rootScope.waitLoaderStatus = LOADER_HIDE;
				}
			);
		}
		
		
		$scope.enviaContratos = function(){
			 $rootScope.contratosResponseCita = false;
			$rootScope.executeAction( "firmas", "respuestaContratos",  
					  { nombre:"envioDocumentos", idCliente:$rootScope.solicitudJson.cotizacion.clientes[0].idPersona, mostrarSpinner:0, 
                      filtroDocumentos: CONTRATOS_ENVIAR+","+FIRMA_PRIVACIDAD.descripcion+","+FIRMA_BURO.descripcion+","+FIRMAR_CTE_CONTRATOS_TARJETA });
		}
		$rootScope.respuestaContratos = function(respuesta){
			$rootScope.contratosResponseCita = true;
			$rootScope.loggerIpad("respuestaContratos", null, respuesta);
			console.log(respuesta);
		}
		$scope.visualizaDoc =  function (value,visualizar){
			$rootScope.isAviso = undefined;
			$rootScope.isBuro = undefined;
			$rootScope.isContratoCaratula = undefined;
			$rootScope.isSolicitud = undefined;
			$rootScope.isSeguroCliente = undefined;
			$rootScope.isSeguroCarta = undefined;
			
			$rootScope.contratoIndex = visualizar;
			$scope.contratoSeleccionado = value;
			
			var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
    			return d["idContrato"];
    			
    		}).indexOf (value);
			if (index3 >= 0)
				$scope.firma1Ant = $scope.documentos[index3].statusFirma 
//					$rootScope.solicitudJson.contratos.contrato[index3].statusFirma;
			$scope.muestraAvisos = false;
			switch (value){
            
            case "1": 
            	$scope.tituloAviso = generalService.getDataInput("CONTRATOS","TITULO MODAL CONTRATOS 1", $scope.origen);
				$scope.urlDoc = "AvisoPrivacidad.html";
				$rootScope.isAviso = true;
				$rootScope.title = "Firma Aviso de Privacidad";
				$scope.negacionCheck = {texto:"No consiento la firma de este documento", visible: false, textoMensaje:"", botonAceptar: "Aceptar"};
                 break;
            case "2":  
            	$scope.tituloAviso = generalService.getDataInput("CONTRATOS","TITULO MODAL CONTRATOS 2", $scope.origen);
				$scope.urlDoc = "BuroCredito.html";
				$rootScope.isBuro = true;
				$rootScope.title = "Firma Buro de Crédito";
				$scope.negacionCheck = {texto:"No consiento la firma de este documento", visible: false, textoMensaje:"", botonAceptar: "Aceptar"};
                 break;
            case "3":  
            	$scope.tituloAviso = {texto:"Solicitud de la Tarjeta de Crédito "+ $rootScope.camelize( $rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc )};
            	$scope.tituloFirma = "Solicitud de la Tarjeta de Crédito "+ $rootScope.camelize( $rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc );
            	$scope.urlDoc = ($rootScope.solicitudJson.idProducto != 28)?"SolicitudTarjetaCredito.html":"SolicitudTarjetaCreditoTEC.html";
				$scope.muestraAvisos = true;
				$rootScope.isSolicitud = true;
				$rootScope.title = ($rootScope.solicitudJson.idProducto != 28)?"Firma Solicitud de la Tarjeta de Crédito "+ $rootScope.camelize( $rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc ):"Firma Solicitud de la Tarjeta de Credito TEC";
				$scope.negacionCheck ={texto:"No consiento la firma de este documento", visible: true, textoMensaje: " la Solicitud de la Tarjeta de crédito.", botonAceptar: "Aceptar" };
                 break;
            case "4":  
            	$scope.tituloAviso = {texto:"Contrato de la Tarjeta de Crédito "+ $rootScope.camelize( $rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc )};
            	$scope.tituloFirma = "Contrato de la Tarjeta de Crédito "+ $rootScope.camelize( $rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc );
            	$scope.urlDoc = ($rootScope.solicitudJson.idProducto != 28)?"ContratoTarjetaCredito.html":"ContratoTarjetaCreditoTEC.html";
				$rootScope.isContratoCaratula = true;
				$rootScope.title = "Firma Contrato de la Tarjeta de Crédito "+ $rootScope.camelize( $rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc );
				$scope.negacionCheck = {texto:"No consiento la firma de este documento", visible: true, textoMensaje: "l Contrato de  la Tarjeta de Crédito. ", botonAceptar: "Aceptar"};
                 break;
            case FIRMA_SEGURO_CLIENTE.id:  
            	$scope.tituloAviso = {texto: "Certificado Seguro Vidamax"};
            	$scope.tituloFirma= "Acepto Seguro VidaMax";
				$scope.urlDoc = "Certificado Vidamax.html";
				$rootScope.isSeguroCliente = true;
				$rootScope.title = "Firma Seguro Vidamax";
				$scope.negacionCheck ={texto:"No acepto contrato de Seguro VidaMax", visible: true, textoMensaje:"l Seguro VidaMax.", botonAceptar: "Aceptar Seguro" }; 
                 break;
            case FIRMA_SEGURO_CARTA.id: 
            	$scope.tituloFirma="Carta Instrucción";
            	$scope.tituloAviso = {texto: "Carta Instrucción"};
            	$scope.urlDoc = "Carta de 14 semanas de atraso Vidamax.html";
				$rootScope.isSeguroCarta = true;
				$rootScope.title = "Firma Seguro Vidamax";
				$scope.negacionCheck = {texto:"No acepto Carta Instrucción", visible: true, textoMensaje:"l Atraso Vidamax.", botonAceptar: "Aceptar"} 
                break;
            case FIRMA_CARATULA_TARJETA.id: 
            	$scope.tituloFirma=FIRMA_CARATULA_TARJETA.etiqueta;
            	$scope.tituloAviso = {texto: FIRMA_CARATULA_TARJETA.etiqueta};
            	$scope.urlDoc = ($rootScope.solicitudJson.idProducto != 28)?"CaratulaCreditotarjeta.html":"CaratulaCreditotarjetaTEC.html";
				$rootScope.isCaratulaTarjeta = true;
				$rootScope.title = "Firma "+FIRMA_CARATULA_TARJETA.etiqueta;
				$scope.negacionCheck = {texto:"", visible: false, textoMensaje:"l Atraso Vidamax.", botonAceptar: "Aceptar"} 
                break;
            case FIRMA_ANEXO_TARJETA.id: 
            	$scope.tituloFirma=FIRMA_ANEXO_TARJETA.etiqueta;
            	$scope.tituloAviso = {texto: FIRMA_CARATULA_TARJETA.etiqueta}
            	$scope.urlDoc = ($rootScope.solicitudJson.idProducto != 28)?"CaratulaCreditotarjeta.html":"CaratulaCreditotarjetaTEC.html";
				$rootScope.isAnexo = true;
				$rootScope.title = "Firma "+ FIRMA_ANEXO_TARJETA.etiqueta;
				$scope.negacionCheck = {texto:"", visible: false, textoMensaje:"", botonAceptar: "Aceptar"} 
                break;
            case FIRMA_PUNTOS_TARJETA.id: 
            	$scope.tituloFirma=FIRMA_PUNTOS_TARJETA.etiqueta;
            	$scope.tituloAviso = {texto: FIRMA_CARATULA_TARJETA.etiqueta}
            	$scope.urlDoc = ($rootScope.solicitudJson.idProducto != 28)?"CaratulaCreditotarjeta.html":"CaratulaCreditotarjetaTEC.html";
				$rootScope.is5puntos = true;
				$rootScope.title = "Firma "+FIRMA_PUNTOS_TARJETA.etiqueta;
				$scope.negacionCheck = {texto:"", visible: false, textoMensaje:".", botonAceptar: "Aceptar"} 
                break;
            default:
            	$scope.tituloAviso = {texto:"Carátula de Crédito"};
              	$scope.tituloFirma = "Carátula de Crédito";              	              	
              	$scope.urlDoc = "CaratulaCreditotarjeta.html";              	              	
              	$rootScope.title = "Firma Seguro Vidamax";
              	$scope.negacionCheck = {texto:"", visible: false, textoMensaje:"", botonAceptar: "Aceptar"} 
            	break;
       }/* END SWITCH */
			
			
			$timeout( function(){
				construirIframe();
			}, 100 );
			
			$scope._btnNoAceptar = generalService.getDataInput("CONTRATOS","BOTON NO ACEPTAR", $scope.origen);
			$scope._btnAceptar = generalService.getDataInput("CONTRATOS","BOTON ACEPTAR", $scope.origen);
			$scope.txtModalContratos = generalService.getDataInput("CONTRATOS","TEXTO MODAL CONTRATOS", $scope.origen);
			
			var imagenesArray = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";				
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
							
				
			modalService.pdfViewModal($scope.urlDoc, $scope.tituloAviso.texto, $scope._btnAceptar.texto, "Cerrar", null, $scope._btnAceptar.estilo, null, ($scope.creditoInmediato||$rootScope.marcas), $scope.esContratos, $scope.contratosAceptados, $scope.firma1Ant, $scope.txtModalContratos,imagenesArray, $scope.muestraAvisos, $scope.negacionCheck )
							.then(
									function(aceptar){
										$scope.responseViewPDF({codigo:RESPONSE_CODIGO_EXITO_IPAD});
										$scope.addOverflow();
									},function(noaceptar){
										if (noaceptar){
											for (var i = 0; i < $scope.documentos.length; i++){
												if ($scope.documentos[i].statusFirma == STATUS_CONTRATO.INFORMATIVO){
													$scope.documentos[i].statusFirma = STATUS_CONTRATO.VISTO;
													$scope.vistos = true;
												}
											} 
											
										}
										$scope.responseViewPDF({codigo:1});			
										$scope.addOverflow();
									}
								);				
		};
		
		$scope.addOverflow=function(){
			$( "html" ).removeClass( "overflowHiddenHTML");
			$( "body" ).addClass( "overflowInitialHTML");
		}
		
		$scope.continuarContratos = function (){
			if($scope.firma1){
				if($scope.origen == "TIENDA"){
					$scope.archivarFirma1();	
//					$scope.guardar();
				} else{
					$scope.guardar();
				}
				
			}else{
				if($scope.firma2){
					if($scope.origen == "TIENDA"){
						$scope.archivarFirma2();	
					} else{
						$scope.guardar();
					}	
				}else
					if($scope.firma3){
						if($scope.origen == "TIENDA"){
							$scope.archivarFirma3();	
						} else{
							$scope.guardar();
						}
					}else if(!generalService.isEmpty($rootScope.firmaCaratula) && $rootScope.isContratoCaratula == true){
						$scope.guardar();
					}else{
						if ($scope.vistos){
							$scope.guardar();
						}else
							generalService.locationPath("/ochoPasos");
					}
			}			
		};
		
		$scope.regresa = function (){
			generalService.locationPath("/ochoPasos");
		};
		
		$scope.cargaFirma = function (imgB64){
			
			var canvas = document.getElementById("canvas1");
			var ctx = canvas.getContext("2d");

			var image = new Image();
			image.onload = function() {
			    ctx.drawImage(image, 0, 0);
			};
			image.src = imgB64;
		};
		
		$scope.negacion = function (value){
			
			var foo = function (){
				$scope.noAceptaContratos = false;
			};
			
			if(value == true){
				var aviso = ["Por políticas internas y para continuar con la solicitud del crédito se requiere la aceptación de la solicitud de crédito y contrato."];
				$rootScope.message("Aviso", aviso, "Aceptar", null, "bgRosa", "btnRosaD", foo);
			}
		}
		
		
//archiva firmas nuevo
		$scope.archivarFirma1 = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$scope.contadorArchivarFirmas++;
			
			var descripcion = "";
			var etiqueta = "";
			var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
				return d["idContrato"];
		    			
			}).indexOf (FIRMA_SEGURO_CLIENTE.id);
			if (index3 != -1){
				descripcion = FIRMA_SEGURO_CLIENTE.descripcion;
				etiqueta =  FIRMA_SEGURO_CLIENTE.etiqueta;
			}else{
//				descripcion = FIRMA_CARATULA_CLIENTE_TARJETA.descripcion;
				descripcion = FIRMA_CARATULA_CLIENTE.descripcion;
				etiqueta =  FIRMAR_CTE_CONTRATOS_TARJETA;
			}
			
//			if( !$scope.confTipoWindows  ){
//				$scope.GetData1();
//				$scope.imgFirma = $scope.imageData1;
//		    	$scope.b64Firma = $scope.imgFirma.replace("data:image/png;base64,","").trim();
//			}
			$scope.imgFirma = $scope.b64Firma;
	    	$scope.b64Firma = $scope.imgFirma.replace("data:image/png;base64,","").trim();
	    	$rootScope.enviarImagen(
	    			$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
	    			"",
//	    			DESC_CONTRATO_TARJETA,
	    			DESC_FIRMA_BURO,
	    			etiqueta,
	    			'firmas',
	    			{	
	    				ruta: null,
	    				idSolicitud: $rootScope.solicitudJson.idSolicitud,
	    				cadena:$scope.b64Firma,
	    				tipoCadena: descripcion,
	    				nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
	    				foto: $rootScope.fotoCteOriginal
	    			},	
	    			"responseEnvioFirmas1"
	    	);
			
		};
			
		
		$scope.responseEnvioFirmas1 = function( responseIPAD ){
			$scope.contadorRepsuestaFirmas++
			$rootScope.loggerIpad("responseEnvioFirmas1", null, responseIPAD);
			try{
				
				if( responseIPAD.codigo == 0 ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					$rootScope.message("CONTRATOS",[ "Correcto para guardar firmas TRY." + JSON.stringify(responseIPAD)], "Aceptar", null);
					if ($scope.firma2)
						$scope.archivarFirma2();
					else
						$scope.guardar();
						
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Error al encolar archivos." + JSON.stringify(responseIPAD)], "Aceptar", null);
					
				}
				
			}catch(e){
				console.log(e.message);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("CONTRATOS",[ "Error al encolar archivos."+e.message], "Aceptar", null);
				console.error( e.message );
				
			}
		}
		$scope.archivarFirma2 = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$scope.contadorArchivarFirmas++;
			var descripcion = "";
			var etiqueta = "";
			var imagenCliente = "";
			var imagenAval = "";
//			if( !$scope.confTipoWindows ){
//				$scope.GetData2();
//				$scope.imgFirma2 = $scope.imageData2;
//				$scope.b64Firma2 = $scope.imgFirma2.replace("data:image/png;base64,","").trim();
//			}else{
			
			$scope.imgFirma2 = $scope.b64FirmaSeguro;
			$scope.b64Firma2 = $scope.imgFirma2.replace("data:image/png;base64,","").trim();
//				$scope.b64Firma2 = $scope.b64FirmaSeguro;
//			}
			var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
				return d["idContrato"];
		    			
			}).indexOf (FIRMA_SEGURO_CARTA.id);
			if (index3 != -1){
				descripcion = FIRMA_SEGURO_CARTA.descripcion;
				etiqueta = FIRMA_SEGURO_CARTA.etiqueta;
				imagenCliente = $scope.imgFirma2;
			}else{
				descripcion = FIRMA_CARATULA_AVAL.descripcion;
				etiqueta = FIRMA_CARATULA_AVAL.etiqueta;
				imagenAval = $scope.imgFirma2;
			}
			
			if ($scope.avisoFirmado){
				$scope.imgFirma2 = $rootScope.imgPrivacidad;
				$scope.b64Firma2 = $scope.imgFirma2.replace("data:image/png;base64,","").trim();
				$rootScope.enviarImagen(
						$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
						"",
						DESC_FIRMA_PRIVACIDAD,
						FIRMA_PRIVACIDAD.descripcion,
						'firmas',
						{	
							ruta: null,
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							cadena: $scope.b64Firma2,
							tipoCadena: "firmaAviso",
							nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
							foto: $rootScope.fotoCteOriginal
						},	
						"responseEnvioFirmas2"
				);
	    	}else{		
				$rootScope.enviarImagen(
						$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
						"",
						DESC_FIRMA_BURO,
						etiqueta,
						'firmas',
						{		
							ruta: null,
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							cadena: $scope.b64Firma2,
							tipoCadena: descripcion,
							nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
							foto: $rootScope.fotoCteOriginal
						},	
						"responseEnvioFirmas2"
				);
	    	}
		};
			
		$scope.responseEnvioFirmas2 = function( responseIPAD ){
			$scope.contadorRepsuestaFirmas++
			$rootScope.loggerIpad("responseEnvioFirmas2", null, responseIPAD);
			try{
					
				if( responseIPAD.codigo == 0 ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					$rootScope.message("CONTRATOS",[ "Correcto para guardar firmas TRY." + JSON.stringify(responseIPAD)], "Aceptar", null);
					if ($scope.firma3)
						$scope.archivarFirma3();
					else
						$scope.guardar();
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Error al encolar archivos." + JSON.stringify(responseIPAD)], "Aceptar", null);
						
				}
					
			}catch(e){
				console.log(e.message);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("CONTRATOS",[ "Error al encolar archivos."+e.message], "Aceptar", null);
				console.error( e.message );
					
			}
		}
		
		$scope.archivarFirma3 = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$scope.contadorArchivarFirmas++;
			if ($scope.buroFirmado){
				$scope.imgFirma3 = $rootScope.imgBuro;
				$scope.b64Firma3 = $scope.imgFirma3.replace("data:image/png;base64,","").trim();
				$rootScope.enviarImagen(
						$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
						"",
						DESC_FIRMA_BURO,
						FIRMA_BURO.descripcion,
						'firmas',
						{	
							ruta: null,
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							cadena:$scope.b64Firma3,
							tipoCadena: "firmaBuro",
							nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
							foto: $rootScope.fotoCteOriginal
						},	
						"responseEnvioFirmas3"
				);	
	    	}
		};
			
		$scope.responseEnvioFirmas3 = function( responseIPAD ){
			$scope.contadorRepsuestaFirmas++
			$rootScope.loggerIpad("responseEnvioFirmas3", null, responseIPAD);
			try{
					
				if( responseIPAD.codigo == 0 ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					$rootScope.message("CONTRATOS",[ "Correcto para guardar firmas TRY." + JSON.stringify(responseIPAD)], "Aceptar", null);
					$scope.guardar();
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Error al encolar archivos." + JSON.stringify(responseIPAD)], "Aceptar", null);
						
				}
					
			}catch(e){
				console.log(e.message);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("CONTRATOS",[ "Error al encolar archivos."+e.message], "Aceptar", null);
				console.error( e.message );
					
			}
		}
		
//archiva firmas nuevo
		
		
//		$scope.archivarFirma = function()
//		{
//			$rootScope.waitLoaderStatus = LOADER_SHOW;
//			
//			$scope.GetData1();
//			$scope.imgFirma = $scope.imageData1;
//	    	$scope.b64Firma = $scope.imgFirma.replace("data:image/png;base64,","").trim();
//	    	
//			$rootScope.enviarImagen(
//					$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
//					"",
//					FIRMAR_CONTRATOS,
//					FIRMAR_CTE_CONTRATOS,
//					'canvas1',
//					{	
//						idSolicitud: $rootScope.solicitudJson.idSolicitud,
//						firmaAviso: "",
//						firmaBuro: "",
//		    			firmaCliente: $scope.b64Firma,
//		    			firmaAval: "",
//		    			nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
//						foto: $rootScope.fotoCteOriginal
//					},	
//					"responseEnvioFirmas"
//			);
//			
//			
//		};
//		
//		$scope.responseEnvioFirmas = function( responseIPAD )
//		{
//
//			try{
//				
//				if( responseIPAD.codigo == 0 ){
//					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					//$rootScope.message("CONTRATOS",[ "Correcto para guardar firmas TRY." + JSON.stringify(responseIPAD)], "Aceptar", null);
//					$scope.guardar();
//				}else{
//					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					$rootScope.message("CONTRATOS",[ "Error al encolar archivos." + JSON.stringify(responseIPAD)], "Aceptar", null);
//					
//				}
//				
//			}catch(e){
//				console.log(e.message);
//				$rootScope.waitLoaderStatus = LOADER_HIDE;
//				$rootScope.message("CONTRATOS",[ "Error al encolar archivos."+e.message], "Aceptar", null);
//				console.error( e.message );
//				
//			}
//			
//			
//		};
		
		$scope.verPdf = function (urlDoc, nombreArchivo){

			$rootScope.visualizaPdf("viewDoc", 
									urlDoc,
									nombreArchivo,
									$scope.firma1Ant==1||$scope.firma1Ant==2?false:true,
									false,
									"responseViewPDF");
		};
		
		$scope.responseViewPDF = function( responseIPAD )
		{
			$rootScope.loggerIpad("responseViewPDF", null, responseIPAD);
			try{
				
				var value = $scope.contratoSeleccionado;
				
				if( responseIPAD.codigo == 0 ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					//console.log(JSON.stringify(responseIPAD));
//					$rootScope.message("URL=>", ["URL=>"+$scope.urlDoc], "Aceptar", null);
					if ($rootScope.solicitudJson.contratos.contrato[ $rootScope.contratoIndex ].statusFirma != STATUS_CONTRATO.SIN_FIRMA || $scope.contratoAceptado[ $rootScope.contratoIndex ].firma != true){
						$scope.contratosAceptados++;
						$scope.Ipad = true;
						$scope.contratoAceptado[$rootScope.contratoIndex].firma = true;
						$scope.validaContratos();
					}
					
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					//$rootScope.message("CONTRATOS",[ "Error al visualizar el documento." + JSON.stringify(responseIPAD)], "Aceptar", null);
					if($scope.firma1Ant == 0)
					{
						if ($rootScope.solicitudJson.contratos.contrato[ $rootScope.contratoIndex ].statusFirma != STATUS_CONTRATO.SIN_FIRMA || $scope.contratoAceptado[ $rootScope.contratoIndex ].firma == true){
							$scope.contratosAceptados--;
							$scope.Ipad = false;
							 $scope.contratoAceptado[$rootScope.contratoIndex].firma = false;
							 $scope.validaContratos();
						}
						
					}
					
					
				}
				
			}catch(e){
				console.log(e.message);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("CONTRATOS",[ "Error al visualizar el documento."+JSON.stringify(e)], "Aceptar", null);
				console.error( e.message );
				
			}
			
			
		};
		
		$scope.visorPdfWeb = function (){
			var value = $scope.contratoSeleccionado;
			
			modalService.avisosModal($scope.tituloAviso, $scope.urlDoc, $scope._btnNoAceptar, $scope._btnAceptar, null,$scope._btnNoAceptar.estilo, $scope._btnAceptar.estilo, ($scope.creditoInmediato||$rootScope.marcas), $scope.esContratos, $scope.contratosAceptados, $scope.firma1Ant, $scope.txtModalContratos).then(
 					function(exito){
                        
 						if ($rootScope.solicitudJson.contratos.contrato[ $rootScope.contratoIndex ].statusFirma != STATUS_CONTRATO.SIN_FIRMA || $scope.contratoAceptado[ $rootScope.contratoIndex ].firma != true){
 							$scope.contratosAceptados++;
 							$scope.Ipad = true;
 							$scope.contratoAceptado[$rootScope.contratoIndex].firma = true;
 							$scope.validaContratos();
 						}
 						
 						
 					},function(error){
 						if($scope.firma1Ant == 0)
 						{
 							
 							if ($rootScope.solicitudJson.contratos.contrato[ $rootScope.contratoIndex ].statusFirma != STATUS_CONTRATO.SIN_FIRMA || $scope.contratoAceptado[ $rootScope.contratoIndex ].firma == true){
 								$scope.contratosAceptados--;
 								$scope.Ipad = false;
 								$scope.contratoAceptado[$rootScope.contratoIndex].firma = false;
 								$scope.validaContratos();
 							}
 						}
 						
 					}
 			);
		};
		
	    $scope.$on("$destroy", function() {
	    	$( "body" ).removeClass( "overflowInitialHTML");
	    });
	    
	    $scope.consultarCat = function() {
	    	// No sé qué es el producto 28
	    	if ($rootScope.solicitudJson.idProducto == 28) {
	    		// Se configura el GATO con valores por defecto.
	    		$rootScope.cat = {
	    			cat: '', // ¿Cuál sería un valor por defecto?
	    			tasaOrdinaria: '', // ¿Cuál sería un valor por defecto?
	    			tasaMoratoria: '' // ¿Cuál sería un valor por defecto?
	    		};
	    		
	    		// La entrada para el consumo.
	    		let input = {
    	    		idSolicitud: $rootScope.solicitudJson.idSolicitud,
    	    		tipoTarjeta: 'R1' // Por ahora, esto va en duro.
    	    	};
	    		
	    		// Se procede con el consumo silente.
	    		tarjetaService.consultaDatosCaratulaTDC(input).then(
    	    		function(success) {
    	    			if (success.data.codigo == RESPONSE_CODIGO_EXITO) {
    	    				let j;
    	    				
    	    				try {
    	    					j = JSON.parse(success.data.respuesta);
    	    				} catch(g) {
    	    					console.log('What\'s the frecuency, Kenneth?');
    	    					
    	    					j = false;
    	    				}
    	    				
    	    				if (j && 2 == j.codigo) {
    	    					try {
    	    						// Se configura el objeto GATO con los valores del servicio.
    	    						$rootScope.cat.cat = j.data.catTotal.replace('%', '');
    	    						$rootScope.cat.tasaOrdinaria = j.data.tasaOrdinaria.replace('%', '');
    	    						$rootScope.cat.tasaMoratoria = j.data.tasaMoratoria.replace('%', '');
    	    					} catch(a) {
    	    						console.log('You talking to me?!');
    	    					}
    	    				}
    	    			}
    	    		}, function(unsuccess) {}
    	    	);
	    	} else {
	    		var x = {
						idSolicitud: $scope.solicitudJson.idSolicitud,
						ticketYakana:	 generalService.getArrayValue('ticketTarjeta'),
						numeroEmpleado: $scope.solicitudJson.idEmpleado					
				};
				
				tarjetaService.consultaCat( x ).then(
					function(data){
						if(data.data.codigo == 1){
							var j = JSON.parse(data.data.respuesta);
							//modalService.alertModal("OK "+j.codigo, [j.descripcion]);
							$rootScope.cat =  j.data;
						}else
							//modalService.alertModal("",[data.data.respuesta]);
							$rootScope.cat = data.data.respuesta;
						
					}, function(error){
		                //modalService.alertModal("Error "+error.status, [error.statusText]);
						$scope.cat = "Error";
					}
				);
	    	}
		};
		
		function procesarFirma(){
			$rootScope.loggerIpad("Entre a la funcion procesarFirma", null);
			var hayFirmasPendientes = false;
			var imgFirma = "";
			var descripcion = "";
			if($rootScope.isSolicitud){
				if($rootScope.firmaSolUnoWSD){
					descripcion = FIRMA_SOLICITUD_CREDITO_UNO.descripcion;
					imgFirma = $rootScope.firmaSolicitud;
					hayFirmasPendientes = true;
				}else{
					hayFirmasPendientes = true;
					$rootScope.isSolicitud = false;
					descripcion = FIRMA_SOLICITUD_CREDITO_DOS.descripcion;
					imgFirma = $rootScope.firmaSolicitudDos; 
				}
			}
			
			if(hayFirmasPendientes){
				if (!generalService.isEmpty(imgFirma)){
					var cadenaFirma = imgFirma.replace("data:image/png;base64,","").trim();
					if(configuracion.origen.tienda){
						var biometrico = {
								ruta: null,
								idSolicitud: $rootScope.solicitudJson.idSolicitud,
								cadena: cadenaFirma,
								tipoCadena: descripcion,
								porcentaje: 100
						}
						enviarFirma(biometrico);
					}
				}else{
					$rootScope.loggerIpad("La firma del:" + descripcion + "esta vacia", null);
					generalService.locationPath("/ochoPasos");
				}
			}else{
				guardaFirmaFaltante();
			}
		};
		
		function enviarFirma(biometrico){

			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$scope.respaldoBio = biometrico;
			clienteUnicoService.setBiometrico( biometrico ).then(
				function(data){
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							if($scope.respaldoBio.tipoCadena == "firmaSolicitudCreditoUno"){
								$rootScope.firmaSolUnoWSD = false;
							}else if($scope.respaldoBio.tipoCadena == "firmaSolicitudCreditoDos"){
								$rootScope.firmaSolDosWSD = false;
								$rootScope.solicitudJson.contratos.contrato[2].statusFirma = STATUS_CONTRATO.ENVIAD0;
							}
							
							procesarFirma();
							
						}else if(j.codigo == RESPONSE_CODIGO_ERROR_ID){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$rootScope.message("Error",[j.descripcion], "Aceptar", "/simulador", "bgCafeZ","cafeZ",null,null,null);
						}else{
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$rootScope.message("Error",["Error al enviar los contratos. Por favor, espere unos minutos para reintentar"], "Aceptar", "/ochoPasos", "bgCafeZ","cafeZ",null,null,null);
						}
					}else{
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Error",["Error en la respuesta del servicio para guardar el contrato del cliente. Por favor, reintente nuevamente."], "Aceptar", "/ochoPasos", "bgCafeZ","cafeZ");
					}
				},function(error){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Error",["Servicio no disponible para enviar el contrato, favor de comunicarse con soporte."], "Aceptar", "/ochoPasos", "bgCafeZ","cafeZ");
				});
	 	
		};

	});
	
});

//"nGIRbhkJmdXXfPGtBXNJnlZ/MtO7gQEuml61hFo2EWa9WLhTSstG5u30+G+EqptbJDqAOUtBRx3sDlM8qSFyCYspB/s8w3l1cdZkhb5M8+MO3wc1v0dejZcWa9+6q9XTxJySg5osfBE62xTgP6K5GZcGppWLA4kUyuS1JXhbVgzevRVITNCK/fmhxPNE7tUQ"