'use strict';

define(["app"], function (app) {
	
	app.controller("cuentasClienteController", function ($timeout, $scope, $rootScope, solicitudService, generalService, modalService, buroService, messageData, validateService, documentosService, clienteUnicoService ) {
		$rootScope.waitLoaderStatus = LOADER_HIDE;
//		.tab.verdeVt.active
//		$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = 42000;
		var csstabs = {on:"tab dos verdeA active", off:"tab dos verdeA"}; 
		$scope.tabInverisonCSS =  csstabs.off;
		$scope.tabCreditoCSS =  csstabs.on;
		
		$scope.Showinversiones = true;
		$scope.showInverison = function(inverison){
			if(inverison == 1){
				$scope.tabInverisonCSS =  csstabs.off;
				$scope.tabCreditoCSS =  csstabs.on;
				$scope.Showinversiones = true;
				$timeout( function(){ 
	 				$scope.sliderListener2();
	 			}, 1)
			}else{
				$scope.tabInverisonCSS =  csstabs.on;
				$scope.tabCreditoCSS =  csstabs.off;
				$scope.Showinversiones = false;
				$timeout( function(){ 
	 				$scope.sliderListener();
	 			}, 1)
			}
		}
		$scope.cuentas = [];
		$scope.valorAnt = 0;
		$scope.init = function(){
			$scope.showPage = true;
			
			if( messageData ){
//				$scope.cargaPagina();
				$timeout(function(){
					$scope.showPage = messageData;
				}, 1);
				
				$scope.setContentPage();

			}
		};/* END INIT FUNCITON */
		
		$scope.setContentPage = function()
	    {
			$scope.vista = 0;
	    	if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
	    	$scope._titulo = generalService.getDataInput("CONTRATOS","TITULO", $scope.origen);
	    	$scope.labelTiempo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO TIEMPO."+$scope.origen+".valor"];
			$scope.labelMin = " " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO MIN."+$scope.origen+".valor"];
			$scope.titulo = "Buzón de documentos encolados";
	    	generalService.setMapping(  MODEL_VISTAS_JSON );
	    	
	    	$scope.txtRegresar = generalService.getDataInput("OCHO PASOS","TEXTO BOTON REGRESAR", $scope.origen);
	    	
	    	$timeout( function(){ 
	    		$scope.sliderListener2();
 			}, 10
 		);
	    	
	    	
//	    	$rootScope.obtenerClientesConEnvios( "encoladoDiv", "onListaClientesRespuesta" );
	    		
	    };/* END SET_CONTENT_PAGE FUNCTION */	    
	    $scope.uiSlider1 = function ( valor ){
	    	if($scope.valorAnt1 != valor){
	    		$scope.valorAnt1 = valor;
	    		$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = valor;
	 			$scope.montoInvertir = (parseInt($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto) / 70)*100;
//	 			 $scope.sliderListener();
	 			console.log("slider 1 " + $scope.montoInvertir);
	    	}
	 	};
	 	$scope.uiSlider2 = function ( valor ){
	    	if($scope.valorAnt != valor){
	    		$scope.montoInvertir = valor;
	    		$scope.valorAnt = valor;
	    		$scope.inversion = valor;
	    		$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = parseInt($scope.montoInvertir) * .70;
//	    		$scope.sliderListener();
	    		console.log("slider 2");
	    	}
	 	};
	    $scope.sliderListener = function(){
//	    	$scope.montoInvertir = "10000"
	    	if (!$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto){
	    		$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = 7000;
	    	}
	 		var fooCallback = function( uiValue ){
		 		/* BUG JQUERY TIMEOUT */
				$timeout( function(){ 
		 				angular.element( document.getElementById( "cuentasClienteDiv" ) ).scope().uiSlider1( uiValue );
		 			}, 100
		 		);
	 		};	 	
    
	 		_min = 7000;
	 		_max = 210000;
	 		_step = 7000;
	        var arreglo = [];
	 		arreglo[0] = _min;
	 		for (var i = 1; i <30 ;i++){
	 			arreglo[i] = (arreglo[i - 1] + _step);
			}
	 		
	 		
	 		$scope.minPrestamo = _min;
	 		$scope.maxPrestamo = _max;
	 		
	 		/* INIT SLIDER */
	 		var sliderTmp = slider( _min, _max, _step, $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto, 
	 								'.amount div',arreglo, fooCallback, "#sliderCuenta" );	
		
 	};
 	
 	$scope.sliderListener2 = function(){
 		if (!$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto || $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto < 7000){
    		$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = 7000;
    	}else{
    		$scope.montoInvertir = (parseInt($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto) / 70)*100;
    	}
 		if (!$scope.montoInvertir)
 			$scope.montoInvertir = 10000;
 		var fooCallback2 = function( uiValue ){
	 		/* BUG JQUERY TIMEOUT */

			$timeout( function(){ 
 				angular.element( document.getElementById( "cuentasClienteDiv" ) ).scope().uiSlider2( uiValue );
 			}, 100
 		);
 		};		 	
 		var _min2 = 10000;
 		var _max2 = 300000;
 		var _step2 = 10000;
        var arreglo2 = [];
 		arreglo2[0] = _min2;
 		for (var i = 1; i <30 ;i++){
 			arreglo2[i] = (arreglo2[i - 1] + _step2);
		}
 		$scope.minPrestamo2 = _min2;
 		$scope.maxPrestamo2 = _max2;
 		$scope.inversion = 10000
 		var sliderTmp2 = slider( _min2, _max2, _step2, $scope.montoInvertir, 
					'.amount2 div',arreglo2, fooCallback2, "#sliderCuenta2" );
	
	};
 	
 	$scope.seleccionCuenta = function(key){
 		if ($scope.montoInvertir <= $scope.cuentasCliente[key].montoGarantia){
 			$scope.seleccionada = key;
// 			$scope.cuentaSel = $scope.cuentasCliente[key].cuentaSaldo;
// 			console.log( $scope.cuentasCliente[key].cuentaSaldo);
// 			$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico = $rootScope.datosClienteUnico.fipais + "-" + $rootScope.datosClienteUnico.ficanal + "-" + $rootScope.datosClienteUnico.fisucursal + "-" + $rootScope.datosClienteUnico.fifolio;
// 			$scope.validaHuella(); 			
 		}
 	};
 	 	
 	$scope.validaHuella=function(){
		
		if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) > -1 )
			$scope.responseVerificarHuellaIpad1( {codigo:0, matches:["OK"]} );
//			generalService.locationPath("/ochoPasos");
		else{
			if ( configuracion.origen.tienda ){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$rootScope.verificarHuella( 'cuentasClienteDiv', 'responseVerificarHuellaIpad1', [$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico]);
			}else			
//				$scope.abrirDialogo();
				$scope.nuevaSolicitud($rootScope.datosClienteUnico, $rootScope.opcionTDC);
//				$rootScope.message( "Error al verificar la huella", ["Verificar huella"], "Aceptar", null, "verde", "verde", null, "GENERAL", "EXCEPCION COMPONENTE");
		}
		
		
			
	};
	
	$scope.responseVerificarHuellaIpad1 = function( response ){
		$rootScope.loggerIpad("responseVerificarHuellaIpad1", null, response);
		try{
			
			if(response.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
				
				if( !generalService.isDefined(response.matches) || response.matches.length == 0){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message( "Error al verificar la huella", ["La huella del cliente no coincide, por favor inténtelo de nuevo."], "Aceptar", null, "verde", "verde", null);																												
				
				}else{
			 		$scope.nuevaSolicitud($rootScope.datosClienteUnico, $rootScope.opcionTDC);
			 		
//					generalService.locationPath("/ochoPasos");
//					generalService.locationPath( generalService.getPathSection($rootScope.solicitudJson,$rootScope.sucursalSession.idCanal) );																							
				}	
				
			}else{	
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message( "Error al verificar la huella", [e.message], "Aceptar", null,  "verde",  "verde", null, "GENERAL", "EXCEPCION COMPONENTE");
			}
				
		}catch(e){
			$rootScope.waitLoaderStatus = LOADER_HIDE;	
//			generalService.cleanRootScope($rootScope);
//			generalService.buildSolicitudJson($rootScope, null );
			$rootScope.message( "Error al verificar la huella", [e.message], "Aceptar", null,  "verde",  "verde", null, "GENERAL", "EXCEPCION COMPONENTE");
		}									
	};
	
	$scope.nuevaSolicitud = function( persona, opcion )
	{
		
		$scope.mueveDatos(persona);
//		$rootScope.solicitudJson.cotizacion.=$scope.cuentaSel;
		$scope.persona=persona;
		var jsonEnvio = {
			solicitudJson: JSON.stringify($rootScope.solicitudJson),
			opcion: opcion
		};
		
		$rootScope.waitLoaderStatus = LOADER_SHOW;
		clienteUnicoService.getCU( jsonEnvio ).then(
			function(data){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(data.data.codigo == RESPONSE_CODIGO_EXITO){
					var jsonRespuesta = JSON.parse(data.data.respuesta);							
					$scope.validaRespuesta( jsonRespuesta );
				}else{
					$rootScope.message("ERROR",["Error en la respuesta del servicio para obtener CU. Por favor, reintente nuevamente."], "Aceptar", "/simulador");
				};
		
			}, function(error){
                $rootScope.waitLoaderStatus = LOADER_HIDE;
           	    $rootScope.message("ERROR",[$scope.mensajeError], "Aceptar", "/simulador");
			}
		);
		
	};
	
	$scope.validaRespuesta = function( jsonRespuesta )
	{

		if( jsonRespuesta && jsonRespuesta != null ){
			try{
			    
				switch ( parseInt(jsonRespuesta.codigo) ) {
					case RESPONSE_ORIGINACION_CODIGO_EXITO:
							$scope.seteaDatos( jsonRespuesta, generalService.getPathSection( jsonRespuesta.data, null )  );
//							generalService.locationPath( generalService.getPathSection( jsonRespuesta.data, null ) );
						break;
					case HOMONIMOS_FLUJO_RECOMPRA:
							$scope.seteaDatos( jsonRespuesta, "/ficha" );
//							generalService.locationPath("/ficha");
						break;
					case HOMONIMOS_FLUJO_RECOMPRA_2:
						$scope.seteaDatos( jsonRespuesta, "/ficha" );
//						generalService.locationPath("/ficha");
					break;
					case HOMINOMOS_IMPOSIBLE_CONTINUAR_PROCESO:
							$rootScope.message("ERROR",[jsonRespuesta.descripcion], "Aceptar", "/simulador");
						break;
					case LINEA_CREDIMAX:
						var nombreCte = $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+ $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno;
						$rootScope.message("AVISO",["No es posible continuar con la solicitud ya que el cliente  "+nombreCte+"  es un cliente Activo en Micronegocio"], "Aceptar", "/simulador");
						break;
					case LINEA_MICRONEGOCIO:
						var nombreCte = $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+ $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno;
						$rootScope.message("AVISO",["No es posible continuar con la solicitud ya que el cliente  "+nombreCte+"  es un cliente Activo en Micronegocio"], "Aceptar", "/simulador");
						break;
					default:
							$rootScope.message("ERROR",[$scope.mensajeError], "Aceptar", "/simulador");
						break;
				}
		    }catch( e ){
		    	$rootScope.message("ERROR",[ e.message, e, e.type ], "Aceptar", "/simulador");
		    }
	    }else
			$rootScope.message("ERROR",[$scope.mensajeError], "Aceptar", "/simulador");
	    
//		switch(respuesta.codigo){
//			case 301:
//				$rootScope.solicitudJson=$scope.resp.data;
//				window.routes["/ochoPasos"].requireLogin=false;
//				generalService.locationPath("/ochoPasos");
//				break;
//			case 302:
//				$rootScope.solicitudJson=$scope.resp.data;
//				configuracion.nuevoCredito.opcion=1;
//				window.routes["/nuevoCredito"].requireLogin=false;
//				generalService.locationPath("/nuevoCredito");
//				break;
//			case 303:
//				$rootScope.solicitudJson=$scope.resp.data;
//				window.routes["/ochoPasos"].requireLogin=false;
//				generalService.locationPath("/ochoPasos");
//				break;
//			case 304:
//				$rootScope.solicitudJson=$scope.resp.data;
//				window.routes["/ochoPasos"].requireLogin=false;
//				generalService.locationPath("/ochoPasos");
//				break;
//			case 305:
//				$rootScope.solicitudJson=$scope.resp.data;
//				window.routes["/visitaAsesor"].requireLogin=false;
//				generalService.locationPath("/visitaAsesor");
//				break;
//			case 306:
//				$rootScope.solicitudJson=$scope.resp.data;
//				window.routes["/estatus"].requireLogin=false;
//				generalService.locationPath("/estatus");
//				break;
//			case 307:
//				$rootScope.solicitudJson=$scope.resp.data;
//				window.routes["/ochoPasos"].requireLogin=false;
//				generalService.locationPath("/ochoPasos");
//				break;
//		    default:
//		    	$rootScope.message("ERROR",[$scope.mensajeError], "Aceptar", "/simulador");
//		};
	};
	
	$scope.seteaDatos = function( jsonRespuesta, path )
	{			
		$rootScope.fotoCte = "data:image/png;base64,"+$scope.persona.fcfoto;
		$rootScope.fotoCteOriginal= $scope.persona.fcfoto;
		$rootScope.solicitudJson = jsonRespuesta.data;
											
		agregarIdentificacionOficial(path);
					
	};/* END SETEA DATOS FUNCTION */
	
	function agregarIdentificacionOficial(_path){
		if (configuracion.origen.tienda ){
			
			documentosService.encolarDocSimulador(_path, "homonimosDivId","responseEnvioImg1Ipad","responseEnvioReverso", "firmas", "responseEnvioFirmas","responseEnvioFirmas");
			
//			var fechaVigenciaIFE = "";
//			if( generalService.getArrayValue('fechaVigenciaIFE') != null ){
//				fechaVigenciaIFE = generalService.getArrayValue('fechaVigenciaIFE')
//				generalService.setArrayValue("fechaVigenciaIFE",null);
//			}			
//			
//			
//			var porcentaje = 100;
//			if($rootScope.solicitudJson.documentos.documento != null && $rootScope.solicitudJson.documentos.documento.length > 0)
//				porcentaje = generalService.porcentajeDocs($rootScope);
//			
//			var documentosString = JSON.stringify($rootScope.solicitudJson.documentos);
//			var documentosObj = JSON.parse(documentosString);
//			documentosObj.porcentaje = porcentaje; 
//			documentosObj.documento = new Array();
//			
//			
//			documentosObj.documento.push( { idDocumento:'1',documentoDes: IDENTIFICACION_OFICIAL.descripcion,
//					 status:STATUS_ENCOLADO_IPAD,
//					 idTipoPersona:1,idPersona:$rootScope.solicitudJson.cotizacion.clientes[0].idPersona, consecutivoPersona:0, idTipoDocumento:1, 
//					 tipoDocumentoDes:"Credencial de Elector (IFE/ INE)",  fechaVigencia:fechaVigenciaIFE,
//					 idMotivoRechazo:0, observacion:"" } );												
//			
//			$rootScope.waitLoaderStatus = LOADER_SHOW;
//			documentosService.validarDocumentos( { idSolicitud: $rootScope.solicitudJson.idSolicitud, jsonDoc: JSON.stringify(documentosObj) } ).then(
//					function(data){
//						$rootScope.waitLoaderStatus = LOADER_HIDE;
//													
//						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
//							var responseJson = JSON.parse(data.data.respuesta);
//							
//							if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){	
//								
//								$rootScope.solicitudJson = responseJson.data;																																
//								$rootScope.calculaDocumentos();																					
//								$scope.encolarDocumentos();																														
//																									
//							}							
//															
//							generalService.locationPath(_path);
//							
//						}else								
//							generalService.locationPath(_path);
//						
//							
//																																																					
//						
//						
//					}, function(error){	
//		                $rootScope.waitLoaderStatus = LOADER_HIDE;				                
//		                generalService.locationPath(_path);
//					}
//				);
			
		}else{
//			$scope.encolarDocumentos();
            generalService.locationPath(_path);
		}
	};
	
	$scope.responseEnvioReverso = function(responseIPAD){		 						
		
		if(responseIPAD.codigo == RESPONSE_CODIGO_EXITO_IPAD){
			
			var IdOficialFrente = IDENTIFICACION_OFICIAL.descripcion + " " + CLIENTE.descripcion +" " + etiquetaFrente;
			var IdOficialReverso = IDENTIFICACION_OFICIAL.descripcion + " " + CLIENTE.descripcion +" " + etiquetaReverso;
			
			$rootScope.executeAction( "moduloTracker", 
									  "executeActionResponseIdOficialExp",  
									  { 
										nombre:"envioDocumentos", 
										idCliente:$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
										mostrarSpinner:0, 
										filtroDocumentos: IdOficialFrente +","+IdOficialReverso 
									  } 
									);
			
		}
		 			
	};
 	
 	$scope.mueveDatos = function( setJson )
	{
		
		// DATOS HOGAR
		var cont = 0;
		var contCampo = 0;
		var arregloOpcionales = generalService.recorrerOpcionalesPorSeccion( "DATOS HOGAR" );
		for (var a=0; a < arregloOpcionales.length; a++){
			if (arregloOpcionales[a].opcional == false)
				cont++;
		}
		var porcentajeCampo = 0;
		if(cont > 0)
			porcentajeCampo = parseInt(100 / cont);
		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle = (setJson.fccalle==null?"":setJson.fccalle).toString();
		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroExterior = (setJson.fcnumero_EXTERIOR==null?"":setJson.fcnumero_EXTERIOR).toString();
		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroInterior = (setJson.fcnumero_INTERIOR==null?"":setJson.fcnumero_INTERIOR).toString();
		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp = (setJson.fccodigo_POSTAL==null?"":setJson.fccodigo_POSTAL).toString();
//		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = setJson.fccolonia==null?"":setJson.fccolonia;
		if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle != "")
			contCampo++;
		if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroExterior != "")
			contCampo++;
		if(parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp) > 0)
			contCampo++;
		else
			$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp = "";
		if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia != "")
			contCampo = contCampo + 3;
		var porcentaje = porcentajeCampo * contCampo;
		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje = parseInt(porcentaje.toFixed(0));
		
		// OTROS DATOS
//		$rootScope.solicitudJson.cotizacion.clientes[0].celular = (setJson.fctelefono==null?"":setJson.fctelefono).toString();
//		$rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion = setJson.fcfolio_IDENTIFICACION;
//		$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto = setJson.fiocupacion;
		$rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova = (setJson.fccliente_ALNOVA==null?"":setJson.fccliente_ALNOVA).toString();
		$rootScope.solicitudJson.cotizacion.clientes[0].clienteTienda = setJson.fiid_NEGOCIO + "-" + setJson.fiid_TIENDA + "-" + setJson.fiid_CLIENTE + "-" + setJson.fidigito_VERIFICADOR;
		
		// DATOS BASICOS
		var cont = 0;
		var contCampo = 0;
		var arregloOpcionales = generalService.recorrerOpcionalesPorSeccion( "DATOS BASICOS" );
		for (var a=0; a < arregloOpcionales.length; a++){
			if (arregloOpcionales[a].opcional == false)
				cont++;
		}
		var porcentajeCampo = 0;
		if(cont > 0)
			porcentajeCampo = parseInt(100 / cont);
		$rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil = ( setJson.fiedocivil == null || setJson.fiedocivil == "" ? 0 : parseInt(setJson.fiedocivil) );
		$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto = ( setJson.fiocupacion == null || setJson.fiocupacion == "" ? 0 : parseInt(setJson.fiocupacion) );
//		$rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento = ( setJson.fidedo == null || setJson.fiedo == "" ? 0 : parseInt(setJson.fidedo) );
		if ($rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil != 0){
			var estadoCivil = generalService.construirCatalogo("CATALOGO ESTADO CIVIL");
			var indexEstadoCivil = estadoCivil.map(function(data){
				return data['id'];
			}).indexOf($rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil);
			
			if(indexEstadoCivil == -1)
				$rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil = 0;
			else
				contCampo++;
		}
		if ($rootScope.solicitudJson.cotizacion.clientes[0].idPuesto != 0){
			var ocupaciones=generalService.construirCatalogo("CATALOGO OCUPACION");
			var indexOcupaciones = ocupaciones.map(function(data){
				return data['id'];
			}).indexOf($rootScope.solicitudJson.cotizacion.clientes[0].idPuesto);
			
			if(indexOcupaciones == -1)
				$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto = 0;
			else
				contCampo++;
		}
		if ($rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento != 0){
			var estados = generalService.construirCatalogo("CATALOGO ESTADOS");
			var indexEstados = estados.map(function(data){
				return data['id'];
			}).indexOf($rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento);
			
			if(indexEstados == -1)
				$rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento = 0;
			else
				contCampo++;
		}
		var porcentaje = porcentajeCampo * contCampo;
		$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = parseInt(porcentaje.toFixed(0));
		
	};
	
	$scope.respuesta = {
		    "dateOperation": "09-08-2016 5:31 pm",
		    "descriptionCode": "b039: (bga0182) cliente con cuentas lc disponibles",
		    "folioEncore": "919|20160809 17:32:03|eservices",
		    "invalid": "false",
		    "statuscode": "0",
		    "trackingNumber": "09082016173203",
		    "list": [
		      {
		        "banderaLibre": "",
		        "caracterLibre": "",
		        "cuentaeje": "",
		        "cuentaSaldo": "01270673701328907720",
		        "montoGarantia": "329610.00",
		        "montoLineaCredito": "769090.00",
		        "montoTotal": "1098700.00",
		        "numeroLibre": "0.00",
		        "producto": "13",
		        "subProducto": "0017",
		        "tipoProducto": "c"
		      },
		      {
		    	  "banderaLibre": "",
		    	  "caracterLibre": "",
		    	  "cuentaeje": "",
		    	  "cuentaSaldo": "1231231231313123123",
		    	  "montoGarantia": "32610.00",
		    	  "montoLineaCredito": "769090.00",
		    	  "montoTotal": "1700.00",
		    	  "numeroLibre": "0.00",
		    	  "producto": "12",
		    	  "subProducto": "0017",
		    	  "tipoProducto": "c"
		      },
		      {
		    	  "banderaLibre": "",
		    	  "caracterLibre": "",
		    	  "cuentaeje": "",
		    	  "cuentaSaldo": "1231231231313123112323",
		    	  "montoGarantia": "150610.00",
		    	  "montoLineaCredito": "769090.00",
		    	  "montoTotal": "1700.00",
		    	  "numeroLibre": "0.00",
		    	  "producto": "11",
		    	  "subProducto": "0017",
		    	  "tipoProducto": "c"
		      }
		    ]
		  };
	
	$scope.cancelar = function (){
		generalService.cleanRootScope($rootScope);
		generalService.buildSolicitudJson($rootScope, null );
		generalService.locationPath("/")
	}
	$scope.showBoton = function(){
		if(!isNaN($scope.seleccionada)){
			if ($scope.montoInvertir <= $scope.cuentasCliente[$scope.seleccionada].montoGarantia){
				return false;
			}else{
				return true;
			}
		}else{
			return true;
		}
	}
	$scope.aceptar = function(){
		if(!isNaN($scope.seleccionada)){
			if ($scope.montoInvertir <= $scope.cuentasCliente[$scope.seleccionada].montoGarantia){
	 			modalService.confirmModal("Notificación",["Infórmale a tu cliente que se hará una retención a su cuenta de captación <b>Guardadito Plus</b> como fuente alterna de pago de su tarjeta.", "<b>Pídele a tu cliente que seleccione una opción y coloque su huella</b>"], "No Acepto", "Acepto", "bgVerde", "btn gris", "btn verde" ).then(
						function(exito){
							$scope.cuentaSel = $scope.cuentasCliente[$scope.seleccionada].cuentaSaldo;
							console.log( $scope.cuentasCliente[$scope.seleccionada].cuentaSaldo);
							$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico = $rootScope.datosClienteUnico.fipais + "-" + $rootScope.datosClienteUnico.ficanal + "-" + $rootScope.datosClienteUnico.fisucursal + "-" + $rootScope.datosClienteUnico.fifolio;
							$scope.validaHuella(); 
						},function(error){
														
						}
				 );
	 			
			}
		}
	}
 	$scope.cuentasCliente = $rootScope.cuentasClienteData.list;
// 	$scope.cuentasCliente = $scope.respuesta.list;
 	
	});

});
