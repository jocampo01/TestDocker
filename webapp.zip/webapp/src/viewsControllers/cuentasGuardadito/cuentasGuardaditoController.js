'use strict';

define( [ "app" ],function(app) {
	app.controller('cuentasGuardaditoController',function($rootScope, $scope, messageData, modalService, validateService,generalService, surtimientoService,tarjetaService, 
															callCenterService, solicitudService,buroService,clienteUnicoService, ngDialog, $location) {
		if (configuracion.origen.tienda)
			$rootScope.validarTienda = true;
		else
			$rootScope.validarTienda = false;
		
		$scope.init = function() {
			if (messageData) {
				if (generalService.existeSolicitud($rootScope.solicitudJson)){
					loadView();
					listadoCuentas();
				}else
					$rootScope.message(SIN_SOLICITUD.titulo,[ SIN_SOLICITUD.texto ],"Aceptar", "/","bgCafeZ", "cafeZ");
			} else
				$rootScope.message(ERROR_CARGA_PAGINA.titulo,[ ERROR_CARGA_PAGINA.texto ],"Aceptar", "/","bgCafeZ", "cafeZ");
		};/* END INIT FUNCTION */
		
		function loadView() {

			$scope.origen = ($rootScope.validarTienda == true) ? "TIENDA": "WEB";
			$scope._titulo = generalService.getDataInput("SURTIMIENTO","TITULO", $scope.origen);
			$scope._titulo.texto = "Guardadito";
			$scope._titulo.imagen = "images/header/ingresos_egresos.png";
			$scope.nombreCompleto = generalService.camelize($rootScope.solicitudJson.cotizacion.clientes[0].nombre
															+ " "
															+ $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno
															+ " "
															+ $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno);
			
		};/* END LOAD VIEW FUNCTION */

//		var listadoCuentas = function(){
//			var jsonRequest = {
//					idSolicitud: $rootScope.solicitudJson.idSolicitud,
//					idSeguimiento: $rootScope.solicitudJson.idSeguimiento,
//					idPais: $rootScope.solicitudJson.idPais,
//					idCanal: $rootScope.solicitudJson.idCanal,
//					idSucursal: $rootScope.solicitudJson.idSucursal,
//					terminal: $rootScope.solicitudJson.terminal,
//					clienteAlnova: $rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova,
//					nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre,
//					apellidoPaterno: $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno,
//					apellidoMaterno: $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
//					fechaNacimiento: $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento
//				};
//			$rootScope.waitLoaderStatus = LOADER_SHOW;
//			tarjetaService.consultaCuentasCliente(jsonRequest,PROCESOS.PSC).then(
//				function(data) {
//					
//					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
//						var jsonResponse = JSON.parse(data.data.respuesta);
//						
//						if (jsonResponse.codigo == 2) {
//							$scope.vaciarListaCuentasApertura(JSON.parse(jsonResponse.data));
//							$scope.showPage = true;
//							$rootScope.habilitarGuardadito=false;
//						} else {
//							if($rootScope.aperturarGuardadito){
//								if (jsonResponse.codigo == 618)
//									$rootScope.habilitarGuardadito=true;
//								else
//									$rootScope.habilitarGuardadito=false;
//								generalService.locationPath(generalService.whichOneVisit(0));
//							}else
//								$rootScope.message("Notificación",[ "El cliente no tiene cuenta Guardadito" ],"Aceptar",generalService.whichOneVisit(0),"bgCafeZ","cafeZ");
//						}
//					} else{
//						$rootScope.message("Error", ["Favor de volverlo a intentarlo nuevamente"], "Aceptar", "/simulador", "bgCafeZ", "cafeZ");
//					}
//				},
//				function(error) {
//					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					$rootScope.message("Error", ["Favor de volverlo a intentarlo nuevamente"], "Aceptar", "/simulador", "bgCafeZ", "cafeZ");
//				});
//
//		};/* END LISTADO CUENTAS FUNCION */
		
		var listadoCuentas = function(){
			tarjetaService.consultaCteAlnova($rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if (jsonResponse.codigo == TARJETA_WS_EXITO) {
							var cuentasData = jsonResponse.data;
							$scope.vaciarListaCuentas(cuentasData.consultaCuentasList);

							if ($scope.existeGuardadito) {
								$scope.showPage = true;
							}else{
								$rootScope.message("Notificación",[ "El cliente no tiene cuenta Guardadito" ],"Aceptar",generalService.whichOneVisit(0),"bgCafeZ","cafeZ");
							}
						} else {
							$rootScope.message("Error",[ jsonResponse.descripcion ],"Aceptar",null,"bgCafeZ","cafeZ");
							$scope.manejador = "principal";
						}
					} else{
						$rootScope.message("Error", [generalService.displayMessage(data.data.descripcion)], "Aceptar", null, "bgCafeZ", "cafeZ");
					}
				},
				function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Error", ["Favor de volverlo a intentarlo nuevamente"], "Aceptar", "/simulador", "bgCafeZ", "cafeZ");
				});

		};/* END LISTADO CUENTAS FUNCION */
		
		$scope.vaciarListaCuentas = function(listaCuentas) {
			$scope.respuestaCuentas = [];
			$scope.existeGuardadito = false;
			var cuentaCancelada = false;
			for ( var indexCuenta in listaCuentas) {
				var dataCuenta = {
					"foto" : "",
					"clienteUnico" : $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
					"cuenta" : listaCuentas[indexCuenta].cuentaSelecta,
					"tipoCuenta" : listaCuentas[indexCuenta].descProducto,
					"apellidoPaterno" : $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno,
					"apellidoMaterno" : $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
					"nombre" : $rootScope.solicitudJson.cotizacion.clientes[0].nombre,
				};
				
				/*Se agrega la validación cuentaCancelada para quitar aquellas cuentas canceladas y solo se tomen en cuenta las activas*/
				if(!listaCuentas[indexCuenta].estatusCuenta){
					console.log("Lista Cuentas " + listaCuentas);
				}else{
					cuentaCancelada = listaCuentas[indexCuenta].estatusCuenta.toUpperCase().indexOf("CANCELADA") != -1;
				}
						
				
				/*Valida las cuentas canceladas*/
				if(!cuentaCancelada){
					if (dataCuenta.tipoCuenta){
	                	if (dataCuenta.tipoCuenta.toUpperCase().indexOf("GUARDADITO") != -1) {
	                		$scope.respuestaCuentas.push(dataCuenta);
	                		$scope.existeGuardadito = true;
	                	}
	                }
				}
			}
		};/* END VACIAR LISTA CUENTAS FRUNCTION */

		$scope.vaciarListaCuentasApertura = function(listaCuentas) {
			$scope.respuestaCuentas = [];
			for ( var indexCuenta in listaCuentas) {
				var dataCuenta = {
					"foto" : "",
					"clienteUnico" : $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
					"cuenta" : listaCuentas[indexCuenta].cuentaSelecta,
					"tipoCuenta" : listaCuentas[indexCuenta].descProducto,
					"apellidoPaterno" : $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno,
					"apellidoMaterno" : $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
					"nombre" : $rootScope.solicitudJson.cotizacion.clientes[0].nombre,
				};
				
				$scope.respuestaCuentas.push(dataCuenta);
			}
		};/* END VACIAR LISTA CUENTAS FRUNCTION */

		$scope.detalle = function(cuentaSeleccionada){
			$scope.guardarDatosLiberacion(cuentaSeleccionada)
		};

		$scope.guardarDatosLiberacion=function(cuentaSeleccionada){
			
			var r = {
				idSolicitud: $rootScope.solicitudJson.idSolicitud,
				numCuenta: cuentaSeleccionada.cuenta,
				tipoCredito: DISPERSION_GUARDADITO   			
			};
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;										 												
			solicitudService.guardarDatosLiberacion(r).then(
				 function(data){
					 $rootScope.waitLoaderStatus = LOADER_HIDE;
					 
					 if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						 var responseJson = JSON.parse(data.data.respuesta);
						 
						 if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
							 $rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.tipoDispersionSeleccionado;
							 $rootScope.solicitudJson.tipoDispersion = r.tipoCredito;
							 generalService.locationPath(generalService.whichOneVisit(0));
						 }else{
							 $rootScope.message("Guardadito",[responseJson.descripcion],"Aceptar",null,"bgCafeZ", "cafeZ");
						 }
					 }else{
						 $rootScope.message("Guardadito", ["Error en Datos de Guardadito. Por favor comuniquese con soporte"],"Aceptar",null,"bgCafeZ", "cafeZ");
					 }
				 }, function(error){
					 $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
				 }
			);
		};
    
	});
});