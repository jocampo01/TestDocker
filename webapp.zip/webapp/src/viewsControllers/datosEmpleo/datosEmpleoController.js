'use strict';

define(["app"], function (app) {

	app.controller("datosEmpleoController", function ($timeout,$scope, $rootScope, modalService, generalService, solicitudService, buroService, messageData, validateService) {
		
//		colonia opcional
		 $scope.coloniaOpcional ={ desc: ""};
		
		$scope.pageClass = generalService.calculaVistas($rootScope.paginaActual,$rootScope.paginaAnterior,$rootScope.recuperaSolicitud);
		$scope.showPage = true;
		$scope.bloqueaSeccion = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].editable;
	    $scope.vistaDatosUsuario=configuracion.datosUsuario.opcion=0;
		var empleos=[];
		var actividadEmpresa=[];
		var estados=[];
		var tipoPago=[];
		var perIng=[];
		var antiguedadEmpresa=[];
		$scope.catalogoProfesion=false;
		//CARGA FECHAS
		var fechaDia = new Date();
		var dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
		var mm = ((fechaDia.getMonth() + 1) < 10 ? '0' : '') + (fechaDia.getMonth() + 1); 
		var aa = fechaDia.getFullYear();
		$scope.convertir = function(){
			$scope.datosAnteriores = JSON.stringify(DatosAnterioresArreglo('datosEmpleo'));
		}
		$scope.dias = ["01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"];
		$scope.meses = [{id:"01", descripcion:'ENERO'},
		                {id:"02", descripcion:'FEBRERO'},
		                {id:"03", descripcion:'MARZO'},
		                {id:"04", descripcion:'ABRIL'},
		                {id:"05", descripcion:'MAYO'},
		                {id:"06", descripcion:'JUNIO'},
		                {id:"07", descripcion:'JULIO'},
		                {id:"08", descripcion:'AGOSTO'},
		                {id:"09", descripcion:'SEPTIEMBRE'},
		                {id:"10", descripcion:'OCTUBRE'},
		                {id:"11", descripcion:'NOVIEMBRE'},
		                {id:"12", descripcion:'DICIEMBRE'}
		                ];
		$scope.cargaVista=function(){
			if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
			$scope.labelTiempo=MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO TIEMPO."+$scope.origen+".valor"];
			$scope.labelMin=" " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO MIN."+$scope.origen+".valor"];
			$scope.titulo             = generalService.getDataInput("DATOS EMPLEO","TITULO"             ,$scope.origen);
			$scope.empresa            = generalService.getDataInput("DATOS EMPLEO","EMPRESA"            ,null);
			$scope.giro               = generalService.getDataInput("DATOS EMPLEO","GIRO"               ,null);
			$scope.profesionOficio    = generalService.getDataInput("DATOS EMPLEO","PROFESION U OFICIO" ,null);
			$scope.tipoPago           = generalService.getDataInput("DATOS EMPLEO","TIPO PAGO"          ,null);
			$scope.calle              = generalService.getDataInput("DATOS EMPLEO","CALLE"              ,null);
			$scope.numExt             = generalService.getDataInput("DATOS EMPLEO","NUMERO EXT"         ,null);
			$scope.numInt             = generalService.getDataInput("DATOS EMPLEO","NUMERO INT"         ,null);
			$scope.codigoPostal       = generalService.getDataInput("DATOS EMPLEO","CODIGO POSTAL"      ,null);
			$scope.colonia            = generalService.getDataInput("DATOS EMPLEO","COLONIA"            ,null);
			$scope.poblacion          = generalService.getDataInput("DATOS EMPLEO","POBLACION"          ,null);
			$scope.estado             = generalService.getDataInput("DATOS EMPLEO","ESTADO"             ,null);
			$scope.telefono           = generalService.getDataInput("DATOS EMPLEO","TELEFONO"           ,null);
			$scope.extension          = generalService.getDataInput("DATOS EMPLEO","EXTENSION"          ,null);
			$scope.antiguedad={
					"tipoElemento"  : "select",
					"campo"         : "antiguedad",
					"marcaAgua"     : "Seleccione una opción",
					"visible"       : true,
					"deshabilitado" : false,
					"obligatorio"   : false,
					"buro"          : false,
					"cincom"        : false,
					"opcional"      : false,
					"estilo"        : "inpuSelect active",
					"imagen"        : "images/icon-form/calendario.png",
					"longMin"       : "",
					"longMax"       : "",
					"formato"       : "",
					"valor"         : "",
					"pattern"       : "",
					"texto"         : "",
					"colorModal"    : "",
					"colorSeccion"  : "",
					"CATALOGO"      : "catalogo"
				};
//			$scope.annoAntiguedad     = generalService.getDataInput("DATOS EMPLEO","ANNO ANTIGUEDAD"    ,null);
//			$scope.mesAntiguedad      = generalService.getDataInput("DATOS EMPLEO","MES ANTIGUEDAD"     ,null);
			$scope.cuandoPagan        = generalService.getDataInput("DATOS EMPLEO","CUANDO PAGAN"       ,null);
			$scope.etiquetaEmpleo     = generalService.getDataInput("DATOS EMPLEO","ETIQUETA EMPLEO"    ,$scope.origen);
			$scope.etiquetaDireccion  = generalService.getDataInput("DATOS EMPLEO","ETIQUETA DIRECCION" ,$scope.origen);
			$scope.etiquetaAntiguedad = generalService.getDataInput("DATOS EMPLEO","ETIQUETA ANTIGUEDAD",$scope.origen);
			$scope.etiquetaCuando     = generalService.getDataInput("DATOS EMPLEO","ETIQUETA CUANDO"    ,$scope.origen);
			$scope.btnGuardar         = generalService.getDataInput("DATOS EMPLEO","BOTON GUARDAR"      ,$scope.origen);			
			$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";
		};
			
		$scope.init = function(){

			/*\Se agrega un evento para la bitacora\*/
//			(Datos del Empleo)
			$rootScope.addEvent( BITACORA.SECCION.datosEmpleo.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje, BITACORA.SECCION.datosEmpleo.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
			
			$scope.inicio=true;				
			
			if(messageData){
				$scope.desdeAnno=$scope.desdeMes="";
				$scope.cargaVista();
				empleos=generalService.construirCatalogo("CATALOGO OCUPACION");
				actividadEmpresa=generalService.construirCatalogo("CATALOGO GIROS DE EMPRESA");
				tipoPago=generalService.construirCatalogo("CATALOGO TIPO DE PAGO");
				estados=generalService.construirCatalogo("CATALOGO ESTADOS");
				perIng=generalService.construirCatalogo("CATALOGO PERIODICIDAD PAGO");
				antiguedadEmpresa=generalService.construirCatalogo("CATALOGO ANTIGUEDAD");
	  			$scope.combos = {"empleos":empleos, "actividadEmpresa":actividadEmpresa, "tipoPago":tipoPago,
	  					         "estados":estados,"perIng":perIng, "antiguedadEmpresa":antiguedadEmpresa
	  			};
	  			generalService.setRespaldo($rootScope.solicitudJson);
	  			$scope.telefono.valor = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.telefono;
	  			$timeout(function(){
	  				$rootScope.waitLoaderStatus = LOADER_HIDE;
					$scope.convertir();
//		  			if ($scope.inicio){
		  				if($rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje > 0)
							cuentatext('datosEmpleo',null,true,$scope);
		  				$scope.showPage=true;
//		  			}
				}, TIME_OUT_VIEW_MODEL);
	  		
			}
	    };
	
		$scope.getDescripcionCatalogo = function(id, lista, fechaAnt){
			if(fechaAnt){
				var mmAnt=null;
				var aaAnt=null;
				var tiempo=null;
				var fechaInicial=new Date();
				switch(id){
					case 1:
						tiempo = 1;
						break;
					case 2:
						tiempo = 12;
						break;
					case 3:
						tiempo = 36;
						break;
					case 4:
						tiempo = 60
						break;
					case 5:
						tiempo = 61
						break;
					case 6:
				}
				fechaInicial.setMonth(fechaDia.getMonth() - tiempo);
				mmAnt = ((fechaInicial.getMonth() + 1) < 10 ? '0' : '') + (fechaInicial.getMonth() + 1); 
				aaAnt = fechaInicial.getFullYear();
				$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].antiguedad="01/"+mmAnt+"/"+aaAnt;
			}
			return generalService.descripcionCatalogo(id, lista);
		};
	
		$scope.cargaProfesiones=function(){
			if ($rootScope.solicitudJson.cotizacion.clientes[0].idPuesto > 0 &&
				$rootScope.solicitudJson.cotizacion.clientes[0].puestoDes != ""){
				$scope.idProfesionAnt=$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].idProfesion;
				$scope.profesionAnt=$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].profesion;
				$scope.cargoOcupacion();
				$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].idProfesion=$scope.idProfesionAnt;
				$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].profesion=$scope.profesionAnt;
			}
		};
		
		$scope.cargoOcupacion=function(){
			$rootScope.solicitudJson.cotizacion.clientes[0].puestoDes = $scope.getDescripcionCatalogo($rootScope.solicitudJson.cotizacion.clientes[0].idPuesto,$scope.combos.empleos);
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].idProfesion = null;
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].profesion = "";
			if (!$scope.catalogoProfesion){
				var profesion=[];
				var arr = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.CATALOGO PROFESIONES"];
				for(var i=0; i < arr.length; i++){
					if (arr[i]["ID OCUPACION"]["valor"] == 1)
						profesion.push( {id: parseInt(arr[i].ID.valor), descripcion:arr[i].ETIQUETA.valor, idOcupacion: arr[i]["ID OCUPACION"]["valor"]});
				}
				$scope.combos['profesion']=profesion;
				$scope.catalogoProfesion=true;
			}
			if ($rootScope.solicitudJson.cotizacion.clientes[0].idPuesto == 1 ||
				$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto == 2 ||
				$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto == 4 ||
				$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto == 5){
				if ($rootScope.solicitudJson.cotizacion.clientes[0].idPuesto == 1){
					$scope.profesionOficio.deshabilitado=false;
				}else{
					var arrProfesino = $scope.combos['profesion'];
					for(var i=0; i < arrProfesino.length; i++){
						if ($scope.combos['profesion'][i].idOcupacion == $rootScope.solicitudJson.cotizacion.clientes[0].idPuesto){
							$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].idProfesion = $scope.combos['profesion'][i].id;
							$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].profesion = $scope.combos['profesion'][i].descripcion;
						}
					}
				}
				$scope.profesionOficio.opcional=true;
				
			}else{
				$scope.profesionOficio.deshabilitado=true;
				$scope.profesionOficio.opcional=true;
				var arrProfesino = $scope.combos['profesion'];
				for(var i=0; i < arrProfesino.length; i++){
					if ($scope.combos['profesion'][i].idOcupacion == $rootScope.solicitudJson.cotizacion.clientes[0].idPuesto){
						$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].idProfesion = $scope.combos['profesion'][i].id;
						$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].profesion = $scope.combos['profesion'][i].descripcion;
					}
				}
			}
			if ($rootScope.solicitudJson.cotizacion.clientes[0].idPuesto == 6 || 
				$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto == 7 ||
				$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto == 8){
				$scope.bloqueaCampos();
				$scope.opcionalCancelado=true;
			}else{
				$scope.empresa.deshabilitado=$scope.giro.deshabilitado=$scope.tipoPago.deshabilitado=$scope.calle.deshabilitado=$scope.numExt.deshabilitado=$scope.numInt.deshabilitado=$scope.codigoPostal.deshabilitado=$scope.telefono.deshabilitado=$scope.extension.deshabilitado=$scope.antiguedad.deshabilitado=$scope.cuandoPagan.deshabilitado=false;
				$scope.opcionalCancelado=false;
			}
		};
		
		$scope.bloqueaCampos=function(){
			var datosLimpios =
				[
					{
						"idEmpleo":"",
						"nombreEmpresa": "",
						"idGiro": 0,
						"giro": "",
						"ext": "",
						"antiguedad": "",
						"idPeriodicidad": 0,
						"periodicidad": "",
						"empleoActual": 0,
						"porcentaje": 0,
						"idProfesion":null,
						"profesion":"",
						"idTipoPago":0,
						"tipoPago":"",
						"bloqueado": 0,
						"guardado": 0,
						"domicilio": 
						{
							"idDomicilio":"",
							"calle":"",
							"numeroExterior":"", 
							"numeroInterior":"",
							"cp": "",
							"colonia":"",
							"idDelegacion":0,
							"delegacion":"",
							"idEstado":0,
							"estado":"",
							"telefono":""
						}
					}
					];
			var idProfesionNew = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].idProfesion;
			var desProfesionNew = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].profesion;
			var porcentajeNew = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje;
			var guardadoNew = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].guardado;
			var idEmpleoNew = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].idEmpleo;
			var idDomicilioNew = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idDomicilio;
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0]=datosLimpios[0];
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].idProfesion = idProfesionNew;
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].profesion = desProfesionNew; 
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje = porcentajeNew;
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].guardado = guardadoNew;
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].idEmpleo = idEmpleoNew;
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idDomicilio = idDomicilioNew;
			$scope.desdeAnno=$scope.desdeMes="";
			$scope.empresa.deshabilitado=$scope.giro.deshabilitado=$scope.tipoPago.deshabilitado=$scope.calle.deshabilitado=$scope.numExt.deshabilitado=$scope.numInt.deshabilitado=$scope.codigoPostal.deshabilitado=$scope.colonia.deshabilitado=$scope.telefono.deshabilitado=$scope.extension.deshabilitado=$scope.antiguedad.deshabilitado=$scope.cuandoPagan.deshabilitado=true;
		};
		
	//DESDE CUANDO TRABAJAS AHI
		$scope.annoAnt=[];
		if ($rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento != "")
			var annoNacimiento = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento.split('/')[2];
		else
			var annoNacimiento = aa - 75;
		
		var fechaAnno = mm;
    	var fechaValida = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento.split('/')[1]; 
        var anno = new Date().getFullYear();
        if (fechaAnno < fechaValida){
        	anno = (parseInt(anno) - 1 ).toString();
        };
		
		
		for(var i=0;anno - i >= annoNacimiento;i++){
			var cadenaAnno = (parseInt(i) < 10 ? '0' : '') + (i.toString());
			if(parseInt(cadenaAnno) == 0)
				cadenaAnno = "0";
			$scope.annoAnt.push(cadenaAnno);
		}
		$scope.numMesAnt = ["0","01","02","03","04","05","06","07","08","09","10","11"];
		
//		$scope.cargaAntiguedad=function(){
//			if ($rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].antiguedad != ""){ 
//				var cargadoMM = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].antiguedad.split('/')[1]);
//				var cargadoAA = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].antiguedad.split('/')[2]);
//				if (cargadoMM > mm){
//					var mmAux = parseInt(mm) + 12;
//					var aaAux = parseInt(aa) - 1;
//					$scope.desdeMes = ((mmAux - cargadoMM) < 10 ? '0' : '') + (mmAux - cargadoMM);
//					if($scope.desdeMes == "00")
//						$scope.desdeMes="0";
//					$scope.desdeAnno = ((aaAux - cargadoAA) < 10 ? '0' : '') + (aaAux - cargadoAA);
//					if($scope.desdeAnno == "00")
//						$scope.desdeAnno="0";
//				}else{
//					$scope.desdeMes = ((mm - cargadoMM) < 10 ? '0' : '') + (mm - cargadoMM);
//					if($scope.desdeMes == "00")
//						$scope.desdeMes="0";
//					$scope.desdeAnno = ((aa - cargadoAA) < 10 ? '0' : '') + (aa - cargadoAA);
//					if($scope.desdeAnno == "00")
//						$scope.desdeAnno="0";
//				}
//				$scope.validaAnno();
//			}
//		};
		
//		$scope.validaAnno = function(){
//	    	var fechaNac = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento;
//	    	var fechaAnno = mm;
//	    	var fechaValida = fechaNac.split('/')[1];
//	        if (fechaAnno < fechaValida){
//	        	var aaCompara = (parseInt(aa) - 1 );
//	        }else
//	        	var aaCompara = parseInt(aa);
//	    	var anioNac = fechaNac.split('/')[2];
//	    	var mesNac = fechaNac.split('/')[1];
//	    	var numMes = ["0","01","02","03","04","05","06","07","08","09","10","11"];
//	    	
//	    	if ( (parseInt($scope.desdeAnno) + parseInt(anioNac)) == aaCompara ){
//	    		
//	    		var slice = 13 - (parseInt(mesNac) - mm);
//	    		if (slice >= 13){
//	    			slice = slice - 12 ;	    			
//	    		}
//	    		$scope.numMesAnt = numMes.slice(0,slice);
//	    	
//	    		if(parseInt($scope.desdeMes) > parseInt($scope.numMesAnt[slice - 1]))
//	    			$scope.desdeMes = $scope.numMesAnt[slice - 1];
//	    	}else{
//	    		$scope.numMesAnt = numMes;
//	    	}
//	    	
//	    };/* END VALIDA_ANNO FUNCTION */
	
	//RECUPERA REFERENCIAS DE CODIGO POSTAL
		$scope.cargaColonias=function(){
			if (parseInt($rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.cp) > 0){
				$scope.inicio=false;
				$scope.cargado=true;
				$scope.coloniaAnt=$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia;
				$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia="";
				$scope.getCP($scope.cargado);
			}
		};
		$scope.insertaCP=function(){
			var contPais=0;
			var colonias=[];
			//$scope.resp.registro = $scope.resp.registro.replace(/DISTRITO FEDERAL/gi,"CIUDAD DE MEXICO");
			$scope.resp.registro = $scope.resp.data.listaColonias;
			var numArr = $scope.resp.data.listaColonias.length;
			if (numArr > 0){				
				for(var i=0;i < numArr;i++){
					if ($scope.resp.registro[i].paisID == "1"){
						contPais = contPais + 1;
						var a=i+1;
						colonias.push({id:a,descripcion:$scope.resp.registro[i].descColonia,idProblacion:parseInt($scope.resp.registro[i].poblacionID),descPoblacion:$scope.resp.registro[i].descPoblacion,idEstado:parseInt($scope.resp.registro[i].edoID)});
						if (!$scope.cargado){
							if (i == 0){
								$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia="";
								$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.delegacion="";
								$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idDelegacion=0;
								$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.estado="";
								$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idEstado=0;
							}
						}else{
							$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia=$scope.coloniaAnt;
						}
					}
				}
				if (contPais == 1){
					$scope.colonia.deshabilitado=true;
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia=colonias[0].descripcion;
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.delegacion=colonias[0].descPoblacion;
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idDelegacion=colonias[0].idProblacion;
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idEstado=parseInt(colonias[0].idEstado);
				}else if (contPais > 0)
						$scope.colonia.deshabilitado=false;
					  else
						$scope.sinDatosCP();
			}
//			else{
//				$scope.colonia.deshabilitado=true;
//				if ($scope.resp.registro.paisID == "1"){
//					contPais = contPais + 1;
//					colonias.push({id:numArr,descripcion:$scope.resp.registro.descColonia});
//					if (!$scope.cargado)
//				    	$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia=$scope.resp.registro.descColonia;
//					else
//						$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia=$scope.coloniaAnt;
//					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.delegacion=$scope.resp.registro.descPoblacion;
//					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idDelegacion=parseInt($scope.resp.registro.poblacionID);
//					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idEstado=parseInt($scope.resp.registro.edoID);
//				}else
//					$scope.sinDatosCP();
//			}
			if (contPais == 1){
				for(i=0;i < $scope.combos.estados.length;i++){
					if($scope.combos.estados[i].id == $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idEstado)
						$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.estado=$scope.combos.estados[i].descripcion;
				}
			}
			
//			var dataObj ={"id":a,
//			"descripcion":$scope.resp.registro[i].descColonia,
//			"idProblacion":parseInt($scope.resp.registro[i].poblacionID),
//			"descPoblacion":$scope.resp.registro[i].descPoblacion,
//			"idEstado":parseInt($scope.resp.registro[i].edoID)};
			var dataObj = {
					"id": 999,
					"descripcion": "NO SE ENCUENTRA COLONIA",
					"idProblacion":colonias[0].idProblacion,
					"descPoblacion":colonias[0].descPoblacion,
					"idEstado":colonias[0].idEstado
				};
			
			colonias.push( dataObj );
			if ($rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia){
				
				
				var index = colonias.map(function(d){
					return d["descripcion"];
					
				}).indexOf ($rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia);
				
				if (index == -1){
					 $scope.coloniaOpcional.desc = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia;
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia = "NO SE ENCUENTRA COLONIA";
					$scope.muestraColoniaOpc=true;
					generalService.setRespaldo($rootScope.solicitudJson);
				}
				
			}
				
			if (contPais > 0)
				$scope.combos['colonias']=colonias;
			
			 
			
		};
		$scope.getCP=function(cpValido){
			if (cpValido && parseInt($rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.cp) > 0 && ($scope.cpAnterior != $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.cp)){
				$scope.cpAnterior = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.cp;
				$scope.miniLoading=true;
				 $scope.coloniaOpcional.desc = "";
	    		$scope.muestraColoniaOpc=false;
				solicitudService.consultaCP($rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.cp).then(
						function(data){
							$scope.miniLoading=false;
 
							if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
								$scope.resp=JSON.parse(data.data.respuesta);
								if($scope.resp.codigo == 2){
									$scope.insertaCP();
									$scope.cpAnterior = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.cp;
								}
								else
		     						$scope.sinDatosCP();
							}
							if($scope.cargado){
								$scope.cargado=false;
								$scope.showPage=true;
							}
						},function(error){
							$scope.miniLoading=false;
							if($scope.cargado){
								$scope.cargado=false;
								$scope.showPage=true;
							}
	 						$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.cp=null;
	 						$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia="";
							$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.delegacion="";
							$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idDelegacion=0;
							$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.estado="";
							$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idEstado=0;
							$scope.combos.colonias=[];
							$scope.colonia.deshabilitado=true;
						});
			}else{
				if (!cpValido){
					if ($rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.cp){
						$scope.cpAnterior = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.cp;
					}else{
						var element = document.getElementsByName($scope.codigoPostal.campo)
						if (element.length > 0)
							$scope.cpAnterior = element[0].value
					}
				}
				if (!$scope.cargado){
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia="";
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.delegacion="";
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idDelegacion=0;
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.estado="";
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idEstado=0;
					$scope.combos.colonias=[];
					$scope.colonia.deshabilitado=true;
				}
			}
		};
		
		$scope.sinDatosCP=function(){
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.cp=null;
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia="";
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.delegacion="";
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idDelegacion=0;
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.estado="";
			$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idEstado=0;
			$scope.combos.colonias=[];
			$scope.colonia.deshabilitado=true;
			$rootScope.message( $scope.titulo.texto, ["El código postal es inválido."], "Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion,null,"GENERAL","ERROR CP"  );	
		};
		
		$scope.cargaDelegacion=function(){
			if($rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia == "NO SE ENCUENTRA COLONIA"){
//	    		 $scope.coloniaOpcional = coloniaOpcional;
	    		$scope.muestraColoniaOpc=true;
//	    		id = 999;
	    	}else{
	    		$scope.muestraColoniaOpc=false;
//	    		id = 0;
	    		 $scope.coloniaOpcional.desc =""
	    	}
			var array = $scope.combos.colonias;
			var ok=true;
			for(var i=0;ok;i++){
				if($rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia == $scope.combos.colonias[i].descripcion){
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.delegacion=$scope.combos.colonias[i].descPoblacion;
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idDelegacion=$scope.combos.colonias[i].idProblacion;
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idEstado=parseInt($scope.combos.colonias[i].idEstado);
					var okEstado=true;
					for(var a=0;okEstado;a++){
						if($scope.combos.estados[a].id == $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idEstado){
							$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.estado=$scope.combos.estados[a].descripcion;
							okEstado=false;
						}
					}
					ok=false;
				}
			}
		};
		
	//SERVICIO
		$scope.enviaGuardar=function(form){
			if (form.$valid){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$timeout(function(){
					$scope.guardar(form);
				}, 0);
			}
		};
		
		$scope.guardar = function(form){
//			if ($scope.opcionalCancelado){
				var datosValidos=true;
				if ($scope.muestraColoniaOpc)
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.colonia =  $scope.coloniaOpcional.desc ;
//				var mmAux = 0;
//				var aaAux = 0;
//				if ($scope.desdeAnno == "" && $scope.desdeMes == "")
//					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].antiguedad="";
//				else{
//					if ($scope.desdeAnno == "" || $scope.desdeMes == "")
//						datosValidos=false;
//					else{
//						if (parseInt(mm) <= parseInt($scope.desdeMes)){
//							mmAux = parseInt(mm) + 12;
//							aaAux = parseInt(aa) - 1;
//						}else{
//							mmAux = parseInt(mm);
//							aaAux = parseInt(aa);
//						}
//						var cadenaMM = ((parseInt(mmAux)-parseInt($scope.desdeMes)) < 10 ? '0' : '') + (parseInt(mmAux)-parseInt($scope.desdeMes));
//						var cadenaAA = aaAux-parseInt($scope.desdeAnno);
//						$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].antiguedad="01/"+cadenaMM+"/"+cadenaAA;					
//					}
//				}
				if (datosValidos || $scope.opcionalCancelado){
					validateService.limpiaMascaras();
					var porcentajeant = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje;
					if ($scope.opcionalCancelado)
						$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje = 100;
					else
						$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje = cuentatext('datosEmpleo');
					
					if (offLine){				
						$rootScope.cargaDocumentos();
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.porcentajes.secciones[2].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje;
						generalService.locationPath("/ochoPasos");
					}else{
						$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].empleoActual=1;
						var solicitudJsonString = JSON.stringify($rootScope.solicitudJson);
						solicitudService.saveSolicitud( { solicitudJson:solicitudJsonString , seccion: 3 } ).then(
							function(data){
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								
								if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
									var responseJson = JSON.parse(data.data.respuesta);						
									if(responseJson.codigo == 2){
										$rootScope.solicitudJson = responseJson.data;	
										
										/*\Se agrega un evento para la bitacora\*/
//										(Datos del Empleo)
										$rootScope.addEvent( BITACORA.SECCION.datosEmpleo.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.guardar.id, $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje, BITACORA.SECCION.datosEmpleo.guardarEnBD );
										/*\Se agrega un evento para la bitacora\*/
										
										$rootScope.porcentajes.secciones[2].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje;
										$scope.datosActuales = JSON.stringify(DatosAnterioresArreglo('datosEmpleo'));
										$rootScope.calculaDocumentos();
										
										if(generalService.productosQuickFixes()){
											generalService.locationPath( "/ochoPasos",true);
										}else{
											solicitudService.validaFolioCallCenter(JSON.parse(solicitudJsonString), responseJson.data)
															.then(
																	function(data){
																		if(data == null){
																			buroService.consultaBuro( $scope.titulo.colorModal, "btn gris","btn azulD" );
																		}else
																			generalService.locationPath(data);
																	},function(error){
																		
																	}
																);
										}
										
																																
									}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
										var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
										$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
									}else{
										if(responseJson.codigo == ERROR_SOL_RECHAZADA){
											var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
											var marca = $rootScope.solicitudJson.marca;
											var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
											var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
											$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],
													"Aceptar", "/simulador",  $scope.titulo.colorModal , $scope.titulo.colorSeccion,buildJsonDefault);
										}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
											generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
											generalService.locationPath("/ficha");
										}else{
											$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje = porcentajeant;
											$rootScope.message($scope.titulo.texto,["Error al guardar sección. Código " +
													"de error [" + responseJson.codigo + "] no identificado."], 
											"Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion);
										}
									}
								}else{
									$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje = porcentajeant;
									$rootScope.message($scope.titulo.texto,["Error en la respuesta del servicio para guardar los datos de la sección de Datos del Empleo. Por favor, reintente nuevamente."], "Aceptar", null,  $scope.titulo.colorModal, $scope.titulo.colorSeccion);
								}
								
							}, function(error){
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje = porcentajeant;
							}
						);
					}
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Error",["Fecha invalida"], "Aceptar", null, "bgRojo", "rojo", null, "GENERAL", "ERROR FECHA");
				}
				$scope.validaTel = function(telefono) {
					 if (telefono){
						 $scope.datosEmpleo.telefono.$invalid  = false;
						 $scope.validatelefono = false;										 
					 }else{
						 $scope.datosEmpleo.telefono.$invalid  = true;
						 $scope.validatelefono = true;
					 }
					console.log("telefono " + telefono + " valida " + $scope.validatelefono)
				}
//			}else
//				$rootScope.waitLoaderStatus = LOADER_HIDE;
		};
	});
});