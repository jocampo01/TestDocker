'use strict';

define(["app"], function (app) {

	app.controller("datosEncuestaController", function ($scope, $rootScope, generalService, solicitudService) {
	
		/**
		 * Declaración de variables globales
		 **/
		$scope.showPage = true;
		$scope.cssPreguntasRadioButton = [];
		$scope.bloqueaBotonPregunta = true;
		var indexResp = undefined;
		var tiempoFinal = 0;
		var tiempoInicio = 0;
		
		/**
		 * Función que se manda a llamar cuando se carga la vista
		 * Contiene un manejo de errores globales (try/catch)
		 * Los errores que se presenten dentro de esta función se reflejaran en el LOG
		 * El manjeo de errores en esta funcion, solo contiene a las funciones cargaVista(), y obtienePreguntas() y evaluaMostrarPregunta()
		 * Si contiene el idsolicitud, continuara con el proceso. Si no, manda un mensaje indicandole que no esxiste una solicitud en proceso 
		 **/
		$scope.init = function(){
			$scope.cssPreguntasRadioButton = [];
			$scope.bloqueaBotonPregunta = true;
			indexResp = undefined;
			tiempoFinal = 0;
			tiempoInicio = 0
			if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto))
				$scope.pathTarjetas = "/liberacion";
			else{
				$scope.pathTarjetas = "/credito";
				 $rootScope.informeRecomendado();
			}
			try{
				if($rootScope.solicitudJson.idSolicitud != undefined){
					cargaVista();
				}else{
			    		var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
			    		$rootScope.message("Aviso ", ["No existe una solicitud en proceso"],"Aceptar","/simulador",null,null,buildJsonDefault);
			    	}
			}catch(e){
				$rootScope.loggerIpad("Error Controlador Datos Encuesta", {error:e.message, detalle: e.stack});
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				
				var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
				$rootScope.message("Aviso ", ["Hubo un error en el proceso, por favor, comuniquese con soporte"],"Aceptar","/simulador",null,null,buildJsonDefault);
			}
	    };
	    
	    /**
	     * Función para cargar la vista principal
	     * Se parametriza la layenda del titulo y sus estilos
	     * Se inicializa el boton para guardar la bateria con la leyenda 'Siguiente'
	     * Manda a llamar a la función 'obtienePreguntas()'
	     **/
	    function cargaVista(){
			$scope.titulo             = {tipoElemento:"titulo",campo:"textoTitulo",marcaAgua:"undefined",visible:true,estilo:"mainHeader naranja",imagen:"images/header/datosEmpleo.png",valor:"",texto:"Encuesta",colorModal:"bgNaranja",colorSeccion:"naranja",CATALOGO:"catalogo"};
			$scope.btnGuardar         = {estilo:"btn naranja", texto:"Siguiente", visible:true}
			$scope.bloqueaSeccion = false;
			
			obtienePreguntas();
		};
		
		/**
		 * Función para generar y obtener de base por medio del id de la solicitud la bateria de preguntas
		 **/
		function obtienePreguntas(){
			
			/**
			 * Se arma el JSON para guardar la bateria de preguntas
			 * idSolicitud, el id de la solicitud
			 **/
			var json = {
				idSolicitud: $rootScope.solicitudJson.idSolicitud
			};
			
			/**
			 * Se levanta el Spin
			 **/
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			solicitudService.obtenerBateriaPreguntasRespuestas(json).then(
				function(data){
					/**
					 * Se baja el spin
					 * Si el parametro 'data.data.codigo' es igual a 1 --> no hubo error en los puentes
					 * Si transforma la respuesta de String a JSON
					 **/
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var jResponse = JSON.parse(data.data.respuesta);
						
						if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							/**
							 * Código 2 --> Continua con el proceso del llenado de la bateria de preguntas
							 * Se bloquean todas las secciones del menú que se encuentran del lado izquierdo
							 * Se manda a llamar la función 'evaluaMostrarPregunta()' (Explicación en la Función)
							 * Se inicializa el tiempo para contestar la pregunta 'tiempoInicio'
							 **/							
							$rootScope.solicitudJson.cotizacion.clientes[0].bloqueado = 1;
							$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado = 1;
							$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].bloqueado = 1;
							$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.bloqueado = 1;
							$rootScope.solicitudJson.referencias.bloqueado = 1;
							$rootScope.solicitudJson.documentos.bloqueado = 1;
							$rootScope.solicitudJson.contratos.bloqueado = 1;
							
							$scope.datosEncuesta = jResponse.data;
							evaluaMostrarPregunta();
							tiempoInicio = new Date().getTime();
						}else if(jResponse.codigo == RESPONSE_ORIGINACION_GENERA_BATERIA){
							/**
							 *Código 28002 --> Hubo un error en la generación de la bateria de preguntas, la marca es 4007 y continua hacia el 'Dia de Pago'
							 **/
							$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.errorBateriaBuro;
							generalService.locationPath($scope.pathTarjetas);
						}else if(jResponse.codigo == RESPONSE_ORIGINACION_ERROR_ID){
							/**
							 * Código 464 --> Se detiene porque no encontro el idSolicitud y manda al 'Simulador'
							**/
							var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
							$rootScope.message("Error", [ ERROR_SERVICE, jResponse.descripcion],"Aceptar","/simulador","bgCafeZ", "cafeZ", buildJsonDefault);
						}else{
							/**
							 * Si no se tiene un codigo mapeado, manda un erro genérico y va a la pantalla del simulador
							 **/
							var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
							$rootScope.message("Error", [ ERROR_SERVICE, jResponse.descripcion],"Aceptar","/simulador","bgCafeZ", "cafeZ", buildJsonDefault);
						}					
					}else{
						/**
						 * Si no se tiene un codigo mapeado, manda un erro genérico y va a la pantalla del simulador
						 **/
						var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
						$rootScope.message("Error", [ ERROR_SERVICE, "Error "+jResponse.codigo],"Aceptar","/simulador","bgCafeZ", "cafeZ", buildJsonDefault);
					}
				}, function(error){
	               $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
					
				}
			); 
		}
		
		/**
		 * Función que evalua las preguntas y sus respuestas de la bateria de preguntas
		 * Contiene un manejo de errores globales (try/catch)
		 * Los errores que se presenten dentro de esta función se reflejaran en el LOG
		 * El manjeo de errores en esta funcion, solo contiene a las funciones indicePosicionSeleccionado(), y calculaPorcentaje() y evaluaMostrarPregunta()
		 **/
		$scope.evalPregunta = function(indexPregunta){
			try{
				/**
				 * Se manda a llamar a la funcion 'indicePosicionSeleccionado()' y guarda la posición de la respuesta que fues seleccionada para la pregunta que contiene el indice en la variable 'indexPregunta' (Explicación en la Función)
				 **/
				var respuestaActivada = indicePosicionSeleccionado(indexPregunta);
				
				/**
				 * Si el la variable 'respuestaActivada' viene en -1, quiere decir que no encontro ninguna respuesta seleccionada
				 * Si viene en 0, 1 o la posicion de la respuesta dentro de la pregunta seleccionada, es que si se seleccionó una respuesta
				 **/
				if(respuestaActivada != -1){
					/**
					 * Se guarda, dependiendo de la respuesta, el valor de 1 dentro del JSON de la bateria de preguntas --> preguntas(i) --> respuesta (j)
					 * Se guarda el tiempo que le tomo en contestar la pregunta al asesor 'tiempoFinal'
					 * Se saca el tiempo total (tiempo de inicio - tiempo final) en el campo 'tiempo' de la pregunta seleccionada
					 * Se manda a llamar la funcion 'calculaPorcentaje()' y se calcula el porcentaje de avance para la bateria de preguntas (Explicación en la Función)
					 **/
					$scope.datosEncuesta.bateriaPreguntas[indexPregunta].respuestas[respuestaActivada].isSeleccionada = 1;
					tiempoFinal = new Date().getTime();
					$scope.datosEncuesta.bateriaPreguntas[indexPregunta].tiempo = (tiempoFinal-tiempoInicio);
					calculaPorcentaje();
					
					/**
					 * Se arma el JSON para guardar la bateria de preguntas
					 * idSolicitud, el id de la solicitud
					 * jsonBateria, el JSON que contiene toda la información de la bateria
					 **/
					var json = {
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						jsonBateria: $scope.datosEncuesta, 
					}
					
					/**
					 * Se levanta el Spin
					 **/
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					
					solicitudService.guardarBateriaPreguntas(json).then(
						function(data){
							/**
							 * Se baja el spin
							 * Si el parametro 'data.data.codigo' es igual a 1 --> no hubo error en los puentes
							 * Si transforma la respuesta de String a JSON
							 **/
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var jResponse = JSON.parse(data.data.respuesta);
								
								if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									/** 
									 * Código 2 --> Continua con la evaluación de la las preguntas
									 * Se manda a llamar la función 'evaluaMostrarPregunta()' (Explicación en la Función)
									 * Se inicializa el tiempo para contestar la pregunta 'tiempoInicio'
									 **/
									evaluaMostrarPregunta();
									$scope.datosEncuesta = jResponse.data;
									tiempoInicio = new Date().getTime();
								}else if(jResponse.codigo == RESPONSE_ORIGINACION_EVALUACION_BATERIA_LIBERA){
									/** 
									 * Código 28005 --> Se proceso correctamente la evalución de la bateria por buro, la marca es 4008 y continua al 'Dia de Pago'
									 * Si el porcentaje de la bateria de preguntas es 100, continua al 'Dia de Pago'
									 * Si es diferente de 100, se manda un mensaje indicando que faltan preguntas por contestar
									 * Se reinicia la vista y se obtiene de nuevo la bateria de preguntas 
									 **/
									if($scope.datosEncuesta.porcentaje == 100){
										$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.evalucionCorrectaBateria;
										generalService.locationPath($scope.pathTarjetas);
									}else{
										$rootScope.message("Advertencia",["Aun tienes preguntas pedientes por contestar, por favor, termina la encuesta"], "Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion);
										$scope.init();
									}
								}else if(jResponse.codigo == RESPONSE_ORIGINACION_EVALUACION_BATERIA_MESA){
									/** 
									 * Código 28004 --> Buró dictamino que la solicitud se vaya a mesa, la marca es 4009, en esta fase, debe continuar al 'Dia de Pago'
									 **/
									$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.evalucionCorrectaBateriaMCO;
									generalService.locationPath($scope.pathTarjetas);
								}else if(jResponse.codigo == RESPONSE_ORIGINACION_GENERA_BATERIA){
									/** 
									 * Código 28002 --> Error en la evaluacion de la bateria con Buró, la marca es 4007, y debe continuar al 'Dia de Pago'
									 **/
									$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.errorBateriaBuro;
									generalService.locationPath($scope.pathTarjetas);
								}else{
									/**
									 * Si no se tiene un codigo mapeado, manda un erro genérico y va a la pantalla del simulador
									 **/
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$rootScope.message("Error", [ ERROR_SERVICE, jResponse.descripcion],"Aceptar","/simulador","bgCafeZ", "cafeZ", buildJsonDefault);
								}					
							}else{
								/**
								 * Si no se tiene un codigo mapeado, manda un erro genérico y va a la pantalla del simulador
								 **/
								var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
								$rootScope.message("Error", [ ERROR_SERVICE, "Error "+jResponse.codigo],"Aceptar","/simulador","bgCafeZ", "cafeZ", buildJsonDefault);
							}
						}, function(error){
			               $rootScope.waitLoaderStatus = LOADER_HIDE;
						}
					);
				}else{
					/**
					 * Si no seleccionó una pregunta se le manda un mensaje indicando que debe seleccionar una respuesta para poder continuar.
					 **/
					$rootScope.message("Advertencia",["Por favor, seleccione una de las opciones para continuar con la siguiente pregunta."], "Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion);
				}
			}catch(e){
				$rootScope.loggerIpad("Error Controlador Datos Encuesta", {error:e.message, detalle: e.stack});
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				
				var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
				$rootScope.message("Aviso ", ["Hubo un error en el proceso, por favor, comuniquese con soporte"],"Aceptar","/simulador",null,null,buildJsonDefault);
			}
		}

		/**
		 * 
		 * Función que recibe como parametro el indice (i) de la pregunta que se esta evaluando
		 * Se toma por medio del id de la pregunta ([i][j] i = pregunta y j = respuesta), cual de las respuestas (j) tiene el valor de 1
		 * La funcion devuelve como valor el indice (j) de la respuesta seleccionada de esa pregunta
		 * 
		 **/
		function indicePosicionSeleccionado(indexPregunta){
			var respuestaActivada = -1;
			for(var j=0;j<$scope.datosEncuesta.bateriaPreguntas[indexPregunta].respuestas.length;j++){
				var valorPregunta = document.getElementById(''+indexPregunta+''+j).checked;
				
				if(valorPregunta){
					respuestaActivada = j;
					break;
				}
			}
			
			return respuestaActivada;
		}
		
		/**
		 * 
		 * Función para mostrar preguntas de una en una.
		 * Se crea el arreglo 'cssPreguntasRadioButton' que tendrá los mismo elementos que '$scope.datosEncuesta.bateriaPreguntas'
		 * Se valida que, si una pregunta tiene el campo 'idSeleccion' en 0 en las respuestas de esa pregunta, se coloca en true y las demas preguntas, automaticamente, se colocan en false
		 * El valor de true indica que se va mostrar, el valor de false, indica que no se va a mostrar
		 * El campo 'contadorFaltaContestar' aumenta cada que encuentra preguntas que en el campo 'idSeleccion' de sus respuestas, contengan 0
		 * Si el campo 'contadorFaltaContestar' es igual a 1, se cambia la leyenda del boton de 'Siguiente' a 'Terminar'
		 * 
		 **/
		function evaluaMostrarPregunta(){
			$scope.cssPreguntasRadioButton = [];
			var banderaValidar = true;
			var contadorFaltaContestar = 0;
			
			for(var i=0;i<$scope.datosEncuesta.bateriaPreguntas.length;i++){
				var banderaValorResp = false;
				
				for(var j=0;j<$scope.datosEncuesta.bateriaPreguntas[i].respuestas.length;j++){
					if($scope.datosEncuesta.bateriaPreguntas[i].respuestas[j].isSeleccionada > 0){
						banderaValorResp = true;
						contadorFaltaContestar++;
						break;
					}
				}
				
				if(!banderaValorResp && banderaValidar){
					$scope.cssPreguntasRadioButton.push({mostrarPregunta:true});
					banderaValidar = false;
				}else{
					$scope.cssPreguntasRadioButton.push({mostrarPregunta:false});
				}
			}
			
			if(($scope.datosEncuesta.bateriaPreguntas.length - contadorFaltaContestar) == 1){
				$scope.bloqueaBotonPregunta = false;
				$scope.btnGuardar.texto = "Terminar";
			}
		}
		
		/**
		 *
		 * Función que calcula el porcentaje de las preguntas cada que se contesta una
		 * Se inicializa el porcentaje de la bateria de preguntas en 0
		 * Se valida que, si en la pregunta, al menos una respuesta tiene el campo 'idSeleccion' en 1, se marca la bandera 'banderaPorcentaje' en true
		 * Si la bandera 'banderaPorcentaje' es true, se dividira el total de porcentaje requerido (100) entre el numero total de preguntas, mas lo que ya se tenga de porcentaje
		 * Se asigna el porcentaje al JSON de la bateria de preguntas
		 * 
		 **/
		function calculaPorcentaje(){
			$scope.datosEncuesta.porcentaje = 0;
			
			for(var i=0;i<$scope.datosEncuesta.bateriaPreguntas.length;i++){
				var banderaPorcentaje = false;
				for(var j=0;j<$scope.datosEncuesta.bateriaPreguntas[i].respuestas.length;j++){
					if($scope.datosEncuesta.bateriaPreguntas[i].respuestas[j].isSeleccionada >0){
						banderaPorcentaje = true;
						break;
					}
				}
				
				if(banderaPorcentaje){
					$scope.datosEncuesta.porcentaje = $scope.datosEncuesta.porcentaje + (100/$scope.datosEncuesta.bateriaPreguntas.length);
				}
			}
			
			$scope.datosEncuesta.porcentaje = Math.round($scope.datosEncuesta.porcentaje);
		}		
	})
});