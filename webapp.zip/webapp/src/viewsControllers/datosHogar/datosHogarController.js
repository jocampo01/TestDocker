'use strict';

define(["app"], function (app) {
	
	app.factory( 'GlobalVariablesService', function(){
	
	    function getArrayYears( fecha, mm, dd )
	    {
	    	var fechaAnno = mm;
	    	var fechaValida = fecha.split('/')[1]; 
	    	var aaNacimiento = fecha.split('/')[2];
	        var array_years = [];
	        var anno = new Date().getFullYear();
	        if (fechaAnno < fechaValida){
	        	anno = (parseInt(anno) - 1 ).toString();
	        };
	        for( var year = 0; (anno - year) >= aaNacimiento; year++ ){
	        
	        	var cadenaAnno = (parseInt(year) < 10 ? '0' : '') + (year.toString());
	        	if(parseInt(cadenaAnno) == 0)
	        		cadenaAnno="0";
	    		array_years.push(cadenaAnno);	        	
	        }
	
	        return array_years;
	
	    }
	
	    function getArrayDays()
	    {
	
	        var array_days = [];
	    	
	        for( var day = 0; day < 31; day++ ){
	            
	        	array_days.push( ( day < 10 ? '0' + day : day )  );
	        	
	        }
	
	        return array_days;
	
	    }
	
	    function getArrayMonths()
	    {
	        return ( ["0","01","02","03","04","05","06","07","08","09","10","11"] );
	    }
	
	    function getMonthByYear()
	    {
	
	    }
	
	    return {
	        getArrayYears: getArrayYears,
	        getArrayDays: getArrayDays,
	        getArrayMonths: getArrayMonths,
	        getMonthByYear: getMonthByYear
	    };
	
	});
	
	app.controller( 'datosHogarController', function ( $rootScope, /*MarkerCreatorService,*/ GlobalVariablesService, $scope, generalService, solicitudService, 
														modalService, buroService, $timeout, messageData, validateService, MapService,MapConstants, MapBazService ) {
		
	    /**
	     * Bandera para activar la enmarcación de los recuadros de los imput en rojo.
	     * Se inicializa en false, al cambiar de código postal, esta se activa.
	     **/
		$scope.cCheckDatosHogar=false;
	    $rootScope.activaErrores = false;
	    $rootScope.banderaIsFoundCP = false;
	    $rootScope.consultaPrimeraVez = true;
	    
		$scope.confTipoWindows = configuracion.so.windows;
		$scope.esProduccion = generalService.isProduccion();
		$scope.isBazDigital = generalService.isBazDigital();
		$scope.mapasGoogleShow = true;
		$scope.mapasBancoShow = false;
		if(!$rootScope.solicitudJson.avales[0].datosHogar.zonificacion){
			$rootScope.solicitudJson.avales[0].datosHogar.zonificacion = {};
		}
		$rootScope.coloniaOpcional = "";
		$scope.zipCodeAnterior = "";
		$scope.muestraColoniaOpc=false;
		$scope.nAnio=$scope.nMes="";
		$scope.pageClass = generalService.calculaVistas($rootScope.paginaActual,$rootScope.paginaAnterior,$rootScope.recuperaSolicitud);
		$scope.bloqueaSeccion = ($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].editable==0 || $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.malZonificada.id)?false:true;
		$scope.vistaDatosUsuario=configuracion.datosUsuario.opcion=0;
//		$rootScope.waitLoaderStatus = LOADER_SHOW;	
		var json_T = $rootScope.solicitudJson.cotizacion.clientes;
				
		var zona_T = json_T[0].domicilios[0].zonificacion;
		
		$scope.convertir = function(){
			$scope.datosAnteriores = JSON.stringify(DatosAnterioresArreglo('datosHogar', 'buro'));
			$scope.datosAnterioresM = JSON.stringify(DatosAnterioresArreglo('datosHogar', 'cincom'));
			$scope.datosRespaldo = DatosAnterioresArreglo('datosHogar', 'edicion');
// I-MODIFICACION TDC (VALIDAR CAMBIO DE DOMICILIO PARA PREAPROBADOS EN TARJETAS)
			$scope.datosAnterioresTDC = JSON.stringify(DatosAnterioresArreglo('datosHogar', 'vCambio'));
// F-MODIFICACION TDC (VALIDAR CAMBIO DE DOMICILIO PARA PREAPROBADOS EN TARJETAS)
		}
						
		$scope.gralAddress = {};
	    $scope.completeAddress = '';
	    
	    var upu_address = [ '', '', '', '', '', '', ''];
	    
	    $scope.combos = {};
	    
		var fechaDia = new Date();
		var dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
		var mm = ((fechaDia.getMonth() + 1) < 10 ? '0' : '') + (fechaDia.getMonth() + 1); 
		var aa = fechaDia.getFullYear();
	    		   
	    $scope.init = function()
	    {
	    	
	    	/*\Se agrega un evento para la bitacora\*/
//			(Datos Hogar)
	    	$rootScope.addEvent( BITACORA.SECCION.datosHogar.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje, BITACORA.SECCION.datosHogar.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
	    	
	    	$scope.showDatosHogar = false;
//	    	$scope.showDatosHogar = messageData;
	    	generalService.setRespaldoDom($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0]);
	    	
	    	$scope.configFullScreen();
	    	if(zona_T.latitud == ""  && zona_T.longitud == ""){
	    		$scope.datosConexion();
	    	}
	    	
	    	//Regla para mostrar zonificación
	    	$scope.showSeccionMapa = generalService.validateShowMapa();
	    	
	    	if( messageData ){
	    		
	    		$scope.setContentPage();

	    		generalService.setRespaldo($rootScope.solicitudJson);
	    		if($rootScope.ocrColonia != null)
	    			$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.ocrColonia;
	    		

				setYears();
				setMonths();
		        
		    	var estados = [];
				estados = generalService.construirCatalogo("CATALOGO ESTADOS");//["Aguascalientes", "Baja California", "Baja California Sur", "Campeche", "Chiapas", "Chihuahua", "Coahuila de Zaragoza", "Colima", "Distrito Federal", "Durango", "Guanajuato", "Guerrero", "Hidalgo", "Jalisco", "Mexico", "Michoacan de Ocampo", "Morelos", "Nayarit", "Nuevo Leon", "Oaxaca", "Puebla", "Queretaro de Arteaga", "Quintana Roo", "San Luis Potosi", "Sinaloa", "Sonora", "Tabasco", "Tamaulipas", "Tlaxcala", "Veracruz-Llave", "Yucatan", "Zacatecas"];
				
				var clases = [];
				clases = generalService.construirCatalogo("CATALOGO CLASE VIVIENDA");
				
				var viviendas = [];
				viviendas = generalService.construirCatalogo("CATALOGO TIPO DE DOMICILIO");
				
				var antiguedadEmpresa = [];
				antiguedadEmpresa=generalService.construirCatalogo("CATALOGO ANTIGUEDAD");
				
				$scope.combos = {
					"estados": estados,
					"clases": clases,
					"viviendas": viviendas,
					"antiguedadEmpresa": antiguedadEmpresa
				};
				
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].antiguedadDes = validaCaracteres($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].antiguedadDes);
				
				$scope.datosHogar.telefono = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].telefono;
					
				
				$timeout(function(){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$scope.convertir();
					if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje > 0){
						cuentatext('datosHogar',null,true,$scope);
						$scope.porcMayor=true;
					}
					$scope.showDatosHogar = messageData;
//					$scope.mapasBancoShow = false;
					
					if(!$scope.showSeccionMapa && ($scope.confTipoWindows) && ($rootScope.consultaFuncionalidad.tipoCartografiaZonificacion)){
						$scope.cargarIdCartografia();
					}else if($scope.mapasBancoShow && !$scope.mapasGoogleShow ){
						$scope.showSeccionMapa = false;
					}						
				}, TIME_OUT_VIEW_MODEL);
				
			}
	    
	    };/* END INIT FUNCITON */
	    
	    /* 
    	 *Ws Maps que consulta el id de cartografia para los mapas 
    	 */
	    $scope.cargarIdCartografia = function(){		    	
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	solicitudService.consultaIdCartografia($rootScope.solicitudJson.idSolicitud).then(	    	
	    			function(data){	    				
	    				if(data.data.codigo == RESPONSE_CODIGO_EXITO){	    						    						
	    						$scope.responseCartografia = JSON.parse(data.data.respuesta);
	    							if($scope.responseCartografia.xpIdCartografia == 0){	    								
	    								$rootScope.waitLoaderStatus = LOADER_HIDE;
	    								console.log("Se muestra mapa de google por default: "+$scope.responseCartografia.xpIdCartografia +"  ");	    							    								
	    							}else{
	    								$scope.objLatLong = {
	    										
	    										lat : $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud,
	    										lng : $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud
	    										
	    										}
	    								$scope.mapasGoogleShow = false;
	    								$scope.mapasBancoShow = true;
	    								$scope.crearMapa();
	    								$scope.actualizaPosicion($scope.objLatLong);
	    								$timeout(function(){$rootScope.waitLoaderStatus = LOADER_HIDE;}, TIME_OUT_5SEG);
	    								console.log("Se muestra mapa de banco por default: "+$scope.responseCartografia.xpIdCartografia +" CARTOGRAFIA GEOIT");	    								
	    							}
	    				}else{
	    					$rootScope.loggerIpad("Error en la respuesta del WS MAPS: "+data.data.descripcion);
							console.log("Error en la respuesta del WS MAPS: "+data.data.descripcion);
							$rootScope.waitLoaderStatus = LOADER_HIDE;
	    				}	    				
	    			}, function(e){
	    				$rootScope.loggerIpad("Error al consultar WS MAPS", e);
	    				console.error(e.message);
	    				$rootScope.waitLoaderStatus = LOADER_HIDE;
					}	    			
	    	);	    	
	    };	    
    	/*
    	 *FIN Ws Maps que consulta el id de cartografia para los mapas 
    	 */
	    
	    $scope.inicializarMapa = function(initialize, camaraAnglesJson){
		    MapService.createMap( 'map', 'streetView', initialize );
		    if (camaraAnglesJson)
		    	$timeout(function (){MapService.updateCameraSV(camaraAnglesJson);}, 100)
	    }
	    
	    $scope.crearMapa=function(initializeMap){
	    	var pais, canal, sucursal = 1;
	    	if ($rootScope.sucursalSession){
	    		if (!$rootScope.sucursalSession.idPais)
		    		pais = 1;
		    	else 
		    		pais = $rootScope.sucursalSession.idPais;
		    	if (!$rootScope.sucursalSession.idCanal)
		    		canal = 1;
		    	else 
		    		canal = $rootScope.sucursalSession.idCanal;
		    	if ($rootScope.sucursalSession){
		    		if (!$rootScope.sucursalInfo)
		    			sucursal = $rootScope.sucursalSession.idSucursal;
		    		else 
		    			sucursal = $rootScope.sucursalInfo.idSucursal;
		    	}
	    	}
	    		
			var initialize = {
					lat: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud,
					lng: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud,
					fnCallback:"callbackMap",
					direccion: {
						xDireccion : $scope.getCurrentAddress( true, true),
						idPais: pais,
						idEdo: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idEstado,
						idMun: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idDelegacion,
						cp: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp,
						idCol:$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.id,
						calle: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle
					},
					tienda: {
						xCveZon : "NOC",
						xPais:pais,
						xCanal:canal,
						xSucursal:sucursal,
					},	doOnFail: function(){
						alert("Error");
					},
					failOptions: {
						messageNoConnection: 'No hay mapas de banco', 
						timeout: 1 /* TIEMPO DE ESPERA EN SEGUNDOS, 5 SEGS POR DEFAULT */
					}
			};
			if ($scope.confTipoWindows || !$scope.esProduccion)
				MapBazService.createMap("mapasBanco", initialize)
		}
	    
	    $scope.actualizaPosicion=function(initializeMap){
			var latitud = initializeMap.lat;
			var longitud = initializeMap.lng;
			if ($scope.confTipoWindows || !$scope.esProduccion)
				MapBazService.updatePosition(longitud,latitud);
		}
	    
	    $scope.setContentPage = function()
	    {
	    	if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
			
	    	$scope.labelTiempo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO TIEMPO."+$scope.origen+".valor"];
			$scope.labelMin = " " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO MIN."+$scope.origen+".valor"];

	    	generalService.setMapping(  MODEL_VISTAS_JSON );
	    		    	
	    	$scope._titulo			= generalService.getDataInput("DATOS HOGAR","TITULO"				, $scope.origen	);
			$scope._edificio		= generalService.getDataInput("DATOS HOGAR","EDIFICIO"				, null         	);  
			$scope._andador	        = generalService.getDataInput("DATOS HOGAR","ANDADOR"				, null         	);
			$scope.antiguedad={
					"tipoElemento"  : "select",
					"campo"         : "antiguedad",
					"marcaAgua"     : "Seleccione una opción",
					"visible"       : true,
					"deshabilitado" : false,
					"obligatorio"   : false,
					"buro"          : false,
					"cincom"        : false,
					"opcional"      : false,
					"estilo"        : "inpuSelect active",
					"imagen"        : "images/icon-form/calendario.png",
					"longMin"       : "",
					"longMax"       : "",
					"formato"       : "",
					"valor"         : "",
					"pattern"       : "",
					"texto"         : "",
					"colorModal"    : "",
					"colorSeccion"  : "",
					"CATALOGO"      : "catalogo"
				};
//	 		$scope._anio			= generalService.getDataInput("DATOS HOGAR","ANIO"					, null         	);
			$scope._calle           = generalService.getDataInput("DATOS HOGAR","CALLE"					, null         	);
			$scope._claseVivienda	= generalService.getDataInput("DATOS HOGAR","CLASE VIVIENDA"		, null         	);
			$scope._codigoPostal	= generalService.getDataInput("DATOS HOGAR","CODIGO POSTAL"			, null         	);
			$scope._colonia			= generalService.getDataInput("DATOS HOGAR","COLONIA"				, null         	);
			$scope._estado			= generalService.getDataInput("DATOS HOGAR","ESTADO"				, null         	);
			$scope._estado.deshabilitado=true;
			$scope._lote			= generalService.getDataInput("DATOS HOGAR","LOTE"					, null         	);
			$scope._manzana			= generalService.getDataInput("DATOS HOGAR","MANZANA"				, null			);
//			$scope._mes				= generalService.getDataInput("DATOS HOGAR","MES"					, null         	);
			$scope._delegacion		= generalService.getDataInput("DATOS HOGAR","MUNICIPIO"				, null         	);
			$scope._numeroExterior	= generalService.getDataInput("DATOS HOGAR","NUMERO EXTERIOR"		, null      	);
			$scope._numeroInterior	= generalService.getDataInput("DATOS HOGAR","NUMERO INTERIOR"		, null			);
			$scope._referencia		= generalService.getDataInput("DATOS HOGAR","REFERENCIA"			, null			);
			$scope._superManzana	= generalService.getDataInput("DATOS HOGAR","SUPERMANZANA"			, null			);
			$scope._telefonoCasa	= generalService.getDataInput("DATOS HOGAR","TELEFONO CASA"			, null			);
//			$scope._telefonoCasa.opcional=false;
			$scope._tipoVivienda	= generalService.getDataInput("DATOS HOGAR","TIPO VIVIENDA"			, null			);
			$scope._etqDireccion	= generalService.getDataInput("DATOS HOGAR","ETIQUETA DIRECCION"	, $scope.origen	);
			$scope._etqHogar		= generalService.getDataInput("DATOS HOGAR","ETIQUETA HOGAR"		, $scope.origen	);
			$scope._etqMapa			= generalService.getDataInput("DATOS HOGAR","ETIQUETA MAPA"			, $scope.origen	);
			$scope._etqReferencia	= generalService.getDataInput("DATOS HOGAR","ETIQUETA REFERENCIA"	, $scope.origen	);
			$scope._etqTelefono		= generalService.getDataInput("DATOS HOGAR","ETIQUETA TELEFONO"		, $scope.origen	);
			$scope._etqTiempo		= generalService.getDataInput("DATOS HOGAR","ETIQUETA TIEMPO"		, $scope.origen	);
			$scope._btnGuardar		= generalService.getDataInput("DATOS HOGAR","BOTON GUARDAR"			, $scope.origen	);
	    	
			/*
			 * Para el flujo de zonificación posterior a la evaluación se considerará opcional el campo 
			 * referencia antes de realizar la primera evaluación.
			 */
			if($scope.showSeccionMapa){
				$scope._referencia.opcional = true;
			}
			if($scope.muestraColoniaOpc){
				$scope._colonia.obligatorio = true;
			}
	    	$scope.datosHogar = {
	    		telefono: ""
	    	};
	    	
	    		    	
	    };/* END SET_CONTENT_PAGE FUNCTION */	    

	    /**
	     **/
		var solicitudResp = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0];
	    $scope.getCurrentAddress = function( propagate, baz, resetUbicacion){
	    		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0] = (resetUbicacion)? solicitudResp : $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0];
    	
	        var addressObject = $scope.gralAddress;
	        var address = $scope.completeAddress;

	        
	        var street = validaCaracteres($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle); //addressObject.street;
	        var extnum = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroExterior; //addressObject.extnum;
	        var intnum = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].numeroInterior; //addressObject.intnum;
	        var zipcode = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp; //;
	        
	        var suburb = null;
	        
	        if( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc )
	        	suburb = validaCaracteres($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc); //addressObject.suburb;
	        else
	        	suburb = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia; //addressObject.suburb;
	       
	        var town = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].estado; //
	        var del = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].delegacion; //
	        
	        if ( street !== '' && street ) {
	            
	            upu_address[0] = street;
	            address += street;            
	    
	        }

	        if( extnum !== '' && extnum ){

	            upu_address[1] = extnum;
	            address += ' ' + extnum;

	        }

	        if( intnum !== '' && intnum){

	            upu_address[2] = intnum;
	            address += ', ' + intnum;

	        }

	        if( zipcode !== '' && zipcode ){

	            upu_address[3] = zipcode;
	            address += ', ' + zipcode;

	        }

	        if( suburb !== '' && suburb ){

	            upu_address[4] = suburb;
	            address += ', ' + suburb;

	        }
	        
	        if( del !== '' && del ){

	            upu_address[5] = del;
	            address += ', ' + del;

	        }
	        
	        if(baz)
	        		return address;

	        if( town !== '' && town ){

	            upu_address[6] = town;
	            address += ', ' + town;
	            refreshMap( address );
	            
	        }

	        $scope.gralAddress.completeAddress = address;

	    };/* END GET_CURRENT_ADDRESS FUNCTION */

	    $scope.suburbEvent = function( flag, coloniaOpcional ){
	    	if(coloniaOpcional == undefined)
	    		coloniaOpcional = "";
	    	var id=0;
	    	if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc == "NO SE ENCUENTRA COLONIA"){
	    		$rootScope.coloniaOpcional = coloniaOpcional;
	    		$scope.muestraColoniaOpc=true;
	    		id = 999;
	    	}else{
	    		$scope.muestraColoniaOpc=false;
	    		id = 0;
	    		$rootScope.coloniaOpcional=""
	    	}
		    $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].delegacion = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.delegacion; 
	        $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idEstado = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.idEstado);
	        $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].estado = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.descEstado;
	        $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idDelegacion = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.idDelegacion);
	        if(id == 999){
	        	var coloniaDesc = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc;
	        	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc = $rootScope.coloniaOpcional;
	        }
	        if( flag && $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc != "")
	           	$scope.getCurrentAddress( true );
	        if(id == 999)
	        	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc = coloniaDesc;
            
	    	
	    };/* END SUBURB_EVENT FUNCTION */
	    
	    $scope.getStreetViewURL = function()
	    {
	        console.log( url );

	        convertImgToBase64( url, function( base64Img ){

	        });

	        
	        setTimeout( function(){

	            
	        }, 10);
      

	    };/* END GET_STREET_VIEW_URL FUNCTION */

	    $scope.blockCP = false;
	    
	    $rootScope.serviceModuleLocation = function( zipcode, dataType)
	    {
	    	if ( $scope.formHogar.cp.$valid && zipcode != "" && zipcode != $scope.zipCodeAnterior){
	    		$rootScope.coloniaOpcional = "";
	    		$scope.muestraColoniaOpc=false;
	    		$scope.zipCodeAnterior = zipcode;
	    		
		    	if( zipcode != "" && zipcode != -1 && zipcode != 0 ){
		    		
		    		var len = 0;
		    		
		    		if( zipcode ){
		    			len = zipcode.length;
		    		}else{
		    			resetFields( false );
		    		}
		    		
		    		if( len == 5 && $scope.blockCP == false){
	   				    
		    			$scope.blockCP = true;
		    			$scope.zonification = true;
		    			//$scope.getCurrentAddress();

		    			solicitudService.consultaCP( zipcode ).then(
		    	    		
			    				function( data ){
															
			    					$rootScope.loggerIpad("Respuesta Servicio Código Postal", data);
			    					$scope.zonification = false;			    								    					
											
			    					
									if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
								
										try{
										
											var responseJson = JSON.parse(data.data.respuesta);	
												
											if(responseJson.codigo == 2){
												$scope.isInputDisabled = true;
												resetFields( false );
												$scope.blockCP = false;
												var resp = JSON.parse(generalService.getRespaldoDom());
												if(resp.cp == ""){
													generalService.setRespaldoDom($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0]);
												}
												dynamicSelectSuburb( responseJson.data.listaColonias.length, responseJson.data.listaColonias, dataType, zipcode );
											}else{
												
												//Error
												$scope.isInputDisabled = false;
												resetFields( true );
												
												var foo = function(){
													$scope.blockCP = false;
												};
												
												$rootScope.message("Datos del Hogar", [ "El código postal es inválido." ], "Aceptar", 
														null, $scope._titulo.colorModal , $scope._titulo.colorSeccion, foo,
														"GENERAL", "ERROR CP" );
												//$scope.focusInput = true;
											}
										
										}catch( e ){
											$rootScope.loggerIpad("Error Servicio Código Postal", e);
											console.error( e.message  );
											$scope.blockCP = false;
										}
									
									}else{
										$scope.blockCP = false;										
		
									}	
								
								}, function( error ){
									$rootScope.loggerIpad("Error Servicio Código Postal", error);
									$scope.blockCP = false;
	//			                	$rootScope.waitLoaderStatus = LOADER_HIDE;
									$scope.zonification = false;
									resetFields( true );
								}
					
			    		);
			    		
		    		}else{
		    			resetFields( false );
		    		}
		    		
		    	}else{
		    		resetFields( true );
		    	}
	    	}	    	
	    };/* END SERVICE_MODULE_LOCATION FUNCTION */
	    
	    function resetFields( flag )
	    {
	    	
            if( flag ){
	    		//Error
	    		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp = "";
		    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = "";
	    	}
            
            $scope.combos.colonias = [];
            
            if( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc )
        		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = "";
            
            $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].delegacion = ""; 
            $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idEstado = 0;
            $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].estado = "";
            $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idDelegacion = 0;
            	    	
	    };/* END RESET_FIELDS FUNCTION */
	    
	    function dynamicSelectSuburb( numRegistros, registros, dataType, zipcode ){
	    	$rootScope.loggerIpad("Detalle Parámetros a Zonificar", {num:numRegistros, registros:registros, tipoDato:dataType, cp:zipcode});
	    	
	    	try{
	    		var numColonias = 0;
	    		var colonias = [];
	    			    		
	    		if( parseInt(numRegistros) > 0 ){
	    			$scope.coloniaInfoEncontrada=false;
	    			var coincidencias=0;
	    			var objetoCoincidencia=null;
	    			var idColonia = 0;
	    			var descColonia = "";
	    			var idEstado = 0;
	    			var descEstado = "";
	    			var idDelegacion = 0;
	    			var delegacion = "";
	    			
	    			for( var i = 0; i < parseInt(numRegistros); i++ ){
	    				if( parseInt(registros[i].paisID) == 1 ){
    						numColonias++;
	    					var dataObj = {
	    						"id": i,
	    						"idEstado": registros[i].edoID,
	    						"desc": registros[i].descColonia,
	    						"descEstado": registros[i].descEdo,
	    						"delegacion": registros[i].descPoblacion,
	    						"idDelegacion": registros[i].poblacionID
	    					};
	    					
	    					for(var j=0;j<RANGOSCP.length;j++){
	    						if(parseInt(zipcode) >= RANGOSCP[j].rangoInicial && parseInt(zipcode) <= RANGOSCP[j].rangoFinal && RANGOSCP[j].id === dataObj.idEstado){
	    							colonias.push( dataObj );
	    							break;
	    						}
	    					}
	    				
	    					if( dataType != null && dataType != "" ){
	    						if( dataObj.desc === dataType ){
	    							$scope.coloniaInfoEncontrada=true;
	    							idColonia = dataObj.id;
	    							descColonia = dataObj.desc;
	    							idEstado = dataObj.idEstado;
	    							descEstado = dataObj.descEstado;
	    							idDelegacion = dataObj.idDelegacion;
	    							delegacion = dataObj.delegacion;
	    								
	    							$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = colonias[i];		    						
	    						}
	    					}
    					}
    				}
	    			
    				if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia == "" && coincidencias == 1){
    					$scope.coloniaInfoEncontrada=true;
    					$rootScope.ocrColonia=dataType=objetoCoincidencia.desc;
    					$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=objetoCoincidencia;
    				}

	    			var dataObj = {
						"id": 999,
						"idEstado": colonias[0].idEstado,
						"desc": "NO SE ENCUENTRA COLONIA",
						"descEstado": colonias[0].descEstado,
						"delegacion": colonias[0].delegacion,
						"idDelegacion": colonias[0].idDelegacion
	    			};
    				
    				colonias.push( dataObj );
	    		}
	    		
    			if(!$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia && $scope.coloniaInfoEncontrada){
    				var dataObj = {
    						"id": idColonia,
    						"idEstado": idEstado,
    						"desc": descColonia,
    						"descEstado": descEstado,
    						"delegacion": delegacion,
    						"idDelegacion": idDelegacion
    					};
    				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = dataObj;
    			}
	    			
	    		if ( numColonias > 0 ){
		    		
	    			$scope.combos['colonias'] =  colonias;
		    		
		    		if( dataType != null && dataType != ""){
		    			
		    			if(!$scope.coloniaInfoEncontrada){
		    				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=colonias[colonias.length - 1];
		    			}
		    			
		    			$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].delegacion = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.delegacion; 
		                $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idEstado = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.idEstado);
		                $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].estado = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.descEstado;
		                $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idDelegacion = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.idDelegacion);
		    			
		    			$timeout( function(){
		    				var latitud = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud;
		    				var longitud = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud;
		    				
		    				
		    				var fHeading=parseFloat( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.heading );
		    				var fPitch=parseFloat( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.pitch );
		    				var fZoom=parseFloat( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.zoom );
		    				var fov= parseFloat( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.fov)

		    	    		if (isNaN(longitud) || longitud == "" || longitud == null ){
		    	    			if($scope.muestraColoniaOpc){
		    	    				$scope.suburbEvent(true, $rootScope.coloniaOpcional);
		    	    			}else{
		    	    				$scope.getCurrentAddress()
		    	    			}
		    	    		}else{
			    			    var initialize = {
			    			    	country: 'MX',
		    						lat: parseFloat(latitud),
		    						lng: parseFloat(longitud),
		    						typeMoving: MapConstants.CENTER_MARKER,
		    						//clickableMoveMaker: false,
		    						enableFullScreen: true,
		    						sv: true,
		    						markerRadio: 6,
		    						svOptions: {
		    							messageNoneView: 'No hay vista de calle en este punto.',
		    							enableFullScreen: true,
		    							enableSatelliteView: true,
		    							satelitalZoom: 20
		    						},	doOnFail: function(){
		    							$scope.mapasGoogle(false);
		    							$scope.mapasGoogleShow = false;
		    							$scope.mapasBancoShow = true;
		    							$rootScope.message( "Datos del Hogar", ["No existe una conexión a Google."], "Aceptar", null, "bgRosa" , "rosa"  );		    									    							
		    						},
		    						 failOptions: {
		    							messageNoConnection: "No existe una conexión a Google.",
		    							timeout: 1
		    						}
		    					};
			    			    
			    				var camaraAnglesJson={
		    						fov: fov,
		    						heading: isNaN(fHeading)?0:fHeading,
		    						pitch: isNaN(fPitch)?0:fPitch,
		    			    		zoom: isNaN(fZoom)?1:fZoom
		    					};
			    				$scope.inicializarMapa(initialize, camaraAnglesJson);
			    				$scope.actualizaPosicion(initialize);
		    	    		}
		    			}, 100 );

			    		var objetoColonia=$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia;
			    		if(!$scope.coloniaInfoEncontrada){
		    				$scope.muestraColoniaOpc=true;
		    				$rootScope.coloniaOpcional=dataType;
			    		}
		    			$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=dataType;
		    			generalService.setRespaldo($rootScope.solicitudJson);
	    				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=objetoColonia;
		    		}
	    		}else{
					$scope.isInputDisabled = false;
					resetFields( true );
	    		}	    			    			    			
	    	}catch(e){
	    		$rootScope.loggerIpad("Detalle del Error al Zoonificar", e);
	    		$rootScope.message( "Datos del Hogar", ["Código postal inválido."], "Aceptar", null, "bgRosa" , "rosa"  );
	    	}
	    	
	    };	    

	    function convertImgToBase64( url, callback, outputFormat ){

	        var img = new Image();
	        img.crossOrigin = 'Anonymous';

	        img.onload = function(){
	            var canvas = document.createElement('CANVAS');
	            var ctx = canvas.getContext('2d');
	            canvas.height = img.height;
	            canvas.width = img.width;
	            ctx.drawImage(img,0,0);
	            var dataURL = canvas.toDataURL( outputFormat || 'image/png');
	            callback( dataURL );
	            canvas = null; 
	        };

	        img.src = url;

	    };/* END CONVERT_IMG_TO_BASE64 FUNCTION */
    

	    function refreshMap( stringAddress )
	    {
	    	
	    	var zipcode = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp;
	    	
	    	if($scope.mapasGoogleShow){
	    		console.log("Se consulta geocoding de google");
	    		MapService.geolocation( stringAddress);
	    	}else{
	    		$scope.actualizaDireccion(stringAddress)
	    	}
//	    	se comenta por actrualizacion
//	        MarkerCreatorService.createByAddress( stringAddress + ", MÉXICO", zipcode, function( marker ) {
//	            
//	            //$scope.map.markers.push( marker );
//	            $scope.map.markers[0] = marker ;
//	            refresh( marker );
//
//	        });

	    };/* END REFRESH_MAP FUNCTION */

	    function refresh( marker ) 
	    {
	    	
	        $scope.gralAddress.latitude = marker.latitude;
	        $scope.gralAddress.longitude = marker.longitude;  
	        $scope.autentiaMarker = marker;
	        
	        $scope.map.control.refresh( {
	            latitude: marker.latitude, 
	            longitude: marker.longitude
	        });
	    
	    };/* END REFRESH FUNCTTION */

	    var setMonths = function()
	    {

	        $scope.array_months = GlobalVariablesService.getArrayMonths();

	    };/* END SET_MONTHS FUNCTION */

	    var setYears = function()
	    {

	        $scope.array_years = GlobalVariablesService.getArrayYears( $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento, mm, dd );

	    };/* END SET_YEARS FUNCTION */
	    
	    $scope.validaAnno = function(){
	    	var fechaNac = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento;
	    	var fechaAnno = mm;
	    	var fechaValida = fechaNac.split('/')[1];
	        if (fechaAnno < fechaValida){
	        	var aaCompara = (parseInt(aa) - 1 );
	        }else
	        	var aaCompara = parseInt(aa);
	    	var anioNac = fechaNac.split('/')[2];
	    	var mesNac = fechaNac.split('/')[1];
	    	var numMes = ["0","01","02","03","04","05","06","07","08","09","10","11"];
	    	
	    	if ( (parseInt($scope.nAnio) + parseInt(anioNac)) == aaCompara ){
	    		
	    		var slice = 13 - (parseInt(mesNac) - mm);
	    		if (slice >= 13){
	    			slice = slice - 12 ;	    			
	    		}
	    		$scope.array_months = numMes.slice(0,slice);
	    	
	    		if(parseInt($scope.nMes) > parseInt($scope.array_months[slice - 1]))
	    			$scope.nMes = $scope.array_months[slice - 1];
	    	}else{
	    		$scope.array_months = numMes;
	    	}
	    	
	    };/* END VALIDA_ANNO FUNCTION */
	    
	    $scope.functionAntiguedad = function()
	    {
	    	
	    	
	    	var mes = $scope.nMes;
	    	var anio = $scope.nAnio;
	    	
	    	//$scope.muestraMeses( mes, anio );
	    	
	    	if( !anio ){
	    		
	    		anio = ( new Date().getFullYear() );
	    	
	    	}
	    	
	    	if( !mes ){
	    	
	    		mes = ( (new Date().getMonth() + 1) < 10 ? "0" + (new Date().getMonth() + 1)  : (new Date().getMonth() + 1) );
	    		
	    	}
	    	
	    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].antiguedad = "01/" + mes  + "/" + anio;
	    		
	    	
	    };/* END ANTIGUEDAD FUNCTION */
	    
	    $scope.muestraMeses = function()
	    {
	    	
	    	var anio = $scope.nAnio;
	    		    	
	    	var fechaNac = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento;
	    	var anioNac = fechaNac.split('/')[2];
	    	var mesNac = fechaNac.split('/')[1];
	    	
	    	var months = GlobalVariablesService.getArrayMonths();
	    	
	    	if( anio == anioNac ){
	    	
	    		$scope.array_months = months.slice( parseInt(mesNac) - 1 , months.length );
	    		
	    		$scope.nMes = "Mes";
	    		
	    	}else{
	    		$scope.array_months = GlobalVariablesService.getArrayMonths();
	    	}
	    			        	
	    };/* END MUESTRA_MESES FUNCTION */
	    
	    $scope.saveStreetView = function()
	    {
	    	var obj = MapService.getDataPosition();
	    	
	    	if(obj != null && !$scope.mapasBancoShow){
		    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud = "" + obj.latitude;
		    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud = "" + obj.longitude;

		    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.heading = "" + obj.heading;
		    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.pitch = "" + obj.pitch;
		    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.zoom = "" + obj.zoom;
		    
		    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.fov = "" + obj.fov;
	    	}else{
	    		if ($scope.mapasBancoShow && ($scope.confTipoWindows || !$scope.esProduccion) ){
		    		$scope.mapaPosition= JSON.parse(MapBazService.getDataPosition());
		    	
		    		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud = "" + $scope.mapaPosition.xpUbicacion.xpCoordY;
			    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud = "" + $scope.mapaPosition.xpUbicacion.xpCoordX;
			    	
			    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.heading = "" + 30;
			    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.pitch = "" + 0;
			    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.zoom = "" + 2;
			    
			    	$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.fov = "" + 45;
		    	}
	    	}
	    			    		
	    };/* END SAVE_STREET_VIEW FUNCTION */
	    
	    $scope.aniobisiesto = function( vAnno,vMes )
	    {
	    	
			  $scope.arrayDias=[];
			  
			  if ( (vAnno % 4 == 0) && ( (vAnno % 100 != 0) || (vAnno % 400 == 0) ) ) {
				  
				  if (vMes == "02"){
					  
					  $scope.arrayDias = GlobalVariablesService.getArrayDays().slice( 0, 29 );
					  
					  if( $scope.vDia ){
						  if ($scope.vDia>"29"){
							  $scope.vDia="29";
						  }
					  }
				  }
				  
			  }else {
				  if (vMes == "02"){
					  
					  $scope.arrayDias = GlobalVariablesService.getArrayDays().slice( 0, 28 );
					  
					  if( $scope.vDia ){
					  
					  	if ( $scope.vDia>"28"){
						
					  		$scope.vDia="28";
					  
					  	}
					  }
				  }
			  }
			  
			  if ( vMes=="04"||vMes=="06"||vMes=="09"||vMes=="11" ){
				  $scope.arrayDias = GlobalVariablesService.getArrayDays().slice( 0, 30 );
				  
				  if( $scope.vDia ){
					
					  if ($scope.vDia>"30"){
						  $scope.vDia="30";
					  }
					  
				  }
			  }
			  
			  if ( vMes=="01"||vMes=="03"||vMes=="05"||vMes=="07"||vMes=="08"||vMes=="10"||vMes=="12" ){			    		
				  $scope.arrayDias = GlobalVariablesService.getArrayDays();
			  }
		};

		
		var fechaDia = new Date();
    	var fechaPos = new Date();
    	fechaPos.setDate( fechaDia.getDate() + 1 );
    	var dd = ( fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
    	var mm = ( ( fechaDia.getMonth() + 1 ) < 10 ? '0' : '' ) + ( fechaDia.getMonth() + 1 ); 
    	var aa = fechaDia.getFullYear();	    	
    	var ddPos = ( fechaPos.getDate() < 10 ? '0' : '') + fechaPos.getDate();
    	var mmPos = ( ( fechaPos.getMonth() + 1 ) < 10 ? '0' : '') + ( fechaPos.getMonth() + 1 );
    	var aaPos = fechaPos.getFullYear();
    	
	    
	    
	    $scope.validadiasProxima = function()
	    {
	    	
	    	var vAnno="";
	    	var vMes="";
	    	    	
	    	if( angular.isNumber( $scope.nAnio ) ){
	    		   		
	    		if( $scope.nAnio == aaPos ){
	    			
	    			$scope.array_months = GlobalVariablesService.getArrayMonths().slice( 0, mm );
	  	    			
	    			if( parseInt( $scope.nMes ) > mm ){
	    				$scope.nMes = mm;
	    			}
	    			
	    		}else{
	    			
	    			$scope.array_months = GlobalVariablesService.getArrayMonths();
	    			
	    		}
	    		
	    	}
	    	
	 	};
	 	
	    
	    $scope.validar = function(form){
    		var flag=true;
				
    		try{						
	    		var obj = MapService.getDataPosition();
	    		if((obj != null || obj !=undefined) && !$scope.mapasBancoShow){
	    			if (isNaN(obj.latitude) || obj.latitude == "" || obj.latitude == null || obj.latitude == 0 || isNaN(obj.longitude) || obj.longitude == "" || obj.longitude == null || obj.longitude == 0)
	    				flag=false;
	    		}else{
	    			$scope.mapaPosition= JSON.parse(MapBazService.getDataPosition());
	    			var latBaz = $scope.mapaPosition.xpUbicacion.xpCoordY;
	    			var longBaz = $scope.mapaPosition.xpUbicacion.xpCoordX;
	    			if (isNaN(latBaz) || latBaz == "" || latBaz == null || latBaz == 0 || isNaN(longBaz) || longBaz == "" || longBaz == null || longBaz == 0)
	    				flag=false;
	    			else
	    				$scope.saveStreetView();
	    		}
    		}catch(e){
    			flag=false;
    		} 	
    	
    		return flag;
    	
    };
	    
	    
	    //funcion que reemplaza caracteres especiales 
	    
	    function validaCaracteres (str)
	    {
	            var from = ['Ñ'];
	            var to = ['N'];
	            //var str = st.toLowerCase();
	          
	            if(typeof str !== 'string'){
	            	console.log("solo letras")
	            } else {
	            for (var i = 0, c = from.length; i < c; i++)
	            {
	            	var rgx = new RegExp(from[i],'g');
	            	str = str.replace(rgx,to[i]);
	            };
	            }
	            
	            return str;
	    };
	    
	    
	    $scope.saveZone = function(){
	    
	    	var jsonTM = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia;
	    	
	    	console.log( jsonTM );
	    	
	    	if( jsonTM.hasOwnProperty( 'desc' ) ){
        		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].delegacion = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.delegacion; 
                $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idEstado = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.idEstado);
                $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].estado = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.descEstado;
                $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idDelegacion = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.idDelegacion);
                $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc;
	    	}else{
        		$rootScope.serviceModuleLocation( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp, $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia );
	    	}
	    
	    };
	    /**
		* Si la solicitud cuanta con un cambio de sucursal entonces mestrar el mensaje conrrespondiete e invocamos la funsión para el guardar la sección..
		**/
	    $scope.muestraMensaje=function(form){
	    	
	    	$scope.mensaje = ["Esta solicitud está siendo monitoreada centralmente,"," Hemos detectado que se ha realizado una edición de datos en el (los) campo (s): ",$scope.mostrar,"Por favor verifica que los datos sean correctos, ya que una vez guardada la información no podrás volver a editarla."];
	    	
	    	if($rootScope.solicitudJson.solicitudMigrada == SOLICITUD_MIGRADA && $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado == 0)
				$scope.mensaje = ["¿Estás seguro que deseas guardar la sección?","Una vez guardada no podrás volver a editar la información del cliente"];
	    	
	    	modalService.confirmModal("Advertencia",$scope.mensaje , "Revisar información",  "Guardar",$scope._titulo.colorModal,$scope._titulo.colorSeccion,$scope._titulo.colorSeccion,null,null)
			.then(
				  function(confirm){
					  $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado=1;
					  $scope.save(form);
				},function(cancel){
					console.log("Revisar");
				}
			);
	    }
	    
	    
	    var obtenerCamposValidados= function(){
	    	var validarDatosRespaldoTemp=$scope.datosRespaldo;
			var validaNuevosDatosTemp=$scope.actualizacionDatos;
			var camposEditados=[];
			var campos=[
						{nombreCampo: "calle",descripcion: "Calle"}, 
						{nombreCampo: "manzana",descripcion: "Manzana"}, 
						{nombreCampo: "supermanzana",descripcion: "Supermanzana"},
						{nombreCampo: "lote",descripcion: "Lote"}, 
						{nombreCampo: "andador",descripcion: "Andador"}, 
						{nombreCampo: "edificio",descripcion: "Edificio"}, 
						{nombreCampo: "numext",descripcion: "Número Exterior"}, 
						{nombreCampo: "numint",descripcion: "Número interior"}, 
						{nombreCampo: "cp",descripcion: "Código postal"}, 
						{nombreCampo: "colonia",descripcion: "Colonia"},
						{nombreCampo: "coloniaTexto",descripcion: "Colonia manual"},
						{nombreCampo: "del",descripcion: "Delegación"}, 
						{nombreCampo: "edo",descripcion: "Estado"},  
						{nombreCampo: "antiguedad",descripcion: "Antigüedad"}, 
						{nombreCampo: "vivienda",descripcion: "Tipo vivienda"}, 
						{nombreCampo: "tel",descripcion: "Teléfono"},
						{nombreCampo: "referencia",descripcion: "Referencia"}
						];
			
			//Valida todos los campos que hallan sido editados
			validaNuevosDatosTemp=validaCamposEditados(validaNuevosDatosTemp,validarDatosRespaldoTemp);
			
			//Genera json para mostrar el mensaje
			for(var x=0; x < validaNuevosDatosTemp.length; x++){
				for(var j=0; j<campos.length;j++){
					if(campos[j].nombreCampo==validaNuevosDatosTemp[x].nombreCampo){
						camposEditados.push(campos[j].descripcion);
					}
				}
			}
			
			if($scope.existeEdicionZonificacion==true)
				camposEditados.push("Zonificación actualizada");
			
			//Convertimos a String los campos obtenidos
			var cadena=JSON.stringify(camposEditados);
			$scope.mostrar=cadena.replace(/(\[)|(")|(\])/g,'');
			
		}
	    
	    
	    var existeEdicionDatos=function(){
	    	$scope.latitudRespaldo=parseFloat($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud);
			$scope.longitudRespaldo=parseFloat($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud);
			$scope.actualizacionLatitud=null;
			$scope.actualizacionLongitud=null;
			var validarDatosRespaldo=JSON.stringify($scope.datosRespaldo);
			var validaNuevosDatos=JSON.stringify($scope.actualizacionDatos);
			var seccionId=pathSeccion[  window.location.hash ];
			var existeEdicion=false;
			$scope.existeEdicionZonificacion=false;
			var obj = MapService.getDataPosition();
			
			
		//Valida todos los campos del formulario
			if(validarDatosRespaldo != validaNuevosDatos)
				existeEdicion=true;

		//Revisa si han realizado cambios en la zonificación
			try{
				if(obj != null || obj != undefined){
					$scope.actualizacionLatitud = obj.latitude;
					$scope.actualizacionLongitud = obj.longitude;
					var respuesta=obtenerDistanciaMetros($scope.actualizacionLatitud,$scope.actualizacionLongitud,$scope.latitudRespaldo,$scope.longitudRespaldo);
					
					if(respuesta!=0.000)
						$scope.existeEdicionZonificacion=true;		
		    	}else{
		    		$scope.mapaPosition= JSON.parse(MapBazService.getDataPosition());
		    		$scope.actualizacionLatitud = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud;
					$scope.actualizacionLongitud = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud;
		    		var respuesta=obtenerDistanciaMetros($scope.mapaPosition.xpUbicacion.xpCoordY,$scope.mapaPosition.xpUbicacion.xpCoordX,$scope.latitudRespaldo,$scope.longitudRespaldo);
					
					if(respuesta!=0.000)
						$scope.existeEdicionZonificacion=true;
		    	}
    		}catch(e){
    			$scope.existeEdicionZonificacion=false;
    		}
    		
    	//Valida la sección y los cambios realizados
    		if(seccionId == SECCION_HOGAR && (existeEdicion==true || $scope.existeEdicionZonificacion==true))
				$scope.existeEdicion=true;
			else
				$scope.existeEdicion=false;
    		
    		return $scope.existeEdicion;
		};
		
		$scope.verificaDireccion = function(form){
			var domResp = JSON.parse(generalService.getRespaldoDom());
			if(!$rootScope.isMexico && !$scope.showSeccionMapa){
					modalService.alertModal("Aviso",["Estás zonificando fuera de territorio Mexicano, favor de validar nuevamente"],"Aceptar",$scope.titulo.colorModal, $scope.titulo.colorSeccion).closePromise.then(
							function(exito){
								//Regresamos al punto anterior
								$scope.getCurrentAddress(null, null, 1);																										
							},function(error){
								//Actualizamos posicion
								$rootScope.serviceModuleLocation(domResp.cp, domResp.colonia);
							}
					 );
				
			}else if(($rootScope.cpActual != domResp.cp && !$rootScope.activaErrores) && !$scope.showSeccionMapa){
			
				modalService.modalAceptaZonificacion("Prueba Descripción", "bgRosa",  1, null, "Prueba").then( 
						function(estatus) {
							if(estatus == 1){
								$rootScope.activaErrores = true;
							}else{
								if(domResp.cp != $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp){
									$rootScope.cpActual = domResp.cp;
									$rootScope.solicitudJson.cotizacion.clientes[0].domicilios = [domResp];    			
									$rootScope.serviceModuleLocation(domResp.cp, domResp.colonia);
								}else{
									$scope.getCurrentAddress(null, null, 1);
								}
							}
						}, function(error) {
						}
					);
			}else{
				$scope.guardar(form);
			}
	};
		
		$scope.guardar=function(form){
			$scope.existeEdicion=false;
			//Obtener los datos actualizados
			$scope.actualizacionDatos=DatosAnterioresArreglo('datosHogar', 'edicion');
			
			if($rootScope.solicitudJson.solicitudMigrada == SOLICITUD_MIGRADA &&
			   $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado == 0){
				$scope.muestraMensaje(form);
			}else if($rootScope.solicitudJson.consultaBuro == 1 && existeEdicionDatos() == true && $rootScope.solicitudJson.consultasRealizadasEvaluacion != 1){
				obtenerCamposValidados();
				$scope.muestraMensaje(form);
			}
			else
				$scope.save(form);
			
		};
		
		function obtenerDistanciaMetros(lat1,lon1,lat2,lon2){
			var rad = function(x) {return x*Math.PI/180;}
			var 	R = 6378137; //Radio de la tierra en km
			var dLat = rad( lat2 - lat1 );
			var dLong = rad( lon2 - lon1 );
			
			var a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLong/2) * Math.sin(dLong/2);
			var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
			var d = R * c;
			
			return d.toFixed(3); //Retorna tres decimales
		 }
		
	    $scope.save = function(form)
	    {	  var objetoAntColonia = null;
	    	if(form.$valid){
	    		var validate = $scope.validar();
	    		
	    			if($rootScope.coloniaOpcional != ""){
	    				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc=$rootScope.coloniaOpcional;
	    			}else{
	    				if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc == "NO SE ENCUENTRA COLONIA")
	    					$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc = "";
	    			}
	    			objetoAntColonia=$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia;
	    			$scope.saveZone();		        	
		        	$scope.saveStreetView();
		        	
					if(!validate){
						$rootScope.message("Aviso", [ "No se pudo establecer una petición con Google, por favor revisa tu conexión a Internet." ], "Aceptar", null,  "bgRosa" , "rosa");
						return;
					}
		        	
		        	$rootScope.waitLoaderStatus = LOADER_SHOW;
		    		var porcentajeant = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje;
		    		
		    		$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje  = cuentatext('datosHogar');
		    		
		    	    $scope.datosActuales = JSON.stringify(DatosAnterioresArreglo('datosHogar','buro'));
					$scope.datosActualesM = JSON.stringify(DatosAnterioresArreglo('datosHogar','cincom'));
// I-MODIFICACION TDC (VALIDAR CAMBIO DE DOMICILIO PARA PREAPROBADOS EN TARJETAS)
					$scope.datosActualesTDC= JSON.stringify(DatosAnterioresArreglo('datosHogar','vCambio'));
						console.log($scope.datosActualesTDC);
					if($scope.datosActualesTDC != $scope.datosAnterioresTDC && $rootScope.productosTarjetas( $rootScope.solicitudJson.idProducto ) && $rootScope.promocionCampanas($rootScope.solicitudJson.tarjetasCredito.tarjetaOro.campana) ){
						 $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].edicionDatosHogar = $rootScope.solicitudJson.tarjetasCredito.tarjetaOro.campana;
					}
// F-MODIFICACION TDC (VALIDAR CAMBIO DE DOMICILIO PARA PREAPROBADOS EN TARJETAS)
					
		    	    validateService.limpiaMascaras();
	
		    	    
		    	    if (offLine){				
						$rootScope.cargaDocumentos();
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.porcentajes.secciones[1].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje;
						generalService.locationPath("/ochoPasos");
						}else{						
						var buroTmp = $rootScope.solicitudJson.consultaBuro;
						var matrizTmp = $rootScope.solicitudJson.consultaMatriz;
						var consultarBuro = -1;
						
						if (($scope.datosAnteriores != $scope.datosActuales) || $rootScope.solicitudJson.consultasRealizadasEvaluacion == 1){
							$rootScope.solicitudJson.consultaBuro = 0;
							$rootScope.solicitudJson.consultaMatriz = 0;
							consultarBuro = 1;
						}else if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idAntiguedad == 1 && $rootScope.consultaFuncionalidad.habilitarReglaAntiguedadDomicilio){
							$rootScope.solicitudJson.consultaBuro = 0;
							$rootScope.solicitudJson.consultaMatriz = 0;
							consultarBuro = 1;
						}else{
								
							if ( $rootScope.solicitudJson.consultaBuro == 1 ){
								if ( $scope.datosAnterioresM != $scope.datosActualesM ){
									$rootScope.solicitudJson.consultaMatriz = 0;
									consultarBuro = 0;
								}											
							}else{
								consultarBuro = 1;
							}
						}
												
						$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].domicilioActual=1;
						
						if(!$rootScope.ejecutarEncuentaPreaprobado){
							$rootScope.solicitudJson.banderaOfertaCP=1;
						}
						
						var solicitudJsonString = generalService.delete$$hashKey( $rootScope.solicitudJson );
		    	    
						solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: SECCION_HOGAR } ).then(
		    	    		
							function( data ){
								
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								
								if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
									$rootScope.ocrColonia=null;
									var responseJson = JSON.parse(data.data.respuesta);
									
									var fnStatusOK = function( esMalZonificada ){
										
										$rootScope.porcentajes.secciones[1].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje;
										$rootScope.solicitudJson = responseJson.data;
										
										/*\Se agrega un evento para la bitacora\*/
//										(Datos Hogar)
										$rootScope.addEvent( BITACORA.SECCION.datosHogar.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.guardar.id, $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje, BITACORA.SECCION.datosHogar.guardarEnBD );
										/*\Se agrega un evento para la bitacora\*/

										if( esMalZonificada && typeof esMalZonificada !== 'undefined' ){
											var excepciones = [ SECCION_HOGAR.toString() ];
											generalService.bloqueoSecciones( $rootScope.solicitudJson, excepciones );
										}
										
										$rootScope.calculaDocumentos();
										
										if (generalService.isBazDigital()){
											generalService.locationPath("/visitaAsesor");
										}else{
											if($scope.cCheckDatosHogar){
												actualizarSolicitud($rootScope.solicitudJson.idSeguimiento, MARCAS_SOLICITUD.requiereCambioDomiclioConvivencia, solicitudJsonString, consultarBuro);
											}else{
												solicitudService.validaFolioCallCenter(JSON.parse(solicitudJsonString), responseJson.data)
																.then(
																		function(data){
																			if(data == null){
																				buroService.consultaBuro( "bgNaranja", "btn gris","btn naranja", null, null, consultarBuro, null );
																			}else
																				generalService.locationPath(data);
																		},function(error){																	
																		}
																	);
											}
										}
										
									};
									
									if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
										fnStatusOK();							
									}else if( responseJson.codigo == STATUS_SOLICITUD.malZonificada.guardarSeccion ){
										generalService.setDataBridge( {esMalZonificada:true} );
										fnStatusOK( true );
									}else if(responseJson.codigo == BURO_OTRA_SUCURSAL_CERCANA){
										$rootScope.message(	"Aviso", [ responseJson.descripcion ],"Aceptar", null,  $scope._titulo.colorModal , $scope._titulo.colorSeccion,fnStatusOK);
									}else if(responseJson.codigo == BURO_NO_EXISTE_SUCURSAL_CERCANA){
										var fnCallBack = function( esMalZonificada ){
											generalService.cleanRootScope($rootScope);
											generalService.buildSolicitudJson($rootScope, null );
											generalService.locationPath("/simulador");	
										}
										$rootScope.message(	"Aviso", [ responseJson.descripcion ],"Aceptar", null,  $scope._titulo.colorModal , $scope._titulo.colorSeccion,fnCallBack);
									}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
										generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
										generalService.locationPath("/ficha");
									}else if(responseJson.codigo == ERROR_SOL_RECHAZADA){
											var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
											var marca = $rootScope.solicitudJson.marca;
											var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
											var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
											$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],
													"Aceptar", "/simulador",  $scope._titulo.colorModal ,  $scope._titulo.colorSeccion,buildJsonDefault);
									}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
										var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
										$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
									}else{
										$rootScope.serviceModuleLocation( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp, $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia );
										$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje = porcentajeant;
										$rootScope.message( "Datos del Hogar", ["Error al guardar la sección."], "Aceptar", null, "bgRosa" , "rosa"  );
										$rootScope.solicitudJson.consultaBuro = buroTmp;
										$rootScope.solicitudJson.consultaMatriz = matrizTmp;
										if($scope.muestraColoniaOpc)
											objetoAntColonia.desc="NO SE ENCUENTRA COLONIA";
										$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=objetoAntColonia;	
									}
									
								}else{
					    					
									$rootScope.serviceModuleLocation( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp, $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia );
									$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje = porcentajeant;
									$rootScope.message(	"Error en el servidor", ["Error en la respuesta del servicio para guardar los datos de la sección de Datos del Hogar. Por favor, reintente nuevamente."],"Aceptar", null,  $scope._titulo.colorModal , $scope._titulo.colorSeccion);
									$rootScope.solicitudJson.consultaBuro = buroTmp;
									$rootScope.solicitudJson.consultaMatriz = matrizTmp;
									if($scope.muestraColoniaOpc)
										objetoAntColonia.desc="NO SE ENCUENTRA COLONIA";
									$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=objetoAntColonia;
									
									//Regresamos la bandera a 0 cuando el servicio no responda siempre y cuando se cumplan las condiciones 
									if($rootScope.solicitudJson.consultaBuro == 1 && $scope.existeEdicion == true)
										$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado=0;
								}
								
							}, function(error){
								
								$rootScope.serviceModuleLocation( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp, $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia );
								$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje = porcentajeant;
				                $rootScope.waitLoaderStatus = LOADER_HIDE;
				                $rootScope.solicitudJson.consultaBuro = buroTmp;
								$rootScope.solicitudJson.consultaMatriz = matrizTmp;
								if($scope.muestraColoniaOpc)
									objetoAntColonia.desc="NO SE ENCUENTRA COLONIA";
								$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia=objetoAntColonia;
//				                var msgerror = generalService.isEmpty( error.statusText ) ? ERROR_SERVICE : error.statusText; 		                
								
								//Regresamos la bandera a 0 cuando el servicio no responda siempre y cuando se cumplan las condiciones
								if($rootScope.solicitudJson.consultaBuro == 1 && $scope.existeEdicion == true)
									$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado=0;
							
							}
						);
					}					
	    	}    		
	    	    
	    }
	    
	    var actualizarSolicitud = function (seguimiento, marca, solicitudJsonString, consultarBuro){
	    	var jsonSolicitud = {
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					idSeguimiento: seguimiento,
					marca: marca
				};
	    	solicitudService.actualizarSolicitud(jsonSolicitud).then(
					function(data) {
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);							
							if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								solicitudService.validaFolioCallCenter(JSON.parse(solicitudJsonString), $rootScope.solicitudJson)
								.then(
									function(data){
										$rootScope.requiereCambioDomiclioConvivencia=true;
										if(data == null){
											buroService.consultaBuro( "bgNaranja", "btn gris","btn naranja", null, null, consultarBuro, null );
										}else
											generalService.locationPath(data);
									},function(error){																	
									}
								);
							}
						}
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
					}
			);
	    }
	    
	    $scope.getDescripcionCatalogo = function(id, lista,fechaAnt){
	    	if(fechaAnt){
				var mmAnt=null;
				var aaAnt=null;
				var tiempo=null;
				var fechaInicial=new Date();
				switch(id){
					case 1:
						tiempo = 6;
						break;
					case 2:
						tiempo = 12;
						break;
					case 3:
						tiempo = 36;
						break;
					case 4:
						tiempo = 60
						break;
					case 5:
						tiempo = 61
						break;
					case 6:
				}
				fechaInicial.setMonth(fechaDia.getMonth() - tiempo);
				mmAnt = ((fechaInicial.getMonth() + 1) < 10 ? '0' : '') + (fechaInicial.getMonth() + 1); 
				aaAnt = fechaInicial.getFullYear();
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].antiguedad="01/"+mmAnt+"/"+aaAnt;
			}
			return generalService.descripcionCatalogo(id, lista);
		};
		
		
$scope.datosConexion = function(){
		var x = 0;
		var y = 0;
		
		if( zona_T.latitud == "" || isNaN(zona_T.latitud) ){
						
			console.log( 'Default location' );			
			
			if($rootScope.sucursalInfo.sucursal != null){
				if($rootScope.sucursalInfo.sucursal.xpUbicacion){
					if($rootScope.sucursalInfo.sucursal.xpUbicacion.xpCoordY)
						x = parseFloat($rootScope.sucursalInfo.sucursal.xpUbicacion.xpCoordY);
					if($rootScope.sucursalInfo.sucursal.xpUbicacion.xpCoordX)
						y = parseFloat($rootScope.sucursalInfo.sucursal.xpUbicacion.xpCoordX);
				}
			}else{
				x = 19.4284706;
				y = -99.1276627;
			}
			if(isNaN(x) || isNaN(y)){
				x = parseFloat( localStorage.getItem( 'latitude' ) );
				y = parseFloat( localStorage.getItem( 'longitude' ) );
			}			
		}else{
			x = parseFloat( zona_T.latitud );
			y = parseFloat( zona_T.longitud );			
			
		}
		 var initialize = {
					country: 'MX',
					lat: x,
					lng: y,
					typeMoving: MapConstants.CENTER_MARKER,
					//clickableMoveMaker: false,
					enableFullScreen: true,
					sv: true,
					markerRadio: 6,
					svOptions: {
						messageNoneView: 'No hay vista de calle en este punto.',
						enableFullScreen: true,
						enableSatelliteView: true,
						satelitalZoom: 20
					},	doOnFail: function(){
						$scope.mapasGoogle(false);
						$scope.mapasGoogleShow = false;
						$scope.mapasBancoShow = true;
						$rootScope.message( "Datos del Hogar", ["No existe una conexión a Google."], "Aceptar", null, "bgRosa" , "rosa"  );
					},
					 failOptions: {
						messageNoConnection: 'No hay google maps!!! :c', /* MSJ A MOSTRAR EN LOS DIVS EN CASO DE NO CONTAR CON CONEXIÓN, TIENE MENSAJE POR DEFAULT EN CASO DE NO IR ESTE TAG */
						timeout: 1 /* TIEMPO DE ESPERA EN SEGUNDOS, 5 SEGS POR DEFAULT */
					}
				};
		 
		 $scope.inicializarMapa(initialize);
		 $scope.crearMapa(initialize);
}
		$scope.configFullScreen = function(){
			
			 var foo = function(){
	    		  
				 var latitud = $scope.map.markers[0].latitude;
				 var longitud = $scope.map.markers[0].longitude;
	    		  
			 };		
			
		};
		
		
	    $scope.map = {
	        zoom: 18,
	        markers: [],
	        control: {},
	        options: {
	            scrollwheel: true, //false
	            streetViewControl: false,
	            panControl: false,
	            zoomControl: false,
//	            styles: styleArray
//	            styles: styles
	        },
	        panorama: null
	    };

	    $scope.map.markers[0] = $scope.autentiaMarker;

	    if( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc ){
			$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc;
		}
		
		$scope.cargaAntiguedad=function(){
			if ($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].antiguedad != ""){ 
				var cargadoMM = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].antiguedad.split('/')[1];
				var cargadoAA = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].antiguedad.split('/')[2];
				if (cargadoMM > mm){
					var mmAux = parseInt(mm) + 12;
					var aaAux = parseInt(aa) - 1;
					$scope.nMes = ((mmAux - cargadoMM) < 10 ? '0' : '') + (mmAux - cargadoMM);
					if($scope.nMes == "00")
						$scope.nMes="0";
					$scope.nAnio = ((aaAux - cargadoAA) < 10 ? '0' : '') + (aaAux - cargadoAA);
					if($scope.nAnio == "00")
						$scope.nAnio="0";
				}else{
					$scope.nMes = ((mm - cargadoMM) < 10 ? '0' : '') + (mm - cargadoMM);
					if($scope.nMes == "00")
						$scope.nMes="0";
					$scope.nAnio = ((aa - cargadoAA) < 10 ? '0' : '') + (aa - cargadoAA);
					if($scope.nAnio == "00")
						$scope.nAnio="0";
				}
				$scope.validaAnno();
				
				
				
				
			}
		};
				
		
		$scope.actualizaDireccion=function(stringAddress){
			var jsonAddress={
					xDireccion : stringAddress,
					idPais:1,
					idEdo:$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idEstado,
					idMun:$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idDelegacion,
					cp: parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp),
					idCol:$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.id,
					calle:validaCaracteres($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle)
			};
			if($scope.confTipoWindows || !$scope.esProduccion)
				MapBazService.geolocation(jsonAddress);
		}
		
		$scope.getDataPosition=function() {
			if ($scope.confTipoWindows || !$scope.esProduccion)
				$scope.mapaPosition=MapBazService.getDataPosition();
		};
		$scope.mapasGoogle = function(bandera){
			$scope.mapasGoogleShow = bandera;
			$scope.mapasBancoShow = !bandera;
			if ($scope.mapasBancoShow){
				$scope.crearMapa();
			}
		}
		
		$scope.callbackMap = function(){
			$scope.mapaPosition= JSON.parse(MapBazService.getDataPosition());
			if ($scope.mapasBancoShow)
				MapService.updatePosition($scope.mapaPosition.xpUbicacion.xpCoordY, $scope.mapaPosition.xpUbicacion.xpCoordX );
		}
		
		/**Nueva Funcionalidad**/
		$scope.cssPrincipalUno = "height:100%;width:80%;border: 1px solid #dfe0df;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: flex-start;";
		$scope.cssBorderUno = "height:100%;width:100%;";
		$scope.cssUno = "height: 2.5em;width: 20em;margin: 9em 0 0 -8.75em;z-index: 5;-webkit-transform: rotate(-90deg);text-align: center;border:0;";
		
		$scope.cssPrincipalDos = "height:100%;width:80%;border: 1px solid #dfe0df;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: flex-start;";
		$scope.cssBorderDos = "height:100%;width:100%;";
		$scope.cssDos = "height: 2.5em;width: 20em;margin: 9em 0 0 -8.7em;z-index: 5;-webkit-transform: rotate(90deg);text-align: center;border:0;";
		
		$scope.cambiaDatos = function(accion, variable){
			if(accion == 1){
				if(variable == 1){
					$scope.cssPrincipalUno = "height:100%;width:80%;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: flex-start;";
					$scope.cssBorderUno = "flex-direction: column;display: flex;align-items: flex-start;align-content: center;justify-content: center;height:auto;width:592%;border: 1px solid #dfe0df;margin: 0 0 0 -9.8em;";
					$scope.cssUno = "height: 2.5em;width: 15em;margin: 0 0 0 0;z-index: 5;-webkit-transform: rotate(0deg);position: relative;text-align: center;border:0;";
				}
				
				if(variable == 2){
					$scope.cssPrincipalDos = "height:100%;width:80%;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: flex-start;";
					$scope.cssBorderDos = "flex-direction: column;display: flex;align-items: flex-start;align-content: center;justify-content: center;height:auto;width:592%;border: 1px solid #dfe0df;";
					$scope.cssDos = "height: 2.5em;width: 15em;margin: 0 0 0 0;z-index: 5;-webkit-transform: rotate(0deg);position: relative;text-align: center;border:0;";
				}
			}
			
			if(accion == 2){
				if(variable == 1){
					$scope.cssPrincipalUno = "height:100%;width:80%;border: 1px solid #dfe0df;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: flex-start;";
					$scope.cssBorderUno = "height:100%;width:100%;";
					$scope.cssUno = "height: 2.5em;width: 20em;margin: 9em 0 0 -8.75em;z-index: 5;-webkit-transform: rotate(-90deg);text-align: center;border:0;";
				}
				
				if(variable == 2){
					$scope.cssPrincipalDos = "height:100%;width:80%;border: 1px solid #dfe0df;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: flex-start;";
					$scope.cssBorderDos = "height:100%;width:100%;";
					$scope.cssDos = "height: 2.5em;width: 20em;margin: 9em 0 0 -8.7em;z-index: 5;-webkit-transform: rotate(90deg);text-align: center;border:0;";
				}
			}
		}
		
		$scope.muestraAviso = function(){
			if($scope.cCheckDatosHogar)
				modalService.alertModal("Datos Hogar", ["Asesor Financiero, informa al cliente que el cambio de domicilio lo podrá realizar  posteriormente a la entrega de la tarjeta."], null, "bgRosa", "btn rosa");
		}
		
	});
	
});
