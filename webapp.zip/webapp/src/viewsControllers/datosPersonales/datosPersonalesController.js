'use strict';

define(["app"], function (app) {

		app.controller("datosPersonalesController", function ($timeout, $scope, $rootScope, generalService, solicitudService, modalService, buroService, 
															  securityService, clienteUnicoService, messageData, validateService) {
		    
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			$scope.pageClass = generalService.calculaVistas($rootScope.paginaActual,$rootScope.paginaAnterior,$rootScope.recuperaSolicitud);
			
			$scope.bloqueaSeccion = generalService.bloqueaDatosPersonales;
			$scope.vistaDatosUsuario=configuracion.datosUsuario.opcion=0;
			$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";
			var cont = 0;																					
			$scope.enviaOchoPasos = true;
			$scope.testShow = false;
			var servicioEnvioImgDocIpad = "clienteUnico";
			var functionCallbackEnvioImgIpad = "responseEnvioImgIpad";
			
			/* Date module conf*/
			var fechaDia = new Date();
			var yyyy = new Date().getFullYear()-18;
			var yy75 = new Date().getFullYear()-75;
			var dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
			var mm = ((fechaDia.getMonth() + 1) < 10 ? '0' : '') + (fechaDia.getMonth() + 1);
			var diafin = 31;	
						
			$scope.convertir = function(){
				$scope.datosAnteriores = JSON.stringify(DatosAnterioresArreglo('datosPersonalesDiv'));
			}
			
			$scope.cargadias = function(){
				$scope.days = [];
				for( var i = 1; i <= diafin; i++ ){
					if( i < 10 )
						$scope.days.push( "0" + i );
					else
						$scope.days.push( "" + i );	
				}
			}
			
			$scope.months = [	{id:"01", descripcion:'ENERO'},
				 				{id:"02", descripcion:'FEBRERO'},
				 				{id:"03", descripcion:'MARZO'},
				 				{id:"04", descripcion:'ABRIL'},
				 				{id:"05", descripcion:'MAYO'},
				 				{id:"06", descripcion:'JUNIO'},
				 				{id:"07", descripcion:'JULIO'},
				 				{id:"08", descripcion:'AGOSTO'},
				 				{id:"09", descripcion:'SEPTIEMBRE'},
				 				{id:"10", descripcion:'OCTUBRE'},
				 				{id:"11", descripcion:'NOVIEMBRE'},
				 				{id:"12", descripcion:'DICIEMBRE'}
				 			];			 				
			 
			$scope.years = [];
			 
			for( var i = (new Date().getFullYear() - 18); i > new Date().getFullYear() - 101; i-- ){
				$scope.years.push( "" + i );
			}
			
			//validacion de fecha
			$scope.aniobisiesto = function(){ 
				if ( ( $scope.nAnno % 4 == 0 ) && ( ( $scope.nAnno % 100 != 0 ) || ( $scope.nAnno % 400 == 0 ) ) ) {
					if ( $scope.nMes == "02"){
						diafin = "29";
						$scope.cargadias();
					}
				}else{
					if ( $scope.nMes == "02" ){
						diafin = "28";
						$scope.cargadias();
					}
				}
				if ( $scope.nMes == "01" || $scope.nMes == "03" || $scope.nMes == "05" || $scope.nMes == "07" || $scope.nMes == "08" || $scope.nMes == "10" || $scope.nMes == "12"){			    		
					diafin = "31";
					$scope.cargadias();
				}
				if ( $scope.nMes == "04" || $scope.nMes == "06" || $scope.nMes == "09" || $scope.nMes == "11" ){
					diafin = "30";
					$scope.cargadias();
				}
			}

			$scope.validadiasconmes = function(){
				if ( !( $scope.nMes == null || $scope.nMes == "" ) ){
					$scope.aniobisiesto();  
					if( $scope.nDia > diafin ){
						$scope.nDia = diafin;	
					}
				}
			}

			$scope.validadias = function(){
				$scope.aniobisiesto();
				if( $scope.nDia > diafin && $scope.nMes != 'Mes' ){
					$scope.nDia = diafin;				  
				}				 
			}

			$scope.validames = function(){
				$scope.aniobisiesto();
				if( $scope.nDia > diafin ){
					$scope.nDia = diafin;				  
				}
			}
			
			$scope.cargaVista=function(){
				if (configuracion.origen.tienda)
					$scope.origen="TIENDA";
				else
					$scope.origen="WEB";
				$scope.labelTiempo=MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO TIEMPO."+$scope.origen+".valor"];
				$scope.labelMin=" " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO MIN."+$scope.origen+".valor"];
				$scope.titulo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO TITULO."+$scope.origen+".valor"];
				$scope.showPregunta1 = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO PRIMERA PREGUNTA.VISIBLE.valor"];
				$scope.pregunta1 = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO PRIMERA PREGUNTA."+$scope.origen+".valor"];
				$scope.showPregunta2 = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO SEGUNDA PREGUNTA.VISIBLE.valor"];
				$scope.pregunta2 = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO SEGUNDA PREGUNTA."+$scope.origen+".valor"];
				$scope.showPregunta3 = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO TERCERA PREGUNTA.VISIBLE.valor"];
				$scope.pregunta3 = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO TERCERA PREGUNTA."+$scope.origen+".valor"];
				$scope.showPregunta4 = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO CUARTA PREGUNTA.VISIBLE.valor"];
				$scope.pregunta4 = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO CUARTA PREGUNTA."+$scope.origen+".valor"];		
				$scope.showNombre = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.NOMBRE CLIENTE.VISIBLE.valor"];
				$scope.labelNombre = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.NOMBRE CLIENTE.MARCA DE AGUA.valor"];
				$scope.disabledNombre = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.NOMBRE CLIENTE.DISABLED.valor"];
				$scope.obligatorioNombre = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.NOMBRE CLIENTE.OBLIGATORIO.valor"];
				$scope.opcionalNombre = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.NOMBRE CLIENTE.OPCIONAL.valor"];
				$scope.buroNombre = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.NOMBRE CLIENTE.BURO.valor"];
				$scope.longminNombre = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.NOMBRE CLIENTE.LONGMIN.valor"];
				$scope.longmaxNombre = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.NOMBRE CLIENTE.LONGMAX.valor"];
				
				$scope.showPaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.PATERNO CLIENTE.VISIBLE.valor"];
				$scope.labelPaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.PATERNO CLIENTE.MARCA DE AGUA.valor"];
				$scope.disabledPaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.PATERNO CLIENTE.DISABLED.valor"];
				$scope.obligatorioPaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.PATERNO CLIENTE.OBLIGATORIO.valor"];
				$scope.opcionalPaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.PATERNO CLIENTE.OPCIONAL.valor"];
				$scope.buroPaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.PATERNO CLIENTE.BURO.valor"];
				$scope.longminPaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.PATERNO CLIENTE.LONGMIN.valor"];
				$scope.longmaxPaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.PATERNO CLIENTE.LONGMAX.valor"];
				
				$scope.showMaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.MATERNO CLIENTE.VISIBLE.valor"];
				$scope.labelMaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.MATERNO CLIENTE.MARCA DE AGUA.valor"];
				$scope.disabledMaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.MATERNO CLIENTE.DISABLED.valor"];
				$scope.obligatorioMaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.MATERNO CLIENTE.OBLIGATORIO.valor"];
				$scope.opcionalMaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.MATERNO CLIENTE.OPCIONAL.valor"];
				$scope.buroMaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.MATERNO CLIENTE.BURO.valor"];
				$scope.longminMaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.MATERNO CLIENTE.LONGMIN.valor"];
				$scope.longmaxMaterno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.MATERNO CLIENTE.LONGMAX.valor"];
				
				$scope.showSexo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.RADIO SEXO.VISIBLE.valor"];
				$scope.disabledSexo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.RADIO SEXO.DISABLED.valor"];
				$scope.obligatorioSexo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.RADIO SEXO.OBLIGATORIO.valor"];
				$scope.opcionalSexo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.RADIO SEXO.OPCIONAL.valor"];
				$scope.buroSexo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.RADIO SEXO.BURO.valor"];
//				$scope.valorSexo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.RADIO SEXO.VALOR.valor"];
				
				$scope.showDia = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.DIA NACIMIENTO.VISIBLE.valor"];
				$scope.labelDia = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.DIA NACIMIENTO.MARCA DE AGUA.valor"];
				$scope.disabledDia = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.DIA NACIMIENTO.DISABLED.valor"];
				$scope.obligatorioDia = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.DIA NACIMIENTO.OBLIGATORIO.valor"];
				$scope.opcionalDia = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.DIA NACIMIENTO.OPCIONAL.valor"];
				$scope.buroDia = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.DIA NACIMIENTO.BURO.valor"];
				
				$scope.showMes = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.MES NACIMIENTO.VISIBLE.valor"];
				$scope.labelMes = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.MES NACIMIENTO.MARCA DE AGUA.valor"];
				$scope.disabledMes = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.MES NACIMIENTO.DISABLED.valor"];
				$scope.obligatorioMes = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.MES NACIMIENTO.OBLIGATORIO.valor"];
				$scope.opcionalMes = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.MES NACIMIENTO.OPCIONAL.valor"];
				$scope.buroMes = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.MES NACIMIENTO.BURO.valor"];
				
				$scope.showAnno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.AÑO NACIMIENTO.VISIBLE.valor"];
				$scope.labelAnno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.AÑO NACIMIENTO.MARCA DE AGUA.valor"];
				$scope.disabledAnno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.AÑO NACIMIENTO.DISABLED.valor"];
				$scope.obligatorioAnno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.AÑO NACIMIENTO.OBLIGATORIO.valor"];
				$scope.opcionalAnno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.AÑO NACIMIENTO.OPCIONAL.valor"];
				$scope.buroAnno = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.AÑO NACIMIENTO.BURO.valor"];
				
				$scope.showLugarNac = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.LUGAR NACIMIENTO CLIENTE.VISIBLE.valor"];
				$scope.labelLugarNac = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.LUGAR NACIMIENTO CLIENTE.MARCA DE AGUA.valor"];
				$scope.disabledLugarNac = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.LUGAR NACIMIENTO CLIENTE.DISABLED.valor"];
				$scope.obligatorioLugarNac = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.LUGAR NACIMIENTO CLIENTE.OBLIGATORIO.valor"];
				$scope.opcionalLugarNac = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.LUGAR NACIMIENTO CLIENTE.OPCIONAL.valor"];
				$scope.buroLugarNac = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.LUGAR NACIMIENTO CLIENTE.BURO.valor"];
				
				$scope.showEstadoCivil = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.ESTADO CIVIL CLIENTE.VISIBLE.valor"];
				$scope.labelEstadoCivil = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.ESTADO CIVIL CLIENTE.MARCA DE AGUA.valor"];
				$scope.disabledEstadoCivil = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.ESTADO CIVIL CLIENTE.DISABLED.valor"];
				$scope.obligatorioEstadoCivil = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.ESTADO CIVIL CLIENTE.OBLIGATORIO.valor"];
				$scope.opcionalEstadoCivil = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.ESTADO CIVIL CLIENTE.OPCIONAL.valor"];
				$scope.buroEstadoCivil = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.ESTADO CIVIL CLIENTE.BURO.valor"];
				
				$scope.showFoto = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO BOTON FOTO.VISIBLE.valor"];
				$scope.labelFoto = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO BOTON FOTO."+$scope.origen+".valor"];
				$scope.obligatorioFoto = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO BOTON FOTO.OBLIGATORIO.valor"];
				$scope.opcionalFoto = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO BOTON FOTO.OPCIONAL.valor"];
				$scope.buroFoto = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO BOTON FOTO.BURO.valor"];
				
				$scope.showHuella = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO BOTON HUELLA.VISIBLE.valor"];
				$scope.labelHuella = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO BOTON HUELLA."+$scope.origen+".valor"];
				$scope.obligatorioHuella = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO BOTON HUELLA.OBLIGATORIO.valor"];
				$scope.opcionalHuella = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO BOTON HUELLA.OPCIONAL.valor"];
				$scope.buroHuella = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO BOTON HUELLA.BURO.valor"];
				
				$scope.showAceptar = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO BOTON GUARDAR.VISIBLE.valor"];
				$scope.labelAceptar = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.DATOS PERSONALES.TEXTO BOTON GUARDAR."+$scope.origen+".valor"];
			}
			
			$scope.init = function(){
				if(messageData){
					$scope.cargaVista();
					generalService.setRespaldo($rootScope.solicitudJson);
					$scope.cargadias();
					var genero =  generalService.construirCatalogoIdString("CATALOGO GENERO");
					var estados = generalService.construirCatalogo("CATALOGO ESTADOS");
					var estadoCivil = generalService.construirCatalogo("CATALOGO ESTADO CIVIL");											
					
					$scope.combos = { "estados":estados, "genero":genero, "estadoCivil":estadoCivil};	
					
					$timeout(function(){
						$scope.convertir();
					}, 1);
		
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$scope.testShow = messageData;
					
					/*$rootScope.waitLoaderStatus = LOADER_SHOW;
					if( !generalService.existeSolicitud($rootScope.solicitudJson) ||  MODEL_CATALOGOS_JSON == null){
						
							console.log("Aun no responde ws, se retarsa la carga de la pag 3 segundos");
							cont += 1;	
							if(cont < 5)
								$timeout( function(){ $scope.init(); }, TIME_OUT_1SEG);	
							else{
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								if (configuracion.origen.tienda)
									$scope.origen="TIENDA";
								else
									$scope.origen="WEB";
								
								$scope.vistaJson = MODEL_VISTAS_JSON;
								
								$scope.labelTiempo=MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO TIEMPO."+$scope.origen+".valor"];
								$scope.labelMin=" " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO MIN."+$scope.origen+".valor"];
								console.log("ya respondio el ws, se  carga la pagina");		
													
								generalService.setRespaldo($rootScope.solicitudJson);				
								
								var genero = [ {id:1, descripcion:"Mujer"}, {id:2, descripcion:"Hombre"} ];
								var estados = generalService.construirCatalogo("CATALOGO ESTADOS");
								var estadoCivil = generalService.construirCatalogo("CATALOGO ESTADO CIVIL");											
								
								$scope.combos = { "estados":estados, "genero":genero, "estadoCivil":estadoCivil};	
								$rootScope.message("Error al cargar los datos Personales", [ERROR_SERVICE], "Aceptar", null);
							}
					}else{
					}
											*/	
				}
			};
			
			$scope.getDescripcionCatalogo = function(id, lista){				
				return generalService.descripcionCatalogo(id, lista);				
			};
			
			$scope.fotoCliente = function(){				
				if($scope.isTienda){
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					$rootScope.tomarRostro('fotoCteDiv','respuestaFotoIpad');
				}								
			};
			
			$scope.huellaCliente = function(){
				if($scope.isTienda){
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					$timeout(function(){ $rootScope.capturarHuella('huellaCteDiv','4,7', 'respuestaHuellaIpad'); }, TIME_OUT_1SEG);
				}
			};
			
			$scope.respuestaHuellaIpad = function(response){
				$rootScope.loggerIpad("respuestaHuellaIpad", null, response);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(response.codigo == RESPONSE_CODIGO_EXITO_IPAD){
					var porcentajeFoto = cuentatext('datosPersonalesDiv',1).toString();
					
					$rootScope.enviarImagen(
							$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
							response.nombreHuellas,
							servicioEnvioImgDocIpad,
							"Huellacliente",
							'huellaCteDiv',
							{	
								ruta: null,
								idSolicitud: $rootScope.solicitudJson.idSolicitud,
								cadena: response.nombreHuellas,
								tipoCadena: "huella",
								porcentaje: porcentajeFoto,
								nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
								foto: $rootScope.fotoCteOriginal
							},
							functionCallbackEnvioImgIpad
						);
					
//					$rootScope.obtenerHuellas('huellaCteDiv','4,7', 'respuestaHuellaIpad')
//					$rootScope.enviarHuellasIpad('huellaCteDiv', 1, 365, 1, response.nombreHuellas, 'respuestaEnvioHuellasIpad' );
					$scope.huellaAnterior = $rootScope.solicitudJson.cotizacion.clientes[0].huella;
					$rootScope.solicitudJson.cotizacion.clientes[0].huella = "1";
					$scope.objetoEnviar = "huella";
					$scope.manoEnviar = 1;
					$scope.dedoEnviar = 2;
					//$scope.cadenaEnviar = $scope.manoEnviar + "-" + $scope.dedoEnviar + "-" + response.nombreHuellas;
					$scope.cadenaEnviar = $scope.manoEnviar + "-" + $scope.dedoEnviar + "-XXXXXXXXXXXXXXXXXX,2-1-YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY";
//					$scope.enviaOchoPasos = false;	
					$scope.SetFOTO();
					//$rootScope.enviarHuellasIpad('huellaCteDiv', 1, 365, 1, response.nombreHuellas, 'respuestaEnvioHuellasIpad' );													
										
				}
//				else
//					$rootScope.message("Datos Personales",[response.mensaje], "Aceptar", null, "bgNaranja", "naranja");
			};
			
			$scope.respuestaEnvioHuellasIpad = function(response){
				$rootScope.waitLoaderStatus = LOADER_HIDE;				
				//$rootScope.message("Datos Personales",[response.mensaje], "Aceptar", null, "bgNaranja", "naranja");								
			};
			
			$scope.respuestaFotoIpad = function(response){
				$rootScope.loggerIpad("respuestaFotoIpad", null, response);
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				try{
					if(response.codigo == RESPONSE_CODIGO_EXITO_IPAD){
					var porcentajeFoto = cuentatext('datosPersonalesDiv',1).toString();
					$rootScope.enviarImagen(
							$rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
							response.archivo,
							servicioEnvioImgDocIpad,
							"Foto cliente",
							'fotoCteDiv',
							{	
									ruta: null,
									idSolicitud: $rootScope.solicitudJson.idSolicitud,
									cadena: response.archivo,
									tipoCadena: "foto",
									porcentaje: porcentajeFoto,
									nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
									foto: $rootScope.fotoCteOriginal
							},	
							functionCallbackEnvioImgIpad
						);
					}
					$scope.fotoanterior1 = $rootScope.fotoCte;
					$rootScope.fotoCte = 'data:image/png;base64,' + response.cadenaJPG;
					$scope.cadenaEnviar = response.cadenaJPG;
					$scope.objetoEnviar = "foto";
					$scope.manoEnviar = null;
					$scope.dedoEnviar = null;
					$scope.fotoAnterior = $rootScope.solicitudJson.cotizacion.clientes[0].foto;
					$rootScope.solicitudJson.cotizacion.clientes[0].foto = "1";
//					$scope.enviaOchoPasos = false;
					$scope.SetFOTO();	
				}catch(e){
					$rootScope.message("Datos Personales",[e], "Aceptar", null);
				}
			};
			
			
			$scope.responseEnvioImgIpad = function(responseIPAD){
				$rootScope.loggerIpad("responseEnvioImgIpad", null, responseIPAD);
				console.log("envio correcto");
			}
			
			$scope.SetFOTO = function(){
				$rootScope.waitLoaderStatus = LOADER_SHOW; 						
				var porcentajeFoto = cuentatext('datosPersonalesDiv',1).toString();
				var biometrico = {
						ruta: null,
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						cadena: $scope.cadenaEnviar,
						tipoCadena: $scope.objetoEnviar,
						porcentaje: porcentajeFoto
				};
				
				clienteUnicoService.setBiometrico( biometrico ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);							
							if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								$rootScope.waitLoaderStatus = LOADER_HIDE;
//								if( $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje == 100  && $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje == 100 && $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado == 0 &&
//									$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje == 100  && $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje == 100 ){
//									$rootScope.solicitudJson.consultaBuro = 0;
//								}
								$scope.huellaAnterior = $rootScope.solicitudJson.cotizacion.clientes[0].huella;
								$scope.fotoAnterior = $rootScope.solicitudJson.cotizacion.clientes[0].foto;
								$scope.fotoanterior1 = $rootScope.fotoCte;
								$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje + parseInt(porcentajeFoto);
								if ($rootScope.solicitudJson.cotizacion.clientes[0].porcentaje > 100)
									$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = 100;
								generalService.setRespaldo($rootScope.solicitudJson);
								
							}else if(j.codigo == RESPONSE_CODIGO_ERROR_ID){
								$rootScope.waitLoaderStatus = LOADER_HIDE; 
								$rootScope.solicitudJson.cotizacion.clientes[0].huella = $scope.huellaAnterior;
								$rootScope.solicitudJson.cotizacion.clientes[0].foto = $scope.fotoAnterior;
								$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = porcentajeant;
								$rootScope.fotoCte = $scope.fotoanterior1;
								$rootScope.message("Datos Personales",[$scope.mensajeError], "Aceptar", null, "bgNaranja", "naranja");
							}else{
								$rootScope.waitLoaderStatus = LOADER_HIDE; 
								$rootScope.solicitudJson.cotizacion.clientes[0].huella = $scope.huellaAnterior;
								$rootScope.solicitudJson.cotizacion.clientes[0].foto = $scope.fotoAnterior;
								$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = porcentajeant;
								$rootScope.fotoCte = $scope.fotoanterior1;
								$rootScope.message("Datos Personales",[$scope.mensajeError], "Aceptar", null, "bgNaranja", "naranja");
							}
						}else{
							$rootScope.waitLoaderStatus = LOADER_HIDE; 
							$rootScope.solicitudJson.cotizacion.clientes[0].huella = $scope.huellaAnterior;
							$rootScope.solicitudJson.cotizacion.clientes[0].foto = $scope.fotoAnterior;
							$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = porcentajeant;
							$rootScope.fotoCte = $scope.fotoanterior1;
							$rootScope.message("Datos Personales",[$scope.mensajeError], "Aceptar", null, "bgNaranja", "naranja");
						}
					}, function(error){
						$rootScope.solicitudJson.cotizacion.clientes[0].huella = $scope.huellaAnterior;
						$rootScope.solicitudJson.cotizacion.clientes[0].foto = $scope.fotoAnterior;
						$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = porcentajeant;
						$rootScope.fotoCte = $scope.fotoanterior1;
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
//		                $rootScope.message("Datos Personales",[$scope.mensajeError], "Aceptar", null, "bgNaranja", "naranja");
						
					}
				);
							
			};
			
			
			
			$scope.guardar=function(){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$timeout(function(){ save(); }, 1);
			};
			
			function save(){
				
				var fechaSel = $scope.nAnno + "/" + $scope.nMes + "/" + $scope.nDia
		    	var fechaMin = yy75 + "/" + mm + "/" + dd
		    	if (($scope.nAnno == yyyy && $scope.nMes > mm) || ($scope.nAnno == yyyy && $scope.nMes == mm && $scope.nDia > dd)){
					var mensaje = "Datos inválidos";
					$rootScope.waitLoaderStatus = LOADER_HIDE; 
					$rootScope.message( mensaje, ["El cliente no cumple con la edad mínima requerida por las políticas internas, por lo cual, no es posible continuar con el proceso."] , "Aceptar", null,  "bgAzul", "azul");	    		
		    	}else{
		    		
		    		if (fechaSel <= fechaMin){
		    			var mensaje = "Datos inválidos";
		    			$rootScope.waitLoaderStatus = LOADER_HIDE; 
						$rootScope.message( mensaje, ["El cliente supera la edad máxima definida en las políticas internas, por lo cual, no es posible continuar con el proceso."] , "Aceptar", null,  "bgAzul", "azul");	    		
		    		}else{
				
				
				var porcentajeant = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje;											
				$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = cuentatext('datosPersonalesDiv');	
				
				var solicitudJsonString = generalService.delete$$hashKey($rootScope.solicitudJson);
				$scope.datosActuales = JSON.stringify(DatosAnterioresArreglo('datosPersonalesDiv'));
								
								
				
				if (offLine){				
					$rootScope.cargaDocumentos();
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.porcentajes.secciones[0].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje; 
					generalService.locationPath("/ochoPasos");
				}else{
				
				solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: SECCION_PERSONALES } ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;

						if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
							var responseJson = JSON.parse(data.data.respuesta);							
							if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									$rootScope.solicitudJson = responseJson.data;	
									generalService.setRespaldo($rootScope.solicitudJson);
									$rootScope.porcentajes.secciones[0].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje; 
									$rootScope.calculaDocumentos();
									if ($scope.datosAnteriores != $scope.datosActuales){
//										if( $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje == 100  && $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje == 100 && $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado == 0 &&
//											$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje == 100  && $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje == 100 )
										$rootScope.solicitudJson.consultaBuro = 0;
									}
									if ($scope.enviaOchoPasos){																	
										buroService.consultaBuro( "bgNaranja", "btn gris","btn naranja" );
									}else{
										if( $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje == 100  && $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje == 100 && $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado == 0 &&
											$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje == 100  && $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje == 100 
											&& $rootScope.solicitudJson.consultaBuro == 0 ){	
											buroService.consultaBuro( "bgNaranja", "btn gris","btn naranja" );
										}
									}
							}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
								var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
								$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
							}else{
								if(responseJson.codigo == ERROR_SOL_RECHAZADA){
									var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
									var marca = $rootScope.solicitudJson.marca;
									var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],
											"Aceptar", "/simulador",  "bgNaranja", "naranja",buildJsonDefault);
								}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
									generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
									generalService.locationPath("/ficha");
								}else{
									$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = porcentajeant;
									$rootScope.message("Datos Personales",[$scope.mensajeError], "Aceptar", null, "bgNaranja", "naranja");
								}
							}
						}else{
							 $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = porcentajeant;
							$rootScope.message("Datos Personales",[$scope.mensajeError], "Aceptar", null, "bgNaranja", "naranja");
						}
						
					}, function(error){
						 $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = porcentajeant;
		                $rootScope.waitLoaderStatus = LOADER_HIDE;
		                
//		                var msgerror = generalService.isEmpty( error.statusText ) ? ERROR_SERVICE : error.statusText; 		                
//		                $rootScope.message("Datos Personales",[$scope.mensajeError], "Aceptar", null, "bgNaranja", "naranja");						
					}
				);	
				}
		    		}
		    	}
			};		
		});
});