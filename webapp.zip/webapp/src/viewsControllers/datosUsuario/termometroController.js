'use strict';

define( ["app"], function ( app ){


	app.factory( "TermometroController", function ( $timeout, $rootScope, $location, loginService, modalService, 
													ngDialog, generalService, authService, solicitudService, 
													clienteUnicoService, buroService ) {
		
		var controller = {};
		
		controller.inheritProperties = function( scopeDataOchoPasos )
		{
			
			console.log( $rootScope.solicitudJson );
			scopeDataOchoPasos.muestraTermometro = true;
			controller.showMessageBuro( scopeDataOchoPasos );
							
		};/* END INHERIT PROPERTIES FUNCTION*/
		
		controller.showMessageBuro = function( scopeDataOchoPasos, typeAuth )
		{
		
			var buroCn = ( typeAuth && typeAuth != null ) ? typeAuth : $rootScope.buroConditional;
			
			switch( buroCn ){
				case BURO_RECALCULAR_PLAZO:
						console.log( "RECALCULAR");
						scopeDataOchoPasos.muestraMensajeBuro = true;
						scopeDataOchoPasos.mensajeBuro = "Favor de recalcular el monto";
						scopeDataOchoPasos.muestraAlertaBuro = true;
						scopeDataOchoPasos.deshabilitarRecalcular = true;
					break;
				case BURO_AUTORIZADO_PORCOMPROBAR:
						console.log( "COMPROBAR");
						scopeDataOchoPasos.muestraMensajeBuro = true;
						scopeDataOchoPasos.mensajeBuro = "Selecciona un tipo de comprobante y recalcula";
						scopeDataOchoPasos.muestraAlertaBuro = true;
						scopeDataOchoPasos.muestraCondicion = true;
						scopeDataOchoPasos.deshabilitarRecalcular = true;
					break;
				case BURO_AUTORIZADO_SCORE:
				case RESPONSE_ORIGINACION_CODIGO_EXITO:
						console.log( "BURO OK");
						var plazo = $rootScope.solicitudJson.cotizacion.plazo;
						
						var fnCallBack = function(){
							var valorSlider = $( "#sliderVertical" ).slider( "value" );
							controller.muestraCondicion( plazo, valorSlider, scopeDataOchoPasos );
							controller.filtrosOferta( scopeDataOchoPasos );
						};
						
						scopeDataOchoPasos.threadSlider( 'sliderVertical', fnCallBack, false );
						scopeDataOchoPasos.muestraMensajeBuro = false;
						scopeDataOchoPasos.muestraAlertaBuro = false;
					break;
			}
			
		};
		
		controller.errorLoad = function( scopeDataOchoPasos )
		{
			
			scopeDataOchoPasos.muestraTermometro = true;
			scopeDataOchoPasos.muestraCondicion = false;
			scopeDataOchoPasos.muestraRefresh = true;
			scopeDataOchoPasos.mensajeRefresh = "No fue posible calcular una alternativa";
			scopeDataOchoPasos.labelBtn = "Reintentar";
			scopeDataOchoPasos.muestraMensajeBuro = false;
			scopeDataOchoPasos.muestraAlertaBuro = false;
			
		};/* END ERROR LOAD */
		
		
		controller.errorBuroGlobo = function( scopeDataOchoPasos ){
			
			if( $rootScope.termometroHandler == BURO_RESPUESTAWS_ERROR ){
				scopeDataOchoPasos.muestraAlertaBuro = true;
				scopeDataOchoPasos.muestraMensajeBuro = true;
				scopeDataOchoPasos.mensajeBuro = "Es necesario reintentar para poder continuar";
				scopeDataOchoPasos.llenaSeccion = false;
			}	
			
		};/* END BURO GLOBO */
		
		controller.intentarBuro = function( scopeDataOchoPasos, tercerosModatelasCita, tercerosModatelasLiberar )
		{
			
			var consultaBuro = 0;
			scopeDataOchoPasos.muestraMensajeBuro = false;
			scopeDataOchoPasos.muestraAlertaBuro = false;
			
			var foo =  function( typeAuth ){
				
				scopeDataOchoPasos.muestraTermometro = true;
//				scopeDataOchoPasos.muestraCondicion = true;
				scopeDataOchoPasos.muestraRefresh = false;
				
				scopeDataOchoPasos.termometroManager();
				
				var monto = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;
				scopeDataOchoPasos.uiSlider( monto );
				
				controller.showMessageBuro( scopeDataOchoPasos, typeAuth );
				
			};
			
			if( typeof tercerosModatelasCita !== "undefined" && tercerosModatelasCita ){
				foo = function(){
					scopeDataOchoPasos.enviaVisitaAsesor();
				};
			}
			
			if( typeof tercerosModatelasLiberar !== "undefined" && tercerosModatelasLiberar ){
				foo = function(){
					scopeDataOchoPasos.liberarGerencia();
				};
			}
			
			if( $rootScope.solicitudJson.consultaBuro == 0 ){
				consultaBuro = 1; // Consulta Buro
				buroService.consultaBuro( "bgVerde", "btn gris", "btn verde", null, null, consultaBuro, foo );
			}else{
				
				if( $rootScope.solicitudJson.consultaBuro == 1
					&& $rootScope.solicitudJson.consultaMatriz == 0 )
					consultaBuro = 0; //Consulta matriz
				if( $rootScope.solicitudJson.consultaBuro == 1
						&& $rootScope.solicitudJson.consultaMatriz == 1 ){
					buroService.getMontosPlazos( $rootScope.solicitudJson.idSolicitud, foo );
				}else{					
					if( generalService.validaConsultaBuro($rootScope.solicitudJson) )
						buroService.consultaBuro( "bgVerde", "btn gris", "btn verde", null, null, consultaBuro, foo );
					else
						scopeDataOchoPasos.validaInmediato();
				}
					
			}
			
		};
		
		controller.calculaPlazos = function( valor, scopeDataOchoPasos )
		{
			
			var arrayPlazos = generalService.getPlazos( $rootScope ); 
			
			var index = arrayPlazos.map( function(d){
				return d['monto'];
			}).indexOf( parseInt(valor) );
			
			if( arrayPlazos.length == 0 ){
				$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
				controller.errorLoad( scopeDataOchoPasos );
				return [];
			}			
			
			if( index != -1 ){
				
				var plazos = [];
				var _comprobables = arrayPlazos[index].cpComprobable;
				var _noComprobables = arrayPlazos[index].cpNoComprobable;
				
				_comprobables = _comprobables ? _comprobables : [];
				_noComprobables = _noComprobables ? _noComprobables : [];
				
				if( _comprobables.length > _noComprobables.length ){
					var comprobables = _comprobables;
					var noComprobables = _noComprobables;
				}else{
					var comprobables = _noComprobables;
					var noComprobables = _comprobables;
				}	
				
				for( var i = 0; i < comprobables.length; i++ ){
						
					if( noComprobables[i] ){
						
						if( plazos.indexOf( comprobables[i] ) == -1 ){
							plazos.push( comprobables[i] );
						}
						
						if( plazos.indexOf( noComprobables[i] ) == -1 ){
							plazos.push( noComprobables[i] );
						}
						
					}else{
						if( plazos.indexOf( comprobables[i] ) == -1 ){
							plazos.push( comprobables[i] );
						}
					}
						
				}/* END FOR */
				
				return plazos.sort( function( a, b ){
					return b-a;/* Invert to asc */
				});
				
			}/* END IF INDEX */
			
			return [];
			
		};
		
		controller.muestraCondicion = function( plazo, monto, scopeDataOchoPasos ){
			
			var arrayPlazos = generalService.getPlazos( $rootScope ); 
			
			var indexPlazo = arrayPlazos.map( function(d){
				return d[ 'monto' ];
			}).indexOf( parseInt(monto) );
			
			var index = -1;
			var comprobante = false;
			scopeDataOchoPasos.tiposComprobantes = null;
			
			if( indexPlazo != -1 ){
				
				var condicionRequeridaC = arrayPlazos[indexPlazo].requeridoComprobable;
				var condicionRequeridaNC = arrayPlazos[indexPlazo].requeridoNoComprobable;
				
				if( condicionRequeridaC != '' && condicionRequeridaC != null )
					condicionRequeridaC = condicionRequeridaC.split(",");
				if( condicionRequeridaNC != '' && condicionRequeridaNC != null )
					condicionRequeridaNC = condicionRequeridaNC.split(",");
				
				if( arrayPlazos[indexPlazo].cpNoComprobable ){
					
					index = arrayPlazos[indexPlazo].cpNoComprobable.indexOf( parseInt(plazo) );
					
					if( typeof condicionRequeridaNC == "object" && index != -1 && condicionRequeridaNC != null ){
						comprobante = true;
						scopeDataOchoPasos.tiposComprobantes = arrayPlazos[indexPlazo].requeridoNoComprobable;
					}
			
					if( index == -1 ){
						
						index = arrayPlazos[indexPlazo].cpComprobable.indexOf( parseInt(plazo) );
						
						if( typeof condicionRequeridaC == "object" && condicionRequeridaC != null){
							comprobante = true;
							scopeDataOchoPasos.tiposComprobantes = arrayPlazos[indexPlazo].requeridoComprobable;
						}
						
						if( index != -1 )
							comprobante = true;
												
					}
					
				}else{
					
					if( arrayPlazos[indexPlazo].cpComprobable ){
						
						index = arrayPlazos[indexPlazo].cpComprobable.indexOf( parseInt(plazo) );
						
						if( typeof condicionRequeridaC == "object" && condicionRequeridaC != null ){
							comprobante = true;
							scopeDataOchoPasos.tiposComprobantes = arrayPlazos[indexPlazo].requeridoComprobable; 
						}
						
						if( index != -1 )
							comprobante = true;
						
					}
					
				}
				
			}					

			if( comprobante ){				
				scopeDataOchoPasos.deshabilitarRecalcular = true;
				scopeDataOchoPasos.recordarRadio( plazo, monto );
			}else{
				
				if( $rootScope.solicitudJson.banderaOfertaCP == 0 ){
					$rootScope.solicitudJson.banderaIngresos = 0;  
					$rootScope.solicitudJson.banderaSolidario = 0;
				}else if($rootScope.solicitudJson.banderaOfertaCP == 1 && $rootScope.solicitudJson.banderaSolidario == 1){
					$rootScope.solicitudJson.banderaSolidario = 0;
				}
				
				scopeDataOchoPasos.deshabilitarRecalcular = false;
			}
			if(scopeDataOchoPasos.tiposComprobantes)
				scopeDataOchoPasos.muestraCondicion = true;
			
			return comprobante;
			
		};
						
		controller.filtrosOferta = function( scopeDataOchoPasos ){
//			
////			$rootScope.solicitudJson.capacidadPagoComprobable = 15000;
////			$rootScope.solicitudJson.capacidadPagoNoComprobable = 5000;
//			var capPagoComp = typeof $rootScope.solicitudJson.capacidadPagoComprobable != "undefined" ? 
//								$rootScope.solicitudJson.capacidadPagoComprobable : 0;
//			var capPagoNoComp = typeof $rootScope.solicitudJson.capacidadPagoNoComprobable != "undefined" ? 
//								$rootScope.solicitudJson.capacidadPagoNoComprobable : 0;
//			
//			var jsonOferta = {
//					"dias": 30,
//					"periodicidad": "semanal",
//					"capPagoComp": capPagoComp,
//					"capPagoNoComp": capPagoNoComp
//			};
//			
//			var estatusFiltro = false;
//			
//			var commonFn = function( doFunction ){
//				
//				if( $rootScope.solicitudJson.capacidadPagoComprobable > $rootScope.solicitudJson.capacidadPagoNoComprobable 
//						&& $rootScope.solicitudJson.capacidadPagoNoComprobable > 50 ){
//					estatusFiltro = true;
//					$rootScope.onceOfert = false;
//					modalService.ofertaModal( jsonOferta ).then( 
//						function( confirm ){
//							console.log( confirm );
////							scopeDataOchoPasos.test( confirm );
//							
//						
//							switch($rootScope.buroConditional){
//								case BURO_RECALCULAR_PLAZO:
//									scopeDataOchoPasos.muestraAlertaBuro = true;											
//								break;
//								case BURO_AUTORIZADO_SCORE:
//								case RESPONSE_ORIGINACION_CODIGO_EXITO:
//								case BURO_AUTORIZADO_PORCOMPROBAR:
//									scopeDataOchoPasos.muestraAlertaBuro = false;
//								break;
//								default:
//									console.warn("CACHE ESTE CODIGO: " + $rootScope.buroConditional + " EN TERMOMETRO CONTROLLER");
//							}
//						
//							if( ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id || $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id) 
//									&& $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinLiberar )
//								$rootScope.onceOfert = false;
//							
//							scopeDataOchoPasos.calculaMonto(true,true);
//							
//						},function( cancel ){
//							console.log( cancel );
//							
//							if( ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id || $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id) 
//									&& $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinLiberar )
//								$rootScope.onceOfert = false;
//					
////							scopeDataOchoPasos.test( cancel );
//							scopeDataOchoPasos.calculaMonto();
//						}
//					);
//				}
//				
//			};
//			
//			if( typeof $rootScope.solicitudJson.banderaOfertaCP != 'undefined' && $rootScope.solicitudJson.banderaOfertaCP != null
//					&& ($rootScope.solicitudJson.idCanal == 1 || ( EMPLEADOS_PRUEBA.indexOf($rootScope.userSession.noEmpleado.toString()) > -1)) ){
//				if( ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id || $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id) 
//						&& $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinLiberar ){
//					if( $rootScope.solicitudJson.banderaOfertaCP == 1 ){
//						var plazo = $rootScope.solicitudJson.cotizacion.plazo;
//						var monto = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;
//						var tieneComprobante = controller.muestraCondicion( plazo, monto, scopeDataOchoPasos );
//						if( !tieneComprobante && $rootScope.onceOfert )
//							commonFn();
//					}
//				}else{
//					if( $rootScope.solicitudJson.banderaOfertaCP == 0 ){
//						if( $rootScope.solicitudJson.banderaIngresos == 0 && $rootScope.onceOfert ){
//							commonFn();
//						}
//					}
//				}
//			}
//			
//			return estatusFiltro;
			
		}/* END FILTROS OFERTA FUNCTION */
		
		return controller;
	    		
	});/*END APP FACTORY - TermometroController*/
	
});