'use strict';

define(["app"], function (app) {

	app.controller("ejemploServicioController",function($scope, $rootScope, ejemploService,convertidor) {
		
		var x2js = new X2JS();
	
		$scope.convertXml2JSon=function(){
			$scope.jsonArea=convertidor.convertXml2JSon($scope.xmlArea);
		}
		
		$scope.convertJSon2XML=function(){
			$scope.xmlArea=convertidor.convertJSon2XML($scope.jsonArea);
		}
		
		$scope.armarJSON=function(){
			$scope.jsonArea=JSON.stringify(
					{
					    "DatosAval": {
					        "Item_aval": {
					            "_nombre": $scope.nombre,
					            "_apellidoPaterno": $scope.apellido,
					            "_apellidoMaterno": "LOPEZ",
					            "_sexo": "M",
					            "_fechaNacimiento": "12/05/1979",
					            "_calle": "24 DE FEBRERO",
					            "_numeroExt": "180",
					            "_numeroInt": "12",
					            "_cp": "89604",
					            "_estado": "TAMAULIPAS",
					            "_delegacion": "ÁLVARO OBREGÓN",
					            "_colonia": "SERAPIO VENEGAS SECTOR 1",
					            "_celular": "2721268813",
					            "_telefonoCasa": "2721268813",
					            "_tipoAval": "Propiedad",
					            "_tipoPropiedad": "Casa"
					        },
					        "Item_datos_auditoria": {
					            "_empleadoID": "276186",
					            "_direccionIP": "",
					            "_ultimaModificacion": "",
					            "_usrUltimaModificacion": ""
					        }
					    }
					}
			);
		}
	
	    
		
	//	$scope.convertXml2JSon();
	//    $scope.convertJSon2XML();
		
		var params={USUARIO:'HORACIO',CONTRASENIA:'1234',IDCATEGORIA:5};
		
		$scope.ejemploObtenerCategoriaPorPost = function() {
			$rootScope.waitLoaderStatus = LOADER_SHOW;	
			console.log("obtenerCategoriaPorPost");		
			ejemploService.obtenerCategoriaPorPost(params).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						console.log("Exito");
						console.log(data);
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						console.log("Error");
					});
		};
	
		$scope.ejemploObtenerCategoriaPorGet = function() {
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			console.log("obtenerCategoriaPorGet");
			ejemploService.obtenerCategoriaPorGet(params).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						console.log("Exito");
						console.log(data);
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						console.log("Error");
					});
	
		};					
						
	});
	
});