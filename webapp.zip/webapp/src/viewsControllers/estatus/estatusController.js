'use strict';

define(["app"], function (app) {

	//Sirve para tener varios controladores en la pagina
	app.controller("statusController", function ( $timeout,$scope,$rootScope, modalService, messageData,generalService,callCenterService,solicitudService,tarjetaService,generalServiceOS, clienteUnicoService, surtimientoService ) {
		
		
		$scope.pageClass = generalService.calculaVistas($rootScope.paginaActual,$rootScope.paginaAnterior,$rootScope.recuperaSolicitud, generalService);		
		$scope.estatus = 2;
		$scope.reenviar=true;
		var cont=0;
		$scope.showCallCenter=false;
		$scope.huellaValida=false;
		$scope.esGanadorPromocion = false;
		$scope.esGanadorDiaMadres = false;
		$scope.esGanadorRegresoAclases = false;
		$scope.esSorteoNavidad = false;
		$scope.mostrarBeneficiosTaz=false;
		if(($rootScope.solicitudJson.idProducto == PRODUCTOS.consumo.ID.valor || $rootScope.solicitudJson.idProducto == PRODUCTOS.italika.ID.valor || $rootScope.solicitudJson.idProducto == PRODUCTOS.prestamoPersonal.ID.valor
				|| $rootScope.solicitudJson.idProducto == PRODUCTOS.tarjetaAzteca.ID.valor || $rootScope.solicitudJson.idProducto == PRODUCTOS.telefonia.ID.valor) && !$rootScope.esSolicitudRescate)
			$scope.mostrarBeneficiosTaz = true;
		
		var PROMOCION = {
			regresoAclases : {
				productoID : null,
				vigencia : "15/07/2019-25/08/2019",
				productos : [ PRODUCTOS.prestamoPersonal.ID.valor ],
				mensaje : "<div style='width:70%;margin: 0% 15%;text-align: left;'>" +
								"<br>Nombre: " + "<b>" + $rootScope.solicitudJson.cotizacion.clientes[0].nombre + " " + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno
								+ " " + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno + "</b>" +
								"<br>Cliente Único: " + "<b>" + $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico + "</b>" +
								"<br>Pedido: " + "<b>" + $rootScope.solicitudJson.pedido + "</b>" +
								"</div>" +
								"<div style='width:80%;margin: 0% 10%;text-align: center;color: #ed5d8b;font-size: 1.2em;'>" +
								"<br>" +
								" <b>Tu Crédito Personal</b> premia a tus clientes <b>con un regalo para este Regreso a Clases.</b>" +
								"<br><br>" +
								"</div>",
				pieMensaje: "<div style='font-size:2.5em'>" +
								"<br>" +
								"<b>Entrega a tu cliente un Regalo</b>" +
							"</div>",
				plazos: [52,65,80,100,128],
				periodicidad: [PERIODICIDAD.semanal]
			},
			billetazo : {
				productoID : 201507,
				vigencia : "13/08/2018-28/10/2018",
				productos : [ PRODUCTOS.prestamoPersonal.ID.valor ],
				mensaje : "<div ng-if='esGanadorPromocion'><b><br>¡Billetazo te regala $1,000 al instante!<br><br>Serán depositados en Guardadito.<br>Acércate con tu asesor para hacer valido tu regalo.<br><br><b>Permiso de SEGOB DGRTC/1311/18<br>Vigencia del 13 de agosto al 28 de octubre.</b></div>"
			},
			navidad : {
				productoID : 201507,
				vigencia : "03/12/2018-07/01/2019",
				productos : [ PRODUCTOS.prestamoPersonal.ID.valor ],
				mensaje : "<div ng-if='esGanadorPromocion'>" +
								"<b><br>¡Ganaste  $1,000 al instante!" +
								"<br><br>Serán depositados en tu cuenta Guardadito.<br>Acércate con tu asesor para hacerlo válido.<br>"+
								"</div>"
			},
			sorteo : {
				productoID : 201507,
				vigencia : "03/12/2018-07/01/2019",
				productos : [ PRODUCTOS.prestamoPersonal.ID.valor ],
				mensaje : "<br><div ng-if='esSorteoNavidad'><b>Ya eres parte del gran sorteo, puedes ganar una Italika o hasta una Camioneta." +
																												   "<br><br>Participas con el siguiente folio:  " +
																												   $rootScope.solicitudJson.idCanal + "-"+$rootScope.solicitudJson.idSucursal+ "-"+ $rootScope.solicitudJson.pedido+
																												   "</b>"+
																												   "<br><br><b><label style='font-size:15px'>www.bancoazteca.com.mx</label></b>" +
																												   "<br><br><label style='font-size:13px'>Vigencia del 3 de diciembre de 2018 al 7 de enero de 2019</label>"+
																												   "</div>"
			},
			diaMadres : {
				productoID : 201512,
				/** vigencia : "22/04/2019-12/05/2019", **/
				vigencia : "22/04/2019-12/05/2019",
				productos : [ PRODUCTOS.prestamoPersonal.ID.valor ],
				mensaje : "<div style='width:70%;margin: 0% 15%;text-align: left;'>" +
								"<br>Nombre: " + "<b>" + $rootScope.solicitudJson.cotizacion.clientes[0].nombre + " " + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno
								+ " " + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno + "</b>" +
								"<br>Cliente Único: " + "<b>" + $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico + "</b>" +
								"<br>Pedido: " + "<b>" + $rootScope.solicitudJson.pedido + "</b>" +
								"</div>" +
								"<div style='width:80%;margin: 0% 10%;text-align: center;color: #ed5d8b;font-size: 1.2em;'>" +
								"<br>" +
								" <b>Tu Crédito Personal</b> de Banco Azteca <b>te premia con una increíble bolsa para festejar a mamá.</b>" +
								"<br><br>" +
								"</div>",
				pieMensaje: "<div style='font-size:2.5em'>" +
								"<br>" +
								"<b>Recoge tu regalo con el asesor</b>" +
							"</div>",
				montos: [7000,7500,8000,8500,9000,9500,10000,10500,11000,11500,12000,12500,13000,13500,14000,14500,15000,15500,16000,16500,17000,17500,18000,18500],
				plazos: [52,65,80,100,128],
				periodicidad: [PERIODICIDAD.semanal]
			}
		};
		
		$scope.mensajePromocionesNavidad = "<div ng-if='esSorteoNavidad'><img src='images/promociones/imgBAZMejorRegalador.png' class='png' style='height: 10%;''>"+"<div><b><label style='color: green;  font-size: 30px;' ng-if='esGanadorPromocion || esSorteoNavidad '>¡Felicidades!</label></b></div>"+"</div>"+"<div ng-if='esGanadorPromocion'>"+PROMOCION.navidad.mensaje+"</div>"+"<div ng-if='esSorteoNavidad'>"+PROMOCION.sorteo.mensaje+"</div>";

		$scope.cargaVista=function(){
			
			/*\Se agrega un evento para la bitacora\*/
//			(Estatus)
			//Este evento lo sugirio Urias pero no viene en el requerimiento.
			$rootScope.addEvent( BITACORA.SECCION.estatus.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, 0, BITACORA.SECCION.estatus.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
			
			if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
			$scope.titulo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ESTATUS.TITULO."+$scope.origen+".valor"];
			$scope.showPreAutorizada = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ESTATUS.TEXTO PRE AUTORIZADA.VISIBLE.valor"];
			$scope.preAutorizada = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ESTATUS.TEXTO PRE AUTORIZADA.VALOR.valor"];
			$scope.showVisita = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ESTATUS.TEXTO VISITA.VISIBLE.valor"];
			$scope.visita = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ESTATUS.TEXTO VISITA.VALOR.valor"];
			$scope.showLiberada = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ESTATUS.TEXTO LIBERADA.VISIBLE.valor"];
			$scope.liberada = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ESTATUS.TEXTO LIBERADA.VALOR.valor"];
			$scope.labelValidando = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ESTATUS.TEXTO DESC ESTATUS PRE AUTORIZADA.VALOR.valor"];
			$scope.labelVisita = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ESTATUS.TEXTO DESC ESTATUS VISITA.VALOR.valor"];
			$scope.labelLiberada = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ESTATUS.TEXTO DESC ESTATUS LIBERADA.VALOR.valor"];
			$scope.labelTiempo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ESTATUS.TEXTO TIEMPO APROXIMADO.VALOR.valor"];
			$scope.labelDocumentos = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ESTATUS.TEXTO ENVIAR DOCUMENTOS.VALOR.valor"];
			$scope.showAceptar = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ESTATUS.BOTON ACEPTAR.VISIBLE.valor"];
			$scope.aceptar = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ESTATUS.BOTON ACEPTAR.VALOR.valor"];
			$scope.showLiberar = false;
						
			$scope.MCO="En Mesa de crédito";
			$scope.statusMesa = ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.mesaControl.id && ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.mesaControl.marca.revisionMesa || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.mesaControl.marca.revisionMesaCDT)) ? true:false;
			
			if($rootScope.banderaFolio && $rootScope.solicitudJson.folioFlujoUnico != "" ){
				$rootScope.banderaFolio = false;
				
				var r = {
						 idSolicitud: $rootScope.solicitudJson.idSolicitud,
						 numCuenta: $rootScope.solicitudJson.cotizacion.clientes[0].numCuenta,
						 tipoCredito: DISPERSION_EFECTIVO   			
				 };
				
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				solicitudService.guardarDatosLiberacion(r).then(
						 function(data){
							 $rootScope.waitLoaderStatus = LOADER_HIDE;
							 if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								 var responseJson = JSON.parse(data.data.respuesta);
								 if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
									 $rootScope.message("SMS Folio Único",["Mensaje Enviado"],"Aceptar",null,"bgAzulD", "azulD");
								 }else{
									 $rootScope.message("SMS Folio Único",[$scope.mensajeError],"Aceptar",null,"bgAzulD", "azulD");
								 }
							 }else
								 $rootScope.message("SMS Folio Único", [generalService.displayMessage(data.data.descripcion)],"Aceptar",null,"bgAzulD", "azulD");
						 }, function(error){
							 $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
							
						 }
				 );
			}/**/
			
			var documentoEncolado = generalService.documentoEncolado($rootScope.solicitudJson);
			var contratoEncolado  = generalService.contratoEncolado($rootScope.solicitudJson);
			
			if( documentoEncolado )
				$scope.labelVisita = $scope.labelDocumentos;
			
			if ( contratoEncolado)
				$scope.labelVisita = "Falta enviar los contratos";
			
			if($rootScope.solicitudJson.creditoInmediato == 0)
				$scope.preAutorizada = "En proceso";

			if( ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id || $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id) && !$rootScope.solicitudJson.idSolicitudTienda){
				$scope.solGenerada=false;
				$scope.validaDocumentosFaltantes();
			}else if( $rootScope.solicitudJson.existeCita == 1 && 
					(
					  $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.generada.id
					)
				){
				$scope.estatus = 1;
				$scope.solGenerada=true;
				$scope.validaDocumentosFaltantes();
				
			}else if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.mesaControl.id && ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.mesaControl.marca.revisionMesa || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.mesaControl.marca.revisionMesaCDT)){
				$scope.estatus = 2;
				$scope.labelVisita = "Indícale a tu cliente que su trámite está siendo validado por el área de mesa de crédito, favor de esperar la actualización del estatus";
				$scope.showAceptar=true;
				
			}else if( $rootScope.solicitudJson.existeCita == 1 && $rootScope.solicitudJson.marca != STATUS_SOLICITUD.autorizada.marca.surtida && 
				(
				  $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id || /* <--CON EL TIEMPO QUITAR*/
				  $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id 
				) && $rootScope.solicitudJson.marca != STATUS_SOLICITUD.autorizada.marca.sinTaz
			){
					$scope.estatus = 1;
					$scope.labelVisita = "No se ha podido liberar la solicitud.";
			}else if( $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && $rootScope.solicitudJson.marca != STATUS_SOLICITUD.autorizada.marca.surtida 
					&& $rootScope.solicitudJson.idSolicitudTienda && $rootScope.solicitudJson.marca != STATUS_SOLICITUD.autorizada.marca.sinTaz){				
				$scope.estatus = 3;
				$scope.labelVisita = "Tu solicitud está autorizada.";
			}else if( $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id 
					&& $rootScope.solicitudJson.idSolicitudTienda && $rootScope.solicitudJson.marca != STATUS_SOLICITUD.autorizada.marca.sinTaz){				
				$scope.estatus = 1;
				$scope.labelVisita = "Tu solicitud está preautorizada.";
			}
			
			if( $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preRechazada.id||
				$rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.mas120mts.id||
				$rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.menos30min.id){
					$scope.labelVisita = "En autorización por GCC.";
			}
			
			if( $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.reprogramada.id){
						$scope.labelVisita = "Reprogramada.";
			}
			
			if( (( ($rootScope.solicitudJson.idSeguimiento == 6 || $rootScope.solicitudJson.idSeguimiento == 185) && $rootScope.solicitudJson.marca == 215 && $rootScope.solicitudJson.idSolicitudTienda > 0) || ($rootScope.solicitudJson.idSeguimiento == 185 && $rootScope.solicitudJson.marca == 205 && $rootScope.solicitudJson.idSolicitudTienda == 0))
					&& $rootScope.consultaFuncionalidad.habilitarEnvioCitaCredInmNoHit 
					&& !$rootScope.solicitudJson.hitBuro 
					&& $rootScope.solicitudJson.creditoInmediato 
					&& ($rootScope.solicitudJson.banderaIngresos && ($rootScope.solicitudJson.idColor == 1 || $rootScope.solicitudJson.idColor == 2 || $rootScope.solicitudJson.idColor == 3) ||
							!$rootScope.solicitudJson.banderaIngresos && ($rootScope.solicitudJson.idColorNC == 1 || $rootScope.solicitudJson.idColorNC == 2 || $rootScope.solicitudJson.idColorNC == 3))){
				$scope.labelVisita = "La solicitud de verificación ha sido agendada, por favor continue con el proceso.";
			}
			
			/**
			 * Condiciones para ejecutar en caso de que truene:
			 * Liberacion si es prestamo personal
			 * Liberacion si es consumo
			 **/			
			if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && !$rootScope.campanasConvivencia($rootScope.solicitudJson.campana)  && ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazEntregada || $rootScope.solicitudJson.marca == 253 || $rootScope.solicitudJson.marca == 254 || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente)){
				$scope.showAceptar=false;
				$scope.showLiberar=true;
				$scope.labelVisita = ""; 
			}else if(
					   ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && ($rootScope.solicitudJson.marca == 1016 || $rootScope.solicitudJson.marca == 253 || $rootScope.solicitudJson.marca == 254 || $rootScope.solicitudJson.marca == 5006 || $rootScope.solicitudJson.marca == 1007) && $rootScope.solicitudJson.pedido == 0 && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal) ||
					   ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && $rootScope.solicitudJson.marca == 5002 && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal)
					){
							$scope.showAceptar=false;
							$scope.showGenerarPedido=true;
							$scope.labelVisita = "";
							
			}else if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id){
				var ok=false;
				if( $rootScope.solicitudJson.idProducto == PRODUCTOS.consumo.ID.valor && $rootScope.solicitudOSJson && $rootScope.solicitudOSJson.idSolicitud != "" && ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinTaz || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.liberadaConTaz)){
					ok = true;
					$scope.labelVisita = " ¡Tu solicitud ha sido autorizada y liberada!";
				
					
				}else if($rootScope.solicitudJson.tipoSolicitud == SOLICITUD_REACTIVADO && !$rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
					if($rootScope.historicoMarcas.includes(150) || $rootScope.historicoMarcas.includes(151)){
						console.log("No muestra mensaje a rescate Prestamo");
					}else {
						if ($rootScope.solicitudJson.idProducto == PRODUCTOS.prestamoPersonal.ID.valor && $rootScope.solicitudJson.creditoInmediato != 1 ){
							
							var capacidadConsumo = obtenerCapacidadConsumoCliente($rootScope.capacidadesPagoProducto);
							
							if (capacidadConsumo>=50){
								$rootScope.message( "Incentivar consumo", ["Tu cliente cuenta con $"+ capacidadConsumo +" de capacidad de pago disponible, invítalo a utilizarla en la tienda para adquirir algún artículo."], "Aceptar", null);
							}
						}
					}
					
					ok=true;
					if($rootScope.solicitudJson.idProducto == PRODUCTOS.prestamoPersonal.ID.valor){
						if($rootScope.solicitudJson.tipoDispersion == DISPERSION_EFECTIVO){
							$scope.labelVisita =  $scope.mensajePromocionesNavidad +"<br><br><b>Tu préstamo con número de pedido: " + $rootScope.solicitudJson.pedido + " ha sido depositado en tu cuenta Guardadito.</div><br><br>Ya puedes disponer de tu préstamo, por favor pasa a caja a retirar tu efectivo con el siguiente número de folio: <b>"+$rootScope.solicitudJson.folioFlujoUnico+"</b> y número de pedido: <b>"+$rootScope.solicitudJson.pedido+"</b>, con este folio también podrás activar tu Tarjeta Azteca.";
							if($scope.esGanadorDiaMadres){
								modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.diaMadres.mensaje, PROMOCION.diaMadres.pieMensaje ).then(
										function(exito){
											console.log("Exito");
										}, function(error){
											console.log("Error : " + error);
								});
							}
							if($scope.esGanadorRegresoAclases){
								modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.regresoAclases.mensaje, PROMOCION.regresoAclases.pieMensaje ).then(
										function(exito){
											console.log("Exito");
										}, function(error){
											console.log("Error : " + error);
								});
							}
					}else{
							if($rootScope.parametroCaptacion || $rootScope.solicitudJson.tipoDispersion == DISPERSION_GUARDADITO){
									$scope.labelVisita = $scope.mensajePromocionesNavidad+
																    "<div><br><br><b>Indícale a tu cliente que su préstamo con número de pedido: " + $rootScope.solicitudJson.pedido + " ha sido depositado en su cuenta Guardadito." +
																    "<br><br>Para activar sus tarjetas, proporciónale el siguiente número de folio: <b>"+$rootScope.solicitudJson.folioFlujoUnico+"</b>.</div>"
								    if($scope.esGanadorDiaMadres){
										modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.diaMadres.mensaje, PROMOCION.diaMadres.pieMensaje ).then(
												function(exito){
													console.log("Exito");
												}, function(error){
													console.log("Error : " + error);
										});
									}
								    if($scope.esGanadorRegresoAclases){
										modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.regresoAclases.mensaje, PROMOCION.regresoAclases.pieMensaje ).then(
												function(exito){
													console.log("Exito");
												}, function(error){
													console.log("Error : " + error);
										});
									}
														
						}else{
								
								$scope.labelVisita = $scope.mensajePromocionesNavidad + "<br><br><b>Tu préstamo con número de pedido: " + $rootScope.solicitudJson.pedido + " ha sido depositado en tu cuenta Guardadito.</div><br><br>Indícale a tu cliente que pase con el Gerente, Sub Gerente o a caja con el siguiente número de folio " + $rootScope.solicitudJson.folioFlujoUnico + " y número de pedido "+$rootScope.solicitudJson.pedido+" con el cual podrá activar su TAZ, una vez activada, se realizará el depósito de su préstamo a su cuenta Guardadito.";
								if($scope.esGanadorDiaMadres){
									modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.diaMadres.mensaje, PROMOCION.diaMadres.pieMensaje ).then(
											function(exito){
												console.log("Exito");
											}, function(error){
												console.log("Error : " + error);
									});
								}
								if($scope.esGanadorRegresoAclases){
									modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.regresoAclases.mensaje, PROMOCION.regresoAclases.pieMensaje ).then(
											function(exito){
												console.log("Exito");
											}, function(error){
												console.log("Error : " + error);
									});
								}
							}								
						}
// I-MODIFICACION TDC (MENSAJE DE FOLIO UNICO PARA TDC)
					}else{
						if ( $rootScope.productosTarjetas($rootScope.solicitudJson.idProducto) )
							$scope.labelVisita = "Indícale a tu cliente que pase a caja con el siguiente folio "+ $rootScope.solicitudJson.folioFlujoUnico + " con el cual podrá activar su TDC "+ $rootScope.camelize($rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc)+".";
						else
							$scope.labelVisita = "<b>¡Felicidades!</b><br><br>Ya puedes hacer uso de tu línea de crédito para comprar en Elektra<br><br>Para hacer uso de tu tarjeta azteca no olvides activarla en caja, con el gerente o subgerente y proporciona el siguiente número de folio: <b>"+$rootScope.solicitudJson.folioFlujoUnico+".</b>";
					}
// F-MODIFICACION TDC (MENSAJE DE FOLIO UNICO PARA TDC)
				}else{
					if($rootScope.historicoMarcas.includes(150) || $rootScope.historicoMarcas.includes(151)){
						console.log("No muestra mensaje a rescate Prestamo");
					}else {
						if ($rootScope.solicitudJson.idProducto == PRODUCTOS.prestamoPersonal.ID.valor && $rootScope.solicitudJson.creditoInmediato != 1 ){
							
							var capacidadConsumo = obtenerCapacidadConsumoCliente($rootScope.capacidadesPagoProducto);
							
							if (capacidadConsumo>=50){
								$rootScope.message( "Incentivar consumo", ["Tu cliente cuenta con $"+ capacidadConsumo +" de capacidad de pago disponible, invítalo a utilizarla en la tienda para adquirir algún artículo."], "Aceptar", null);
							}
						}
					}
					
					if($rootScope.parametroCaptacion && !generalService.isEmpty($rootScope.parametroCaptacion.folioActivacionTaz) && generalService.isEmpty($rootScope.solicitudJson.folioFlujoUnico)){
						ok=true;

						if($rootScope.solicitudJson.idProducto == PRODUCTOS.prestamoPersonal.ID.valor){
							
							$scope.labelVisita = $scope.mensajePromocionesNavidad + "<br><br><b>Indícale a tu cliente que su préstamo con número de pedido: " + $rootScope.solicitudJson.pedido + " ha sido depositado en tu cuenta Guardadito.</div><br><br>Para activar su tarjeta Guardadito proporciónale el siguiente número de folio: " + $rootScope.parametroCaptacion.folioActivacionTaz + ".";
							if($scope.esGanadorDiaMadres){
								modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.diaMadres.mensaje, PROMOCION.diaMadres.pieMensaje ).then(
										function(exito){
											console.log("Exito");
										}, function(error){
											console.log("Error : " + error);
								});
							}

							if($scope.esGanadorRegresoAclases){
								modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.regresoAclases.mensaje, PROMOCION.regresoAclases.pieMensaje ).then(
										function(exito){
											console.log("Exito");
										}, function(error){
											console.log("Error : " + error);
								});
							}
						}else{
							$scope.labelVisita = "Infórmale a tu cliente que para concluir su proceso pase con el gerente,  subgerente o caja a realizar la activación de su Tarjeta Guardadito con el siguiente numero de folio: "+ $rootScope.parametroCaptacion.folioActivacionTaz + ".";
						}							
					}else{
						if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.pendienteDeSurtir && !generalService.isEmpty(""+$rootScope.solicitudJson.pedido+"")){
							ok=true;
// I-MODIFICACION TDC (MENSAJE DE FOLIO UNICO PARA TDC)												
							if($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto))
								$scope.labelVisita = "Indícale a tu cliente que pase a caja con el siguiente folio "+ $rootScope.solicitudJson.folioFlujoUnico + " con el cual podrá activar su TDC "+ $rootScope.camelize($rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc)+".";
							else
								/**
								 * Si es un canal soriana se muestra un mensaje parecido
								 */
								if($rootScope.sucursalSession.idCanal == CANALES.soriana && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal) {
									$scope.labelVisita = $scope.mensajePromocionesNavidad + "<br><br><b>Tu préstamo con número de pedido: " + $rootScope.solicitudJson.pedido + " ha sido depositado en tu cuenta Guardadito.</div><br><br>Ya puedes disponer de tu préstamo, por favor pasa a caja a retirar tu efectivo con el siguiente número de pedido "+ $rootScope.solicitudJson.pedido + ".";
									if($scope.esGanadorDiaMadres){
										modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.diaMadres.mensaje, PROMOCION.diaMadres.pieMensaje ).then(
												function(exito){
													console.log("Exito");
												}, function(error){
													console.log("Error : " + error);
										});
									}
									if($scope.esGanadorRegresoAclases){
										modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.regresoAclases.mensaje, PROMOCION.regresoAclases.pieMensaje ).then(
												function(exito){
													console.log("Exito");
												}, function(error){
													console.log("Error : " + error);
										});
									}
								}else{
									$scope.labelVisita = "Indícale a tu cliente que pase a caja a recoger su efectivo con el siguiente número de pedido: "+ $rootScope.solicitudJson.pedido + ".";
								}													
						} else if($rootScope.sucursalSession.idCanal == CANALES.soriana && ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinTaz || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.pendienteDigitalizar || $rootScope.solicitudJson.marca == 5006 || $rootScope.solicitudJson.marca == 1007) && ($rootScope.solicitudJson.idProducto == PRODUCTOS.consumo.ID.valor || $rootScope.solicitudJson.idProducto == PRODUCTOS.italika)) {
							$scope.estatus = 3;
							$scope.labelVisita = "<b>¡Felicidades!</b><br><br>Ya puedes hacer uso de tu línea de crédito para comprar.";
						}else if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinTaz && !generalService.isEmpty(""+$rootScope.solicitudJson.pedido+"") && $rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
							$scope.estatus = 3;
							$scope.labelVisita = "Indícale a tu cliente que pase a caja con el siguiente folio "+ $rootScope.solicitudJson.folioFlujoUnico + " con el cual podrá activar su TDC "+ $rootScope.camelize($rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc)+".";
						}
// F-MODIFICACION TDC (MENSAJE DE FOLIO UNICO PARA TDC)	
					}
				}
				if(ok){
					$scope.estatus=3;
					$scope.showAceptar=true;
				}
			}
			
			$scope.nuevasValidacion();
			
			if($rootScope.solicitudJson.existeCita == 1 && $rootScope.solicitudJson.idPlataforma == 6){
				$scope.showAceptar=false;
				$scope.showDispersion=false;
				$scope.showActivarTAZ=false;
				if( ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id || 
					 $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id) &&
					 $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazEntregada){
					$scope.estatus=1;
					$scope.labelVisita = "Es necesario activar la tarjeta";
					$scope.showActivarTAZ=true;
				}
				
				if( ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id || 
				     $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id) &&
					($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazActivada ||
					 $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.pendienteDeSurtir ||
					 $rootScope.solicitudJson.marca != STATUS_SOLICITUD.autorizada.marca.surtida)){
					$scope.estatus=3;
					$scope.labelVisita = "Es necesario realizar dispersión";
					$scope.showDispersion=true;
				}
				
				if(($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id || 
					$rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id) &&
				    $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.surtida){
					$scope.estatus=3;
					$scope.labelVisita = "Proceso completado";
					$scope.showAceptar=true;
				}
			}
			
			
			if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id &&
			   $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.surtida &&
			   $rootScope.solicitudJson.campana == CAMPANAS_REACTIVADOS.winback){
				$scope.estatus=3;
				$scope.showAceptar=true;
				$scope.showCallCenter=false;
				$scope.showActivarTAZ=false;
				$scope.showDispersion=false;
				$scope.showLiberar=false;
				$scope.showGenerarPedido=false;
				if($rootScope.parametroCaptacion && !generalService.isEmpty($rootScope.parametroCaptacion.folioActivacionTaz)){
					$scope.labelVisita = "<div ng-if='esSorteoNavidad'><img src='images/promociones/imgBAZMejorRegalador.png' class='png' style='height: 10%;''>" +
															"<div><b><label style='color: green;  font-size: 30px;' ng-if='esGanadorPromocion || esSorteoNavidad '>¡Felicidades!</label></b></div>" +
														"</div>" +
														"<div ng-if='esGanadorPromocion'>" +PROMOCION.navidad.mensaje +"</div>"+																
														"<div ng-if='esSorteoNavidad'>" +PROMOCION.sorteo.mensaje +"</div>"+
														"<br><br><b>Indícale a tu cliente que su préstamo con número de pedido: " + $rootScope.solicitudJson.pedido + " ha sido depositado en tu cuenta Guardadito.</div><br><br>Para activar su tarjeta Guardadito proporciónale el siguiente número de folio: " + $rootScope.parametroCaptacion.folioActivacionTaz + ".";
					if($scope.esGanadorDiaMadres){
						modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.diaMadres.mensaje, PROMOCION.diaMadres.pieMensaje ).then(
								function(exito){
									console.log("Exito");
								}, function(error){
									console.log("Error : " + error);
						});
					}
					if($scope.esGanadorRegresoAclases){
						modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.regresoAclases.mensaje, PROMOCION.regresoAclases.pieMensaje ).then(
								function(exito){
									console.log("Exito");
								}, function(error){
									console.log("Error : " + error);
						});
					}
				}else{
					$scope.labelVisita = "Proceso completado";
				}					
			}
			
			switch ($scope.estatus) {
			    case 1:
			    	$scope.horas = 24;
			        break;
			    case 2:
			    	$scope.horas = 12;
			        break;
			    case 3:
			    	$scope.horas = 0;
			        break;
			}
//			if($rootScope.solicitudJson.tipoSolicitud == SOLICITUD_REACTIVADO && $rootScope.solicitudJson.campana == CAMPANAS_REACTIVADOS.winback && $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id){
//				$rootScope.message( "Promoción WinBack", ["Cómo usted ha sido uno de nuestros mejores clientes, queremos reconocerle con un incentivo especial de crédito " +
//				"personal con 50% en tasa de interés, que seguramente le apoyará para este buen fin.", "Porfavor realiza tu presupuesto de préstamos personales en la opción de ADN: " +
//				"Menú principal > Colocación > Credimax personal > Presupuesto"], "Aceptar", null);
//			}
			
		};
		
		$scope.nuevasValidacion = function(){
			if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.investigacion.id){
				if($rootScope.parametroCaptacion){
					if($rootScope.parametroCaptacion.motivo == 0){
						if(!generalService.isEmpty($rootScope.parametroCaptacion.numTarjeta) && !generalService.isEmpty($rootScope.parametroCaptacion.folioActivacionTaz))
							$scope.labelVisita="Indícale a tu cliente que la apertura de su cuenta Guardadito con terminación "+ $rootScope.parametroCaptacion.cuenta.substring($rootScope.parametroCaptacion.cuenta.length-4) + " fue exitosa.</div><br><br>Para activar su tarjeta Guardadito proporciónale el siguiente número de folio: " + $rootScope.parametroCaptacion.folioActivacionTaz + ".<br><br>"+$scope.labelVisita;
						else
							$scope.labelVisita="Indícale a tu cliente que la apertura de su cuenta Guardadito con terminación "+ $rootScope.parametroCaptacion.cuenta.substring($rootScope.parametroCaptacion.cuenta.length-4) + " fue exitosa.</div><br><br>"+$scope.labelVisita;
					}else
						$scope.labelVisita="Indícale a tu cliente que por el momento no es posible aperturar su cuenta Guardadito. Invítalo a acudir con un Líder de captación.</div><br><br>"+$scope.labelVisita;
				}
			}
			if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id){
				if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.consumo || $rootScope.solicitudJson.idProducto == ID_PRODUCTO.italika || $rootScope.solicitudJson.idProducto == ID_PRODUCTO.telefonia){
					if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazEntregada || 
							$rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinTaz || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.liberadaConTaz){
						$scope.estatus = 3;
						$scope.showAceptar=false;
						$scope.showLiberar=true;
						$scope.labelVisita="";
					}else if(!generalService.isEmpty($rootScope.solicitudJson.folioFlujoUnico)){
						$scope.estatus = 3;
						$scope.showAceptar=true;
						$scope.showLiberar=false;
						$scope.labelVisita = "<b>¡Felicidades!</b><br><br>Ya puedes hacer uso de tu línea de crédito para comprar en Elektra<br><br>Para hacer uso de tu tarjeta azteca no olvides activarla en caja, con el gerente o subgerente y proporciona el siguiente número de folio: <b>"+$rootScope.solicitudJson.folioFlujoUnico+".</b>";
					}else{
						if($rootScope.campanaNvoPreaprob($rootScope.solicitudJson.campana)){
							if($rootScope.solicitudJson.marca == 215){
								$scope.estatus = 1;
								if(!$rootScope.solicitudJson.hitBuro ){
									$scope.labelVisita = "La solicitud de verificación ha sido agendada, por favor continue con el proceso.";
								}else{
									$scope.labelVisita = "Tu solicitud está preautorizada.";
								}
							}else{
								$scope.estatus = 3;
								$scope.labelVisita=" ¡Tu solicitud ha sido autorizada y liberada!";
							}
						}else{
							$scope.estatus = 3;
							$scope.labelVisita=" ¡Tu solicitud ha sido autorizada y liberada!";
						}
					}
				}

				if($rootScope.solicitudJson.idProducto == PRODUCTOS.prestamoPersonal.ID.valor ){
					if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazEntregada ||
					   $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinTaz ||
					   $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.liberadaConTaz){
						$scope.estatus = 3;
						$scope.showGenerarPedido=false;
						$scope.showAceptar=false;
						$scope.showLiberar=true;
						$scope.labelVisita="";
					}


					if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.surtida){
						$scope.estatus = 3;
						$scope.showAceptar=true;
						$scope.showLiberar=false;
						
						if(! generalService.isEmpty($rootScope.solicitudJson.folioFlujoUnico)){
							//Cuando se entrega TAZ y/o se apertura Guardadito
							$scope.labelVisita = $scope.mensajePromocionesNavidad+
						    									"<div><br><br><b>Indícale a tu cliente que su préstamo con número de pedido: " + $rootScope.solicitudJson.pedido + " ha sido depositado en su cuenta Guardadito." +
						    									"<br><br>Para activar sus tarjetas, proporciónale el siguiente número de folio: <b>"+$rootScope.solicitudJson.folioFlujoUnico+"</b>.</div>";
							if($scope.esGanadorDiaMadres){
								modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.diaMadres.mensaje, PROMOCION.diaMadres.pieMensaje ).then(
										function(exito){
											console.log("Exito");
										}, function(error){
											console.log("Error : " + error);
								});
							}
							if($scope.esGanadorRegresoAclases){
								modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.regresoAclases.mensaje, PROMOCION.regresoAclases.pieMensaje ).then(
										function(exito){
											console.log("Exito");
										}, function(error){
											console.log("Error : " + error);
								});
							}
						}else{
							if($rootScope.parametroCaptacion && !generalService.isEmpty($rootScope.parametroCaptacion.folioActivacionTaz)){
								////Cuando no hay TAZ y Se apertura Guardadito en NOC
								$scope.labelVisita = $scope.mensajePromocionesNavidad + 
																	"<br><br><b>Indícale a tu cliente que su préstamo con número de pedido: " + $rootScope.solicitudJson.pedido + 
																	" ha sido depositado en tu cuenta Guardadito.</div><br><br>Para activar su tarjeta Guardadito proporciónale el siguiente número de folio: " + $rootScope.parametroCaptacion.folioActivacionTaz + ".";
								if($scope.esGanadorDiaMadres){
									modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.diaMadres.mensaje, PROMOCION.diaMadres.pieMensaje ).then(
											function(exito){
												console.log("Exito");
											}, function(error){
												console.log("Error : " + error);
									});
								}
								if($scope.esGanadorRegresoAclases){
									modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.regresoAclases.mensaje, PROMOCION.regresoAclases.pieMensaje ).then(
											function(exito){
												console.log("Exito");
											}, function(error){
												console.log("Error : " + error);
									});
								}
							}else{
								//Cuando No hay TAZ y No se apertura Guardadito en NOC
								$scope.labelVisita = $scope.mensajePromocionesNavidad + "<br><br><b>Tu préstamo con número de pedido: " + $rootScope.solicitudJson.pedido + " ha sido depositado en tu cuenta Guardadito.</div>";
								if($scope.esGanadorDiaMadres){
									modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.diaMadres.mensaje, PROMOCION.diaMadres.pieMensaje ).then(
											function(exito){
												console.log("Exito");
											}, function(error){
												console.log("Error : " + error);
									});
								}
								if($scope.esGanadorRegresoAclases){
									modalService.diaMadresModal("¡FELICIDADES!", PROMOCION.regresoAclases.mensaje, PROMOCION.regresoAclases.pieMensaje ).then(
											function(exito){
												console.log("Exito");
											}, function(error){
												console.log("Error : " + error);
									});
								}
							}
						}
							
					}
					
				
				}
				if($rootScope.solicitudJson.tipoSolicitud == SOLICITUD_REACTIVADO && $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.liberacionAplicada){
					$scope.estatus = 3;
					$scope.showAceptar=true;
					$scope.showGenerarPedido=false;
					$scope.showLiberar=false;
					$scope.labelVisita=" ¡Tu solicitud ha sido autorizada y liberada!";
				}
				
				if( $rootScope.solicitudJson.idProducto == PRODUCTOS.tarjetaAzteca.ID.valor ){
					if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.liberacionAplicada){
						if($rootScope.solicitudJson.folioFlujoUnico != ""){
							$scope.estatus = 3;
							$scope.showAceptar=true;
							$scope.showGenerarPedido=false;
							$scope.showLiberar=false;
							$scope.labelVisita = "<b>¡Felicidades!</b><br><br>" +
							"<b>Tú TARJETA AZTECA ha sido autorizada.</b><br><br>" +
							"Pasa a caja, con el gerente o subgerente y proporciona el siguiente<br>" +
							"número de Folio: " + $rootScope.solicitudJson.folioFlujoUnico + " para realizar la activación de tu tarjeta.";
						
						}else{
							$scope.estatus = 3;
							$scope.showAceptar=true;
							$scope.showGenerarPedido=false;
							$scope.showLiberar=false;
							$scope.labelVisita = "<b>¡Felicidades!</b><br><br>" +
									"<b>Tú línea de crédito ha sido autorizada.</b>";
						}
					}
				}
				
				
				
			}
		}
		
		//valida si aplica la promocion de billetazo
		var aplicaPomocionBilletazo = function(){
			
			var aplicaPomocion = false;			
			// se validan reglas de la promocion
			var PromoBilletazo = ( PROMOCION.billetazo.productos.indexOf($rootScope.solicitudJson.idProducto) > -1  &&  $rootScope.solicitudJson.pedido != 0 &&  
					               $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto >= 7000 		&&  $rootScope.solicitudJson.cotizacion.plazo >= 52   &&
					               ($rootScope.parametroCaptacion || $rootScope.solicitudJson.tipoDispersion == DISPERSION_GUARDADITO)  );
			
			if( PromoBilletazo ){				
					//var vigenciaPromocion = PROMOCION.billetazo.vigencia.split("-");
					var vigenciaPromocion = PROMOCION.navidad.vigencia.split("-");
					var fechaIniPromoArray = vigenciaPromocion[0].split("/");
					var fechaFinPromoArray = vigenciaPromocion[1].split("/");
					var fechaActualEnMS = new Date().getTime();
					//new Date(año, mes, dia, horam min, seg, ms)
					var fechaInicioPromocioEnMS = new Date(fechaIniPromoArray[2], (fechaIniPromoArray[1]-1), fechaIniPromoArray[0]).getTime();		
					var fechaFinPromocioEnMS    = new Date(fechaFinPromoArray[2], (fechaFinPromoArray[1]-1), fechaFinPromoArray[0], 23, 59, 59, 0).getTime();	
					
					//se valida vigencia de la promocion
					if( fechaActualEnMS >= fechaInicioPromocioEnMS  &&  fechaActualEnMS <= fechaFinPromocioEnMS )							
						aplicaPomocion = true;									
			}
						
				
			return aplicaPomocion;
								
		};
		
		
		//valida si aplica la promocion de Dia de las Madres
		var aplicaPomocionDiaMadres = function(){
			
			var aplicaPomocion = false;			
			// se validan reglas de la promocion
			var PromoDiaMadres = ( PROMOCION.diaMadres.productos.indexOf($rootScope.solicitudJson.idProducto) > -1  &&  $rootScope.solicitudJson.pedido != 0 &&  
									PROMOCION.diaMadres.montos.indexOf($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto) > -1 &&  
									PROMOCION.diaMadres.plazos.indexOf($rootScope.solicitudJson.cotizacion.plazo) > -1   &&
									PROMOCION.diaMadres.periodicidad.indexOf($rootScope.solicitudJson.cotizacion.idPeriodicidad) > -1   &&
					               ($rootScope.parametroCaptacion || $rootScope.solicitudJson.tipoDispersion == DISPERSION_GUARDADITO || $rootScope.solicitudJson.tipoDispersion == DISPERSION_EFECTIVO) );
			
			if( PromoDiaMadres ){
					var vigenciaPromocion = PROMOCION.diaMadres.vigencia.split("-");
					var fechaIniPromoArray = vigenciaPromocion[0].split("/");
					var fechaFinPromoArray = vigenciaPromocion[1].split("/");
					var fechaActualEnMS = new Date().getTime();
					
					var fechaInicioPromocioEnMS = new Date(fechaIniPromoArray[2], (fechaIniPromoArray[1]-1), fechaIniPromoArray[0]).getTime();		
					var fechaFinPromocioEnMS    = new Date(fechaFinPromoArray[2], (fechaFinPromoArray[1]-1), fechaFinPromoArray[0], 23, 59, 59, 0).getTime();	
					
					//se valida vigencia de la promocion
					if( fechaActualEnMS >= fechaInicioPromocioEnMS  &&  fechaActualEnMS <= fechaFinPromocioEnMS )							
						aplicaPomocion = true;									
			}
						
				
			return aplicaPomocion;
								
		};
		
		//valida si aplica la promocion de Regreso a Clases
		var aplicaPomocionRegresoAclases = function(){
			var aplicaPomocion = false;			
			// se validan reglas de la promocion
			var PromoRegresoAClases = ( PROMOCION.regresoAclases.productos.indexOf($rootScope.solicitudJson.idProducto) > -1  &&  $rootScope.solicitudJson.pedido != 0 && 
									PROMOCION.regresoAclases.plazos.indexOf($rootScope.solicitudJson.cotizacion.plazo) > -1   &&
									PROMOCION.regresoAclases.periodicidad.indexOf($rootScope.solicitudJson.cotizacion.idPeriodicidad) > -1   &&
					               ($rootScope.parametroCaptacion || $rootScope.solicitudJson.tipoDispersion == DISPERSION_GUARDADITO || $rootScope.solicitudJson.tipoDispersion == DISPERSION_EFECTIVO) );
			
			if(($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto >= 7000) && ($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto < 8500)){
				PROMOCION.regresoAclases.productoID = 201517;
				PROMOCION.regresoAclases.pieMensaje = "<div style='font-size:2.5em'>" +
				"<br>" +
				"<b>Entrega a tu cliente una Lapicera</b>" +
				"</div>";
			}
			
			if(($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto >= 8600) && ($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto <= 10400)){
				PROMOCION.regresoAclases.productoID = 201518;
				PROMOCION.regresoAclases.pieMensaje = "<div style='font-size:2.5em'>" +
				"<br>" +
				"<b>Entrega a tu cliente una Lonchera</b>" +
				"</div>";
			}
			
			if($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto >= 10500){
				PROMOCION.regresoAclases.productoID = 201519;
				PROMOCION.regresoAclases.pieMensaje = "<div style='font-size:2.5em'>" +
				"<br>" +
				"<b>Entrega a tu cliente una Mochila</b>" +
				"</div>";
			}
			
			if($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto <= 6999){
				PromoRegresoAClases = false;
			}
			
			if( PromoRegresoAClases ){
					var vigenciaPromocion = PROMOCION.regresoAclases.vigencia.split("-");
					var fechaIniPromoArray = vigenciaPromocion[0].split("/");
					var fechaFinPromoArray = vigenciaPromocion[1].split("/");
					var fechaActualEnMS = new Date().getTime();
					
					var fechaInicioPromocioEnMS = new Date(fechaIniPromoArray[2], (fechaIniPromoArray[1]-1), fechaIniPromoArray[0]).getTime();		
					var fechaFinPromocioEnMS    = new Date(fechaFinPromoArray[2], (fechaFinPromoArray[1]-1), fechaFinPromoArray[0], 23, 59, 59, 0).getTime();	
					
					//se valida vigencia de la promocion
					if( fechaActualEnMS >= fechaInicioPromocioEnMS  &&  fechaActualEnMS <= fechaFinPromocioEnMS ){
						aplicaPomocion = true;
					}
					
															
			}
						
				
			return aplicaPomocion;
								
		};
		
		
		$scope.init = function(){
			
			try{
				if( $rootScope.consultaFuncionalidad.habilitarBilletazo ){
					if(aplicaPomocionBilletazo()){
						consultaPromocionClientePedido(PROMOCION.billetazo.productoID);
					}else if(aplicaPomocionDiaMadres()){
						consultaPromocionClientePedido(PROMOCION.diaMadres.productoID);
					}else if(aplicaPomocionRegresoAclases()){
						consultaPromocionClientePedido(PROMOCION.regresoAclases.productoID);
					}
					else{
						inicializaVista();
					}
				}else
					inicializaVista();
				
			}catch(e){
				inicializaVista();
			}
			
	    };
	    
	    function inicializaVista(){
			
			$scope.showPage = false;
			
			if( messageData ){
				
				if( generalService.existeSolicitud($rootScope.solicitudJson) ){
					
					$scope.cargaVista();										
					
					$timeout(function(){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$scope.showPage = messageData;
					}, TIME_OUT_VIEW_MODEL);
				
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message(SIN_SOLICITUD.titulo, [SIN_SOLICITUD.texto], "Aceptar", "/", null, null);								
				}
			}
			
				
	    };
	    
	  $scope.validaDocumentosFaltantes = function(){
		  var ifeEnviada=false;
			var huellaEnviada=false;
			var fotoEnviada=false;
			var numFaltaEnviados=0;
			angular.forEach( $rootScope.solicitudJson.documentos.documento, function(doc){																																	
				if( doc.idDocumento == 1 && doc.status != 7){
					ifeEnviada = true;
					
				}
			});
			if(!ifeEnviada)
				numFaltaEnviados++;
			if($rootScope.solicitudJson.cotizacion.clientes[0].huella == HUELLA_ENVIADA)
				huellaEnviada=true;
			else
				numFaltaEnviados++;
			if($rootScope.solicitudJson.cotizacion.clientes[0].foto == FOTO_ENVIADA)
				fotoEnviada=true;
			else
				numFaltaEnviados++;
			
			$scope.estatus = 1;
			if(ifeEnviada && huellaEnviada && fotoEnviada){
				if(!$scope.solGenerada)
					$scope.labelVisita = "La solicitud aún no baja a tienda. Favor de comunicarse con soporte. ";
				else
					$scope.labelVisita = "La solicitud aún no esta en investigación. Favor de comunicarse con soporte. ";
			}else{
				if(numFaltaEnviados == 1){
					switch(false){
					case ifeEnviada:
						if(!$scope.solGenerada)
							$scope.labelVisita = "La solicitud aún no baja a tienda. Falta enviar la IFE";
						else
							$scope.labelVisita = "La solicitud aún no esta en investigación. Falta enviar la IFE";
						break;
					case huellaEnviada:
						if(!$scope.solGenerada)
							$scope.labelVisita = "La solicitud aún no baja a tienda. Falta enviar la HUELLA";
						else
							$scope.labelVisita = "La solicitud aún no esta en investigación. Falta enviar la HUELLA";
						break;
					case fotoEnviada:
						if(!$scope.solGenerada)
							$scope.labelVisita = "La solicitud aún no baja a tienda. Falta enviar la FOTO";
						else
							$scope.labelVisita = "La solicitud aún no esta en investigación. Falta enviar la FOTO";
						break;
					}
				}else{
					if(!$scope.solGenerada)
						$scope.labelVisita = "La solicitud aún no baja a tienda. Falta enviar los siguientes documentos: ";
					else
						$scope.labelVisita = "La solicitud aún no esta en investigación. Falta enviar los siguientes documentos: ";
					var i=0;
					$scope.listaDocumentosFaltantes=[];
					if(!ifeEnviada){
						$scope.listaDocumentosFaltantes[i]="IFE";
						i++;
					}
					if(!huellaEnviada){
						$scope.listaDocumentosFaltantes[i]="HUELLA";
						i++;
					}
					if(!fotoEnviada){
						$scope.listaDocumentosFaltantes[i]="FOTO";
					}
					for(i=0;i<$scope.listaDocumentosFaltantes.length;i++){
						if(i < ($scope.listaDocumentosFaltantes.length - 1))
							$scope.labelVisita = $scope.labelVisita + $scope.listaDocumentosFaltantes[i] + ", ";
						else
							$scope.labelVisita = $scope.labelVisita + $scope.listaDocumentosFaltantes[i];
					}
				}
			}
	  }	  	 


	  $scope.terminar = function() {
		  /*\Se agrega un evento para la bitacora\*/
			//(estatus)
				$rootScope.addEvent( BITACORA.SECCION.estatus.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.aceptar.id, 0, BITACORA.SECCION.estatus.guardarEnBD );
				$rootScope.enviaEventos();
				/*\Se agrega un evento para la bitacora\*/
		  var documentoEncolado = generalService.documentoEncolado($rootScope.solicitudJson);
		  var bazDigital=false;
		  if($rootScope.solicitudJson.idPlataforma == 6)
			  bazDigital=true;
		  if(!bazDigital && $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.liberacionAplicada && $rootScope.solicitudJson.idProducto != ID_PRODUCTO.prestamoPersonal){
			  generalService.cleanRootScope($rootScope);
			  generalService.buildSolicitudJson($rootScope, null);
			  
/** INICIA_OS**/ 			  
			  if($rootScope.solicitudOSJson && $rootScope.solicitudOSJson.idSolicitud != ""){
			  		generalServiceOS.cleanRootScope($rootScope);
			  		generalService.buildSolicitudOSJson($rootScope, null);
			  }
/** TERMINA_OS**/ 

			  generalService.locationPath("/simulador");
		  }else{
			  if(  $rootScope.solicitudJson.marca != STATUS_SOLICITUD.autorizada.marca.surtida && $rootScope.solicitudJson.idSolicitudTienda != 0 && !documentoEncolado && $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && !bazDigital && $rootScope.solicitudJson.marca != STATUS_SOLICITUD.autorizada.marca.tipoDispersionSeleccionado && $rootScope.solicitudJson.marca != STATUS_SOLICITUD.autorizada.marca.sinTaz && $rootScope.solicitudJson.marca != STATUS_SOLICITUD.autorizada.marca.pendienteDeSurtir && $rootScope.solicitudJson.tipoSolicitud != SOLICITUD_REACTIVADO && $rootScope.sucursalSession.idCanal != CANALES.soriana)
				  generalService.locationPath("/ochoPasos");
			  else if( $rootScope.solicitudJson.marca != STATUS_SOLICITUD.autorizada.marca.surtida && $rootScope.solicitudJson.creditoInmediato == 1 && $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id && !bazDigital && $rootScope.solicitudJson.marca != STATUS_SOLICITUD.autorizada.marca.tipoDispersionSeleccionado && $rootScope.solicitudJson.marca != STATUS_SOLICITUD.autorizada.marca.sinTaz){
					generalService.locationPath("/ochoPasos");
			  }else{
				  generalService.cleanRootScope($rootScope);
				  generalService.buildSolicitudJson($rootScope, null);
				  
/** INICIA_OS**/ 			  
				  if($rootScope.solicitudOSJson && $rootScope.solicitudOSJson.idSolicitud != ""){
				  		generalServiceOS.cleanRootScope($rootScope);
				  		generalService.buildSolicitudOSJson($rootScope, null);
				  }
/** TERMINA_OS**/ 
	
				  generalService.locationPath("/simulador");
			  }
		  }
			  
	  };/* END TERMINAR FUNCTION */
	    
	  
	  $scope.liberarCallCenter=function(){
		  if($scope.reenviar){
		     $rootScope.waitLoaderStatus = LOADER_SHOW; 
			 var x = {
				solicitudJson: JSON.stringify($rootScope.solicitudJson),
				seccion: 9					
			 }
			 callCenterService.liberar( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO)						
					     $scope.reenviar=false;
					else
						$rootScope.message("Reenvío CallCenter",[generalService.displayMessage(data.data.descripcion)],"Aceptar");
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                $rootScope.message("Reenvío CallCenter",[ ERROR_SERVICE ],"Aceptar");
					
				}
			 );
		  }
	  };
	  
	  $scope.dispersarCallCenter=function(){
		  if($scope.reenviar){
		     $rootScope.waitLoaderStatus = LOADER_SHOW;
		     
		     if(generalService.isBazDigital()){
		    	 var request = {
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							tipoPeticion: 1,
							idPlataforma: PLATAFORMA.BAZDIGITAL
						};
		    	 
				callCenterService.dispersarTarjetas( request ).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var jResponse = JSON.parse(data.data.respuesta);
								
								if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									generalService.setDataBridge({origen: FICHA.origen.recuperar });
									generalService.locationPath("/ficha");
								}else
									$rootScope.message("Dispersar CallCenter ", [ jResponse.descripcion, "Codigo de error "+jResponse.codigo ],"Aceptar");
								
							}else
								$rootScope.message("Dispersar CallCenter",[generalService.displayMessage(data.data.descripcion)],"Aceptar");
								
							
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 			                
							
						}
					);
		     }else{
		    	 solicitudService.dispersionTarjeta({idSolicitud:$rootScope.solicitudJson.idSolicitud}).then(
		 				function(data){
		 					$scope.reenviar=false;
		 					$rootScope.waitLoaderStatus = LOADER_HIDE;
		 					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
		 						var jResponse = JSON.parse(data.data.respuesta);
		 						if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO)
		 							$rootScope.message("Dispersar Tarjeta",[ "Operación exitosa" ],"Aceptar");
		 						else
		 							$rootScope.message("Dispersar Tarjeta",[ jResponse.descripcion ],"Aceptar");
		 					}else
		 						$rootScope.message("Dispersar Tarjeta",[generalService.displayMessage(data.data.descripcion)],"Aceptar");
		 				}, function(error){
		 					$rootScope.waitLoaderStatus = LOADER_HIDE;
		 					$rootScope.message("Dispersar Tarjeta",[ ERROR_SERVICE ],"Aceptar");
		 				}
		 			 );
		     }		     		     
			 
		  }
	  };
	  
	    $scope.recuperaTAZ=function(){
	    	$scope.tarjetaNueva={};
	    	$scope.tarjetaNueva={valor:""};
	    	var r = {
    			idSolicitud: $rootScope.solicitudJson.idSolicitud,
    			tipoTarjeta: 42
	    	};
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	solicitudService.buscaTarjeta(r).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
				    	var jResponse = JSON.parse(data.data.respuesta);
						if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							$scope.tarjetaNueva.valor=jResponse.data[0].numTarj;
				    		$scope.activaTaz();
						}else
							$rootScope.message("Recuperar tarjeta",[ jResponse.descripcion ],"Aceptar");
					}else
						$rootScope.message("Recuperar tarjeta",[generalService.displayMessage(data.data.descripcion)],"Aceptar");
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
					
			});
	    };
	    
	    $scope.activaTaz=function(){
			var cu = $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico;								
			var cuArray = cu.split('-');
			var request = {
	    			idSolicitud: $rootScope.solicitudJson.idSolicitud,	    			
	    			cu: {pais:parseInt(cuArray[0]), canal:parseInt(cuArray[1]), sucursal:parseInt(cuArray[2]), folio:parseInt(cuArray[3])},
	    			numCteAlnova: $rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova,
	    			numTaz: $scope.tarjetaNueva.valor,
	    			nip: ""
	    	};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	tarjetaService.activaTazInstantanea( request ).then(
    			function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						$scope.respuetaActivacion(data.data.respuesta,request);
					}else{
						$rootScope.waitLoaderStatus = LOADER_HIDE; 
						modalService.alertModal("Entrega de tarjeta", [generalService.displayMessage(data.data.descripcion)], "Aceptar", "bgCafeZ", "cafeZ");
					}
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE;
	                $rootScope.modalService.alertModal("Error en servidor", [ERROR_SERVICE], "Aceptar", "bgCafeZ", "cafeZ");
				});
		};
		
		$scope.respuetaActivacion=function(jresponse,request){
			jresponse.jsonResponseLCR = JSON.parse(jresponse.jsonResponseLCR);								
			if(jresponse.jsonResponseLCR.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
				jresponse.jsonResponseActivacion = JSON.parse(jresponse.jsonResponseActivacion);									
				try{
					if(jresponse.jsonResponseActivacion.codigo == RESPONSE_TARJETA_CODIGO_EXITO){
						jresponse.jsonResponseUpdStatus = JSON.parse(jresponse.jsonResponseUpdStatus);
						if(jresponse.jsonResponseUpdStatus.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.tazActivada;
							$scope.showActivarTAZ=false;
							$scope.showDispersionCallCenter=true;
							$scope.dispersarCallCenter();
						}else{
							$scope.reenviar=false;
							$rootScope.message("Actualizar Estatus", ["Favor de intentarlo más tarde."], "Aceptar");
						}
						
//						var flujoPorCanal = $scope.verificarCanal();
//						if(jresponse.jsonResponseUpdStatus.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
//							$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.tazActivada;
//							if( request.nip!=undefined  &&  !generalService.isEmpty(request.nip) ){
//								jresponse.jsonResponseNIP = JSON.parse(jresponse.jsonResponseNIP);
//								if(jresponse.jsonResponseNIP.codigo != RESPONSE_TARJETA_CODIGO_EXITO)
//									$rootScope.message("NIP", ["La tarjeta fue activada exitosamente pero hubo un error al registrar el NIP, coméntale al cliente que " +
//									                           "lo puede registrar posteriormente."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
//								else{
//									$scope.capacidadPago = ($rootScope.solicitudJson.banderaIngresos == 1 || $rootScope.solicitudJson.banderaSolidario == 1)? $rootScope.solicitudJson.capacidadPagoComprobable : $rootScope.solicitudJson.capacidadPagoNoComprobable;
//									$scope.disponible = $scope.capacidadPago - $rootScope.solicitudJson.cotizacion.pagoNormal;
//									if ($scope.disponible <= 0)
//										$rootScope.message("Confirmación", ["Infórmale a tu cliente que esta tarjeta la podrá ocupar una vez que surta su primer pedido."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
//									else
//										$rootScope.message("Confirmación", ["Tarjeta activada exitosamente."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
//								}
//							}else{
//								$scope.capacidadPago = ($rootScope.solicitudJson.banderaIngresos == 1 || $rootScope.solicitudJson.banderaSolidario == 1)? $rootScope.solicitudJson.capacidadPagoComprobable : $rootScope.solicitudJson.capacidadPagoNoComprobable;
//								$scope.disponible = $scope.capacidadPago - $rootScope.solicitudJson.cotizacion.pagoNormal;
//								if ($scope.disponible <= 0)
//									$rootScope.message("Confirmación", ["Infórmale a tu cliente que esta tarjeta la podrá ocupar una vez que surta su primer pedido."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
//								else
//									$rootScope.message("Confirmación", ["Tarjeta activada exitosamente."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
//							}
//						}else
//							$rootScope.message("Actualizar Estatus", ["Codigo de error "+jresponse.jsonResponseUpdStatus.codigo, ERROR_SERVICE], "Aceptar", null, "bgCafeZ", "cafeZ");
					}else{
						var respuestaAln=$scope.manejoErrorAlnova(jresponse.jsonResponseActivacion.data.descriptionCode);
						if (respuestaAln){
							$rootScope.message("Activar Tarjeta", [respuestaAln], "Aceptar", null, "bgCafeZ", "cafeZ");
						}else{
							if (jresponse.jsonResponseActivacion.data.descriptionCode){
								$rootScope.message("Activar Tarjeta", ["Codigo de error "+jresponse.jsonResponseActivacion.codigo,jresponse.jsonResponseActivacion.data.descriptionCode], "Aceptar", null, "bgCafeZ", "cafeZ");
							}else{
								$rootScope.message("Activar Tarjeta", ["Error al intentar activar tarjeta"], "Aceptar", null, "bgCafeZ", "cafeZ");
								$rootScope.loggerServicios("estatusController", jresponse);
							    $rootScope.waitLoaderStatus = LOADER_HIDE;
							}
						}
					}
				}catch( e ){
					$rootScope.message("Activar Tarjeta", ["Error "+ e.message ], "Aceptar", null, "bgCafeZ", "cafeZ");
				}								
			}else{
				if (jresponse.jsonResponseLCR.codigo == 401){
					$rootScope.waitLoaderStatus = LOADER_HIDE; 
					generalService.cleanRootScope($rootScope);
					generalService.buildSolicitudJson($rootScope, null);
					$rootScope.message("LCR", ["Esta solicitud de Línea de Crédito no se encuentra autorizada, por lo cual, no es posible continuar con el proceso."], "Aceptar", "/", "bgCafeZ", "cafeZ");
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE; 
					$rootScope.message("LCR", ["Codigo de error "+jresponse.jsonResponseLCR.codigo,ERROR_SERVICE], "Aceptar", null, "bgCafeZ", "cafeZ");
				}
			}
		};
		
		$scope.validarHuella=function(){
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) > -1 ){
				$scope.huellaValida=true;
			}
			
			if(!$scope.huellaValida){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$rootScope.verificarHuella( 'estatus', 'responseVerificarHuellaIpad', [$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico]);
			}else if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazEntregada || $rootScope.solicitudJson.marca == 253 || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente)){
				$scope.liberarLCR();
			}else if(
					($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && ($rootScope.solicitudJson.marca == 1016 || $rootScope.solicitudJson.marca == 253 || $rootScope.solicitudJson.marca == 254 || $rootScope.solicitudJson.marca == 5006 || $rootScope.solicitudJson.marca == 1007) && $rootScope.solicitudJson.pedido == 0 && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal) ||
					($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && $rootScope.solicitudJson.marca == 5002 && $rootScope.solicitudJson.idProducto != ID_PRODUCTO.prestamoPersonal) ||
					($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && ($rootScope.solicitudJson.marca == 1016 || $rootScope.solicitudJson.marca == 253 || $rootScope.solicitudJson.marca == 254 || $rootScope.solicitudJson.marca == 5006 || $rootScope.solicitudJson.marca == 5002 || $rootScope.solicitudJson.marca == 1007) && $rootScope.solicitudJson.pedido == 0 && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal && $rootScope.solicitudJson.campana==="winback")
				){
				$scope.generarPedido();
			}
		}
		
		$scope.responseVerificarHuellaIpad = function( response ){
			$rootScope.loggerIpad("responseVerificarHuellaIpad", null, response);
			try{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				switch(response.codigo){
					case VALIDA_HUELLA_RESPONSE.EXITO:
						$scope.huellaValida=true;

						if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazEntregada || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente)){
							$scope.liberarLCR();
							
						}else if(
								($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && ($rootScope.solicitudJson.marca == 1016 || $rootScope.solicitudJson.marca == 253 || $rootScope.solicitudJson.marca == 254 || $rootScope.solicitudJson.marca == 5006 || $rootScope.solicitudJson.marca == 1007) && $rootScope.solicitudJson.pedido == 0 && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal) ||
								($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && $rootScope.solicitudJson.marca == 5002 && $rootScope.solicitudJson.idProducto != ID_PRODUCTO.prestamoPersonal)
							){
							$scope.generarPedido();
							
						}
						
						break;
					case VALIDA_HUELLA_RESPONSE.NO_HAY_COINCIDENCIAS:
						modalService.alertModal("estatus", ["La huella ingresada no coincide con el cliente."], "Aceptar", "bgCafeZ", "cafeZ");
						break;
					default:
						modalService.alertModal( "Error al verificar la huella", [response.mensaje], "Aceptar", "bgCafeZ", "cafeZ");
						break;
				}
			}catch(e){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				modalService.alertModal( "Error al verificar la huella", [e], "Aceptar", "bgCafeZ", "cafeZ");
			}
		};
		
		
		$scope.liberarLCR = function(){
			var request = {
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					tarjeta: "1"
			};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.liberarLCR(request).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jResponse = JSON.parse(data.data.respuesta);
							
							if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.liberacionAplicada;
								
								if($rootScope.solicitudJson.tipoSolicitud == SOLICITUD_REACTIVADO){
									//$scope.cargaVista();
									if($rootScope.solicitudJson.campana == CAMPANAS_REACTIVADOS.winback)
										generalService.locationPath("/surtimiento");
									else
										generalService.locationPath("/estatus");
									
								}else if(generalService.flujoPorDispersion()){
									generalService.locationPath("/surtimiento");								
								}else{
									var request = {
										idSolicitud: $rootScope.solicitudJson.idSolicitud
									};
												
									$rootScope.waitLoaderStatus = LOADER_SHOW;
									callCenterService.liberarPedidoSinTAZ(request).then(
										function(data){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											
											if(data.data.codigo == RESPONSE_CODIGO_EXITO){
												var respuesta = JSON.parse(data.data.respuesta);
												
												if(respuesta.codigo == 2){
													
													/*\Se agregan eventos para la bitacora\*/
//													(Surtimiento)
											    	$rootScope.addEvent( BITACORA.SECCION.surtimiento.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.surtir.id, 0, BITACORA.SECCION.surtimiento.guardarEnBD );								
													/*\Se agregan eventos para la bitacora\*/
											    	
													generalService.setDataBridge({origen: FICHA.origen.recuperar });
													//generalService.locationPath("/ficha");
													if($rootScope.flujoSinTAZ){
													/** Aqui va mensaje intermedio de Felicidades **/
														modalService.liberarPRModal("¡FELICIDADES!", $rootScope.solicitudJson.idProducto ).then(
																function(exito){
																	generalService.locationPath("/ficha");
																}, function(error){
																	console.log("Error : " + error);
														});
													}else{
														generalService.locationPath("/ficha");
													}
												}else if(respuesta.codigo == LCR_CENTRAR_SINLIBERAR_ERROR){
													$scope.showLiberar=false;
													$scope.showGenerarPedido=true;
													$scope.huellaValida=false;
													$rootScope.message("Estatus Codigo: "+ respuesta.codigo,["La linea de crédito aún no está liberada, favor de intentar nuevamente en 5 minutos, si el problema persiste favor de comnicarse con soporte."],"Aceptar",null,"bgAzulD", "azulD");
												}else{
													$scope.showLiberar=false;
													$scope.showGenerarPedido=true;
													$scope.huellaValida=false;
													$rootScope.message("Estatus Codigo: " + respuesta.codigo,["Hemos detectado un inconveniente: " +respuesta.descripcion],"Aceptar",null,"bgAzulD", "azulD");
												}
											}else{
												$scope.showLiberar=false;
												$scope.showGenerarPedido=true;
												$scope.huellaValida=false;
												$rootScope.message("Estatus", ["Se presentó un problema al consumir el servicio por favor reintente."],"Aceptar",null,"bgAzulD", "azulD");
											}
										}, function(error){
											$scope.showLiberar=false;
											$scope.showGenerarPedido=true;
											$scope.huellaValida=false;
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$rootScope.message("Estatus", ["Se presentó un problema al consumir el servicio por favor reintente."],"Aceptar",null,"bgAzulD", "azulD");
										}
									);
								}
							}else{
								$scope.huellaValida=false;
								$rootScope.message("Error", ["No se liberó la Linea de Crédito, Intentalo Nuevamente."],"Aceptar",null,"bgAzulD", "azulD");
							}	
					}else{
						$rootScope.message("Error", ["No se liberó la Linea de Crédito, Intentalo Nuevamente."],"Aceptar",null,"bgAzulD", "azulD");
					}
				}
			);
		};

		$scope.generarPedido = function() {
			// Se prepara el JSON para el consumo.
			var request = {
					idSolicitud: $rootScope.solicitudJson.idSolicitud
			};

			// Oh, hello Spinner!
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			// Se detona el consumo.
			callCenterService.liberarPedidoSinTAZ(request).then(
				function(data) {
					// Bye, bye Spinner!
					$rootScope.waitLoaderStatus = LOADER_HIDE;

					if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var respuesta = JSON.parse(data.data.respuesta);

						if(respuesta.codigo == 2) {
							// Se actualiza el JSON de la solicitud.
							$rootScope.solicitudJson = respuesta.data;
							
							/*\Se agregan eventos para la bitacora\*/
//							(Surtimiento)
					    	$rootScope.addEvent( BITACORA.SECCION.surtimiento.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.surtir.id, 0, BITACORA.SECCION.surtimiento.guardarEnBD );								
							/*\Se agregan eventos para la bitacora\*/

							if(($rootScope.solicitudJson.idSeguimiento == 6 && 
									($rootScope.solicitudJson.marca == 253 
											|| $rootScope.solicitudJson.marca == 254 
											|| $rootScope.solicitudJson.marca == 5006) 
									&& $rootScope.solicitudJson.pedido == 0 
									&& rootScope.solicitudJson.idProducto != ID_PRODUCTO.prestamoPersonal) 
									|| ($rootScope.solicitudJson.idSeguimiento == 6 
											&& ($rootScope.solicitudJson.marca == 5006 
													|| $rootScope.solicitudJson.marca == 267))) {
								if($rootScope.solicitudJson.tipoDispersion == DISPERSION_GUARDADITO && $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.surtida){
									validarPromocion();
								}else{
									// ¡A la calle, venga!
									generalService.setDataBridge({origen: FICHA.origen.recuperar });
									generalService.locationPath("/ficha");
								}
							} else if($rootScope.solicitudJson.idSeguimiento == 6 
									&& ($rootScope.solicitudJson.marca == 1016 
											|| $rootScope.solicitudJson.marca == 253 
											|| $rootScope.solicitudJson.marca == 254 
											|| $rootScope.solicitudJson.marca == 5006 
											|| $rootScope.solicitudJson.marca == 1007) 
									&& $rootScope.solicitudJson.pedido > 0 
									&& rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal) {
								$scope.cargaVista();
							}
						} else if(respuesta.codigo == LCR_CENTRAR_SINLIBERAR_ERROR){
							$scope.huellaValida = false;
							$rootScope.message("Estatus Codigo "+ respuesta.codigo,["La linea de crédito aún no está liberada, favor de intentar nuevamente en 5 minutos, si el problema persiste favor de comnicarse con soporte."], "Aceptar", null, "bgAzulD", "azulD");
						
						}else{
							$scope.huellaValida = false;
							$rootScope.message("Estatus Codigo " + respuesta.codigo,["Hemos detectado un inconveniente: " +respuesta.descripcion], "Aceptar", null, "bgAzulD", "azulD");
						}
					} else {
						$scope.huellaValida = false;
						$rootScope.message("Estatus", ["Se presentó un problema al consumir el servicio por favor reintente."],"Aceptar",null,"bgAzulD", "azulD");
					}
				}, function(error) {
					$scope.huellaValida = false;
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Estatus", ["Se presentó un problema al consumir el servicio por favor reintente."],"Aceptar",null,"bgAzulD", "azulD");
				}
			);
		};
		
		var validarPromocion = function(){
			var idPlataforma = 1;
			if($rootScope.solicitudJson.idPlataforma == 6 || $rootScope.solicitudJson.idPlataforma == 7 || $rootScope.solicitudJson.idPlataforma == 9)
				idPlataforma = 2;
			var jsonRequest = {
					clienteUnico: $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
					pais: $rootScope.solicitudJson.idPais,
					canal: $rootScope.solicitudJson.idCanal,
					sucursal: $rootScope.solicitudJson.idSucursal,
					pedido: $rootScope.solicitudJson.pedido,
					plataforma: idPlataforma,
					plazo: $rootScope.solicitudJson.cotizacion.plazo,
					monto: $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto,
					surtimientoEnLinea: "true",
					campana: $rootScope.solicitudJson.campana,
					observaciones: $rootScope.solicitudJson.observaciones
				};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			surtimientoService.consultaPromocion(jsonRequest,PROCESOS.PSC).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if (jsonResponse.codigo == 90206) {
							var jsonResponsePromo = JSON.parse(jsonResponse.data);
							var isGanador = JSON.parse(jsonResponsePromo.ganador);
							if(isGanador)
								modalGanador(jsonResponsePromo);
							else{
								// ¡A la calle, venga!
								generalService.setDataBridge({origen: FICHA.origen.recuperar });
								generalService.locationPath("/ficha");
							}
						}else{
							// ¡A la calle, venga!
							generalService.setDataBridge({origen: FICHA.origen.recuperar });
							generalService.locationPath("/ficha");
						}
					} else{
						$rootScope.message("Error", ["Favor de volverlo a intentarlo nuevamente"], "Aceptar", "/simulador", "bgCafeZ", "cafeZ");
					}
				},
				function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Error", ["Favor de volverlo a intentarlo nuevamente"], "Aceptar", "/simulador", "bgCafeZ", "cafeZ");
				});
			
		}
		
		var modalGanador = function(jsonResponsePromo){
			modalService.buenFin(jsonResponsePromo).then(
					function(exito){
						// ¡A la calle, venga!
						generalService.setDataBridge({origen: FICHA.origen.recuperar });
						generalService.locationPath("/ficha");
					}, function(error){
						// ¡A la calle, venga!
						generalService.setDataBridge({origen: FICHA.origen.recuperar });
						generalService.locationPath("/ficha");
			});
		}
		
		function consultaPromocionClientePedido(fiproducto){			
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			//$scope.esSorteoNavidad = true;
			
			var jsonRequest = {
				"fipais": $rootScope.sucursalSession.idPais,
				"ficanal": $rootScope.sucursalSession.idCanal,
				"fisucursal": $rootScope.sucursalSession.idSucursal,
				"finopedido":  $rootScope.solicitudJson.pedido,
				"fiproducto": fiproducto,
				"ficamp":1023,
				"fcempentrega":"" ,
				"fdentrega":null ,
				"fnprecio":0.0 ,
				"ficantidad":1 ,
				"fcUsuario":"USRPRESTAMOS",
				"fcObserv":""
			}


			solicitudService.promoCreditoRegistrar( jsonRequest ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					if(data.data.codigo == 1){
						var j = JSON.parse(data.data.respuesta);
						
						
						if(j.estatus === "1"){
							
							switch(fiproducto){
							case PROMOCION.billetazo.productoID:$scope.esGanadorPromocion = true;
							break;
							case PROMOCION.diaMadres.productoID:$scope.esGanadorDiaMadres = true;
							console.log("$scope.esGanadorDiaMadres en true");
							break;
							case PROMOCION.regresoAclases.productoID:$scope.esGanadorRegresoAclases = true;
							console.log("$scope.esGanadorRegresoAclases en true");
							break;
							}

							inicializaVista();
						}else
							inicializaVista();
						
						
					}else
						inicializaVista();
					
				}, function(error){
					inicializaVista();
	                $rootScope.waitLoaderStatus = LOADER_HIDE;
				}
			);
		}
		
		function obtenerCapacidadConsumoCliente(capacidadesPagoProducto){
			var capacidadConsumo;
			for(var i=0; i< capacidadesPagoProducto.length;i++){
				if(capacidadesPagoProducto[i].producto == PRODUCTOS.consumo.ID.valor){
					if ($rootScope.solicitudJson.banderaIngresos== 1){
						capacidadConsumo = capacidadesPagoProducto[i].capacidadPagoComprobable - $rootScope.solicitudJson.cotizacion.pagoPuntual;
					}else{
						capacidadConsumo =capacidadesPagoProducto[i].capacidadPagoNoComprobable - $rootScope.solicitudJson.cotizacion.pagoPuntual;
					}

				}
			}
			
			return capacidadConsumo;
		}
		
		$scope.validarContratos = function(){
			var hayAcuseTaz = false;
			var contratos = $rootScope.solicitudJson.contratos.contrato;
			for(var i in contratos){
				if(contratos[i].idContrato == FIRMA_ACUSE_TAZ.id){
					if(contratos[i].statusFirma == STATUS_CONTRATO.ENVIAD0 || $scope.envioAcuseTaz)
						hayAcuseTaz = true;
					break;
				}
			}
			(hayAcuseTaz)?$scope.liberarLCR():$scope.modalAcuseTaz();
		};
		
		$scope.modalAcuseTaz = function(){
			
			if (configuracion.origen.tienda)
				$rootScope.validarTienda = true;
			else
				$rootScope.validarTienda = false;
		    $scope.tituloAviso = {texto:"Acuse de entrega de la Tarjeta de Crédito "};
          	$scope.tituloFirma = "Firma Acuse de entrega de la Tarjeta de Crédito ";              	              	
          	$scope.urlDoc = "acuseTaz.html";
          	$rootScope.isSolicitud = false;
          	$rootScope.isAcuseTaz = true;
          	$rootScope.title = "Acuse de entrega de la Tarjeta de Crédito";
          	$scope.negacionCheck = {texto:"No acepto Acuse de Tarjeta de Crédito", visible: true, textoMensaje:" Acuse de Tarjeta Azteca", botonAceptar: "Aceptar"};
			$scope._btnNoAceptar = generalService.getDataInput("CONTRATOS","BOTON NO ACEPTAR", $scope.origen);
			$scope._btnAceptar = generalService.getDataInput("CONTRATOS","BOTON ACEPTAR", $scope.origen);
			$scope.txtModalContratos = generalService.getDataInput("CONTRATOS","TEXTO MODAL CONTRATOS", $scope.origen);
			
			var imagenesArray = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";				
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
							
				
			modalService.pdfViewModal($scope.urlDoc, $scope.tituloAviso.texto, $scope._btnAceptar.texto, "Cerrar", null, $scope._btnAceptar.estilo, null, true, $scope.esContratos, $scope.contratosAceptados, 0, $scope.txtModalContratos,imagenesArray, $scope.muestraAvisos, $scope.negacionCheck )
			.then(
					function(aceptar){
						$rootScope.isAcuseTaz = true;
						
						$scope.guardarContratos();
						$scope.addOverflow();
					},function(noaceptar){
						 $rootScope.isAcuseTaz = false;
						$scope.addOverflow();
					}
				);					
		};
		
		$scope.guardarContratos = function (){
			
			var agregaAcuseTaz =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
				return d["idContrato"];
				
			}).indexOf (FIRMA_ACUSE_TAZ.id);
			if (agregaAcuseTaz == -1){
				
				var jsonAcuseTaz = {
						idContrato: FIRMA_ACUSE_TAZ.id,
						idPersona: $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
						statusFirma: STATUS_CONTRATO.SIN_FIRMA,
						descripcion: "acuseTaz",
						idTipoPersona: 1
					};
	
				$rootScope.solicitudJson.contratos.contrato.push(jsonAcuseTaz);
				
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($rootScope.solicitudJson), seccion: 8 } ).then(
					function(data){
						if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
							var responseJson = JSON.parse(data.data.respuesta);
							
							if(responseJson.codigo == 2){							
								$rootScope.solicitudJson.contratos = responseJson.data.contratos;
								if ($scope.origen == "TIENDA" && (configuracion.so.ios || configuracion.so.windows)){
									$scope.archivafirmasAcuseTaz();
								}
							}
						}else{
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$rootScope.message("Error",["Ocurrio un error al guardar la sección de contratos. Favor de volver a intentar"], "Aceptar", null, "bgRosa", "btnRosaD");
						}
						
					}, function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Error",["Ocurrio un error al guardar la sección de contratos. Favor de volver a intentar"], "Aceptar", null, "bgRosa", "btnRosaD");
					}
				);
			}else{
				$scope.archivafirmasAcuseTaz();
			}
			
		};
		
		$scope.archivafirmasAcuseTaz = function(){
			$scope.contadorArchivarFirmas++;
								
			var descripcion = FIRMA_ACUSE_TAZ.descripcion;
			var etiqueta =  FIRMA_ACUSE_TAZ.etiqueta;
	
			$scope.imgFirma = $rootScope.imgAcuseTaz;
			if (!$scope.imgFirma){
				console.log("No hay firma");
			}else{
				$scope.b64Firma = $scope.imgFirma.replace("data:image/png;base64,","").trim();
		    	if(configuracion.origen.tienda){
		    		
		    		var biometrico = {
							ruta: null,
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							cadena:$scope.b64Firma,
							tipoCadena: descripcion,
							porcentaje: 100
					}
		    		
		    		$scope.enviaAcuseTaz(biometrico);
		    		
		    	}	
			}
		};
		
		$scope.enviaAcuseTaz = function (biometrico){
			$scope.envioAcuseTaz = false;
			clienteUnicoService.setBiometrico( biometrico ).then(
				function(data){
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							$scope.envioAcuseTaz = true;
							$scope.liberarLCR();
							generalService.setRespaldo($rootScope.solicitudJson);
						}else if(j.codigo == RESPONSE_CODIGO_ERROR_ID){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$scope.activar = false;
							$rootScope.message("Error",[j.descripcion], "Aceptar", null, "bgCafeZ","cafeZ",null,null,null);
						}else{
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$scope.activar = false;
							$rootScope.message("Error",["Error al enviar el contrato. Por favor, espere unos minutos para reintentar"], "Aceptar", null, "bgCafeZ","cafeZ",null,null,null);
						}
					}else{
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$scope.activar = false;
						$rootScope.message("Error",["Error en la respuesta del servicio para guardar el contrato del cliente. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafeZ","cafeZ");
					}
				},function(error){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Error",["Servicio no disponible para enviar el contrato, favor de comunicarse con soporte."], "Aceptar", "/simulador", "bgCafeZ","cafeZ");
				});
		};
		
		$scope.addOverflow=function(){
			$( "html" ).removeClass( "overflowHiddenHTML");
			$( "body" ).addClass( "overflowInitialHTML");
		};
	  
	});
	
});