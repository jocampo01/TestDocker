'use strict';

define(["app"], function (app) {

	app.controller("exampleController", function ($q, $scope,ngDialog,$timeout, $rootScope, $http, $compile, $interval, exampleService, solicitudService, modalService, callCenterService, clienteUnicoService, 
												  generalService, buroService, documentosService, loginService, securityService, messageData, validateService, tarjetaService, surtimientoService,
												  bazDigitalService, italikaService, obligadoSolidarioService) {                              
		
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		$scope.solId = "20170510184807184807569709";
		$scope.pathImg = "";
		$scope.pathImg1 = ""
		$scope.ciphecode = "";
		$scope.isTienda = configuracion.origen.tienda;
		
		$scope.titulo = "TEST";
		$scope.showcaptcha = false;
		$scope.showcadenaimg = false;
		$scope.captcha = {
				id:null,
				respuesta: null,
				img:null,
				pregunta:null
		}
		$scope.solicitudes = [];
		
		var jsonRequest = {id:1, descripcion:"PRUEBA SERVICES REST POR POST"};
		var intento = 0;
		
		$scope.tipofotoife = ["Capturar IFE (frente)", "Capturar IFE (reverso)"];
		$scope.tipofotoingreso = ["Capturar comprobante de ingresos"];
	        		
		var timer = null;	
		
		$scope.getTasaItalika = function(){
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			italikaService.getTasaItalika(  ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						$rootScope.message("exito", [data.data.respuesta],"Aceptar",null,"bgCafeZ", "cafeZ");
												
					}else
						$rootScope.message("Error", [data.data.descripcion],"Aceptar",null,"bgCafeZ", "cafeZ");
				}, function(error){
	               $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
					
				}
			);
		};
		
		$scope.getProductoPorNombreItalika = function(){
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			italikaService.getProductoPorNombreItalika( {nombreProducto:'moto'} ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						$rootScope.message("exito", [data.data.respuesta],"Aceptar",null,"bgCafeZ", "cafeZ");
												
					}else
						$rootScope.message("Error", [data.data.descripcion],"Aceptar",null,"bgCafeZ", "cafeZ");
				}, function(error){
	               $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
					
				}
			);
		};
		
		
		$scope.consultaProductosItalika = function(){
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			italikaService.consultaProductosItalika( {descripcionProducto: "MOTO"} ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						$rootScope.message("exito", [data.data.respuesta],"Aceptar",null,"bgCafeZ", "cafeZ");
												
					}else
						$rootScope.message("Error", [data.data.descripcion],"Aceptar",null,"bgCafeZ", "cafeZ");
				}, function(error){
	               $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
					
				}
			);
		};
		
		
		$scope.guardaLiberacionFolioUnico = function(){
			var r = {
					idSolicitud: "20162811256897458965324785",
					numCuenta: null,
					tipoCredito: 99			//98 efectivo / 99 deposito	    			
	    	};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.guardarDatosLiberacion(r).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						$rootScope.message("exito", [data.data.respuesta],"Aceptar",null,"bgCafeZ", "cafeZ");
												
					}else
						$rootScope.message("Error", [data.data.descripcion],"Aceptar",null,"bgCafeZ", "cafeZ");
				}, function(error){
	               $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
					
				}
			);
		};
		
		
		$scope.ligaFolioUnico = function(){
			var r = {
					idSolicitud: "20170329173216173216523918",
					numeroTarjeta: "4213646126064869",
					tipoUs: 1,
					folioGuardadito: "1546547895462132"
	    	};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.ligaFolioUnico(r).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var jResponse = JSON.parse(data.data.respuesta);
						
						if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){							
							$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.tazEntregada;
							generalService.locationPath("/surtimiento");
							
						}else
							$rootScope.message("Ligar Tarjeta", [ ERROR_SERVICE, "Error "+jResponse.codigo],"Aceptar",null,"bgCafeZ", "cafeZ");
												
					}else
						$rootScope.message("Error", [ERROR_SERVICE],"Aceptar",null,"bgCafeZ", "cafeZ");
				}, function(error){
	               $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
					
				}
			);
		};
		
		
		$scope.getSolicitudes = function(){			
									
			if( !generalService.isProduccion() ){
				$rootScope.waitLoaderStatus = LOADER_SHOW; 						 
												
				solicitudService.getSolicitudesProceso().then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == undefined)
							validateService.error(data);
						
						else if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var response = JSON.parse(data.data.respuesta);
							$scope.solicitudes = response.data;																						
						}
						
					}, function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;																				
					}
				);
				
			}else
				$("#moduloDigi").html("<div align='center'><H1>EXAMPLE HTML</H1></div>");
			
			
		};
		
		
		$scope.dispersionTarjeta = function(){			
			
			
				$rootScope.waitLoaderStatus = LOADER_SHOW; 						 
												
				solicitudService.dispersionTarjeta({idSolicitud:$rootScope.solicitudJson.idSolicitud}).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							
							alert("OK "+data.data.respuesta);																						
						}else
							alert("error "+data.data.descripcion);
						
					}, function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;																				
					}
				);
							
			
			
		};
		
		$scope.liberarSinTAZ = function(){			
			
			
			$rootScope.waitLoaderStatus = LOADER_SHOW; 						 
											
			callCenterService.liberarPedidoSinTAZ({idSolicitud:$rootScope.solicitudJson.idSolicitud}).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var respuesta = JSON.parse(data.data.respuesta);
						if(respuesta.codigo == 2){
							$rootScope.solicitudJson = respuesta.data;
							alert("OK "+data.data.respuesta);
							alert("JSON "+$rootScope.solicitudJson);
							
						}else
							$rootScope.message("Liberar Pedido Sin TAZ CallCenter",[ respuesta.descripcion],"Aceptar");
						
					} else 
						$rootScope.message("Ocho Pasos",[ERROR_SERVICE], "Aceptar", null, null, null);
					
					
					
				}, function(error){
					$rootScope.waitLoaderStatus = LOADER_HIDE;																				
				}
			);
						
		
		
	};
		
		
		$scope.convert = function(){
			var canvas = document.getElementById('new_canvas')
			//var canvas = document.getElementById('firmaCanvas')
			
			var ctx = canvas.getContext('2d');
			var img = new Image();
			img = document.getElementById("l-g");
			ctx.drawImage(img,0,0);		
			var imgData = canvas.toDataURL("image/png");		
			
			$scope.showcadenaimg = true;
			$("#imgId").html(imgData);
			$scope.imgB64 = imgData;
		};
						
		
		
		
		$scope.getSolicitud = function(){		
			
			
											
			imgDocumento[IDENTIFICACION_OFICIAL.id] = {imgB64:null, width:null, height:null};
			imgDocumento[COMP_DOMICILIO.id] = {imgB64:null, width:null, height:null};
			imgDocumento[COMP_INGRESOS.id] = {imgB64:null, width:null, height:null};
			imgDocumento[COMP_PROPIEDAD.id] = {imgB64:null, width:null, height:null};
			imgDocumento[IDENTIFICACION_OFICIAL_AVAL.id] = {imgB64:null, width:null, height:null};
			imgDocumento[COMP_DOMICILIO_AVAL.id] = {imgB64:null, width:null, height:null};
			imgDocumento[COMP_INGRESOS_AVAL.id] = {imgB64:null, width:null, height:null};
			imgDocumento[COMP_PROPIEDAD_AVAL.id] = {imgB64:null, width:null, height:null};
						
			generalService.buildSolicitudJson($rootScope, $rootScope.solicitudJson);						
			$rootScope.waitLoaderStatus = LOADER_SHOW; 						 										
			
			solicitudService.getSolicitud( $scope.solId ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == undefined)
						validateService.error(data);
					
					else if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						
						if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							$rootScope.solicitudJson = j.data;						
							generalService.locationPath("/ochoPasos");
						
						}else if(j.codigo == RESPONSE_CODIGO_ERROR_ID){
							alert(j.descripcion);
						}
						
					}else
						alert(data.data.descripcion);
					
				}, function(error){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					validateService.error(error);																				
				}
			);
		};
		
		
		$scope.objSelected = function(selected) {			
			$scope.solId = selected.originalObject.idSolicitud;
			$scope.getSolicitud();
		};
				
		
		$scope.saveSolicitud = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			angular.forEach( $rootScope.solicitudJson.documentos.documento, function(doc){																																	
				if( doc.idDocumento == '2')
					doc.status = STATUS_ENCOLADO_IPAD;														
			});

			var solicRequest = {
					solicitudJson: JSON.stringify($rootScope.solicitudJson),
					seccion: SECCION_DOCUMENTOS
			};
						
			
			solicitudService.saveSolicitud( solicRequest ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						modalService.alertModal("OK "+j.codigo, [j.descripcion]);
					}else if(data.data.codigo == PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
						var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
						$rootScope.message("Aviso ", [data.data.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
					}else
						alert(data.data.descripcion);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		};
		
				
		
		$scope.homonimos = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var x = {
					solicitudJson: JSON.stringify($rootScope.solicitudJson),
					//huella: "",
					tipoBusqueda: "1"
			}
			clienteUnicoService.getHomonimos( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){													
						modalService.alertModal("", [JSON.stringify(data.data.respuesta)]);						
					}else
						alert(data.data.descripcion);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		}
		
		$scope.getCU = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			var x = {
					solicitudJson: JSON.stringify($rootScope.solicitudJson),
					opcion: 3
			}
			
			clienteUnicoService.getCU( x ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);							
							modalService.alertModal("OK "+j.codigo,[j.descripcion]);
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                modalService.alertModal("Error "+error.status, [error.statusText]);							
					}
				);
			
//			var i=0;
//			var timer = $interval(function(){
//				clienteUnicoService.getCU( x ).then(
//						function(data){//							
//							console.log("ejecuxion exitosa "+i);
//							i++;
//							
//							if(i > 10)
//								$interval.cancel(timer);
//							
//						}, function(error){
//			                console.log("ejecuxion con error "+i);	
//			                i++;
//			                if(i > 10)
//								$interval.cancel(timer);
//						}
//					);
//				
//		      },1000);						
			
			
		}
		
		
		$scope.getFOTO = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 						
			
			var biometrico = {
					//ruta: "/1/53/172/29195.b64",
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					width: 30
			};
			
			clienteUnicoService.getFoto( biometrico ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						$rootScope.fotoCte="data:image/png;base64,"+j.data
						
					}else
						alert(data.data.descripcion);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                validateService.error(error);
					
				}
			);
						
		};
				
		$scope.getHuellasCU = function(){
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			clienteUnicoService.getHuellasCU( { arrayCtesUnicos: ['1-53-172-29360','1-52-412-12','1-53-172-2365'] } ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var lstResponse = JSON.parse(data.data.respuesta);	
						modalService.alertModal("", ["se encontraron "+lstResponse.length+" coincidencias "]);
						
					}else
						modalService.alertModal("error", [data.data.descripcion]);
						
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                validateService.error(error);
					
				}
			);
		};
		
		$scope.setBiometrico = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 		
			
			var tipoCadenaF = "foto";  //cliente
//			var tipoCadenaF = "foto_aval";  //aval
			
			var foto = {
					idSolicitud: "20150909171704171705167196",
					cadena: $rootScope.imgUsuario,
					tipoCadena: tipoCadenaF
//					porcentaje: "25"
			};
			
			
			var tipoCadenaH = "huella";  //cliente
//			var tipoCadenaH = "huella_aval";  //aval
			
			var huella = {
					ruta: null,
					idSolicitud: "20150909171704171705167196",
					cadena: "1-1-sdfsdfsdfsd89sdfud78234rnfbt3454us34786238ejwi82364",
					tipoCadena: tipoCadenaH,
					porcentaje: "25"
			};
			
			clienteUnicoService.setBiometrico( huella ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						modalService.alertModal("OK "+j.codigo,[j.descripcion]);
					}else
						alert(data.data.descripcion);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                validateService.error(error);
					
				}
			);
						
		};
		
		
		$scope.getFolioCC = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var x = {
					solicitudJson: JSON.stringify($rootScope.solicitudJson),
					fotoImg: "fotoooooooooooooooooo",
					ifeFrenteImg: "ifefrente",
					ifeReversoImg: "ifereverso",
					coincidencias: '["1-53-365-3608","1-1-4737-239","1-1-4737-244","1-1-4737-267"]',
					ruta: 0
			}
			callCenterService.getFolio( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){						
						modalService.alertModal("OK ", [data.data.respuesta]);
					}else
						alert(data.data.descripcion);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		};
		
		
		$scope.buro = function(){			 								
			buroService.consultaBuro( "bgNaranja", "btn gris","btn naranja", "/example");														
		};
		
		
		$scope.agendaCita = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var x = {
					idSolicitud: '20151229121503121503861283',//$rootScope.solicitudJson.idSolicitud,
					idUsuario: '20150902190539244481',
					fecha: '10/09/2015',
					periodo: "45",
					empleado: '245745',
					idEmpleado: '245745'
			}
						
			
			solicitudService.agendaCita( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						modalService.alertModal("OK "+j.codigo, [j.descripcion]);
					}else
						modalService.alertModal("",[data.data.descripcion]);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		};
		
		
		
		$scope.agendaCitaBazDigital = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var x = {
					idSolicitud: '20151229121503121503861283',//$rootScope.solicitudJson.idSolicitud,					
					fecha: '10/09/2015',
					periodo: "45",
					empleado: '245745',
					idEmpleado: '245745'
			}
						
			
			bazDigitalService.agendarCita( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						modalService.alertModal("OK "+j.codigo, [j.descripcion]);
					}else
						modalService.alertModal("",[data.data.descripcion]);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		};
		
		
		$scope.liberarSolicitud = function(){						
			
//			$rootScope.solicitudJson.marca = 215;
//			$rootScope.solicitudJson.idSeguimiento = 6;
			solicitudService.liberarSolicitud( $rootScope.solicitudJson ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						modalService.alertModal("OK ", [data.data]);
						
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                modalService.alertModal("Error "+error.status, [error.statusText]);
						
					}
				);
		};
		
		
		
		$scope.digitalizarDoc = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 						
			
			var digitDocRequest = {
					idSolicitud: "20160216193135193135598068",
					extensionIMG: "jpg",
					imagenB64: $rootScope.imgUsuario,
					idDocumento: 1,
					consecutivoPersona: 0,
					porcentaje: "50"
			};
						
			
			documentosService.digitalizar( digitDocRequest ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						modalService.alertModal("OK "+j.codigo, [j.descripcion]);
					}else
						alert(data.data.descripcion);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
						
		};
		
		
		
		$scope.validaContratosDigitalizados = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 						
			
			var digitDocRequest = {
					jsonSolicitud: $rootScope.solicitudJson,					
			};
						
			
			documentosService.validaContratosDigitalizados( digitDocRequest ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						modalService.alertModal("OK "+j.codigo, [j.descripcion]);
					}else
						alert(data.data.descripcion);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
						
		};
		
		
		
		
		$scope.inputCode = {
				codeCelular:{
					code: null,
					success:null
				},									
				codeMail:{
					code: null,
					success:null
				},
				solicitudJson: $rootScope.solicitudJson
		}
		
		$scope.getCode = function(){
									
			var celular = { idDestino: 1, destino: $rootScope.solicitudJson.cotizacion.clientes[0].celular, celular: $rootScope.solicitudJson.cotizacion.clientes[0].celular, 
					        nombreCte:"NOMBRE", idSolicitud: $rootScope.solicitudJson.idSolicitud, tipoPersona: AVAL.id }	
			
			loginService.getCode( celular ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
														
							$rootScope.solicitudJson.codigoCelular = data.data.descripcion;
							$scope.inputCode.solicitudJson = $rootScope.solicitudJson; 
							modalService.alertModal("OK", ["El código esta en el log"]);
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                modalService.alertModal("Error "+error.status, [error.statusText]);
						
					}
				);
			
			var mail  = { idDestino: 2, destino: "destino@baz.com", celular: $rootScope.solicitudJson.cotizacion.clientes[0].celular, nombreCte:"NOMBRE", 
					      idSolicitud: $rootScope.solicitudJson.idSolicitud, tipoPersona: CLIENTE.id } //mail
			loginService.getCode( mail ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
																											
							$rootScope.solicitudJson.codigoCorreo = data.data.descripcion;		
							$scope.inputCode.solicitudJson = $rootScope.solicitudJson;
							modalService.alertModal("OK", ["El código esta en el log"]);
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                modalService.alertModal("Error "+error.status, [error.statusText]);
						
					}
				);
		};
		
		
		$scope.validateCode = function(){
			
			
			loginService.validateCode( $scope.inputCode ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
												
							var r = JSON.parse(data.data.respuesta);			  		
							modalService.alertModal("", ['Celular '+r.codeCelular.success,'Mail '+r.codeMail.success]);
						
						}else
							modalService.alertModal("Error",[data.data.descripcion]);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                modalService.alertModal("Error "+error.status, [error.statusText]);
						
					}
				);
		};
		
		
		$scope.buroInterno = function(){
			var input = {
					nombre: "LETICIA",
					paterno: "GOMEZ",
					materno: "PATIÑO",
					fechaNacimiento: "01/01/1977",
					pais: 1					
			}
																						
			
			buroService.consultaBuroInterno( input ).then(
					function(data){						
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							
							var j = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK "+j.codigo, [j.descripcion]);
						}else
							modalService.alertModal("",[data.data.descripcion]);
						
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                modalService.alertModal("Error "+error.status, [error.statusText]);
						
					}
				);
		};
		
		
		$scope.getImagesDoc = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 						
			
			var jsonRequest = {
					cuenta: '104101202395',
					idTipoDocto: "0",
					status: 1,
					opcion: 1					
			};
								
			
			documentosService.getImages( jsonRequest ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){												
										
						
						 
							$scope.pathImg = 'ImageServlet?url='+data.data.respuesta[0].urlDoc;
							$scope.pathImg1 = 'ImageServlet?url='+data.data.respuesta[1].urlDoc;
							
							
						
																								
					}else{
						$scope.pathImg = 'images/documentoNoEncontrado.png';
						$scope.pathImg1 = $scope.pathImg;
//						alert(data.data.descripcion);
						$rootScope.message("Error", ["Error en la respuesta del servicio para obtener las imágenes. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafeZ", "cafeZ");
					}
																
				}, function(error){
					$scope.pathImg = 'images/documentoNoEncontrado.png';
					$scope.pathImg1 = $scope.pathImg;
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		};
		
		
		
		
		$scope.getDatosAsesor = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 						
			
			var jsonRequest = {
					latitud: '19.139786',
					longitud: "99.136659",
					idSolicitud: '20151027131834131835302641'
			};
								
			
			solicitudService.getDatosAsesor( jsonRequest ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						
						modalService.alertModal("OK ", [JSON.stringify(data.data.respuesta)]);						
						
					}else
						alert(data.data.descripcion);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                validateService.error(error);
					
				}
			);
		};
		
		
		
		
		$scope.getFotoAsesor = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 												
								
			
			solicitudService.getFotoAsesor( { noCuenta: '47470106902583' } ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						
						modalService.alertModal("OK ", [JSON.stringify(data.data.respuesta)]);						
						
					}else
						alert(data.data.descripcion);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                validateService.error(error);
					
				}
			);
		};
		
		

	    $scope.getUser = function(){
	    	sessionService.userSession("bVnqRKmPs+lEFKN-GeiPUxEa").then(
					function(data){ //EXITO			                						
	                	if(data.data.codigo == RESPONSE_CODIGO_EXITO)	                		
	                		modalService.alertModal("OK ", [JSON.stringify(data.data.respuesta)]);	                				                		                				                					                				                		                			                
    				}, function(error){ //ERROR 				                					
    	                console.log(error);	 
    	                modalService.alertModal("Error "+error.status, [error.statusText]);
    				}
			);
	    } 
	    
	    
	    $scope.getHomonimosAval = function(){
	    	
	    	$rootScope.solicitudJson.avales[0].celular = "5548675945";
	    	//$rootScope.solicitudJson.avales[0].primerInser = 1; SI ES 0, se consultan lista negras > hoonimos y se generan codigos
	    	
	    	var x = {
	    			nombre: 'erick',
	    			paterno: 'barrera',
	    			materno: 'lopez',
	    			fechaNacimiento: '28/08/1993',
//	    			nombre: 'MAXIMINO',
//	    			paterno: 'JUAREZ',
//	    			materno: 'SANTIAGO',
//	    			fechaNacimiento: '24/05/1976',
	    			pais: "1",
	    			solicitud: JSON.stringify($rootScope.solicitudJson)
//	    			nombre: 'RAUL',
//	    			apellidoPaterno: 'NUÑEZ',
//	    			apellidoMaterno: 'MAGAÑA',
//	    			fechaNacimiento: '24/05/1976'
	    	};	
	    	
	    	clienteUnicoService.getHomonimosAval(x).then(
					function(data){ //EXITO			                
						console.log( JSON.parse(data.data.respuesta));
	                	if(data.data.codigo == RESPONSE_CODIGO_EXITO)	                		
	                		modalService.alertModal("OK ", [JSON.stringify(data.data.respuesta)]);
	                	else	
	                		modalService.alertModal("OK ", [JSON.stringify(data.data.descripcion)]);
	                			                		                				                					                				                		                			                
    				}, function(error){ //ERROR 				                					
    	                console.log(error);	 
    	                modalService.alertModal("Error "+error.status, [error.statusText]);
    				}
			);
	    }
	    
	    
	    
	    
	    
	    $scope.getFotoCU = function(){
	    	var x = {	    			
	    			pais: 1,
	    			canal: 1,
	    			sucursal: 4737,
	    			folio: 286,
	    			width: 50
	    	}
	    	clienteUnicoService.getFotoCU(x).then(
					function(data){ //EXITO			                						
	                	if(data.data.codigo == RESPONSE_CODIGO_EXITO){
	                		var resp = JSON.parse(data.data.respuesta)
	                		if( !generalService.isEmpty(resp.data))	                			
	                			modalService.alertModal("foto ", ["Tiene foto, ver en log"]);
	                		else
	                			modalService.alertModal("Foto ", ["No tiene foto"]);
	                	}else	                		
	                		modalService.alertModal("OK ", [JSON.stringify(data.data.respuesta)]);
	                		
	                		                			                		                				                					                				                		                			               
    				}, function(error){ //ERROR 				                					
    	                console.log(error);	 
    	                modalService.alertModal("Error "+error.status, [error.statusText]);
    				}
			);
	    }
	    
	    
	    
	    $scope.contratosDigitalizados = function(){
	    	
	    	documentosService.contratosDigitalizados( $rootScope.solicitudJson ).then(
					function(data){ //EXITO			                						
	                	if(data.data.codigo == RESPONSE_CODIGO_EXITO)	                		
	                		modalService.alertModal("OK ", [JSON.stringify(data.data.respuesta)]);
	                		
	                		                			                		                				                					                				                		                			               
    				}, function(error){ //ERROR 				                					
    	                console.log(error);	 
    	                modalService.alertModal("Error "+error.status, [error.statusText]);
    				}
			);
	    }
	    
	    
	    $scope.homonimosBsqFonetica = function(){
	    	$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var x = {
					tienda: 365,
					arrayCtesUnicos: ["1-5-5031-2808","1-53-172-29386"] 
			}
			clienteUnicoService.getHomonimosBsqFonetica( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						modalService.alertModal("OK "+j.codigo, [JSON.stringify(j.data)]);						
					}else
						alert(data.data.descripcion);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                validateService.error(error);
					
				}
			);
	    };
	    
	    
	    $scope.recuperaPuntoDeControl = function(){
	    	$rootScope.recuperarPuntoDeControl($scope.solicitudJson.idSolicitud, 'jsonSolicitud', 
	    			function(dataPC){	    		
	    				modalService.alertModal("datos recuperador del puntop de control ", [dataPC]);	    				
	    			}
	    	);	    
	    };
	    
	    
	    
	    $scope.resultadoConsultaBuro = function(){
	    	buroService.resultadoConsulta("20151211132422132422849078").then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK "+j.codigo, [JSON.stringify(j.data)]);						
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    
	    $scope.getMontosPlazos = function(){
	    	buroService.getMontosPlazos("20151211132422132422849078");
	    };
	    
	    
	    
	    $scope.setDiaPago = function(){
	    	var r = {
	    			idSolicitud: "20151212211032211032900549",
	    			dia: "MARTES"
	    	};
	    	solicitudService.setDiaPago(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = data.data.respuesta;
							modalService.alertModal("OK", [JSON.stringify(j.inventarioTazResponseJson),"code json sol: "+j.solicitudJson.codigo]);						
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    
	    
	    $scope.getStatusLCR = function(){ //1-1-673-11186
	    	var r = {
	    			pais: 1,
	    			canal: 1,
	    			sucursal: 673,
	    			folio: 11186
	    	};
	    	solicitudService.getStatusLCR(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK "+j.codigo, [JSON.stringify(j.data)]);						
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    
	    
	    $scope.activarTarjeta = function(){ 
	    	var r = {
	    			idSolicitud: "20150902190539190539731091",
	    			cu: {pais: 1,canal: 1,sucursal: 673,folio: 11186},
	    			numCteAlnova: "49729881",
	    			numTaz: "4213644099763211" 
//	    			nip: "4444"					//opcional	    			
	    	};
	    	tarjetaService.activaTazInstantanea(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK "+j.codigo, [JSON.stringify(j.data)]);						
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	   
	    
	    $scope.activarTarjetas = function(){ 
	    	var r = {
	    			idSolicitud: "20150902190539190539731091",	    			
	    			cu: {pais: 1,canal: 1,sucursal: 673,folio: 11186},
	    			numCteAlnova: "49729881",
	    			valeElectronico:{
	    				numTaz: "4213644099763211"
	    			},
	    			tarjetaAzteca:{
	    				numTaz: "4213644099763212"
//	        			nip: generalService.getArrayValue('nip')
	    			}    			
	    	};
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	tarjetaService.activarTarjetas(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO)							
							modalService.alertModal("OK ", [data.data.respuesta.valeElectronico,"",data.data.respuesta.tarjetaAzteca]);						
						else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    $scope.getCteAlnova = function(){ 
	    	
	    	tarjetaService.consultaCteAlnova("45945934").then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK "+j.codigo, [JSON.stringify(j.data)]);						
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    $scope.cambioNIP = function(){ 
	    	var r = {
	    			nip: "444SDe4tirbsNxnGvJUnnA==",
	    			numTaz: "4213644099763393"	    			
	    	};
	    	tarjetaService.cambioNIP(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK "+j.codigo, [JSON.stringify(j.data)]);						
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    $scope.getTarjeta = function(){ 
	    	var r = {
	    			numcta: "71131388878298",
	    			numcontrato: "",
	    			numTaz: "",
	    			opcion: "2"
	    	};
	    	tarjetaService.consultaTaz(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK "+j.codigo, [JSON.stringify(j.data)]);						
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    
	    $scope.consultaInventario = function(){ 
	    	var r = {sucursal: "0673",opcion: "01"};
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	tarjetaService.consultaInventario(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK "+j.codigo, [JSON.stringify(j.data)]);						
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    
	    $scope.ligarTarjeta = function(){ 
	    	var r = {
	    			idSolicitud: "20150902190539190539731091",
	    			numeroTarjeta: "4213644099763393",
	    			tipoTarjeta: 42,  //taz verde,    			
	    			cteUnico: "010106739651",
	    			cteAlnova: "49729881",
	    			ligarTarjeta: "true"    				    				    				    				    				    			
	    		};
	    	solicitudService.guardaTarjeta(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){							
							modalService.alertModal("OK "+data.data.codigo, [data.data.respuesta]);						
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    
	    
	    $scope.buscaTarjeta = function(){ 
	    	var r = {
	    			idSolicitud: "20160928123646123647151284",
	    			tipoTarjeta: 42
	    		};
	    	solicitudService.buscaTarjeta(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){							
							modalService.alertModal("OK "+data.data.codigo, [data.data.respuesta]);						
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    
	    
	    
	    $scope.validarDocumento = function(){ 
	    	var r = {
	    			idSolicitud: $rootScope.solicitudJson.idSolicitud,
	    			jsonDoc: JSON.stringify($rootScope.solicitudJson.documentos)
	    	};
	    	documentosService.validarDocumentos(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK "+j.codigo, [JSON.stringify(j.data)]);						
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    
	    
	    $scope.updSolicitudes = function(){
	    	var r = {
	    		    "solicitudes": [
	    		                    {
	    		                        "idSolicitud": "456789",
	    		                        "pais":  1,
	    		                        "canal": 5,
	    		                        "sucursal": 635,
	    		                        "statusSolicitud": 6,
	    		                        "idEmpleado": 277689,
	    		                        "observaciones": "Se autoriza la solicitud",
	    		                        "fechaRendicion": "22/12/2015 20:45:00"
	    		                    },
	    		                     {
	    		                        "idSolicitud": "147258",
	    		                        "pais":  1,
	    		                        "canal": 5,
	    		                        "sucursal": 635,
	    		                        "statusSolicitud": 6,
	    		                        "idEmpleado": 277689,
	    		                        "observaciones": "Se autoriza la solicitud",
	    		                        "fechaRendicion": "22/12/2015 20:45:00"
	    		                    }
	    		                ]
	    		            };
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	solicitudService.updateSolicitudes(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						data = data.data;
						if(data.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							
							modalService.alertModal("OK "+data.codigo, [data.descripcion]);						
						}else
							modalService.alertModal("Error", [data.descripcion]);			
							
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    
	    $scope.firmasContrato = function(){ 
	    	var r = {
	    			idSolicitud: $rootScope.solicitudJson.idSolicitud,
	    			firmaCliente: "FIRMADELCLIENTEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE"
	    			//firmaAval: "FIRMADELAVALLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL",
	    	};
	    	documentosService.firmasContrato(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){	
							var j = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK "+j.codigo, [j.descripcion]);						
						}else
							modalService.alertModal("ERROR "+data.data.codigo, [data.data.descripcion]);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    
	    $scope.pdf = function(){
	    	window.location = "src/viewsControllers/avisos/avisosPDF.jsp";	    		    	
	    };
	    
	    
	    $scope.dispersion = function(){ 
	    	var r = {
	    			idSolicitud: "20160104132936132936646440",
	    			numCuenta: "01276208591372988421"
	    	};
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	surtimientoService.dispersion(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){	
							var dispersionResponse = data.data.respuesta.jsonResponse;							
							modalService.alertModal("codigo "+dispersionResponse.codigo, [dispersionResponse.respuesta]);						
						}else
							modalService.alertModal("ERROR "+data.data.codigo, [data.data.descripcion]);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    
	    
	    
	    $scope.citasSolicitudes = function(){ 
	    	var r = {solicitudesArray: ["20160106173616173616694233","20160112102629102629859332"]};	    	
	    	
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	solicitudService.citasSolicitudes(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){								
							var jResponse = JSON.parse(data.data.respuesta);							
							modalService.alertModal("codigo "+jResponse.codigo, [JSON.stringify(jResponse.data)]);						
						}else
							modalService.alertModal("ERROR "+data.data.codigo, [data.data.descripcion]);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
		$scope.oferta = function(){
			
			var jsonOferta = {
				"dias": 300,
				"periodicidad": "semanal",
				"capPagoComp": 10200,
				"capPagoNoComp": 4088
			};
			
			modalService.ofertaModal( jsonOferta );
			
		};
	  		
		$scope.solicitudesAsesor = function(){ 
			
			//sin fechas
//	    	var r = {fechaInicial: null, fechaFinal: null};
	    	
	    	//con rango de fechas
	    	var r = {fechaInicial: "01/01/2000", fechaFinal: "01/01/2016"};
	    	
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	solicitudService.solicitudesAsesor(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){								
							var jResponse = JSON.parse(data.data.respuesta);							
							modalService.alertModal("codigo "+jResponse.codigo, [JSON.stringify(jResponse)]);						
						}else
							modalService.alertModal("ERROR "+data.data.codigo, [data.data.descripcion]);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    
	    
	    $scope.getLCRCU = function(){ 	    		    	
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	clienteUnicoService.getLCRCU( {clienteUnico:"1-28-973-12"} ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){								
							var jResponse = JSON.parse(data.data.respuesta);
							console.log( jResponse );
							modalService.alertModal("codigo "+jResponse.codigo, [JSON.stringify(jResponse.data)]);						
						}else{
							console.error( data );
							modalService.alertModal("ERROR "+data.data.codigo, [data.data.descripcion]);
						}
					}, function(error){
						console.error( data );
						console.error( error );
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 		                						
					}
				);
	    };
	    
	    	   
	    
	    $scope.datosPresupuesto = function(){ 	    		    	
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	solicitudService.datosPresupuesto( {idPresupuesto:71166666} ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){								
							var jResponse = JSON.parse(data.data.respuesta);							
							modalService.alertModal("codigo "+jResponse.codigo, [JSON.stringify(jResponse.data)]);						
						}else
							modalService.alertModal("ERROR "+data.data.codigo, [data.data.descripcion]);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 		                						
					}
				);
	    };
	    
	    
	    
	    $scope.consultaFolioCU = function(){ 	    		    	
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	clienteUnicoService.consultaFolioCU( {idSolicitud:"20160312569878987452365012"} ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){								
							var jResponse = JSON.parse(data.data.respuesta);							
							modalService.alertModal("codigo "+jResponse.codigo, [JSON.stringify(jResponse.data)]);						
						}else
							modalService.alertModal("ERROR "+data.data.codigo, [data.data.descripcion]);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 		                						
					}
				);
	    };
	       	
	    
	    $scope.generaSolicRechazada = function(){
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	solicitudService.generaSolicRechazada( {idSolicitud:"20160401212307212308064872"} ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){								
							var jResponse = JSON.parse(data.data.respuesta);							
							modalService.alertModal("codigo "+jResponse.codigo, [JSON.stringify(jResponse.data)]);						
						}else
							modalService.alertModal("ERROR "+data.data.codigo, [data.data.descripcion]);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 		                						
					}
				);
	    };
	    
	    
	    $scope.seguroVidamax = function(){
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	var req = {
	    			cu: "1-1-673-94281",
	    			aplicacion: 1,
	    			capacidadPago: 840,
	    			fechaNacimiento: "09/09/1987",
	    			iva: 16,
	    			plazo: 52,
	    			subArea: 1
	    			
	    	};
	    	tarjetaService.seguroVidamax( req ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){								
							var jResponse =data.data.respuesta;							
							modalService.alertModal("codigo "+jResponse.codigo, [JSON.stringify(jResponse)]);						
						}else
							modalService.alertModal("ERROR "+data.data.codigo, [data.data.descripcion]);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 		                						
					}
				);
	    };
	    
	    
	    $scope.seguroVidamaxUnificado = function(){
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	var req = {  
	    			   "tipoOferta":1,
	    			   "origen":4,
	    			   "cliente":{  
	    			      "pais":1,
	    			      "canal":9,
	    			      "sucursal":414,
	    			      "folio":"39507",
	    			      "capacidadPagoDisponible":31,
	    			      "fechaNacimiento":"1992-12-25"
	    			   },
	    			   "productoCredito":{  
	    			      "montoVenta":18240,
	    			      "productoId":24,
	    			      "periodo":1,
	    			      "plazo":80
	    			   },
	    			   "seguro":{  
	    			      "esPromocion":false,
	    			      "iva":0.16
	    			   },
	    			   "informacionBase":{  
	    			      "ws":"",
	    			      "usuario":76745,
	    			      "sucursal":414
	    			   }
	    			};
	    	solicitudService.segurovidamaxUnificado( req ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){								
							var jResponse =data.data.respuesta;							
							modalService.alertModal("codigo "+jResponse.codigo, [JSON.stringify(jResponse)]);						
						}else
							modalService.alertModal("ERROR "+data.data.codigo, [data.data.descripcion]);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 		                						
					}
				);
	    };
	    
	    $scope.getDatosLcr = function(opc){	    	
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	
	    	switch(opc){
	    	case 1:
	    		solicitudService.getDatosLcrAutorizada( {clienteUnico:"1-1-973-123456"} ).then(
						function(data){
							f(data);
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 		                						
						}
					);
	    		break;
	    	case 2:
	    		solicitudService.getDatosLcrBloqueada( {clienteUnico:"1-20-1699-2852"} ).then(
						function(data){
							f(data);
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 		                						
						}
					);
	    		break;
	    	}
	    	
	    	var f = function(data){
	    		$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(data.data.codigo == RESPONSE_CODIGO_EXITO){								
					var jResponse = JSON.parse(data.data.respuesta);							
					modalService.alertModal("codigo "+jResponse.codigo, [JSON.stringify(jResponse.data)]);						
				}else
					modalService.alertModal("ERROR "+data.data.codigo, [data.data.descripcion]);
				
	    	};
	    	
	    };
	    
		
	    $scope.consultaBuroAval = function(){
	    	var jsonAvalAprobado = {"idSolicitud":"20160407195605195605476717","idPais":1,"idCanal":28,"idSucursal":9421,"idSeguimiento":3,"tipoLevantamiento":2,"tipoSolicitud":8,"idProducto":24,"idEmpleado":241781,"direccionIp":"10.51.81.154","idPlataforma":1,"aceptaTerminos":1,"folioCallCenter":"","respuestaCallCenter":0,"marca":255,"capacidadPagoComprobable":340,"capacidadPagoNoComprobable":90,"envioCorreo":0,"codigoCorreo":"","envioCelular":1,"codigoCelular":"Hog6zUb2xHzSCx1KV9pIIw==","cantidadReenviosCelular":0,"cantidadReenviosCorreo":0,"promocionCorreo":1,"pedido":0,"pedidoSEG":0,"pedidoSAC":0,"idSolicitudTienda":0,"idSolicitudTiendaCredInm":0,"idCondicion":0,"idEstatusLCR":0,"idMotivoRechazo":0,"idMotivoBloqueo":0,"consultaBuro":1,"consultaMatriz":1,"clienteForaneoGuardado":0,"banderaIngresos":0,"banderaSolidario":0,"banderaCUDigitalizacion":0,"banderaEntregaTAZ":0,"banderaOCR":0,"banderaOfertaCP":0,"creditoInmediato":0,"tratamientoDatos":1,"transferenciaDatos":1,"existeCita":0,"aceptaConsultaBuro":1,"cotizacion":{"idCotizacion":"20160407195605105512","statusCotizacion":1,"fechaVigencia":"","montoTotal":2652,"idPeriodicidad":1,"periodicidad":"Semanal","idPlazo":1,"plazo":13,"pagoNormal":204,"pagoPuntual":184,"ultimoAbono":204,"idPresupuesto":0,"detallesCotizacion":[{"idDetalle":"20160407195605110175","enganche":0,"intereses":652,"monto":2000,"cantidad":1,"idProducto":"520004"}],"clientes":[{"idPersona":"20160407192730277719","nombre":"ROSARIO GUADALUPEI","apellidoPaterno":"RODRIGUEZ","apellidoMaterno":"NUÑES","apellidoCasada":"","idGenero":"F","genero":"FEMENINO","fechaNaciomiento":"13/08/1991","celular":"6727728727","email":"","idLugarNacimiento":9,"lugarNacimientoDes":"DISTRITO FEDERAL","idEstadoCivil":1,"estadoCivil":"SOLTERO (A)","curp":"RONR910813MDFDXS04","rfc":"RONR910813SB3","dni":"","clienteUnico":"","clienteTienda":"","clienteAlnova":"","foto":"2","huella":"2","idPuesto":6,"puestoDes":"AMA DE CASA","folioIdentificacion":"","fechaVigenciaIdentificacion":"","consecutivoPersona":0,"porcentaje":100,"bloqueado":0,"editable":0,"guardado":1,"domicilios":[{"idDomicilio":"20160407193017334343","calle":"INSURGENTES SUR","numeroExterior":"1500","numeroInterior":"","cp":"50000","colonia":"VICENTE GUERRERO","idDelegacion":106,"delegacion":"TOLUCA","idEstado":15,"estado":"MEXICO","telefono":"5552738392","domicilioActual":1,"idTipoVivienda":1,"tipoViviendaDes":"PROPIA","manzana":"","edificio":"","superManzana":"","lote":"","antiguedad":"01/08/2008","andador":"","porcentaje":100,"bloqueado":0,"editable":0,"guardado":1,"zonificacion":{"latitud":"18.01817651590142","longitud":"-94.54747957236492","referencia":"IDKDKDKD","calleDelante":"","calleAtras":"","calleIzquierda":"","calleDerecha":"","heading":"-83.25000000000001","pitch":"12.000000000000004","zoom":"1","fov":"90","idCuadrante":0,"idPais":0,"idZonaGeo":0}}],"ingresosEgresos":{"dependientesMayores":99,"dependientesMenores":99,"porcentaje":100,"bloqueado":0,"editable":0,"guardado":1,"flujoEfectivo":[{"idTipo":2,"tipoDes":"EGRESO","idConcepto":1,"conceptoDes":"LUZ","monto":0},{"idTipo":2,"tipoDes":"EGRESO","idConcepto":2,"conceptoDes":"AGUA","monto":0},{"idTipo":2,"tipoDes":"EGRESO","idConcepto":6,"conceptoDes":"TRANSPORTE","monto":0},{"idTipo":2,"tipoDes":"EGRESO","idConcepto":7,"conceptoDes":"TELEFONO","monto":0},{"idTipo":2,"tipoDes":"EGRESO","idConcepto":8,"conceptoDes":"GAS","monto":0},{"idTipo":2,"tipoDes":"EGRESO","idConcepto":9,"conceptoDes":"COMIDA","monto":10000}]},"datosEmpleo":[{"idEmpleo":"","nombreEmpresa":"","idGiro":0,"giro":"","ext":"","antiguedad":"","idPeriodicidad":0,"periodicidad":"","empleoActual":0,"porcentaje":0,"idProfesion":4,"profesion":"AMA DE CASA","idTipoPago":0,"tipoPago":"","bloqueado":1,"editable":0,"guardado":0,"domicilio":{"idDomicilio":"","calle":"","numeroExterior":"","numeroInterior":"","cp":"","colonia":"","idDelegacion":0,"delegacion":"","idEstado":0,"estado":"","telefono":""}}],"flujoEfectivo":[{"idTipo":1,"tipoDes":"INGRESO","idConcepto":3,"conceptoDes":"COMPROBABLES","monto":7000}]}]},"avales":[{"idPersona":"20160408113500894947","nombre":"DSFASDF","apellidoPaterno":"ASDFASD","apellidoMaterno":"FASDFASD","apellidoCasada":"","idGenero":"F","genero":"FEMENINO","fechaNaciomiento":"18/03/1986","celular":"5545402089","email":"","idLugarNacimiento":8,"lugarNacimientoDes":"CHIHUAHUA","idEstadoCivil":2,"estadoCivil":"CASADO (A)","curp":"AAFD860318MCHSSS00","rfc":"AAFD860318383","dni":"","idTipoAval":2,"tipoAvalDes":"PROPIEDAD","idTipoPropiedad":2,"tipoPropiedadDes":"TERRENO","clienteUnico":"","clienteTienda":"","clienteAlnova":"","foto":"2","huella":"2","porcentaje":100,"porcentajeBasico":100,"porcentajeContacto":100,"bloqueado":0,"editable":0,"guardado":0,"idParentesco":1,"parentescoDes":"MADRE","idPuesto":6,"puestoDes":"AMA DE CASA","presencial":1,"primerInser":1,"consecutivoPersona":0,"folioIdentificacion":"671761567517615","fechaVigenciaIdentificacion":"01/01/2032","idSeguimiento":0,"marca":0,"envioCorreo":0,"codigoCorreo":"","envioCelular":0,"codigoCelular":"2UT/9INfhm74+6NYY7mLIw==","codigosEnviados":1,"cantidadReenviosCelular":0,"cantidadReenviosCorreo":0,"idCondicion":0,"idMotivoRechazo":0,"idMotivoBloqueo":0,"consultaBuro":0,"consultaMatriz":0,"clienteForaneoGuardado":0,"existeCita":0,"aceptaConsultaBuro":1,"aceptaTerminos":1,"banderaOCR":0,"datosHogar":{"idDomicilio":"20160407195500969418","calle":"CALLLE TQTYQ","numeroExterior":"6262","numeroInterior":"","cp":"11111","colonia":"PAPALOTE MUSEO DEL NINO","idDelegacion":11,"delegacion":"MIGUEL HIDALGO","idEstado":9,"estado":"DISTRITO FEDERAL","telefono":"5634534534","domicilioActual":1,"idTipoVivienda":0,"tipoViviendaDes":"","manzana":"","edificio":"","superManzana":"","lote":"","antiguedad":"","andador":"","porcentaje":100,"bloqueado":0,"editable":0,"guardado":0,"zonificacion":{"latitud":"19.2972509","longitud":"-99.1853969","referencia":"SHJSNSJS","calleDelante":"","calleAtras":"","calleIzquierda":"","calleDerecha":"","heading":"0","pitch":"0","zoom":"1","fov":"90","idCuadrante":48,"idPais":1,"idZonaGeo":125}},"flujoEfectivo":[{"idTipo":1,"tipoDes":"INGRESO","idConcepto":3,"conceptoDes":"COMPROBABLES","monto":59000}]}],"referencias":{"porcentaje":100,"bloqueado":0,"editable":0,"guardado":1,"referencia":[{"idPersona":"20160407193322803407","nombre":"CESAR","apellidoPaterno":"COTNEJO","apellidoMaterno":"CORNEJO","apellidoCasada":"","idGenero":"","genero":"","fechaNaciomiento":"","celular":"3883838329","email":"","idLugarNacimiento":0,"lugarNacimientoDes":"","idEstadoCivil":0,"estadoCivil":"","curp":"","rfc":"","dni":"","idParentesco":5,"parentescoDes":"HIJO (A)","telefonoCasa":"8332929292"},{"idPersona":"20160407193322812378","nombre":"ARIEL","apellidoPaterno":"PESQUEIRA","apellidoMaterno":"VEGA","apellidoCasada":"","idGenero":"","genero":"","fechaNaciomiento":"","celular":"3883839393","email":"","idLugarNacimiento":0,"lugarNacimientoDes":"","idEstadoCivil":0,"estadoCivil":"","curp":"","rfc":"","dni":"","idParentesco":6,"parentescoDes":"ABUELO (A)","telefonoCasa":"7738383993"}]},"documentos":{"porcentaje":100,"bloqueado":0,"editable":0,"guardado":0,"documento":[{"idDocumento":"1","documentoDes":"Identificacion Oficial del Cliente","idTipoDocumento":0,"tipoDocumentoDes":"","fechaVigencia":"","status":7,"idTipoPersona":1,"idPersona":"20160407192730277719","consecutivoPersona":0,"idMotivoRechazo":0,"observacion":""},{"idDocumento":"2","documentoDes":"Comprobante de Domicilio del Cliente","idTipoDocumento":3,"tipoDocumentoDes":"telÃ¿Â¿Ã¿Â©fono","fechaVigencia":"07/03/2016","status":7,"idTipoPersona":1,"idPersona":"20160407192730277719","consecutivoPersona":0,"idMotivoRechazo":0,"observacion":""},{"idDocumento":"4","documentoDes":"Comprobante de Propiedad del Cliente","idTipoDocumento":0,"tipoDocumentoDes":"","fechaVigencia":"","status":7,"idTipoPersona":1,"idPersona":"20160407192730277719","consecutivoPersona":0,"idMotivoRechazo":0,"observacion":""},{"idDocumento":"3","documentoDes":"Comprobante de Ingresos del Cliente","idTipoDocumento":0,"tipoDocumentoDes":"","fechaVigencia":"","status":3,"idTipoPersona":1,"idPersona":"20160407192730277719","consecutivoPersona":0,"idMotivoRechazo":0,"observacion":""},{"idDocumento":"7","documentoDes":"Identificacion Oficial del Aval","idTipoDocumento":0,"tipoDocumentoDes":"","fechaVigencia":"","status":3,"idTipoPersona":3,"idPersona":"20160407195500947022","consecutivoPersona":0,"idMotivoRechazo":0,"observacion":""},{"idDocumento":"8","documentoDes":"Comprobante de Domicilio del Aval","idTipoDocumento":0,"tipoDocumentoDes":"","fechaVigencia":"","status":3,"idTipoPersona":3,"idPersona":"20160407195500947022","consecutivoPersona":0,"idMotivoRechazo":0,"observacion":""}]},"contratos":{"porcentaje":0,"bloqueado":0,"editable":0,"guardado":0,"contrato":[{"idContrato":"1","statusFirma":0,"idPersona":"","descripcion":"","idTipoPersona":0},{"idContrato":"2","statusFirma":0,"idPersona":"","descripcion":"","idTipoPersona":0}]},"lineaDeCredito":{"capacidadDePagoTotal":null,"capacidadDePagoOcupada":null,"capacidadDePagoDisponible":null,"siguientePago":null,"pagoAntesDe":"","bonificacion":null,"liquidarAhora":null,"tipoPago":""},"promocioCelular":1};
	    	var jsonAvalRechazado = {"idSolicitud":"20160407195605195605476717","idPais":1,"idCanal":28,"idSucursal":9421,"idSeguimiento":3,"tipoLevantamiento":2,"tipoSolicitud":8,"idProducto":24,"idEmpleado":241781,"direccionIp":"10.51.81.154","idPlataforma":1,"aceptaTerminos":1,"folioCallCenter":"","respuestaCallCenter":0,"marca":255,"capacidadPagoComprobable":340,"capacidadPagoNoComprobable":90,"envioCorreo":0,"codigoCorreo":"","envioCelular":1,"codigoCelular":"Hog6zUb2xHzSCx1KV9pIIw==","cantidadReenviosCelular":0,"cantidadReenviosCorreo":0,"promocionCorreo":1,"pedido":0,"pedidoSEG":0,"pedidoSAC":0,"idSolicitudTienda":0,"idSolicitudTiendaCredInm":0,"idCondicion":0,"idEstatusLCR":0,"idMotivoRechazo":0,"idMotivoBloqueo":0,"consultaBuro":1,"consultaMatriz":1,"clienteForaneoGuardado":0,"banderaIngresos":0,"banderaSolidario":0,"banderaCUDigitalizacion":0,"banderaEntregaTAZ":0,"banderaOCR":0,"banderaOfertaCP":0,"creditoInmediato":0,"tratamientoDatos":1,"transferenciaDatos":1,"existeCita":0,"aceptaConsultaBuro":1,"cotizacion":{"idCotizacion":"20160407195605105512","statusCotizacion":1,"fechaVigencia":"","montoTotal":2652,"idPeriodicidad":1,"periodicidad":"Semanal","idPlazo":1,"plazo":13,"pagoNormal":204,"pagoPuntual":184,"ultimoAbono":204,"idPresupuesto":0,"detallesCotizacion":[{"idDetalle":"20160407195605110175","enganche":0,"intereses":652,"monto":2000,"cantidad":1,"idProducto":"520004"}],"clientes":[{"idPersona":"20160407192730277719","nombre":"ROSARIO GUADALUPEI","apellidoPaterno":"RODRIGUEZ","apellidoMaterno":"NUÑES","apellidoCasada":"","idGenero":"F","genero":"FEMENINO","fechaNaciomiento":"13/08/1991","celular":"6727728727","email":"","idLugarNacimiento":9,"lugarNacimientoDes":"DISTRITO FEDERAL","idEstadoCivil":1,"estadoCivil":"SOLTERO (A)","curp":"RONR910813MDFDXS04","rfc":"RONR910813SB3","dni":"","clienteUnico":"","clienteTienda":"","clienteAlnova":"","foto":"2","huella":"2","idPuesto":6,"puestoDes":"AMA DE CASA","folioIdentificacion":"","fechaVigenciaIdentificacion":"","consecutivoPersona":0,"porcentaje":100,"bloqueado":0,"editable":0,"guardado":1,"domicilios":[{"idDomicilio":"20160407193017334343","calle":"INSURGENTES SUR","numeroExterior":"1500","numeroInterior":"","cp":"50000","colonia":"VICENTE GUERRERO","idDelegacion":106,"delegacion":"TOLUCA","idEstado":15,"estado":"MEXICO","telefono":"5552738392","domicilioActual":1,"idTipoVivienda":1,"tipoViviendaDes":"PROPIA","manzana":"","edificio":"","superManzana":"","lote":"","antiguedad":"01/08/2008","andador":"","porcentaje":100,"bloqueado":0,"editable":0,"guardado":1,"zonificacion":{"latitud":"18.01817651590142","longitud":"-94.54747957236492","referencia":"IDKDKDKD","calleDelante":"","calleAtras":"","calleIzquierda":"","calleDerecha":"","heading":"-83.25000000000001","pitch":"12.000000000000004","zoom":"1","fov":"90","idCuadrante":0,"idPais":0,"idZonaGeo":0}}],"ingresosEgresos":{"dependientesMayores":99,"dependientesMenores":99,"porcentaje":100,"bloqueado":0,"editable":0,"guardado":1,"flujoEfectivo":[{"idTipo":2,"tipoDes":"EGRESO","idConcepto":1,"conceptoDes":"LUZ","monto":0},{"idTipo":2,"tipoDes":"EGRESO","idConcepto":2,"conceptoDes":"AGUA","monto":0},{"idTipo":2,"tipoDes":"EGRESO","idConcepto":6,"conceptoDes":"TRANSPORTE","monto":0},{"idTipo":2,"tipoDes":"EGRESO","idConcepto":7,"conceptoDes":"TELEFONO","monto":0},{"idTipo":2,"tipoDes":"EGRESO","idConcepto":8,"conceptoDes":"GAS","monto":0},{"idTipo":2,"tipoDes":"EGRESO","idConcepto":9,"conceptoDes":"COMIDA","monto":10000}]},"datosEmpleo":[{"idEmpleo":"","nombreEmpresa":"","idGiro":0,"giro":"","ext":"","antiguedad":"","idPeriodicidad":0,"periodicidad":"","empleoActual":0,"porcentaje":0,"idProfesion":4,"profesion":"AMA DE CASA","idTipoPago":0,"tipoPago":"","bloqueado":1,"editable":0,"guardado":0,"domicilio":{"idDomicilio":"","calle":"","numeroExterior":"","numeroInterior":"","cp":"","colonia":"","idDelegacion":0,"delegacion":"","idEstado":0,"estado":"","telefono":""}}],"flujoEfectivo":[{"idTipo":1,"tipoDes":"INGRESO","idConcepto":3,"conceptoDes":"COMPROBABLES","monto":7000}]}]},"avales":[{"idPersona":"20160408113500894947","nombre":"MAURICIO","apellidoPaterno":"ASDFASD","apellidoMaterno":"FASDFASD","apellidoCasada":"","idGenero":"F","genero":"FEMENINO","fechaNaciomiento":"18/03/1986","celular":"5545402089","email":"","idLugarNacimiento":8,"lugarNacimientoDes":"CHIHUAHUA","idEstadoCivil":2,"estadoCivil":"CASADO (A)","curp":"AAFD860318MCHSSS00","rfc":"AAFD860318383","dni":"","idTipoAval":2,"tipoAvalDes":"PROPIEDAD","idTipoPropiedad":2,"tipoPropiedadDes":"TERRENO","clienteUnico":"","clienteTienda":"","clienteAlnova":"","foto":"2","huella":"2","porcentaje":100,"porcentajeBasico":100,"porcentajeContacto":100,"bloqueado":0,"editable":0,"guardado":0,"idParentesco":1,"parentescoDes":"MADRE","idPuesto":6,"puestoDes":"AMA DE CASA","presencial":1,"primerInser":1,"consecutivoPersona":0,"folioIdentificacion":"671761567517615","fechaVigenciaIdentificacion":"01/01/2032","idSeguimiento":0,"marca":0,"envioCorreo":0,"codigoCorreo":"","envioCelular":0,"codigoCelular":"2UT/9INfhm74+6NYY7mLIw==","codigosEnviados":1,"cantidadReenviosCelular":0,"cantidadReenviosCorreo":0,"idCondicion":0,"idMotivoRechazo":0,"idMotivoBloqueo":0,"consultaBuro":0,"consultaMatriz":0,"clienteForaneoGuardado":0,"existeCita":0,"aceptaConsultaBuro":1,"aceptaTerminos":1,"banderaOCR":0,"datosHogar":{"idDomicilio":"20160407195500969418","calle":"CALLLE TQTYQ","numeroExterior":"6262","numeroInterior":"","cp":"11111","colonia":"PAPALOTE MUSEO DEL NINO","idDelegacion":11,"delegacion":"MIGUEL HIDALGO","idEstado":9,"estado":"DISTRITO FEDERAL","telefono":"5634534534","domicilioActual":1,"idTipoVivienda":0,"tipoViviendaDes":"","manzana":"","edificio":"","superManzana":"","lote":"","antiguedad":"","andador":"","porcentaje":100,"bloqueado":0,"editable":0,"guardado":0,"zonificacion":{"latitud":"19.2972509","longitud":"-99.1853969","referencia":"SHJSNSJS","calleDelante":"","calleAtras":"","calleIzquierda":"","calleDerecha":"","heading":"0","pitch":"0","zoom":"1","fov":"90","idCuadrante":48,"idPais":1,"idZonaGeo":125}},"flujoEfectivo":[{"idTipo":1,"tipoDes":"INGRESO","idConcepto":3,"conceptoDes":"COMPROBABLES","monto":59000}]}],"referencias":{"porcentaje":100,"bloqueado":0,"editable":0,"guardado":1,"referencia":[{"idPersona":"20160407193322803407","nombre":"CESAR","apellidoPaterno":"COTNEJO","apellidoMaterno":"CORNEJO","apellidoCasada":"","idGenero":"","genero":"","fechaNaciomiento":"","celular":"3883838329","email":"","idLugarNacimiento":0,"lugarNacimientoDes":"","idEstadoCivil":0,"estadoCivil":"","curp":"","rfc":"","dni":"","idParentesco":5,"parentescoDes":"HIJO (A)","telefonoCasa":"8332929292"},{"idPersona":"20160407193322812378","nombre":"ARIEL","apellidoPaterno":"PESQUEIRA","apellidoMaterno":"VEGA","apellidoCasada":"","idGenero":"","genero":"","fechaNaciomiento":"","celular":"3883839393","email":"","idLugarNacimiento":0,"lugarNacimientoDes":"","idEstadoCivil":0,"estadoCivil":"","curp":"","rfc":"","dni":"","idParentesco":6,"parentescoDes":"ABUELO (A)","telefonoCasa":"7738383993"}]},"documentos":{"porcentaje":100,"bloqueado":0,"editable":0,"guardado":0,"documento":[{"idDocumento":"1","documentoDes":"Identificacion Oficial del Cliente","idTipoDocumento":0,"tipoDocumentoDes":"","fechaVigencia":"","status":7,"idTipoPersona":1,"idPersona":"20160407192730277719","consecutivoPersona":0,"idMotivoRechazo":0,"observacion":""},{"idDocumento":"2","documentoDes":"Comprobante de Domicilio del Cliente","idTipoDocumento":3,"tipoDocumentoDes":"telÃ¿Â¿Ã¿Â©fono","fechaVigencia":"07/03/2016","status":7,"idTipoPersona":1,"idPersona":"20160407192730277719","consecutivoPersona":0,"idMotivoRechazo":0,"observacion":""},{"idDocumento":"4","documentoDes":"Comprobante de Propiedad del Cliente","idTipoDocumento":0,"tipoDocumentoDes":"","fechaVigencia":"","status":7,"idTipoPersona":1,"idPersona":"20160407192730277719","consecutivoPersona":0,"idMotivoRechazo":0,"observacion":""},{"idDocumento":"3","documentoDes":"Comprobante de Ingresos del Cliente","idTipoDocumento":0,"tipoDocumentoDes":"","fechaVigencia":"","status":3,"idTipoPersona":1,"idPersona":"20160407192730277719","consecutivoPersona":0,"idMotivoRechazo":0,"observacion":""},{"idDocumento":"7","documentoDes":"Identificacion Oficial del Aval","idTipoDocumento":0,"tipoDocumentoDes":"","fechaVigencia":"","status":3,"idTipoPersona":3,"idPersona":"20160407195500947022","consecutivoPersona":0,"idMotivoRechazo":0,"observacion":""},{"idDocumento":"8","documentoDes":"Comprobante de Domicilio del Aval","idTipoDocumento":0,"tipoDocumentoDes":"","fechaVigencia":"","status":3,"idTipoPersona":3,"idPersona":"20160407195500947022","consecutivoPersona":0,"idMotivoRechazo":0,"observacion":""}]},"contratos":{"porcentaje":0,"bloqueado":0,"editable":0,"guardado":0,"contrato":[{"idContrato":"1","statusFirma":0,"idPersona":"","descripcion":"","idTipoPersona":0},{"idContrato":"2","statusFirma":0,"idPersona":"","descripcion":"","idTipoPersona":0}]},"lineaDeCredito":{"capacidadDePagoTotal":null,"capacidadDePagoOcupada":null,"capacidadDePagoDisponible":null,"siguientePago":null,"pagoAntesDe":"","bonificacion":null,"liquidarAhora":null,"tipoPago":""},"promocioCelular":1};
	    	
	    	var json = jsonAvalRechazado;
	    	
	    	var jsonRequest = {
	    		solicitud: json,
	    		consultaBuro: 1
	    	};
	    	
	    	buroService.consultaBuroAval( jsonRequest );
	    };
	    
	    $scope.loggerFront = function(){
	    	
	    	var json = {
	    		"string": "jajaja",
	    		"numerico": 1,
	    		"arreglo": ["1","11","111"],
	    		"obj":{
	    			"nombre": "pedro",
	    			"ap":"martinez"
	    		},
	    		"boleano": true,
	    		"flotante": 15.45,
	    	}
	    	
	    	
	    
	    	solicitudService.loggerFront( json ).then(
				function(data){
					f(data);
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 		                						
				}
			);
	    	
	    	var f = function(data){
	    		$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(data.data.codigo == RESPONSE_CODIGO_EXITO){								
					var jResponse = JSON.parse(data.data.respuesta);							
					modalService.alertModal("codigo "+jResponse.codigo, [JSON.stringify(jResponse)]);						
				}else
					modalService.alertModal("ERROR "+data.data.codigo, [data.data.descripcion]);
				
	    	};
	
	
	    	
	    };
	    
	    
	    
	    $scope.validarCIModatelas=function(){
	    	$rootScope.seConsultoBuro = true;
	    	$rootScope.solicitudJson.creditoInmediato = 1;
	    	
	    	if($rootScope.seConsultoBuro){
				
				if($rootScope.solicitudJson.creditoInmediato == 0){
					modalService.notificacionModatelasModal().then(
							function(exito){
								console.log("cancelar sol");
								solicitudService.cancelarSolicitud({idSolicitud:$rootScope.solicitudJson.idSolicitud});
								$scope.reiniciaCotizacion();															
							},function(error){								
								console.log("No hacer nada");								
							}
					 );
					
				}else{
					var cuerpoDlg=[
						           	"Infórmale a tu cliente que para autorizar su tarjeta será necesario una visita a su domicilio.",
						           	"De ser autorizado su crédito, obtendrá una tarjeta con un límite de crédito de $2,000 para comprar en Modatelas."
					];
					
					modalService.confirmModal("Notificación",cuerpoDlg, "Continuar", "No está interesado", "bgAzul", "btn azul", "btn gris" ).then(
							function(exito){
								console.log("cancelar sol");
								solicitudService.cancelarSolicitud({idSolicitud:$rootScope.solicitudJson.idSolicitud});
								$scope.reiniciaCotizacion();
																
							},function(error){
								console.log("No hacer nada");																			
							}
					 );
				}
					
				$rootScope.seConsultoBuro=null;
				
			}
			
		};
	    
		$scope.cifrarPrueba = function(){
			
			var json = { nombre: 'Sahir Omar Burciaga Sosa', curp:"BUSS881110HVZRSH04"}	
			
			loginService.cifrarPrueba ( json ).then(
					function(data){
						console.log(data);						
					}, function(error){
						console.log(data);						
					}
				);
		};
		
		
		$scope.getHuellasEmpleadosCU = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			var x = {
					numerosEmpleado: '857005'					
			}
			
			clienteUnicoService.getHuellasEmpleadosCU( x ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){								
							modalService.alertModal("OK ",[data.data.respuesta]);
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                modalService.alertModal("Error "+error.status, [error.statusText]);							
					}
				);									
		};
		
		
		$scope.setHuellaEmpleadoCU = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			var x = {
					  numeroEmpleado: '857005',
					  nombre: 'Eduardo',
					  apellidoPaterno: 'Ramirez',
					  apellidoMaterno: 'Chavarrua',
					  fechaNacimiento: '1983-05-01',
					  negocio: '1',
					  xmlHuellas: '<HuellasRequestDTO><HuellasOT><huellaOT><idHuella>7</idHuella><mano>2</mano><dedo>2</dedo><cadenaHuella>00F83201C82AE3735CC0413709AB717094145592C910B0A156DC6AF2546ADF5FB0011512A9DF68807F58C5119FA3078D5D152B455CE12ABC557C8DFD23DA2D03CB5E5E3D773E4C556DBC5DF9AD8882ECD1D9811405CA3D8F6E262165D5EABB99C8198F479260508F041CBC76C0E72DB1EE2D916A18CBC3252418B2D51DE1CBBC0FE7174CC4D5E31067EB82FE80FB1DC265A31D50F496FB4EEB636A5121E33882FCBC5442EB746FFF163E08114F4C56F80C4536A718C21B5ED9AB6D6CBFD541CFAA0A01DE747A61A572A3614DDB791E7DBD9E5AD44245FB5ABD0EE4A4B0CC294BEFB569A20C4B40C5D4201F299CC5DC7E515299DE19203192EDBE9F9589EF5133CA78F9EC736B04AAD37F3AB0C5B2B7E0D36A1FD3B3C985E063C8C1E7B7477962B4DC2BD8DA111E9769A869557A8B395B00CDC2B7DB396F00F83B01C82AE3735CC0413709AB71B09B1455927AAC22279E2B94168F9B4C0A3FF15FF36A8AF98D3AC73723668603597A6A1E58A6A7B497CC7D70DC7F6A1061AA807313BE0D99B549553DCCDF50AB4930FF730EFF0C9A868F81AF1DFF00B505B9AA164AB5D07295A128BE3416CAC83D83C1CD446239ED8DD9C6BE51C328D982921D4D91659B72CB0E0E2838CDA1BB056669ACF6EF7F3EF806FDE6A185BB975B57F8C8F3B826B5A2848C656CB66EA5C9C93ECA9878912F17B480E349766379F3714157EE74A56E35BF700210B7B02BEBED0F7695CBFE100461F25CD38C996C922B32B1B5D8FD55D2D2BD03C5C5125DB05E8CC290F9ED5981443000277E8B80EC754E9482DAD881635DAA13B6288539635C2C6A94FC8ECB73876318C7D85196E7D6BE9C4E6A457187126738DE54169AF7CD64898CBEAD61FE55D4980247BB126F00F83601C82AE3735CC0413709AB71F09614559202BB52AC1B4A873F90F05127FA5B15EC86F5848068EC72E733CF20C75C70AF80FABCF0D555FFB20C2186088F0B504622F83052BE6FA8C9438F807F93BC46D3C57CA7F679F33026AE0C1F97B4D93C7D4357758A67A375EA459CDFAEE7DA654C400A853B90706CC35F0CC017354FC0775DB16C42925F0ACC3067C483FDDF1E2E0A0C3137EFE96FDFDE0CF7BF936CE75ED6F3439FDEE612007DA24F081550910E867C81D45E63CED1C3DD7E0F36AF5415A8B0954596978BCE854ABF5750EB76CD98A65A6182169B61679A04115D0350FFCE13F8576441FEE9EE87440ACE68013A964B060BC1C7A83DC877B775AECE913FE441607B051FC8C7DE46BFFBA7B228F96D786A6B312EAE7CE6E1F64BF767983551D4C092F88EBE3BEBD6C6A7D4F92C1D08D3CD320847916F00E83201C82AE3735CC0413709AB713082145592177A9C33548BE60B30937A5184C569BBC465411D38B47BDCCAE9E8E8EF1F53003A83EF4F6B06201EE5A9E39AC32EB584F68E5D9E12CD7161FCCF6BD7AB27234DB4E9F53BA71C463F5A5D54173AA07D98E73359AD1F1197747AD58E2216FB8D0C04CC4C885FD23499FF1D6A9839754112C2B0784A2435FCEA40242F91606C56BCDEAA85028A976606B404AA7BB054DB194698C32F1C08CFD3685E137BCBC364CDF5AE3E6D65ECB50339FEA62304B24708B7F6A2F29B5CF9955A11F85D04C5F532FCE6D950E7B126702479152CF67FBB3249AE56A0CE3F79253E09CB4006238B20FFB80C113E152D30B1CE1472FC4F92A9C08C3E83BDC8510D5B6AE09349AE1EF7429C284175AE72A14CA7A44CC9B6CE38FC93EA7B65E848B4356CB39796AD8FAAC1EB6F0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000100000000000000000000000000000000000100000000000000D50000000000000000000100000000000000FF2D000000000000005300C5000000000000FC000080FF0F00C0FF0F00F0FF3F00F8FF3F00F8FF7F00FCFFFF00FEFFFF00FEFFFF01FEFFFF01FEFFFF01FFFFFF01FFFFFF03FFFFFF03FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF070000000000000050400BF813000000B000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000</cadenaHuella></huellaOT><huellaOT><idHuella>4</idHuella><mano>1</mano><dedo>2</dedo><cadenaHuella>00F85B01C82AE3735CC0413709AB7170A214559283B7683E414219E38FEE2B7985D83C333ADCE7C83DBB82C5C4E2D32142C002DEE0FA31C92378B1FA9379CF6C65B38A5D3EA4F1CFCD12A779A8C95FC6846553A2D69028484DCEF7915D669A42EE7CA3CC4CEC09C984D717368D39AE354A0A67FCBD7060085C9176D87785DD76523C743A659DAF8DE71C4B1FE24AE98EC6FE2B127FD723E1C914421C32842163439993FD0739EC76CDCE88B54123D3A71D58712B77CA43EBF4A9AE31AC6E2FB2421DF82AD84DA06BD58F81B68C6D094B418B6B013DE7A1CBB9AE713B31A5CAC6EF50CA5BA723B32CB67C25424BE4330CF8AFC9C0C2062FC12F9B24804A413202CEA321E5F330FC6CD6C262DBCDDAEFE56AFEA6CCCE9AC548EE5173BA4545E3F21AB1ECC9699E7B5DB0F1E559A1690AA52DFF1A3E43EE39790D6BEDE914E9B8FBC9623C3F6892B6B56064BED28BA57E068FA3B40228A7D1FA22678550EA5E596F00F86001C82AE3735CC0413709AB7130A2145592B05D0A2E31F809F402428B6C3DD0E434E79C67FAD8F2874BE535ED390B040EBB94F2D6032AE86BCA5381621A1A5E2136C68156D1AB2E6199967E457F77973267690827C849BB7FFCD64C63B65873759B0A90BAB892A8AC61D16FEEEABA949A16E30E84533D2AB79F47D446810923CBDC2257CE538CFDD7D79DA456FED2E7D97749CB80331A1B87894E0E82307ACC7D80BBECA4012EECE89189B00056E89D1D86F2C0F30096B9CC3B8470B0FB3CFF5EB6B853FEE629BE8D337572DB291BCA7D525FCC78B0BC84B2728BC63E7A7257C4B423165207090A0C733011E45231D4DFFF94B243A0D55BF09A1522C373FB0D64616597AE75D823C0E3F1C61617FC849760240D919E6135F3B658C832AAA8EC10E0DBEFCCAEFD2E5C6A9ACE2AE923D026725D9D6EADEE4E33D6FB08E9F661E38512FEE3AC4FCC10516EEAACD10AD4E976437C414B956E2CF1CDAAE26365F6D7D4FB6F00F85B01C82AE3735CC0413709AB71B0A2145592188A8361FD022FB711CB63E1D1DD6042EE363DC563CFEC58C245CAB568199ECBD891E618542BD1383B8F278B377CACF04EA567D69C23E6B51CC0A595F5AFB8ABE56AD84AD6FE41B709A332825DC4D38E8ED96A736E982319BBD6362E8A9B1B76ABEC3BCD198B03470ACB5AD51AD72E0BD901E24F4C18752D2C6D763BAFC51AEFEB5154F76376C597916B205633F476741744B0A43B947BF9BCB3DE76D6070775200638727C8651C088440E3BCC2CC477BE23C4D9304A15B418846E5ECA76B0628E7F6541AA56D7344AC0B9D4407777EE04CA81D7A0F5B7E848BF084704EA05B0C85C5C1183BA9E985448AA745490405F2499985BF06C8BF3228797C08324E5971A7B788DB88BD9EADE3C13B176FAA6E85D2DDF5F85983B6850CD1B01AAC30BD29F9D7E305C3D02D74AF111812A81CBF8E13C50DE8D99DB52B31D2702160776790AC9C3C7DC23FA935583196F00E85001C82AE3735CC0413709AB71308914559287BCE9CD09FCECFF763937462F199B5B2950CA88BDADBE5B00E9D4B90275EF70C8DF71945F053DC9A407D8007D8893C364B8EBCF45F1E0506B1DE6C243D225E38788394C6AA3BFBF04197D2D2BD06D2BAA540549ECEF12CE4E8FD0A3B6246DB458DB44E1C780E53C43C1397FEF6202DC18069449494AEB838BAD02661239653E971B3C24321F63B22779770FEE07EA7ABF92329E91A94B92F2483F42EC37F582C750AB38C12E49C6EDEEC502080F5A0737B63083EB046DFDF9713EF82D6B650300998C5EDEDA5CED763B12C1F7A3E2199E050BACF0678001C589AEF0114DB01E908A515255D2F203CD6A653C5748875C2BF49F417A29EE2BA5201A9A137D9DB39B73EA90DF0485172DF06BC0F9A4F445624A48C6A4358DF1677128D34A6858A43E9890A943CC1EB5938A19F60E4F8BAEE6FDB651F21BB45C2F642E80286F83876F0000000000010000A8000000002036000000000000005D00A000C0FFFF00F0FFFF01F8FFFF03F8FFFF03FCFFFF07FEFFFF07FEFFFF07FEFFFF07FEFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FFFFFF07FEFFFF03FEFFFF03FCFFFF01F0FF7F000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000080EE00000100070000008029</cadenaHuella></huellaOT></HuellasOT><HuellasPlatino><huellaPlatino><idHuella>7</idHuella><mano>2</mano><dedo>2</dedo><cadenaHuella>30820776308206DF048206A6308206A23034302F0201030201020410A6FA3B7933624C88B5F94214C007BC6C0410479D6AD1B9A811D2A7A70040339F131702030200000201010482066000F83201C82AE3735CC0413709AB717094145592C910B0A156DC6AF2546ADF5FB0011512A9DF68807F58C5119FA3078D5D152B455CE12ABC557C8DFD23DA2D03CB5E5E3D773E4C556DBC5DF9AD8882ECD1D9811405CA3D8F6E262165D5EABB99C8198F479260508F041CBC76C0E72DB1EE2D916A18CBC3252418B2D51DE1CBBC0FE7174CC4D5E31067EB82FE80FB1DC265A31D50F496FB4EEB636A5121E33882FCBC5442EB746FFF163E08114F4C56F80C4536A718C21B5ED9AB6D6CBFD541CFAA0A01DE747A61A572A3614DDB791E7DBD9E5AD44245FB5ABD0EE4A4B0CC294BEFB569A20C4B40C5D4201F299CC5DC7E515299DE19203192EDBE9F9589EF5133CA78F9EC736B04AAD37F3AB0C5B2B7E0D36A1FD3B3C985E063C8C1E7B7477962B4DC2BD8DA111E9769A869557A8B395B00CDC2B7DB396F00F83B01C82AE3735CC0413709AB71B09B1455927AAC22279E2B94168F9B4C0A3FF15FF36A8AF98D3AC73723668603597A6A1E58A6A7B497CC7D70DC7F6A1061AA807313BE0D99B549553DCCDF50AB4930FF730EFF0C9A868F81AF1DFF00B505B9AA164AB5D07295A128BE3416CAC83D83C1CD446239ED8DD9C6BE51C328D982921D4D91659B72CB0E0E2838CDA1BB056669ACF6EF7F3EF806FDE6A185BB975B57F8C8F3B826B5A2848C656CB66EA5C9C93ECA9878912F17B480E349766379F3714157EE74A56E35BF700210B7B02BEBED0F7695CBFE100461F25CD38C996C922B32B1B5D8FD55D2D2BD03C5C5125DB05E8CC290F9ED5981443000277E8B80EC754E9482DAD881635DAA13B6288539635C2C6A94FC8ECB73876318C7D85196E7D6BE9C4E6A457187126738DE54169AF7CD64898CBEAD61FE55D4980247BB126F00F83601C82AE3735CC0413709AB71F09614559202BB52AC1B4A873F90F05127FA5B15EC86F5848068EC72E733CF20C75C70AF80FABCF0D555FFB20C2186088F0B504622F83052BE6FA8C9438F807F93BC46D3C57CA7F679F33026AE0C1F97B4D93C7D4357758A67A375EA459CDFAEE7DA654C400A853B90706CC35F0CC017354FC0775DB16C42925F0ACC3067C483FDDF1E2E0A0C3137EFE96FDFDE0CF7BF936CE75ED6F3439FDEE612007DA24F081550910E867C81D45E63CED1C3DD7E0F36AF5415A8B0954596978BCE854ABF5750EB76CD98A65A6182169B61679A04115D0350FFCE13F8576441FEE9EE87440ACE68013A964B060BC1C7A83DC877B775AECE913FE441607B051FC8C7DE46BFFBA7B228F96D786A6B312EAE7CE6E1F64BF767983551D4C092F88EBE3BEBD6C6A7D4F92C1D08D3CD320847916F00E83201C82AE3735CC0413709AB713082145592177A9C33548BE60B30937A5184C569BBC465411D38B47BDCCAE9E8E8EF1F53003A83EF4F6B06201EE5A9E39AC32EB584F68E5D9E12CD7161FCCF6BD7AB27234DB4E9F53BA71C463F5A5D54173AA07D98E73359AD1F1197747AD58E2216FB8D0C04CC4C885FD23499FF1D6A9839754112C2B0784A2435FCEA40242F91606C56BCDEAA85028A976606B404AA7BB054DB194698C32F1C08CFD3685E137BCBC364CDF5AE3E6D65ECB50339FEA62304B24708B7F6A2F29B5CF9955A11F85D04C5F532FCE6D950E7B126702479152CF67FBB3249AE56A0CE3F79253E09CB4006238B20FFB80C113E152D30B1CE1472FC4F92A9C08C3E83BDC8510D5B6AE09349AE1EF7429C284175AE72A14CA7A44CC9B6CE38FC93EA7B65E848B4356CB39796AD8FAAC1EB6F0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000201000201000400031100AB5523C980E7473FA885619ED019316F031100A1C21100CAA111D28B020090270750C4170D3130303232333139353634375A300D06092A864886F70D0101040500038181000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000</cadenaHuella></huellaPlatino><huellaPlatino><idHuella>4</idHuella><mano>1</mano><dedo>2</dedo><cadenaHuella>30820776308206DF048206A6308206A23034302F0201030201020410A6FA3B7933624C88B5F94214C007BC6C0410479D6AD1B9A811D2A7A70040339F131702030200000201010482066000F85B01C82AE3735CC0413709AB7170A214559283B7683E414219E38FEE2B7985D83C333ADCE7C83DBB82C5C4E2D32142C002DEE0FA31C92378B1FA9379CF6C65B38A5D3EA4F1CFCD12A779A8C95FC6846553A2D69028484DCEF7915D669A42EE7CA3CC4CEC09C984D717368D39AE354A0A67FCBD7060085C9176D87785DD76523C743A659DAF8DE71C4B1FE24AE98EC6FE2B127FD723E1C914421C32842163439993FD0739EC76CDCE88B54123D3A71D58712B77CA43EBF4A9AE31AC6E2FB2421DF82AD84DA06BD58F81B68C6D094B418B6B013DE7A1CBB9AE713B31A5CAC6EF50CA5BA723B32CB67C25424BE4330CF8AFC9C0C2062FC12F9B24804A413202CEA321E5F330FC6CD6C262DBCDDAEFE56AFEA6CCCE9AC548EE5173BA4545E3F21AB1ECC9699E7B5DB0F1E559A1690AA52DFF1A3E43EE39790D6BEDE914E9B8FBC9623C3F6892B6B56064BED28BA57E068FA3B40228A7D1FA22678550EA5E596F00F86001C82AE3735CC0413709AB7130A2145592B05D0A2E31F809F402428B6C3DD0E434E79C67FAD8F2874BE535ED390B040EBB94F2D6032AE86BCA5381621A1A5E2136C68156D1AB2E6199967E457F77973267690827C849BB7FFCD64C63B65873759B0A90BAB892A8AC61D16FEEEABA949A16E30E84533D2AB79F47D446810923CBDC2257CE538CFDD7D79DA456FED2E7D97749CB80331A1B87894E0E82307ACC7D80BBECA4012EECE89189B00056E89D1D86F2C0F30096B9CC3B8470B0FB3CFF5EB6B853FEE629BE8D337572DB291BCA7D525FCC78B0BC84B2728BC63E7A7257C4B423165207090A0C733011E45231D4DFFF94B243A0D55BF09A1522C373FB0D64616597AE75D823C0E3F1C61617FC849760240D919E6135F3B658C832AAA8EC10E0DBEFCCAEFD2E5C6A9ACE2AE923D026725D9D6EADEE4E33D6FB08E9F661E38512FEE3AC4FCC10516EEAACD10AD4E976437C414B956E2CF1CDAAE26365F6D7D4FB6F00F85B01C82AE3735CC0413709AB71B0A2145592188A8361FD022FB711CB63E1D1DD6042EE363DC563CFEC58C245CAB568199ECBD891E618542BD1383B8F278B377CACF04EA567D69C23E6B51CC0A595F5AFB8ABE56AD84AD6FE41B709A332825DC4D38E8ED96A736E982319BBD6362E8A9B1B76ABEC3BCD198B03470ACB5AD51AD72E0BD901E24F4C18752D2C6D763BAFC51AEFEB5154F76376C597916B205633F476741744B0A43B947BF9BCB3DE76D6070775200638727C8651C088440E3BCC2CC477BE23C4D9304A15B418846E5ECA76B0628E7F6541AA56D7344AC0B9D4407777EE04CA81D7A0F5B7E848BF084704EA05B0C85C5C1183BA9E985448AA745490405F2499985BF06C8BF3228797C08324E5971A7B788DB88BD9EADE3C13B176FAA6E85D2DDF5F85983B6850CD1B01AAC30BD29F9D7E305C3D02D74AF111812A81CBF8E13C50DE8D99DB52B31D2702160776790AC9C3C7DC23FA935583196F00E85001C82AE3735CC0413709AB71308914559287BCE9CD09FCECFF763937462F199B5B2950CA88BDADBE5B00E9D4B90275EF70C8DF71945F053DC9A407D8007D8893C364B8EBCF45F1E0506B1DE6C243D225E38788394C6AA3BFBF04197D2D2BD06D2BAA540549ECEF12CE4E8FD0A3B6246DB458DB44E1C780E53C43C1397FEF6202DC18069449494AEB838BAD02661239653E971B3C24321F63B22779770FEE07EA7ABF92329E91A94B92F2483F42EC37F582C750AB38C12E49C6EDEEC502080F5A0737B63083EB046DFDF9713EF82D6B650300998C5EDEDA5CED763B12C1F7A3E2199E050BACF0678001C589AEF0114DB01E908A515255D2F203CD6A653C5748875C2BF49F417A29EE2BA5201A9A137D9DB39B73EA90DF0485172DF06BC0F9A4F445624A48C6A4358DF1677128D34A6858A43E9890A943CC1EB5938A19F60E4F8BAEE6FDB651F21BB45C2F642E80286F83876F00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000201000201000400031100AB5523C980E7473FA885619ED019316F031100A1C21100CAA111D28B020090270750C4170D3130303232333139353634375A300D06092A864886F70D0101040500038181000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000</cadenaHuella></huellaPlatino></HuellasPlatino><HuellasHom><huellaHom><tipoHuella>1</tipoHuella><idHuella>7</idHuella><mano>2</mano><dedo>2</dedo><CadenasHuellasHom><cadenaHuellaHom><tacto>1</tacto><cadenaHuella>464D52002032300000FE0033000000000100016800C500C5010001005625801800C05660401300D85960405C0134755E407400909E5D408300BD445A804100EE485A402F0068545A407D00EF9758406801108B58803201360B56404D0043A556408F00D89E56808A01407D5580950078465440260089A954409D00FE9953804A014E1952406D004D4B5140BC0105A05180BC01299351405501068C504097008EA04F800F00F3734F801A0148A74E40D0014B1E4D802C01504B4C805001232B4140DA0085A23F800F00A2543E8011009C543B40D1013A9D3940D601580D3940300116463840D80140523600470126653400F1014A693200D00062462D0000</cadenaHuella></cadenaHuellaHom></CadenasHuellasHom></huellaHom><huellaHom><tipoHuella>1</tipoHuella><idHuella>4</idHuella><mano>1</mano><dedo>2</dedo><CadenasHuellasHom><cadenaHuellaHom><tacto>1</tacto><cadenaHuella>464D520020323000011C0033000000000100016800C500C501000100562A808F00706A634028004F896240DD00B0715F405000C55A5D402F00CC005B80B300E20D5B40990097675980A300516B5980DB00DE115980C6004B7358401B008B4F56405300DDB255409700E10B55403C00783A54407400B80B54404200DB5A5440F300C1185180B300168B508072012D554F807A006E5E4F407700D7064F402F009F524E80DE004E7E4D40AD0026734D80D6001C8C4C809D0121AE4A809700FA02498053004EA24880420085484840C40102054640C1010F0046808600271B458014008F4C444093012AAE4240F10100043D40370084463A007C00423832000200783A31000200B1582F007C003C122E00B7000E3F2C00040081432C0000</cadenaHuella></cadenaHuellaHom></CadenasHuellasHom></huellaHom></HuellasHom></HuellasRequestDTO>'
					}
			
			clienteUnicoService.setHuellaEmpleadoCU( x ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){													
							modalService.alertModal("OK ",[JSON.stringify(data.data.respuesta)]);
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                modalService.alertModal("Error "+error.status, [error.statusText]);							
					}
				);									
		};
		
		
		
		$scope.consultasCtasPP = function(){ 
	    	var r = {
	    			clienteAlnova: "00178851",
	    			montoLC: 10000,
	    			montoLib: 0	    			
	    	};
	    	tarjetaService.consultasCtasPP(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK "+j.codigo, [JSON.stringify(j.data)]);						
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    $scope.consultaDatosCaratulaTDC = function() {
	    	let input = {
	    		idSolicitud: '20190529173813173813831726',
	    		tipoTarjeta: 'R1'
	    	};
	    	
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	
	    	let error = function() {
	    		modalService.alertModal("¡Ya bailó Bertha!", ['¡Se jodió la bicicleta, amigo!']);
	    	};
	    	
	    	tarjetaService.consultaDatosCaratulaTDC(input).then(
	    		function(success) {
	    			$rootScope.waitLoaderStatus = LOADER_HIDE;
	    			
	    			if (success.data.codigo == RESPONSE_CODIGO_EXITO) {
	    				var j = JSON.parse(success.data.respuesta);
	    				
	    				modalService.alertModal(
	    					"¡Éxito rotundo!", 
	    					[JSON.stringify(j.data)]
	    				);
	    				
	    				return;
	    			}
	    			
	    			error();
	    		}, function(unsuccess) {
	    			$rootScope.waitLoaderStatus = LOADER_HIDE;
	    			
	    			error();
	    		}
	    	); 
	    };
	    
	    $scope.actualizaProducto = function(){
	    	solicitudService.actualizaProducto({idSolicitud:"20160810115823115823771414", idProducto:22}).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK "+j.codigo, [JSON.stringify(j.data)]);						
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    
	    $scope.getCampania = function(){
	    	solicitudService.getCampania({x:"1"}).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK "+j.codigo, [JSON.stringify(j.data)]);						
						}else
							alert("Error en la respuesta del servicio para obtener la campaña. Por favor, reintente nuevamente.");
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };
	    
	    
	    
	    $scope.liberarPorCC = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var x = {
					solicitudJson: JSON.stringify($rootScope.solicitudJson),
					seccion: 9					
			}
			callCenterService.liberar( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){						
						modalService.alertModal("OK ", [data.data.respuesta]);
					}else
						alert(data.data.descripcion);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		};
		
	    $scope.dispersarTarjetasPorCC = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var x = {
					idSolicitud: "20160107205305205305488449",
					tipoPeticion: 1,
					idPlataforma: PLATAFORMA.BAZDIGITAL
			}
			callCenterService.dispersarTarjetas( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){						
						modalService.alertModal("OK ", [data.data.respuesta]);
					}else
						alert(data.data.descripcion);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		};
		
		$scope.actualizaMarca = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 

			var x = {
					jsonSolicitud: {
						"aceptaConsultaBuro":1,
						"idCanalAlnova":"1",
						"pedidoSAC":0,
						"banderaCUDigitalizacion":0,
						"documentos":{
						"porcentaje":0,
						"bloqueado":0,
						"documento":[
						],
						"editable":0,
						"guardado":0
						},
						"sistemaOperativo":"",
						"codigoCorreo":"",
						"pedidoSEG":0,
						"folioCallCenter":"",
						"idEstatusLCR":0,
						"origenSolicitud":0,
						"idMotivoBloqueo":0,
						"banderaOCR":1,
						"aceptaTerminos":1,
						"tipoDispersion":0,
						"tipoSolicitud":8,
						"terminal":"0CRQ",
						"idPais":1,
						"pedido":0,
						"banderaSeguro":0,
						"diaPago":"",
						"envioCorreo":0,
						"idEntidadAlnova":"0127",
						"transferenciaDatos":1,
						"idSolicitud":"",
						"idSeguimiento":3,
						"idSolicitudTienda":0,
						"banderaEntregaTAZ":0,
						"cantidadReenviosCorreo":0,
						"promocionCorreo":0,
						"creditoInmediato":0,
						"banderaIngresos":0,
						"capacidadPagoComprobable":0,
						"tratamientoDatos":1,
						"idEmpleado":196656,
						"cantidadReenviosCelular":0,
						"idSucursal":165,
						"envioCelular":0,
						"contratos":{
						"porcentaje":100,
						"bloqueado":0,
						"editable":0,
						"guardado":0,
						"contrato":[
						{
						"statusFirma":2,
						"descripcion":"Aviso De Privacidad",
						"idTipoPersona":1,
						"idContrato":"1",
						"idPersona":""
						},
						{
						"statusFirma":2,
						"descripcion":"BurÃ³ de CrÃ©dito",
						"idTipoPersona":1,
						"idContrato":"2",
						"idPersona":""
						},
						{
						"statusFirma":0,
						"descripcion":"Contrato y CarÃ¡tula de CrÃ©dito",
						"idTipoPersona":1,
						"idContrato":"3",
						"idPersona":""
						},
						{
						"statusFirma":0,
						"descripcion":"Solicitud de CrÃ©dito",
						"idTipoPersona":1,
						"idContrato":"4",
						"idPersona":""
						}
						]
						},
						"idCanal":1,
						"clienteForaneoGuardado":0,
						"lineaDeCredito":{
						"bonificacion":0,
						"tipoPago":"",
						"capacidadDePagoTotal":0,
						"pagoAntesDe":"",
						"capacidadDePagoOcupada":0,
						"siguientePago":0,
						"capacidadDePagoDisponible":0,
						"liquidarAhora":0
						},
						"promocionCelular":0,
						"cotizacion":{
						"clientes":[
						{
						"bloqueado":0,
						"consecutivoPersona":0,
						"idGenero":"M",
						"estadoCivil":"",
						"ingresosEgresos":{
						"bloqueado":0,
						"porcentaje":0,
						"dependientesMenores":null,
						"dependientesMayores":null,
						"flujoEfectivo":[
						],
						"editable":0,
						"guardado":0
						},
						"datosEmpleo":[
						{
						"bloqueado":1,
						"idEmpleo":"",
						"nombreEmpresa":"",
						"antiguedad":"",
						"antiguedadDes":"",
						"domicilio":{
						"numeroExterior":"",
						"estado":"",
						"cp":"",
						"idDomicilio":"",
						"idDelegacion":0,
						"numeroInterior":"",
						"telefono":"",
						"idEstado":0,
						"colonia":"",
						"calle":"",
						"delegacion":""
						},
						"idTipoPago":0,
						"editable":0,
						"ext":"",
						"porcentaje":0,
						"giro":"",
						"idProfesion":0,
						"tipoPago":"",
						"profesion":"",
						"idGiro":0,
						"periodicidad":"",
						"idAntiguedad":0,
						"empleoActual":0,
						"idPeriodicidad":0,
						"guardado":0
						}
						],
						"domicilios":[
						{
						"superManzana":"",
						"antiguedad":"",
						"bloqueado":0,
						"numeroInterior":"",
						"colonia":"",
						"porcentaje":0,
						"numeroExterior":"",
						"idTipoVivienda":0,
						"lote":"",
						"guardado":0,
						"antiguedadDes":"",
						"idDomicilio":"",
						"edificio":"",
						"domicilioActual":1,
						"telefono":"",
						"manzana":"",
						"andador":"",
						"editable":0,
						"zonificacion":{
						"calleIzquierda":"",
						"fov":"",
						"calleDelante":"",
						"zoom":"",
						"calleDerecha":"",
						"referencia":"",
						"idPais":0,
						"idCuadrante":0,
						"calleAtras":"",
						"latitud":"",
						"longitud":"",
						"pitch":"",
						"heading":"",
						"idZonaGeo":0
						},
						"estado":"",
						"cp":"01450",
						"idDelegacion":0,
						"idAntiguedad":0,
						"idEstado":0,
						"tipoViviendaDes":"",
						"calle":"PRIV NIOS HEROES 02",
						"delegacion":""
						}
						],
						"apellidoPaterno":"TINAJERO",
						"puestoCUDes":"",
						"apellidoCasada":"",
						"rfc":"",
						"idLugarNacimiento":9,
						"idPuestoSPCU":0,
						"porcentaje":0,
						"nombre":"MIGUEL AGUSTIN",
						"apellidoMaterno":"MEJIA",
						"flujoEfectivo":[
						],
						"curp":"",
						"idPersona":"",
						"dni":"",
						"guardado":0,
						"clienteAlnova":"",
						"idPuesto":-1,
						"idPuestoCU":0,
						"numCuenta":"",
						"huella":"",
						"bdmid":"",
						"lugarNacimientoDes":"DISTRITO FEDERAL",
						"idNacionalidad":0,
						"clienteUnico":"",
						"editable":0,
						"idTipoTrabajo":0,
						"nacionalidadDes":"",
						"fechaNaciomiento":"15\/12\/1955",
						"genero":"MASCULINO",
						"email":"",
						"puestoDes":"",
						"foto":"",
						"clienteTienda":"",
						"idEstadoCivil":0,
						"folioIdentificacion":"3480011278123",
						"tipoTrabajoDes":"",
						"fechaVigenciaIdentificacion":"31\/12\/2025",
						"celular":"5510477685"
						}
						],
						"idPresupuesto":0,
						"statusCotizacion":1,
						"fechaVigencia":"",
						"pagoNormal":0,
						"detallesCotizacion":[
						{
						"intereses":0,
						"idDetalle":"",
						"cantidad":0,
						"idProducto":"0",
						"enganche":0,
						"monto":0
						}
						],
						"idPlazo":52,
						"pagoPuntual":0,
						"periodicidad":"Semanal",
						"plazo":52,
						"ultimoAbono":0,
						"idPeriodicidad":1,
						"idCotizacion":"",
						"montoTotal":0
						},
						"banderaSolidario":0,
						"codigoCelular":"PUhgdr8uqBSFTYERDOnM+Q==",
						"idProducto":21,
						"respuestaCallCenter":0,
						"capacidadPagoNoComprobable":0,
						"idCondicion":0,
						"avales":[
						{
						"idTipoAval":0,
						"bloqueado":1,
						"aceptaConsultaBuro":0,
						"idGenero":"",
						"estadoCivil":"",
						"idTipoPropiedad":0,
						"codigoCorreo":"",
						"apellidoCasada":"",
						"idMotivoBloqueo":0,
						"tipoPropiedadDes":"",
						"banderaOCR":0,
						"aceptaTerminos":0,
						"primerInser":0,
						"curp":"",
						"flujoEfectivo":[
						],
						"idPersona":"",
						"envioCorreo":0,
						"presencial":0,
						"guardado":0,
						"idSeguimiento":0,
						"idPuesto":0,
						"cantidadReenviosCorreo":0,
						"idNacionalidad":0,
						"clienteUnico":"",
						"parentescoDes":"",
						"editable":0,
						"datosHogar":{
						"antiguedad":"",
						"superManzana":"",
						"bloqueado":0,
						"numeroInterior":"",
						"claseViviendaDes":"",
						"colonia":"",
						"porcentaje":0,
						"lote":"",
						"idTipoVivienda":0,
						"numeroExterior":"",
						"guardado":0,
						"antiguedadDes":"",
						"idDomicilio":"",
						"edificio":"",
						"domicilioActual":1,
						"telefono":"",
						"idClaseVivienda":0,
						"manzana":"",
						"andador":"",
						"editable":0,
						"zonificacion":{
						"calleIzquierda":"",
						"fov":"",
						"calleDelante":"",
						"zoom":"",
						"calleDerecha":"",
						"referencia":"",
						"idPais":0,
						"idCuadrante":0,
						"calleAtras":"",
						"latitud":"",
						"longitud":"",
						"pitch":"",
						"heading":"",
						"idZonaGeo":0
						},
						"estado":"",
						"cp":"",
						"idDelegacion":0,
						"idAntiguedad":0,
						"tipoViviendaDes":"",
						"idEstado":0,
						"calle":"",
						"delegacion":""
						},
						"nacionalidadDes":"",
						"email":"",
						"cantidadReenviosCelular":0,
						"envioCelular":0,
						"folioIdentificacion":"",
						"clienteForaneoGuardado":0,
						"fechaVigenciaIdentificacion":"",
						"celular":"",
						"consecutivoPersona":0,
						"tipoAvalDes":"",
						"codigoCelular":"",
						"apellidoPaterno":"",
						"idCondicion":0,
						"rfc":"",
						"idLugarNacimiento":0,
						"porcentajeContacto":0,
						"nombre":"",
						"porcentaje":0,
						"porcentajeBasico":0,
						"idMotivoRechazo":0,
						"apellidoMaterno":"",
						"dni":"",
						"idParentesco":0,
						"clienteAlnova":"",
						"huella":"",
						"lugarNacimientoDes":"",
						"consultaMatriz":0,
						"marca":0,
						"consultaBuro":0,
						"existeCita":0,
						"fechaNaciomiento":"",
						"genero":"",
						"puestoDes":"",
						"foto":"",
						"idEstadoCivil":0,
						"clienteTienda":""
						}
						],
						"pushId":"",
						"banderaPrueba":0,
						"idMotivoRechazo":0,
						"idSolicitudTiendaCredInm":0,
						"direccionIp":"10.53.37.59",
						"tipoLevantamiento":2,
						"consultaMatriz":0,
						"referencias":{
						"porcentaje":0,
						"bloqueado":0,
						"editable":0,
						"guardado":0,
						"referencia":[
						{
						"idParentesco":0,
						"lugarNacimientoDes":"",
						"idGenero":"",
						"estadoCivil":"",
						"telefonoCasa":"",
						"apellidoPaterno":"",
						"idNacionalidad":0,
						"parentescoDes":"",
						"apellidoCasada":"",
						"rfc":"",
						"idLugarNacimiento":0,
						"nombre":"",
						"nacionalidadDes":"",
						"fechaNaciomiento":"",
						"genero":"",
						"email":"",
						"apellidoMaterno":"",
						"curp":"",
						"idPersona":"",
						"idEstadoCivil":0,
						"dni":"",
						"celular":""
						},
						{
						"idParentesco":0,
						"lugarNacimientoDes":"",
						"idGenero":"",
						"estadoCivil":"",
						"telefonoCasa":"",
						"apellidoPaterno":"",
						"idNacionalidad":0,
						"parentescoDes":"",
						"apellidoCasada":"",
						"rfc":"",
						"idLugarNacimiento":0,
						"nombre":"",
						"nacionalidadDes":"",
						"fechaNaciomiento":"",
						"genero":"",
						"email":"",
						"apellidoMaterno":"",
						"curp":"",
						"idPersona":"",
						"idEstadoCivil":0,
						"dni":"",
						"celular":""
						}
						]
						},
						"marca":0,
						"consultaBuro":0,
						"seguroDeVida":{
						"clavePromocion":"",
						"opcionSeguro":0,
						"montoFinal":0,
						"abonoSeguro":0,
						"precioSeguro":0,
						"sobrePrecioSeguro":0,
						"montoInicial":0,
						"esDefault":0,
						"ultimoAbonoSeguro":0,
						"totalSeguro":0,
						"nombreSeguro":"",
						"idSeguro":"",
						"comisionVenta":0
						},
						"existeCita":0,
						"banderaOfertaCP":0,
						"idPlataforma":1,
						"preguntasInvestigacion":[
						{
						"idVecino":1,
						"idPregunta":"700",
						"respuestaDes":"",
						"preguntaDes":"Â¿Cual es el Nombre del Cliente?"
						},
						{
						"idVecino":1,
						"idPregunta":"713",
						"respuestaDes":"",
						"preguntaDes":"Â¿Es una persona de confianza?"
						}
						]
					},
					marca: 1021,
			}
			
			solicitudService.actualizaMarca( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){						
						modalService.alertModal("OK ", [data.data.respuesta]);
					}else
						alert(data.data.descripcion);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		};
		
		$scope.recuperaFirmas = function(){
			var x = {
					idSolicitud: "20170214170508170508867343"
			}
			documentosService.recuperaFirmas( x ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){						
							modalService.alertModal("OK ", [data.data.respuesta]);
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                modalService.alertModal("Error "+error.status, [error.statusText]);
						
					}
				);
		}
		
		$scope.solicitudModificada = function(){
			
//			imgDocumento[IDENTIFICACION_OFICIAL.id] = {imgB64:null, width:null, height:null};
//			imgDocumento[COMP_DOMICILIO.id] = {imgB64:null, width:null, height:null};
//			imgDocumento[COMP_INGRESOS.id] = {imgB64:null, width:null, height:null};
//			imgDocumento[COMP_PROPIEDAD.id] = {imgB64:null, width:null, height:null};
//			imgDocumento[IDENTIFICACION_OFICIAL_AVAL.id] = {imgB64:null, width:null, height:null};
//			imgDocumento[COMP_DOMICILIO_AVAL.id] = {imgB64:null, width:null, height:null};
//			imgDocumento[COMP_INGRESOS_AVAL.id] = {imgB64:null, width:null, height:null};
//			imgDocumento[COMP_PROPIEDAD_AVAL.id] = {imgB64:null, width:null, height:null};
			
//			generalService.buildSolicitudJson($rootScope, $rootScope.solicitudJson);					
			
			$rootScope.solicitudJson=
			{
					"idSolicitud" : "20170616162208162208952051",
					"idPais" : 1,
					"idCanal" : 1,
					"idSucursal" : 673,
					"idSeguimiento" : 3,
					"tipoLevantamiento" : 2,
					"tipoSolicitud" : 8,
					"idProducto" : 24,
					"idEmpleado" : 275246,
					"direccionIp" : "10.51.82.226",
					"idPlataforma" : 1,
					"aceptaTerminos" : 1,
					"folioCallCenter" : "",
					"respuestaCallCenter" : 0,
					"marca" : 255,
					"capacidadPagoComprobable" : 709,
					"capacidadPagoNoComprobable" : 290,
					"envioCorreo" : 0,
					"codigoCorreo" : "",
					"envioCelular" : 0,
					"codigoCelular" : "Hzr1U+x6YzAr+ohiSyG3+Q==",
					"cantidadReenviosCelular" : 0,
					"cantidadReenviosCorreo" : 0,
					"promocionCelular" : 0,
					"promocionCorreo" : 0,
					"pedido" : 0,
					"pedidoSEG" : 0,
					"pedidoSAC" : 0,
					"idSolicitudTienda" : 4546,
					"idSolicitudTiendaCredInm" : 0,
					"idCondicion" : "0",
					"idEstatusLCR" : 0,
					"idMotivoRechazo" : "0",
					"idMotivoBloqueo" : "0",
					"consultaBuro" : 1,
					"consultaMatriz" : 1,
					"clienteForaneoGuardado" : 0,
					"banderaPrueba" : 0,
					"banderaIngresos" : 1,
					"banderaSolidario" : 0,
					"banderaCUDigitalizacion" : 0,
					"banderaEntregaTAZ" : 0,
					"banderaOCR" : 0,
					"banderaOfertaCP" : 1,
					"banderaSeguro" : 0,
					"creditoInmediato" : 1,
					"tratamientoDatos" : 1,
					"transferenciaDatos" : 1,
					"existeCita" : 0,
					"aceptaConsultaBuro" : 1,
					"cotizacion" : {
						"idCotizacion" : "20160505113222830866",
						"statusCotizacion" : 1,
						"fechaVigencia" : "",
						"montoTotal" : 7566,
						"idPeriodicidad" : 1,
						"periodicidad" : "Semanal",
						"idPlazo" : 1,
						"plazo" : 26,
						"pagoNormal" : 291,
						"pagoPuntual" : 247,
						"ultimoAbono" : 291,
						"idPresupuesto" : 0,
						"detallesCotizacion" : [{
								"idDetalle" : "20160505113222836235",
								"enganche" : 0,
								"intereses" : 2566,
								"monto" : 5000,
								"cantidad" : 1,
								"idProducto" : "520010"
							}
						],
						"clientes" : [{
								"idPersona" : "20160505113222814406",
								"nombre" : "OMAR",
								"apellidoPaterno" : "LIBERACION",
								"apellidoMaterno" : "CREDITO DOS",
								"apellidoCasada" : "",
								"idGenero" : "M",
								"genero" : "MASCULINO",
								"fechaNaciomiento" : "10/11/1988",
								"celular" : "2281402375",
								"email" : "",
								"idLugarNacimiento" : 30,
								"lugarNacimientoDes" : "VERACRUZ",
								"idEstadoCivil" : 5,
								"estadoCivil" : "VIUDO (A)",
								"curp" : "LICO881110HVZBRM01",
								"rfc" : "LICO881110FZ2",
								"dni" : "",
								"clienteUnico" : "",
								"clienteTienda" : "",
								"clienteAlnova" : "",
								"foto" : "2",
								"huella" : "2",
								"idPuesto" : 5,
								"puestoDes" : "POR SU CUENTA",
								"folioIdentificacion" : "4664467755678",
								"fechaVigenciaIdentificacion" : "",
								"consecutivoPersona" : 0,
								"porcentaje" : 100,
								"bloqueado" : 0,
								"editable" : 0,
								"guardado" : 1,
								"domicilios" : [{
										"idDomicilio" : "20160505113457817364",
										"calle" : "20 DE NOVIEMBRE",
										"numeroExterior" : "180",
										"numeroInterior" : "",
										"cp" : "94330",
										"colonia" : "ESPINAL",
										"idDelegacion" : 118,
										"delegacion" : "ORIZABA",
										"idEstado" : 30,
										"estado" : "VERACRUZ",
										"telefono" : "7877878778",
										"domicilioActual" : 1,
										"idTipoVivienda" : 1,
										"tipoViviendaDes" : "PROPIA",
										"manzana" : "",
										"edificio" : "",
										"superManzana" : "",
										"lote" : "",
										"antiguedad" : "01/11/2008",
										"andador" : "",
										"porcentaje" : 100,
										"bloqueado" : 0,
										"editable" : 0,
										"guardado" : 1,
										"zonificacion" : {
											"latitud" : "18.86792084059424",
											"longitud" : "-97.09920727042612",
											"referencia" : "NINGUNO",
											"calleDelante" : "",
											"calleAtras" : "",
											"calleIzquierda" : "",
											"calleDerecha" : "",
											"heading" : "0",
											"pitch" : "0",
											"zoom" : "1",
											"fov" : "90",
											"idCuadrante" : 0,
											"idPais" : 0,
											"idZonaGeo" : 0
										}
									}
								],
								"ingresosEgresos" : {
									"dependientesMayores" : 3,
									"dependientesMenores" : 3,
									"porcentaje" : 100,
									"bloqueado" : 0,
									"editable" : 0,
									"guardado" : 1,
									"flujoEfectivo" : [{
											"idTipo" : 2,
											"tipoDes" : "EGRESO",
											"idConcepto" : 1,
											"conceptoDes" : "LUZ",
											"monto" : 33
										}, {
											"idTipo" : 2,
											"tipoDes" : "EGRESO",
											"idConcepto" : 2,
											"conceptoDes" : "AGUA",
											"monto" : 23
										}, {
											"idTipo" : 2,
											"tipoDes" : "EGRESO",
											"idConcepto" : 6,
											"conceptoDes" : "TRANSPORTE",
											"monto" : 23
										}, {
											"idTipo" : 2,
											"tipoDes" : "EGRESO",
											"idConcepto" : 7,
											"conceptoDes" : "TELEFONO",
											"monto" : 23
										}, {
											"idTipo" : 2,
											"tipoDes" : "EGRESO",
											"idConcepto" : 8,
											"conceptoDes" : "GAS",
											"monto" : 23
										}, {
											"idTipo" : 2,
											"tipoDes" : "EGRESO",
											"idConcepto" : 9,
											"conceptoDes" : "COMIDA",
											"monto" : 23
										}
									]
								},
								"datosEmpleo" : [{
										"idEmpleo" : "",
										"nombreEmpresa" : "",
										"idGiro" : 0,
										"giro" : "",
										"ext" : "",
										"antiguedad" : "",
										"idPeriodicidad" : 0,
										"periodicidad" : "",
										"empleoActual" : 0,
										"porcentaje" : 0,
										"idProfesion" : 3,
										"profesion" : "POR SU CUENTA",
										"idTipoPago" : 0,
										"tipoPago" : "",
										"bloqueado" : 1,
										"editable" : 0,
										"guardado" : 0,
										"domicilio" : {
											"idDomicilio" : "",
											"calle" : "",
											"numeroExterior" : "",
											"numeroInterior" : "",
											"cp" : "",
											"colonia" : "",
											"idDelegacion" : 0,
											"delegacion" : "",
											"idEstado" : 0,
											"estado" : "",
											"telefono" : ""
										}
									}
								],
								"flujoEfectivo" : [{
										"idTipo" : 1,
										"tipoDes" : "INGRESO",
										"idConcepto" : 3,
										"conceptoDes" : "COMPROBABLES",
										"monto" : 9580
									}
								]
							}
						]
					},
					"avales" : [{
							"idPersona" : "",
							"nombre" : "",
							"apellidoPaterno" : "",
							"apellidoMaterno" : "",
							"apellidoCasada" : "",
							"idGenero" : "",
							"genero" : "",
							"fechaNaciomiento" : "",
							"celular" : "",
							"email" : "",
							"idLugarNacimiento" : 0,
							"lugarNacimientoDes" : "",
							"idEstadoCivil" : 0,
							"estadoCivil" : "",
							"curp" : "",
							"rfc" : "",
							"dni" : "",
							"idTipoAval" : 0,
							"tipoAvalDes" : "",
							"idTipoPropiedad" : 0,
							"tipoPropiedadDes" : "",
							"clienteUnico" : "",
							"clienteTienda" : "",
							"clienteAlnova" : "",
							"foto" : "",
							"huella" : "",
							"porcentaje" : 0,
							"porcentajeBasico" : 0,
							"porcentajeContacto" : 0,
							"bloqueado" : 1,
							"editable" : 1,
							"guardado" : 0,
							"idParentesco" : 0,
							"parentescoDes" : "",
							"idPuesto" : 0,
							"puestoDes" : "",
							"presencial" : 0,
							"primerInser" : 0,
							"avalVinculado" : 0,
							"consecutivoPersona" : 0,
							"folioIdentificacion" : "",
							"fechaVigenciaIdentificacion" : "",
							"idSeguimiento" : 0,
							"marca" : 0,
							"envioCorreo" : 0,
							"codigoCorreo" : "",
							"envioCelular" : 0,
							"codigoCelular" : "",
							"codigosEnviados" : 0,
							"cantidadReenviosCelular" : 0,
							"cantidadReenviosCorreo" : 0,
							"idCondicion" : 0,
							"idMotivoRechazo" : 0,
							"idMotivoBloqueo" : 0,
							"consultaBuro" : 0,
							"consultaMatriz" : 0,
							"clienteForaneoGuardado" : 0,
							"existeCita" : 0,
							"aceptaConsultaBuro" : 0,
							"aceptaTerminos" : 0,
							"banderaOCR" : 0,
							"datosHogar" : {
								"idDomicilio" : "",
								"calle" : "",
								"numeroExterior" : "",
								"numeroInterior" : "",
								"cp" : "",
								"colonia" : "",
								"idDelegacion" : 0,
								"delegacion" : "",
								"idEstado" : 0,
								"estado" : "",
								"telefono" : "",
								"domicilioActual" : 1,
								"idTipoVivienda" : 0,
								"tipoViviendaDes" : "",
								"manzana" : "",
								"edificio" : "",
								"superManzana" : "",
								"lote" : "",
								"antiguedad" : "",
								"andador" : "",
								"porcentaje" : 0,
								"bloqueado" : 0,
								"editable" : 0,
								"guardado" : 0,
								"zonificacion" : {
									"latitud" : "",
									"longitud" : "",
									"referencia" : "",
									"calleDelante" : "",
									"calleAtras" : "",
									"calleIzquierda" : "",
									"calleDerecha" : "",
									"heading" : "",
									"pitch" : "",
									"zoom" : "",
									"fov" : "",
									"idCuadrante" : 0,
									"idPais" : 0,
									"idZonaGeo" : 0
								}
							},
							"flujoEfectivo" : []
						}
					],
					"referencias" : {
						"porcentaje" : 100,
						"bloqueado" : 0,
						"editable" : 0,
						"guardado" : 1,
						"referencia" : [{
								"idPersona" : "20160505114546167026",
								"nombre" : "REFERENCIA",
								"apellidoPaterno" : "PERTERNO",
								"apellidoMaterno" : "MATERNO",
								"apellidoCasada" : "",
								"idGenero" : "",
								"genero" : "",
								"fechaNaciomiento" : "",
								"celular" : "2121212121",
								"email" : "",
								"idLugarNacimiento" : 0,
								"lugarNacimientoDes" : "",
								"idEstadoCivil" : 0,
								"estadoCivil" : "",
								"curp" : "",
								"rfc" : "",
								"dni" : "",
								"idParentesco" : 2,
								"parentescoDes" : "PADRE",
								"telefonoCasa" : "2121212121"
							}, {
								"idPersona" : "20160505114546175739",
								"nombre" : "REFERENCIA",
								"apellidoPaterno" : "MATERNA",
								"apellidoMaterno" : "PATERNA",
								"apellidoCasada" : "",
								"idGenero" : "",
								"genero" : "",
								"fechaNaciomiento" : "",
								"celular" : "4343434343",
								"email" : "",
								"idLugarNacimiento" : 0,
								"lugarNacimientoDes" : "",
								"idEstadoCivil" : 0,
								"estadoCivil" : "",
								"curp" : "",
								"rfc" : "",
								"dni" : "",
								"idParentesco" : 9,
								"parentescoDes" : "PRIMO (A)",
								"telefonoCasa" : "4311341342"
							}
						]
					},
					"documentos" : {
						"porcentaje" : 100,
						"bloqueado" : 0,
						"editable" : 0,
						"guardado" : 0,
						"documento" : [{
								"idDocumento" : "1",
								"documentoDes" : "Identificacion Oficial del Cliente",
								"idTipoDocumento" : 1,
								"tipoDocumentoDes" : "CREDENCIAL DE ELECTOR (IFE/ INE)",
								"fechaVigencia" : "01/01/2018",
								"status" : 4,
								"idTipoPersona" : 1,
								"idPersona" : "20160505113222814406",
								"consecutivoPersona" : 0,
								"idMotivoRechazo" : 0,
								"observacion" : "",
								"cantidad" : 2
							}, {
								"idDocumento" : "2",
								"documentoDes" : "Comprobante de Domicilio del Cliente",
								"idTipoDocumento" : 3,
								"tipoDocumentoDes" : "TELEFONO",
								"fechaVigencia" : "14/04/2016",
								"status" : 4,
								"idTipoPersona" : 1,
								"idPersona" : "20160505113222814406",
								"consecutivoPersona" : 0,
								"idMotivoRechazo" : 0,
								"observacion" : "",
								"cantidad" : 1
							}, {
								"idDocumento" : "4",
								"documentoDes" : "Comprobante de Propiedad del Cliente",
								"idTipoDocumento" : 0,
								"tipoDocumentoDes" : "",
								"fechaVigencia" : "",
								"status" : 4,
								"idTipoPersona" : 1,
								"idPersona" : "20160505113222814406",
								"consecutivoPersona" : 0,
								"idMotivoRechazo" : 0,
								"observacion" : "",
								"cantidad" : 1
							}, {
								"idDocumento" : "3",
								"documentoDes" : "Comprobante de Ingresos del Cliente",
								"idTipoDocumento" : 0,
								"tipoDocumentoDes" : "",
								"fechaVigencia" : "",
								"status" : 4,
								"idTipoPersona" : 1,
								"idPersona" : "20160505113222814406",
								"consecutivoPersona" : 0,
								"idMotivoRechazo" : 0,
								"observacion" : "",
								"cantidad" : 1
							}
						]
					},
					"contratos" : {
						"porcentaje" : 100,
						"bloqueado" : 0,
						"editable" : 0,
						"guardado" : 0,
						"contrato" : [{
								"idContrato" : "1",
								"statusFirma" : 2,
								"idPersona" : "",
								"descripcion" : "Aviso de Privacidad",
								"idTipoPersona" : 1
							}, {
								"idContrato" : "2",
								"statusFirma" : 2,
								"idPersona" : "",
								"descripcion" : "BurÃ¿Â³ de CrÃ¿Â©dito",
								"idTipoPersona" : 1
							}, {
								"idContrato" : "3",
								"statusFirma" : 2,
								"idPersona" : "20160505113222814406",
								"descripcion" : "Contrato y CarÃ¿Â¡tula de CrÃ¿Â©dito",
								"idTipoPersona" : 1
							}, {
								"idContrato" : "4",
								"statusFirma" : 2,
								"idPersona" : "20160505113222814406",
								"descripcion" : "Solicitud de CrÃ¿Â©dito",
								"idTipoPersona" : 1
							}
						]
					},
					"lineaDeCredito" : {
						"capacidadDePagoTotal" : null,
						"capacidadDePagoOcupada" : null,
						"capacidadDePagoDisponible" : null,
						"siguientePago" : null,
						"pagoAntesDe" : "",
						"bonificacion" : null,
						"liquidarAhora" : null,
						"tipoPago" : ""
					},
					"seguroDeVida" : {
						"nombreSeguro" : "",
						"opcionSeguro" : 0,
						"idSeguro" : "",
						"precioSeguro" : 0,
						"sobrePrecioSeguro" : 0,
						"abonoSeguro" : 0,
						"ultimoAbonoSeguro" : 0,
						"totalSeguro" : 0,
						"clavePromocion" : "",
						"comisionVenta" : 0,
						"montoFinal" : 0,
						"montoInicial" : 0,
						"esDefault" : 0
					},
					"promocioCelular" : 0
				};
			
			var arrayPlazos = [{"monto":2000,"cpComprobable":[13,26,39,52],"cpNoComprobable":[13,26,39,52]},{"monto":2500,"cpComprobable":[39,52,13,26],"cpNoComprobable":[39,52,26]},{"monto":9000,"cpComprobable":[26,39,52,65,80,100],"cpNoComprobable":[65,80,100]},{"monto":9500,"cpComprobable":[26,39,52,65,80,100],"cpNoComprobable":[80,100]},{"monto":10000,"cpComprobable":[26,39,52,65,80,100],"cpNoComprobable":[80,100]},{"monto":10500,"cpComprobable":[26,39,52,65,80,100],"cpNoComprobable":[80,100]},{"monto":11000,"cpComprobable":[39,52,65,80,100],"cpNoComprobable":null},{"monto":11500,"cpComprobable":[39,52,65,80,100],"cpNoComprobable":null},{"monto":12000,"cpComprobable":[39,52,65,80,100],"cpNoComprobable":null},{"monto":3000,"cpComprobable":[13,26,39,52],"cpNoComprobable":[26,39,52]},{"monto":3500,"cpComprobable":[13,26,39,52,65,80],"cpNoComprobable":[26,39,52,65,80]},{"monto":4000,"cpComprobable":[13,26,39,52,65,80],"cpNoComprobable":[26,39,52,65,80]},{"monto":4500,"cpComprobable":[13,26,39,52,65,80],"cpNoComprobable":[26,39,52,65,80]},{"monto":5000,"cpComprobable":[13,26,39,52,65,80],"cpNoComprobable":[39,52,65,80]},{"monto":5500,"cpComprobable":[13,26,39,52,65,80,100],"cpNoComprobable":[39,52,65,80,100]},{"monto":6000,"cpComprobable":[26,39,52,65,80,100],"cpNoComprobable":[39,52,65,80,100]},{"monto":6500,"cpComprobable":[26,39,52,65,80,100],"cpNoComprobable":[39,52,65,80,100]},{"monto":7000,"cpComprobable":[26,39,52,65,80,100],"cpNoComprobable":[52,65,80,100]},{"monto":7500,"cpComprobable":[26,39,52,65,80,100],"cpNoComprobable":[52,65,80,100]},{"monto":8000,"cpComprobable":[26,39,52,65,80,100],"cpNoComprobable":[52,65,80,100]},{"monto":8500,"cpComprobable":[26,39,52,65,80,100],"cpNoComprobable":[65,80,100]}];
			
			generalService.setPlazos( $rootScope, arrayPlazos, 2 );
			
			generalService.locationPath( generalService.getPathSection($rootScope.solicitudJson,$rootScope.sucursalSession.idCanal) );
//			generalService.locationPath("/ochoPasos");
			
		};
		
		$scope.enviarMensaje = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var x = {
					celular: "5575185287",					
			}
			solicitudService.envioMensaje( x ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jsonresponse = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK ", [jsonresponse.descripcion]);
						}else
							alert(data.data.descripcion);
						
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                modalService.alertModal("Error "+error.status, [error.statusText]);
						
					}
				);
		}
		
		$scope.getSucursalBig = function() {
			$rootScope.waitLoaderStatus = LOADER_SHOW; 

			var x = {
					idPais: 1,
					idSucursal: 6318					
			}

			solicitudService.getSucursalBig(x).then(
					function(data) {

						$rootScope.waitLoaderStatus = LOADER_HIDE;

						if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
							var jsonresponse = JSON.parse(data.data.respuesta);
							
							modalService.alertModal("OK ", [data.data.respuesta]);
						} else {
							alert(data.data.descripcion);
						}

					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;

						modalService.alertModal("Error " + error.status, [error.statusText]);
					}
			);
		}
		
		$scope.enviarIngresosCompMayoresA20k = function() {
			$rootScope.waitLoaderStatus = LOADER_SHOW; 

			var x = "20170223130205130205722812"

			solicitudService.enviarIngresosCompMayoresA20k(x).then(
					function(data) {

						$rootScope.waitLoaderStatus = LOADER_HIDE;

						if(true) {							
							modalService.alertModal("OK ", "Respuesta correcta.");
						} else {
							alert(data.data.descripcion);
						}

					}, function(error) {}
			);
		}
		
			
		$scope.validaHuellaINE = function() {
			$rootScope.waitLoaderStatus = LOADER_SHOW; 

			var x = {
					ocr: 3761128389519,
					idSucursal: 6318,
					tipoBusqueda: 2,
					formatoHuella: "ansi",
					indiceDerecho: "077DC139-FEF5-477B-88C6-543BC422FD5B-1199-000001056217E803",
					indiceIzquierdo: "2A19EC7F-1206-4A28-A4B2-0C7BC482F6CE-1199-000001056217EA97",
			}

			clienteUnicoService.validaHuellaINE(x).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
							var jsonresponse = JSON.parse(data.data.respuesta);
							
							if(jsonresponse.codigo == 0){
								$rootScope.message("Exito", [jsonresponse.descripcion], "Aceptar");
							}else{
								$rootScope.message("Error", [jsonresponse.descripcion], "Aceptar");
							}
						} else {
							$rootScope.message("Error", ["Error en el Servicio de Cliente Único"], "Aceptar");
						}

					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Error", ["Error en el Servicio de Cliente Único"], "Aceptar");
					}
			);
		}
		
		//Agenda llamada para clientes verdes.
		$scope.agendarLlamadaClienteVerde = function(){			
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var x = {
					idSolicitud: "20170223130205130205722812",//$rootScope.solicitudJson.idSolicitud,					
					periodoCita: "1"
			};
						
			
			bazDigitalService.agendarLlamada( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == 2){
						var j = JSON.parse(data.data.respuesta);
						modalService.alertModal("OK "+j.codigo, [j.descripcion]);
					}else
						modalService.alertModal("",[data.data.respuesta]);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		};
		
		//Se agenda la llamada para clientes verdes y pertenecientes a Baz Digital.
		$scope.guardarHoraLlamadaBazDigital = function(){			
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var x = {
					idSolicitud: "20170223130205130205722812",//$rootScope.solicitudJson.idSolicitud,					
					periodoCita: "1"
			};
						
			
			bazDigitalService.agendaLlamadaBazDigital( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == 2){
						var j = JSON.parse(data.data.respuesta);
						modalService.alertModal("OK "+j.codigo, [j.descripcion]);
					}else
						modalService.alertModal("",[data.data.respuesta]);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		};
		
		$scope.actualizarSolicitud = function() {
			
			// Esta activación del spinner, ¿va o no va? 
			// $rootScope.waitLoaderStatus = LOADER_SHOW;
			$scope.solicitudModificada();
			// Se respalda la solicitud, para revertirla, una vez que se obtenga respuesta.
			var solicitud = $rootScope.solicitudJson;
			solicitud.marca = STATUS_SOLICITUD.generada.marca.huellasINERechazado;
			solicitud.huellaExistenteINE = "0";
				
			$rootScope.solicitudJson.huellaExistenteINE = "0";

			solicitudService.actualizarSolicitud(solicitud).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == 2) {
							var j = JSON.parse(data.data.respuesta);
							modalService.alertModal("OK "+j.codigo, [j.descripcion]);
						}else
							modalService.alertModal("",[data.data.respuesta]);
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE; 
		                modalService.alertModal("Error "+error.status, [error.statusText]);
					}
			);
		};
		
		$scope.consultaCP = function(){
			solicitudService.consultaCP( 14000 ).then(
		    		
					function( data ){
									
					
					}, function( error ){
						
					}
		
			);
		}
		
		$scope.consultaFuncionalidad = function() {
			$rootScope.waitLoaderStatus = LOADER_SHOW; 

			var x = {
					idPais: 1,
					idSucursal: 6318,
					idCanal: 1,
			}

			loginService.consultaFuncionalidad(x).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
							var jsonresponse = JSON.parse(data.data.respuesta);
							
							if(jsonresponse.codigo == 0){
								$rootScope.message("Exito", [jsonresponse.descripcion], "Aceptar");
							}else{
								$rootScope.message("Error", [jsonresponse.descripcion], "Aceptar");
							}
						} else {
							$rootScope.message("Error", ["Error en el Servicio de Cliente Único"], "Aceptar");
						}

					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Error", ["Error en el Servicio de Cliente Único"], "Aceptar");
					}
			);
		}
		
		/**
		 * Servicio que Testea la obtención de la bateria de preguntas
		 **/
		$scope.obtenerBateriaPreguntasRespuestas = function(){
			var json = {
					idSolicitud: "20170824115825115825561027"
			};
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			solicitudService.obtenerBateriaPreguntasRespuestas(json).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var jResponse = JSON.parse(data.data.respuesta);
						
						if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){							
							$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.tazEntregada;
							$rootScope.message("Exito", [jsonresponse.descripcion], "Aceptar");
						}else{
							$rootScope.message("Error", [ ERROR_SERVICE, "Error "+jResponse.codigo],"Aceptar",null,"bgCafeZ", "cafeZ");
						}					
					}else{
						$rootScope.message("Error", [ERROR_SERVICE],"Aceptar",null,"bgCafeZ", "cafeZ");
					}
				}, function(error){
	               $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
					
				}
			);
		};
		
		/**
		 * Servicio que Testea el guardado de la bateria de preguntas
		 **/
		$scope.guardarBateriaPreguntas = function(){
			var json = {
					idSolicitud: "20170824115825115825561027",
					jsonBateria:  {
						      "porcentaje": 5,
						      "bateriaPreguntas":       [
						                  {
						            "idPregunta": 23,
						            "descPregunta": "Esta pagando un crédito grupal a su nombre?",
						            "bloqueo": 0,
						            "tiempo": "",
						            "respuestas":             [
						                              {
						                  "idRespuesta": 1,
						                  "descRespuesta": "Sí",
						                  "isCorrecta": 0,
						                  "isSeleccionada": 0
						               },
						                              {
						                  "idRespuesta": 2,
						                  "descRespuesta": "No",
						                  "isCorrecta": 1,
						                  "isSeleccionada": 0
						               },
						                              {
						                  "idRespuesta": 3,
						                  "descRespuesta": "No sé",
						                  "isCorrecta": 0,
						                  "isSeleccionada": 0
						               }
						            ]
						         },
						                  {
						            "idPregunta": 22,
						            "descPregunta": "Esta pagando un crédito Personal que este a su nombre?",
						            "bloqueo": 0,
						            "tiempo": "",
						            "respuestas":             [
						                              {
						                  "idRespuesta": 1,
						                  "descRespuesta": "Sí",
						                  "isCorrecta": 0,
						                  "isSeleccionada": 0
						               },
						                              {
						                  "idRespuesta": 2,
						                  "descRespuesta": "No",
						                  "isCorrecta": 1,
						                  "isSeleccionada": 0
						               },
						                              {
						                  "idRespuesta": 3,
						                  "descRespuesta": "No sé",
						                  "isCorrecta": 0,
						                  "isSeleccionada": 0
						               }
						            ]
						         },
						                  {
						            "idPregunta": 21,
						            "descPregunta": "Esta pagando un crédito de auto que este a su nombre?",
						            "bloqueo": 0,
						            "tiempo": "",
						            "respuestas":             [
						                              {
						                  "idRespuesta": 1,
						                  "descRespuesta": "Sí",
						                  "isCorrecta": 0,
						                  "isSeleccionada": 0
						               },
						                              {
						                  "idRespuesta": 2,
						                  "descRespuesta": "No",
						                  "isCorrecta": 1,
						                  "isSeleccionada": 0
						               },
						                              {
						                  "idRespuesta": 3,
						                  "descRespuesta": "No sé",
						                  "isCorrecta": 0,
						                  "isSeleccionada": 0
						               }
						            ]
						         },
						                  {
						            "idPregunta": 20,
						            "descPregunta": "Esta pagando un crédito de casa que este a su nombre?",
						            "bloqueo": 0,
						            "tiempo": "",
						            "respuestas":             [
						                              {
						                  "idRespuesta": 1,
						                  "descRespuesta": "Sí",
						                  "isCorrecta": 0,
						                  "isSeleccionada": 0
						               },
						                              {
						                  "idRespuesta": 2,
						                  "descRespuesta": "No",
						                  "isCorrecta": 1,
						                  "isSeleccionada": 0
						               },
						                              {
						                  "idRespuesta": 3,
						                  "descRespuesta": "No sé",
						                  "isCorrecta": 0,
						                  "isSeleccionada": 0
						               }
						            ]
						         },
						                  {
						            "idPregunta": 19,
						            "descPregunta": "Esta pagando algún crédito?",
						            "bloqueo": 0,
						            "tiempo": "",
						            "respuestas":             [
						                              {
						                  "idRespuesta": 1,
						                  "descRespuesta": "Sí",
						                  "isCorrecta": 0,
						                  "isSeleccionada": 0
						               },
						                              {
						                  "idRespuesta": 2,
						                  "descRespuesta": "No",
						                  "isCorrecta": 1,
						                  "isSeleccionada": 0
						               },
						                              {
						                  "idRespuesta": 3,
						                  "descRespuesta": "No sé",
						                  "isCorrecta": 0,
						                  "isSeleccionada": 0
						               }
						            ]
						         },
						                  {
						            "idPregunta": 11,
						            "descPregunta": "Tiene tarjetas de Tiendas Comerciales, como Liverpool, Wall Mart, Sears, C&A, etc.?",
						            "bloqueo": 0,
						            "tiempo": "",
						            "respuestas":             [
						                              {
						                  "idRespuesta": 1,
						                  "descRespuesta": "Sí",
						                  "isCorrecta": 0,
						                  "isSeleccionada": 0
						               },
						                              {
						                  "idRespuesta": 2,
						                  "descRespuesta": "No",
						                  "isCorrecta": 1,
						                  "isSeleccionada": 0
						               },
						                              {
						                  "idRespuesta": 3,
						                  "descRespuesta": "No sé",
						                  "isCorrecta": 0,
						                  "isSeleccionada": 0
						               }
						            ]
						         }
						      ]
						   }

			};
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			solicitudService.guardarBateriaPreguntas(json).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var jResponse = JSON.parse(data.data.respuesta);
						
						if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){							
							$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.tazEntregada;
							$rootScope.message("Exito", [jResponse.descripcion], "Aceptar");
						}else{
							$rootScope.message("Error", [ ERROR_SERVICE, "Error "+jResponse.codigo],"Aceptar",null,"bgCafeZ", "cafeZ");
						}					
					}else{
						$rootScope.message("Error", [ERROR_SERVICE],"Aceptar",null,"bgCafeZ", "cafeZ");
					}
				}, function(error){
	               $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
					
				}
			);
		};
		
		$scope.consultaDomicilio = function() {
			$rootScope.waitLoaderStatus = LOADER_SHOW; 

			var x = "20170925162114162115277631";	

			solicitudService.consultaDomicilio(x).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
							var jsonresponse = JSON.parse(data.data.respuesta);
							
							if(jsonresponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								$rootScope.message("Exito",["Código: "+jsonresponse.codigo+" "+jsonresponse.descripcion], "Aceptar");
							}else{
								$rootScope.message("Error", [jsonresponse.data.message], "Aceptar");
							}
						} else {
							$rootScope.message("Error", [data.data.message], "Aceptar");
						}

					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
					}
			);
		}
		
		// Función para generar Aviso de Privacidad Rechazo RENAPO.
		$scope.generarAPRechazoRENAPO = function() {			
			var x = {
			  "jsonSolicitud": "{\"idSolicitud\":\"20160615174937174938144544\",\"idPais\":1,\"idCanal\":28,\"idSucursal\":9502,\"idCanalAlnova\":0,\"tipoSolicitud\":8,\"origenSolicitud\":0,\"idProducto\":21,\"tipoLevantamiento\":2,\"idPlataforma\":1,\"idSeguimiento\":6,\"marca\":217,\"idEmpleado\":186094,\"terminal\":\"\",\"direccionIp\":\"10.53.35.59\",\"idEntidadAlnova\":\"\",\"aceptaTerminos\":1,\"folioCallCenter\":\"\",\"respuestaCallCenter\":0,\"capacidadPagoComprobable\":450.0,\"capacidadPagoNoComprobable\":300.0,\"idColorNC\":0,\"envioCorreo\":0,\"codigoCorreo\":\"\",\"envioCelular\":1,\"codigoCelular\":\"9c8CB6hBVMKDO62p7sShPAu003du003d\",\"cantidadReenviosCelular\":0,\"cantidadReenviosCorreo\":0,\"promocionCelular\":0,\"promocionCorreo\":0,\"pedido\":0,\"pedidoSEG\":0,\"pedidoSAC\":0,\"tipoDispersion\":0,\"idSolicitudTienda\":9,\"idSolicitudTiendaCredInm\":10,\"idSolicitudTiendaReactivacion\":0,\"idCondicion\":\"0\",\"idEstatusLCR\":0,\"idMotivoRechazo\":\"0\",\"idMotivoBloqueo\":\"0\",\"consultaBuro\":1,\"consultaMatriz\":1,\"clienteForaneoGuardado\":1,\"banderaPrueba\":0,\"banderaIngresos\":0,\"banderaSolidario\":0,\"banderaCUDigitalizacion\":1,\"banderaEntregaTAZ\":0,\"banderaOCR\":1,\"banderaOfertaCP\":0,\"banderaSeguro\":0,\"creditoInmediato\":1,\"tratamientoDatos\":1,\"transferenciaDatos\":1,\"fechaCita\":\"\",\"empeladoCita\":\"\",\"periodoCita\":\"\",\"existeCita\":1,\"aceptaConsultaBuro\":1,\"diaPago\":\"VIERNES\",\"tipoBusqueda360\":0,\"respuesta360\":\"\",\"folioFlujoUnico\":\"\",\"campaniaDesc\":\"\",\"observaciones\":\"\",\"codSucCercana\":0,\"fechaPedido\":\"\",\"idColor\":0,\"idEmpleadoGerente\":\"\",\"diasRechazo\":0,\"tipoCampania\":0,\"huellaExistenteINE\":\"\",\"tipoDispositivo\":\"\",\"cotizacion\":{\"idCotizacion\":\"\",\"statusCotizacion\":1,\"fechaVigencia\":\"\",\"montoTotal\":0.0,\"idPeriodicidad\":1,\"periodicidad\":\"Semanal\",\"idPlazo\":0,\"plazo\":0,\"pagoNormal\":0.0,\"pagoPuntual\":0.0,\"ultimoAbono\":0.0,\"idPresupuesto\":0,\"detallesCotizacion\":[{\"idDetalle\":\"\",\"enganche\":0.0,\"intereses\":0.0,\"monto\":0.0,\"cantidad\":0.0,\"idProducto\":\"8\"}],\"clientes\":[{\"clienteUnico\":\"1-1-2024-55524\",\"clienteTienda\":\"1-9502-100033-6\",\"clienteAlnova\":\"38708169\",\"idBiometrico\":\"\",\"clienteADN\":\"\",\"numCuenta\":\"\",\"foto\":\"1\",\"huella\":\"1\",\"idPuesto\":5,\"puestoDes\":\"POR SU CUENTA\",\"idPuestoCU\":0,\"puestoCUDes\":\"\",\"idPuestoSPCU\":0,\"puestoSPCUDes\":\"\",\"idTipoTrabajo\":0,\"tipoTrabajoDes\":\"\",\"folioIdentificacion\":\"3016079379564\",\"claveElector\":\"\",\"fechaVigenciaIdentificacion\":\"01/01/2026\",\"consecutivoPersona\":0,\"porcentaje\":100,\"bloqueado\":0,\"editable\":1,\"guardado\":1,\"idTipoContacto\":0,\"domicilios\":[{\"domicilioActual\":1,\"idTipoVivienda\":2,\"tipoViviendaDes\":\"FAMILIAR\",\"manzana\":\"\",\"edificio\":\"\",\"superManzana\":\"\",\"lote\":\"\",\"antiguedad\":\"01/06/2012\",\"andador\":\"\",\"idAntiguedad\":0,\"antiguedadDes\":\"\",\"porcentaje\":100,\"bloqueado\":0,\"editable\":1,\"guardado\":1,\"zonificacion\":{\"latitud\":\"19.3220099\",\"longitud\":\"-99.29150340000001\",\"referencia\":\"ENTRE AHUAUTLA Y CAPULINES ENTRAR POR CAPAULINES DOMICILIO ESCALERAS HACIA ABAJO CERCA DE LA VIRGEN FACHADA AMARILLA PUERTA AZUL.\",\"calleDelante\":\"\",\"calleAtras\":\"\",\"calleIzquierda\":\"\",\"calleDerecha\":\"\",\"heading\":\"0\",\"pitch\":\"0\",\"zoom\":\"1\",\"fov\":\"90\",\"idCuadrante\":1,\"idPais\":1,\"idZonaGeo\":7795},\"idDomicilio\":\"20160615182142203876\",\"calle\":\"3RA CDA DE CAPULINES\",\"numeroExterior\":\"128 A\",\"numeroInterior\":\"\",\"cp\":\"10330\",\"colonia\":\"LAS CRUCES\",\"idDelegacion\":10,\"delegacion\":\"MAGDALENA CONTRERAS LA\",\"idEstado\":9,\"estado\":\"DISTRITO FEDERAL\",\"telefono\":\"5515204462\"}],\"ingresosEgresos\":{\"dependientesMayores\":0,\"dependientesMenores\":2,\"porcentaje\":100,\"bloqueado\":0,\"editable\":1,\"guardado\":1,\"flujoEfectivo\":[{\"idTipo\":2,\"tipoDes\":\"EGRESO\",\"idConcepto\":1,\"conceptoDes\":\"LUZ\",\"monto\":100.0},{\"idTipo\":2,\"tipoDes\":\"EGRESO\",\"idConcepto\":2,\"conceptoDes\":\"AGUA\",\"monto\":90.0},{\"idTipo\":2,\"tipoDes\":\"EGRESO\",\"idConcepto\":6,\"conceptoDes\":\"TRANSPORTE\",\"monto\":400.0},{\"idTipo\":2,\"tipoDes\":\"EGRESO\",\"idConcepto\":7,\"conceptoDes\":\"TELEFONO\",\"monto\":500.0},{\"idTipo\":2,\"tipoDes\":\"EGRESO\",\"idConcepto\":8,\"conceptoDes\":\"GAS\",\"monto\":100.0},{\"idTipo\":2,\"tipoDes\":\"EGRESO\",\"idConcepto\":9,\"conceptoDes\":\"COMIDA\",\"monto\":1500.0}]},\"datosEmpleo\":[{\"idEmpleo\":\"\",\"nombreEmpresa\":\"\",\"idGiro\":0,\"giro\":\"\",\"ext\":\"\",\"antiguedad\":\"\",\"idPeriodicidad\":0,\"periodicidad\":\"\",\"idAntiguedad\":0,\"antiguedadDes\":\"\",\"empleoActual\":0,\"porcentaje\":0,\"idProfesion\":3,\"profesion\":\"POR SU CUENTA\",\"idTipoPago\":0,\"tipoPago\":\"\",\"bloqueado\":1,\"editable\":1,\"guardado\":0,\"domicilio\":{\"idDomicilio\":\"\",\"calle\":\"\",\"numeroExterior\":\"\",\"numeroInterior\":\"\",\"cp\":\"\",\"colonia\":\"\",\"idDelegacion\":0,\"delegacion\":\"\",\"idEstado\":0,\"estado\":\"\",\"telefono\":\"\"}}],\"flujoEfectivo\":[{\"idTipo\":1,\"tipoDes\":\"INGRESO\",\"idConcepto\":3,\"conceptoDes\":\"COMPROBABLES\",\"monto\":6000.0}],\"preguntaPEPS\":null,\"idPersona\":\"20160615174937749592\",\"nombre\":\"MARGARITA\",\"apellidoPaterno\":\"GARCIA\",\"apellidoMaterno\":\"CARRASCO\",\"apellidoCasada\":\"\",\"idGenero\":\"F\",\"genero\":\"FEMENINO\",\"fechaNaciomiento\":\"17/10/1965\",\"celular\":\"5539696573\",\"email\":\"\",\"idNacionalidad\":0,\"nacionalidadDes\":\"\",\"idLugarNacimiento\":9,\"lugarNacimientoDes\":\"DISTRITO FEDERAL\",\"idEstadoCivil\":2,\"estadoCivil\":\"CASADO (A)\",\"curp\":\"GACM651017MDFRRR03\",\"rfc\":\"GACM651017SWA\",\"dni\":\"\"}]},\"avales\":[{\"idTipoAval\":0,\"tipoAvalDes\":\"\",\"idTipoPropiedad\":0,\"tipoPropiedadDes\":\"\",\"clienteUnico\":\"\",\"clienteTienda\":\"\",\"clienteAlnova\":\"\",\"foto\":\"\",\"huella\":\"\",\"porcentaje\":0,\"porcentajeBasico\":0,\"porcentajeContacto\":0,\"bloqueado\":1,\"editable\":1,\"guardado\":0,\"idParentesco\":0,\"parentescoDes\":\"\",\"idPuesto\":0,\"puestoDes\":\"\",\"presencial\":0,\"primerInser\":0,\"avalVinculado\":0,\"consecutivoPersona\":0,\"folioIdentificacion\":\"\",\"fechaVigenciaIdentificacion\":\"\",\"idSeguimiento\":0,\"marca\":0,\"envioCorreo\":0,\"codigoCorreo\":\"\",\"envioCelular\":0,\"codigoCelular\":\"\",\"codigosEnviados\":0,\"cantidadReenviosCelular\":0,\"cantidadReenviosCorreo\":0,\"idCondicion\":0,\"idMotivoRechazo\":0,\"idMotivoBloqueo\":0,\"consultaBuro\":0,\"consultaMatriz\":0,\"clienteForaneoGuardado\":0,\"existeCita\":0,\"aceptaConsultaBuro\":0,\"aceptaTerminos\":0,\"banderaOCR\":0,\"datosHogar\":{\"domicilioActual\":1,\"idTipoVivienda\":0,\"tipoViviendaDes\":\"\",\"manzana\":\"\",\"edificio\":\"\",\"superManzana\":\"\",\"lote\":\"\",\"antiguedad\":\"\",\"andador\":\"\",\"idAntiguedad\":0,\"antiguedadDes\":\"\",\"porcentaje\":0,\"bloqueado\":0,\"editable\":1,\"guardado\":0,\"zonificacion\":{\"latitud\":\"\",\"longitud\":\"\",\"referencia\":\"\",\"calleDelante\":\"\",\"calleAtras\":\"\",\"calleIzquierda\":\"\",\"calleDerecha\":\"\",\"heading\":\"\",\"pitch\":\"\",\"zoom\":\"\",\"fov\":\"\",\"idCuadrante\":0,\"idPais\":0,\"idZonaGeo\":0},\"idDomicilio\":\"\",\"calle\":\"\",\"numeroExterior\":\"\",\"numeroInterior\":\"\",\"cp\":\"\",\"colonia\":\"\",\"idDelegacion\":0,\"delegacion\":\"\",\"idEstado\":0,\"estado\":\"\",\"telefono\":\"\"},\"flujoEfectivo\":[],\"idPersona\":\"\",\"nombre\":\"\",\"apellidoPaterno\":\"\",\"apellidoMaterno\":\"\",\"apellidoCasada\":\"\",\"idGenero\":\"\",\"genero\":\"\",\"fechaNaciomiento\":\"\",\"celular\":\"\",\"email\":\"\",\"idNacionalidad\":0,\"nacionalidadDes\":\"\",\"idLugarNacimiento\":0,\"lugarNacimientoDes\":\"\",\"idEstadoCivil\":0,\"estadoCivil\":\"\",\"curp\":\"\",\"rfc\":\"\",\"dni\":\"\"}],\"referencias\":{\"porcentaje\":100,\"bloqueado\":0,\"editable\":1,\"guardado\":1,\"referencia\":[{\"idParentesco\":3,\"parentescoDes\":\"HERMANO (A)\",\"telefonoCasa\":\"\",\"idPersona\":\"20160615182812779561\",\"nombre\":\"PATRICIA\",\"apellidoPaterno\":\"GARCIA\",\"apellidoMaterno\":\"CARRASCO\",\"apellidoCasada\":\"\",\"idGenero\":\"\",\"genero\":\"\",\"fechaNaciomiento\":\"\",\"celular\":\"5531607063\",\"email\":\"\",\"idNacionalidad\":0,\"nacionalidadDes\":\"\",\"idLugarNacimiento\":0,\"lugarNacimientoDes\":\"\",\"idEstadoCivil\":0,\"estadoCivil\":\"\",\"curp\":\"\",\"rfc\":\"\",\"dni\":\"\"},{\"idParentesco\":5,\"parentescoDes\":\"HIJO (A)\",\"telefonoCasa\":\"\",\"idPersona\":\"20160615182812800883\",\"nombre\":\"BRENDA XIMENA\",\"apellidoPaterno\":\"GARCIA\",\"apellidoMaterno\":\"CARRASCO\",\"apellidoCasada\":\"\",\"idGenero\":\"\",\"genero\":\"\",\"fechaNaciomiento\":\"\",\"celular\":\"5528569840\",\"email\":\"\",\"idNacionalidad\":0,\"nacionalidadDes\":\"\",\"idLugarNacimiento\":0,\"lugarNacimientoDes\":\"\",\"idEstadoCivil\":0,\"estadoCivil\":\"\",\"curp\":\"\",\"rfc\":\"\",\"dni\":\"\"}]},\"documentos\":{\"porcentaje\":0,\"bloqueado\":0,\"editable\":1,\"guardado\":0,\"documento\":[{\"idDocumento\":\"1\",\"documentoDes\":\"Identificacion Oficial del Cliente\",\"textoDigitalizacion\":\"\",\"idCompania\":\"\",\"companiaDes\":\"\",\"idTipoDocumento\":1,\"tipoDocumentoDes\":\"Credencial de Elector (IFE/ INE)\",\"fechaVigencia\":\"01/01/2026\",\"status\":6,\"idTipoPersona\":1,\"idPersona\":\"20160615174937749592\",\"consecutivoPersona\":0,\"idMotivoRechazo\":0,\"observacion\":\"\",\"cantidad\":0,\"banderaMod\":0},{\"idDocumento\":\"2\",\"documentoDes\":\"Comprobante de Domicilio del Cliente\",\"textoDigitalizacion\":\"\",\"idCompania\":\"\",\"companiaDes\":\"\",\"idTipoDocumento\":6,\"tipoDocumentoDes\":\"RECIBO DE TELEVISION DE PAGA CON SERVICIO TELEFONICO CONTRATADO\",\"fechaVigencia\":\"\",\"status\":6,\"idTipoPersona\":1,\"idPersona\":\"20160615174937749592\",\"consecutivoPersona\":0,\"idMotivoRechazo\":0,\"observacion\":\"\",\"cantidad\":2,\"banderaMod\":0},{\"idDocumento\":\"322\",\"documentoDes\":\"Comprobante Arraigo Domiciliario\",\"textoDigitalizacion\":\"\",\"idCompania\":\"\",\"companiaDes\":\"\",\"idTipoDocumento\":0,\"tipoDocumentoDes\":\"\",\"fechaVigencia\":\"\",\"status\":6,\"idTipoPersona\":1,\"idPersona\":\"20160615174937749592\",\"consecutivoPersona\":0,\"idMotivoRechazo\":0,\"observacion\":\"\",\"cantidad\":1,\"banderaMod\":0}]},\"contratos\":{\"porcentaje\":100,\"bloqueado\":0,\"editable\":1,\"guardado\":0,\"contrato\":[{\"idContrato\":\"1\",\"statusFirma\":1,\"idPersona\":\"\",\"descripcion\":\"Aviso de Privacidad\",\"idTipoPersona\":1,\"digitalizado\":0},{\"idContrato\":\"2\",\"statusFirma\":1,\"idPersona\":\"\",\"descripcion\":\"Buró de Crédito\",\"idTipoPersona\":1,\"digitalizado\":0},{\"idContrato\":\"3\",\"statusFirma\":1,\"idPersona\":\"20160615174937749592\",\"descripcion\":\"Contrato y Carátula de Crédito\",\"idTipoPersona\":1,\"digitalizado\":0},{\"idContrato\":\"4\",\"statusFirma\":1,\"idPersona\":\"20160615174937749592\",\"descripcion\":\"Solicitud de Crédito\",\"idTipoPersona\":1,\"digitalizado\":0}]},\"lineaDeCredito\":{\"capacidadDePagoTotal\":null,\"capacidadDePagoOcupada\":null,\"capacidadDePagoDisponible\":null,\"siguientePago\":null,\"pagoAntesDe\":\"\",\"bonificacion\":null,\"liquidarAhora\":null,\"tipoPago\":\"\",\"estatus\":\"\"},\"seguroDeVida\":{\"nombreSeguro\":\"\",\"opcionSeguro\":0,\"idSeguro\":\"\",\"precioSeguro\":0.0,\"sobrePrecioSeguro\":0.0,\"abonoSeguro\":0.0,\"ultimoAbonoSeguro\":0.0,\"totalSeguro\":0.0,\"clavePromocion\":\"\",\"comisionVenta\":0,\"montoFinal\":0.0,\"montoInicial\":0.0,\"esDefault\":0},\"bazDigital\":null,\"tarjetasCredito\":null,\"lugarOriginacion\":\"\",\"existeEdicion\":0,\"folioMCO\":\"\",\"mesaControl\":null,\"flujoSolicitudADN\":0,\"generadaDesdeRechazo\":0,\"LDCOROComprobable\":0.0,\"LDCORONoComprobable\":0.0}",
			  "fotoB64": "iVBORw0KGgoAAAANSUhEUgAAArMAAAEmCAYAAABxpBh2AAAAAXNSR0IArs4c6QAAQABJREFUeAHsnQe8FcX1x2kPePQH0gQEe6/EKAJRUJoIVmz5x67RxIYpdkVjjL1i712DGgGVooBKiybYsQRRQBAVfPSO8P/+rneX2X279933eOWWM5/PuVN3duZ3d2fOnjlzpmYNc4aAIZCXCBx00EGN6tSpc1XNmjXbbty4cUqtWrUW4XeBTgGQBtCH5E3ZsGFDH/ztiS/Efxt/JWWOjCpD/k+qi7wZ+PsQP4BwbegL6APiC6mvP35UfYVco3uq7OFQOF6uNlFPuN3lrfdj6lL/d4e6QeXtV1Q/fqLfE+n/bOjQJD5RaWn3hXp608YdoIXQ29QZ+7+RX557ReH4Afcdxb2WUef+P//88z8nTJgwjPBGyJwhYAjEI1Dz4IMP1thyEO9PD/wDoaL44omcxfxqvJ0ITVq/fv1/33rrrdWJnCz6od+96PPf1WTGj6vGjRs3uqzNr1nWC6y8IWAIZBYCvXv37skAcA6t+gwSI/gr4mfgRzFNxQwaU8ivRX4vqB5kzhCoTAQWUPlknrmdefb0EfMj9Dr0X2g3aENhYeE1I0eOFNNtzhDIOwRg5i7i3biejqczHv+Pd+li6IPx48fP4Zqs/VDs1avXgfTjMvqgD2/PLYUp7whTLkY9bWfMbNpQWUFDoHIQCDGjM5Bcbs3Api/zLlCc9E+StEkMBFtSZr/KaZnVaghUGQLrudM/oTo818+88cYbI6rsznYjQ6CaEGDs78B4fx23PymNJnxJmeth9J6F0dP7ktXukEMOOZMOPBjVCVYJfzV27NhpUXlxaTWpsDSufi2DyxwmzW2oRGXXQBpwvLRi8v5HfH/Si6E3oP5QIfQRpOUmicsDeVxTGcuJFbVUls7y6gf0SVKwxHIofqCvcZiU0u/wsl2JePg+xH28Q3VHSeUqC5906o1qT4kl03D/6NNLPFt6fhLLpYTfJpxqubREneXEJapPUWnh+/n95L762lS7f4K0DBReQjZmFFDMGQIRCGiVoT2keeTf0L+g7SCT4gKCuexFoEuXLoUNGzYcwPzwf/SiL3NaQYrezCP/JcoOe/PNN6dQbkOKslWe1blz5wZFRUVDaGNbmPJ/w4Qupa2a87pDErLUJu8z0t7Hr4l/FGmaI/8H7ah8KOw+XbRo0T7Tpk1bF85IFU+HmU11veUZAoZAdiOwgjFmGgPR1/gaVOdCsxmUPmLgaQ1tS3wO+V+RVpf4jpRrhS7k9Lp160r/tZ1bpnbt2rVI0zUdoe+If75u3brl+G2J64O4BaSPXzH29d36CgoKpG+7FddvDX3BNT9STpKLRJz8H8jfEipTm8LtDt8nnXqpYwFt2RLajvYs5JrP1qxZs7Q8/Yq6H5hIQKAl+Hb4X+F/w30Kwmmk10uFWbhu2j2T/6ou1+1AXbH/G/kl7l/avSL+n4W0Tf/7bvhSH9gK0sSmyasinaRSz0KrobWmolCR0FpdlYBALZbT9+CdOIS6RWL04t6JjeRNgV7g3Z2AdHI6YaVVl5Me73Hc/Fja8wVj0mzCDSGpDO2M/ysoHdUIiqXl9BE7AMb967RKO4WMmXXAsKAhkMUI/EDbJ0OrGTTn43/DYPMR1JJ4gvkjTSoMNRmUtiZcW3G+qr8YNmzYKsLmDIEKRwDJTQHPmCSqu/Ac/syzNwvmugmMsOJ7kL4PpE0vcZM7WaW6nykxjvo68rzrgyBuBeUtnv8PacNaynYh/AI6hy9SvjqZhVI7ZwWyFwFWvq+m9ZdCpTJ8PLtv8Gz+YcyYMfqYrTI3ZMiQWhMnTizi3s15LyRsaIG/LfHu+FJ3U1pVuZXcdz+Y+E/LekNjZsuKmJU3BCoHAUkdJ/IiixmdB33OhK8v4aXcrjXkSzVJn7V27VoMEdRR2nrKTG/evPlMmFJN6uYMgaxCILns2pXJ/P947n9D4/WxVVXuR270DbQv9BPv3720YQtoo0l8q+ovyL37aHc+vdLy+wFp9O7fPG7XlGcHfxp1xxWp2bNnz8N43u+mgFZQasYVrOT076i/DtTKuc/HfADvy3y21kkrNegxs5oEnwfQ1YAvHdgf8NuQppvMhKS3tIS0ZeRpWXERYZmMWCIivi3x75NltiYuqZAm546kKT4X0DQpb6M8aD7x9kzCFbqcSP0VsVSWcimTdn9Ku9V/d/lTy62d1Ff8eTAbK/C3C2NSWr+5LrCsGo6zhOjfh7pSYhpebqQ9+tqrFHzSqTdqSRosA8vW9erVW4RyuyYy0beQni8xbHoetYOzDpRymTtcJzgElq7TxQW8SizxRqXRtsCyb1Q/YToLkEZJOpVYQqYvX9PP2saMgkgVuf79+xehFvA0tzs0eUuZkLqsiieQKuptdt8Gk3FteDf24/+pyTu3gHFQ80tn4tLB2xVqVEU9DEt8pR8fkO7yXpvpsSr6MzL9Nj169NiVZ7Uf7fwdpFWHVG45z5L2gzyKFPKdVAU3Jy9pfrEV744EIq2ZH8XX/Yr3SuYW229O3c614u20WWsWpDla/N+X+DOIr+Ce0qfdDr8Zvsp8TbgB787cFi1azFq8ePGxlJXakO+4/mI2gd7kJ6QR8JjZ29FRuCiN8lbEEDAEDIGsQ4DlvpE0+rBQw5cziHaCodUGPXNZgMCgQYPqLlmyZG8mxe40V5tvpVagibo6naS770OSwknwYxvWACGXHePJ0TBcpzN+bKCfYhAlrGiaos8byXuPa7SRcRIfa/8dNWqUNtNXuIOp3hFm8TruNZDK61bADTROap+Dlv61cqiNWfMgSVXnwJRO3Vzbtkiyn6L+/6M+z+k+GpulPpeWk+RVbstfPPs1BAwBQyDnEKhFjyTVC7tGDPo7kTg5nGHxzEQgufT4Lq0T3QJpuXQrmIM9YHDrMrF+xaRYDxKTm1gJQVomtZxC/B1J2xnaAdLqj+IVMdlribQv5Dkx2qKEW7Vq1dkwP88SsQ1rSUyy1eNZO4Dn6B8wWr+B0u3GqzybF6KfPTPdC1KV44Ou9vLly5vzTLfkOW8FtaR+haV7fhCkMa2sTkv6s+iTVh8WEtZmzumEp7Dk/35Zl/zLenPe28G8w0dynTaXydVnbP4n/oGJWBo/nmT2KSSzJ6VR3ooYAoaAIZBVCDAB9WRgHBfR6C9Q99h7c6UKEfVaUhYgMGDAgAYwmtplvieT9ipoHeF9aHpXSOpNlSXx/Zm6J0K6VyH3nMq9nyHMNFz2XdxcZ64SEeBDROqRx/EfHc9tSlMf8FqynsBLjDu3o0agD6/NckguW3P/E6jkL1BbaLN1XOnTMup5gXof4bnTakK1Ovr4Mm0RQ+s5mrjxYKSzE7yEVH6CmaWCc9BPuD9VQcszBAwBQyAbEWAy0tLeEU7bJYl9EBrOIC69bHOGQBiBgMSXOXIm0qMGMCeSennS3a2YbHcir3744s2IS3r7GB9Z5+eCYfzNwKHaLuUgg4b8rwdCvUT8v9LTTsdJoinG602ueRWeSsvwpbp+/fo1Qcr6D56tJhSWLr+sbbQkLtOIbUjTh5XaoBWmsjqq2Chbtd9w4fci4vOJ/4dnbFImfcgn9zV8SRtbOp38HJuze6Zjc9aTzJ7GoP6YU4EFDQFDwBDIegSYKOph53YlHXEngr6Md2OyvnPWgWpHQM/X6tWrd4LxkG1dHRW9GNoe2twNa2KEGkENIDE4o6hTkrT9oWd5fl/GN1dBCCAV1OEFfwbnLahyF8IFaVT9LeUeZ4lfJrVmwrzO55qN3nV8RDelvus9JpV0HSjQGJL6izZfaTN9e8KyJuCOT14V5fWl0zoWepZ7D0cyvKK8FVX1dXxIHACeWrXw8QCftIStnmT2b/wRV1V1w+1+hoAhYAhUJgJRzCwTyI4sXf2vMu9rdRsCQiC0Ye0IPXtMzmKYNtfNo4Jx1DWTOqUvLJu5wza30ny7PimFvQcMT06z71IReQ36D9fsA/5fQrPAvzZ+B9I7kN4hGe5I3GfKCFek0wapmVT4A/QjTOuPtEGWmD7AKtBkNpfJwkBWOj4sHgK/02m8p0oxH3WgHSdPnqyPuVhnzGwsNJZhCBgCuYAAEpL/0I9feX1hwB8EM/uiFzffEKhCBGr26dNnW1QW9uE51IqBTBdJb1e6gr+BvAm8zE2CAZjLRTr6tBDfTkZLgWDPnj3bgfs5FDkLcpe1o67aQKJMRWpTFDAnJKkV8UESda+4NLVhCjScDWivVPXBCnGNqoz0pGk+Sbl9B+4DGLNf9RMiAglrBhTU14Y5Q8AQMARyDgHGt7eZgHxmlg7uDRkzm3P/dFZ0aGOSEfnKae0EwnfCYMme7lnQqcRLY7Ccy38J8pxr6foCLwNp1jl8yPkno1GvbG6LIZqBL6niAYRle1w2QT/E12EtvyZNqgxlTucarXZ8Qj06qroT4e6QNi7JFv2n+F/jf4+/LVLEbviyArEUfzpx2SaVbmcbyuxL+g6QGPvZkOqdQ/pifKlwdMFP59o5lJtB+W+5Voyo8O1Gmjb2leWjQdJVSVk7cj1ehbu11Kg+zgWHGTDZNWmrbM7Lvvr3fPh8j07tjEmTJi2q8DtnYIXo8X7PcxtoGZiImU/pEswsgOmBMWcIGAKGQC4i8KHbKca7vdy4hQ2BTEAgabrpYiRTl7NUvA8bdFohhVsAY7MN7ZNO7m7420EyKVYbKs2pTG+e90Q5rheDfLgiXprCpGtz0a74ivqurOlcuIsoop4i0nU0qphb3c+9fzPiXWmPLEgk8uQ7Tn0Xudd42aVduzUFdWhTorzbZ6+CSvZlHUP2WcWkypfEfA0ku9Yefd2gQYOPRo4cKSm9uU0IrCeY4E+VBI6lWhZJFKZgQKS7qT4LGQKGgCGQ3QjAEHzIZOJ2Yk83YmFDIJMQSFoxeM9p07tOuEbXrl0bwwBJT3YvGCQxiLIvmi6D61Zl4fIjICmppOufwz+tQnJYg//jJ/6PhJ1W0r4h7YNs2nxVfigq/MoS4m9w1UdcSudxvhLp2+7elFBZpiFgCGQjAizRfYFBbklE6iXb3w7p1xYwDQuzsT/W5vxGILkRRublRPcIDe2ch3nqTHA/mKpD8beHSpVmUcZcSQTEkEol4gsxqoSlKCsJeYLA+YtmzZp9wkECpp5ZEruKSgkwtGDfvLSKPWa21IKlVWT5hoAhYAhkIgKSdDHZf0bbpCubcEhrJc2SrqI5QyDrEUjaSx5PR0T/gAJ2ctG7/IoPugIY3W3Jk/7nd2LKiC/lXWhD/tbE28C0zSZvBvFl6aajDqEl9OWQTqPqxPXtoB8g6at+h1+P+rwd/iozj/hM2jMfs3l18aXrKysA0pddQDtmkT+LNNncFUPejraoTpm60kasr7nme+7bmLoGkXYEvtQkpNuayknfYDr0GvQq5aWv25Zwa3BYRp1zCH+LNHUB/i+6CQTMVTkC/DUbx/Pf9HLunJ5klj/SucaChoAhYAjkFgIMjB8zQPrMLL0zZja3/mLrTRCBjejgijEVue6/biQZ1uajdyoofVJEPUr6IiZdyV+myJtH3vtePqa0WsHEHgqz+yfSevNO66CBKF1b7xLdN8HkU/YtdsRLV9V1H7sRC2cMAvqQcZ30ulO6hGSWgV676cwZAoaAIZCrCHwS6piYWXOGgCGQwQjITFNBQYE2j/2GZv4GwdtuSG5rEY9tNXmymHAn/mMwr5IQm8syBPiLn+P/G+A0u22PHj12nTBhgiTrkc5TM6jI4/gib2SJhoAhYAhUFwJMgtOZ4PzbE97Pj1jAEDAEMgIB6f7SkJugnSGpH/jWCAiX5j7gvb4Zye2w5Ca60spbfoYiwCFez/Es/JXm+ZZnUAPZg3hqZhYueEaG9smaZQgYAobAZiPA7u/PsLvp1rMbpzMVsokjkOgWsLAhYAhUDQLakAmzci53uwTyNmqmc3PZpn2Bgs/BAEWpUKRTh5XJTARkS9h3CCTW+ZGIgKdmkLJQxHWWZAgYAoZA1iCwbNmy75gstTnA2yRSc9GiRdr1/VLWdMIaagjkGALowO6H/uvZdOs4qDCN7smCwHssQY/CH40awTR82/STBnBZVkTLaFuG2hzW/w5kJ5hZHqZdAqkWMQQMAUMghxDQsiNnfr+GFMfVwzqWLhozm0P/s3Ul8xHgpDOdpHUiK8K/Rdq2K+FUjZZJPUlcJ1JuItYPpvAu6yQwc7mNgGcOraXTTdlS1tHkkc6TzMZrU0deZomGgCFgCGQXAkyG19Nil5k9lOXN+kyO4Z2z2dUxa60hkOEI9OrVS3Zvj0SiehT+ryEd2RrX6uVkvI05rhvXrFnzH3s/42DK7XSej2fo4YVeLxm/U1o08DaAmXkKDzHzDQFDICcRwBbnu0hn5zIoamOJXCMmzIPwRytizhAwBCoGAfTR6y5evLg7ktd+vG+HwphoQ1dKR5lZlL0L6wWPjBo1amnKwpaZDwjIZJzveDZcKa2f7gU8yaxJJjxEzDcEDIFcRUBLV6/SOenoJRzx3gSMmU3iYZ4hUF4E+vXr1wRLArfBlO6FPrqWhBvxfpVWnfbrvAY93Lx589F2qlZpcOVVfnO3t3wYBeJunsIJZpaHT+Lb18OZFjcEDAFDIJcQYHIdy3jnM7P07aBc6p/1xRCoagRQ1WFvZZ1T0We9g3s3SOP+0i+YzHv4XN26dYchhV2QxjVWJM8QYKw+kGfE7zXxlNJ9j5lNZxehX6kFDAFDwBDIRgT4un+HQVEjpCcy2oPJuBF6edLTM2cIGAJpIoAqQe3i4uLjeZ+u4pIdSrlsHYzJW5R5BX84p5PpZC9zhkAsAjxXT/Cs9HIKbCvpf5wKiqdmoPOON9v179+/CIXtp6moL7SIhvyLBtUm3AdqAy2DPoNmQXPI11nIcygzW37yfGmC5gwBQ8AQqHgEdJwlxrh1fOZOydprI1WSYe5JFX83q9EQyD0EYCjqoU7wO1QJ/srcrY1dkY68uXw8jsaXGs+bvHtLIgtaoiEQgcDYsWOfYY/DDTw/3h6HgrVr13am6ISI4r+oGWAiQwzmZjsY2eepRDpoci1oxBm/BP1fne7RJUk1yPczFGCS0dfbm2zKuJ1GT0Basj5QwCKGgCFgCGw+Ajrr3WNmda67TpYxZnbzcbUachgBbMK2kk1Y5uZzmLslnCrhSF/L+zSejMs4xOBD/E3rxCVKW4IhkBoBeNP/8Dx5zKwKh23P+hXUUYjC+rp6108tRwAOujWXHViOS91LCngZ+mkHJNKS5TC3si+nzrxH+ntIbiXJNWcIGAKGQLkRYDwJHG3LgKnNKuYMAUMgAgHManUl+Wzm5UHMw/UiiihJgqfH0Ju9FiHU3JgylmwIlAkBxuot3AsYq9e6cTecYGZ5SLd2E8sZvobr4h708lTZiIsOEvECJa6HuS2mc18QX47/DYlXs3TxQyLTfgwBQ8AQSAMBBsQZjB9+ScLb+BELGAKGQA1UCVoigf0dUJzG+5HKvuc65uMnkdj+Az3YmQadIVBRCGhjIXUd4NbH2B37jCWYWR7GTSO7e2WaYU702Ic6zgwVv5uXQLppNVAb+BzbcbP4aqvLQ9+Bsu2hDjDRCnegiCTDYqh/4VoJxLjmlE90Dl9FzoTBfZPwMOr6l/ThYq6zZEPAEDAEEggwBs1mUHTRaOdGLGwI5CMCMA/1masPYz79HYys7MMWpMBhKfP7Q5S/E93GCtlzk+JelpWHCHAEec2ioqJAz9HVjhWYJphZHkpJOcvtmBhku9GdHf6Hcvifpk2bJhtyYfdFOEFxGVlmZ2RPXqDDiQ6EYnUjVD7pdM/etL83190HY/tv/FHER6GSYPo6HkrmGwKGgItAYDWHMSOlMW73QgsbArmGAMKoI5nD/0K/JIFtov7xTsiLcjPIuwc1wMfidpVHXWRphkBZERD/iPrqZJ6333jXEtYGsKle3PUTzCwJX7uJ5Qi3da/hhn+JYWTdYoEwxpKlC6Fdj6I/9OnTZ1u48M7U9Svion2gxIuGH+XUl24wst3w/w5jK9t170Bvk/Y2UttPCW+AzBkChkAeI1CvXr1FrBL5CDA+tPAjFjAE8gQBNnQ1ZEXzPrordYJUTi/LCBjeB5DCjiNs82gqtCyvwhCA/xtPZb9xKtzGCQeCHjO7N6mR3G6gdHTElcgmSrCLcWR00bRTN44ZM+YrSoteSF5Vky/IrXihdiN+Gp3ch0moUzIvypO05WgRZWUpYT3lHyd+henZgoI5QyB/EVgT6nohcYmiNkvdKlSnRQ2BjEWA+fBYGNmbaeBWcY1k3pyuOROh0tNs6vo+rpylGwKVhQDP3/fi3zxHOFag6TGzHb3CZfUHDhzYcOXKle5lilTGpLARBfPZ1C3S8Xc1evTosSvM7VF08CiishWZytWh3BkUOAnR9Wtc9xRLJa+zVBKe2FLVYXmGgCGQ5QisWrXqZ979DXTD/xBHSrUjUqdIFags76413xDwEYCJPYjI9VAXPzEYWEj0aebHp3kfpgWzLGYIVC0C8GxbuHeEuW3mxt1wgpnlgmVuYlnCMLLHu+W52Y9uvDLDEyZMmE79or/xkuoLs0+SDsaP63Rd+nsk7TySpcalXDeG8GscqyfGVqoJ5gwBQyCHEZD9at779+mi1JcSjjFgXwLGzCbxMC+3EMC8lvaWXEavDozpmTZP/50NN3eh8vdzTBlLNgSqFAF4tQN5bt177u5G3HCCmWV3rwb28rpL3Au5+Sw3XlXhpA3ah7jfQzpmb8mSJXvRrwP5wtSGMunS+lIYp00SWct23iAY2w1McB8Tn0D8LeLvMOktdspa0BAwBHIHgdF0xWVmpWr1VO50z3qS7wjopC6sEui42QuZ/+JWLqUPewfz5DVIYlfkO2bW/8xCQCsE8HG9nFZtJ7NxUYLHBDPLBVpyqyj3ekVVVN56kl+WWiIR3aaz1zEhchIv9XnE/ZN/QvWL2dULvxcv/mCWIaVnO5vw5c2bN6fKxAa10CUWNQQMgWxEgPf6I8YDv+mEpYtvzhDIegTYW7Itc/qZCGRO5blulaJDwyl3ianXpEDIsqoVAfZOPQUfdhON0KFccrXQ4dYqWgk+01MzkOhWkooyO5TIz+WFeJgLt+TFeWP58uVDy1xJJV+AhHU5t7gXug992f1p7/FMZoOIB6wwRDSjI316GjNjdwCobNk+jd6uNsoF5N4R11mSIWAIZDACvNfT3eYxHsR95LrFLGwIZCQCScsE2vB8Cs/2gTzPUSuRXtvHkj+EjdDl3fTt1WO+IVDZCIjXehs61rlRcyfsBxPMLA+2dvOWy8HcjercuXOnpk2btiI8r1yVVN1FG5Mv8NQhQ4YMnjJlyr4wqP24/aFQZyhuANiCvHNggs+BqZ1DeDiY/Qvx90Tp3xE3ZwgYAlmEALqBM/lIlW5g7WSz23fp0qVw6tSpq7KoG9bUPEaAebeAVcNezEUnMo9JnU6nZup4+ihUfobJ1Zx1M/P0e1EFLM0QyFAEurrt4hn+yY174ZowZ3ryT0Pn9DEvMR99JLYt6Hd3qAcv/W/xFS/NLaLAG9Bo1BhGIxKfX9oFlm8IGAKZgQDv/De865281vCxurMtuXpomJ+pCDBny9zkRbRvZxjX4BFJJRu9iDKPUv5e5vivS2ZbiiGQ0QiIRw2owcLM7pbc/B9ouKcz+1kgNQ8jSGzF7b+SpAuY6HZhADiD+ElQHGOrgUTi72MBeCOgzyD8HXQfA8c/8c0ZAoZA5iKgVZZOXvOQbrUnbBYNPEDMzygEmF+2okE65ODQGOmr297JlHmoQYMGw0aOHLnSzbCwIZBFCGyED1vAs9zSazNCB23WDaiJKc9TM9ie8LtKMPcLAjC3YvAvYufcpSjS9wVQ6dkOIK1hDEbaTbJDkg5i4LmG8F0FBQXP2LF/MYhZsiFQjQjwTgdWUni/vU0G1dgqu7UhEESADczN2JAsq0HnQ6lUAr/lmX4aetJWGIIYWix7EWBcfobWX+j1gOd7Vy/s+glmFonE1m6ihTchkDxUYTgpwwcMGNAAg+syEyH9pMMg/2uBcNhpQ8m9MMK3wNiOJPwcjO3oZH3hshY3BAyBqkcgYFeaL37pxpszBDICAc03q1evPo/J/K80KHLTC+lSdXuBCf75rl27TmQvSGBJNiM6Yo0wBDYPgf+5l/OsR/JdCWaWzEiNcbcCC9eokVyuSTC2SVu2v0K9oA/49Qaf/SFvM4kLVwMix4lgbHVIwyjCIzAv8brZsXVhsrAhULUI8N5Kn9C/KeFmfsQChkA1ISAmlsOIzkZwIiY2crWAZ3cuebcwp9zjbULmGPlqarHd1hCoVAQCH3IIXwNx786emsE3XoL56SGQtGUr1QzRtTCpTRlgTmFCPI24bFZGWUbQIQ0JxpZlI51C9G/KjyU8pkmTJtOSdVLEnCFgCFQ2AgyKy3ln3dvEqRC5ZSxsCFQKAqi0NYE5/QNM7GCey1YxN5lH3hVIYZ80KWwMQpacUwjwvB8In+T3ifgufsQJeJJZ6Yea2wwE2PC1hMvvFMGkbgXgpxA+lT+hE36UE/bdKNcN6e61ixcvXsSRgzOYYD9r2LDhJSNGjPgh6iJLMwQMgQpDYHWopvqhuEUNgUpHoE+fPm2ZA86HkT2bm8WtDixmLrmJDV13aoXQpLCV/rfYDTIHgSdpitQ7Pbc9dpVboRf+o5cg35PMSqH2AzfDwuVHAMZ2DldfC10HY3sA/rHQMVDsIQ0MVEXk/xrm9tcsMZ3Eda8QfqRZs2ZjTGILMuYMgYpHIGwjOkpNqOLvajUaAiCAxZw98AbDyJ6AXy8GlGWk31WvXr1bX3vtNenHmjME8goBPtyehh8SP+Xt7arFO9OD+AsuEJ5kNnJ3mFvQwuVCYAOM7SSunMSS0IUTJ07cj00mh8G4yirC7ilqrEXeUZQ7CsPu8/gjn+LPexzbal+muMayDAFDoAwI8C7W5B3zryC8KeKnWsAQqDgEtNeiuLhY4/95CCs0IQf0XJw7LeVxHMq4fzs6sQuddAsaAvmIwKt0+jyv47w7JU5s9JjZyN1h3oXmbz4CSf0mHR8ouhwxeQdUCnR6Sy/+mINJi/sP2pF3CYcyXIIawhTKP0H8haRaA0FzhoAhUB4EeJcK3et4D20nuAuIhSsMAS2LwpiejjrZWTxnnVJULAsbd7JBWBu7FqcoZ1mGQD4hIDVO123rRhROMLNxu8PChS1ecQig7/EttT2apFo9e/bcC0nRZcR/DXWASjgmX6ksiO5AWjuCQfFJ9KzGertZS1xgCYaAIZAKgQPdTN6n7dy4hQ2BzUWAcfoo6riMOXZ3nq+6jOFxVX5Fxm2FhYVP2CEHcRBZer4iwLuzX+jd2TeMhSeZ1e57c9WHwAbOy36f20uvVrpUXfBOg47jT2ystJCTROk4/tzjsITwAwPmcwyWTyXrCBW1qCFgCEQhwLu13B0gCQcktVHXWJohkA4CWCaoh3R1KM/UGaWUf4v8O7p16zbSrBOUgpRl5zMCT9J5dxPYDuFNYDr3Vp+KGzDo3waD/lriMJchCPBnNYRJPZrmnApJihSnX+W1+HMCz8DgPjN69OhZXqL5hoAhUBIBxj69Wy86ORNQ3+npxC1oCJQZAVbZDkAt7EEY2bi9KCvJe5axfSj7ID4q8w3sAkMgDxFgvP6abm/tdZ136HhOavU3gSUks2TW4itSYtvXvYLmVz8CqCKsoBX6InkSxnZrBr+TCIu2gaLcziRex395HX/8t/zZp/NnmyXtKKQsLe8R4P34HOmsi0MnN2JhQ6AsCEhSxDN1PSSTjLUirv2GNFkmeMIsE0SgY0mGQGoEUm4C85hZVRF5qkLqui23qhCAsdVAeA2kAxq64oupHQTF2SXswEQ9lrLv4t+Ike3htowFWuYMgSQC2OychYF6F4/2vCO17D1xIbFwaQh06dKlkGfpQoQNF1O2aUT5RYzB12Bi6C7yNkbkW5IhYAiUjkDKTWD+1yM7LX8qvS4rkQEIbJS5L+gsJLBtGSRlw3YEtDambVKcfnnSpEmfwdieedBBB5lh+BigLDm/EEhutHHHvYKpU6e2zi8UrLflRUB6sexv+COH3HzFOHw99YQZWTGujzJObwMjeydhY2TLC7Zdl/cI8I7tFwKhsxv3mVl20s9yMyyc+QhgxWA1g+QwGNvDYVi3pMWywxY4FcPpxY6EH0SfdhZM7dUMxC2dPAsaAvmKwDy341gHiT3YxC1n4fxFYMCAAQ1gYnVi1wwm2KEgobE37D5nTD6Ysfl0M7EVhsbihkC5EHgqdNUOLh/jM7MU2j1U0KJZhAC6sT8xcA6FWvNhsj9NHw5FSQIkeRrCQDwHpvaR5Ck0WdRTa6ohUHEIwIz8EKrNJLMhQCz6CwKaOBkzh6CaMovnRpLWKBOKxeRdyGE3ezImTzDsDAFDoGIQQHD3FB+Is5za6rDq0d+LuzqzYmb/6WWYn70IoF/7Lq0/okePHrsiif0LulwnMsAWhHokdYPTSD+NAfotwkN5MIabzdoQShbNaQQYHAMWXNiFvkVOd9g6V2YEGB/35qLzEADo2Nk4Na2V5N3N5q4bbXNXmSG2CwyBtBCAXxlNwbO9wvA2xxF+XHGfmWVQb6MEc7mDAGZfptObU5AoXMFAfD7hs6CwXpc6fJAIxvdbBu4HYWofhqn9XhnmDIEcR6DY7R+DY5Ebt3B+IqBNXejCaoOtJk7Z/Y5zYmIfYMy8ycbMOIgs3RCoGATgU9vB0PqVsQq9n7dp11czoEChX8ICOYUA9oPnon7wV3bcallsMCR7bVFO+X+DqZ0NU/sCKgg9iG96cqKusDRDILsRWBJqftTHXqiIRXMVAWzE7sO4NxRGVrrUT0CRjCzz5SLy/s5kujVj60XGyObqE2H9yiQEeO+ed9sDc1s0efLkxDvqS2YpsI1byMK5h8CIESOW0as7Bg0adHdxcfEAHgxJa8Wwhl1dEo4l/1iY2u8Iv83y67ljxowJSLHCF1ncEMhCBJa7beaZb+jGLZz7CLBy1YSVq6H8992ZHDuV0uOZlLkLvdnHmEQ1npozBAyBKkKAD8dn4Umu4nba0O657QlMdplZZUoKF7VpyLvI/BxAYNiwYT/TjVdEGPreDbNs5zKQ/x/xqIlcO3VPoMxRPETXcVLcXUh6l5JmzhDIegRgTFby7Pv9IGwrVD4aOR+o2atXr+NhZB+ipw15FuI6rIyxSGHvadq06evJ8TOurKUbAoZAJSGAIK42myu3dauHN0ls4nWZ2eYwKzvB+X7uFrRwbiPAZrFP6eHZ/PcX4+sghnOgnaGwq0fC3xj4B1P2dmNqw/BYPBsRgEFZ4zIx6MzqOTeX4wigSrAvHy6389/rAJo4p0nycValHmZV6qu4QpZuCBgCVYrAJukDt2UM36C7u8ys4mJijJkVEnnm+IiR7uDd0FCkFb9hkP89YR3IUBtynU6KM6bWRcTC2YyAVilcFx4T3TwLZzkCffv27cRmrevpxvFQYFJMdm0DTO5rhB9DFevVadOmrUumm2cIGALVjIBWRRCmyeTdIU5TpDM7JjBww8AUOgUsmJ8IbMSe29t0/W02Q/xFS2uED4YaheAwpjYEiEWzDwHGvMRXvddyGJkoBsfLNj9LEZCNWFaVLoORPYcuREnfxbSOQzJ/9vjx42dnaTet2YZAziPAmD2FYdplZg9UpwPMLIyLmWPK+Uch/Q4yqGtH7xHJDRLaLCZLCGJiXWdMrYuGhbMKAQbFWgyOfpvDzK2fYYGsRIDju5uhEnXR2rVrL+S/bhzTiRGoEvzJVAli0LFkQyCzENg71Jy9ZJ7LN82lTL5Kvw0VsqghUEMbvlBD0OavrYHjSijKqoHH1H7DMsAVYoANOkMg0xGAeS1w2wjDs96NWzg7EdD4g17slYxZX/MfXxnDyH6IAEdHzh5ujGx2/s/W6vxDgHc5YJ4LBJrJPFeAmSVxj/yDxnqcLgLG1KaLlJXLFgQYGBuE2mo6kiFAsinarVu3Ij6mr0alQEfOXgsjWxTR/tnknUTZzmyAHR+Rb0mGgCGQoQjw8fksTfsy1Lztw2oGZms2hJBFSyKQNM11HdKPu5g0TP2gJESWkiUIwOwc5DYVJmc7N27h7EAAKWxr/jupQUknNm5V6EfKXM+hMPczhq1hb0B2dM5aaQgYAj4Ccea5AsysmaXx8bJAGggYU5sGSFYkoxGAuVkOQ+u3kXB9P2KBjEeATarboirwZxp6MhS3gbmY//UW7FHezUldgUMyMr6D1kBDwBCIQiCwUZcP1DUBNQMGhQVRV1maIZAKgTKqH8zD9New/v37Ry3/pbqN5RkCFY4ADM7LoUrDprpC2RbNBARQJdhf4whzlpYbz4aiGNmfSL9Cuv7jxo37hzGymfDPWRsMgc1DQOa5+Did4taCIHbXgGSWzE/cAhY2BMqCQJqS2kY8iMesWbOmLxPSKei/vFSWe1hZQ6AiEUAyG9a96lCR9VtdFYcAlgnqwJgeSY0XMoYcAMVV/gN5t61evfo+O3I2DiJLNwSyFwHGbZ1M6rrmAWaWAcCkEi48Fi4XAukytVT+Irpu2oAxGMnJx+W6mV1kCGwGAkhm57BE5dbQ3o1YuPoRSJoGvJeW9GaOahnXIvJmIam9Zfny5Y9OnTp1VVw5SzcEDIGsRyBwpC2S2dUBNQO6t3vWd9E6kDEIRKgfrAk3ji+sntD7SGkfRfJijEQYIItXKgIsPS/mBiudmzQ0s3IOGtUc1LGzbDLVIQa/heIY2Q+Vz4fJ9mzquscY2Wr+0+z2hkDlI1Ds3gI70UsCIgkyW7sFLGwIVAQCjqT2AU7geQIJSi/qdZ89HZl7KhKy49GDuw//Bq4x/e2KAN/qKBUBnkftcu/kFUQFRkzTUi9uftUjwAdFPcaKq/hv/srd3bHCawxZG0fzv92GqtKbXqL5hoAhkPsI8O4v5d2XbfuEQzLbMiyZ9fLMNwQqHAExqEhODqXiPaCxETco5CG9CEnM10hqb2BCi5PERFxqSYZA+RBgUNRGIde1cCMWrloEkMb24MSujxgLLuPOYUZ2PekPkL4rqkmHGiNbtf+N3c0QyAQEGLM7hdrxc2CgoIAdZxtCyKIVjwAT0OfU2geGtT/+TdAuobs0In4xTO25SGofYPnwtuTRuqFiFjUEKgQBqRr4jnGwqR+xQJUhgJmtdui83swNj4cCpnfUCP6XtwsLC08cMWLEd4qbMwQMgbxFQGoGvmSWcaM4IJklwTbh5O2zUfUdh6l9jaXEPZG0nMHdo45SbihJLc/lTBjfR6Cdq76Vdsc8QGCZ20eeN31MmasiBHr37t2Qd/tqcJdliROgMCM7D0a2P6s6BxkjW0V/it3GEMhgBOALAmpgJdQMKBAeRDK4O9a0XECADTjrWS58BKZ2ByasC+lT1OpAPdJPg6Yz6b0GHULYnlVAMFchCAR2vjMORtksrZAbWSWbEOjcuXMBr/I5TEQzSB0CNdyUmwjxV/yiUgAj+3ooz6KGgCGQpwjAK3QKdT2oZsCgIl3Gd0OFLGoIVDoCMLWrucmdAwYMeAj7kGcyif2FeLvQjcXASuf2UPTqpiPJGcpD/RTnq68IlbOoIZA2AjxDa3ne/PKEC/yIBSocAdmLZffxb8H9SioPmNhxbvYB/8Mf+dCd6qRZ0BAwBAwBIZBazYACZs3AHpRqRWDkyJErkcLciXF0TXJnQZLalHBMhLsy2d3HB9hc9GrvRMJjKgglULKEdBDgOdrgluPZknUNcxWMQFISexrWSj4H48epPoqR/ZH03xcVFe1rjGwF/wFWnSGQIwgwZpdQM6iTI32zbuQYAlg+kE3ahwYNGvTookWLjiCs89f3j+hmMx7s80k/H2ntXPzTmATfiChnSYZAughsEtOme4WVi0VAOrFs4jwDBvYiCm0VU1C2fm/nI/ampCm/mGKWbAgYAvmOAGNJpxAGQTUDCkTpK4ausaghUHUI6Bxm7qYjb1+CWe3CM3oB4aOhEh9i5OnQhbFIaf+NCsL1qB+8StwYE0AwlxKBwLPEc7Q+ZWnLTAuBPn36tEUX/lxWT84G0+YxF60l/WHUDq4bM2bM/JgylmwIGAKGgItACTWDwCAOA/CxW9rChkAmIZBcdpyqk8JYqvw9bTsTilKN2Z8JdARM7SdIbW9EKvSCNpplUl+sLRmFQH23NTwzWhUwV04E+Ojcl0vP5707Fia2bkw1YmIf5z29HrN7s2PKWLIhYAgYAiUQkJqB+4HMONIywMxSQBtszBkCGY0AjOlcGnglKgh/Ky4uHsRDfSvxKKZ2d/KehvH9GxPsrStXrrQz2zP6n622xoV30duGwjL+FXxg1uc9O5bL/gDtl+JyqRM8guDkZlZOvk1RzrIMAUPAEIhEgHm9UygjqGYAd2vWDEIIWTRzEUAFQdKdZ0RIYffnY+wyHvLDiIc/yrYmfWjDhg2vgqkdyqR7D0uaWqYwZwgIgSYuDIyDAbuzbp6FSyBQk3fvelKl0x4QjoRK/sT7eU/dunWH2lHVIWQsaggYAmVFILWaAbVFSbfKehMrbwhUOQIcwPBvbjoQZnUPGNdLCEtKFN6V3oq8a1n+/CvlHmFyvd2WOKv8r8rEGwb0OZEaLsrERmZam3iHZBv6Adp1UIq2fUnenZzc9YQslaQoZ1mGgCFgCKSFAHN3ajWDtGqxQoZABiOAXq30vk/kaMwrYUokLToFCuhEEm/EJHwB9EekSsOQxN0CU/s+6ebyDwFJ8bdxu81mpIVu3MJBBFApaMTqxuWkDoZ0oEnYydTZaN6robxXYwgHTJ+FC1vcEDAEDIGyIMDc3SlUPqhmQAGzZhBCyKLZiQCT6Exafg4T7zVMvLKAcDbULNQbLYueANN7AkztBJ7/W7BxO4o0s4AQAipXo/zvUjEIfOysWbPGJLMRfzjvkg47OJ335Gqy20YU0XszjDKXo8bzVUS+JRkChoAhUBEIaIwu8ipiDi8O6DiRYNYMPHTMzwkE2CymD7RL+/Xr949169bpEAYdmRs+WUx97cHSRQ+Ym88J375ixYqnp06dukoZ5nIXAdRTlvKf63/2j7BlHGxBfF7u9rpsPWOjZW02Wh6fZGK3j7l6DJLY35vaTgw6lmwIGAIVhgBz9RLGI5+ZZexpWcutHZuAUUtGbhELGwJZiYAMscO43MLJQtvwEpzKyzA9piM6SexBNovNRifwGqh1TDlLzg0EJE0MSBGRLLbMja5tXi90YhfP/8kwstN5Z56mtihGdh7v0gm8W32Nkd08vO1qQ8AQSA8BxqNOoZIl1Az2osDEUCGLGgI5g0DSAsLjdOgJjsHtxxfdn3gxekZ0sCXpV5F+MRP6c6gq3MHS6UcR5Swp+xEI68hKMpu3rmvXro3ZsHU6AGgVo2MMENrMdRsCkBtZ/VgeU8aSDQFDwBCoDARkN97VLPjJjdRg8jaJRGXAbnVmIgIb0Y99nYa9zmaxfVhavoiwLCAUhBpbj/fiFCwgnAJTOxcp1HFIoKaEylg0uxEI6MjygeMvX2V3t8rWetQttGrxR57x07gyrF/uVaZJ5FEwupb3wFQxPFTMNwQMgapCIGx6U7xrmwAzywC1uqpaY/cxBDIFASZlWTL4P/RqL0HSdB6TuXRrS0zmvDDtoclM+iNYir7KJLWZ8g9uXjv4v2Xmxa+EsDaF5YWTPuyiRYv60tlzoH5gEVA9c0AQE/sUc8TfeV+0udKcIWAIGALVhcCmAfuXFqwJMLNIp2ZUV8vsvoZAdSOAXu1c2nAxu7b/hlrBqYTPh7aLaNdAJLUDYGpfxL9mwoQJcfq3EZdaUqYhAPMaXiYPnwiWaU3e7Pbw7G5FJafByOo5VzjSwdyuYl54lI+3W0aPHj0rspAlGgKGgCFQdQhon8NiyFcH00d4mJn9rOraY3cyBDITgaQO4N1Dhgy5Z/LkyYfzotxLS9uEWqsvw0FM8kfDGAyDqf2bMbUhhLInGrZaETDVlT3dSN3SAQMGNOBI56Ng3k+mpPTE46SwqugHyt1bUFBwn53YJTjMGQKGQAYh4DOyahNjVZCZZYlVO7lNypRB/5g1pfoQgJmVsfd/idCX7YGE6joY2wNCLRJDcBxM7SCY2pfIvy55cEOomEUzGAEdi+y6um4k28M8u8cw2P951apVu+I3KqU//yF/KEzsCzCxa0opa9mGgCFgCFQHAsXc1D25MbgBjMl6m+pold3TEMh0BGBQJ9DGrlhAOBSG9VrCnUNtFlM7CGbhGJja4WJ8x44dOy1UxqIZiAD/58/8b37LCIePQfbzsinAxsaOfGTdS/8OLaXdKyjzPM/s/WyK/G8pZS3bEDAEDIFqRYDxKnCcLfEtAmoGKPebndlq/Yvs5pmOQNICwigY1oG09Wpo71CbxRUdwbt0BGXG8JL9HUbYzN2FQMqkKMyrdLB8x3+2ibP1U7Mn0KdPn+aovVxKi8+lL6lUJt6lzKNIYZ9HCrs0e3poLTUEDIF8RoAxu1Oo/+sDzCxf5gtCBSxqCBgCJRHYiJH44SSPYAn3cF4s2aMNM7W6qg95fWBqJxP+B9fIFFiAcVIhc9WLAP9RLZg+vxGEpV6SdY7nrCl9uQBGdjCNL2GNI9mhH/Afp49P8pFleySy7l+2BhsChgAIBOzMwrsGj7OlwCcGkyFgCKSNwEYYglcoPZwl3cNY0r0CJuHXEVd3Je1VmI1PYDZu5kSl56dNm7YuopwlVQMC/Gdh28IaKLPGJSWxsrxxPn0pimo4z51sJN/ICXj3cXDIz1FlLM0QMAQMgSxAIGrlrLX0/HzHF31O6Ir5HbKAIVA1CGzE9uZIVBD2g2mQNPadmNvuDkPxJAzFVzC2g3XSUkw5S65aBALqVfx/WWFvG7vI7VkZuJWNu7OASyovJRhZnre5qLycyrPWkZWBocbIVu2DZXczBAyBSkEgwLsyxi0OqxnsyW3jJuJKaZFVagjkEgIwtGPpz1iY1W740lvsB4W/JGXX8zaODL2Kcg/wIt5tpymBSPW5gF1ZmNmV1deU0u/cu3fvzjwzg9euXXssbQ1Llb0KfiJwA6a47pk6deoqni8v3XxDwBAwBLIWAca//ox/AWaWcXBhgJklwY6zzdq/2BqeSQggBZtEe/qzBLwnKx4XEx4EBd434tJrvBh9n8EwtS8Qvp3rPsA3V7UIBCTkDJThQxSqtjURd+vcuXNBs2bNjmaMPpf2SW1FthUjStaQyZrb2NR1t23qioLH0gwBQyCbEdCegPDYx5j4VWByJSErltey+Y+wtucXAskjb0+EWZU+7UW8hKeCQIMQCrJr+jsRy8ZaFj6GAxi009xc1SDQNHSbJaF4tUVlXouPnTNpwGlQ2xQNmU/e7diSvZ+DPpalKGdZhoAhYAhkLQLsTXmHObKn1wHm1I9YeXovwMwyaM7wCphvCBgCFYcAEtevqe1cjsodwlG5fyQsKrESwovZnpd1KszvyzC/V9mO84r7D1LUFDhNBtwl3aw2JyksetUDaMcZPA+9aUiqvQxfUObWdevWPc3JdSaMqLZ/zW5sCBgCVYEAjOzx7n0YJ99XPMzM/s8tZGFDwBCoWARgOBZS4zVdunS5qVGjRifxIsqM0o6hu2j9WEvKR3JIwz/Z4HOdHZUbQqgCo+Dcjv/Br5G4/qMqd0jl9+Dep3Dj30KtCMe1QY19g/w70dEeRXhT4+OusHRDwBAwBHIDgZ1C3fhO8QAzC8e7O2kfhQpa1BAwBCoYAW3KocoHoIdgYgbCmNxHuE3oNrJ/ejyS2mOR1L7Cysn1dqpYCKHNjJ511lkFX3/9dTu3Gv4L2WKtEodFgiZIVYdyM20Y3LqUm+pggyeg+5D0f15KWcs2BAwBQyAXEQjYmGW8nqtOBnaEwcyWNpjmIjDWJ0OgOhHYIFu1MCfSh+wF/SeiMXpPj+L9/C9M7RtIa7X0HCu2i7jekmIQwN5viRw2T1WJpJP/8nAsEmgglr50qrH3vwzYZyKhb8dzcr4xsiX+MkswBAyB/EAgat5rpa4HJLMMmFUyiOcH5tZLQ6BsCMCkvMkV45DUHo4/hPdRpvLC7hCktfBBh3xMxh0wXs+ya31NuJDF00NAh1eApZapfOksTGNr4pV2vCsfI3tR/038j734j+MauoiMZ8h/BFWCD+MKWbohYAgYAnmGQFgIu1j9DzCzDK7f5Bko1l1DINMQ8E8VE1MLM3MFDewc0cg9SHuUJep/wBw9SPh+mJ6E7lBEWUtKjYCkoz4zi+kXbcybkfqSsufyf+7C/3kV46zMtAUG5GRtEiaMgp6AoR5hG7qSqJhnCBgChgAIxNmYFTgBZpa4dlybMwQMgepHwGdqkRxKreAS6KCIZrWGObpS+ZR7hfB9qC28RdxWWSLAiknSAQOuC1g3cDPKE4aJ3Rcm9mKuPRKKYmJ/Jn88HyZnwcDOKs897BpDwBAwBHIdgTgbs+p3mJndm7SpuQ6I9c8QyCIENqJ9MIb2jsHm6K/ZBPYnwkdDYXNNOglqEEzRIJjaL2BqHyL+BIxtmFEj2ZyLAFgVg5ufBMZFfqScAUyw1WHj3hHUewFVaHNXnBtHxmCk6p/EFbB0Q8AQMAQMASa9GBuzwibMzHY0wAwBQyAzEZBhaFp2XN++fTshxTsXRul04jpFLOx2Iu9WEq9PSmsf6d69+7ghQ4ZsCBe0eOIkrYTOlYNFUydcpiBMbHvsCJ8Ogywbse1TXPwh+ZfDxL6eooxlGQKGgCFgCCQRiLMxq+wAM8vgusxQMwQMgcxGYPTo0bNo4Z+TBzD8Dsbpj7y7u0a0uh5px5F33KRJk2ajW/skyzRPwBTPjCibt0ngsxQM3f43cSOlhTGvVQ8d14HUcQpl+0C1qTPusg/IuA5p+yv49nERh5KlGwKGgCFQEoGAjVnG3LlekQAzS6IGWnOGgCGQBQigX7mcZt4H3Q+j+hte7HMISy+zLhR2Hcm/kiX0Kyk7l/C5MFQjKZT3DBVf+8tDzGejMHgR8Vrg2B0cT0RKrg1dqVQTKLbxTbC/BUnsG5QNcM4RdVuSIWAIGAKGQAgBxtFljNWNvWTCX3jhADNLwUIvw3xDwBDIGgQ2wiO9TWvfZrdnK5izkwmfCW0f1QPecy1/v4IKwpeE70IP6QkOY1gRVTYf0mAyV4KD31UGyAZ+JBioyWau/ckX83oM13QIZpeI6WPjaeq/B3w/LZFrCYaAIWAIGAJpIcDcdhhzW6ygIcDMUuPu0Itp1WyFDAFDIOMQgGn6kUbdDN3Cyy/J4WnQMcQbRjR2RxizexggroOxfYSl8nvycTc9/V8NDj484FXfiyQ3cnUnXxLvI6DSGFhd+j7lH0J3VjaAK81erW5kzhAwBAyBfEAgaclg00BNpxm7oyWzDMCbxBP5gI710RDIXQQ2wti+Q/feQafzfJbCjyd8LaQDAcJOS+R/hvkaDFM7Ekni3Vw7gbS8GA/o7xoYWB8TwnUHDhzYeOXKlTeQeBYU/uj3yzoBfUQ8Iyn3mDFjPnLSLWgIGAKGgCGwmQiELRlQ3Yfs/3jfqzY8SOtUIXOGgCGQQwgkpYM6WOFBmNW98S+ExNyGdWtl7usIvnaPoNxnfNzeC4P7VK5LF+nvevpK1323N4zsLGLN/ZTowDIY3+HQs9TxBlLt9dHFLNUQMAQMAUNgcxBgjNWc5brAHq8AM8uAvtotaWFDwBDILQTY9KUB4GQ2L10KE6YNY7+HWkb0chfyhyLR/QeM7TOEdRhDTn7sIpn9mf75EDAO7ulHSga0WexVyg9bsWLFqKlTp64qWcRSDAFDwBAwBCoYgYAlA+r+zq0/wMwyQMu8j9k9dBGysCGQgwiwYUwDwZXohP4d6euJhM+D9oroqnaOng0DdzYM8BTGiAdg4oblChPXo0ePHemT7PWmcrL4MBoMHli+fPkbudL3VB22PEPAEDAEMgyBYtrjrpbNc9sXZmbNmsakHGkAAEAASURBVIGLjoUNgRxHgKVxrcY8KkIC2w3/XOgoSCeKBRxM3wEkHNCwYcPb2dX/FMs+D02YMGF6oFCWRDhNrSfM6YVQf5ocdcSserKIPt9OmbuQaC/Jkq5ZMw0BQ8AQyDkEGIuXMhb7zCzxLdxOBphZCn7rZlrYEDAE8gcBGLZJ9HYSEtgtGShk2kvULgKB5owVF6CQf0FSWvswS/X/ZNNYRpv3GjBgQINVq1b9lv6IYd8jol9ekhj8awoKCu7NdX1hr8PmGwKGgCGQyQgw53Ry20c8sOcjwMxScIZb2MKGgCGQfwgkVRCuSaogDAQB6dYeDAV2SQkZmN6EtBYp7R1Idl+AqX0EpvZd5WWKg+HenracDSN7Kn5RGu0aBmMvSwbmDAFDwBAwBDIDgcU0o5nXFJhZ2fH2XYCZZWKStELSGXOGgCGQ5wgkd+e/DAwviyFMSmtPIR61YawJ6WfC1J4JU6sVnkmUP49NYz8RrnLXuXPngmbNmh3OgPd72hHJiHuNoswsynRy4iu9sPmGgCFgCBgC1YsA47kOstG47DOzjNmBcTqsK9axeptsdzcEDIFMRABp7QyklX9l6b0Dg4hMpIyDNpkACDZaBwucAJP4HYztDX369GkbzK68mDZ0cc+bioqKvuX+w7jTIVAJiTJpMsf1IiQ94aGQ72DIzcSWj4YFDAFDwBCoXgQYz++nBVt6rWAO2sjYPdqLyw9IZslc5mZa2BAwBAwBFwF0SNcQf0HEHqpt0ZvVCWOnEPcHGsKek07TxZzcciGS3adhEm9DUvuZl1lRfteuXRsXFhYOoj6pEXSFophX73YLGOceps33w6DPUSLM7yVepnxUJbZx4xY2BAwBQ8AQqFYE/FMZ1QrG8OkSsLgtCjCzZASM0LoFLWwIGAKGgIsAp6/MJH45urVXwwD2g05jkBkIoxhe8alH2unknYYVhNGUu4OB6A2ujZPsureJDcOEHk2df6Xu3SikZahYR5kp3Pc+zJANSzLkbtnwxrV6bqaFDQFDwBAwBKoPAcb5sYzhElh47nMv4PkBZpbCZprLQ8Z8Q8AQSAuBpG7tSAqPhLFtj7T2LgafnsSbhioguWY/xpl+MKKS0A6FwXyyrFYQuFb13gedQF2hWwSi2jDwNPQgEuFPAjnBiPSCj3OSfnbCFjQEDAFDwBCoRgQY5//k3p55ZKkbVzgsQdk9XMDihoAhYAikiwCM7VwYx6M4WEF6sn+AJL2NcruQeC+qB3NRQbijb9++O0YVCqXVRLXhFNK+gE4I5XlRcbdvM9idhOpBO/R8z4NSMbKyyKD6fEe8kx+xgCFgCBgChkB1IxA4/Yt5Y164QQHJLBNASjFH+GKLGwKGgCEQhUDylKz7Bg0a9OCiRYuOoIy+rLtElG0G83jB+vXrz0cFYQJj0APz589/Zfr06WvdskhjDyEuc1md3XQnrBPNHkUq/MSYMWO+ctJLDaLT+zXqB265jrS79rBhw0xC66JiYUPAEDAEqgeBYm7rH5jAit78cDMCIzgFPg0XsLghYAgYAuVFIMkQvsT1L8GP7g+zegHM69HEC0J1kpVQTejZtm3bH7bccssnyH+YtLZ8hQ8h3CNU3osuoL7runfvPnTIkCE6drbMDmnyctr2Ixe2Sl5c96effmpPeHaZK7MLDAFDwBAwBCoUAcb4wOlfzAklzEMGmFkKhNUOKrRBVpkhYAjkLwIs9/+b3v8bVYF2fDifTVgnjLWOQKQ1g9dfSdfmrojsRNJqfm9EonsDzOhqVBviyqWb/g0FPWZWFg22Jm7MbLroWTlDwBAwBCoJAYQanUJVlzCfGGBmmTh2DV1gUUPAEMheBGp269atGbZhWzEYtIZasQy/G8vq+8CszeB9X0DXNChoOV1+IEx+Ip2ytQjX53pZJahPOZF2/HthPx4uxzVR1zVMXotXYx1UEwqMRcpI4b6i3rfJr0vfLkOqWlf3pZmJ9jht9NvntUvtcfIbU4c+4CXRDUh1KfcU9WopS6bIxDh7vhteQznF1yMIqKf7O3UrXBhOo2xhsi1qm4uD6llB3upknYqvgvy48hR3SWW59yrnGr88/7Mf9vJRp1i1GufVwYeA+hX7xUCeOUPAEDAEqhsBzU3+HMG4KrWDgPMzlcqAZ4NaAB6LGAIVj4D0MefOnVuXE6oKOGJVDFnddevWyS/gJa0LE1JXPkxKIA4zU8A7Ktut9chrQhmdhtKUdPmJcNL3wtr1H1jO5zq959r0RFZqp3JyXlnPT3WVd43nu9fHXBdoX0yZcPJ2tGU7N7G0PnntielDbeoS+Y5y7YmIUjqvvqj7R6WpMq8toYplSaYwKs+7R6h8Iqq88DVeeZ6PEpcgya7h6gfDsOtBWAl9Sj3f8HzMITwbkj+HtNlI1JcQNmcIGAKGQHUg8MtE5NyZMa6NE00Ew8zsR+ECFjcEDIH0Eejfv38Rgq8OMBLteeHawwy0h0HoIJ9atGO/HRuiajVs2LAGDGyCsRDzIQZDPoxs4mZiOuXCzKfKyFGfz2QmEuzHECgfApooJCHej2drPz1XYcfGPEmIdSxxgijjh700z1cez/5PbMJbTFpA2k3cnCFgCBgC5UEgPDBpRSngwsysfYEH4LFIjiJQE3uogWXyunXr+svhTOr+crHCYOATE3Vi+Zi0FuRtweS9BeGEr/iaNWtUj89oklZCcpajmFq3chQBnmdJjdOWVOuDDImvGFnZgtSc4vkKL6G+ZXykST95CWovT61du/Y9bcIjbs4QMAQMgTACkuDo47iFl8G8WmLZKcDMMsDsSuHx3gXmGwJZiEDN3r17a6djBx74rXimt1KYCXQr4h3x9YzrtKjAlx7lSCrpKB9IFHPqOTfPTffyM8GnXcto5w/42q3/A7SWeBHxz/ElcdMYoCV2+XHhDZT39EM9fcsSOqTUt9or54ZhbmRSpQ90GOmSTqdyS6jjX5R7BdIAJpWKBnxE/Jr0nsT3gVKpJug0rwnQSMprmTzRXvnJcKIfSMJXFxcXr8aE2Fo+bArq16+/O0vw73Gd577j+iOI+B85XB+lM6yPojq0bw3t9O7h35O81fTfj1Muod8KE7carZLV8+bNU14N7l+/SZMm9Smb+JDi3v4HFWUTH1PUL6YyEVa+wvq4ku/F3XzlhdIT+roqQ190XSMoMAcQryinyaZZkgJ10ib/A48+ncJ/sSGpnzyLggmifbMoN4v/ZFbLli3nYBUjYKotUKFFDAFDINcR8BlZdZTxITgxkxYeyDTpmDMEqgwBGIk6LLcXaiKXz2ReKCmpfBpRXxO4JnMmNk3E3oaaRJjnWc+rGFePJO1pyTXSK00495l3w15+NfniiDU5iyGULwZzLf1bByXCyfQScafsMsJi9iTpWiwCM0m+EmlgthhaEnF0K0WqxsGg7E5/htO2rUu7I2Xeo+z9HHTwwsiRI6XDGXavKIHnpRnMzwkEr4aiLCFoyfwwqB/0OnXei6WDdwhHf62QgVTwZ/SYP0X9Q/+LN0i2at68+ftVaGtWG+H0n1apo98yQ5b42OPG+vATdYQR1sdfgvhv9C5WphPj2y5JXXUj7i0voX7D/yJmdxHRH0lfQHsWRIV53hPpTZs2/akK/zc105whYAhULgLrqd7nVxkDpOoUcDUZJH4ZNUhmoLiKgf9vgRIWMQQ2AwGYjy2QQHWCwezEA9iJqjpCnXjWdiPegXBg4w3xbHdaLp1L376lj/Lnej4YzIURm4s+YYmdmNneabf9/fr1a8mHyVWknQOl+n+FwzMwIY+AyUduHemEGbv2BtuLKHscOKeS1s6k3IN8JD0Gcy+GJ9JR3w9k6IMo4cTQcdTut148X/2uXbs25h1uAX5SrWkB1s3lg0eC3DBp+sBUujYfeh8GBKvO0T6tJCzljmKAE0Sa/CW8g80JLyNf0v+Pi4qKZhvjW3X/jd3JECgHAuJTJfTxmVnCQ9iYeo1bl5sp24punoXzEAGYzzowFzsw0Pem+z0Y9GcQ/gFay0Qg6ZFE/FqmbyiftISvOOSlN+S6llAbykiK6i8rUibhSPeC1eXrS0+MZ2JpmH4kls1pV2JJWOkeuWkqR1zL84vpl6REC3lvFrIcuhBGdSHMj5a589Ix4MiywkUwshcCQJMYECRtHk3ekzBHIzdHcsxg9gH1/A67tZfwP5wDnUXdktKH3bbk3Ui7rqWNUl946I033hhPIf9DPnnBHHyfmaUuSSnznpmdPHmyJMaiWVBaThY7li5d2hSsm4BjU7BvyoWJOH4z0rvjt4GE9w5Qqo8estN33E8TWbMkba0rSZPnj0Pc/yTFkfqu5ZmYS3A2aXN4v2cT1nMgmr1y5cpvk6fZETVnCBgC1YRAmGHQfB1wAWaWFz7x4gdKWCTjEYABrQ8Dui8NPZkBuQH/46cwWLJZqaXrxBcN6U2gxgzW8hNh8sRwBMLEG0OaDBKOsgmfsv5EkMxKTBBevpcmX2XlovISGZX/o6V2MSGakCQh/RY8/DDSmLmmg1dxfwK73VuAr072Oo//XExElFtI4rVI+J5PJR2NurC0tPHjx8+jzBW8B9dR//G041zinSOuk37rceQfBwMzk7Y+imrGE8nrVVzPyK8UkCNfKwfmyoFAUtopybsoyt3jJSLJr8fHoFQapNOuVRtRIkwZreRsCVUYs+vdN+lLJWkbEfcsMWZhdWQjz0oxed/TtvlJX6cRLSe8Uj7X6gNW423Cd+NKY8xdsWzZshXTpk1LCAPIN2cIGALpIyCGQnO6VnwSjveqlhf2/AAzy4u5i5dhftUjwKDenkH9Cu4syaaWXRMMKf9LY6g5g6KWyLSM51IRcTEQ/p9LmUiGkjr9wVphz7lhL60KfTVEkk5NBPJX0R5JSxVO+PQ74SvNCysP0mahBTBSCV05GJMFTD4LYnQuKW6uIhFgkhcTMBg6lf9Bkvko9zWJf0GK+nJUZkWmofuqZ+JxEW3bH19qDsdC2uwUdtvS5r/z7FwLMz4W/zHi37mFeJ4kmTVXyQgkpfMzuI2ohEuuFrXgg70l46MOAGkp4v9K+AozLiTSubglpPHRHw9LVFi2BH3NS7VCE+mu+ImruXfAT0RCPyor4tmqwQd0wsIDcW0s1IEl8wjrIyxBlJmHVQeFv+c51qqROUPAENiEgM/IKol355cXcVN+jYDOLOlLGCy2sJfJQagCgpJcgf0QqhLj+V9IjJuW19oxqMkWaTvC7ZNpeDnlpLs2mz7Ooq+zFcafJZ9l5lkVLaWjXnOVi0DNXr169eQ/PI/baKNVnMRMHxjXIym9L8msVG6rYmpPSo1Ppr1nUWTHmGJe8koCUpXx3N0w4ed7EfOzAwFPxQHVhiIY4CIY3SLGH/nNiR9IL6T7qw8cqTe0zrBeiUvWcyiJr6S/y2l7Iqy4F1Y6tEJxSAKAOpAOW9FmWTHdUucZjz8bHOZhMnCeqUuAoLmsRADhhFY1fOErz/U5qIrd73bGU6wt8BIp1I1Ck724+WVDgMmzNRh+71ylAUd6oxUlKXCqrpSgBtM50DcQzd74Ge1fiV8X33tONNhKarySwTPhe3H5TBgqX4wO6Q8wMmJmzWU5An369GmOpFJ6hmIKd07RnZ/472/l4IihSV3LFEWrNEtjnRiZM6CjoShpbbhBn/N890cPWu+CuRxEQJvb+KjeirEtQXRR0nifSJegwRv3sh0B6RlKNcIbsxPjOHGN115YjLGOh25EuvZDNFKY67TyIhU0CWTEVOh0F22q89QsPD+hasE1CZ/8FbxDNfmQ8NTZtMrohZuQL9oCEsaSSC+ENGcs84jyS6lPJga1cU9MTUL/Wj7xZtQvX+1qA6medZT9kXsuIU+rd6pvCaR6EmHSEz5lVpMu9SPPzN2WlNmJ+FvQm+hUf2HqISBRvc7jU31mluaU2ACmQt+R0dZrKw/BuTCz93hx88uGQBjPsl1d7tLavauNWpKGyWTF/4iL+UwQ8fXENRBI10uDRMJXnJd5GS+2jJgvRYq2jC/4pSaZByFzNYYMGVJr0qRJPYHiNOhIKJYB5LmayzN0Owzvgzw/mtgy1umUNp7z39JA9WvvNBoqveuzsPQyOo2yViSHENA7MHHixJaMkW15ttvynLeiex5zJwZPDJ98SfS99MRGWCdPm+DECJZYGiXNXGYjsIHmiQlOmD8kvMgJJ9IY96TPKea9HoKchsT3IryaZ+Z5no1puW69hr5WthOfqo8YdxXwUlbNbnBvrEKSxPmOP8rMc/lolD0AnpJqlnfjiL5MxZRqSf4LwjJurq9kMaKLCGsjwiJeEr1QxQyui7C1Xvzjjz8utq/Hsv9XdkU0Aqwu7MIz9n88Y2L4JKVK5T7guby9WbNmL2TjpjpUJvZi8jmFPpxIJ1um6ih5H1Lutmztayl9s+zKRaAm75X2PEjy104+txO1S/peXGoP7qRN1FyWIyBGt5j/PDF/K6z5mzG2OBmWhFtOUmp9XOvwmWEwxu+zKvSjMvLdwVdJYu/rzYLP5QgXrndxETMrQIu8RApdRqF/eHHzy4ZA586dG6DsP4urSpsYS1TM0mxHJGFihs0ZAlWKAOOAdpMfz4B7PDcuTVqpgx1epvw9fB1PqtKGVtLNeG8LeG8HUv2LadxiPmUeZLJ5AKmLwuYMgYpCoBYb3hJS3nr16jXiQ8td5vfCjWCEElJg3kH5hdB63kmZT1xPniwzqA4tobcmLOZZq69aTjeXXQhI/UOrrT7xf0pVRCsE+k93hPT/q5x4h+8hMcA/UkZ61W0I64NJ5bQvR7qD88mT6pTGLm1I/JlnZnv8XxNXvVLNkJDiS/xC/KNI0z1kzUP651plkODNX/Yn7XBW9EeQVimO+SkgdOUmVzD3/N29mZjZ50k4zkuksdfCzF7txc0vFwK1wfVw/uATGFx0QpMeviKw1TLTNlBT4jsRr+XVTvhhcD/Ti5tvCFQFAjynu3Of4dDWadzvK57bh3mmH+dZ/SGN8llXBDw0aTRPs+HrwGM4eDwIHm9yTXjATbMaK2YIVD4CMMn1YZBlurEhm8Ia8DHWgOdXtsLF+EpdQnk6ZVEmHROby0iXVFF6rwmdWK5f3qZNm9XTp0+vj1paQ/ZFJK5NXp9Qu1DYJerfSN1aXfT0XhM+K4vLaMMyhDjLGjduvJI21WcDemPqlAlJ+WLmpWPbmGsTRFg6sQl9V/wlLlFmCfrPy2lrg1WrVjXBl6RTc20T6pGeruKe31RplJHqVOIoanxZzamLvzOkd7kj1Any52nC5qIRWA+e22HmcHZ09ualMi5LzcBlnktsAFOmNkP4jj/zSz9igfIi8DNfDS9zsSjS8edIaX0P8N6Oh+DLFi1avBtZ0BINgUpAoAyndGlSk7TyMb6838HPaYaNd/Ix+vsnB/KXiJO88UjSwsu/BaQfQ/4xvM9fE36cyflxOzXMQc+CGYMAuuyS1IqKK6BRYi60/6Ii3RoqE4O6uU71eEv3m1VX0iyc5modo91MvohKE2kww15cDPxq5vI1pEkwUARJginGuBDKdVeHfu9HJyuDma0ZBo//QBLngBMzGyhIg/TVY66SEYDZ1Us7MUmVfDer3hD4BYHkR1Rpp3Rpp/I4mLSnkZb8K9M3dFXwfysJq8vM7gITv0vPnj23hVE9n8nqVHDRJBV225B+LflDwHg8mU8hZXo5z7ALY2JxQyCrEeD91XK6VmtE5XFa/ZYEuDnjQcJUHJXoOGjfXBzjhhhfCQmkKiBGWNJkScx3jhlrKJJxbh2S+imV2CpfKqt7gJ8+WAJOBd6CDvZSBSDhV724+YaAIZD9CCTtrV7AIHAeA6QkC1FOZrX+RsbzuapGENVpN40lz8mFhYWuPthOkmJjYm4m5S4gfCWT0u/A6Q/Ed3GvTYa1JHmICEnOvUxkwyn73OLFi8fYJs0ItCzJEMhtBDYmBVcSXn1T1q4OHDiwMcdC64TF5iLGEoUL4dMWEv4RtYof2QS+eMWKFQ1Ib4nqRkvGdx0ioj07DfkAl4my76H5hL9nTFrH4RwtCbfheulTt6G8xiwd5TwLhnSBVD0Id6K+TqRLDUO24ecT16l8qldWkKSKpY1q25K+kvs+wBg5l7TKcrIq4at70A6pgwScmNmPIZ+ZpXH5IBIPgGARQyBXEYCZ2oa+DYZO5d3WUliU+5rEKjmlK+rmmZQm27hg9gFt2jfZrpoM/l0Jv6J40m7yPQTvRVrbnUH1TOgY4hr0w054n0j+iWwuW0y9n/Mf3MWHgvYpmDMEDAFDICUCI0aMkCqHaFbKgr8c9/pdKWW87AUEPvMiMf4nEekTI9KqKims3qbVw4ATM3usm8LA+60bt7AhYAhkHQJZdUpXBqI7mTZ5zKyOTvSZWaetG9ns8A7xd7p163Y+0hFZgjgFZvXXThk3KGl4F8p0gam9Cv8mVDieT+oxuuUsbAgYAoaAIbAJATGyi6EWXhLjrCS1ASdmtp2bgvj4IzduYUPAEMgOBNxTunjZpS4U5zL1lK649lZpOozmFPC70Lnp/k64RBBzetpscp8oTRu9O1P/Yyz53YSd24e43/22aawErJZgCBgChoCHgM/IKoExM7DXS2liZhdCWygiR5nt8d5PROzHEDAEMhoB95Qu9JaOpLFRy92JPvBuZ80pXdUJOkzmVKSmbhP20a7m5GYQN71EGBUCLd9dBl0BY9sVzI8nLNOHgcGYuFxLmNrLoIuR1o6k7H1sNnuD9PCSWqKw/RgChoAhkKcIuPsYxKeW2JBXh8RnGUzP9wBCmXcfwi94cfMNAUMg8xDwJIBIBX9L67YqpYUf8J5n7SldpfStwrO1kQHmUvpnOpVJrgEbI3bD/zARS+9nA4ytdMwmwghfAIMsG9JnQ7tCtSHXKX4E4/AR3Hcm/9WDkEx8/egWsrAhYAgYAnmIgKSwAUks42NJ01wMoIEBEzWDlEtqeQikddkQyAgEYHQCp3Tx7qZqV86d0pWqs5WQ9x/qPNyrl3GxM+GyMLPepTWSEt2EGkLv3r23pi5ZQjgdKvILbQpsy/96I/Q3/u/hDNoPd+3a9U0k8CV0xDZdYiFDwBAwBHIagYAAgDE0sHSmntdisJShW98R30NLl36CBQwBQ6BaEejRo8eeMDayODCb9/NG/L1TNEindF0CM7QVK9YnYBZmUoqylhWDAPhNc7NYsUqFuVs0ZRhp6zf8J3+hvg4UPIv7fBRzgUzPDCJ/DBYWZvL/X431hI4xZS3ZEDAEDIFcRSBKalNiNbIOg6XMxAxwUGjG4NmFuHb0mjMEDIFqQgBVgtYwpkO4/VlQqg/MvDqlq4r+Dpnn8h3j5F5+pAICMLUrqOYhEdLaA5A0SAVhEFRC55l7dyJ9CAzwVTC144k/3qBBg3+NHDlyJenmDAFDwBDIZQQCKgbqKGNgCQa3FlKCZ8n7MoSENoGZMwQMgWpAQFYJ2OV+PYzsV9xeTE4UIys7e2MpcxJGrtsghT0Fepu0Ei85aebKiABGxcMS092posSgWsZqI4vD2E5hHD6J8bk9BS6Cvogs+MtzcAj/+dOcPT8fxvYRnpMDKVsp7YppgyUbAoaAIVCtCPBhH1CPVWNqDho0qPaiRYtWE5ZlA88dxuD6mhcx3xAwBCofATYKbQETNRhm5Y/crWnMHfP+lK4YXCo8GUaxGAazyKsY6WknbMvO9uKV6NdEKt+N5+AM7qEDGRqkuhdtnEXZZxjgn4YxjmOEU1VheYaAIWAIZCoCspu+nnHOF+ow3l2L8OZqt8EeAxv+sm/oFrKwIWAIVB4CyU1BksidCsW9ezPI0yldwyuvJVaziwCD53Ti3bw0PjR2JVwVzOxGzxIC0tfzacfx3Pc0BvDIAxlI70T+5TDbl8MEyxrCe2vWrLlg4sSJC0g3ZwgYAoZAViPgMrLJjpQ4AazWsGHDlBjYJMKFGrTNGQKGQCUiAOPRHWblRZgQMarnQlGM7PcwJ+fOnz9/N2NkK/HPiK76czeZ/2knN14VYf7zJTC2D0D7Jcflm7nv/Lh786xsS94J9erVm8ezdQ+bB3eMK2vphoAhYAhkAQIlVOcYC9uF252QzJIxl0HQzyNc4mI/0wKGgCFQbgSQwjaEKTqRCmSeKdWmIknVbmbp+N7kZqFy39MuLB8CjItfhMbFamUMYWh1IMNfUQ27tLi4uBdt+x3xI6AoNYQC0v+ANPkcmNqx9GVo9+7dXzcTX6BizhAwBLIJgU3MabLVjGcleNQ6SZ1ZnVDjOwbJ8OYHP88ChoAhUHYEYCj25qozk4xsnD6sdmnqw/JWmNiHjIktO84VeQX/Q3hj7A4VWX9560qupo3m+tEDBw5svGLFiqNo6/8RPxgKD/yK9yG/DwdsfIPu2QMc4PAoB0PoY8mcIWAIGAJZh0DUBrBInVkGviVZ1ztrsCGQYQhoQxeMwwk061RIzGys4537CEb2tubNmz8Ps7I2tqBlVBkCHA/8FZJN9377upFMCI8YMWIZ7XhCxAeTbC/eBh0ERR2fuzXP2A0c1XsNZV/imXuQTRTvULaElIM0c4aAIWAIZAoCG2iIvwGMcIkxK/EVj+7eOwxs3Z1Wn4+u1t1O3IKGgCGQBgIwsPVhgA7jfZKkrB8k4/dx7meYixFk3s0S8oS4QpZePQjov+RjZFXo7h0ZG+eE0jIq2rlz54JmzZodhfRCm8cOSNU48r/kWX2Ysk+yElDC3E2qay3PEDAEDIEqQKAmH9/ruI8vWWDMuo0P8T+5905IZsnwziD38pp7AfMNAUOgdAT4IDyG9+hPMAe74jcu5Qpt4HkEeggmNqMZo1L6kdPZHEO7mkF0IZ3cwusoaiI9CT/uxTPRnzZtmgb+F0ToaHemzX8kLIsIhVDA8axKD/hmpNDX09eRPL+PER6dPII3UNYihoAhYAhUAwKSwkr1dR/v3oxTfQkHmFlPbKsdsL5j8PPDFjAEDIF4BGAWOsAEvApTMIxS+6dgZGU15DXyj8Kus6R7V2a6hC++1/mTw/91n9tbJJi93Ximh5G2TuM5O43BvwN9+TPtleWMEo48bRiT7u1IpNFzeKZv5tnerURBSzAEDAFDoOoRCBwvzji1E2OU1Kp85+nMLiKlyEuloOnseWCYbwhEIMASdDMm/YuRYl3A+1JC4uVc8jn5jxN/mmWR75x0C2YBAnzYj+L/u9JpqiSzUs8qobPllMm4ICsAP9GoW6Hb2ATWE+b2LMKyhBClBtOW9D/T9z8zYbxP+CnKP0cdPxA2ZwgYAoZAlSLAKZeXMd+e6d2U8agW43JglcxjZsdSyLVoUOJ8cK8S8w2BfEYAJrYROrHn8SJJytUcvwQcpC3gZXsG/xkY2P+WKGAJWYMAHyv/YRDVhljPAkVrjhveZcyYMTpQIRvdRp7JcTR8XL9+/VoySegY3dOJ7xzTGS3t7cOzfDOM7Zt6rsHkFdQQlseUt2RDwBAwBCoUAcabnxh/wnUG1GE901xHu6VYSrMjEV1ALJz3CDDxN1m7du0fmdQHA0bLKEDIm8tkfxObb+5Nmk+KKmZpWYSAdEcZRCfR5P5es2HmfkM4W5lZrxs1kua5JK29lT7uj38qJKGGx7gT9J0EH315xvvC3K9EujuCZ/35goKC0dSzxi9lAUPAEDAEKgeBgEUDxqIm7m08yWxAvMQgZTYIXZQsnLcIoDfYiuXW85Fg/YGXx1fFCQEi9YEru3bt+rgZpQ8hkwNRxkNZe/GZWbrUFQro0mZ7N9Gr/Td9+PeAAQMGr1q1SuoHJ0EShfg7iAl7rgGYaEPZ8Zj5Wszmx1cIv7B48eJxyc1nXjnzDQFDwBCoKAQCql2MQY3cihNMrJnmciGxsCGA9fmDD94FHAbDxMjEVpzazWJeqJtQO7jLDjjI3acGKWRX/mdJZz03E+ZvOy+Sqz793pJ+nwj9H+/BnqX1kzKLKKtT0+5DleFpygcmn9Kut3xDwBAwBOIQYPVIm8BciwbT0eP3N6kmmFkKfUUh16LBEAbra+IqtXRDIBcRQKpaa8qUKf1ZRpZOrKRSgRULp89LmLTvXLNmzR2cqqTNk+ZyGIEuXboUNmzYUHqz2vEvt5EPmC3Qmy3+JZr7v7JswArFb+mpDgHpmEaPZ/KO3MW79CSqGovTKG9FDAFDwBCIRQA+9UEy/U1ghDfUrVu33euvv/69LvKY2fAX9A0ws5eqgDlDINcRSKoSnEY/tcN76xT9XagJGiZ2qDGxKVDKwSwG0g/o1l5e1/Sxk9xI5SXli18Tie0BvAdSMxgEtS6l4yvBahjlH2ZOcaXbpVxm2YaAIWAIbEKA1dIWjCULN6UkQqczrjyqUJ1khiQM7s6wgC5Csox5hkDOICApLAxpLzp0OhKnw/GjTBR5/f2GwO1sjHzU1Ak8SPLODzCz9H5PSFYB8s3JGsJkOj150KBBF6InexCM6rFMMoPwo3TKpV97MuVP5oPgS/zHed+eGj9+/Lx8A876awgYAuVHQOYFGUMCFTDu+PO2J5m9jRLape05mN03NdGbMwRyCoGePXtuyxLxyUyw2uBS2nLpJMrd2bx583+ZdYKcegzK3BmkkRfwLNzhXUj4cQbXU714vvuYrKuDZYMzwOX3YCE9Nk9QEgWNDhB5E3qysLDwlZEjR66MKmRphoAhYAi4CMDMyl62K3hVto7hPisx4DAAbQeHq0TP7eAFzDcEcgEBlih24BkfRV+24XmP7RJ5qyj3HNKje5AevR9b0DLyCgGei4ApLp6ROLuseYWL11mZMCN8vwg7vG3RldWpY2eAUyfSwk4WEvqIVq5cuYwPhZcJP4tJu3H20RiGyuKGgCHgIcB4Mo5xRepNrmtF5OXEcbYUeN7NIbxV3759dWa3OUMgqxFgKbQujOylPOOf0JFtUnTmc/IGY0OzPasSpxsjmwKpPMxC6vhFqNv2wR8CxIuyMW4+79Dfu3fvrk3FfSEd9Rx5qiTvZWMmp5OhMRzzPA/Jy90wtzJ9FpCuEDdnCBgCeY4A40TcZtJa/oDBIKLduk0crH7PgKTdY+YMgaxEAJWCAei53kLj4xiPFbwcw5hQH+FZlx5gvMg2KxGwRlcgAjUZI3XqVQOvTtRVWuSTRQOv3+XxUUPYgg9FWUI4BfLN66So61vyXoT+ybv5Lr69mynAsixDIB8QiNkElui6y8wGBgsm+QvQCbsrHwCyPuYWAkh2foWawI0wqTq7OcpJ7+bSBg0aPD9ixIhlUQUszRAIIwAzK1UD2R9OOJ6xzibB99BI3wfH3Sn9O+hEqF0aV37LfCRVhJeQ9k62g0nSQMyKGAI5igDjR4BX9brpKukvItHfjQojUM8rZL4hkA0IJG1hXsPEdyTPr/+h5rRdprX+zEfak6RFvhBOWQsaAgEEeKRm8/z4zCxS/w4UML3qAEqlR5C0SuXnr6gAXbpkyZID+SiQ/dqjoGYxV3cA+wvIu2Dy5MkL+FidwTX38h4/E1Pekg0BQyB3EZB+vsu7JnrqJowl5Tiv/wzaZp7LA8P8jEaADSd7suHkcia4o2loQg881GDtnn6QZ/pKJkBJZc0ZAmVGgOdHagau25vIcDfBwukjkNzsNZ4rxvfr1+8PHI3bF4yPh3EdQFrDqJrIb0l6S8ocgITmcsIymfesmcyLQsvSDIGcQyBKSJXoZIKZ5Qu5Nsr3YgR8xwAR3vDg51nAEMgEBJDE/gYG9mIY2X60J+4hH8sE+BeY2I8zoc3WhuxFgOdoC5govwOEZb5wiJ9ggXIjMGrUqDVcrA+D4QMGDGiAlYNDwVe7lvtDkYwt6bIo8SBjwM0wti/w/8hc2lTSzBkChkDuIrBpEHb66EpmAwUYGBY45SxoCGQEArJnyRF2x/B8DmYS+3WKRv2HvMtY0pQ9S3OGQEUg8BKV9PAq4hmUSRhzFYxA0u6sNn+9KMZ29erVMuMlNYSBYO5uUvbu3JTAWTC/Z8HUzqDMc2zOew5prQlkPITMNwRyAwGpB34E7RPujs/AskvsHQaD7k6B8+ED7nbiFjQEqg2B5JGzZzJRnc1z2j5FQ94n/xpOKRpJGdOLTQGUZZUNARglMU1SU5GdVDkex40tTXXlFzAq+1dm9oqLi2W79vfcazcoSqXIbcYnRPQB8nJST9fNs7AhYAhkIQKMw7KydWa46T4zS4GvyJRdQM8NYQC4xouYbwhUAwI1YWK7I4E9m3tLMhO7KRGmYgqT3PU8s69TzpjYaviz8uGWbD76L89aZ6+vPJsDsWigDydzVYgAZvc6ogqnj9vTee/bpHHrryk7krKvFhUVvYO+7to0rrEihoAhkGEIxJnnctUMXEa2BoP06gzrgzUnTxBgM0gTNoMMpbs9eQ5jTfcwMW1ggnoVugXp2MQ8gce6WY0I8KxN4fY+MwtDtR9xY2ar+D/hA2I2t7yic+fO17Ro0aIv48TJxA+D4j54t2G8SFhEYH/IUoQ344mPQR1hNG4W15kzBAyBLEBAK2G8vyVa6jKzxeQ290rwki/xwuYbAlWFAA9pNxjZV7mflnTj3HKYiiegu3iw/xdXyNINgYpGAAboPZ47t1qfsXUTLVw1CEybNm0dd9LHxMj+/fsXrVmz5kj+H1lE6EGaO7+5DZLe7RGUO2L9+vU1GHNmENcxmePwJ5jaiAuVhQ2BjESghHku/2XnRV7KAOAzs3zpygSKOUOgShDQRMRGj39wM+nCxOnCfckzeh/PqnYt28dWlfwzdhMXAcZF6WS7SXu6EQtXHwKvvfbaIu7+qCh54thAwkdCEuPUh+Lc9mRsz/8qdaYNMLfaOPYj8Uf5sH7urbfe0sRpzhAwBDIDgcAA7DXJT+QFDogbYBiuhWG42itoviFQGQjIOgGrANqJfA31bxFxjw2kDWM590F2J08gHHhOI8pbkiFQaQjoecUt4wY+c8RYuYVJ8yoN8s2umP+sEf/ZwfxPhzHOHEqFW5ah0mKuGca1LyLFha81xrYM2FlRQ6AyENDR4lqR8TbiJu7hS2aJ6au2KJH6y4/pzDpgWLDCEajJZhqZ2LqWmneKqF1M69vQyWzqmhORb0mGQJUjIGaG5/ZLnltfIsuHlp7fyVXeGLthWgjwn+mwi+FJ0rij/64PUvbeMKrdCNeF4lxz/mtZT/g9DPFPXPsqdq2HE+bbeuyKuIss3RAwBCoNAfEGH0EB81wuMzuWTP8EMMK+5IGwOUOgohCoxW5EWSa4wmUIQpVLD/b3MLFvhdItaghUOwI8t3o+fWYWpmg74sbMVvs/k1YDNmK270NKim7EWkpD/j8xtAdDPaG9oTg1pxb89yfz8XIy16xCOjSB+Gui5IY0LjVnCBgCVYDANO5RkpmNOQFMSvHmDIEKQQALBfXQP/stlf0Z0sk9UW4FE8P1HIpwa/JEoKgylmYIVDcCM90GIN3b2o1bOHsQSEpXx9BiUQ2Oxm6O5PVEghqrNE41haJcIYk6pUx0D4ztZ/ijSRvDOPcO0mBb2YxCzdIMgQpAAD7hUt437a/xnSuZ9fVnlUtB6SSYMwQ2CwEddsCDdzYD/NlU1Damsp9Jf5RnTraNv4spY8mGQEYgwHM6m2fabUsHN2Lh7EVgzJgxsuozVKRDGpYsWXIwUthjiB8OtYDi3C48E7uQeREqCKtQR5hE+E2elXEHHHDAB0OGDJHuvzlDwBCoAAS0R4EPyEBNPgNLxlvkHOjl8mLaBjAPDPPLjADPk5buzoGOhuJsP2qAfwFJyDUTJkz4krA5QyDjEYBR0bGq0sFMOBiWUSxda2ORuRxFILnxT2OamFpRWaTxxTwvb3PNWzwrE/hg/5Rw4GuIuDlDwBAoAwLwGDqN0bfA5Utmednm8qL5VRG2l81HwwLpINC9e/eWqAj8jmfndMpLShHn1lHmWegGlvlkBsecIZA1CPDc/sB46beXcCs/YoGcRCBpxeAtOica3KNHj12xwqIPmP5QV8ifSwmHXXOemSNJFMmu7UK8GaT9DynuFahUzVW6OUPAEEgfAd4f2YYe5F2ReAGTOrPu5i/lf+wV+v/2zgTeqqps44hymSS5OMQkg4BDOBUmIqCCIiKR1peZqVhmk4aaFpWa8uGcfg5oOVRmmUPgCAo4pyKoiTOiooCASogIKl7Age//HM/e7rPv3nfAe+49w7N+v/esca/hOXuv/e53vetd9o1AGgLZ89I1qY/m5tLEXtPOYNky/gs34KVIsmyhIA1Upxc0AtzDkghEXWU04nDpI8BK0hxGKboA5lR6tftyX+yPSsJw/B7Ea3JbkLkF8+AA1K9Gc/1DXHMT4VtgmsXo2hkBI1ALAjw/K6NFol+Tn4tlKcHDZQX2KFIO5yCQ/QA6j6MhT+Reid5HOeWyEe3+vrxFixZ/RwrxXlIBpxmBYkGA3eyrUI2JdlcnStmVKQKoDaxi6LdmqRlqKH140e5HXBYShkDhUijhuNN7dx/Ky4Dx5Vz7IOFJzJW3M1e+HS/suBEwAp8hwHOSswksZGD5OryPInr4AjeWh/SCIGLfCAQIsKlrL17ml8HE7hykJfhSJbiDG+4q7qP7yf98XTahsJOMQLEgMGrUqDZVVVWhjVHu83WsNKTphRfLsNzPPCDAxq/mM2bM2IWq98nSXvjtodrcx8ydD/PhdCtz7e2Y/nqjtgucbwTKDQH41pCviErUpFYQMrM8SDI9YmcEQgSGDh3aCz2x87S7lxd4mB4LzCV+DffPdTCx/43lOWoEih4BToLKEctyr0u1Rg9EOLEW/SA9gAZBIGvF4GkqE12sFa2VK1d+lXtmLPFdoT5QktuEOXYo5YbC0F7GS/sJwneQdjvzquZYOyNgBJo1+xgQMnxsyJHwsCwhsUsEnaN5aP4WiTtYpghgI3ZLXuCnMpnKOkGSTqxe4nfA5J6LBOGJMoXJwy4TBLI729cy3NC4Ph95fTDr9GqZQOBhNhAC2LXtjeRV+1VEO9WxWt1nU5iPp3DtI9nNaXW81MWMQMkgoGNt1zGaHGZWiXE7eINhZmeUzLA9kHojwD2xGZKAk2FSpRfbLqECMbH/hNEdy4S6NCHfSUagJBHg2XiKgX01MrhDmS8nRuIOGoF6IYD61vZa9YJJ1cqXVBPq4rQJ5h7oLvRsUbO1nm1dQHOZkkBAfKvOQ9hYo8lwtPhiSrRDNzQKzQMlfUgzs4BQbk5MLP//8Yz7l/iVTKzVICDtCaQCv0QSO7NaphOMQOkjoD0GITPL86AlYzOzpf+/522EWTOFZ9HAWVmJ7bcIf4t7qz/zcLgKEOuA9G+/K8IawqdsIHsShng610yrrKz8z6RJk3JUYmLXOmoEihkB8a3/gfbQIAJmVuE7oKMVyLruQcB+eSCw7777bo5+1glMnGOYDDVJVnPkLSTvVDa83EimbiY7I1B2CPAcPMtzEI6beF0laeE1DhiBNASyKivagH0BDGpn7q9RhA/inhuKn7bZsDnldqfM7pQ5HUsznyCYuInw2dazBQW7kkIga1Fpt2BQITPLQ1ARnZwJvx8Usl/aCDDhdWOEv4SO4T7YNGW0y7gnzmEp60qWsqQvaGcEyhYBnoW4He4dyxYMDzyvCCA4eJMGrhKhr70pJrz2J/wNaCRU04EdWn49XMQcPwv/WlTCJqISJtUEOyNQCgiEEoVMIMvhyq5syNyyhDwSw9BTS2G0HkMyAlgn+BqS2JPI1TJVi+RSzXQU44XcD5cxCX6QUsbJRqCsEGDOrEDypecheG7Wt2nTZrPJkydbCFBWd0LTDVZmv2bOnPl15uYD+bjSwTX9oPDlntIzvefvgm6AsZ3KnG578ilAObnwEeAjbRG93Fo9jTKzkrZlFGmVAQMz4v7775+usF3pIJA1DaOz5U9gVHvXMLLlTJAXy5A3ktj3aijnLCNQlggwkcpE0vbB4HmmdmfOlA6XnRFodARQE/syc/ZwGpY0dj8oTc826Nsq7tkpCDQmMc/f7RW3ABb7RYJAojUDnRetDQ2hnVnCPjShSP7RunRz4MCB7Vq3bv1Hymqyq2lp6g0muIv42r/akti6IOsy5YoAc+ZtjP3gYPw8N0fCzP4ziNs3Ak2FAOoIrVAJ+xabwY6BwR1CP2qU2HLvvk+5qTC2t2NmbqoFGE31z7ndeiCQaM1A1/vQhHqgWExF+WL/ChPVDPpcWUO/XyTvQnbAXs8OWNluszMCRqAGBGAAXuG5CksQ7h1GHDACTYhAVn3gRrpwIya/eupDS0Q88R7l3pXpxUNhfkXr2HT2EOUltb0TKwsLmnAobtoIpCGgDejS/85Y4dokUkp6k6Hj5l4cRhwoVgT05fILOn8e1CZlEPfzX1/EJoNp5Ns6QQpITjYCcQR4bnIOSSDeK17GcSPQ1AhkmdHx9ONM3gcy8/U97lW97zul9K2CMsPIGwZjO4Fr5lJ+GuHpFRUVD1sdIQU1JzcFAhlGVg0HzKzEC9HTv5Q3Tz92xYkAX+M7MvlcQe8HJYxA535fywQ1AZMtzyfkO8kIGIFaEOD5mc9zFJYi3DOMOGAECg+B9cz3j9Gtx9g7cTLH6g7inv0O8W9DnWvo7g6U24H7/SRs2a6GuX2JsnNgbH8zderUpTVc5ywjkG8EPqaBDB8bMLOakX1oQr5hb4T6R44cWblu3bozYGSPpblgp3W05cfQpTqEr+sl0USHjYARqB8C6JUvZBk2elGPaMRhI1CoCGQPU3iI/olOgEHdHV/63wdB4aZGwnHXlgRZTejHe+YIrpsMo/v3pUuXTp0zZ47V0+JoOZ5PBCSEDV3AzCrBhyaEsBRfYNSoUW3WrFkzZu3atb+h90m6sav4sh6DOsF1xTc699gIFB4Cm2+++WLMc+kY8ICj7cjGm03QV5S0wM4IFAsCnwYSWzr8W/ZYbIufsWPLO2Mw4SShiMam+/5gyhzcqVOnd6BJMLY3sAlyBumfL1mopJ0RyA8CIUMbMrPchD40IT9g57VWMbFVVVU//fDDD8cyqXRMaexOJEjHojtlPegUgJxsBOqLgDZKIplaxnXBc7cxS6/SQ/RzVl8wXb5gEIAZfYXOXCQaMWLEl1At2I/wAVnK2PQkHHfSXfwZ76Cf8Uzo/r8ZmgiT/Di+GVtAsGtwBHRf5W4Ayx6a8L1YU0/H4o4WEAKc3d0Bo9fHwciOoVtbMolU6x0fKFoGPQlprEwI2RkBI9DwCOh0poCZbcZzaGa24TF2jU2EQNZE1600L5IJz514r5zOfS61BJ0cmeTE8OpEyV9mGdvbCd+KpZxHsuoNSdc4zQhsCALVNoCpkhxuiBu29YbU7GvyiwCTww60MAZ9vdFMKNJfSnIryTsXZncCX9lrkgo4zQgYgQZBIGcDDLrqIWPbILW7EiNQQAhkNwwfoi5xguTuvGf0HpIgLGQqYt0VYyuByxhUcpbz/ppKeDJCmHseffTR92NlHTUC9UUgdwOYvpa4yaTnsnekpp0Ia6nArokRkB4eTor5P4eGQjkfHpHufcDEchnS2AvvvvvuFZF0B42AEcgDAnz066S8aM1py7DRMg4bgaJH4IEHHniCQTzRt2/fkzp27Lg/z8FhxPWeShOybEHeaBEH+KzFlu3DPD9TRVnVBrLsjECdEciZeKM6s0uikzJh67nUGdP8FORh78ODfjS1HwWl2QRU49IbuRxJ7KVsPlmuBDsjYATyjwAfjp14RqMNjSSik/bsjEBZICArBtCdDPZO7eFg/8aB8A8y+aVNZGmMbUuem4wtW8pezKaz1ym7CLoaxvZ6/JyHiridEUhCIORhM4Gszuyh0ZJM0i9E4w43HgLaTcoDPo2HfZtaWl1EuQlIbf/s4wdrQcrZRiA/COR8PPLMWs0gPzi71iJAYMqUKR/STa3o3jxgwIDWbdu2lcT2YJ6LUaSlqSJI17w7+aLBrBKfhX8lx+r+nRXGtwjbGYE0BEJrMhkxbZaZXUvpjSNXHIp+zMRI3ME8I8ByTQXLNSfzYI+jqYoamnuEMpexy/Q2mwGqASVnGYE8I8DhJP3Qk30y0syqQYMGdRg3bpwmWTsjYARAQKpy2DcfyLMyineXGFuZ/6rNSR9Sagh/44CHu2bPnv1RbRc4v6wQ0AmnuicyfGuoc0Div0ncO4CCG2g84v4zgrj9/CKASsG+YH4ZrWiDV5KTndh/UuaqrBJ+UhmnGQEj0LgIaEKVeS7pA2YcmzN3ffDBB58N4vaNgBHIRUCrj6z+juB9diA5+0A1CW90sZ6xG5DWXou01s+WELGTdQ2tjGUk/qG+ATeVdWab4Obgz5AqwQXgryMFk9w7JI7lwf8XdmJXJxVwmhEwAk2GwHpafhTSxpeMQ+1nDwJ+4WbxsGcE4ghkN3zJnu2lrG60RWL7Q8KivlBLKO62IuFEPhRPRPCjZ+s63ok3WA0hDlPZxUPVlVSdWSB5ruxgacQBs+zSnpfeqTQ5Bkp6ePXFcTJS2Ovw9cK0MwJGoAAR4EP0cVZNQmaWLn4duqoAu+ouGYGCQyArpLmcjl2OxHZzmNQjeKZ+RHynpM6Stwvpu8DYno8w6H7C12Pq6zab+kpCq+TTck1zZYcbqhwozuS8puRhaIIBwsS2QnfoOB7I39F8+FUR6Yp07f6qfL5eJZW1MwJGoIARYK78T7R7PLtfjcYdNgJGoG4IZN95l1L6UiSwu/EsSVp7GFSZUIN0JfcXYerrChjbKYRv5P06nQ3R2gNkV9oI5PKswVi5Ee4jvG8Qxx+LVPCCSNzBL4BAVgH+Bzycv6eabilVPUb+8TzQOS/HlLJONgJGoAAQ4NneglWWtyNdWYOZvHbenBlBxEEjsIEISADE8/VNLh8NDYdC9cikKvm4XMV7dC6qCxOwhXtjUhmnlQQCORvAojeF1ApCZpabwSeANcD/nbUUcThV/R5Me6dUuZg8SWJvIN8qBSkgOdkIFCICsu2MMEAngQVmuVqxUUW68NIJtDMCRuALIMDzpVViWVaaCGPbEcb2e4SPhL4GVXO8SzcjcQ/UFfZAunsi8dMRzN1Dmt+t1dAq6gT9n7Kxn7sBjITvRofF183iaNzh+iHQr1+/Fh06dDicI/xO4co+KVfrC/J8yl3CKWxVKWWcbASMQOEjMJcuBsyseivTQ2ZmhYSdEWggBGBs9dF4iQj92q/gS1D0ffiVHvjVHO/X3UmczsemhHWXsmJyQ5Y5rlbWCUWJQKiqGUhmpXvQJTaUebG4o3VAILsk8kMeorFQj5RL1pCnU4LOtV5sCkJONgLFhYDmyyFBl5EK9QrC9o2AEWh4BHh3vkitp0KnYRFhABvCxNRKahsyOJFWdyb8V6S62jR2LeWuvvfee83jRAAq0mC1DWAS12qzUXgTwGzpz59RpANs9G7DxG7K0uIVPCTfoPH2+El9WEfiNSion42C+pKkAk4zAkagKBFYEO11DR+y0WIOGwEj8MURWI9FhJlUM5P38Im8h39C+HjewdslVC170L/i+TwZpvYh/Gspf7PNXiYgVfhJOUxWIJlVt++Ajo70v3sk7GANCAwdOrQLkphnKBIaTo8VFxP7d74Kz5k+ffrCWJ6jRsAIFDkCvBQXxz5guxT5kNx9I1B0CKBCIEndn0RZawi/Jvw/0MZQ1IkR2odndh82il0GY3sb4evbt29/Pyp/n0QLOlzQCIQMbcjMMhlXRCdjwu8X9BAKpHM8MHuDnXZMJjGyUly/hoflD+yqfL1AuuxuGAEj0PAIvBmrMqo/G8ty1AgYgXwjgBqBjpk+9IADDuiBCsLPeU8fQ7xDQrvtSBtN/mj2uCyDsb2F8CT2sjxsxjYBrcJJkkZBuAEsw9Vmd9yL8QqZW8LfYAfgXYXT78LqiTZ4VVZWnk6vZC82/tX3ER8DFyOtvcQnlBTW/+beGIF8IDB8+PC+vDBfiNT9EvNn2tHUkWIOGgEj0BgIDBgwoHXbtm0Poa0fQ4Pq0OZy3uOvQJehhnBTHcrBeiGDAAAb5klEQVS7SCMjwIeHGNqMizKvobhWOXyZ2DTXZxhV+80uX/yZjF2rZTZr9gw3/0i+CuOSmoSiTjICRqBEEFgRG0eSkfdYEUeNgBFoLARmzZoli0H/ECGt3Y6Pz6MIHwmv0zWlD1uQJ9oTpknqCucgwLrd0toUtJomOdwA1lztZ/+cGbG+JB4lFytTVlGkLx24qf/Izf0YA48zsvpCOJubfTczsmV1W3iwRkAf/+/FYAg308bSHTUCRqCJEWDvysu8p08ZOHBgd9QA9+X5/QtCqHdr6JZs2t6MGsICeIAz2SdjayU1gNVIWTkC2DCCzbZ/8mceHunE/7JMNi4SL9vgiBEjWq5bt+448DkVEJJ0bt4i7wc8HPeULUgeuBEobwQ25iUnKUHo1qxZ02HGjBk1vSDDsg4YASPQtAigblkBszqMd7lUEQ6GwdXhC2lOwisJtSbCDE9iT8wbaQWdnjcEdALYp0HtGTWDrM7soUGifPQ9o/pf0ayyCWcPPjjqo48+Oo0bvHvKwK/npj8Bxl+mzeyMgBEoTwS0A1qbEdoHw2/VqtWehL3vIADEvhEoYARYoZbVIT2vd4mxXbFixTG8939BPEn3XYLAASJMe/0fwsAnKTsZXmAK9m+fI92ucRAQM5vRMEjVmeVrI1OgcfpTWK1IEstJIcHBBz1TejeP9DEwsXen5DvZCBiB8kJAm0R+FgyZF5uZ2QAM+0agiBDIMrYZE19I/6RyKab2CKhNfBg8581hZHXS2O74Z1F+MeF7SddK7X0+GCmOWIPGQz41VWeWP6JvgzZZBJVJJ5bNXaegUrCQ8V9Bl5MY2VWkj+Xgg53MyBbBn+ouGoFGQoA5I2ffAS+2/o3UtJsxAkYgTwjwnn8e+inVd+aZliWERyCpGaS5rck4mrI3QcthbhciuT1C0t60C5y+YQiAb66agaphIl5CRlgj4Zr+rLBcKQQ4Cm9Hxv8Ldjfqy6ttFIfI+NaQ/idUDs7FMPPySLqDRsAIGIFmHIryOHNIFIl+RDSpls1cGh28w0aglBCAoZUg6y8iNoB1hx/4H+g7xPeAPmeeiMScyl6HPu7FMLY3ocJ5Laa+ZsfKOLoBCMC3hZLZzB+Q1ZnNsTML4IcA+M0bUH/RXII6QVeY03/T4Zp2JgqXv6B2cD5M7JKiGZw7agSMQGMjoA0J0p0PzXIxb/Rh3ni1sTvi9oyAEWgcBFjN7UxLB8JYjcTfD9q0Di2/RJl/iWCS59ahvIskIMB8GwoKylZnFhAOQp3gOr6Y2iVgpCSZ2rkK5e6LffBBCkJONgJGIIoA77P1TzOnDA0SkdbuQtjMbACIfSNQYghkTXFmJLZZy0d7IgwczlzwI4aadDKoENgeOkOECsIc5ozb2Kd0G1YRniYtZNAI26UjkCMNzzCzsjMLczeDa/YOruOPKEmdWW6czblxLmacR+IHw436i4hcBv05u6wQzXPYCBgBI5CKAHPKs2SGzCxhbR65JfUCZxgBI1AyCEybNm0tg3kwS7+Fr5IlBOnZjoYSbU8zZ4jX6gsDfBrlddjSfBjbCTC2kwjb1RGBUDIL81rqOrMboedyFDfOH8BmywR83gGD49B5u4VlwY8T8p1kBIyAEagNgRyThqUqFKgNBOcbASOAKYPPVAhOQmL7O1QapYZwJHQglLYZTCoLnWFsB8HYPg6/cjqS33tJs7QWEBJcrmmurM5sydqZRRr7dW6OS3ixyFRO3H1E+hmDBw8+f9y4ceHOuHghx42AETACtSHAXDKXF1BYjLCWE+2MgBEoYwSyEttbgeBWWU1CaHYwYR3OsC/UAkpy/ZlP7oaplU7tnwn/w2a+qsEUbgALJbMU+XwGJlIKdmaxUtCTcZzFcA7jRsgZXxYSGTf+ATfI01A2yZ4RMAJGYMMQQEf25ZhFA20u1YTrD+UNg9RXGYGSQoA9OCsY0DUiMbbwKCPhT3Ti2Ag+flsnDFaqCheRdx6M7XT8m5DyTmEF+YOEsmWVBBafgluGoQ0ZPED6NyhEdWbHw+CdUYzIZHcXnsIgpauSJM6vIu/MlStXXjh79uyPinGM7rMRMAKFiQBzqUz3hfpxWDTY2pZQCvO/cq+MQKEgsM8++7Riw/lPYNB+QZ/61NQv+Jcq8u+j/B18PN8Jr/bfmsqXaF7142w1UMApep1ZboauSEbGMpZjGFLSF46GejsqBydhdmyBInZGwAgYgQZGQHNLyMwyJ/UgvqSB23B1RsAIlBACfPDKDOgEEavKUjE4EZId2+gKembEMLzib0Yh1R1FuBmqlAvFBKOjO5X09ZlCpf+TM84MSMWuMztkyJDteGH8mj/+CP6/lin/4TP82b9Cl9r6BCkAOdkIGIEGQWARtewWqUlSlhmRuINGwAgYgVQEELY9TuZhqCGcBMN6JLzND4mn6t/D2/Qg/06Y2mcR1l24YsWKf5XBqnOoWcDYM7pc8uVyMgAwo4fwWVZh/vLHfYMlvWcRtb/Iny2bbkmM7Hzyjhw0aFA/M7KF+T+6V0agxBDYLDoe5h9t9LAzAkbACNQLAdm4h2/5AxLXHVAn0Afy+dD8tEpgandhvrmusrLyNXijX0E5c1HadaWQHjKwDPrfDGjvYFAAUtA6s/T3DPo6Luhvgv86aedwhNzfyuALJWH4TjICRqApEGBuuoF2D4u0PY+X0baRuINGwAgYgQ1GAEHezkhgD4JPG0MlSaZGM3WT/z6Ba2ByJzAHpTLBG9yRpr1wI/ZHfcwYM4LXUPpKwpJovxh8jj5CNK8pw3379q1gAJfTh3Ep/ZjHWI7hy2Rb/ryrzcimoORkI2AE8oIAK0WnxyruhQ7cVrE0R42AETACG4QAG76eQ2J7JjzOVvBqX6eSidAn8crIawedQPorMMDPMA9JB7dkXMDIakAZZlY6swy44O3MytRWp06dHmYAxyX8G8/zpXIITOwO/NF/5VSzdQllnGQEjIARyCsCLA3q+NrZkUaaM2cNj8QdNAJGwAg0CAIwtU/C1Ip/0+qPBH2rEyoWj7cL6qOTEAZeqWN3E8oUW1KOwDWUzDKKUOVAIyo0nVmW7o6mT8/Qtf7qX8Tp+Lix/Jk7ozR9s47mjeQ5aASMgBFoCgSmxRqVcXQ7I2AEjEBeEIAHmg+NYWWoGx/Pp9LIm0kNkfdT7NS+Ak81ZtSoUW2SyhRJWg7PmmFmswxgzm5bBqzzgpvcSRoL6HfTkb9CX4p1aAFK0f35Ay+IpTtqBIyAEWhKBHKspjCfDm7KzrhtI2AEygMBHcrA6vQ5rFL3RBo7mlG/mDDybqRNqKqqegP+6iqktQOJ5zCHCdcUdFIomWWyLSidWRkQBuTTkMa+AIL7J6B4B18guz344IPPJuQ5yQgYASPQZAisXr1apnWiqk7bWG+2yf4ON2wEyg4BqVqignAdwr6+8HfSm/0gAYT2pP2E/BnwW0ugB2Fsv5lQrhCTqqsZJOnMwtE3FZOoUx2+i91YfU2cCcXF4Kvp28/5g76VPRauEEF2n4yAEShjBGbNmlXF8HVcduhYRfpaGHHACBgBI9BICCCpncBJhD1pTjq1aaeediZvHxjbO+DBnmLD2Pe04b6RurghzeRIkjeJ1JCTAcO4KpLXKEEkF0ORxJ5DY3G92KD9B8n/8QMPPPBakGDfCBgBI1CgCDxNv3YL+sacuhPh6UHcvhEwAkagsRDghDEdsz0GPusP8FE/JfxjKM3KyleZr25kw/070GTK3dKiRYv7pk2bpj1KBekyzKx0ZuHCZ9L5UK+LwUpn9oHG6DVtH0zb59HmdintLeNrYSxfF/8gP0e0nFLeyUbACBiBJkWAOW0O81bYB+Jp81tYxgEjYASMQD4RYKP8Yuo/Danr+M6dO+9H+LvMU9/Gb5fQro7l/qGITWMfILF9ifBTWI46iXqSrCYkVJG3pM8nV5oIdWaZaCVijroO0Ui+woDzE9q+jfqTJnqJwy9BPL4djOzfCed0Pl99cr1GwAgYgQZAYF60Dj7We0bjDhsBI2AEmgqBOXPmSKd2KvQDNottQT+OhV6poT+bkqeVpp8wly1DCPl7THylHthQQz15yYqqGfSKtkBn10Tj+QjDyI7ki+BymNl49WJabyXvFJjYmsCNX+e4ETACRqAgEGBeWxSTzHYtiI65E0bACBiBCALaLEb0ChFMqk4X+xFz1xHE04SabZjfxiOtPQ0+7hHK3UX5u5qSX4sysyuiHcdSQD51ZrXJ62TaOxdAon1oRnwmGyV+iV7sE+TbGQEjYASKEgHmsbeYz6J97xGNOGwEjIARKDQEYEifo08nYBjg1ytWrNibOUzWDUQy5xV32iC2r4hyF8HXrYOpnVhRUXES+rVvxwvnMx7OtHDjC+hMj6AxOnQ6gzoziDeUj8mtrlgq+DP1HZBQ53lYKfhdQrqTjIARMAJFhcC4ceOaz5gx45Nop1GZ2pqNGEuiaQ4bASNgBAodgSFDhuyCkPNC+jkUClVUU/otFdHZ8JSPwktW4lchxT2voec+mOdQ9TRkZqOJ6hwdGA8ze0ZKR+ud3K9fvxYdOnQ4XkwyF38pVsGnpI+hvT/F0h01AkbACBQtAsyr2kGsTRSBO5YPdi3n2RkBI2AEig4B5rRuMKdHwLONpvNJe53SxiTG83GulWEBzYkfIdgc/0UkuFG+NbrE/y6VV0KBayid2eYY4T1UzDHUO6g84q9EP3c0agVTImkOGgEjYARKAYGLGcRZwUCYA0cQNjMbAGLfCBiBokKAj/FFdFgmVM+Bt+sD/7YXDOp3oP2Z32qS2Ep4ugdl9ggGjLT2ZzCkE4lvwvXXsxltcpBXXz8qmb2Jiw8NKqDBLySZRZ0ApnuT71Pfb6CvBPVGfdp4GNtlR02fPn1hNN1hI2AEjEApIKDNFEzS0QNoVrFzePPsEeKlMESPwQgYASPQTCccsk/gMOY7bRwL7WvXBxqunQlzPJcNaFV1kdpGJbMZZlYngL377ruSxIaSWir9PlzyjfXpiMqiTtCGyfpygqMgmXtIcu9S/ykDBw68Gr2yT5MKOM0IGAEjUAIIaLPrMsYRzoVM+Lv6GO4S+Gc9BCNgBBIREGPL/oB+6NjuhtByCIW2hbokFk5P1H4DbUbbBZK61hXUtQWM7voso7ucuTXkH6PMrE522BgK3DDEyfcFkbr4SGM70ogaT7M9JqXgKxnk+OxpFHWp1mWMgBEwAkWLANLZyXy86+M+cD9iar0miNg3AkbACJQ6AkOHDu0CI7orc2E/mFKpW+0MtdnAcYvRvR/aP7g+I4lNOgGMAjtAdWZm4ZCHU/5vUBIjKyb2OgZyFqdGLCBsZwSMgBEoCwSYvJ9ioFFmdqeyGLgHaQSMgBHIIsC+qDcIiu6Cxg8YMKB127ZtBxI+EhJT2hGqq5PgNWRkdVFUraBzrJYOsXhiFAVgXXc+nPbh+KEObrbwx6T/EbqYgbyeWIETjYARMAIljADMbM6xtgxVS252RsAIGIGyRWDWrFlVDF4CU9FGrGBJgLofdCiCzx3gG6MGCUiu2YXMLMV6RYumnQCGKkEr9CAG0NgQGtsH6s91FdFrFdYEzk61Axrarli8HceNgBEwAoWMAHPkq7H+9YjFHTUCRsAIlDMC6zHN+iIAiCZk93F9hblzd3hJ6cVKDfarkCS520BfhnJclJldQU4ojY2fAAYTq8MOxEFLqrARjeRUFIlIl+FcGNn/hZH9OJLuoBEwAkag7BDAYssS5sPouHtHIw4bASNgBIzA5whkrb08T4oocDdkAxuhf9sNfnRnhK6Tg8zQJhjM6XtBonwKhbqviH8Hc+EzJMtAblyVQMUD9zQS24Fsbvi9GdkAEvtGwAiUMwL9+/d/Jzb+Ck7TqY+x8djljhoBI2AEyhaB9VJbZf+VziaQEDbjQsY0aq9LOTC3p7Zp0+aSqqqqW4kOg0LGV/kxtwJR8G/at2//N9tPjCHjqBEoAgRguL7Url27s3mO29PdJ6EVzAGtiPfG35747tBWkD56pQOq46/fgDoSVl4fSPPJImge6YtJXw51IdyvjvkUa7YYehlaxLUr8ftw/QD8oO3nic8nbyl+L3wtO32Z8Co+wJX3KiQzLv3JkwrUxvivkPYM9AZh9VVGu7WB4CXoadKWkzeSsMYgxvMRSDr+B0Jq/x3KzCSscX2N8J6E63w9ZdWfzaCWUOCWErgR0mawQVBafbr2IdqUoEDnng+AbmJJ7mbS7YyAETACZYsAgla9h3oIgCgzq0k8VDOgwM+ZNI8nTUq5OY7098m/Gf9J/Kdat2793JQpUz7MKeSIETACjYaArInwPP4UhuclfDF062DuutGBnoR74cuI9abkfUD8NcJL8MWkdSLcA1IZMVR2xYGA5mvNvy34DzPMNX5tTPvL3B9vUm4w12nzxTnYEn+zOIbrXhoBI2AEchGICmFDZjbK4ao4E97pTHjjcy9tJkXZ/+OAhVNmz56dowQWK+eoETACNSCADvqmqO6cznPWCXocHXVJIbeBJKkbSFpG2kj4ecJxaaN03V+BXoBaQVKM3xqyMwL1QUDz+UJIkvD3IUmItbFC0vdQAk64N++CPetwT86jrO7JhdDmXCPp+HaE9Z6pSWJPdq0S+YJYDaCfIRaEU3EibxX0LDQPDCT8yUj+8ROl/JSp7UOkxtUD2tHHzSPQ69R1IO1olSEj1Sf8IWnfIi6bns8QnslHjY4e1f6X8DrCmZWIlLSkup6mrFY3DoJUdzzekG3ls66kscXbSyrzHGN+CNKcHayuzCU8G2yBfaNvE87gQnwacT1je3BoykQOTZlEOHXjEXl2dUAAZlZ8aGbvV8jMRjlc1QH4pwL+2dH6iF/El/zJ0TSHjYAR+AyBKINKymO8MN7jOepL+GAoWK6eRbg5NAxqCdkZASNgBIxAeSEg5ngGpJXvRPUm0pM+NDJMNe+VUO2ojJljna64DpyqMbMCrgOUcTCuUjP4LZHu2SR5x7O567JI3ME8IcBxcG31QQENg7bj/2gXNEX4ID4qJgdx+w2DAJgPZWn+WPCdQ43zCPckPISwdDa1BF9Nx5J8SVpKgkFlLK8yxgWMR2oIuv/WkbYgm7agoqJiGTr0bM5v0YW0rcmXvuzbMO0LmVAXkrYGCfOWpCm/MyTp3FJwlLRIkrla8ykjyWAX6lEdm3HdYvz5SLFVTyva2Zo6JYXeCv8N4q+R95bySJNaRXfSpfe7gPRX161bt5q6OlKuJ/3sSN7rkKRgqzmJUCoW29DGFsRfhl4nrSXlepMuXd8AD02WkpprLnyT/Jeo8/16XK++bUt9h+BLQhc4SX8uoZ9zyVsVr49Ci+h3G9qSdFMvPUnSNHa9/DaF7IyAETACQmAZ9BS0JxSXkrcm7XFI+5+0svApc874adOmvU28mJ2YWZntyrhQMpukZkCJpxn4DfjtmHT1whqAlQJtXLCrBwIBkwSGc/Qi5MW7G7geQxWt8Z8lrmWovYmvgOZB/SFJ79Lcx1zT2wdRVIcnhrWW+Lan1Heg1K9fyswAfzE2e1SvsThSGMNH3Fsv6h6jx2sYTwX3iPQhX4fESIr+S34rJjIxoV8mv1JpyuPZXsSz/QFhuzwhwL3ZH8wfi1S/GuFAvZlSVgA24YOiJ//Z9vzPbfnIeJl63+c/7UxaDtNOmpaYu0C9KNuLcp11rxPvii+m3XrSkT/EQSNQJgh8wjjvh/SBrndjRuLLnBCopLRmjphF/B7ydsK/oQAFaGJmP6Z/GV4pZGaT1AzYMXvOiBEjtmSC7IN0YDac/FoutKsBgYCZ4s+fw4tjDQzGwdwU2kHd0O5QXoQTG7rSQqwviin9S5KYvkz6c2C+HVj3K8QxpPRpNelPQq/R9wp8WQB4FZoHg/ImUsWWpEsSlyNtFOOC3VJJJrtB67jHXqHsqzCjayhrV6AIYAi8gv0GOXMo/99wXhJ6YTS603GSWKzpScPbQLK2ML9ly5ZvIiFuzZxfLwk41+hDSBYnunF/6tqV3McLqGcB92cV748aJfZclyqRX7t2bUs+wLpSpqBWA+hPyzScSG/NmLuDRQ/KaZXjJcawGJz0nAvvUMpPmfco+4VWD2ivApzDFQXqXMh/IDUmrQhsRd4LtP0O7WQ+bEhfRNprpG1MvpiZcCUiXhd5C+h/sLqQqYs0WTvpRjs9qXMu/tvUs3UQJ38Z+Z2hXoS/UFsN2e+kuuizNlFq9TMVp2gZyundrvHqw7A34eX8t3OpQ2plXYj3Btv25EmQoA2XWmXaEX9HfK0ebQtJelpsbgEd1n0bFbqtJ645TeMRYylJ6QOQdMZvhEe5Az9fLlkyCzNbTc2ASfbK2noxatSoNkw2m/MHHk7Z30ISaUsKpAc2Omjd/PfxBx9IugYeVxavLV6bQnY1KWekPfVpKXHdYHrAE/tHeiAVDf4gLS8GZYO04E9TXtTpT2weTchjWG3JeoQmmLziBl45kuMIphvyH9bW13j+M4yvChoMFYsLGNT5dFgvrmVgqOXwWUxwGoueC0nD5lVWVr6EKTul2ZUJAsyzbzHUjpHhMt/fNywSd9AIGIESRqBfv34tmPv14aETrj5hlWU+wgiZQazxowIeayHl9ZEUqh0Rl6BDzLF4nEJ2YnTFMwUMbxJfFfRfvJas8pyAQPXeIDHBT5bMJqkZUNGZCRVkkij/e0D8DZG2aWWcbgSKEIH/cl8/Qr/X8DDJLulcJo+XYEalCiLJU6hjSZqkHxvDpEq6ZQa1CP/sxu7ysGHDBnJP6f4KVsXWc/90xwD44sbui9szAkag+BFg9bzlmjVrtmcekeT3HaTEK2B8tSoglSMxhRIqbsO7SquWuxHvhf9lqJhcwAyn9jmYUJslqBmcAjN7bvRKGNhhAHI2YHwJX18HdkagEBF4i/vzUTqmZfcF0PM81K/DfDbPPsiZJTWWnOZTbmMefklLpYc8p0OHDq/54A/QsMsbAsy1MsO2WaSBo5DO/iMSd9AIGAEjkC8EosfBViCseZV3o3RkM6oWvBO170IrjDuQNgJfTLLekQXtokvlOZwvL39x8zmOQUrtQBx+TrojRqARENDOy4e596p4wDISU5hPfXWughndAl/LLSuVttdeey0YN26cVDGSXHQDTpA/OwjYNwKNgECUkW3GfatlNTsjYASMQGMgkDkOloZejzUWfzc+RL54vmbDhw+XbvAA5qp3YXzFN+4ALYMRXk16V8KreAdXkv8R4f7QAKgb1GguYGarcad0rFM9erGMsq9BC2GC72dw2iUtBWANULto/0t4JX5P/PnkL6VcV/xE5XHSa1Ump0yO0jYAB/X3pM0l1P8ebelrQrqLq0k7Hl9j0g73/vSlB+Ev6sQwLYUWQZICvgFpOfoF2pBOqTDQi0uSmEQsSJeifHf8av2uL055wC1vfYv3NR4HE5lbkimlNoRfQGL6ci0S0xlgmHFYeQiC9o1AwSPA/V3o+m4Fj6E7aASMQP4QuPvuu1+ldlHgbg8CaT4bt3fkHa7N7/pY3xyStHdTKOCLVvF+lxWWrtBqwuIPNyHck/A3CVfjS0lLdf8PHViGeM9y2IQAAAAASUVORK5CYII="
			};
			
			// Se muestra el spinner.
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			solicitudService.generarAvisoPrivacidadRechazoRENAPO(x).then(
				function(data) {
					// Se esconde el spinner.
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var response = JSON.parse(data.data.respuesta);
						
						switch(response.codigo) {
							case 2:
								$rootScope.message("¡Albricias!", 
										["Código: " + response.codigo + ". " + response.descripcion],
										"Aceptar"
								);
								break;
							case 5:
								$rootScope.message("¡Error Inesperado!", 
										["Código: " + response.codigo + ". " + response.descripcion],
										"Aceptar"
								);
								break;
							case 11:
								$rootScope.message("¡JSON NO VÁLIDO!", 
										["Código: " + response.codigo + ". " + response.descripcion],
										"Aceptar"
								);
								break;
							case 17:
								$rootScope.message("¡PARÁMETRO NO VÁLIDO!", 
										["Código: " + response.codigo + ". " + response.descripcion],
										"Aceptar"
								);
								break;
							default:
								$rootScope.message("¡Error!", 
										["Código: " + response.codigo + ". " + response.descripcion],
										"Aceptar"
								);
						};						
					} else {
						$rootScope.message("¡ERROR!", [data.data.descripcion], "Aceptar");
					}					
				}, function(error) {
					// Se esconde el spinner.
					$rootScope.waitLoaderStatus = LOADER_HIDE;
				}
			);
		}
		
		
		//Funcion para liberar la LCR
		$scope.liberarLCR = function(){
			var r = {
				idSolicitud: "20171031171733171734049687",
				tarjeta: "1"
			}
			solicitudService.liberarLCR(r).then(
					function(data){
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var response = JSON.parse(data.data.respuesta);
							switch(response.codigo) {
							case 2:
								$rootScope.message("¡Proceso terminado correctamente!", 
										["Código: " + response.codigo + ". " + response.descripcion],
										"Aceptar"
								);
								break;
							case 5:
								$rootScope.message("¡Error Inesperado!", 
										["Código: " + response.codigo + ". " + response.descripcion],
										"Aceptar"
								);
								break;
							case 624:
								$rootScope.message("Solicitud no Autorizada o Liberada por Gerente", 
										["Código: " + response.codigo + ". " + response.descripcion],
										"Aceptar"
								);
								break;
							case 3011:
								$rootScope.message("Ocurrio un inconveniente en la liberacion", 
										["Código: " + response.codigo + ". " + response.descripcion],
										"Aceptar"
								);
								break;
							default:
								$rootScope.message("¡Error!", 
										["Código: " + response.codigo + ". " + response.descripcion],
										"Aceptar"
								);
						};
					}else{
						$rootScope.message("¡Error!", 
								["Código: " + data.data.codigo + ". " + response.descripcion],
								"Aceptar"
						);
					}
				}
			);
		}
		
		$scope.obtenerSolicitudesPorNombre = function(){			
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var jsonRequest =  {
					"nombreCliente": "omar"
			};
						
			
			solicitudService.obtenerSolicitudesPorNombre( jsonRequest ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == 2){
						var j = JSON.parse(data.data.respuesta);
						modalService.alertModal("OK "+j.codigo, [j.respuesta]);
					}else
						modalService.alertModal("",[data.data.respuesta]);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		};
		
		$scope.getDatosAsesorDispAgendarCita = function() {
			var fechaIni = new Date();
			
			var ddIni = (fechaIni.getDate() < 10 ? '0' : '') + fechaIni.getDate();
			var mmIni = ((fechaIni.getMonth() + 1) < 10 ? '0' : '') + (fechaIni.getMonth() + 1);
			var aaIni = fechaIni.getFullYear()
			
			var fechaFin = new Date();
			fechaFin.setDate(fechaFin.getDate() + 13);
			
			var ddFin = (fechaFin.getDate() < 10 ? '0' : '') + fechaFin.getDate();
			var mmFin = ((fechaFin.getMonth() + 1) < 10 ? '0' : '') + (fechaFin.getMonth() + 1);
			var aaFin = fechaFin.getFullYear()
			
			var x = {
				fechaIni : aaIni + "-" + mmIni + "-" + ddIni,
				fechaFin : aaFin + "-" + mmFin + "-" + ddFin,
				latitud : 19.280152,//parseFloat($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud),
				longitud : -99.197811//parseFloat($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud)
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.getDatosAsesorDispAgendarCita(x).then(
				function(data) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var json = JSON.parse(data.data.respuesta);
						$rootScope.message("Exito", [json.descripcion], "Aceptar");
					} else {
						$rootScope.message("Error", [json.descripcion], "Aceptar");
					}
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Exito", ["TIME OUT"], "Aceptar");
				});
		};
		
		$scope.consultarIne = function(){			
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var jsonRequest =  {
					"jsonSolicitud": JSON.stringify({"aceptaConsultaBuro":1,"idCanalAlnova":"1","pedidoSAC":0,"mesaControl":{"folioMCO":"","fechaGeneraFolio":"","contEdicion":0,"cometario":"","origenEdicion":"","existeEdicion":0},"banderaCUDigitalizacion":0,"documentos":{"porcentaje":0,"bloqueado":0,"documento":[],"editable":0,"guardado":0},"sistemaOperativo":"","codigoCorreo":"","campana":"","pedidoSEG":0,"folioCallCenter":"","idEstatusLCR":0,"origenSolicitud":0,"idMotivoBloqueo":0,"aceptaTerminos":1,"banderaOCR":1,"tipoDispersion":0,"tipoSolicitud":8,"terminal":"GGAP","idPais":1,"banderaFolioRecomendador":0,"pedido":0,"banderaSeguro":0,"diaPago":"","envioCorreo":0,"transferenciaDatos":0,"idEntidadAlnova":"0127","idSolicitud":"","idSeguimiento":3,"idSolicitudTienda":0,"folioRecomendador":"","banderaEntregaTAZ":0,"tipoCampania":1,"cantidadReenviosCorreo":0,"promocionCorreo":0,"creditoInmediato":0,"banderaIngresos":0,"capacidadPagoComprobable":0,"tratamientoDatos":0,"idEmpleado":901351,"cantidadReenviosCelular":0,"tipoDispositivo":"Windows","idSucursal":7676,"envioCelular":0,"contratos":{"porcentaje":100,"bloqueado":0,"editable":0,"guardado":0,"contrato":[{"statusFirma":2,"descripcion":"Aviso De Privacidad","idTipoPersona":1,"idContrato":"1","idPersona":""},{"statusFirma":2,"descripcion":"Buró de Crédito","idTipoPersona":1,"idContrato":"2","idPersona":""},{"statusFirma":0,"descripcion":"Contrato y Carátula de Crédito","idTipoPersona":1,"idContrato":"3","idPersona":""},{"statusFirma":0,"descripcion":"Solicitud de Crédito","idTipoPersona":1,"idContrato":"4","idPersona":""}]},"diasRechazo":0,"idCanal":1,"clienteForaneoGuardado":0,"promocionCelular":0,"lineaDeCredito":{"bonificacion":0,"tipoPago":"","capacidadDePagoTotal":0,"pagoAntesDe":"","capacidadDePagoOcupada":0,"siguientePago":0,"capacidadDePagoDisponible":0,"liquidarAhora":0},"cantidadReenviosLlamada":0,"cotizacion":{"clientes":[{"bloqueado":0,"consecutivoPersona":0,"idGenero":"F","estadoCivil":"","ingresosEgresos":{"bloqueado":0,"porcentaje":0,"dependientesMenores":null,"dependientesMayores":null,"flujoEfectivo":[],"editable":0,"guardado":0},"preguntaPEPS":[{"parentesco":0,"status":0,"apellidoPaterno":"","areaAdscritoDes":"","fechaNacimiento":"","cargo":0,"areaAdscrito":1,"parentescoDes":"","numero":1,"nombre":"","dependencia":1,"apellidoMaterno":"","dependenciaDes":"","idPersona":"","cargoDes":""},{"parentesco":0,"status":0,"apellidoPaterno":"","areaAdscritoDes":"","fechaNacimiento":"","cargo":0,"areaAdscrito":1,"parentescoDes":"","numero":2,"nombre":"","dependencia":1,"apellidoMaterno":"","dependenciaDes":"","idPersona":"","cargoDes":""}],"datosEmpleo":[{"bloqueado":1,"idEmpleo":"","nombreEmpresa":"","antiguedad":"","antiguedadDes":"","domicilio":{"numeroExterior":"","estado":"","cp":"","idDomicilio":"","idDelegacion":0,"numeroInterior":"","telefono":"","idEstado":0,"colonia":"","calle":"","delegacion":""},"idTipoPago":0,"editable":0,"ext":"","porcentaje":0,"giro":"","idProfesion":0,"tipoPago":"","profesion":"","idGiro":0,"periodicidad":"","idAntiguedad":0,"empleoActual":0,"idPeriodicidad":0,"guardado":0}],"domicilios":[{"superManzana":"","antiguedad":"","bloqueado":0,"numeroInterior":"","colonia":"","porcentaje":0,"numeroExterior":"","idTipoVivienda":0,"lote":"","guardado":0,"antiguedadDes":"","idDomicilio":"","edificio":"","domicilioActual":1,"telefono":"","manzana":"","andador":"","editable":0,"zonificacion":{"calleIzquierda":"","fov":"","calleDelante":"","zoom":"","calleDerecha":"","referencia":"","idPais":0,"idCuadrante":0,"calleAtras":"","latitud":"","longitud":"","pitch":"","heading":"","idZonaGeo":0},"estado":"","cp":"14400","idDelegacion":0,"idAntiguedad":0,"idEstado":0,"tipoViviendaDes":"","calle":"4A CDA DE PROL LA PALMA 32","delegacion":""}],"apellidoPaterno":"DE LA CRUZ","puestoCUDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":9,"idPuestoSPCU":0,"porcentaje":0,"nombre":"YULISSA","apellidoMaterno":"MUNGUIA","flujoEfectivo":[],"curp":"","idPersona":"","dni":"","guardado":0,"clienteAlnova":"","numCuenta":"","idPuesto":-1,"idPuestoCU":0,"huella":"0","bdmid":"","lugarNacimientoDes":"CIUDAD DE MEXICO","idNacionalidad":0,"clienteUnico":"","claveElector":"CRMNYL97022809M400","editable":0,"idTipoTrabajo":0,"nacionalidadDes":"","fechaNaciomiento":"28\/02\/1997","genero":"FEMENINO","email":"","puestoDes":"","foto":"0","clienteTienda":"","idEstadoCivil":0,"folioIdentificacion":"3961100075074","tipoTrabajoDes":"","fechaVigenciaIdentificacion":"31\/12\/2024","celular":"5532907875"}],"idPresupuesto":0,"statusCotizacion":1,"fechaVigencia":"","pagoNormal":155,"detallesCotizacion":[{"intereses":9499,"idDetalle":"","cantidad":1,"idProducto":"520012","enganche":0,"montoText":"6,000","monto":6000}],"idPlazo":7,"pagoPuntual":132,"periodicidad":"Semanal","plazo":100,"ultimoAbono":154,"idPeriodicidad":1,"idCotizacion":"","montoTotal":15499.998000000001},"banderaSolidario":0,"codigoCelular":"QxrURoGj\/LdDK78FuffbOg==","idProducto":24,"respuestaCallCenter":0,"capacidadPagoNoComprobable":0,"idCondicion":0,"avales":[{"idTipoAval":0,"bloqueado":1,"aceptaConsultaBuro":0,"idGenero":"","estadoCivil":"","idTipoPropiedad":0,"codigoCorreo":"","apellidoCasada":"","idMotivoBloqueo":0,"tipoPropiedadDes":"","banderaOCR":0,"aceptaTerminos":0,"primerInser":0,"curp":"","flujoEfectivo":[],"idPersona":"","envioCorreo":0,"presencial":0,"guardado":0,"idSeguimiento":0,"idPuesto":0,"cantidadReenviosCorreo":0,"idNacionalidad":0,"clienteUnico":"","parentescoDes":"","editable":0,"datosHogar":{"antiguedad":"","superManzana":"","bloqueado":0,"numeroInterior":"","claseViviendaDes":"","colonia":"","porcentaje":0,"lote":"","idTipoVivienda":0,"numeroExterior":"","guardado":0,"antiguedadDes":"","idDomicilio":"","edificio":"","domicilioActual":1,"telefono":"","idClaseVivienda":0,"manzana":"","andador":"","editable":0,"zonificacion":{"calleIzquierda":"","fov":"","calleDelante":"","zoom":"","calleDerecha":"","referencia":"","idPais":0,"idCuadrante":0,"calleAtras":"","latitud":"","longitud":"","pitch":"","heading":"","idZonaGeo":0},"estado":"","cp":"","idDelegacion":0,"idAntiguedad":0,"tipoViviendaDes":"","idEstado":0,"calle":"","delegacion":""},"nacionalidadDes":"","email":"","cantidadReenviosCelular":0,"envioCelular":0,"folioIdentificacion":"","clienteForaneoGuardado":0,"fechaVigenciaIdentificacion":"","celular":"","consecutivoPersona":0,"tipoAvalDes":"","codigoCelular":"","apellidoPaterno":"","idCondicion":0,"rfc":"","idLugarNacimiento":0,"porcentajeContacto":0,"nombre":"","porcentaje":0,"porcentajeBasico":0,"idMotivoRechazo":0,"apellidoMaterno":"","dni":"","idParentesco":0,"clienteAlnova":"","huella":"","lugarNacimientoDes":"","consultaMatriz":0,"marca":0,"consultaBuro":0,"existeCita":0,"fechaNaciomiento":"","genero":"","puestoDes":"","foto":"","idEstadoCivil":0,"clienteTienda":""}],"pushId":"","banderaPrueba":0,"idMotivoRechazo":0,"idSolicitudTiendaCredInm":0,"direccionIp":"10.53.37.59","tipoLevantamiento":2,"consultaMatriz":0,"referencias":{"porcentaje":0,"bloqueado":0,"editable":0,"guardado":0,"referencia":[{"idParentesco":0,"lugarNacimientoDes":"","idGenero":"","estadoCivil":"","telefonoCasa":"","apellidoPaterno":"","idNacionalidad":0,"parentescoDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":0,"nombre":"","nacionalidadDes":"","fechaNaciomiento":"","genero":"","email":"","apellidoMaterno":"","curp":"","idPersona":"","idEstadoCivil":0,"dni":"","celular":""},{"idParentesco":0,"lugarNacimientoDes":"","idGenero":"","estadoCivil":"","telefonoCasa":"","apellidoPaterno":"","idNacionalidad":0,"parentescoDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":0,"nombre":"","nacionalidadDes":"","fechaNaciomiento":"","genero":"","email":"","apellidoMaterno":"","curp":"","idPersona":"","idEstadoCivil":0,"dni":"","celular":""}]},"marca":0,"consultaBuro":0,"seguroDeVida":{"clavePromocion":"","opcionSeguro":0,"montoFinal":0,"abonoSeguro":0,"precioSeguro":0,"sobrePrecioSeguro":0,"montoInicial":0,"esDefault":0,"ultimoAbonoSeguro":0,"totalSeguro":0,"nombreSeguro":"","idSeguro":"","comisionVenta":0},"existeCita":0,"banderaOfertaCP":0,"idPlataforma":1,"preguntasInvestigacion":[{"idVecino":1,"idPregunta":"700","respuestaDes":"","preguntaDes":"¿Cual es el Nombre del Cliente?"},{"idVecino":1,"idPregunta":"713","respuestaDes":"","preguntaDes":"¿Es una persona de confianza?"}]}),
					"folioDigitalizacion": null
			};
						
			
			solicitudService.consultarIne( jsonRequest ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == 2){
						var j = JSON.parse(data.data.respuesta);
						modalService.alertModal("OK "+j.codigo, [j.respuesta]);
					}else
						modalService.alertModal("",[data.data.respuesta]);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		};
		
		$scope.cierrePuertasPP = function(){			
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var jsonRequest =  {
				"idPais": 1,
				"idCanal": 1,
				"idSucursal": 2244,
				"folio": 9983,
				"idSolicitud": ""
			};
			
			solicitudService.cierrePuertasPP( jsonRequest ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == 2){
						var j = JSON.parse(data.data.respuesta);
						modalService.alertModal("OK "+j.codigo, [j.respuesta]);
					}else
						modalService.alertModal("",[data.data.respuesta]);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		};
		
		$scope.promoCreditoRegistrar = function(){			
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var jsonRequest = {
				"fipais": 1,
				"ficanal": 1,
				"fisucursal": 9669,
				"finopedido":  18671,
				"fiproducto": 301502,
				"ficamp":1023,
				"fcempentrega":"" ,
				"fdentrega":null ,
				"fnprecio":0.0 ,
				"ficantidad":1 ,
				"fcUsuario":"USRPRESTAMOS",
				"fcObserv":""
			}

			solicitudService.promoCreditoRegistrar( jsonRequest ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == 2){
						var j = JSON.parse(data.data.respuesta);
						modalService.alertModal("OK "+j.codigo, [j.respuesta]);
					}else
						modalService.alertModal("",[data.data.respuesta]);
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                modalService.alertModal("Error "+error.status, [error.statusText]);
					
				}
			);
		};
		
		/******************************
		 * INICIA SECCION COACREDITADO *
		 ******************************/
		
		$scope.consultaFolioCUOS = function() {
			var request = {
				idSolicitud:"",
				ruta:"",
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.consultaFolioCUOS(request).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							$rootScope.message("Exito", [jsonResponse.descripcion], "Aceptar");
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}
					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'consultaFolioCUOS'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
				});
		};
		
		$scope.obtenerFolioCallCenterOS = function() {
			var request = {
				solicitud: JSON.stringify({"aceptaConsultaBuro":1,"idCanalAlnova":"9","pedidoSAC":0,"mesaControl":{"folioMCO":"","fechaGeneraFolio":"","contEdicion":0,"cometario":"","origenEdicion":"","existeEdicion":0},"banderaCUDigitalizacion":0,"documentos":{"porcentaje":0,"bloqueado":0,"documento":[],"editable":0,"guardado":0},"sistemaOperativo":"","codigoCorreo":"","campana":"","pedidoSEG":0,"folioCallCenter":"","idEstatusLCR":0,"origenSolicitud":0,"idMotivoBloqueo":0,"aceptaTerminos":1,"banderaOCR":1,"tipoDispersion":0,"tipoSolicitud":8,"terminal":"3SI0","idPais":1,"pedido":0,"banderaSeguro":0,"diaPago":"","envioCorreo":0,"transferenciaDatos":0,"idEntidadAlnova":"0127","idSolicitud":"","idSeguimiento":3,"idSolicitudTienda":0,"banderaEntregaTAZ":0,"tipoCampania":1,"cantidadReenviosCorreo":0,"promocionCorreo":0,"creditoInmediato":0,"banderaIngresos":0,"capacidadPagoComprobable":0,"tratamientoDatos":0,"idEmpleado":348339,"cantidadReenviosCelular":0,"tipoDispositivo":"Windows","idSucursal":1769,"envioCelular":0,"contratos":{"porcentaje":100,"bloqueado":0,"editable":0,"guardado":0,"contrato":[{"statusFirma":2,"descripcion":"Aviso De Privacidad","idTipoPersona":1,"idContrato":"1","idPersona":""},{"statusFirma":2,"descripcion":"Buró de Crédito","idTipoPersona":1,"idContrato":"2","idPersona":""},{"statusFirma":0,"descripcion":"Contrato y Carátula de Crédito","idTipoPersona":1,"idContrato":"3","idPersona":""},{"statusFirma":0,"descripcion":"Solicitud de Crédito","idTipoPersona":1,"idContrato":"4","idPersona":""}]},"diasRechazo":0,"idCanal":9,"clienteForaneoGuardado":0,"lineaDeCredito":{"bonificacion":0,"tipoPago":"","capacidadDePagoTotal":0,"pagoAntesDe":"","capacidadDePagoOcupada":0,"siguientePago":0,"capacidadDePagoDisponible":0,"liquidarAhora":0},"promocionCelular":0,"cantidadReenviosLlamada":0,"cotizacion":{"clientes":[{"bloqueado":0,"consecutivoPersona":0,"idGenero":"M","estadoCivil":"","ingresosEgresos":{"bloqueado":0,"porcentaje":0,"dependientesMenores":null,"dependientesMayores":null,"flujoEfectivo":[],"editable":0,"guardado":0},"preguntaPEPS":[{"parentesco":0,"status":0,"apellidoPaterno":"","areaAdscritoDes":"","fechaNacimiento":"","cargo":0,"areaAdscrito":1,"parentescoDes":"","numero":1,"nombre":"","dependencia":1,"apellidoMaterno":"","dependenciaDes":"","idPersona":"","cargoDes":""},{"parentesco":0,"status":0,"apellidoPaterno":"","areaAdscritoDes":"","fechaNacimiento":"","cargo":0,"areaAdscrito":1,"parentescoDes":"","numero":2,"nombre":"","dependencia":1,"apellidoMaterno":"","dependenciaDes":"","idPersona":"","cargoDes":""}],"datosEmpleo":[{"bloqueado":1,"idEmpleo":"","nombreEmpresa":"","antiguedad":"","antiguedadDes":"","domicilio":{"numeroExterior":"","estado":"","cp":"","idDomicilio":"","idDelegacion":0,"numeroInterior":"","telefono":"","idEstado":0,"colonia":"","calle":"","delegacion":""},"idTipoPago":0,"editable":0,"ext":"","porcentaje":0,"giro":"","idProfesion":0,"tipoPago":"","profesion":"","idGiro":0,"periodicidad":"","idAntiguedad":0,"empleoActual":0,"idPeriodicidad":0,"guardado":0}],"domicilios":[{"superManzana":"","antiguedad":"","bloqueado":0,"numeroInterior":"","colonia":"","porcentaje":0,"numeroExterior":"","idTipoVivienda":0,"lote":"","guardado":0,"antiguedadDes":"","idDomicilio":"","edificio":"","domicilioActual":1,"telefono":"","manzana":"","andador":"","editable":0,"zonificacion":{"calleIzquierda":"","fov":"","calleDelante":"","zoom":"","calleDerecha":"","referencia":"","idPais":0,"idCuadrante":0,"calleAtras":"","latitud":"","longitud":"","pitch":"","heading":"","idZonaGeo":0},"estado":"","cp":"20660","idDelegacion":0,"idAntiguedad":0,"idEstado":0,"tipoViviendaDes":"","calle":"CTO MOSTO 193","delegacion":""}],"apellidoPaterno":"RANGEL","puestoCUDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":14,"idPuestoSPCU":0,"porcentaje":0,"nombre":"JOSE JUAN","apellidoMaterno":"CARREON","flujoEfectivo":[],"curp":"","idPersona":"","dni":"","guardado":0,"clienteAlnova":"","numCuenta":"","idPuesto":-1,"idPuestoCU":0,"huella":"0","bdmid":"","lugarNacimientoDes":"JALISCO","idNacionalidad":0,"clienteUnico":"","claveElector":"RNCRJN88080614H600","editable":0,"idTipoTrabajo":0,"nacionalidadDes":"","fechaNaciomiento":"06\/08\/1988","genero":"MASCULINO","email":"","puestoDes":"","foto":"0","clienteTienda":"","idEstadoCivil":0,"folioIdentificacion":"0415096392995","tipoTrabajoDes":"","fechaVigenciaIdentificacion":"31\/12\/2026","celular":"4497695286"}],"idPresupuesto":0,"statusCotizacion":1,"fechaVigencia":"","pagoNormal":179,"detallesCotizacion":[{"intereses":10900,"idDetalle":"","cantidad":1,"idProducto":"520014","enganche":0,"montoText":"7,000","monto":7000}],"idPlazo":7,"pagoPuntual":145,"periodicidad":"Semanal","plazo":100,"ultimoAbono":179,"idPeriodicidad":1,"idCotizacion":"","montoTotal":17900.001},"banderaSolidario":0,"codigoCelular":"v4PnwHtWOP0tHL82Z0FIog==","idProducto":24,"respuestaCallCenter":0,"capacidadPagoNoComprobable":0,"idCondicion":0,"avales":[{"idTipoAval":0,"bloqueado":1,"aceptaConsultaBuro":0,"idGenero":"","estadoCivil":"","idTipoPropiedad":0,"codigoCorreo":"","apellidoCasada":"","idMotivoBloqueo":0,"tipoPropiedadDes":"","banderaOCR":0,"aceptaTerminos":0,"primerInser":0,"curp":"","flujoEfectivo":[],"idPersona":"","envioCorreo":0,"presencial":0,"guardado":0,"idSeguimiento":0,"idPuesto":0,"cantidadReenviosCorreo":0,"idNacionalidad":0,"clienteUnico":"","parentescoDes":"","editable":0,"datosHogar":{"antiguedad":"","superManzana":"","bloqueado":0,"numeroInterior":"","claseViviendaDes":"","colonia":"","porcentaje":0,"lote":"","idTipoVivienda":0,"numeroExterior":"","guardado":0,"antiguedadDes":"","idDomicilio":"","edificio":"","domicilioActual":1,"telefono":"","idClaseVivienda":0,"manzana":"","andador":"","editable":0,"zonificacion":{"calleIzquierda":"","fov":"","calleDelante":"","zoom":"","calleDerecha":"","referencia":"","idPais":0,"idCuadrante":0,"calleAtras":"","latitud":"","longitud":"","pitch":"","heading":"","idZonaGeo":0},"estado":"","cp":"","idDelegacion":0,"idAntiguedad":0,"tipoViviendaDes":"","idEstado":0,"calle":"","delegacion":""},"nacionalidadDes":"","email":"","cantidadReenviosCelular":0,"envioCelular":0,"folioIdentificacion":"","clienteForaneoGuardado":0,"fechaVigenciaIdentificacion":"","celular":"","consecutivoPersona":0,"tipoAvalDes":"","codigoCelular":"","apellidoPaterno":"","idCondicion":0,"rfc":"","idLugarNacimiento":0,"porcentajeContacto":0,"nombre":"","porcentaje":0,"porcentajeBasico":0,"idMotivoRechazo":0,"apellidoMaterno":"","dni":"","idParentesco":0,"clienteAlnova":"","huella":"","lugarNacimientoDes":"","consultaMatriz":0,"marca":0,"consultaBuro":0,"existeCita":0,"fechaNaciomiento":"","genero":"","puestoDes":"","foto":"","idEstadoCivil":0,"clienteTienda":""}],"pushId":"","banderaPrueba":0,"idMotivoRechazo":0,"idSolicitudTiendaCredInm":0,"direccionIp":"10.53.37.58","tipoLevantamiento":2,"consultaMatriz":0,"referencias":{"porcentaje":0,"bloqueado":0,"editable":0,"guardado":0,"referencia":[{"idParentesco":0,"lugarNacimientoDes":"","idGenero":"","estadoCivil":"","telefonoCasa":"","apellidoPaterno":"","idNacionalidad":0,"parentescoDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":0,"nombre":"","nacionalidadDes":"","fechaNaciomiento":"","genero":"","email":"","apellidoMaterno":"","curp":"","idPersona":"","idEstadoCivil":0,"dni":"","celular":""},{"idParentesco":0,"lugarNacimientoDes":"","idGenero":"","estadoCivil":"","telefonoCasa":"","apellidoPaterno":"","idNacionalidad":0,"parentescoDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":0,"nombre":"","nacionalidadDes":"","fechaNaciomiento":"","genero":"","email":"","apellidoMaterno":"","curp":"","idPersona":"","idEstadoCivil":0,"dni":"","celular":""}]},"marca":0,"consultaBuro":0,"seguroDeVida":{"clavePromocion":"","opcionSeguro":0,"montoFinal":0,"abonoSeguro":0,"precioSeguro":0,"sobrePrecioSeguro":0,"montoInicial":0,"esDefault":0,"ultimoAbonoSeguro":0,"totalSeguro":0,"nombreSeguro":"","idSeguro":"","comisionVenta":0},"existeCita":0,"banderaOfertaCP":0,"idPlataforma":1,"preguntasInvestigacion":[{"idVecino":1,"idPregunta":"700","respuestaDes":"","preguntaDes":"¿Cual es el Nombre del Cliente?"},{"idVecino":1,"idPregunta":"713","respuestaDes":"","preguntaDes":"¿Es una persona de confianza?"}]}),
				foto: "/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCACFAGQDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDHEVPEeO36VZEVP8vHJ6UwIFiFZl7q8cJ8qz8uefdgjdhV+p/pWbq2ufaJntIWIhU8shwW/wDrVRUkoQ0QGcBWzwf8+1S2XGPVluXUtVS8eVVaZSuFhQgBff3qIeKpFBjmW5jbPPK5H6DimeV5dl5zPKpLbUyT+PHpUM1n5kaiQvKSPlUnJGen/wCqhIpo2IPEavIictnrnGT9K39B1Xw9Nfxza39pFip+ZY0zls9GwchfXHNcHHDDbRoiRMUIO4yDp/8ArP6VoQpD5G4m2fexKwyvsPHfd2x70C5Uz6X1TxBpPh/w1FfwLE1s6AWkNuAolyMgLjoPU9q8V1fW9c8WaikUkksryPths4MhAfQL3+prKtXnRILPzojEqfLE0+SrZOSO2Dx+Vd/8KoYZtev5ztZ4rUCM9cbmw38gKaZMk9jmrj4feKbGH7WLLLR/Ni2nDSL7gDnP0rb0DX9P8X26+H/FUKPdH5ba7I2O7emf4ZP0boRmvXTH7dO9eSfFPw7Da3VvrNugT7U5jnC8fvAMh/YkA59wDRcHHl1Rg6r8Ntesr94bG2N/bdY5lkVDj0YEjDD24orsfDfxH00aLFHr00wvoiUMiR7vNUdGPv2PuM96Kd2K0DmRFXMeJ9d+x29xbQDEmNm73rspkMcLsOqqTzXkmozfbbt2mYsSeMHGeaTGkU4fMlB2lAQM/OeP/r1qF3+wyzAoEUKAVbOSc9PyrKlEjS7Sg/2R6CpWwsRjUEE8nnr6fWpLRLHeOqAPISAMruGcVoDVFZrcTYTDjJxyx9c1z7vLCwZCVGKel074UW4bHOCM1QXL1wWlVi5bqSDkjIqxYwNeRfZgpcg5DY6+1Q2dle3TAxIiqeNvvW/YaBcpMjksjsdvtmpcjWNOT1K/lT/YWhuY0+UEKyyHfHzk4xxXVeDPFJ0HWob0ruhkxDcgKB+7OBkY7g4P51duvDZs9Mkurjy1hiAbGNxc9kVe/Pc1yEkEiKHNr5LkmYLnsCMZFSpXZVSjZXPqK2uYLy1juLaVJoJV3JIhyGFeefFm+t00qz07cDcSTiYoOqoqkZP1J/Q151p+s6jYxbtP1C5tfMALrDIQpbvx0qpczz3dw89xNJNM5y0kjFmP1J@rRI5ZStoVCoBororPwjd3tss41LRoA3RJr9Q34gZxRTM7M6Oa3LwOvqpH6V4lIu+4CFSGQ9K99MWVxXjHiG0/s7xHdW5GAG3Lj0Iz/AFpM2RUtIhcXOZPv9DV6fRpJ5xIBlRwGPXFaHhvSlffcyjJJwAa7K3sFkAAUYrmqVeWWh30qClHU4L/hG5bqF0jDb1+bGOv0pdI0pxdJaS2zpIT8hA6/Q+tewaXo6Da2wDsceldFDpdtFtcRKCDkECiNaTNJYeEWrnBaF4Du1l8yVyqE52so5+tdQfDscZKgHdkMCRxkV0sP+twOgq0UjAJZgMdqNXqS5qOljHuLOOaAIyAjAIBHQ15D4v0ya0uJFTJCoQXI7/5zXss93aRvs85dxPAJ71yvjSyaXR5biKJZGiUu69yuOce+M0k7SuynecGjyzT4itqQTx157VrXGgatbWC38+nXCWbqrCcr8uD0PtnI61c8KaB/bXiGOxGWtywklI7Qjr+fA/GvUNVuH1y38VaKsDRw2tqggJiKh22sTgkYIBVRxXWeVNXZ4gUUnlR+VFb+jabol9aPLqWstYyiTCxiEvuXAO7OPUkfhRTM7Hb+XkV5b8TNOFrqltqCn/j5Qqw91wP5EV61tGK8/wDitCJNIsMDLid8DHqv/wBYVLN0Q2NqNI0uBJ2G5VBdvUnk0w+M7W1GEA64z1pviG3N+toC7hDGHZUOM5Aqhp9tpljMUmsftUpBIRkLEADJwBycAcnge9ccVFu8j0eaVvdOm034iW0LbXBds/dA6V3mm+JbXVYA6ZUjtXmkFvaahbPc2OmGOOODz32hCUTOMsoYkc/U1NaibTLuErIfJkAYEHIIPvTn7uyLprn3dz0zU9VaxtnliXJ+n6151deJPFF/cOluiiEsMMx2kV380MF7pkI3E5HOa5PWNFuBLLCt08KmImGSIKSH7Zz2+nNTGbuW6atoVILLVJmUXV1aFmzgCUEj8u9bWjQX9rOY7y7ae1fIELJn8c+ntWbZaNqVxptwDeXAumKLFDI5mhAGd7OH657bcEY7V2en6Y9vYKlw4eRFHTJH681c5PYiEYrV6HIeFdRj8I3fiKNozJJEmy3wBnAY4z7DKk1p+GviFdNqZg8Q3sJsmhb955GCHyMZ29iM9qr6vZBZ9XmKgbrZHBA+qn+Qri3QZzgV0U5cyPOxUFCSt1Ov8P6V4Ik0+RtX1FDcC4lVQbho/wB2GITgY6qAfxorizGM9KK0sctz1TGBWP4k0uPVNFuomXLiMtGfRhzW0QeKQjb2yM0mdCOBsVS602ylkViXtkxjscAVas9Alh1D7fYb1nxjeDzj057U+3tBZxmzByLaR4gf9ncSv6EVv6VNtj2d81wSupOx6tJKcUQadpbafDJlEjDnc/yjk5z93pWTqKbr7cQAM4VfSu1jt2nbc3QVyOpAnWm2cwxnBPvUu7NrJbHXadGDpKd2A71di0+2voNs8asV5GR0qroEBn04yM+NoOAe9TLcC2nZUmRnIyYgfmA+lUlZJszm224xepNDbx2rbVjPtk1alBEW5uuOgpYGiuVDcGmXjBRtXOMVokkrmDbcknucX4qlMUOAf9cnlt9Nwb+lcUwrt/FLw/Y9siZlJAiP905yf0FcS/Wt6HwnFjf4hE@RRSn@rRWxxnqXXGKRxkVXnvLazjEl1cxQR9N0rhR+tYF3440uKN/shku3HdV2Rj3LHt9BUnQk3ohdcV7W7ExYGObjHoQKXTroB1OeOvFcpqXjuHWJ/sUdtEkaN/rPNLNux06YxVjT70+Yvzda46ytK56OFleJ6bHeKlqxzyRjmuL8QWe92ltJpFJ5I3Hr6j/wCvWhLcstpHsPDHmsSXWYmlePEjbTjCRk1CbaOltJ6Gz4en1FUQXNwq2/T7nzH8elddaWttDdNcLGvmN1Y9TXJ6ZrFtLbRWzafeb84J8okE1tC61K5GI9NEcQGAZJNv+NXFeQNNo0pZPslxvj/1Tnkf3TSzzFhuz0rDVtThllF5FEbdjlDE5JX61pSSr5O4HtWcmwUVucr4pm33ESegJrmXHNaurXAuNRlYH5QdorLfGa9CkrQSPExMuao2RH@rRSn@rRVmFzA1C8vdQvI3neS4bGC0j9Pw/wqC9YpYNEsm0q+1QBwxPc1UuJ4I3G2GQ56Zbj+dQ6pdGe1BICbiCAvYCuJRqVWlJWR9Y54HL4SlRlzTem9/XZL8y7zHa4/chlBLc8+/8AKrtrfNBKRycGuZH7wLD/AAsM57mtC1m+0Qhs4kT5X+o70p0nT3MVio45tQjaSWnn36I9KstZgnsNjc+oPapEZXx5fFcJZ3zW78/iK6zS9Qj+SQnKk84rNq2xhGWup0MGo30EW2MBQPbOa2NOvrq7TEzAgelLpn2WWPcGVmIzj0rSS5tERhwHHtT3W5pzFW6kYJgDrxXNa7rEekWKvK/+skWGNc9WY8f1rW1TUY0T5WG89Oa8x+IkknlafG33gWnx6YwB/Wkldi57O5dGoI148Em1O6szAZ/P604TJJkoyt9Dms26yUkYJHKAMrG/c+x7cYrPjjmt7hbqyk2I4+dCcEDuM8g/iK6qeIhZKWheNyCtzuWHXMu1tl+vyOgJ5oqsrvNl1uoUBP3ZYjkf98nFFdHNHujxXl2KTt7OX3P/ACOXvrciPA6iQgZ/OodTtmTTklBUhR0B5Fat6gjuzDKfljR5WPsq8f0rPmJl06SJgQY4VVgR/GTlv1q2jAoWw3gHPIAwfemCaS1uvOXgdHHYin2yN5SY6lsVOsYnt5kIww5RjUuPMrMqE5U5KUXZo0IpY7iPK8jqR3WrMElxbHdE2+M1ziCa03MdyIj7Se8Z9D7VsWGrCGdBcKAT3H3WFcc6Thtqj24Yili/i92f4P8AyZ0+n+Jbm14Cg+oLVpr4jvrshY4wpPHByas6fpNjqdqs9uVZT6jpWrBpS2pG1V/AVzuouwOlOL5ZEOnWEr/6TeHLdQDXEeO3+0auVHIigP616NcTeRAS3AFebXyHU9UuJGz5bHaWHf2HvTg7u7GqUqjVOmrtla6uhHp9nOCdzFWKjum3J/XFU7SdoNQVJCZbeU7lBYj8eKTVypaN4+IUUwxgdDjuPbPH4VH5T70SP7yZdP8ACu+nSi6aUkRjswq08ZJ0p6J@rro7JJmg8kQOA2fXkGiqgmJJKgAE5we3tRWP1J919yO3/AFjX8j/8DkTani51a5Vhj54YuP7pJJH44xVS1Buo5S5P72bLfn@RRXafLjfKWGdlXoGBFaUljEkAXqCoz+I5ooph1KMaB9PErDLySGNz/AHiuCG+uOKyHIjn8kqGjZyu3pt9x6UUVD2H1Oo8HazdaTrhtFYywl1QhjjgnFezzlY4y4UZx@RRXk4hJVGfRU25YWnJ76/gzgtd1GaSZ4zwg7A9a5LULuRXFvHhMqPmA6Zz0/KiitKKTmkz0ZfucqlVp6SbtfruO1+JEsLaJVAWAKF/HrVXPlvuHJCqaKK9c+Le5Uvx5V22w4DAN+NFFFQ9xpH//Z",
				ifeFrontal: "/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAA9AGQDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDmbSxt7TTohFEAFjX5QOvH+NUp5jBKQsYOe3GD9OK7CHSob66Wz2GFGs0ZSn8LbQQfzrNuPDNy1z5Uds/mbhyjBgPxJBx9awTXU2kmigJLYWyyyGOLecbiowTjP8qckdmScTID1OF5/LHHUfmK6i18ITR24QtA5J3FccLx0FPfw1cpkC1iYD+6RSugszlmhMbZhszOjrneMDn+tKwmYc2KkZz056fzrZu/DNxcEebZ3GAAAE4Ht0qonhHdgLa3hA44Df0+lPQNSilvIXG6zAU55Hbj9KjSCYkE6a6+5+bJ9OPw5rVXw2YZY3EV4jIQVJ3dvXjnt1preEw7MywXIz6Fuvc/z/M0aC1M3y7kN/yDGOQOmBg9xz6etTfvB5RWxJDj58pynI4x+taEvhJ5VcmC4LEDJz6dMA/55qfS9B2o8VuwDv8AMyTSfP8AkeaOlws27GIvnlc/YQG4O0j+uKjaWYZ/4lzMMZBC9R+I9+ldk3h26XBdkAPXCk1C+i7VO5pSB6DFTdGioyZ5j4h0e0mvophEIy8QLBRtycnqPWitjxUgtdSgjW3R/wBwDl2GfvNRWqloRKFnY7zRXWbxBbEsSPsKdeB9xa3dVvtK0S1mv72dYIxgF2PUnsB1J9hWDoAVfEMIAAAslzk/7Arj/inO91rthbTb2tobdpSin+Jn25/IdaxSuzST0OptPin4Rnu/IeW8gUgKJpYMJ+JBJH1Iru7b7Ncxq0ZDKw3KwOQR1BBHUV8/vp/h5NNSUWk5ll4AGcoR1zzjv+NepfDK4eLwlawTyEmGSWJMgkhA52g0NJ6oLNbnI31pDHLse58zg8qLkdfxx3/D8K7zw1qYvLRoraQ+bbhVlRlYKT2IJ65xXMT3g895iuofIG3M97HtG7IztPfnI/CrukXVlbSrd/bp/OKtHJDNcbwADwwAGO361T1RmtGdfMt5Pt/dgYGMs2RUas8cnlSgA44I6H6U+y1S1voi9vLHIAcMVbIzUk8ENyPmLLzwwPSoLuNxuB4GaydXW3f7LHdgCBpCHYkjHynAyORnpWpcx+QqyQDYB175FPEiyRgoRg9eO9NaaiZxt7pjme@Rrae3S2U7o/NeU7RtIOTnn8Kzo7S0eeO4+3Wc9oGCYjeUsS2dvfH4/nXQeK7+axtRLGxwiltqgfMR0FcVa65q1zqAW7uIJI5gQvkqVMfGfyqk3YpST3K/jUJBqttCIsqlqoXvxubuaKh8YmZdRtBPPGzfZVIOcHG5uvBoqlsTJ6nd6LkeIYsLn/Ql4/wCAisHx+gttS0+/dFMcgaB89sHcP5mtjSJduvo5BO2xH/oIrm/EsV94qtklTcbSBmWa3TkxPn5X98jj2rNNdTTkk1zLoZ1leQqsuYo9pLEAnOzPIz+Ar0bwlA9ro9vuXY8gMhHpu5H6Yry618HXzlY1lluFXlYhwB7k9hXpWia8lxqAtHXP8Mcijh8AZPtUvl6FONSUdtjLcuZxFIJ+n/LSxUY6HqP8/lUNyJoTcSwC4CD7oSwXGSMZB7nH862JvPZpig1vcowFaRUzk4OPcdfwqGQX6Ku6215w2dwFwFEf6c/qK0RztFSC61HTpYo4VnEULAS7LQbJjk8g9emBxWlFqeqTpM6XF8EVkO1rDDEbuVGDzx19M1QS3nuVYmw1xfkVTuuwd3GOff3qKOz1F2yLLXSecBL1ecd8fhinoI6LTYtVv3S4m1SZYVlO62mtAhIBz164xxmr0cii4KIgRecKPrWXPoUlpaO4n1edhtbZFcHe3bAziqFi8ulO5GmazNu2584qxHX/AGvz/Cpeo9g8azIIYITktKrBVHUmuJsJZIJlkvI/LQfxZyMn+mK7u+ZdUm@Rr3SL+JIlLoZcL83YcEnJrJfT4ZLXzm0e8ADbwvndCeOtF2WuU5jxjaW9xqFlIIw2bNeQ5GfmaipfEVqI7u2QySqotwFG48AMwH8qKqL0M2tTrdFCnXV3ybQbQYOP9kVr6LosWmyXKx3ZPmc9Oh5/xrgvC2svqRtbx4tsgh8tsN1K/KT04zjOK7O31Fm4CEELnO7/61ZOLTOhVGo2XU27HSvs8cqy6h5wlAyGUD+XU1FpPh200nJF2ZCr70O0ZBxis6LUpJAxwwKkry2f6U/7bJ759c1Ni3Vk013IRLDDerJ/xUc+yTdhotyvz3H+elSPdm0gjNvp+oSC6YyMJD8yHPQg9PpRLdSZHJ4OetRm9kL7TzgZrS5hykmoeYLa3lKaohLcpYffHHRvb+tV7azWWOeXOuKY42+S7kwXyP4cfxf1qX+0JG+8M4IxzUv8Aacm37vP1ouxcpSsrmW3026tWttXRGAk3ecPOycDCH146e5ptrdW8l6PMj11flZSLtvk6HkjP5e+KsSai5VyyBgOxPWqX9ofv9ojI3An73T9Kd2LlIbDyFusGz1FF2HBuZiy4OOPXPp6U6TWJTqkdjdQNGkh2wshyj+nH5Us1zsQsEPDYxu9s1VlaG9t8z26uqsSAT0I9D2pO442W5z3jea2OqWhXEn+igFgx6iRwaK4/xX@rr3WtskEC28VsggVAc5wSc9B60VrGGhm5an//Z",
				ifeReverso: "/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAA9AGQDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwC/r23Q/C9tHo9rbqYTFEqrbhvlJAPGOT7n3NcifFHiRNKmlSBBJDEhjAsO5cqeMegFUPFiFPE9uuWGNEUH5yMjL96xTJPlnV2Qqvzb5ABjcAPx5z+f0rKMNNTWUnc9B8I69rOqa9bWepwRC2Zpd2bIIQVQFfmx1z+dbeo2EE17dYTadx5GVUfTaK8gFw7xSRo8zOCCG3k/j+gxg1GWLb2DsW3gfL0AxyMDHbn6mhwuCmexJpMC24ZRIrjHUEj+VSvp8CwgRoTnGW29vyrx7zStyCXLhn3YLnGTnOR2xiolAj2uJHRo3KDB53euemMfzpez8w5z2OXSrZB1l9ec/wCFTQ6TakDesjAjlGXcDn14rxe3E8hLINxDFRGzHcQQeR+Ap37/AGArM+ZIiSrs2NuSOOeDnIA9KOTzFz+R7WNLtItscUYCdx5f/wBamS6Ra7wyxKCOD+65/lXiSyyN8ryOx2/KkhySufX8c81IzSBoyFkVXuot538ZDLjj/Paj2Y+c9Uk0+6jlkERsAu0GJJIhuBzyT7Yojs7sXCm5Om+SMbtqKrHgetcbqSMt3p7rEjNLYCMNI64IywYYYYOB/kVlmFJbt1jga4HlHzISrI4RSM4cqSGJ24+hz1FHIP2nkdF4o8K6VqOqJctEInaIBvKAUMcnk46nGOfYUVpyIhtbH5Ci/Zk2qTuwOwzgZ/Kipu+47Ira74W1HVdYgurUwCJdLW1PmyYYP8xHGP8AaHNZv/Cv9a8zcE03jI3PNuIHBA6YPSvY/C5M2mhmYYbacA8D5VroE2BmL4OWGM0Ko0Dgj57XwFr4j2sbIkDK4uQPr/D3FEvgLWEQhnslQfKmLnDAd8cetfQhZHZvlIKev9KxJjq8zSGGCyuV3IIhLKU2jnJyM+3H1o9qxOmjxaHwNrUjMxaxYMeZTcAMp9enPb8B706PwBq3zYktM7WwBc8jJ7HGCcevrXuKNqrWLGOGyiuVaPCeYWXbxv5AHJ5A/DNV4dW1hrgRPonyuCxkW4GxSMAgkjqckjA7U/aMXIjxcfDvWyVZmsVYNw32nlQBx25z+mBSHwDrzhlZrAOW37TfAkkZwRx796+gBLJJaIZEaJmUZQ/w+1fN+n+ItTvPHpunlkDy3pP3zhRvwFGe2BjH1qoybFKKRfPw+14oQraeH2LndeDqCCR0wQcZOae/w58RuYnSG2CJMkh/0lcAAqeOPY/pXue9wjxjbwhJPtg4ri9V1CFPs88dxZII0Ak892Ib5QOm04I+tSptj5EcdqHhrVDe2UIWyYx2yoPMmB2yZJ6Htz1qFfAWuPC@rRzwW90MyMwuAVL56BV/DqSOORyMSL4n1CbVpbrdbRCKTCW+0ldoPTOOc4PPvXbaJqcN5p0WySE3AQebtwWDd8kAc/Sm5NGs6HKk31OV1XR73daxxzvH5VusZCDcMgnvmit3VpFW7X5wPkHGPc0VnzE8pd0q9kitLeGG5kTEahlU9cKB6e1an22YBd9zOoHq4/wAK5ISvDaQXCPHET5WXkcADcVyM+vJH1NUr+81QwOBqun4AnBHHBVjgk442jg//AFqErjbsd7HfyeaP9MmCjIJ3Dn07VMly2NqXtwq9PlIwP0rhAl/JO6pd2pVZiqoCCceWTg8ZJB+bjtU9hPqsUCSf2jZBG+zYaKQYJLYfOR0bOB0OSOlHKFzs3e++ZE1G4OOgJXB/SkeS/jVP+JnP1xggf4Vx11NqqxSSpqtv5ghd8uV2kebjecDjA+XI4z9M1KPt7/aA+swArLcKix4JVVjBA57qSCfY85p2Fc6uSW/2Ni/mBwM5Yf4Vz8Phuxg1FbxbZRMHMgdWxhieuPzNQRy3UwXytcs2ZhCMKcnJQkjrnLY3A45UHgdahjfVre2jebVrQq8SEPvBy3m8nOMEFflyMc/nRZoWh0Qu7tyENxOF5UpuHT8qZJplgsZBhzkdSTXNyx63Kz+VqFuqg3Co8ki5yCcA8fw9D6YOcmonfVnn2nVbXHn7VCSjJXy84K+ufm4osx3Ni70qwJhl8hTIrYDd/wA6sy2Vqu5ghUgZyGINc7CNV+yRyPqdsVLW+JAQytknecYBG7oPXHatOyN+swS81C3nUxy70TAIIkwCAOeBwe2aLMLlTUlJnTGcCMDnn1oqxqMo+0LnH3B/WikMbLAz6BAH02O8P7kiEMVAGRzkeg598VQurJj5saeF2KuLggCU/N82Rxnq459uR3pvhTxLJquhWs0tuFYx7SA+QSvGenfHStKTxIsBmP2Mny8DHm4znHtx1oTa0Cyeo6z0+Oe7Hn6AyYlfY4Zsj92MHOflBJZfQEZ6miK1KRxufDoEgNsCUc7goPJLZw3lgdO5+op134iFlaz3C2rMYwDjzsZ7enFRab4rOoTmE2hQBN2fNz/SjmYWRHDDdJpnkL4XVIlgc+WszcEzL8uRyQQA/wCGParwW6a6lT/hHi6SzTb5jPg5Me0HnoGHy+g496101D5QfKH5+tMOotudQrDj+9/9ajmFymelnEt2tydBVLgvA4ljfnftILE9tgyvPqOxFUktZVsY4m8MhEEUQ2KzAqvmkFSRyQoJfHuRwDzqpqBLDKE4OfvdaedSIdV8s4Y4+90/SlzMfKitewFkmJ8PCVw04IGG3oSuee5fOdvt6iqRgdbxM+HGObgZmNzyB5Y+fr03bhj2Dd61ft5jk27GYHjG/wD+tTLjUTsJ8vGDjhv/AK1HMw5Sg1u37uUaDGkgS33Os5BBUkDODzsH5/hTLURxXkcraPDbYSSPzFkzsG/IUAcYOd2enOKlg1Rp1fMZADEY3en4VUkvfmaMR4GfWjmYcqF1eASXgbLD5Bwp470V5r4m8eajZa3LZ2kcaRwAKTJ85Y9c9sdQMe1FWqbeoudLQ//Z",
				coincidencias: "1-9-3178-4611",
				ruta: "1",
				tipoIdentificacion: "0",
				idSolCliente:"20100103894756720020920287462"
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.obtenerFolioCallCenterOS(request).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							$rootScope.message("Exito", [jsonResponse.descripcion], "Aceptar");
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}
					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'obtenerFolioCallCenterOS'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};

		$scope.busquedaHomonimosOS = function() {
			var request = {
				jsonSolicitud: JSON.stringify({"obligadoSolidario:":"","aceptaConsultaBuro":1,"idCanalAlnova":"9","pedidoSAC":0,"mesaControl":{"folioMCO":"","fechaGeneraFolio":"","contEdicion":0,"cometario":"","origenEdicion":"","existeEdicion":0},"banderaCUDigitalizacion":0,"documentos":{"porcentaje":0,"bloqueado":0,"documento":[],"editable":0,"guardado":0},"sistemaOperativo":"","codigoCorreo":"","campana":"","pedidoSEG":0,"folioCallCenter":"","idEstatusLCR":0,"origenSolicitud":0,"idMotivoBloqueo":0,"aceptaTerminos":1,"banderaOCR":0,"tipoDispersion":0,"tipoSolicitud":56,"terminal":" DFES","idPais":1,"banderaFolioRecomendador":0,"pedido":0,"banderaSeguro":0,"diaPago":"","envioCorreo":0,"transferenciaDatos":0,"idEntidadAlnova":"0127","idSolicitud":"","idSeguimiento":3,"idSolicitudTienda":0,"folioRe comendador":"","banderaEntregaTAZ":0,"tipoCampania":1,"cantidadReenviosCorreo":0,"promocionCorreo":0,"creditoInmediato":0,"banderaIngresos":0,"capacidadPagoComprobable":0,"tratamientoDatos":0,"idEmpleado":931860,"cantidadReenviosCelular":0,"tipoDispositivo":"Windows","idSucursal":6265,"envioCelular":0,"contratos":{"porcentaje":100,"bloqueado":0,"editable":0,"guardado":0,"contrato":[{"statusFirma":2,"descripcion":"Aviso De Privacidad","idTipoPersona":1,"idContrato":"1","idPersona":""},{"statusFirma":2,"descripcion":"BurÃ3 de CrÃ©dito","idTipoPersona":1,"idContrato":"2","idPersona":""},{"statusFirma":0,"descripcion":"Contrato y CarÃ¡tula de CrÃ©dito","idTipoPersona":1,"idContrato":"3","idPersona":""},{"statusFirma":0,"descripcion":"Solicitud de CrÃ©dito","idTipoPersona":1,"idContrato":"4","idPersona":""}]},"diasRechazo":0,"idCanal":9,"clienteForaneoGu ardado":0,"promocionCelular":0,"lineaDeCredito":{"bonificacion":0,"tipoPago":"","capacidadDePagoTotal":0,"pagoAntesDe":"","capacidadDePagoOcupada":0,"siguientePago":0,"capacidadDePagoDisponible":0,"liquidarAhora":0},"cantidadReenviosLlamada":0,"cotizacion":{"clientes":[{"bloqueado":0,"consecutivoPersona":0,"idGenero":"F","estadoCivil":"","ingresosEgresos":{"bloqueado":0,"porcentaje":0,"dependientesMenores":null,"dependientesMayores":null,"flujoEfectivo":[],"editable":0,"guardado":0},"preguntaPEPS":[{"parentesco":0,"status":0,"apellidoPaterno":"","areaAdscritoDes":"","fechaNacimiento":"","cargo":0,"areaAdscrito":1,"parentescoDes":"","numero":1,"nombre":"","dependencia":1,"apellidoMaterno":"","dependenciaDes":"","idPersona":"","cargoDes":""},{"parentesco":0,"status":0,"apellidoPaterno":"","areaAdscritoDes":"","fechaNacimiento":"","cargo":0,"areaAdscrito":1,"parentescoDes":"","numero":2,"nombre":"","dependencia":1,"apellidoMaterno":"","dependenciaDes":"","idPersona":"","cargoDes":""}],"datosEmpleo":[{"bloqueado":1,"idEmpleo":"","nombreEmpresa":"","antiguedad":"","antiguedadDes":"","domicilio":{"numeroExterior":"","estado":"","cp":"","idDomicilio":"","idDelegacion":0,"numeroInterior":"","telefono":"","idEstado":0,"colonia":"","calle":"","delegacion":""},"idTipoPago":0,"editable":0,"ext":"","porcentaje":0,"giro":"","idProfesion":0,"tipoPago":"","profesion":"","idGiro":0,"periodicidad":"","idAntiguedad":0,"empleoActual":0,"idPeriodicidad":0,"guardado":0}],"domicilios":[{"superManzana":"","antiguedad":"","bloqueado":0,"numeroInterior":"","colonia":"","porcentaje":0,"numeroExterior":"","idTipoVivienda":0,"lote":"","guardado":0,"antiguedadDes":"","idDomicilio":"","edificio":"","domicilioActual":1,"telefono":"","manzana":"","andador":"","editable":0,"zonificacion":{"calleIzquierda":"","fov":"","calleDelante":"","zoom":"","calleDerecha":"","referencia":"","idPais":0,"idCuadrante":0,"calleAtras":"","latitud":"","longitud":"","pitch":"","heading":"","idZonaGeo":0},"estado":"","cp":"","idDelegacion":0,"idAntiguedad":0,"idEstado":0,"tipoViviendaDes":"","calle":"","delegacion":""}],"apellidoPaterno":"VILLALOBOS","puestoCUDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":24,"idPuestoSPCU":0,"porcentaje":0,"nombre":"TANIA YAEL","apellidoMaterno":"YAEL","flujoEfectivo":[],"curp":"","idPersona":"","dni":"","guardado":0,"clienteAlnova":"","numCuenta":"","idPuesto":1,"idPuestoCU":0,"huella":"0","bdmid":"","lugarNacimientoDes":"SAN LUIS POTOSI","idNacionalidad":0,"clienteUnico":"","claveElector":"","editable":0,"idTipoTrabajo":0,"nacionalidadDes":"","fechaNaciomiento":"29/02/1988","genero":"FEMENINO","email":"","puestoDes":"","foto":"0","clienteTien da":"","idEstadoCivil":0,"folioIdentificacion":"123456789","tipoTrabajoDes":"","fechaVigenciaIdentificacion":"","celular":"3313101463"}],"idPresupuesto":0,"statusCotizacion":1,"fechaVigencia":"","pagoNormal":47,"detallesCotizacion":[{"intereses":1806,"idDetalle":"","cantidad":1,"idProducto":"2","enganche":0,"montoText":"2,000","monto":2000}],"idPlazo":5,"pagoPuntual":40,"periodicidad":"Semanal","plazo":80,"ultimoAbono":93,"idPeriodicidad":1,"idCotizacion":"","montoTotal":3806},"banderaSolidario":0,"codigoCelular":"aBArCkh+71x5gk789esREg==","idProducto":21,"respuestaCallCenter":0,"capacidadPagoNoComprobable":0,"idCondicion":0,"avales":[{"idTipo Aval":0,"bloqueado":1,"aceptaConsultaBuro":0,"idGenero":"","estadoCivil":"","idTipoPropiedad":0,"codigoCorreo":"","apellidoCasada":"","idMotivoBloqueo":0,"tipoPropiedadDes":"","banderaOCR":0,"aceptaTerminos":0,"pri merInser":0,"curp":"","flujoEfectivo":[],"idPersona":"","envioCorreo":0,"presencial":0,"guardado":0,"idSeguimiento":0,"idPuesto":1,"cantidadReenviosCorreo":0,"idNacionalidad":0,"clienteUnico":"","parentescoDes":"","edita ble":0,"datosHogar":{"antiguedad":"","superManzana":"","bloqueado":0,"numeroInterior":"","claseViviendaDes":"","colonia":"","porcentaje":0,"lote":"","idTipoVivienda":0,"numeroExterior":"","guardado":0,"antiguedadDes":"","idDomicilio":"","edificio":"","domicilioActual":1,"telefono":"","idClaseVivienda":0,"manzana":"","andador":"","editable":0,"zonificacion":{"calleIzquierda":"","fov":"","calleDelante":"","zoom":"","calleDerecha":"","referencia":"","idPais":0,"idCuadrante":0,"calleAtras":"","latitud":"","longitud":"","pitch":"","heading":"","idZonaGeo":0},"estado":"","cp":"","idDelegacion":0,"idAntiguedad":0,"tipoViviendaDes":"","idEstado":0,"calle":"","delegacion":""},"nacionalidadDes":"","email":"","cantidadReenviosCelular":0,"envioCelular":0,"folioIdentificacion":"","clienteFo raneoGuardado":0,"fechaVigenciaIdentificacion":"","celular":"","consecutivoPersona":0,"tipoAvalDes":"","codigo Celular":"","apellidoPaterno":"","idCondicion":0,"rfc":"","idLugarNacimiento":0,"porcentajeContacto":0,"nombre":"","porcentaje":0,"porcentajeBasico":0,"idMotivoRechazo":0,"apellidoMaterno":"","dni":"","idParentesco":0,"clienteAlnova":"","huella":"","lugarNacimientoDes":"","consultaMatriz":0,"marca":0,"consultaBuro":0,"existeCita":0,"fechaNaciomiento":"","genero":"","puestoDes":"","foto":"","idEstadoCivil":0,"clienteTienda":""}],"pushId":"","banderaPrueba":0,"idMotivoRechazo":0,"idSolicitudTiendaCredInm":0,"direccionIp":"10.53.37.58 ","tipoLevanta miento":2,"consultaMatriz":0,"referencias":{"porcentaje":0,"bloqueado":0,"editable":0,"guardado":0,"referencia":[{"idParentesco":0,"lugarNacimientoDes":"","idGenero":"","estadoCivil":"","telefonoCasa":"","apellidoPaterno":"","idNacionalidad":0,"parentescoDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":0,"nombre":"","nacionalidadDes":"","fechaNaciomiento":"","genero":"","email":"","apellidoMaterno":"","curp":"","idPersona":"","idEstadoCivil":0,"dni":"","celular":""},{"idParentesco":0,"lugarNacimientoDes":"","idGenero":"","estadoCivil":"","telefonoCasa":"","apellidoPaterno":"","idNacionalidad":0,"parentescoDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":0,"nombre":"","nacionalidadDes":"","fechaNaciomiento":"","genero":"","email":"","apellidoMaterno":"","curp":"","idPersona":"","idEstadoCivil":0,"dni":"","celular":""}]},"marca":0,"consultaBuro":0,"seguroDeVida":{"clavePromocion":"","opcionSeguro":0,"montoFinal":0,"abonoSeguro":0,"precioSeguro":0,"sobrePrecioSeguro":0,"montoInicial":0,"esDefault":0,"ultimoAbonoSeguro":0,"totalSeguro":0,"nombreSeguro":"","idSeguro":"","comisionVenta":0},"existeCita":0,"banderaOfertaCP":0,"idPlataforma":1,"preguntasInvestigacion":[{"idVecino":1,"idPregunta":"700 ","respuestaDes":"","preguntaDes":"¿Cual es el Nombre del Cliente?"},{"idVecino":1,"idPregunta":"713 ","respuestaDes":"","preguntaDes":"¿Es una persona de confianza?"}]}),
				idSolicitudCliente: "2018042608445484454803910",
				huella: "30820201308201ABASDFASDASDASGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFGSDFSFGSDFGSDFGSDFGSDFGSFDG",
				tipoBusqueda: "1",
				terminal: "USRE",
				nombreSucursal: "Sucursal Lejana",
				tipoIdentificacion: "1",
				statusOCR:"2",
				folioDigitalizacion:"45GFD$GGG44"
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.busquedaHomonimosOS(request).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							$rootScope.message("Exito", [jsonResponse.descripcion], "Aceptar");
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}
					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'busquedaHomonimosOS'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};
		
		$scope.buscarCUOS = function() {
			var request = {
				opcion: "6318",
				idSolicitudCliente: "20170630174227174228201666",
				solicitud: JSON.stringify({"obligadoSolidario:":"","aceptaConsultaBuro":1,"idCanalAlnova":"9","pedidoSAC":0,"mesaControl":{"folioMCO":"","fechaGeneraFolio":"","contEdicion":0,"cometario":"","origenEdicion":"","existeEdicion":0},"banderaCUDigitalizacion":0,"documentos":{"porcentaje":0,"bloqueado":0,"documento":[],"editable":0,"guardado":0},"sistemaOperativo":"","codigoCorreo":"","campana":"","pedidoSEG":0,"folioCallCenter":"","idEstatusLCR":0,"origenSolicitud":0,"idMotivoBloqueo":0,"aceptaTerminos":1,"banderaOCR":0,"tipoDispersion":0,"tipoSolicitud":56,"terminal":" DFES","idPais":1,"banderaFolioRecomendador":0,"pedido":0,"banderaSeguro":0,"diaPago":"","envioCorreo":0,"transferenciaDatos":0,"idEntidadAlnova":"0127","idSolicitud":"","idSeguimiento":3,"idSolicitudTienda":0,"folioRe comendador":"","banderaEntregaTAZ":0,"tipoCampania":1,"cantidadReenviosCorreo":0,"promocionCorreo":0,"creditoInmediato":0,"banderaIngresos":0,"capacidadPagoComprobable":0,"tratamientoDatos":0,"idEmpleado":931860,"cantidadReenviosCelular":0,"tipoDispositivo":"Windows","idSucursal":6265,"envioCelular":0,"contratos":{"porcentaje":100,"bloqueado":0,"editable":0,"guardado":0,"contrato":[{"statusFirma":2,"descripcion":"Aviso De Privacidad","idTipoPersona":1,"idContrato":"1","idPersona":""},{"statusFirma":2,"descripcion":"BurÃ3 de CrÃ©dito","idTipoPersona":1,"idContrato":"2","idPersona":""},{"statusFirma":0,"descripcion":"Contrato y CarÃ¡tula de CrÃ©dito","idTipoPersona":1,"idContrato":"3","idPersona":""},{"statusFirma":0,"descripcion":"Solicitud de CrÃ©dito","idTipoPersona":1,"idContrato":"4","idPersona":""}]},"diasRechazo":0,"idCanal":9,"clienteForaneoGu ardado":0,"promocionCelular":0,"lineaDeCredito":{"bonificacion":0,"tipoPago":"","capacidadDePagoTotal":0,"pagoAntesDe":"","capacidadDePagoOcupada":0,"siguientePago":0,"capacidadDePagoDisponible":0,"liquidarAhora":0},"cantidadReenviosLlamada":0,"cotizacion":{"clientes":[{"bloqueado":0,"consecutivoPersona":0,"idGenero":"F","estadoCivil":"","ingresosEgresos":{"bloqueado":0,"porcentaje":0,"dependientesMenores":null,"dependientesMayores":null,"flujoEfectivo":[],"editable":0,"guardado":0},"preguntaPEPS":[{"parentesco":0,"status":0,"apellidoPaterno":"","areaAdscritoDes":"","fechaNacimiento":"","cargo":0,"areaAdscrito":1,"parentescoDes":"","numero":1,"nombre":"","dependencia":1,"apellidoMaterno":"","dependenciaDes":"","idPersona":"","cargoDes":""},{"parentesco":0,"status":0,"apellidoPaterno":"","areaAdscritoDes":"","fechaNacimiento":"","cargo":0,"areaAdscrito":1,"parentescoDes":"","numero":2,"nombre":"","dependencia":1,"apellidoMaterno":"","dependenciaDes":"","idPersona":"","cargoDes":""}],"datosEmpleo":[{"bloqueado":1,"idEmpleo":"","nombreEmpresa":"","antiguedad":"","antiguedadDes":"","domicilio":{"numeroExterior":"","estado":"","cp":"","idDomicilio":"","idDelegacion":0,"numeroInterior":"","telefono":"","idEstado":0,"colonia":"","calle":"","delegacion":""},"idTipoPago":0,"editable":0,"ext":"","porcentaje":0,"giro":"","idProfesion":0,"tipoPago":"","profesion":"","idGiro":0,"periodicidad":"","idAntiguedad":0,"empleoActual":0,"idPeriodicidad":0,"guardado":0}],"domicilios":[{"superManzana":"","antiguedad":"","bloqueado":0,"numeroInterior":"","colonia":"","porcentaje":0,"numeroExterior":"","idTipoVivienda":0,"lote":"","guardado":0,"antiguedadDes":"","idDomicilio":"","edificio":"","domicilioActual":1,"telefono":"","manzana":"","andador":"","editable":0,"zonificacion":{"calleIzquierda":"","fov":"","calleDelante":"","zoom":"","calleDerecha":"","referencia":"","idPais":0,"idCuadrante":0,"calleAtras":"","latitud":"","longitud":"","pitch":"","heading":"","idZonaGeo":0},"estado":"","cp":"","idDelegacion":0,"idAntiguedad":0,"idEstado":0,"tipoViviendaDes":"","calle":"","delegacion":""}],"apellidoPaterno":"VILLALOBOS","puestoCUDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":24,"idPuestoSPCU":0,"porcentaje":0,"nombre":"TANIA YAEL","apellidoMaterno":"YAEL","flujoEfectivo":[],"curp":"","idPersona":"","dni":"","guardado":0,"clienteAlnova":"","numCuenta":"","idPuesto":1,"idPuestoCU":0,"huella":"0","bdmid":"","lugarNacimientoDes":"SAN LUIS POTOSI","idNacionalidad":0,"clienteUnico":"","claveElector":"","editable":0,"idTipoTrabajo":0,"nacionalidadDes":"","fechaNaciomiento":"29/02/1988","genero":"FEMENINO","email":"","puestoDes":"","foto":"0","clienteTien da":"","idEstadoCivil":0,"folioIdentificacion":"123456789","tipoTrabajoDes":"","fechaVigenciaIdentificacion":"","celular":"3313101463"}],"idPresupuesto":0,"statusCotizacion":1,"fechaVigencia":"","pagoNormal":47,"detallesCotizacion":[{"intereses":1806,"idDetalle":"","cantidad":1,"idProducto":"2","enganche":0,"montoText":"2,000","monto":2000}],"idPlazo":5,"pagoPuntual":40,"periodicidad":"Semanal","plazo":80,"ultimoAbono":93,"idPeriodicidad":1,"idCotizacion":"","montoTotal":3806},"banderaSolidario":0,"codigoCelular":"aBArCkh+71x5gk789esREg==","idProducto":21,"respuestaCallCenter":0,"capacidadPagoNoComprobable":0,"idCondicion":0,"avales":[{"idTipo Aval":0,"bloqueado":1,"aceptaConsultaBuro":0,"idGenero":"","estadoCivil":"","idTipoPropiedad":0,"codigoCorreo":"","apellidoCasada":"","idMotivoBloqueo":0,"tipoPropiedadDes":"","banderaOCR":0,"aceptaTerminos":0,"pri merInser":0,"curp":"","flujoEfectivo":[],"idPersona":"","envioCorreo":0,"presencial":0,"guardado":0,"idSeguimiento":0,"idPuesto":1,"cantidadReenviosCorreo":0,"idNacionalidad":0,"clienteUnico":"","parentescoDes":"","edita ble":0,"datosHogar":{"antiguedad":"","superManzana":"","bloqueado":0,"numeroInterior":"","claseViviendaDes":"","colonia":"","porcentaje":0,"lote":"","idTipoVivienda":0,"numeroExterior":"","guardado":0,"antiguedadDes":"","idDomicilio":"","edificio":"","domicilioActual":1,"telefono":"","idClaseVivienda":0,"manzana":"","andador":"","editable":0,"zonificacion":{"calleIzquierda":"","fov":"","calleDelante":"","zoom":"","calleDerecha":"","referencia":"","idPais":0,"idCuadrante":0,"calleAtras":"","latitud":"","longitud":"","pitch":"","heading":"","idZonaGeo":0},"estado":"","cp":"","idDelegacion":0,"idAntiguedad":0,"tipoViviendaDes":"","idEstado":0,"calle":"","delegacion":""},"nacionalidadDes":"","email":"","cantidadReenviosCelular":0,"envioCelular":0,"folioIdentificacion":"","clienteFo raneoGuardado":0,"fechaVigenciaIdentificacion":"","celular":"","consecutivoPersona":0,"tipoAvalDes":"","codigo Celular":"","apellidoPaterno":"","idCondicion":0,"rfc":"","idLugarNacimiento":0,"porcentajeContacto":0,"nombre":"","porcentaje":0,"porcentajeBasico":0,"idMotivoRechazo":0,"apellidoMaterno":"","dni":"","idParentesco":0,"clienteAlnova":"","huella":"","lugarNacimientoDes":"","consultaMatriz":0,"marca":0,"consultaBuro":0,"existeCita":0,"fechaNaciomiento":"","genero":"","puestoDes":"","foto":"","idEstadoCivil":0,"clienteTienda":""}],"pushId":"","banderaPrueba":0,"idMotivoRechazo":0,"idSolicitudTiendaCredInm":0,"direccionIp":"10.53.37.58 ","tipoLevanta miento":2,"consultaMatriz":0,"referencias":{"porcentaje":0,"bloqueado":0,"editable":0,"guardado":0,"referencia":[{"idParentesco":0,"lugarNacimientoDes":"","idGenero":"","estadoCivil":"","telefonoCasa":"","apellidoPaterno":"","idNacionalidad":0,"parentescoDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":0,"nombre":"","nacionalidadDes":"","fechaNaciomiento":"","genero":"","email":"","apellidoMaterno":"","curp":"","idPersona":"","idEstadoCivil":0,"dni":"","celular":""},{"idParentesco":0,"lugarNacimientoDes":"","idGenero":"","estadoCivil":"","telefonoCasa":"","apellidoPaterno":"","idNacionalidad":0,"parentescoDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":0,"nombre":"","nacionalidadDes":"","fechaNaciomiento":"","genero":"","email":"","apellidoMaterno":"","curp":"","idPersona":"","idEstadoCivil":0,"dni":"","celular":""}]},"marca":0,"consultaBuro":0,"seguroDeVida":{"clavePromocion":"","opcionSeguro":0,"montoFinal":0,"abonoSeguro":0,"precioSeguro":0,"sobrePrecioSeguro":0,"montoInicial":0,"esDefault":0,"ultimoAbonoSeguro":0,"totalSeguro":0,"nombreSeguro":"","idSeguro":"","comisionVenta":0},"existeCita":0,"banderaOfertaCP":0,"idPlataforma":1,"preguntasInvestigacion":[{"idVecino":1,"idPregunta":"700 ","respuestaDes":"","preguntaDes":"¿Cual es el Nombre del Cliente?"},{"idVecino":1,"idPregunta":"713 ","respuestaDes":"","preguntaDes":"¿Es una persona de confianza?"}]})
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.buscarCUOS(request).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							$rootScope.message("Exito", [jsonResponse.descripcion], "Aceptar");
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}
					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'buscarCUOS'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};
		
		$scope.guardaSeccionOS = function() {
			var request = {
				solicitud: JSON.stringify({"obligadoSolidario:":"","aceptaConsultaBuro":1,"idCanalAlnova":"9","pedidoSAC":0,"mesaControl":{"folioMCO":"","fechaGeneraFolio":"","contEdicion":0,"cometario":"","origenEdicion":"","existeEdicion":0},"banderaCUDigitalizacion":0,"documentos":{"porcentaje":0,"bloqueado":0,"documento":[],"editable":0,"guardado":0},"sistemaOperativo":"","codigoCorreo":"","campana":"","pedidoSEG":0,"folioCallCenter":"","idEstatusLCR":0,"origenSolicitud":0,"idMotivoBloqueo":0,"aceptaTerminos":1,"banderaOCR":0,"tipoDispersion":0,"tipoSolicitud":56,"terminal":" DFES","idPais":1,"banderaFolioRecomendador":0,"pedido":0,"banderaSeguro":0,"diaPago":"","envioCorreo":0,"transferenciaDatos":0,"idEntidadAlnova":"0127","idSolicitud":"","idSeguimiento":3,"idSolicitudTienda":0,"folioRe comendador":"","banderaEntregaTAZ":0,"tipoCampania":1,"cantidadReenviosCorreo":0,"promocionCorreo":0,"creditoInmediato":0,"banderaIngresos":0,"capacidadPagoComprobable":0,"tratamientoDatos":0,"idEmpleado":931860,"cantidadReenviosCelular":0,"tipoDispositivo":"Windows","idSucursal":6265,"envioCelular":0,"contratos":{"porcentaje":100,"bloqueado":0,"editable":0,"guardado":0,"contrato":[{"statusFirma":2,"descripcion":"Aviso De Privacidad","idTipoPersona":1,"idContrato":"1","idPersona":""},{"statusFirma":2,"descripcion":"BurÃ3 de CrÃ©dito","idTipoPersona":1,"idContrato":"2","idPersona":""},{"statusFirma":0,"descripcion":"Contrato y CarÃ¡tula de CrÃ©dito","idTipoPersona":1,"idContrato":"3","idPersona":""},{"statusFirma":0,"descripcion":"Solicitud de CrÃ©dito","idTipoPersona":1,"idContrato":"4","idPersona":""}]},"diasRechazo":0,"idCanal":9,"clienteForaneoGu ardado":0,"promocionCelular":0,"lineaDeCredito":{"bonificacion":0,"tipoPago":"","capacidadDePagoTotal":0,"pagoAntesDe":"","capacidadDePagoOcupada":0,"siguientePago":0,"capacidadDePagoDisponible":0,"liquidarAhora":0},"cantidadReenviosLlamada":0,"cotizacion":{"clientes":[{"bloqueado":0,"consecutivoPersona":0,"idGenero":"F","estadoCivil":"","ingresosEgresos":{"bloqueado":0,"porcentaje":0,"dependientesMenores":null,"dependientesMayores":null,"flujoEfectivo":[],"editable":0,"guardado":0},"preguntaPEPS":[{"parentesco":0,"status":0,"apellidoPaterno":"","areaAdscritoDes":"","fechaNacimiento":"","cargo":0,"areaAdscrito":1,"parentescoDes":"","numero":1,"nombre":"","dependencia":1,"apellidoMaterno":"","dependenciaDes":"","idPersona":"","cargoDes":""},{"parentesco":0,"status":0,"apellidoPaterno":"","areaAdscritoDes":"","fechaNacimiento":"","cargo":0,"areaAdscrito":1,"parentescoDes":"","numero":2,"nombre":"","dependencia":1,"apellidoMaterno":"","dependenciaDes":"","idPersona":"","cargoDes":""}],"datosEmpleo":[{"bloqueado":1,"idEmpleo":"","nombreEmpresa":"","antiguedad":"","antiguedadDes":"","domicilio":{"numeroExterior":"","estado":"","cp":"","idDomicilio":"","idDelegacion":0,"numeroInterior":"","telefono":"","idEstado":0,"colonia":"","calle":"","delegacion":""},"idTipoPago":0,"editable":0,"ext":"","porcentaje":0,"giro":"","idProfesion":0,"tipoPago":"","profesion":"","idGiro":0,"periodicidad":"","idAntiguedad":0,"empleoActual":0,"idPeriodicidad":0,"guardado":0}],"domicilios":[{"superManzana":"","antiguedad":"","bloqueado":0,"numeroInterior":"","colonia":"","porcentaje":0,"numeroExterior":"","idTipoVivienda":0,"lote":"","guardado":0,"antiguedadDes":"","idDomicilio":"","edificio":"","domicilioActual":1,"telefono":"","manzana":"","andador":"","editable":0,"zonificacion":{"calleIzquierda":"","fov":"","calleDelante":"","zoom":"","calleDerecha":"","referencia":"","idPais":0,"idCuadrante":0,"calleAtras":"","latitud":"","longitud":"","pitch":"","heading":"","idZonaGeo":0},"estado":"","cp":"","idDelegacion":0,"idAntiguedad":0,"idEstado":0,"tipoViviendaDes":"","calle":"","delegacion":""}],"apellidoPaterno":"VILLALOBOS","puestoCUDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":24,"idPuestoSPCU":0,"porcentaje":0,"nombre":"TANIA YAEL","apellidoMaterno":"YAEL","flujoEfectivo":[],"curp":"","idPersona":"","dni":"","guardado":0,"clienteAlnova":"","numCuenta":"","idPuesto":1,"idPuestoCU":0,"huella":"0","bdmid":"","lugarNacimientoDes":"SAN LUIS POTOSI","idNacionalidad":0,"clienteUnico":"","claveElector":"","editable":0,"idTipoTrabajo":0,"nacionalidadDes":"","fechaNaciomiento":"29/02/1988","genero":"FEMENINO","email":"","puestoDes":"","foto":"0","clienteTien da":"","idEstadoCivil":0,"folioIdentificacion":"123456789","tipoTrabajoDes":"","fechaVigenciaIdentificacion":"","celular":"3313101463"}],"idPresupuesto":0,"statusCotizacion":1,"fechaVigencia":"","pagoNormal":47,"detallesCotizacion":[{"intereses":1806,"idDetalle":"","cantidad":1,"idProducto":"2","enganche":0,"montoText":"2,000","monto":2000}],"idPlazo":5,"pagoPuntual":40,"periodicidad":"Semanal","plazo":80,"ultimoAbono":93,"idPeriodicidad":1,"idCotizacion":"","montoTotal":3806},"banderaSolidario":0,"codigoCelular":"aBArCkh+71x5gk789esREg==","idProducto":21,"respuestaCallCenter":0,"capacidadPagoNoComprobable":0,"idCondicion":0,"avales":[{"idTipo Aval":0,"bloqueado":1,"aceptaConsultaBuro":0,"idGenero":"","estadoCivil":"","idTipoPropiedad":0,"codigoCorreo":"","apellidoCasada":"","idMotivoBloqueo":0,"tipoPropiedadDes":"","banderaOCR":0,"aceptaTerminos":0,"pri merInser":0,"curp":"","flujoEfectivo":[],"idPersona":"","envioCorreo":0,"presencial":0,"guardado":0,"idSeguimiento":0,"idPuesto":1,"cantidadReenviosCorreo":0,"idNacionalidad":0,"clienteUnico":"","parentescoDes":"","edita ble":0,"datosHogar":{"antiguedad":"","superManzana":"","bloqueado":0,"numeroInterior":"","claseViviendaDes":"","colonia":"","porcentaje":0,"lote":"","idTipoVivienda":0,"numeroExterior":"","guardado":0,"antiguedadDes":"","idDomicilio":"","edificio":"","domicilioActual":1,"telefono":"","idClaseVivienda":0,"manzana":"","andador":"","editable":0,"zonificacion":{"calleIzquierda":"","fov":"","calleDelante":"","zoom":"","calleDerecha":"","referencia":"","idPais":0,"idCuadrante":0,"calleAtras":"","latitud":"","longitud":"","pitch":"","heading":"","idZonaGeo":0},"estado":"","cp":"","idDelegacion":0,"idAntiguedad":0,"tipoViviendaDes":"","idEstado":0,"calle":"","delegacion":""},"nacionalidadDes":"","email":"","cantidadReenviosCelular":0,"envioCelular":0,"folioIdentificacion":"","clienteFo raneoGuardado":0,"fechaVigenciaIdentificacion":"","celular":"","consecutivoPersona":0,"tipoAvalDes":"","codigo Celular":"","apellidoPaterno":"","idCondicion":0,"rfc":"","idLugarNacimiento":0,"porcentajeContacto":0,"nombre":"","porcentaje":0,"porcentajeBasico":0,"idMotivoRechazo":0,"apellidoMaterno":"","dni":"","idParentesco":0,"clienteAlnova":"","huella":"","lugarNacimientoDes":"","consultaMatriz":0,"marca":0,"consultaBuro":0,"existeCita":0,"fechaNaciomiento":"","genero":"","puestoDes":"","foto":"","idEstadoCivil":0,"clienteTienda":""}],"pushId":"","banderaPrueba":0,"idMotivoRechazo":0,"idSolicitudTiendaCredInm":0,"direccionIp":"10.53.37.58 ","tipoLevanta miento":2,"consultaMatriz":0,"referencias":{"porcentaje":0,"bloqueado":0,"editable":0,"guardado":0,"referencia":[{"idParentesco":0,"lugarNacimientoDes":"","idGenero":"","estadoCivil":"","telefonoCasa":"","apellidoPaterno":"","idNacionalidad":0,"parentescoDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":0,"nombre":"","nacionalidadDes":"","fechaNaciomiento":"","genero":"","email":"","apellidoMaterno":"","curp":"","idPersona":"","idEstadoCivil":0,"dni":"","celular":""},{"idParentesco":0,"lugarNacimientoDes":"","idGenero":"","estadoCivil":"","telefonoCasa":"","apellidoPaterno":"","idNacionalidad":0,"parentescoDes":"","apellidoCasada":"","rfc":"","idLugarNacimiento":0,"nombre":"","nacionalidadDes":"","fechaNaciomiento":"","genero":"","email":"","apellidoMaterno":"","curp":"","idPersona":"","idEstadoCivil":0,"dni":"","celular":""}]},"marca":0,"consultaBuro":0,"seguroDeVida":{"clavePromocion":"","opcionSeguro":0,"montoFinal":0,"abonoSeguro":0,"precioSeguro":0,"sobrePrecioSeguro":0,"montoInicial":0,"esDefault":0,"ultimoAbonoSeguro":0,"totalSeguro":0,"nombreSeguro":"","idSeguro":"","comisionVenta":0},"existeCita":0,"banderaOfertaCP":0,"idPlataforma":1,"preguntasInvestigacion":[{"idVecino":1,"idPregunta":"700 ","respuestaDes":"","preguntaDes":"¿Cual es el Nombre del Cliente?"},{"idVecino":1,"idPregunta":"713 ","respuestaDes":"","preguntaDes":"¿Es una persona de confianza?"}]}),
				seccion: "1",
				origenEdición: "0"
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.guardaSeccionOS(request).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							$rootScope.message("Exito", [jsonResponse.descripcion], "Aceptar");
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}
					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'guardaSeccionOS'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};
		
		$scope.guardaFirmasBiometricosOS = function() {
			var request = {
				idSolicitudOS: "20150902190539190539731091",
				cadena: "iVBORw0KGgoAAAANSUhEUgAAAiAAAADyCAYAAAB04H4RAAAG3ElEQVR42u3dwZacIBBAUf7/p802J5kegapCsO89ZzZJtzLZ8IKKrQEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD87/rrBwBAgAAAAgQAQIAAAAIEAECAAAD7B4gIAQAECAAgQAAASgJEhAAAAgQAECAAACUBIkIAAAECAAgQAAABAgCcGyBNhAAAq8LjU4CIEAAgPTh6fwAAloWHEAEAHo0PEQIATIfH3ed7wgUAYDo8egKkbRAhAggADouP0e+2D99fHSFXwu8FAGwYHiMBsipC3IsCAAeGxxU8Vrs5VlUMuBkWAA4NkIxj/ftnK88tQgDgoPjIPN5vf5Y9htHQ6Nm9FQA4ID5mAyRjLDOrHFZFAOAF8REJkMjqw+x7aAQIALwgPjID5Ar8LqOXXgQIABwcHxmrCrOxEgkNAQIAB8fHb6sPFZdhfvt9ZkJDfADAgfExMvFnB8jsOMQGABweHxkB0oKfs9oBAF8WH6sDZPS80XMAABvGx4oAyXii5U2XYK4f/l0A4KvioyJAsn7eFB/uZwFAgHRMjq3N34iaGSCnT9ZuqAVAfAxMkDsEyMnvevFEDwDi4+AAOWmyFh0AiI8DAmTmOD2/z67hAQBbBkjkGDsFyN2kHJ3Mdwg50QHA165+ZH6/NyIiAVIxqa+a+L2TBgDxcWCAZE3sV+f3nggPADgqQLImxhUB0vMOl5/+vg3Ew9M3qooOAKx+dE6MGQGUESCRlY2nA0R0ACA+OifHzBWYmQAZvTdjt0suogMA8TE4UWaNpQ1GSFaAZIVKVXgAgPhInhirAiT6npfMAJldlQEAAZLw3ZFVlKp4iMRKxmO5ogOArw6P1fExOvFm3pdRFRxZKykAYOWjOFye/mlt3YqI8ABAfCyOj52CY6exAcBXBkgkHrKip+oR2MoAiYYLAFgBKVz56Dlf1dboK9+YKzwAIDEmqvcI6V2hyIiQ2QDJWMEBAAEyOTFHz3MNHH/l/RYzT7MIDwAIRsHsykTm6kd1fMxcNpkdEwAwESDZW4qPfKbyHS2jQRH5PADQ5jfOyjjX7Jgilz2im4MJDwBIDpAVE2vlkye77icCANysSDw5wVZcXhEhALD56sfdJL5rfOyyXbsAAYDk1Y+dwqMiWlrLe2oGAEha/bgKz1/9KvvMWOmNOQCgc8LseSNs5HwZIZARMZGVFgCgcPUj63/3lTd4Vl2aAQAWrH5kvBRuRXxUrowAAAtXPypusnz6sVcBAgAbr37Mvphth+iwdwcAvCRARlZO3hIeAgQADgmQlU+ceJoFAL40PqojpBUHSOYjxQBAUoDsEh8ZAdI6/w4A2Hz1o+ISSOYTLLN7gAAAD4THlfT96KpEJD4iwQQAHBgfTwZISxw/ALAgPCLx0VruxmCRcWdcygEANo6P2c+NrmxkBUgLjhkASAqPmUgYOWfW+Cr39RAgABCIjbuJfWSyzVrNqIqP1nI3FhMhAJC8wvHb96KrHqsDZOQYAgQAHgqQ3kn26cdyK95wG/03BQASVxFGLtlUjyHyJE1r+TeRChAASJr8Z2NhZBzZQTLyrhYBAgAbBspMHFRHkbfVAoAASb134sl9PQCAzUJkxZMj2SsvAgQAXhIenz6TGR4zAXR3LgDgwPCIxkfFXh3iAgBeHB6ReysiT6uIDwD4svhoLbb6kRE04gMAviQ+RqIgGh5tIHQECAC8MDx6QiOyvXnveEYCRIQAwIvio7W8SyWjY7obowgBgBeGx2xoVO4JMvpWXgBg0/DovYE0Ego942ot5022AMDm4TF6T8bsHh5t8PtZW7ADAAeFx8pgECAA8PLouJKPJUAAQHgcFR5NRACA8MiMj9nzAAAHh0dl0FQFDgBwaHxUHHvmM8IDAF4eHVfx+UbG0zte8QEAwuPjeSNjEx4A8KLoWBUfV+JYhQcAHBwgq88fHXMTHgBwdoA8cX4AQIAIEADgmRC5Fp4XABAh292ECgAIkfTzAACUh4j4AACmQiTrXTAAAMMREt3LAwAgJUbsWgoAbBkjAADLYwQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABe4A82Reb6oIzHwQAAAABJRU5ErkJggg==",
				tipoCadena: "firmaBuroAval",
				porcentaje: "0",
				rechazoFirma: "0"
			}
			

			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.guardaFirmasBiometricosOS(request).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							$rootScope.message("Exito", [jsonResponse.descripcion], "Aceptar");
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}
					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'guardaFirmasBiometricosOS'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};
		
		$scope.buscarSolicitudOS = function() {
			var request = {
				idSolicitudOS: "2018042708445484454803910",
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.buscarSolicitudOS(request).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);




						
						if(jsonResponse.codigo == 2){
							$rootScope.message("Exito", [jsonResponse.descripcion], "Aceptar");
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}
					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'guardaFirmasBiometricosOS'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};
		
		$scope.agendarCitaOS = function() {
			var request = {
				idSolicitudOS: "20180327152726152726543581",
				idUsuario: "170070",
				fecha: "28/03/2018",
				periodo: "1",
				empleadoCita: "612647",
				idEmpleado: "309887",
				ip: "10.53.37.58"
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.agendarCitaOS(request).then(

				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							$rootScope.message("Exito", [jsonResponse.descripcion], "Aceptar");
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}

					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'guardaFirmasBiometricosOS'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};
		
		$scope.digitalizarImagenOS = function() {
			var request = {
				idSolicitud: "2018042709093990939747268",
				extensionIMG: "jpg",
				imagenB64: "/9j/4AAQSkZJRgABAQAASABIAAD/4QBYRXhpZgAATU0AKgAAAAgAAgESAAMAAAABAAEAAIdpAAQAAAABAAAAJgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAmaADAAQAAAABAAAA1QAAAAD/7QA4UGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAAA4QklNBCUAAAAAABDUHYzZjwCyBOmACZjs+EJ+/8AAEQgA1QCZAwERAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/bAEMAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/bAEMBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/dAAQAFP/aAAwDAQACEQMRAD8A/jf0fSLrVJhFaxjzGcIjqNq5bkKCFYqeoBj3E/Nu6jd9bJeyoQnS5adSnQpRqvl9so06j5XGKdTkjC0vZ8tWXu87VO8E1L56WEdRSlClzV4qVHmtCMaVKcFzKbtUUaTXPGMYyhz+0jzKLTcvqT4d/s067rk8FxdIUt5lUkSJ5SZOAVEmIwYzkjgZP3NpyFXxsXnaVGpGNOlNqouaMPfqUZQgqkeWPPU9+Lj70pT0jG6STcZfR5flbUpJ0aboU6UEqUV7WLi4qEcPJR9pKylUb5ov2d26XKn7h+h/wq/Zl0XRTZS6pbhXkOWWRl2vECqkP8rADAAKHcTtEgC8hvl5Z5z16tWFSnTtWadSMqk1z+xmqcUudxqK8lPRqPPywStDmPcw3DbdVyqznh3OTly8jqLlUeWKhGDVOhUqqUmlKcFJyjK75+WP6afDDwlpOl/ZLe1GTI0UEHoVZvkidmORGu0LghAwPU42p5dLGYnE4qlhm4YatGo5p2V4TppwqqNo3m6l7c6j7kYz5pK8nH3sRS+r0XVhKMsHRpOM4+ymo1I07UYqMm1GM6blGKdpqbjLlt78z8e/+CjviZdI/a1vtI0+8j1L+xvBOkaXLcRHY8E8hubq4tUdcKpVpAQY+R8oJK4NfqNDB08NQy9zi5OULqNTlqToubleD95tSr3TfM4vkvKMJSbPy+WOli6uNq0Y15Sq15Sn9ZpuKfsJfu5QU5Ri05RXs3U5Hdwkrpy5fy4+IHjXUtL1OK1g1Bv7SumiVZE/dz6fGsmFlWUbSZ8MQJGOW68/LUY1RgqaUnBU+dUqWsacOeHM2nJT9non70FzU1aK5YPkJUoyToxnFezs/rEXKMaVdwvaLSknKcIx51F8q92SpvmkeYXeqy38V5FeXcp0i0uvtaxOxc3Wo7Sjz5YbtzjiRx1IyVVSQ2dCtFqXPOpBKnenz1FVUuSSu2mqSbVl7KHLyq+7aizz4LlVHmh7OrLXRTfuN2i+ZKlTUqrSfM6MbqNoWUVGXMR3z3kkktsLLTIVKk3LjfeyqpGFjzvHBHGxExnqdp3FSu9YqnSTlTlryKLm6vuzm00mlKK+F8spJXu7s66tKnKm41H7SU5Kp7Km6lCk5KXLepFPVQvHWo46xel1Jx9J8FnQrfX7R/EzzXFos0JmuJ7izuLD5sNvlt33LcxFSPMiDKThlYLtNU8RGnRi4xrS5owj7NJL3IzSSnTVrWSfJJObs17zn70lTqTwlOWHtTlOdOcaScm6HvtQlC6lJuNrKM4tPnu27Jn3x8L/AIofsjaJq8OnfFf4M/DrxX4fIKw+JfBuueIfBvimAt/y1uI7YS2PmISTujXCvyGYAiu+nj6anRq1cOq9NS5JQqxnUlV0taT5lKL0s9NY68ja5jyqtWvLkjhZYijViuVpXrUZd1L2s7rSLi78qa6N/D+mfwj+CvwW8c6nZfEL9hb4/ePZPF9tb79Z+Ctz4m0yLxhpsJ+aa30++1V4bDxLYpCHby2hFy0fynLlhXdUxOVZlU5sLhMTkuLThClTp4qToVGvdVSjWdpU5zclelV53bRNLWXLWjioU743C1quHduSvQjTdNU4782GUrQe6d1yte8nL4Y9jrMfwJ+Klt4k8E+LvFuqf8LVsL9tL8VfBf4m+F4tB03WLyJD52teHtfsTImleJJMMILwO9nctCFktMkFd8JjaeGdTBZvgsVWx6pqnSlJc2Gq0ud2eJdo1E5XXJVhF8ru37jcZd1ClUlRp/V8LVr4ZJVaNfDYmNKrh5xipc0qVVczjNL2LpwUnq1HR3Py7+OP7Pmq+CtLvH8KXA8T/D22ln8zQ9duPtviPQGeVpDp8s21N8YGEjmURI4VWQrudanFUHQpYmdBwpRqTVWOHTjiXTi7Ri1KHLG2kpRVm/eTcFaJrCFBxX1zDRo4iryyhVpdXLRTmrqbhG8k17SlGW0bSXMfFEngO9S3bWfCUBvrESf8TLw+jtLfWzJl5SlvIuZVjHVAJW+UgHnNeHGWJ5IR5nSUItTpTtyJa2gmrOMqmkkrRlJarl5VE76yhRo04VU6cKLhWpV6lNuceaPK1Tipq0YqSfNeLj8Vle8vUfgx8ZPE3wU8WReJvh5qK6LeXkltHqmgNFusL1Yp0MyWkVwri0vJDvSaFoxGWYqhXKlvIzHD1MW4VI0HGrSVWNCrOrKnSqOMY86qU17t9L9I+85qF4tS7MtzF0ZxpUZVPZWcnKmnK75ZSlOErSUKcqkoy9naUlKF7qzlL9//AIIftm23xJtbGLSVOia9YWkkmqacztNayu2JJp9PEgMljtkBE8BzGpZ2H3nVPmq9arQquyvVc+WcISjqpRUKlL2cqcoUrqTb2puN2p2sjsWDw+Pr06tdV3UnLkjP9x7SbUefnnNXjyKUnKnNzjOMPdcpux7p48t/GGtfD7U/FXw51zRYdS05vPvont4b+a5sBGXv9OnkImfUEZSzI8oBtmOUDkFV+j4fzqvgswguepRp01H2UYv36deUpr93C3s6nOn7yitVezjFnmZngcJJcnJGLrJ0nWlCU1UkvZe/GnTtF1oc3NOspqEptOUHdOH8yP7SOnX0Pim4m8eeG7Kw1LXEl1HQfGOg2Q0xbkNPIZNM8QWkAFlqMkJG37faLbXCMYvOVh8tfqSxNTM3hMdLEclCs50XKopVpUK8OdNS5ZOVT2lud3vKEHb3PiPEp0I4R1acPaSlCEfaYepN+wxDpUEqeJoJSsqjnPmbcLJybV9FL48ee6ilkt5/NZ18tHBIYBcEKSG6BgQTyRtHyxjflvRn7CvTcZulGNL20oSqQfK23e9GLfw2c3DmpWc6vvSlytRcqU4SjJKGHlGEoU3F8sozrtKU6nLKFmuaUakJ0pU5Xjb3U5n+3bX4laPZfcfT3l3f3n//0P5jv2cPAy32pQy3ESzL5pZYZR5ZjVSr7yHynysQcgv8obG4HK8Wb5zGguXmg1U5U6ig6/uw5o3lOE5VOf2alThPksqrhJuEkz1MrwFWf7txg/aQlVqSjKNNKpTn7RcjqSnWjTnKcrzUk5Qjy3d1M/ZvwPo2lWWiW0aWkULhW3N5aSFyRuOSq5xgHb/t7Mk8FflK2Y+3t++VTlacY0Yyg6OrpQgr3jrp7RSjK0varXl5Y/a4PKqWGipzo/V6nNCXJDkknFqMXKMakVzU6iSklKEXGUm5c0o8x1VpDOLhZYIZFs4I1+dVIXDNnJYBSpzuVtxyFDrtJ5bzZRqQi1C0qjxE/cbk5znU92okm68ZpRSs4qF3GDXLeaj11KkaNSUkqPslJ0pr2TUuZRSnUUqtqU3SmlGys+WGnKlc98+MVrH+yx8FtK+NHxRnDW2u6e2q+FfDeixXNxqeo20kR+x6hd3VuUi0oNMV8oyCXc5xjafm/VMu8O8xllOB4hxNWNB1YuCnadSrShe2Iw+JhFNzajKFN1JVFKPxez5pSPyvNfEDAxzvG8OYCeMxU8PS/eSp8rjh5VKL5ZKUZKUlUXPzKfLyP7TacT+aWfxDf/H/AMf+M/iV4quJNNvdXvpnsXvpPu26yFLOxuC2N86RFUDALnDMw+UBvYo4XEutGjUrc9KE6Uo/WFTg42d6bUnaXJFWqRUeazUW2+ds+axDlTw9dq1X2041YJ025uo5ybShKLklCTjajJyco6uzjzS8I8efAvx4mpza3aWv9q2TAuZ7ORZm8uPG3j58jGMDeuN3KjOK78bl+KUqMlGM4UZNe7FtpVnOXM7QUI6tty5VpHmTmnJyzwuJhTp0Kc5RtKHtFKM3Ke8YOCn70Y1NnHnm5Jvl5ouSjHwTXbXU7Ly7G+sp7EwM/nRyRPH+839TlcOxyN5YhvlxgjazeHOlOM1has5xl79Zzqe9JttpTe0bRSfs1BJJSbk22ow6aMVzV5qs6soz+ONVTlL7Li21OUZJxk4/vFGz0jHeWXsuI1zEpESjHnfdXHHG/OCHxnGQF75Y4V06dWMKqjBVH7tR2Vukm3ByW1naKhryzv70bM1lFS1ajyu6SbtO1m3fVpq12lHnTd2kuWxsaJpmoazcGKzjS4ZWy7PlbZEPU+aSI8quORnO7gvjFbxq1WoNTVNQg3yVIclOpLeKnzwvdzu9+lrRk+YzqVqdCEHFqDdOUYctLmnOfNaPK4qVql/hu7NpJczlaPsdrofw08N3EM/j3xFeJ5sG+LR/CkYv71TjgTXE8ggtgWHHytweWUYLbTq1I8kpwppSklKl7SKcpy25XTg7XvflnK8ruyexxU62Irc/s6Ept86deVVU3ztaqNPlimpS+LVq94xUWuaP1R8CPFH7FZ8RaM+qeKPjD8L9ftpGng8Z2GujTRYairbre4Etha3DLyMMoKxnPzHB+XojisE7fWcBWtGdpSp1pQ391TjN8rjKL95KKp2tdc17GjoYuFKnVjUhGrTg5Vad5N1FtKlTl7y67qL0umrpc36m2nwu8KftK6W0Xw+/aH8LeNfi74ahbU/AXjzVJ9P0zxNrtgSDH4b124ikSPWZY5gxa7vYIbpA/Uhsr0SjgcU4xxWIqYehFyVGviMTKpOjKMWqfNN1Ipqd7RpybcLtpp/FzUJYrDyVeOXLD35/rOHdWMoezXNVdSg+aMlJrktQhKzbk+W7cZY/hnWpV1C4+D37Tnw81bQvGtvHLp7+ItOtZbESRbvIF3aXckT6X4k025z9olaMzTWyjK4YEsoUq+XYmjGGLWOweklUwSu2nvevU9mqdlFR5LWs73aa5uqNZ4le3w9RUXDljKk4RrVHFRn+7rx9rKpRi5pQbjKPue5KMoo/Or9oT4T6l8MvHctz4O1JP7PkLzaBdQhra01iJH3cbR5cN8g/d8sFlwApGWC9maLBYuk4e3UHUipxalKrOUqensq3JGPuc65nOTh2d7+7anWqUqft6Nm041ZOzqKhJJ3hH3ZKnFJJ0qXLeXvxvdKPkz6PpPxWkXypbTw749a1hM0LbrOx1y4hOJSCjJHa6srqN2F2zdWZWJLeTHEwlBYes+V0uZUqkuVzxEeVycq7m5qMI81oytGSWrTSaJjRlQjVjhKMJ4WEozq3cnOSVJTqKlOFT90rqPIpwp8rbSSWkuesdR+J/wAIPEYleXVrS4tXWaO7RZGgnjgfYsN0VZQLWUsE85cozHaQckN5mNyydanWmp0W6kIT9pQlFrnlZON1J1LxjtvCFmqk5XUT0sDicXD2Xs6nPSvGXK1eKtF3cZqEuVQ92Xs3PmlabSfKon6u/sw/tjRXt3Z6NrBL2GoLDaazbS+Xatp9xOoUlYGZN9sjBvkl3F0UshbIFfE5hTqYCvSvUrqUYzanD3FOMITjdrkcY0py932ntI3lO3LLlsfX4dVcZGftJUpU1T5XOmlHlUOWMoVpSSlGM2rONKSnNQakkm1HQ/bK+FOqaP4Qv9d8N+GPD/jj4d63fWni5bZ45tQbwtqJk8vU7zTIFla5tIrwN5lzY24ELKG3xHeWX9E4WzapiMO5wnF/uIzq4XnV6jpSg4TVOUEoy9lZOvBQniOS9m3ePxua5ZFVYQVSeHarQdOUakqNWFL2N6dpTfs+STtyxlryz5JJOclL8G/iOjWfjjWENlbaYglhmis7BporSK3lhSWIWav5lxFFIjI6hirqWI4ABX9KWPpYqVKapRU8RSpSTUY06PLaT9pGPuR59JRmn7SLspWbjeXmYeEXTlGm1zrE1IKVVRhVnThU5I1J8svZRcYpP2jnFw+F3s+X/bKz7f8AkSvxo+otL+f8D//R/Dr4V+CbvwvbWzjaJU2kzD5GA6bQ6/OmZAWYbmLKQhGCzV+S5zm1CrWlOLXs6HJGjKF4xlZwkubm5Y1KsITUva39x+6rRj736vTymFOqqmHrPlhJqWJjSpysqntFTcuSycKM+WE3TpQhGFSCtCLmj7d8KXE80ENu5RCSqEA/OVxk4JLHvx1HGwjjNeZDH8ytVdT3XNcut4S53zSTU1Cbn7urhCKlzS525QPblhq3JSjFwlTjNxqOEZUqkeWXOlSk53q1UlGXM0r80UrW937I+Ednpfh/VPD2vz+bH9n1AS3cN7Zrc6dcTqUFsPJk3/aVkQeXJHx94SEKAQ302U4hVo06kvdpqrRblJqHs403eMbOHJPnfvPmgockZQjN35jxc0wdacMReq5QdOpzOLlGtC0UqNbWf7m6vCpeahJTm5pSclL4J/4Kg+MfjZ4z+Kt5Df69DL4WubW2GjeErto7DS7XSLPBS2t9JSRAxjceZG+zCsyHauBX9DYPG4vFYGnKWY+66a9jQrXp0+ZU6bUtKbUXVvzSlTSjfmpt1PdZ/NTyjC4XGV61OhapKdepUq1Jx9pL2r5lTq14awhzLmhFKajzv2c5cz5vzGuJ/CTeGfsnijw5faDdzSwyNqFhEQi+UxVpdyE7i5XIbapAxyPnRuaFWdSclmOEi/YqUVVotyg6bvadNxdlo1KTqR5b6Jxupx9Cca7VKrRqxhBRTuqkoVqk5SU3TUJyXvPVym4vmU+VT0UYcvbQeKdBnkuvh/42tdcsGJlXSdVlFxmNmykfeQt0GW3oCfmQMuF3nSlV5KmX4uMkpR56TahJJKKqR9rKpZOUNHTUHGKTjqp8suSMZc6hVhScou9RqLqVMPTj7yk9XeTadSpH2tSDdpSjGfuQr6p438C6ufsPxc8FR6XfshI1CKLzIHbIAmLAIxzgkDCcnHy4zQ6rp+1WZ4RqC5uSrSVKbgoJpc8qcZS0e/O7y3bd0aQpThCVWnUSdpydRylTUpW+OCfNKdRuMqlpPm0Sja75fnH4i+B/Bt1P/aPhTxFFc2jMZFtPMQKsf3ljSPAUbMEbcggfxM3y1wVYYSvGH1Su1TUeaNCceWahCzn70eecE7xadpaW2sdOCxWJtL2sJudNPlnPk9+CfI22pOScXZ8021y6cqvI8Xm1+706N7CxYW9nCcBYAMzzjhGlkTlwpXJUjb/vdK8mVWanJU5U7Oque8bRqKCVoxX7uyTaj+7T1Tk5Ru+XujhKXuVajlUb5opTcVCSmr80YK3NG17SlyK90rpWOahs7/V7ksxkeWUks53SNknJLYDAYHABI9AFzurVwqV5J1JRpW1v7Kb9I8rva/8Adl2acbmz9nRg4xUKbpqyi1v5JJqnd235ndPzZptpltEFS5lvbeJX2u62E2A2Rlj0V+RgYbOPTOa7KUI2qKUpzTT53OnNxbhs4yc+ZKNrttRhorX+zMZVa1Obhao176V5cui1V9430fwxtqtX70u08LNeaJeJqnhHx1Fomo2k0V1Ev2i50qeeS3YSRBflW3kZWHMMjEuMjBBwyeHwM6alF0paODcpzad1uqaipTcmuVWu1LT3VJqJSxeIpe4qMvZzXK0qlOUqco63UZ2tJtW92Sk72Unds/U/4Iftg3nxA1VPBnx18VX2gavdRW7+CvEL5vPDd1rMaLbJbyef5s+hJdqB5q2csVpPN8zouazeOxTlGFWnbCSg4ctCFSnTjKneClWV2nUtFJuKUuVtP3mc9KlGMa8cNDnqutV9rGpanG8rubqVXJynzJOUY3kknandfD9G/E3QNF1HQL3QdY0z7Jf2cRusWRN3bXZdfOXVdBeZ3aORxtmW0jdkz5gAYENU4apTh7eNWnS5pxlzTpNxjV0ioQnO7cZwb1dPW+jalBMdByxOGdfDyVGpTSaSpwqQSjJ/u5O6bja0VzTlLeUYR+KX5keOfC+peF9WOqWN2plE8dzp81tLzcOB5rXxiP7qG5jYos1u65U/eyoYs8RCGPjyqGnLzOTjyc9J+77K/MqzjBLma50m1zRhJy5ImGn9XjKlFxlOo7TlJqMKF7y92nUc5uOqtGS5W0pRvCSR6X4X+Jtn8RdMj8KfEex0q/vrSJbayuLlpLKaaCVhvhe7sgWt5N7CUZkKEqMleajDtYKhiKc6cZxcIJKanPkSl7ypxtFuE4qKc1DmVrw5mpI3qU5Tgq1JW+GL5IQdNU4XVocs4xjBU0lON5XkldqMYqHNeKfhxqngiZNa8Natr1ss8jTSXD2qahoOm2Vs++1W+8RxFJXidVIWOSKWdMMSTlhWGKwKzDBVI4SkuVpqNKMrRpQaneada1pcyd4VOaF3TjGMuVyjrhMzhgsQozdGmqs4VleUlU517SLXJLSdWT3lSjs+SUKl3KH33+zf+0Jqniy1sPhz43Emu+EvEEE2h3l5p7C9OmtfJ9murrSJ5fLu0tru3YkKQFtp9rxsMPXxODxGK4frzlC04Uq9BRpR/eLmjZK9OnCUJNKST5uaK0eilGJ9TiMPSxmHrU3Qp1J16UXT55SleUaVvZ2np+7adRVdXSSs17vJH89/2sP2e7H4a+NL/SrfXJLGS0LXOh2fiaRludZ8P3crm2kh1SOLyjLbqQPJuHQlS20jawX90yXMMNmWE9rQqUXS5pQpVasX7Fzmpv6tJ838Omm+TdqcmuZe8z4nGN0cXUjDDq848leNFS9opydpYmUILmfNqp1VU99wTcYycVL/AGIvLPt/32tfl/vd19x9Bddn90j/0vz5sfBtikaSmMu77TIqKxife4O6Ir8pUts+XbtXBJKcFvwjENJys4U/d9r9u9GnB8tWNpu8JLnkoVnOU5zkkvdUj93wuElHldN+/JOE4tyftUnNu8qsHGMNXGV405RnCKla7geueEvC0U1zbPHGQI5lBIGzaCcxKcyIAQFJLZbbyD8qk06NOUadaMKaqe6qkoOpKtUstJc7hSdSSir6Je7e1m+SZ20I1KCqQjCU2lTqVJVOTlSatTqKUnN8+HpwkpuMYucpQjFRvyHvPiv4hSfBv4Wa94ys9N0vVp/DU6ajNHqU2YJLW3HmvbW8Z/dx3hRHSOQOzF+QGVRt+/4Ng8xlWp041I39jTc5YafsFU56nvqpFc9RVEoxjJtRtG89ZPm+A44xMKCpOrOjTpSjVlCNHEKpOfNRjGrTnqo+0iklFS0lOHO1CUWfzCftUftZ+Nfjh8XJ/iWdYkkhvvNfRrG385P7OsXIAtpY1YiORSpScYUExhsndtr9VvOnQpyUoRhSq1IKCUI0oQfNdKH7tTipXcIyjKV5NuKagz8Vw9JOnXo4hynUVScakozlF+yqNVI+0nTlTvKb55aRjySc1GMoRUjz+w+OPi+0062XVFg1eze2l/0W4QLIy+YGYebsZjxxhuo5JxjbvhMYqbg+Sm41OdJ1bzlK8LuPNTi405bz50pckla3NaRlicHTbnSg5+4+RxpRqXjFqb55S154p+/K8pcunwtpR43xT8QbC6kttU0WKfSJ3AbzLGXy8yAljHIEI3BDheRtHfO3FXKvTU1pOjF1JS15nyJW9xOCXxNp+81Pkik5S5vdMPTqxXuaznOPtHKom7tSirycYqK5bXaUbQdveslLzHXPiH4g123MOp3T3W3IWSUIHKdssqLkdPk7j7+Sc1M8bXqRfNV9p7WTalKL9+kkowvDRT05rylFyUrfZfIehDBttunNJ35udKKTktHdqCU272Tfwq1pStzS4pbqVUcxySDfw+1nUDd1JUdTz1wP9rAOF8ylKoruk1714q9SCi9VHS8XaKV00tVtC9nKVOMFbmu5Qi7tT55tSd+t0l1lC6d9Vs0dDZTaZHZCW7YSNF/q42Q75mIzyeBtVuWycleBjiuymoKmqdWNOrG948rpeyjV5pWi4+z9rDaXMlOTUld8unNnVdVuMYJNzXLtD2fsue6lzpKcKkW78qupWabfuqNS51y+nOLSZbCDr5dqv2deOOdg8yRsYwSeM8Zz8uLquN6alOnCC+Cnq22+kpX91O9/eUXq21ZRkoYeNkpxlUs+aznO/N9p8ruoxba5eZaJXd5X5oY/EF/bgj+0b6VstlZ3MkDbsZ/dybtxOMcjI4Jxn5d44rla5fa3jouWVoeT5eRKzta/Nbpyq65dZYalUkualFNR5oOM6inFSdpOMoJK3SV5eSSvctw6zaXKrBqNhbyozljeWsP2e8VSACMITFIo65I3cY+XI2tYmLc+VUailGKcORU5Qbl7ripWiptvVxcVqmkveUsvYSp39hJRdoNRqPmSjH4oq7W6bbbjO7V3a3LLaM0MZhhN9cT2J+e0mOH8ojO3yi21oZUxhgWVgRlSy4LdVNqFJxm4zhKTUJTUtNPepOUbRjUvaNqjcbO0ZKTUjSoqlOEVBQTqNyjGMFFVVT0TqKnJXbjJtc0Y8js3J3gz9fP2MfjW/wAaPDFx8A/G2r2tv4y8M6dPe/DfxVfmOO8vbS0AZNMuJ2jea8lhbCpE5laW3LkEbK+erVamDrwjJ1KmHxL5qcGpeyoVnrNQm2o2m3eLlzJNKKUm0W1SqU44imqcasXS+tUlOWq5rT9xc0m7cqacZK/W0o83m3xu8O6ho/iG2vbm0tbcTyywXsSOp0tNQgfy7l4G3HyIr5gJFYMkfz7G2jAr2Y1I06UVNKM3b6wlzpxlFczlVceZx1ja7t7t01aUXFy9h7StDD82HqxcfZwfPGV5xakoKo5xguepFOPPyyUZeyTbkj5e8YeHJorq61LSo5oNgSX7DAXSe1lxuL4Xcs8RI3AoSm1skfMtd2H5MTF1cOrv2N5QjyzjNN8qTlpOzV9NHTn1aVzLBt0Jym6qoXiqFOb5akavtVKMo8rjzNys3zOV0uZtSUYyj3Xw8+LtpqNhd/Dn4jWNvrWh6pbs+lRX17d2UEOoQwSLDJK1m6TRtE7kJCw2MzM7I/zbPEpyngY1GpxUatVc0Jzfspw5n7PnjL943zSlKpZy5+Sy5Y2lLpo0aNetJpUJOLqNy9lzTu3aLhQnBVHOEvfglKMlK7Wjsco3iNfhV4usZfDMuveDL2Lyrm3sNVUS2k4Em+JtC1cKF1GynHK2moRIUxkTF121wYvAUsXKdSlTq04qM5Va6qqUZVnTlzzpStfDy5uWMYWcFB2cYc0JT7aWZVKNWFNSU6cFRi6ztGpSmryXtIxqtxnUhalLm9yPv1HeN5H6la740+H/AO1n+z/pXiTxT4K0jxR4w8K3GneGddvrO1vI/E8Uc6+UN+k2ayXtkbacxTtqllHcWLxt+9CIdyrhLHZrgcS8prV3LLcL/tFaDelRSqTTcHFtz92S5fZ+/RvHlu5XlvnOHoSpVMTTShicS6i5qTg1P2FGN+ab0tTqqE17WoorRxjyTmo/6kP2WL+43/fDUc8e/wCBhaXaX/gz/wC5n//T+ddO8HanA6peW4UoV3sBujYO/wApR3m2jJXcx+XKfUCvwvGQcHTfLiKMJJqNLWUeWnTXM6tKNOUuaHPanfar7L39JRj/AEBRr0pUoOf7ypK0JKcqcVzVKkpuytH3PaL2vuXhyydNP3uSXvfwok8CeHfiB4MvfiNbS3HgWDW7CTxdb2kZuXutFty8kkIt4t07I83kvclcOYWdQxwRW+WVVh8zyuriqMY4eWKi61GppGUHNOpRSlzJyUIrDqcouMJSu1Ll5I+Ln1POquT5rLLacKWKp0KscNQlVnTjOryNRVRqMqMISa9rbla5uVTei5vy5/4LEftWweJPjoth8EEsfDvwp0Pw5b6bfeB9Oh+zaNqupdWuDC37yS5jhdCTIGO/IHzCv6uzXH5LjsvyuXD9HBYOMIujioUaNOKrJpezUpUIUWnBL2dO0HyUopytFyjH+UshyzOqWGx3+sFXE4qVTGcmGVWol9XXLzcygpSUknL2c+em1Nt815T5Y/z86/cadeTJqOl2SWC3UrvPAXIa2umB3xrGchYWZ38s7ePlAzjDeE8Sp03CNpOS96XI6sYfvJPnjFJRekeWfLZe8rtSjBH0GHUoNUFUqP2MKdSFWVp/vXNcsW3JzSi291ZJ25W781m2geXTTG9wVQsNspYnlh9xBliEYDA+UqBwCScrx4WrVjOzpwlTjUsrqzjJNXlKPLFfbcfj5k3ZwStza4jESjH2bSnKajOpJz5qitOWqs+RXimnNW5W+aS1tLnb22KwFVDGP5iF+cElclnBwigHHPO7nODkldKk6U6lSCUI1Iu7UpXptNJRcVdty1aVuWPvcvKp6HZB06keaonGooyceaUZuc+jvKSfK1JOLUJJKSiuW/Mc3c25WGFwpKsrA5OAWB6/L1PIJBHoecmtnDnpqpF7O84xtOUUlFNLnhzNJXcvfbtfdCalGUopON4tOMJqSs1GU1NR5ErX1+Pld+bV2HQWMzxM6qTtxuOGIABPPOR+Zydp3ZwK5VOnVbjFJcsfdlL3E5N8zUI2inZ2tZQvzPZP3mmnJRqx5FbmcpNK+qTkl7kpaJNLu3y8y94lfS5JmAhG+OIqsuGJ5b73DHJII2n7oAOM9CtqTnJctLklCMpU48sowd1aUtE0tWnze7fVKN1eOVXnS56knCXvOErSSVrpK61ceVNqMlGaejS+KTNTs3tUiUwyoWJJaRSqgcABAMBgBySCR67etKy5GlzxqLllJJaLrZOSqLXvLe90m2FCaknJSlKej505Tut2re9yWTTvK8t1tZkFlBZE4ljnuZWPCR5jUf7RPzZ+gOSPTmtKdPmSbp6Lf4EtdUpyTvK71duaL25dUjVzqQvaHLaOspR+GMpa2cby2+y0901a1jXj0lbyPFrpt8rKxAdUeQtjHdVDYz0OCDnDdRXbT5HKUo4eLa1lzU2o8z25U7fy6wjy2eqas1KHUXM4upz3VuVuHvy2fJPljzv4bRuv+3VZSpz2l7YZikEixsMmORZEIccFWRgNr9t2MdMhflVcalXE0XUp+x933V7zovVxv/NJ63+FcrVteaV3G1Xo35LKfI3zx/huym1dWdpbq2sbej5TqfAfijxJ4R8SeHfFHhiW4ttZ8O6pa6npd5bq/nwXFtMs32eV1XEkMoXymVvvIxBC7trY4qMK+HcG6ilZPmi+aFCaWjm7y5eZ2cr7LRN2TjUa0aE1OMeWTm1aM1L2lPl5XTl8NpOK5pfDpezbs4/sh8UL/R/i38NNF+Nvh9YjpfiPTEPjjwVcQbW0XxXp8ax6pf6b9ni2LY3Lh1likZZUf97WOGq81KMZzoQnBf7Q6MpODvUbhC9VTdabp250vclzctoJe7OKnUnOCgqlZVdMPVuuWFF3jaTbqXs7NOSWkYrmbfv/AALqWt6lod1LHDcm40268o6VcTANHZZKlbaeQ7JHtXU+U6M+5cbgcqErro4qNOmqzXvRpcv7mSqVoqcpyvKEXKMUv+XkItqTl8XLFcy9tOopRlNe2lyKry04VE4zj7nNJ01Bui9JU007QvzJe8eT+N7S41OZdZsrQxTK+2Wxt3k8yGdTzPpcygiSLdhzFIc9gwKhlmM6eNoxqSjDl5rSlL2cYzbSa9m1bllNq0uZJt2XvKUnLBe19pOpzzu5OMJuMYNVFFSkpNJxcIu0YzXLNe9vJSZ9g/AD4pfD/wCL2h2XwE+N2k+G7idI7mPwR448QM9sdI1CVN0VtqN7aqs/2YlFRxI7iD70cTsNleVhMTVynEKnKNZ5diZclfCxjKSnOUXCnOb19jyVlJ00owbvFuUUlKfXVw8KlFYmhdYxK1TldTlnCm3HEOFO8pc0qcb05Rg5Tf72N3Jc3vHwO1Sx+AfjTUNASx0iSXxDd3fh+PWvh14gufEmjtpqxsv2iO8n33EImkKxyLtEsZG3IwDXHm3tcPTWYYde0nCvOWHdKpGEqTrSi1GUW2pT5YrdytyylUatPm9XAzdajyS9rKirSlTxdNQn7V6VPckn7bmpqEmlGDe9n7yl/rP+YP7x/wDHqXNLtL7/AP7oL3ez+8//1PLdL8RTX0So8rSDK7fMYEgZYhmYKgcyMu3Dbt0YBOC1fz5TqYv92uek1yNVEoJuHJyRnyW9o4/Vozc7up/Gd01yWP3qVKgpRlGCiqaTjJTlBqVm+aUOTl5qrThPlk7JRUWo86OiutKbVrfyUjKsEZMCN2Ul+QhOMDftJOduxFw3LAVU6jao1asp1IU6kaqbqWdGKUueqpKEGpPnclBybnXbas4XOKcpxeISjiJwqwpu9Vyvy1I3pQlUjUUnLROTT5407Jp8qmfgT/wUU8Dp4M+Ium6hY2pC67pchvNOaSOd4biB38268oNuyVVTlQGPGMYNfu/Bk69TKIyqzlKtSVeKsnyO6pKMuSHvJKL5XGWvLFrlXLyn4nxg6FLOVQw6pUabi6kmqU70oz95qVSM5TfPJObk6kYJRS9+LSl+Ws0bWtwLiURmBlaaNEclpScqqFWHymPAyP8AZBO3Kq30FWXO7K8ISahVl7N8tmr81P424ylq/hglaKtJTnLwpxl8UlThJ8l5OTfNBStdyXuQ9qoxp3SbacW0+XmJ7CfU71ytuN8LY3RYVgqEdSuMZ42dD2x3C4wpQhVozjUTlCcqjhJ2XMpXaScpSa5Y81oKLj717Jxibww1+WopVFJLlk4yinaa5kqkoaygnFRvOKfNOzXwuXqth4B1bxFDbNpul3U9xM8cXlpGVPmv8oRFxzgkH+HC84B+VefEY1QqypVUlR96UakltFO6vHlpxcbJU7Sk27xb5leUqoZZWxF5StJOUWtLVIxU2rLmjClGLhp7/tfsqME5XOk1f9mv4lWNu/2jwrqyIcTB0sZZY2yOgkjV1xjacHHfOMmrpZnh6tFqk4pxqXfLKk4wtbkSs4KC1s5U1NLVXm/h2eBxMIKcKbcF9lw57x95x9pKEVC0lFbOaSktYyXKQ+Evgj4p1F59PbR7u3mjbMgngaFmz0H7yONSoBBON2MHochoWOw86ilzRg07wlFyUbxaXNBwlKSindK3NfaV/hOr6nWhTnWlhm5QSnJLkpqKuuW0vfnyq/WMddOXmaZ3ugfs7aydcktdSgkgjTCTssUjwPGWVkYyIq7WGGAAGcdGGQraV8TZTjCdXn5U1Vg4OK5k3KNSKq3lFrls2uZbKMmvd4quFlOc62L5qlK2kr35ZcycX9lzUW0+WSvKLas0onL/ABr+F9zZ6mP7M0y/NpZxxRS3UsTiBmROFgj8vzH34Dbxyc4brW1LGUoRp4XSpUhS5qkak3F04v3vaXb5La8qi3G1nbqjCnh1CEq3NVnRd1KXvU1Tt9qU6jTpxk/djDlaV7uV0fM1zHLprY+ypHcR5XEkbAAjkMsecg5HJcdQeuTt7Hi2o2UKi1glDnbgoLe65Uk0tU2paW2syVTTi3ONV80k4yjL3IJO0fe5k7db+zu902lc9A8C3NxqkxW88TvoMu8JFIFhhQAAAFcpuZskD7zcdQuct2Ua9NqUWuVK9o8ylKU90lzysklduyu+a6crOMeetRqUYR/cc0OdpuVSfxVE1yS5ZwtzaO79o5Xs1K0T6I0zwhZzxs+v2t34vsiAJNRSS2JUY5kBMe/IOeAcDOd5BFa0535k1DEVJty5FOClCVklzRp+zkou17Ny2vZXvHjlyKdpSWGjTXOoQqLScYt3dO7m095LaKs2pq6L2j+DvC+iarJc+ErvT2jlcPc6LrG0SxfxPHDITgknhWCOP4e2FUMPSnKUqdR0ari1OnWv7FaNOU0nFcnL7vdJXUk22ZVfe5HJyrKMVKrr+8VOd23ywUnOStzRvC/Ja6Tk5R+0Pgj8QvhkYtb+HHiq1g0Ca+s7zVbZInV7C7lMHk6igwGH7yAeZ5ZTIdSfl53ebiKdOOKjDEWpOvWotTpxi7ypckk5e/GKVRdJKXPFp3lJNS6KVKrJqpQXNJ+4l7OpGKpT5Gotbq0le6lybx7qXx58V/Bfh3wn4m1Lw3YavFqelXRN/wCG5JXSZJbS+lMotZJIwMGNWzDuJ8iRdpypKrnU5MPenFzq4ao/axUb0Xzzi6fPB8zXLbm92Lg+VRdm7no0rYiVRSw1OVWlNqpUhVvCfJG6km/ZxUk1KbcZ1XOM3FXv7vhc8s2mzvGBJcMqxzIhZfKmVWxJGD/DIMYDAZOcjaDippQhKnFRTo8knVjTjBtxlRvDlu3bmkudrn5ISaVoxSSikoxjKMpxVGMZ6ThCVJSqN8rjdTdpcrUeRKcHNSdrcs+a1LRor66k17QvOtTbul1MBD5P2a7jcttk+bKn5d2QoDBd+ADUV4wq3dHmlKVKlCUITUoy01SnveEoqPN70uaXJryty0p1auG9lPkjUqfFd8ism4KpOSpS57Q5k5R5PbLRycea8vr74b6zP4y8O3Xijwpo9pqfjHwuiXOv+GYmuY45TaKh/wCEl0i2t7iJo5ZSii9iClFfLoq7w6+DWnSw9BKvbnk26ceScvrKldQVaNROUp35aVOE1y+660nZT5vewVV16VP2jShKrJQlJqE6UXCUpUZKens05uVOVpuEZXVSLjM/2EPOn/54/o1dV3/K/wDyX/5YZWh/M/6/7hn/1fnfQrqSNVWLCiIgyNkszlmKsRxnJZccsG2qMqA21v5ubp3oNz84znKSU6ip8nNVgopVHGEp1ZqCdOdS/WKR/QdWl76Xu1at5wkuWlGMfa1OWUqb9xVVKs+bn5JJU7Tgnf3fe/h55vifxLofh0+aZdZvY7CGW3t3mnBmYL5qxBiz7mAbrvVMkA4r08rwVGvi1ha2IoxVWrShBQdV0IVuVcvtIqKjO1GSajFxTqS5XytyUeHMqlOll0sXVmoxwidSdOFKEXfmXtIuTacrKMalOCU5wpxk9G5QPwc/4Kua1bSfH6/0DTbmOceDYDpZ1WGVJHvJA5Elw62+6MBJVMEySIpXpIoy1f0nlmW4bKKTyujDmwtCEJQryp+yqQ1V1y83N7jjC8uaThKbS5moxj/N+JxmIzPH47MsbToU1XlKFBwfP7Sk6ji1UcYvlc4rSPs43jV9kpvlkz8gNVmadpd8WwQ/KgJDfO+GYhgQCHLbgAPlUhcEDFFOpavFyXK5qpL2seb2UvaOV5OLs1K0VGzV3JObWsXGaEadNcyhJRlFxm3H3k42hbl5+bm00jz35otzlJOUI+2/AX4bat498S29lZwORJs3CPqfm4O1eTkcnjb1Y5zXzOb5tTy2KbcpSm5P2ybUfejf7fLHTn5bRndWdrOMoS+nynLJ5lXUW/3bXfmoxleooOpT5FG2kvfjfmTcZxs2z+m/9kL/AIJzf29a6Ze6zYi4ikigke3jjJl3k/ISWCDzAMS/Kqhd2O5r8zzvjiVGcaLrRUZy/eSUNPaKN+epOMaijTnU9zlc1KUYuXutpR/T8LwxHC2k6cI1XKMYc0bUeaurOFJVGnNcsZycpxjCMG6i5otM/aLQv+CfGgTaWltHpUaxouxYjBE0jYXb+9jlDCZwAuXUlUHpmvlP7bzGdSrVeLoRg1RnGKTcLwinKMbS9285SUKV+flSlJtqUY9NXLcDFRhFKjdx/cNxipWblaMk3GUZU7Rc2+VczV4293z7Xv8Agl7pGpfaWj8NacrOzkXENqqyIDyw2rtCnbwZI+TgAYwRX0mAzXMpSgrxrQi5yvDng7xjyKcG4uH8STbjJX3u2kubgxWGwkaVWfsZVVOm2qUOWV5yUnF3ilTnBRsorlcnFa3uuXgL7/gnBa6ZZpY3mgokygC0uYLZf9Liz/qrw4AEsYVdrqDJtbDchq9f+06kI2Ua9NvmlzOVRRSglH90pNNRk5S5L+41G91eB8xSwsVUc5OrFygudSpTnCk5uUn7Km+XlceS1SUVOzaatzXj8o/Gf/gnBpOr6LqFi2j6tYassMv2W507TZrqAPtOHlkSMrnJGcjgYAzjDe9gMzqKHt5KpKb5/dcpQ5kpRin72tlFP7ChHrvFy87HZbOtW56PtZqbgrKmrq1nKL6VFtJt8zvZLmSsfjB8Rv8AglR8QNGa71iNtQ1C33y7PP0O4jKgbmw0qeY4D4IEjxLtx1XmvZlnnt1KEFUhO9251FUjeMrJT5eZyUbXty26PmasdFfIFyrmlRc3yRlzVHCs1Kz5lSdlF9VL3L2tG9z5luv2HvGVnG01l4furq6gjcXNrdsYZYXB3edamRYlnUAAIfmyCcg4VaKebVKiSnByqRqK/PGm4tp2a+J8qcXd8sI8t7crvLmzjksK0edRqQUJO023Sl7kLylKE4qFk0pKc1um482vN4vrHgjxx4IuJ4RdXMM1sHDWRlkhEYQYw9m0aLIQN2SgLP3yAa9vLcxtUhCNSnTVVpRUqvPeEqj5VKMnJpNxj7zjZaOzTUo+PmOQYWV8RHlnzNv2sqcpOSmoxkknBc6erXv7aObufNnjHU/EElx9va9cNHKVLwM0M6MOu7ZINuMDAJx2Yjnb7FSbry5rQU1B+4k4QbvpKKgua121zQTTacteZnzdLB0aTqQhh3KndwinTk17146ct5RbV0ruz0ag3Fc2D4c8ca3o+v6brovrme6sbhRukld90ErbZlLNJlxJHuUgn1JDAHbzVYKtFU5e0qSptzpqalLlkopWek3pKMeVrk005nzcse6hKNJyjGg/fUYwcfhlzKz5mouzbTXNy80W3JJczPojxpeJ4nt9LgVwZJdPa/0K93gsjLukk0x36s0TDKHjbnaQORWFBqN1KrOdOalFczklTnzqKs7OKu3JJR5YvmVrtxcStRo+2VSldTi4SrwTUlLmVpTTk4u0YN8ns5RlNWlKKgrnAQaml7pDFcz3dlKn261YMbpcLtdYU3o5UqpAP38tjAyHrqUalOSjOfNGFRKEKnJKL97mXNKSkpOLU5ws/Z+7KXuzcIyTp0G2pzdaGso1JKjTcZTtyxVN81ScKajKN1PSU03aU+YprqZs5F1vSzJLb4jk1G2G598RbZ+8haTieON2DJhk2MHG0Z2lWlCXLDmbneSp05rkqzUFF8y5YJ6OLUKjjLlcZJ390ilNQjKilKXtWl78EowV1Ti6dSSam6qgrSacU2+dQlLlj6f4O8QzfDvxNpXjjwrf3kOia+RaX1xaTp5mnTSyYa0volC7reV/laORcOnRgQC3kZzgaWKw84ygo1qEIxqyhGVOpCSs6dSn8Skoxbk7Ptzyadz1cK1h4UvaQ+zVjefsoynOClSclK8aMHKnPmjGS5rdo2Uv9oL7U3940BZfzf8ApJ//1vlewnAG1fnfIDGMJsLDO4jEgGCCNoUhTjaM7K/nSCrTtCHLy0YWjCKnFSVONOaeq1alGpKpzJzp83K7qTcf6GrSlUXLzQmpwi0qdWDhVjGEueUJRVnCvGyhJc6tGT9pdycvT/CHiHxB4Y1zSvFOmTXFjd6Hcx6ja3Fo6LKs1qGbaiuSRE4Hlv8AKzAlmBUYFb5dhKuHzLDYqm7ez9m4xmnKlOPtoSpKfvRhObqQcpTfNNxXLyNxUjycyp08VgMZQs6SdCpTcuaE7P2E4T5Ju840+WXs3UUZL3nJLmc2fzj/ALV/ibxJ47+N/wAQvEet6eLa81TVb1nMKbYrmP7RJIsskIJWOR3YPMF2by24KwYFv6mpOtiacMXiacIvEKTUoNcsua0rqXLFTV24xblFpqytZqP84YWVKnVngVUcqdKbjKUqkJyapxShq05uNGUUlOyvBt8tnCR8cyac8uo/2e8X72eSPyk2E7C77GQkYO3CnYcjIYnkV5OIfs6zbm5wtKabqON3Tjamoy5rXSkna94yTi725p+lg1TxGITXPGrCUnH3pQ5mnCLbpw5pydk3GUanNKUZVJXcm4/01f8ABLL9hS/1uy0/xte2iLbsiTXfnRCSMqdrARMVWR28oj7+35/4zjFfzZ4hcXVsXinluWKu5RjyUql6SoRjTjaTc05NRlUs0oXlZe5FJ8x+48J5RHCU5V5Tp81eNNx9p78sQ6iqQlCnzKKsk5N8+kXK+mkj+s/4OfDfT/BOnwR2dpbx7kQHbGiyMB8uNyjaq7Ru5YZxg4yTXwOFrYiNOEal1KNOPO1UclOphkqlaXK7S5pVG4yb1UFaysox+jzGNGqp0qEZ1PZyfJQ57ypRqOFOjTlOVoSUKcW0qfM772i2z690hYpVXylVMLlt4G4KfkKlcnAXG3aGAPcspJr18NOUVCPMlUavGM4ylBNx+sVJQnpafNKT9opJv3km2nCXzsqTdSaajVhO8lTnKHtKaklSpWbk2owcJe5FRvdST0aO5sLJH/dohDHMpwq7vLOAi9SN20kEZyoGThlFfXYWvJ4eknNU5OFHndFuXNdOc/Zr3bwlJJx5Y3m/iSSal8vi4ujVqyVLFUVGVZQjGfNTmnD2afKpN3krrSK5UrrTQs6n4V0+/WNJIomU5OWiVsOFwuM8gFjw3O5/rhfpMIqVSjRg6tV1nTpxmp/F71XnvJaq90nUlH3le1orU87nnD3fb4iKXOlF0p3kqdJJNWvBxtpTcnepO7SWpylz8MNGaeQzWtuSyNmMQgbiVOWY/MxA4BGBknPy7c16FJzowjCDxFSDUYSTnJpuVVtw+BQi29pNJtWS5rM5asalX3nLEzjdvlSVOKtC0JRu1JdYyjHWbTd1ZHhnjX4B+Gr8uy6Ta+aGZt+wSZDKQyMh3IwI6ZVsYA4yFqqM/YSbkqNFOEnGMVOc/wCJZ2UbN7vm1i5XbSSXLKaWMlRi1VjSoJSWtXmqynaHuxqJ3lGWjcLOdraWuz4J+Lf7Efw+8YwXX9o6Gu4rI4u7JTYXNpKUcpJA9uib2zkeWymMjkKMmtKtdrD1a1NRhKk20q02qkoQqauCT5VC809IyqS6297m9+hi6NeNOpUl7Pl5IKrUqct1ySXvUHz89ltzKySfxNWPw9/af/4J66lZQ37aRqEev2EUryW1vrVjE2oQbB8sSahEPtATK/x7znK/KCAvl0+KMPgqnt50lSlayq05VJTs7uXJTk+WMvetHmjFWSb2Z6tLIq+PdWpH2KlJU4QprT2l4puUKaUZTimk+e3uO7UVytS/ne/aX/Z88QeBGu3k0S4g8vzWndYQ0C/PziaNWA4H8Srkc5Xnd93kPFGAxMov6zKo5NciqOUakJcnxKXs4qS5Z+8k5e8re/ds+Vz3hbH4aHtpUW/cU5+z55y5lb3nFLT2NrS1a5btRdkfn1MZYy9s+8RoWbyCzFFcEZfaNgLseM7MkDk87a+1hFTjKtTlFOU+VPX4bOVryi0oRg3ovgUktfekfC0kvbcrirqUkrpqL5Hqk5RUp2VkoOTXvq/K1KZ6Rp+pXEuj2MEJkae3LXFk2WysgwTGp3EgsyMCmQWVtoTk0csW4PljBc01KSUZJNLTl0SUGmuS+qmpNyT1jpUpTo1Kbi0rRg5xhBucYy0V42nBuzle3NJO7dRWUY6d1qbSXFp4o0qARXsX7vWLSMbUlEaqHd4syCN8hy5JJkJBAGSayjVlzKPuStyxTVN2tGMvgeje8Ywtytcsm9ItywcN4SppQm6jhL3U4QUFzW5Z1bx9psoqnL4kpOKcT3fwJ4Z+HfiKMaoviCPTptR2C5sZVRISdq+bCVZVQSodwyxyxYkI275uul7FRk5SqJqLU+SN26slHX4k4Rm3GdP2acYppycZxkYurWpqVKkozdv3tSTUmqda7UtocjjKz5Yy5XJKaTtY9hsvB/wh8PmPQ9ela40zViJbO8sZfKjjlUHiRcMFmiJ3x7lOGDBdu4JXLXw0bxnOHN71OV4tKVST+OEpuUU5zakkrNzlJNx92PNWHq4iM/ZupNPnfstF7ODlaKUaU4fvLz7SlB2spLRx/wBgby7f1/Vq873ez+89i77L7on/1/g298QIgMloWjJ+ViuGK4dhFukIXaFHOMdduQPmFfzm8TUjGpyVUoe1nGpWjGcKkrR5qqjTUoKdSbinde7OnGXLOdoo/f4+7OUIwcU6lPlc+WTjyrlUOd8lT3JSaStGM3oublMCL4jataRapcQymeGy0TUb1LeeaWN7t4LR9ltbvH5ipcNOPMQFSZAAmGIYL6OV4uUcdg4YqdNxliqc3K7pQaj/ABIcsqfLHljemnJxg/empTV3Hzs7jJ4DGVqEas2sNJezjFc1mnFX+KpGXPzNxg9/i5lyn4G/ED4i6t4y1jVL7ZfQz3WpXkdw7ruMEiySeZCS4BBVcKu08KBu3YAb+laGIlKjpepRlNypQh8MOeUm2uR8q5m7+9Ho+WUb+9/N8qKpYh1JxjTrVVyyUYzeIk9/ay5akYJNpwjKUFaKbe8ZRsfBrQm8T+O/D+jyP5kmp6lbrG0rrs/dv92aRypAHzIWXOWGOMAV83nNVfUsVWnSnH2VKaS9nUjVUantOX3YxlFRk1zXcYOEZWlFXbh9ZkGDp18ywynFSowXPJc79nypyik7RVm3yx5udJzcGoSUZSP9C39g74faL4K+EfhXTrezQNJpkMl08ZIMtwYFUksF2rGAM7fmBABHT5v5Gr1Xis0rYio4N0604tJ3VWlTjKpaNKSTUrufLVk7t3bS05f6Ew040sNCnSjzwp0oONKKhGdCpVThKTnLmc+RSUpKN1G8mr2Sj+lUGnILSEWx2mM7kKhRhUKgFVGAc4JJJb5umzIauidOKp3ftXecITVOTcXUqJ1aznzJyqSi5xjK3LHq4yWh5kq9J1Kk5fvG3UlTlSfvysvZUoKn7RRS5r+9orxspSvc7vQLa4VcEMzu3zZDfKAnLf7UmcbRkD5cccGunB0J1ZU6cozm/Zp+0XL7SMZ1Pc57Q+HkjKKUYt+8tVaTOLGVXFycqcZqk4RlON4WjTi2uWPJzOTnrzW5JWuuWzjL1XS0ZIgdjSeWF3nBRyOpUE9cNy/XgbfmxlvqMNRWH0prFKEXUUJxUJPmS5E5LV8zStHVqPK5aXio/J46cG1KnVqR5oUX7q54RU6vPayaTSkpOXVaptRsdACH2hQQY9hIABfG9WyozggchEOeee2xfYhi6tFw+Jzqezp3fVK7aS1aS156qcOeXazUuSpFzlK1aSk+dxktX7yd1az5bx+COiTbSeiL5jEzFwdyhsN03HC4wAemOmAVBJJ7Cuv65Ob5f3r5YUXFXnTpuHPrFu/vXsmpLmk9LuNnz8sadWmpSc61RKU+RNQjy+7a65tU/JSbt73KtFLIv7O3kO0IdxYDIRsgehAzx1B3PhR6A16tKtTqWhTlTpKMJSlCPK6jk5rRTauqttIqFuddHb3eSd5OPtJwpNqPLJQ9rVk/tJ3g1ydpbR1cb6OXnniLwxbXcXyW4DdC79wuc524yvOMk5+YgY5rWcqMKkqVWMU5qf8ANKpUjKMJ305/Z1bRunycuqb6MunyYLlafx8q9pWkqkmlUtenRtGL0lpdS21Tuz5Z+IXwe0LWo7o3FhmV42AZlQo4zycMGwvc8fTO07fjsbhYzbp0sMuarWTcElKp+8jfmnV5Ipz2Sil3vdv3vawuLnQ5YxrODTkoxhK+LceeM7ylo6NKUo+9ZxsnJO6acvx4/az/AGIfCHifRtZSLSreWW6huCYY4U2MChIJaPG5vUfMTjtnFfPSxk8ubuq0p+5++dOUfYycWnGMWlO0bKTnzrli3FcvvSPusvrRr4GcKs6NRVqk1Ln9905vWFKm7e0qTajFLlfJrZSVuaX8TX7ZX7OOsfAj4oanp32YjSb2eS4s5VjPlRpI5zDgNtIQ4CjOTgk4HLfvvBfEWHzXAxp1Z1fb0Y06dRX5oucLq+sYpS1tLdKVr2upy/LeK8iqYPHOrRi/ZSn7WVnFunOfM7e60uVpu93KSaam4JykfMmmyPHo4KqY5LeVnjYEgrJBnd2yQVb7ufY5BxX2Tr0pVZ05OUoufPyy5W/iXLK3PZODt7yjyrlVrOMkfITnheWUpRqKUXNTk6jkkrw10TjpZJc3uNX1V7Gxo1/5c7araqs8dym3VrAphTjpcrEd0e5Cx2MpPAII+Zq0nGnGVN0qkmqUXeE5pzlCXMrRnTS5oqVuZShLqlJpxmcs6kqNJU0tHF8kpR92pe/K5/G7e+lJScbylaN04I2Ghn0p5NQ0lxPo85RpI7dhut5xzFM8Z3rBIJSBIoJ+b5WJUVMZ06tJ81WU1Nxi3CmoqUpR1j7OChN2Smqd0naN1bQ0g7UrThCU5xh7OUU+SHwu7g4pSco3tzR5rSUZShZI6aCR9XgiaICOS4RTkzbIpLqNvMEsC8rG8oyrrGf3nT5cnbEY1p1ZR96bftKUUuVfu/dp3nN3bq03JTUqkPdeivaMplnCs5SjF02nGhGMXrKDquKjWVvfUal5uUnaMoya9zkP9qjY3p+tcNl/Mv8Ayb/5Wdx//9D8l77XWswyGV33xEgDa5KDhQ3KnLk7gAynKk5wuK/malKUaTT99fWE5RqSqUZKu4QdSrCXOvc5ZOmqjjK9nzuXOnH+gIOFacnTqKTqTfs6aqOb57QnZqfNNSkuSUace/O5xaaMKG/idJZ5Lg+UEaScR7gFUKxfPz4wI1zz8yk5DLyG3wsa31mnThC1T2sORSaquMnPkpRu+ZNS5uaSUvZuygua8lHlnVSp1avM/Z0+dVHyqqvar2kqspU6b+KUHH4tIJRtOTj7v42/EsXFt8QPElrpNtdR6bq+v3d/p924BtYmZmM0UbAFSUDk5LfdYFs4Ab+m8uq1qOWYJV5xjFUoWlRjeU04Rpubbs6XtEkpRcotOmv3bSaP53zPE4etmWLqrlpVaFWsk+XlrKnaMoKSinKKUnBJxcZJNc17o+j/ANkbw9Zaj8YPBGmRiO5vZNSErpNuLM25TKypsOU2q7ZAbdjAJJUL83xhjamXZBj8XVqypc9OcYWjBuTlCaj7qkpNxjJy9mmlFyi4qSjyx+y4Nw0MyzXCUeS7hOhzxpwvGVNJKbhKSi3Ts7wjGMlzfC+RpR/0Hv2bYk0zwV4asZ0iKw6fZPDsRUUN5KArhcljtzwwwCOQcnd/H+XTeI0SqOVSquWakk+dTnOrGbnq4yjKDk3JXT0tfll+85pRjGqpRlNKjzyjXqfu58sLKko04RhLmgr80m4/FG8HzLn+7NHUmJJNpYP+6CqpJX5txJGOmFA2jqCATgA19Zg6akvaVotNwqVlKTSjUlUko04RjypQtHmd2rLllqm0fLVbw506koN1KPK2owU/ZR5pScno42TTjFNyc57s9O0qwBhilGCcNtOcEA9VAJIx6MwLDBHzfM1e9hsPFVIunRjze05U42jJezV3LmpJNSbvUfuuNn7yiro8XF1PbTpPmcrwnUbhze9zylCLXdaNpOd9bpyskdjbpKqLj7+5QWAwjADHHJJODh8rzxjIJNenSqNRTjOcOaMo1OblUHKVW9rpJyevN7Ryi37ys7pHm1VObXLKcuSVOEXaKcrR3tKUl7iTTc23rpa3MIzGK6fe5B8gkMAFIYnPOOASPu42heScHhZlO9T3sS3KFaMowjGXJZR3inGS5ot7W523dXi7mMI1FG0qt2nPk5oK++r2cZydrc2j17yTNazJLJuMhBOCONr8ctuG3kZAyPfg5zXQuVqE5c7lCnD3qs5uKSndLlioysk7xuu6tG1pROMmm2pSfPpzNxjpF+909614rSN1vuze8qJlICh3PUMM5b1HBA6YwD74IFenTvQadOtFOUpRfsVeoouN0pOK5nG7tZt3ej2fL5VRRpSSXLD3G24+9U0a05rSSVre77ndRV05ZlzpChSWjVslixJ6A8k47EbuMdh9K2jereclZy5N4xnVcl7jgqu1OnZe/wA0/tN+7opZxS5uW3s4t6OMVUqt1IqzvqobNpaLXVO7Z514h8PWs3PlbgGz8vVs5BBYDIXnG08Z5wM4XjbSTpQilyL3nFx5IzpyvzSu3CpOCim0lqlpz6nVCHsXzTnH2c3+8pLlvzfC5VcSneSslenzqD0Vnpy/L/xJ8AW15YXbGxUM0UoRlBzgBgUAIKsSM5ZuACexw3z+aYaWIg5U3H2k04ty/dzlGavN8kUo0oOWkZRk29Nb6n0GUY+rTrQVJRcbwt7OUIc8o25lScWppRiv42qj1V0mfyD/APBZP9nlG0O81+z0xvMtJJWEscaR4Vcv5mQSoCKrbywGd2EzXTwTi8Tl2PpYaum3KTqQdOTlzKVqc4Nv3pJOUJRafNe0ndS5Y+xneGhi8vxEaLhThHmfNKcudQX7y95cz5rtc05Wc3a3Mk4y/l40iw8MmO+ttSmlimt5RIQH7I+JSAflOVwOGGQu3qNzf0jhqUqnsa1aUVGNNuMoydpSenJOPLCMYuTm5JQdr68h+DYv6zF1IQrUm4urT5Xzc05qTSi6ap2S05kkpublq1bkh2GkSfDHT5jOFuri4YYjRpEWKTduVkKP8j7/ALpBIAHGR8y16rq4SMOVUlGhBNq8Xy25YtycrpxUarU9fjbTjaLvHin9Y5aXtKklGai2+eUXWSXLKCXJa/M1bnmruKm2rmfqGreGfOjbR9OuNKvXLLcQSOv9nXRVmO2SIsUXuEdCVBPQYG/kqRSgp0ab5E48vK1eCk/jd4xjPmbc9Nd0pVN464edeNJxck5wuoSulGinGUpWjGClJNtyhF1eSS00TUI61hpn9o2lyukQPC6yNKbSO6Ris6odzWzPmVVkKnAxtDKOQaScpSiqnuRqxdoQXPOUVGHKuWcvaRtHZKWrmoxt77j2xqU6MqSqe0UoQ9pOlUlClGtOWn96LqRtDljG7b5JOba5o/7T+xvT9a8m3+L/AMAPQP/R/CWLXJtRjM8qMh2fLk9SBw+FYovOSoIIGOjBs1/NqdKpN0alRzgvZuUk6lOD5p2ilUtKpLlfLflklK8XKSako/0HVpqmp2hy1VKpJyXvS+suc1z2k4S5cPB+zvvGKcOaKk1FmqeIYdI8EeIdVdz5cOkagu/zR5nmMjrHtPRQ5XG7JfKkYB+76OW4dzxuGp3aksTSk4KEvZwcZK0WlzSkoKUY3TjC/NJtpe94uf4jD0MsbozSrOhNutum0nNxvzSi1J+4+e+0pPmakfk/pnxB1d7HxDo+q3CTQyTC8gE0aO8Fx5zM8kEpG6NtrYZI8K/AIGN6/wBDNTnGlh6dNRh7CS0abSSpyTjfe/PJT97ZRk5Rvyy/nvEYS+NddU0q8pVHKNJppSm3H2cFNu8Yys5tOUVaLioxuz68/wCCaM0up/tq/CnT7otcWuoardQMrAsNsltNsVU2kDacFT84U5yDnNfA+JcZR4Qr1JRqySrwhJylomuayko35pNNJx5YXXLGTdrH6P4aJUc8VJwqYeU8PKKq0+WUoyc92pKDUpatSStzLkTaSnD/AEIvh7e+F/B2lWlzr+vaToFqjiFTqmo29rK8ca8SQx3EsYZQWCOwOEwDyPu/zZl2XZhDkeGwkpQfJGE5pujzOPvNUoaxlGEeb3rxfNJKrD4Z/rmc5rRoYipQ9tCFSpX5VZQvVlByvepzONOU3CevuppKzfM0fY3gPx/4K8SxlPD3ibQNbe2ibdFpmo210xJAG9jFKcscZI2/e6ZwS33awmJo8ka9OpT52oqM+SalCEVLd3aSn7sVK3NGW8WouPxOLx9NOnetdTlOpyWc6aVrcylLSTaXvK7slaK1vH2TSNQQhMja2BlV2qy/MTgruLKnHGAwbryQAvTSV6MKsFGCi695U5tpu6V+Xku5WvGbtbRL3UiJKNVqNPlhH2UYuTleOt7wjFR91XWt3zK71funaR31siGQyEEDdzwCAMcL1Kkc5wc9sYw2s6icHaSt7OMbTvLmtK9k7aO+qu+ZJyTu7cuMo1OZQUm2pdbxTa6pyUV7tlzc0ve2ajZuVW4vBKI2jIbKguCvLQuw3ZJIIzjjrxziuCpjFSn+7c1erGbag4tSgmv3clFN8qk1yrVr3Wne4UqEqsnJSfLCMlolFaK2nxpRtZaOO1ntc14rhVjVt/yZUnsSuMYAOCSg4GPvdcHgVUsVWqUk3Tb5lJRlJqlBpO904y3bTT5k1declHnlhNX7k204txck7yW2kXbrdadfeeljorS7ikK+Wo3BeSQCR7nkDgc45znPbFe1g8VTqUoqdROXNB8tJ2k3HTljP7LaspNpczWl7NR4q9Ky95ezjzPZJe9ol71rXV79VfS6uWbm4jwcyBjgZwcsN3HGMHAP+xjrjdg16M+anzUekYzk6NOcVJ3V06jdrrVJK8Wne81dRlzRpL3V7O03JaRleUtfdbnCyTa2cr22XRmK62zghtp9BJIYVJbkFn5zjA44B5PcmuOmvrEounK1pQlyuK5aeyajGfxza5uWV91pu1JYuooxSm/d1jNRTlClezXNKLu5KSTfNJLVtt2aPNPGb+FILWRNQ13Q7PMTBvtOo2SYUjlVV5kaPtnKE98GvWjkrqT5ZJQcoVJ8rcouVo3VSo2rzmtP3ceZq9uXW5yxzjDYeolyuVScbt2cpSpp2cqk6dlCjb3moytNpOV20j8DP+CmvgHwD46+EvjC3sfE3hW6vLfTr9xZjVtPW6j2RSMJHQXGTGFyMEo23GQwOF8NZJHKMXTrpte1rU5yjdx0qczi6km3VUpTjGcYQ05o865eWUY/U5PmjzG2ClV9ipJxlXr09ZOLvSlepUl7CEJNJ6puEdY+6on+d74qt10Px1renSvDNax32o2e9GXynXfJHHNFIAQUzyvGzaAOoLN+84Kd8NRl76moQcXGM6lNVFC7jJc0UrRbdk5Tb0+05S/Mcwh7LGYynCVGu6VafvwjFwc+aTcld6Sjdyd72UpNxXO5HFy+ZE7wyOT5LGNU3c7V+5IDg8OuCDgA4IAOCK9GNRcqtGlZtK8Y2UebdKXPFzTld21taLd5JKUzUuR3TfNGDd0laMVzO3uxg1azi7yj7uspWgyzaXFy+VWQrJEuHVgr74+7oG7jgt1IGfmGcNtVvKmuZValTlbsnPk5E/jS92Ks7pODi5c14Td3y8bpqU5S0cU6b3m7NR5vaJLlXKuZqK1mndpu6UuhTUPEUNrBeW0rXVpDiJhHEqPAu4hQJkRWQtncWclc9A2DVTqSoVnyycqsYe0kpRUKag4qd+WKcnVjLRR5pOKi1pqo6KVFVaftKUXOLvCLneOvM7wjrJycql5OS5VF21snD/b48w+h/Nf/AI3Xj3n2f3Hef//S/nT0TVJdSthFHlckg4YHYmfvMcnPOfnBx1UArtL/AM+VYxp1lU500o3VPkh7aU1Zp6wpuCdGTUoRi5q97K85x/ek6taq37SPuJQlF1OeoowlvVlJQlUpVIc2rcpSa5eaaUTP+NOsnR/hTc2waJTqlxa2CqwwHbJLlQobcNg3sS/bkE42+5wvgFWzeviaTrV6cKMHdSpSnGo4U+Vyd6cnzLS8FHmcrtqN1L5biSXJl8KcuSDk5VZRcpLloRUOSdoxkpuzte7VoK0kpSgfk/fNML68fc0XnTGF8E7cEg4x2AxjGeufu8mv3qjTtRpuyk1GPK6jjzSbvHlvHktrF++4ylZJSUo8sj8jnJOSneMk9XOElLmnyX5VFJ8r5HTju+trqUZQ/U7/AIJM6Fc3v7ZvwNlFlNcudfm3OnREjs7glmI4WIgKmTt+YggDGG/O/FKbhwpUpRqR5quJoujFRUmo1HzSThK6lJJy9/3+W6fM22z7bw/VOGb1Z+xjB0sJUnTlWlNRk2248020+SaqN3gnG1/dunM/rI+Pf7C+v/tHeN9U1LxP8VNW8KaFBGbbS9O02+u447VI0yf3SyJEoMn3m2ktgpuPAr8ly7iGlk/1OjLCUalRU6cVSqtSqSbh+9lo6cbTSlNq8eXZ7qR9VmOTSx8vrVP3vZ1ZTqyUoqNOVuVW0cnFNtwnH430bTmfB3xA/wCCdf7S/wAC5z4k/Z5/aYbUJbadLiDR28Rajot8ZxyAsjmSC7ZmHzRMhBxg5GBX1uW8Y5PjaWMoZnl9KjSVO0Iys51GteZVE6ThNJKN+eVk29ObmPMrZZio0X7Oc69SnyKpH2UZNNyajFxlGKcbpra7ULOopOSPd/gB/wAFav2mv2bdTt/AH7YXw81rxJpw2Wtt48sLVZJ41jYJHJPc2geCYKuMs4RmzvILMQvTUyfKcww0MZkuaU8OqnPfBVZuooRatOKha8eeV+WUpdmlJK0cVXqYOlyPBTc+e0q0JRhCpCPLZShKU0oJStaMo3lzfDpE/eX4A/t2fA74+2Nnc+FvGenC+uVQrpGoTi01NQwwxa2klXdHv+UY2nvhuQvzmOy+rQnKknzKmlB68jSj0j7koy3dnG1091Zc3fhMRQr0uaftLylooU4yglprNPmaSa5HFS392y2j9jQeIYLiOLZcqybiY5Iz/rFPPYFXBAwoUYxzxk18VjcxpwxXsqNSpNRcfaP3U01ZNRVlyRWyabd9ZatRPSpUvZdJzjPmnBR5ko3S5m3tKT+yrNRfSTXvdKNadNpQs8YRDjrsJGSB8uWAz0x8ueM9aKOI5XTm4RcW5xUa1S0HdOzcb2U313vpZa2jlKjazlzaxk023CGmq03b2TfO7+TuWp/GdhpNs15qN/Bp9vFHvkknkSOLaoyfMdnG3HJZuMDnDYNe9llT21SEIQqVZzXvKEVThG70SlLl5rpXUVJt2vZXtLzMaoxdP4pq0ZKFK0JSlqny3aaaT+F3TV9GrOP5yftL/wDBWb9lr9nGO8s/EPiyXxR4ltI5TF4e8Kwvql0ZcFooZJ0ZIEWRhtzu4zypxlf0ijklOs6dSr7CkkqVWMpzapPmTi5VopuU+WSSaTlbayep8zi8TipOtHDYeblGcuSCVotvljacvfvyy1tprvZNSPwy+KH/AAVH/bx/bI8Up4Z/Zo8A658MPAc8g+za5qlv/YsEtvn5ZLzWbwqJRj/lnDtZGyM4INexWrcJZXSg6lfDY7HtOnOhhbyqUUnGaqUfaeyUdWlDR3UZR0aiRQyvN3CNfGucZTk7TnD2cJ88ZLkpUVrN7tTtHSz5Zcqcuu+Hn7Ef7Q3xZxqfxt/azgXU5Zxc3+h6P4uvZ47QyHfNFuS4jd5UbdgLJtV1ypVR83kVeOMulVmnQpwjSbjTqtWm60FywTpRk71G7aKc+e/LdO6Oulw7iZ03SqqtKlQSrQkoKcuWV5Km58sW1JtWik3FpaN/FsfFf/gjz4B1PwZrSXH7Rni641aa3u2eTTruV1uGljJi+2XFzePLPhsDbuAKcZBOa83F8d4PE4iMnh6PtYRpzhDldeNP3XGpSftUuW0XGV3GSg+aS5dD0sFlSnUVsNWowhJU3KrUlFOMpaRlBRSVa6i4S5bU9pXUry/jK/a8+BcnwC+Luu+Bv7Sk1qLT5mMOpSRFWu1aaSMSE7pAc7DnaX2tznkNX33DOdwzXA86kk/eUJK3Ja/Lzcq5UuaPKoy0vqrQvaXicTZbHL8VLljTUHGEmk18U4KWvKoSTTbXNO+rbnzKVofMIC3W7dIRMqcyyMwEiLj5C3+xhVT73BOB1Wvpotc8dVyxtFQUY35k+WKlulKdpLmUVztQbWqZ8rVnOcUqsW4pNc0ejTuo2UNXFTlaHKlLRKooK423lkhnWTCmSIh8PlkljGAcDAwT3BLZwDxxXdK65YPlqyqxVPmhZShBxcoxnNLl5rWi/d0WnvNPlqKceWytJ6Lmp2vG7i5O0bxfJfWN21q7XtLoZFntGTV9Kn8q3n/1wyFWKYr88c1sVdGjyNvzoyHIxnGKx5YTlBxSbg4SknTuuZW5VU5X72tpJpqclrG9ko88vZ3qK7hy8yopqM3eTglNuVo8to3ik24XteL92P8AuDb29f0rg07L/wAFyPSP/9P+WDwj4rjijGJo8MrFpN7KMBmWNSDgAOQTkBCV3FAcbW/JcZl06b5KtD2rjFU4wc4uU3NJvZc148yhCMJN3UeeceWUY/rtbE4ao5uMqFSTtzRpyajFW5VB8ripQlKK5JOTlJqylyxlEvfGTWZ73w7oGkwkzC5uJNQSMRmRghi8vzh8q8hiWA2r8mS+chl9/g3LpYSWIxkpRXO/q8KM0oN2qOXK5S9904OVvcdpOCdNq/JL5TP8RJ1cVGTcn7BQftVC0aLSbinemteaMqUZ2UIyd1OLR8F+II4hqEsMfCQytliCpZgSGL575ByCOrAZ+Ubv05R5cPBKDjF6p2bioySu0kocsE4qCilOXNFt2TZ+dUKcoytzaSqOo5KSdRqM5ctoycORSXI5JRvLW/K0lL9zf+CJnhCy1T9qf4a39tev9osGuL77NdbfL8k2rrNjY3KIQ3Dlc5+VmLZT8m8UsQ5ZXh4OUo8taE17OKcpwpvlXvXk2058yj72ilGaUY+9+i8K0Z0vrHOqVVVKbcaDjJ1HBu97R5eWesuVXfI4czjJSbP6qP26viz4k+CPhK98RweCfE/iPR/LfbqPg7SrnWLmyE8beW1zaWUbyvGJdu5HT7g3CQECvyjJ8phmzjGhUpxUI805Va0acoqLvUfNPnV0+eSfLFWnolpI+uxeLWWQq4iUJYhpQjCj8cW6aUYp80vfunezvJtWjeSbP5frL9o39pb9pzxpfaB4D8A/FTxF4gh1UrDF/a1z4M8OaXZyv5SC7W4kikWYxjfIQyuGUh1DYav2TKfDnLq7w8KVRYytUp05Rp0OWuoqneLjUqU7NSlJ8sZzl9r3G4RcT5zGcYVMPRqYyODeEdKV69WrBtzk1O0YUoc8pWmr3inveL05TzP4kftG/Hr9n/xr4k+FvxO02O31zw8LKfUra98Y22p6cLe9iEsNtFDrVrcf2hciD90CrBSV6r0r3sb4ZQweKqYVSeFzB0I1YL2vLJQlG/vTc0pSu3KUYy63tO/NL5zDeIMqmGoY3D4SWIo4ytKKpzo3rSnOTjOag3+7d7NOcFaNpq7bR9UfsgftweEvFniG3h1j4YxWgtZo7e48T6Np7aHqWmyOf3BlFiwsLpJD86uhTkEhDk7vzPiPgvPMLCtiKOPq4tUXCFWEp1ZwglKTcqk7q7TSjF77Jp2TPt8gzDKZum50Hh5SnOXvclSnKs7TlUcGrwTi7ua9122+zL+p39mP9oTSdd0jT9EXWrnUI3MQsrm9cvL+9K7I5BKxZXAOWUnPU4ORu/G8TRr4XG1oYjllOUY1nKC3tL34Sas/dWq0k3GCS1TPra9KjilHEYdT5YScUlJSlJJKUnDlktGnazeyTTWrj+kNrfPNpgnQl08rLbTuQ8DBJ6qPcAdcDoGbpnUlSw9XEUqbTpzhNW6xdk3D4vadb3jHl2stWeFVpRjiIe4lBX5lUlyqba7WkkrvX4ddW9ub4g/aFW68T2V/o+oa9qVhosq4kttOdkuHX+LZcKQyA91bOR2warK8/wAeq0qOGwcq0rqUazU6cUm0nDl92M1/e95wenxSvHrll+FxLpurVpxtdSiorR9Oapr8LaUUlzNK8r2tL8Iv2nrv4Z/AyxuLzwT8MNK8UeL79ju8SeMLF9f+ySncIClp+9N5eTPnyLNNgZ+pGdtfomR4PPeIMTS+v42vGnGpy+whKFCNCnrZK0Umk3aKUrz63aaly16mCyaFStVo08S5Rfs6dPSE5xnpe2nM4yk3Kbtfkdope9+OPx4+N/7W/wAMtc8Kan8RZbvwt4V8Z6Q2v+GrbWdWufDGly6bHdHbMuheHlju7NSqmNNPdHm2MvmbTjd+zS8OcHgaWW43GYerThmEp0liK/uJqPKpVK8JTlNKmpKXMuVtNOKmubl/Na/Hksficww+Bw1aNXBzUK1PmnOFJyjePJ7jg72V53nySSSTXM5Yvwm+Nf7UfjObxk/gD4Zr49j8P+H5vHWp3/h7xH4n0q9tPDvnMnn2LX8yPdSZDOsEgFxIF3DOTu6sRwBkea4zGYXBfUcX9VUpe0hJwo8lGmpTqQe6nLo5u8btKUvd5eVcTZtgPq1SeN5Y1q0KPLV9nP2kpp/ulyyhaXK+vubSum2o/od+yb+2n8afHupQ+CLvSPHd3DcQW9g+keJrC5n1xLy4xHLHb3y2vknS7RlK+feyJIAMlmYGvxvifh3K8n9rKk4Ri5Tc3QnJx5uWypbznTpzlJue0ZyfVOKP1HKc1xuLhCeKw1G0YuMZxtGcqcvZq9+RPmaj77SnH3YpTd1E+S/+CvX7MWu6Pa6Z8Tm06QXsJI18IDI0FhdPv87KqeLebaruGOVJztUB66+AM7jSxUMsklSWIhOVOC05cQm37KpzJQs4czUVQgopq0n7zObjLALE4GOKoPmXMvaS5Ivkjooyi3CPLJONoJ0ouMbtyd5n87xiMUrwNsC5PlswIHXacn5duTgg4IPc8Fm/boT0neMrvk5rStd01B6Qteej1XM29LNpKMfyCtzUdJQcGpxaqLR817KSUud8rlraLitFFXu5F1E82F4zHmWCQfdY+ZswdxBz86kHH8PC4HBzXXRaov2k4qE5w91KTvLm099WlFq0bx92L1u2r8gklGopOcozWjjOVkqVtU1rrdqS1j8Nm3dyNzQLxopJLWVY5rK6XbLBMo2sQMM+8sTuUndtzl8YOCQy3SdJzcoQklKN5rmunbncfdgk9laK9yMVLRuKvLKap1JwqSqP2UX7S0OR8is4NWjfdSTXKmrJ25bNH+4RhfQflXl8y8//ACb/AOWHef/U/M7xL/wTm0Xw/odtqsG8W6wrfXCorF1RePLkEbtHuk2GTd0VmwS207f2HjHwvynD5Z7fBYanCvVSpUPZOpUWKajDmr81So3Cmk5RhCMIzajZ8l2fD5H4j47Fy9nPGziqibhNwXspwUuWaS922t+V2n7NXjBxknKr+W/xqgj8MXniF5VRf7JsTZ6UuFOYGnMKSIAdqyFFHBAYsxJ5LbvwvLsorYHMKdGpPlwkJ1J1Le9J1FT5G1KXvOEJQi3yWUVTs0uZuP3dXN6uOwjrVW5Va8qUPdhGCo25EnPmklzWhTbUZS85O1ofnXq1w73Fy7gs0hyW2jq553MWGSeCpxz3J5avpopqStUSalLlhKo58qXRQ99NK70b5ElFw5nyqPBZOK5ZzhHntZypuHtIx1s3G10/ehJSs7KyWnN+tv8AwRY+JEfg79vP4N6RqUyR6f4nv5/DUTSMwRLm/tJWtyFDAZaSJV/jBzgck1+b+KOX+2yVVpuvF4LE0VPkqJRVKcfZtzmk7xU25Ri+Ve8r02otn3fA2NdDMq8K/v0qmElKlGN5yp1KNpKqpxjF80mpXfK4z+HRpKX+jRb6Fpmu+H5tKvbSG9iuUdCjISjDDKFcjbuXAxk57ZAwRX4XguR4itXnXq0oU6nK1h3FSknonOMLR/e3bdPmaak2o/Ez63F1I1FSU1FU53/fOXMoJyek4zaVpPRtKVntGNpH5L+O/wBk68+HHxd1f4g/DuCCz1G6mFzFYrGrWKTE7j5sZXHzELna5Dc9MDd91lHFmYZLjE8DVdFxp0r07tyajJckpx1UYaybak3zOztrE5J5dgsxy+eGxLhP2tRKE404qdFU21NU6b9nzVGpOPNtrzapKMvhX9sP9hXSP2wPFOnfEL4geGP+EV8bWNpaabres+GbTTo4tft7ORxaT3NveRTR+bEj7XmiRSQM5GArfo2ZeI1fPFQrYmhGnjKGDVKdVV5OVdRd3GV6fMpLVQipSilbmtzNy8PL/D6llNWrWwdd1cPXre1mq8VKcdIubXvpQnyrlk7O7jePI2zB+Gn/AATt8OeD/AMnwx8O6jc2Wiajqy65rOv3WmWd3rlzqqAeRIt6qQtFb2q4FtbQ7Y1YEnK5Ss8LxdVdDEYKjTjTw9XCSVf61y1lOpC1nP3E0l7zvDlWqtNNty7pcPZdQrwxUalXnwyVOnTVTkpyV7yfI27uo2+Xmp67rk0Z+kHwJ/Z3u/h6vh2zi16+8Q3+nXlnDFq7WUNnNdWvmowW9it8xm5Rvl84HcycPyPm/IM+wFKvOdep7KcpRlOlGhHk92N5JJytGTir2l7zS0adlE+ry+pGPNGg3SpTfO6LaklNR5ZSTcJaaNSikrXVr3SP3r8F+CWfwNH55DXj24EmVywVkDfxqoYjGOMgdicZbjyjKKlfByq1KcXDEqXKp3XLy6axV2pJddH00veXgZljIQzFJNuEVpbWN11trbo3dK3VS0PnTxH8JdP1K+uY9SjkuI/NdvJVFQADPybtw+VvxwcHAyBXp5HlOGqVG5OXI5uj76dOKlFb2u5cqfVWb+1HVMwzHM8RGk3S2jFt6u6ur3bSad1rq3tb3Vc/Jv8Aaa/ZLfXfijaeLbTW9S0238OJBN4a8M2mm2Uum2xQyG7urkzxkX99NyFknVmiVQI8YBr6x46plXI6ClHDXjSqNU7t4hP3Kk+e0pRvZ35rRUW+V81pLA/8KWDeErKFX6xzSqzl7so01aXLFuDtNWvqlrprZHhHxt/Z70n9orwp4f8ABfxR8D2fiS38KTb9B1y3t4NM8TWYYD7RBHcQxFBBOcBo2DKz7W+XFfUf8RezR4GWW42lCvh+bkm52lKlJxcXXfMpybtvCmkoxSTTWh51Dwuy/B4tZpg8XUjiq0YylT9qoKa3j7a0oxjGz3dm9uZps6H4H/sQ2XgvRta8J+B/DMug6P4nSGHW7m/vJrjWtStoeIrGe7lVBDZIDk21tmIsxIAwTXzWK44xFKlXoYKkk8RQlQxWIpzftvZOXuy5o8srJJKMOWMpQ9ySaace9ZBlNCvDF4qpTqV6VV4ihRnThOg60PKTaso6xk7N6OK5Wz9PvgN+yV4N+GekR2mk6BatdXBdpbyaGB5ELgcrmMttVzwQ2eBwNor5HFV8Vi406dfnhJWdSEuX348qlScI3a5lDZXqRhe81qzWvmCqSU6cFGnSbdNU1ypy5vevGF5qMnGMYJNR+zL3XHk+XP8AgoX+yHpvxF+F+v2w0tLwtp9zE8RhRS4khYSF0CAsrfxFdoAAwC2a+cxkv7NxFPGQk6NTCy5lJXUnH4uenPknFtcztF8zm43TV7H02TYj69T+o4nkrQqRqcsak5NKvUtZTvKFrTvzVJSUHHlUbNSnL/Ox/aP+BWt/BXx/r3hTWrdxbRXU82lX4icRS23mt5cbMV+WRVKgqdzA4bHOW/oXhLiPD5/l+GrUKipy5FCrSqVY+2jOKcXJQTk3dqaTtFWSSdmlH844m4ellWIxMG51VzqpTkqfuSk1pGDi5a25lyyjK9o95I+dIJGheJ5AyMo2xTcsWx8wV14+UcAng8E8V9dZyjOk2uVpOpzXjbe0XOKd+Z6tLm5W72XNynxTbV21DmTTftVa6uoKn9umtJS5vhWqejTgaeCxEkUYDIFlZVPzK/OJIGUqXjwAGRjlS2SAOWqNWbjCPtFZ2ipNc0NJWlFKykm21JpqMUtE3JWFraXs248tnSlypw9y6lTk7OU4Rvf3ebljLlu7NQ/3Fst6n865fZ+f4f8A3Q7T/9XgJv2nvDWv/s36p4l0K60rVU1y0Gn/APCRxSK62Op6jIlkmleTjz7d4xI5mViAoG8uXO6v6L/1pwcsgxSnPEe2cZwoUuRqOGVOLk6s5uooq85w9nzQU0tPehJRPwXE8P4nDZzltOtRkqFCTnOnUS96K5aspOyi5RhKFWpKqlBLmi4wnKcZy/mr/a2u7A3cKaZK0y3Or3UMxWYssltpYjhe4ZWA+WecSuRlQMKwGCDX4pmGIbkuR2nRq8i5oRjF1K0XKtZRdpRlVlai3Co5LRt3XL+y5Y6k8I5X9nGUGoRj7SnGDqO6jqr1IqPvRdXn5VJScXy3l8AXwMmo+QrAq8yAPxtKbicjGTk457/7JZga4ZpRUZ06UoznC657vV8sHCpBvkThze64cyjf31FRtHojCU0k1JylGML1Oe+rUZtpLkcIq0vhfTZOKPo79kDWZNH/AGr/AIF6pBr6+GEs/ih4UY667FEsEXVYUMkjAAosgcxuTlf3uX2ruFeJxLSjicmzGjJRqt0ZWhLWDlG0nLlcpRfs3CzdoK1owjKyUvZyPEywmaYGtBuU+Z0ZRhBNSUqfsZQ5duVyny814xad3rDmj/qd+BPEEN5aWLxyLO01vCcpt8pg8EZLLgGPy5Adwb5lcMSGzwv8nxws8DjMW61T6unXUqcLuVOXuygn713q79ou917rTP2mrhIVcNg9eWM6MqqrSinScufVNTu5b6udk5p6O1z1LUPAtl4ihVmjzcSsFJt1VAV74wDxkYyM56bhjL/RUMNTrOtOeilypSjU95L3XtrKSkveleatslZXPmsRQq4evRjCj7WK55OVJezSjKSs5WS1veTTbu1eTkkmedX/AOzra3Nw7ymaYlyzpIFAQNx8gwWxnKjI5xkYxX1kMBhKipShOmm6MUoRclLSyakpNJtR5r2cl10krkf2hGm6imov3ryb05nK6V1pKOityNTi2utka2mfADRdKDTTWsYUfOoeFWBwBuIA2gEgEYOcdQM5La1I+x+ryo1eWN3QqLZpcvVy5nKK5rtXaez2aMa+Klim1Gfs3y3UU52SXVxUYQTkmtLSlGzV9x8HhLTbTVLRra3iRIbiEFlTy8BGxjAYjd0AzyAe+c183jZVPaSoxl+7pVEnFcqXLVkm5P3oaON/hcU+qd1zezglKNFOTl7SVOpFK7ipcylZJSc5Su0rO8dXd290+6vDiqNCttqg2xjVQQCARtxhh1BHBJIz65wK+zwNKFHLZOFl7OUZ3qRhKU4tapNc3vXuuVWVlq+p8bjH/tMrtqWqcdLK9tr8y3d72vpZJM5TUtGs1nuJfLRFlZVdfvcE8sM4K546Z4x0zXLSwvtMTUjGUVCSVenJ+4ozV78kVdOXSTaXm9zX2lSphVFKLdNySuopqNtNLpyX/gO1rNXPOvEvwr8LeJYvLuraMzx7jDINwdd/J5PBUZ6HIz253L3Vo4XFxlCpz8ldKHMoqUoV4XWl+Z2klvzapX1tFRzws8ThWsRCcoz1i5N291uN7RcakXKydrpK13pojyqT9mnTvOV0kiVY23o6Lskxk/KSF2ls88gYJ5zivm8VlMabi+fm5b+2g1BpL7FSG8qlRp6tpPS70fuehLOcVyNRmopNNKNnFcys5Si4JSl7zel483TQ9I8OfBbRdNIe4SabldrvLkxsMcDgkcZ/u8cc4LVnTy5UX7SMXVcbWUvdjWparXf2lTV2SVqe7Sdkcc8RJ3Upuo25SfNfvteKja7eqXKrK2tuY9KXw9plhDiOPCxpwGIyOB838IBHAHy/kSS269hC8YyjFtt0pNylBRSTnQnJxclFrSq/eb2jaMmTB1Kjbaba3tJ6N3cnFrZySvJS5Uo6t6tx+X/j8LG80G8tgsThrOcSJ+7O8JGxxk7wTx0wxOCD1+X4jiOVOfLSg5ckq6kp8tVvDzb1TjeCVOaSUbz5aUZOa5m5c31XD9Cr7WNXkjrJKV0nz+9eELOcJLS/s1GznNrmvGMnL+A3/gslo+i+GtS1KeGwtxfXeohIJ3giJKlg0qqygMrgleACSFOShGG+l8K6VWtm0Ixl7KNKEvrFKDnGTk+ZQnGXvXpyalzSTX2Xaa5lH2+OI0o5DUqutF1JVKdKjNt3TcuWcKqhTcXJThzSltU5bJOMXGX87Md1EzsZlKbgwUhcxhiPQnI7AkAnBOccBf6Uox9pJyqTaip8s6l+ab3uoK1udu3KnKylHmvd85/P7lFpykmp+0i2k1ryN/CrJwcuVq7Tirc0nO9ieESRmNreeOQbhjbJtMfPQlsYXHI25ZVHGeQrUIRqzq0ZK0YX5m/fjZaSSb5W3fletpTd/euuVucYSvU5Uox5VKM/sKUGrSS1aei5tZKaTjGKkpf7k/zf3v8Ax+uG77L7onSf/9b+WLT9Z8ZfC1dY8JWHivUtS8J6jcW0uj2+nrcXWlXkabni1N7lD9jWR22yEMFmXc6cBBt+nx7xOHndSvQnThSpQdenKU2rJTm6blz+63GXNza+zc3zRlzeJgsPRxsKcK2E5a0Z+yc6t6coWTjGEPa2nKMYtxblGacJRes1zQ8n+LN/f3SxC6cXDWWnESTRscLNdu80rnBZWkZsbuflyepI2+TGFaXsYTvzzdSbm+W9Tl5Um5OCcJKMox5vd3191Oc+5yp0q0sFTi3GlGlSjVUJ+zcY6ezTScab5H7KVtOdXXI/el8yLBm5imUbkSOSV+MbWXkcHoc4A4OTzg4rVtSklGb9pT5IcsZc7TlveyblTcm3L4YpKz2SjdOTjUiotcqcedU6jjN816bi41Odxduy5Vy3fMkoGv4OmWw1iPVWI+1afcQalZ27o5W6uLK5juY4GaPbInmNHyytubcAQpw7Zxiq0KmHm5NVIuFRqa+0m4xi/fSk4y1Xs7Wcm37qZrSruliY1IWXJLmhLnd1Jz0nzxjGNSF48vs1yWezSdz/AEdv+CYv7YuhftYfsz+CvHljpVn4Y1nw9bweDPFfhazluJItO1jRLa2tllSS4eS5aHUokF6glbh2YYOM1/I3H1OeVcVLAqhHDpTpKMEuZ1advdqvmt/FTl7V6xTi4u7cVH9y4YlXzDK4c9arVlTT5fbciilz2lBNRcE6T1ULy0km20lI/Yvwf4jdvIGFhRVDMCxcNu6NxJj6gAD2G3LY08wlTqVaNNSoz9lOXNJpq9PmUuRRhfV6pL4XrdNpR7MXgJKnTk7R55z5OVO3LprU1tJ3Uk1092UEkm5+4WWpxXUe4Fd6gZBPXGM7cjHXPBYDspB+VvsMJio1Y4OalSTlGMJ1JK93y8yv73NKLvpK10t4RsfMYrLbzrRjZym7q/2Xe6vo2mlpdrfpFr3cvxJrNtBZu7GMHlOSg+fbjG089eW4GPckGvTq1acKGJ5qtO1PlkmtYuO/uy+y+RLR73V3Fe7Ljp4PEUZKcnzOcuXlhzSbirX+Pms3pFtPRXte94+QeF9St/EOrzKqg+Rc+UZFwQzg/cX5cFecknvzzgbvl6uNjWxMKl3HD4ley93WUZ/Cno/ibsukbJ3au+X0ZUakKMov4qalUd9FCFrckndtrpLTycW1zS+5NIsCvh20XaQuFZdpHYckYUNn0B5HQY+9X6DgqFRZVSknTVSFTkqNyd503p70XJK6196901ql73L8XVqJ42pG/wBlO+qjzPZaLddny3vrdO0eP8TE2TxrHEsklxx5fzH7ucsSVKgZ55A75Ax83i5kpYatCNOpGErqdGs1zWb+zBRvq3o3LfondxPQwseaEq0k1CDtU0u0+lk9ZXd27Wta6SvY8wl8aQ2OqLpl+EguG5iGMK6lugJ5356ZAHXjj5vFr51Uhi06lOShUjFYhR9yUailyucm7OFPWLaik5Pb3Xyy9Wll9WvBypJzWjvrqrSfLy83K5a/Zs1vre0e6ttasnVG3BgwypBzsf1bIwQcn64HOBmvRq5jDETgnWbqQglGblywxEWvh+yoqMVGPVPW9205ccsBUt/Dai3bWGqkurSel72l7sr9ehck1SNVJLIN2RjI2tn7p79PQEY6FuazlmFHkklWjTpKUrXmk8PNauMZS96NOV7zlJSm1ta1o3/Z1RtL2bly6tKLalzdLxdmklpq7Nra9pcP4m1qGGFisgjIQ7mjYYU88OeRt6HGeOnOQW8rMcVSlSrOPLKvNJSjG3JUTVlVoqPLH2jTfJGHv8zbk03eXr5dg2klOCu+bkcqeiurXd7xdno0k27prX3Y/Dnxm8VQRabqa+Z9yKXJGSdrIw3JgnO7qxC8LjOcqE+FzLHTU05VVJcvJdyg1XfLZwqt6RlTbXtXbmlL3YNctz7bJcsxFPFKpPk9ne9WD5HGMuX3KkeXWGjXNN/BHR3acpfws/8ABafW1utftLwNG7W2qEwMU3o7uF3KQ/y5ULvO7I5zxkhf0fwin9Zx1eNOlUVN03UqRq88atrNrmejcLrlg4uCWilfU+f8SMRQ/s90VOFqqUZ8sZOjWnB2g2lLenp7KS5XypSbTuj+eC58okSJIzsweR1YAbHdiCvfoDkfL7knk1/R6cpJRjqpOKlyWUYuNpK1rXi3HXlatFcsee3KfhEYqEeV73S0c0mkuWK0UZ8zS5udpJ2tbm1K6u6klG527WAGQwAHtwM9c7cHjdxmlFRXMuW8Yw9pBW2amuWMoqcYtpOyaeqfvRk21FvmppxUpc0fjcZJWi3yxSfMoRgm+W6bXTljzNn+6BXCdR//1/48/BfxP8X+CbS6+Fup+VfeFtQvGE9pqEG+6067dhH9rsLsKJIGQHc0O7ZKRyq7iK9ak21GpTlKth3TVWlzSj7KrShGc4SUPedOMm7c0W5wpx5HKVoTOWFKnGvUlOilUo4n2cJSnedX317SMOR2dJPSLpxlKpFRqJxu1Pe+IkEF3pksGnxyTR21qsc8pOxQ7jchVMgEBQwHB+6cDnfWLqPmVanC8pQnKh7qhGVOUUnzT5HKS5lzLSKfM+ayRlVpzVaNSnKsnCnUVTmg7pKrfnV2r8qaspJRvzR5nzzlD5ieNoiIi5UiHLBMkEh9oDEEjcdv02ZySfvaUZ03FOSk0nNJacz91TvDmSfLO9toNPpJtmk5Vat5NSjByvBLaMoqNmpPmXK3UaqXu2uZLSPMdJYafHdlbZGK3rQm7tZoj5W5YU/exsufnYorFE2jJXO8qcrMKtWTcY2UZSjFSVpypulFzSVSEUuZKapz191fFtaLdKtKo5QrJShFUpyTqKybt7vNyxUnLWfve6lFRUm0f0E/8EA/2pofh38f/HfwB1LUWg8PfFrS49Z8Ni8DII/FuhRs/l20LOV8y/tXmiZvvMIwxUuMt+JeM/DscbiMnz/DqEHQlHLMY5xUqcoyjehXnLmbvGqnFaxvzrV2R+seGmOusRk058yoqWIhRm4OrVu1GtJVNXF2/eyjd8/K3pys/tj8D+L45I49rO04bY245DBRjzFbAHzHrnLHDArhsV+I0q9N42cKcuWVKLpyiv3snL3Xy2cnzU5KScYx5bxd9OWx+mYvD/u8QvhpxrpwjBRcXHXllDRcvL/d5W38UOV3PovQfEBKBjcL5Z5Z9vHCjK4OSGBON/Xg5CnmvUwOJkoODqqoqU5PlaXNFXcpKMo1GoxjzS30V7c0j56thlCqm5SklLlalOLnq7NO2stJXulyvR+9Y5jx34iV9Nnt4Zg0sgZbaMbtzfLhiCGwSeBg7RnPtt9qeOwtalzU6r5EvZ1m5p8k07czVlzqKt8N9LfE00RQouNSdOScVL373U9nJqVrRUItKzTvfeWqtLn/AATr+l+EtJ02a8fyp2vDJO0m1JXnkfhGd5Eyox0CkjJ68mvGxuMw9GCoU6s5TjapRm5qN7SukuZJtu3vtPZ2XLK3Ll7OeKxNZpXtHkVl+7cZaaKHNZ2XuxutdXZS5Y/XFt8c9EtdMtbaRQNkIkMiyIQDtDbmIkBI7cHH0GK9KnxvisPhaMYUYVHFctaDlLmmrWu7StbX+W66N68viT4TxFXEVKi5lzyXs3a2rfvQvo12vqumt7x8/X9pL4cSeIY49Y8Q6RYGTMcUOoajbWsksm7GIopmVnJPBA5PUdAW54cXqrWh9YwtWdOcr06vK/ZU5X/hXcrRs762Vl1Wx6NXgvMIYJToQkpWbnTu3JxWsm43eqS0ktNHa9rywPG93ovizXodS8PypcxR2iy/abWTzLdZiXKoJI/kJ24zg9+1etjH9djGvGj7KtFOdWMZe0hUi1up3s5ta8lm0+WyVnM5sI8Vl1P6pVhHkcoqM5yjCok/dbej5U5Oytd73tozlLXxxNFObWSYLNany54zhSNpI4BO5iMZ3dSCeOAK+eWM51ytThTTUYt1VGpSqQaXvuMWoxa1Xwp8vLzrVntrBub5k71LN8yfN7SOnuv3Yxi9buKevxK11zdMvi9Z1QJeuys3A35ZT9T15Pt06jANL61Wbu52rS1u5JwxEIu0L+9yp9Iws+eXdrnN6OCU+b3Ekouz5U3RvvpFSlq0+ZvXVJxbujkvFHitILS4JuNzEY5JKMrc4I6g9Rk7FPAOM5XycbmFTDydRTnKnFpuEf42FlJ292U2m23JyqLantGT5UzroYOpLFQo3hzuClZxbhUWjUoylop3V1JJXlG7s4rl+Dviv4hub3T78hmkUrIgKKzPGvIZiMqSinHUe20gHd85jMZ9aquLkozcHODvzYfFRd+Xkag40a6fuJRUnUnLmk1flPs6eGjGkr+5aGrhHnnC3wqMWrySdk7vWX2o2sfxV/8ABarWIbbxP4R8ORyKbie91G+uvLJLSCJkSKRmOWyTIQVxtxjaTgrX9DeDOHrU5ZhWnrSVKnGlVm/epS0jOg/3jUvZq6UoqMnzS5rp8x+E+JFSk1hKblJ1I161XR8qcndKo19ptNQk4RsrqL5kuY/CS2TfvHAJAAGRgZZQQemR6e2cA5xX7woNRc3zyjFSktLttu+rabXKt7JKTaUotI/LqcF8ab961nG7lGThyy9x25nLrO+mtoK8eVEVBOQSqlmb5duQVAPHUHPOBtK5zn5siqp3cpRnK9N8sUoqybt/y7TvqrJy51yqS95xVlElBztTdpN8kY7NPs1Z3vB2k+b7N1bRI/3Oa4bR7v74nSf/0P4uviZrUV1431G9kTzWmuzOZ3kAliPmFgBsBBCqQGyTkY5Ga7cnr4ipQ1qRqR9nGCw9ODjR53yxlKDjKMbtq8VU9yMk3Z2vFYqNCNeCpU1SdNxm3b2PNy3UI05LW0U01GKVm3e3N7vp2uXtleaE1zYv5bS2toZkZ2ysaxLl1BVtxJbjnbvVjg9V1nOpVn7NwShClTr8tGnNKc6bs5TvFq9Rykm1Gc5KTtN8q5uP2NapWlVdapU9pVcZxUYJOKlG9SEYwcHFaqKldtXsoKLkeFvAiarLCY1fEJZSchAPL647SHI25BPy5PQbeWtGo27KfNVioR5pxm+ZOE3fkk5uDUXFO0YyTimlGV571KlKXtW4zUVFW51FqHLGNuSKcZSu2laXPzSi25OLjOO14dvE8Oa94X1u8txdaXFdn7VbbF/fQszW9xEd2STsfDZwMdO4q6dSpGN5qbqU60ee+q93mbdoqMeepHl5eZc8pPo2uZQpSXP71On7SnOLjCLnGUpws3ySneNRvkldKFOSfuKdve7L4XfFG++Bnx18IfFPw1I0Fz4K8d6fr2npG+1jpkN+JXtRJGSpWS0Lwy4K4U9q8zijLqefZZmGVyTVPEUpOKs3+9jyukopy54uMkrX5rSTblFO0vT4ex8srx2BxTm3OjNRxMasbqUarnCrOmnJXunaNpRUdHJW1P8AR2+C3xR0v4jeCPBPxT8OXEd5oHjnw1pfiPT54ZEZBHqFrFPNCFiOc2krPE6sGdXTDLx838V5nCrleZVKEr0JUqvs40uRtQUZNcnteSCcuaLTi3K8btXUZH9LUMRSxuAqqk3VhGldKcJJzk38SanNR39xpyjO0lFuylD7GsPEMk2nrBbyEsuHiGNr5Yc5DBcqTkADsc85xXVhq0XjI1G+XD11eo3pCTbfMlG8Z2TfK9NGkly7y8uFGMlLms5puMYcrTcVe3MpJtJpWtBLVN8zujK26jqOpxNcybbcZygIQ7hjYxDEAEYHA9MYIGa7r0qc6lGo4Spyk3RuuZXte6jZTik3b3nF21WgV5UI4WVSDXtYttpxi3y9PNvX47xt5t2jkfEnwBbeLNJ8lxdQ3FpLHc2lxZXElvIlxFghgwO0kMoJAY5xjIBIrsVCjUp06NWMKjhCLi+WMvevzK12ppO0bc0XfRt31PLo454KrCrzWnJtSpuFk27W97maXPFbtwelknY8ohsPHttMsTXl1c29uqRsJ5EaKRI8DaQNrNgYLYKliOduMt5FbLXUquvTdRVLSVWhCMkrJtKfKlJRcltywv6/Z+jp5zh5QhRnHDwnOPPSlTlGU4u2zlFTglfbmSXe1me5+Bfgt4d8dC1vfFej6Xqki3Cyh5bQlo2Ug4DhGkGw4Ay2D/eXGK9/JMOknSnBzoWcZUptSnTdulopQ83yq+tr2tL5rOc2zHDVNa+Iw85W5HKT/exSco25I8i6qPIpab3btL7Y0jwVpeg6RHZadYw29rDHtjt7ZECj5fvbQDIGPAOSx4BHQ19fyr6vTwrjGNGM3KhXSajFpaQkm03NXe9+ZO+qdo/IzxtTE1alarVc5uMedybvo376UlbmWuj+FtvS8YT+aPiP4fh0/UZdUsGaK6DEzxfMpYADJUleWwoX5vvZxwflr4jNYuliJU4ulh6s7JU5RXs60Z2aqSbfK5XcmlFe4nyr3k+X67JMw5qao1VKrhub3Z9Kd3zRc7pJK7bU9JPbV6nB6b4hkRC7fIygqJJEdlB/2htYBs9Qy9s8gAL8xiMc6E+SCTjTu6lCLjOUWrtyhFcrco6uKTkraOLteX1s6FKMXJOEXOLaqRkpqrFNcvPG8eZq/uwUdWrtWV5cf4p1a61OVLW3cHzF3TBFPlttGAVcKNp+YDAPHOAMfL5OIzRVIy9rNyTb9nVpKU5cl/4NWlJNpLec3H33opO9jfDqjSl7ZqPtbWdFuXKtm0tZcvNGXNvFq9k1a54V8S4INF0C4nuC4zFI+9SkjLkM2JNxU7AOdxKlQwHJOayowqxqVZwpqSqqEvZSbhTrNOKhUoVFLlp1Pd1jFXcb3mo2lLavmceRTTqX9p7FzbSq0mk3BSWjd9OS05bavRuX+f3/AMFTfii3xE/al8T21vOJdM8K79GtkjfMS3Al33TLkthmkJEhByCvcg7f7M8O8BSwvDuHlThOM8T7OtWlOMp1G3G93JRV4RekeaD5rRt2P5u4xxFXGZvKpVlGTgow5ItqnFKXuXbSSurSbak5dVG0eb89tJhNxNcAplIbd2ZsZC7RnJ+YbcnADEH+E44Nfc+05XCEFK6k+eMuZXTfNKzhq2l70vsxtrdKMZfMKLcajirckW2nGCabtFPm92KSd7+7Jv3Fraxkqd0mScHJGRhjjOQedoBPbqAOpIGGbbTXK4253aLnOMbWav0vfZ+7bmk3HRTlFQj7OUJaVWtoylHljyr3VK7spTSSt8LjLe6Upf7n1cZuf//R/h58YmT/AISG93MSwl3fOFbn5ueM7V77cA/NzjazNtkspxwtHnTcXeM1GNROafLzya5faSfvNxnUUoJxTjJXal153hpUsbKE7yqRqNObn7slOd5uDhFybb95KVpKMnfn5Uz1WLUXvvDdhH5bbn0oJ520fMtmTlVwVYgFgGGzvgBc/N6bp0KeHkm6/tHCpBtydOon7aU2nzxnGKqOSqc/NK0UuZpu0fLrQk6UVTVp/Hz07+3SjOCSetS6cpSlTjJcsI2TjGSUTmLV/t2uwb0deQoWJRnHl7R+74KlgDkhuRnOc7q8qjVgpqacJS5ouFSd5awcXJylpz8rlGEFKMrS5YtR93myTqUpVpzpxnK0+WM25OTSTcYtQbtGTtCTipucVGbs4Mn8QQvJoy7JFC6bPdpJE4EbCSSVZU8vc+4sqnB4IXqMg11Tg4zrSlCXPKt7WbjJqVpKMIw9nGLUE2+aPMppPRzVvd1hTaoU8TWjJRXLSnFVVKcYyd4K17uKjOKaVSajJaOEtI+eX9215MszokOUjjdYwoQmMBSwIJO9sAsGxkE9yBWSnPScOZSg/ep1JT9pael5JxalfRzcG1HltpFslttclKoldNpScrJXbmlNynzyjy396MnZKWu8/wCwn/g3w/awtviB8NfE/wCy74u1cnxP8OJJfEfgP7VMnmXvhS+ZRqemWoZhJIdKnzKsUanEM2FUbWFfzH4ucOV6OYUMdhKcYYTHN160uWUZ4fEUIpVVReq5qtO1VU5NxlPmc+WyP2rgTO/b0qOBxTqrESg8M/eglKnCF6M6kFZXbjCMZNOzgm2nLmP6bdFS4hjYRSsFZXAY9R2+T5SVLZByd+MsFzg7vzGnyRwcamHcpVouMr1ISdSMXrH3oqcZNR5k7prVN+8+Y+8xFT6s429krpczlyzbi9Wnp8crKOrdnK3K7M5X4j/FLRPhB4dk8TeNLp7LQbNGlurwxSysAis7AmMFuQBk84zjjrXVQhVx0G6VRSx0PhhFNy1duW8bJta2UkrR+1FaHHGj9bxmGhCNNSxbjSpKGjUZuzezipa3vJK2rS15T5FP/BTXwh4ltTB8P9Hs9RsNxji1O/1e1hikRM/vDbKpmVVwS4keN+NvzHNc2Lzavhp0pTw+NnWwvLz/ALqo4Snz25VUhe9klKMZR5o25rpJn9JcJ/RtwuPwdDH51n0J4fGJP6tTUHOMZ3koznzrlmk7Plco77e8S6T+3rBEQPE3ha3a3uNxSbSpw2/I+V/3/mo0ZYfdjfcRzwR81x4gzRyjVw2XYmhCTTdSWDrVHUi9bxnaMpNrSUmpJLtrze/jvox8LK9PKOJMJCstXSxlSjSlTUvtJ+1tO178qUUtb3+KXoHhr/goVq2isbjw/wCBY30i23z3d3JDqU6xxJ/y2nmhgFtCoHUFhg8HAya1wuY55HEyxOEyvF1JYmUlUoulWjFxenuwUpXcnfZKy35r8seWX0deAaVL6nxB4iYGli5JLDzpZth3GFS3wQhNLW+jinLl01NWf/gt18ItB8208SHwql/aqzXFlD4kt1usR8Y+ztLI6OxDbUKhuoBZuF9OGfcSQdWm8hxKoSlyz9q+ScZ66U4yinzRVpNqSklry62l87W+jLwbUqzoZd4l4T26hJxb9nXUrK/K3Scd/V3fTX3sLwb/AMFPPDX7TXjBNA+GPwn8YajFG4k1PxObdE8K6XHIdqCW+kkAu55gGZI4UJXqetPGrH4vCS5qDqwppzvCTrVcMt5TdXk5lGLt7rlq0k9E1H8z4j8I6HB6VWpnscRL2i9hUdOcIYyGqVSmtIyhZW5VaPMlzuV24/emnaRDc2hvDEsUk0CPJAFIVHdQWAVcDec8ct3O8E18djJQnaVfmajy8uKgrtNP7ampJK/8SbimrWUZaRl8HOryS9knKXLK0qbfNGbTuvZt68/TdS00tqznLvSbW2M80i7hCTtVTllXaCdo+b5TwGJAJ9tu5cJ3gptShSlUham5qKoYmLdm5NJKyUvdhyr95rJSvY9mliIPDpcyhCVPVXtXpu2k1b2n7tO10+W8muZaNy/Mr9vj40WXw4+GnifUreTF5DpV5b6TbwBTNPqclsfs0JUOOdx3sC2VA9wi+/wvgqWJxEaFekuT9z7WnWnKm4Pntz0JJTbT91O+yVrWbU/Nx9f2OArOacpOLhTqNNSTVlPnhzRbklHklzRk+WXLGMrpy/zxvjTdajqPxF1/UtXle41HUtQub67mkbc0kl1cSTEtndgHzCu0nIAHIwQv9m8NyjDK8HTpXhGlHl5Iw5W+RcvK/wB7FySa3jFRmpXfK5QcvwHiBOGYcrpSaUU3dqKtaT5m2mnztNyjZy0uuWT97I8L2flaP4o1GYEeXpxt4V37TundBuwQd+1eScgrn2FezCvSjX1qwvy1JRlKlGpzt9ISbb51JN2T5WrOSivcPIVOUMPKfseZTtGpzPljThFxcZR5bczVpqNuVz2d7NHDWcbzsQiOz4wiIMtJIDkKOBnI25Xd3zngqrqU1PWMkotTlGLV0o3lL3oNtXTblCTvyqLVmtTFqLlJyuqzcfZpO0HJayrOLjFaJtx+HXVNpSZ/ud4b0P5VynQf/9L+Jr4oaa9j4nvVYCIGdtuzb904HCLkKdxyd2373ORxXNkeJ5sHShypKMLqUpVatlC/vOpJqVbn1i7tTSX2m/d9jiBezx7VFOEYRU1OLjKlT5eVN2btFp2jKM4c/JyQTkorl0/D7x3GlrF9okKQC7Vc5CrGwBES9Ml8NuxnnnHRn9yjiPZymvZqUZxheTcJtTkkuaVqc7qDkpRTVnGNvdhpDwqfs4zaUHUk4SqP2bXPGM4JyhLlUFKz1lelGdTmclay5GaOksPiCxddylpY4htClwTwHRWyCBnD8fMRlQASK4Gp4iTh7OEakr25aloynHW1Rppv2nJJqCeqklUcrLm2xVOU6NSnSw8KSqRvNxnzqFSmneVopczl7sruKTV2+Z2UtnxTDD/bN/b3rIkUMc14TEADczOiRxrt3eUgDDJBUsgXIZSQF7aloqnJzl7R01JU52as4ySVOMqftJOpJtO8oxkuZbK5zYVxnhKcak4ws4+zhVV487lpFNRi4QjDljyXm/tKyl7vj8iozSwxoIwD0HOSSOd20cDgHAI9R0rCNSVpur71V2hC7el3J8sI781203eyjdPmvyx2dCV4P3bvRtNON435XpGPvWvzRUk46Od+Wx9D/sv/ALQPjL9lX43eA/jL4NupotV8Iaxb3V/YkuIdW0iSRYtT0i5UmMSxXdoXXD7lVmR9pK4bw+Icnhn+VYjLq0adKcqMqmHlKKjKlWlzOlOWl25KVvd973tW1Zx9HKMyrZRjaWIi5ezk7VUnFJxcopKNVSbhJJe05k1aXKuf7R/o9fs5ftDeDP2hvhT4I+NXw21FdW8OeLtLtLya3EscsmiakYV/tLSLtI3IS7sbrzY5I3CvtVSVOQzfx9Vwk8sxWKy/HQeEq4evLDwo1ad5V1SbU6zT5ZOnKSbg5S1i4v3vil/QMaks0wOGqUlSlD2cqqxMG25RUW4zmtHKdvdndqXtL2cj6K1/wr4W+IumvpniG2gvrK6hAe1nhEkTiReQySKYyGz0w2OB6GlhvaZdXjUoqnQVTmkuVpSm6nNq3rJKSbbuorSz3OehOrh1D3kpU21Qkqbkqcnve3LJOUrcvLvzK9lofzi/tff8E3vBXhn4qa5Fosmo+FNJ8WySazot3pN7d2lk80u77TbSRWzwxo0UrAqi4yvJBzW+L4lx9CvSr4emquqX76MXTj7NxjPnTuo00rva95XbSaP7b8G6vCvHXDTyPHVsQ81wD5K8vbzhi17RJQaaquck7tr3bxjopJJzK/wF+HH7S3wC8OXng/w/8Sb3VfBWoXPnK+raHofizUdGBG1v7KvdeaSS2SVSAsbFwh5C8Zr7zJfFelhlBZll1Bw5eR/V8JSrb2tUppwcdIrVOSd18jzOOforVsVjXmHC/EWLjj3TkoUcXmWMw1KXtJX9lVi6tuWOrcnK73SV/e958R2n7Q/xF8MzeBJfiN4vPg67tZbHVtOkg0Tw1Z6nFMDv+3S6JAl1NCwJ3RRyRZC4BAFexjPGPKoT5OG8JWrYqUW+fEYCnQhT35kpvDuN7uzleWllHY+Lyj6HGLr16OYcY8S5bh6NOanVpZY8bjMTCz95UJVq04Sd7NTkktdnex5f8Ov+CdvwM+Hki63rGi2ni/xHrFwnlLcpNJHHcyOvl21jHcyzy3LFzgM5JwzE5J3V+XZtxTnWd1q1fMsXh8M01KjgcLDC0YyUr86Xs405SnOyftJOzcd4JSU/6d4d4S4O4ByjGrKstp4jD4TDueMzjMqNOri4qlFp3hUtSo3VpR5YqWlnzXsf0Ofszfs9eF/hX8KbTToPD1np2qatt1C6WC1gia2Z0xFbEIgIEMfy5OOQD82M1WXOusNNOVTCYmo1ejOXPCcXpGMZWcW5p9eVK923e5/CHitxn/rdxW8VhsRKeT4CM8JgaKUacKceZp1FTpJt80ra6xtbWSbR7LeWzaXZsgZSPmCMSyhAMYx1JHPL9cgYxxt+XxmHlHEV6dCLoy951MG5NxxEmublV04rmekbPaVuWNoyPzyUFXtduorb0+W8HF6J72XLFtt8yu0lq2eMeO/FFtpei3dzcyorQxMzMoBwNrGQt3IVQDgc4JwzZJrj9m6nPCg+WHJKDo1lU5qVW0rVaSipK7aajFPR+87u3L1UYcseZzlUirVFVX2NLqUlG0k7txUNGndvmTP5oP28fiLc/EfVbvT7S9kj0LSvtJjlXmCe8QODI+5izfdVOo2AnHODX3fDWAWFp4ef7yu3LWM5ylX5YTTb5lF3a5rLmu+a8XyqNjLMavLh5zcG3PmmpR5atKbVnL2sk04OTcnUknZWs07xifyMfG232/EHVlCkFp5Dlf8AVkeYcjOeAAM5L8cH5iV3f1lw9UUsqw/s+V8sIR9n7yqxSglFqXJS92cpXcFBxa5nGXKmj8N4lowWPbhz1JOgpupe/Kvf5XSajG1tJQk22vesqqszkpb4jw08ETHEt1HArbcLKgRvOdmDAsGkUKqHC7FGN25TXqKlCkpP3YuMdIaVJNN3XIpRnGCXOoc6lq5Nz5bSZ5Vaop0I3jH3ZLmjJR9+EYSULS5bOWsrRc4xXucs1J8scKxmgtlbMe6TyztOWU7scjIbIA5wVwP72AMNpVi6jpxTlKcHDZx9yO6uuWUZO3Lez5nFLlk73jySkp03zRvLl5bqTnZPSKUZ05K0Y3V1ZLWXPZNH+5VuPp+rf/HK5jY//9P+Qz9p3wuth4ouLiKJUt5Jm8oqMEJgEqyDBVRgbQ6846HB3fH8JY6p7JUE5XpwUavNOHuyblGLVR05Nyas5P2nu05K8nZ8v3nEuG9rSo4qnGMqKjKFTEU9rU/azmowdJRlztaUmoa8t1Lc+dtHuLiCzunjZUVI2iZHwTuc8AoeHYhd0Z5KdsAAr906/NTVOMKsuWKklGSVPlTilUXLTSUo6xmoqDnFScVJp83557Jxqtxk6bjFTknQ5XUsnG02rJ05JqUItuTcW4cnus7rTkSHRotXjUPd2mpWErzGT/VRuGyNvPJI3F0K7PuEHANXRhGheXMqrkoONP2MnUV6ipSXNG75UoyiqcoyfNGbUtZMrENt06b5ZKVqfOoyctI3mo1Pf5a6volzTfIuaKUY8uN42mlmurW5G5pZwzcMOIzjaGGTuBHGchfvBTx8ixSh7aUvbSSWtS8XCTpq7pybhTXJKe9+aSTlGUlzS5pdc6GHov2UYTm6SVoSnemuaF3KKSUYTcvfcXP4m/eSSZymkzafZa7Zz6xZHUrCN43vLJZ5LfzlzwnnRbmRSQD0I6qc5JXn0nGnac4N+/zpU4znCKtKHvQhHmst0r3s176RyvRydNuLUZWm4yiqXMrOKb5pXle2kvdT5bK01HN1q88/ULy6RDHBJLI8EXmM5ji3Hy49+OfLXau7hiq8gkjb0Oca1W/LUjHS0ZSptKLir3jJu7krcv2ea6aklzk1PfdJS524xajKSb9pPZtXcOTZWirqK3jJaH7Of8Ee/wDgpaf2O/HN18L/AIo313c/An4i6lbnUJHknm/4QvX5DFbwa/Yxh18uBwsa6jHGqhkAkOSg2/lniHwf/alOWeZXhIVcwwVCUK+Gi6bq4rDq/vpuMuepSVuS126d4paNS/Q+EOJamXyp5diazVGrKMcK6jgqWHlOX7yE3JPmhKLvZ3jeTa5UpRP7x/h74p0Xxjo2leIvDGtWesaBq9jb6lpOsWM6XdnqOnXUYlhu7aaMsJd6FdwyChypyw+X8BpQ9tRnSqTqOspOUoOg6c4zWipSUkrOm7pqLu3azjZM/WcV7GrUpujOnFShFtweje8klG8X1eqUnGVlJWtJfjV8J9N+LnhE6ZqES2+oWv7/AEvVEUC40++RcwXCtwzxvIoEsTlUP+0DlvnfY+ylPDV+blqKV5SV1rdQ5XaSlNp+9y8zVr6SacvoeC+Mc14JzzB5plM48jq0qeLoVYTXt6d0pwc5t2fLLm5nKydk+blvL829W+HXxc+HzT2Go+GJvEFiCVt9V0WdZzMiZEck1muGgfCgtGeC3IzgbvMqZfmeElOeFpzcKlueSTlTSTvblkpyUpWvzRUVF+87fAf3dw99ILgfOJ0KWcVcRleLdNKpCrh6laim7XcalNNJt7XWkV71rjPD8XxP1V/Isvh7qRaUqktxqLLp9sgJIV3DYbauM4HLY6D5VXnlUzHGVFQpe0+sKLS5YytOytZNppWVr3XLppdvml7ObeLvhvltOdXDcS0Me1Fzp4WjaVZyfxQbqOEYtLXlabXRuzPuL9n/APZzubfVbfxd45mGraxAyy2GnQh10rTMjMflBlK3Ey5wZtowRtBODXbhMpxtbEU1jozjOk48itzRclZucnywtNJ6xU9F71tUfyT4reN+K4rwdbKuGsQ8typ1P9tp0/exOMrRulGTejoODWz11XK1aR+l1tbta2CmaMoyKFWAfOOMBSCVXA6Hkbuwx92vuKsPZUYxxUHJQUYUK8Lp35E+/vOOlnyJ7aq5/NClLEVITjHlU9ZJ3jFR+1yyje7eqlq+a+lrM8N+IniKzsIJC2yGZA6qhbCvkHv2zzwQoHUnnbXyuZqVqkKz9s5KDoYiHu1Kc1tCTbjaKT96/KpXs4aPl9PC0qycrvli1GzXLbkhK6XM17qTd3HW22r1PyY/aS+Mk+r+b4Z0G7IlmLR6jNAC6whtyfZ1IbLMxLbsMAoHOAN1ZZLhppVKtdS5ouNWOKc+SporRvDl/ea6U7a80rKcneMfYqUXTlSqc1SnBSXs5v8Ag15pJxd1KV046XcdFLW8nyR/IL486SuleGb55Isuiy+VCQXM7spllYqclsJueQBvlHVj0r7zLcKsRjIScmo+6/bRlBt2k+WM4r304SSb9pF82+t7nn4zShi5R9jSpuTv7SVT2LjF+9aEZc8mrJqUlD95Zq17R/lf/aEgnh8c3k8kIi/tKSW42KOUiaY+XGh2hSgU5ymc/dJ4Vq/pvhapT/suDhUf7tyi5W1vCLg7Reqm3Z8jUlFfDJNvl/COIoS+uqE2k5rXm91Q1tTldTd4y5lKKtpurWPHrx3t7WG2IwI495JO5dzHgYBYBuTgALt6k8YX3qdPm5Vz2UnOUV7sZJ3upSnN6x0ilfmm0rxtbml5VV1IylCcoe0paW2jeKb9k5Xs1HmUrXja95e/L3cwkAYyBuCgnA47kBc+33i4J6gg4rSjGcrtJS5ZWtJyalF3hfmSTcOZ6RppXWjmloYSfPKKbUf5knz2UHyv3HJ3SUZW2fwRvZxR/ue1x3X8q/8AJv8A5Ybn/9T+XP4+aR/wkGix6miRSyrDNLIx+d965LNlMglgQo42rkY2kbl/MMqrSwWOjpVo0qtqapqLhGUOZOMpUrtxSc+a3NBLknFKabcf1jMY/WcBXowjGCpuSs4uXLOUudT5YRknGcr2alKGtTkl7rR8Im1e0t3tmcpJJKjNGpysmFbBz8uxl3Y+51JLA4+b9IWIlVmnDkUV7rdWLhPmk1J31blG65leaTXs1FWU+T8znh+WUoc7aUrez5k2nGyioKUmqTV5xStzxX20oqB01ut1b6OY9wAuGSFlwWOA6yMccjdFjkkM3OB0+T2KNVNculNOnPmqqo41OVJ2sk/ZuNa7qUrVN1dOM2+bzXWvUqQ5FCUfatw9nKMqzitbSp1GkozipU/dXtYQT5EvflleIb032oAbMGCyhg+XlU2KFUhy3BYneMjaDwAq7d3FKd6kOfmqcy5bt6wTvyNqLdOouVxi9YvkUE25Nyj6HKqipxUVVvSU6qdSa96MbWSleLc4Wc+eMWkr80E7GHoSwTtrVjdy+UZ7UyJctF5jxtZ/OI1G8MPMPBkUn5eMDg0Rp3hTkoWm3ywT55N8/vJOFpRpx0aabfK1yrVNmVOlSnCrHmjTqL31JS91qMbSpyXM1yWtNtQ+KKV1qzmrsMq7ySyNu25IbkddrEgcsP8AaJPI25xTjzc0eXlk0nLmV1d8zfvcnlPmTaaavHSyUscVCNNUeWTnf3o25G4JRgrJrlbVTmslyytZyi173NestPvZdG1DUYbbz7O2lihupFRjJbmTBilyCRGrMCp3HaDgcMRSjF+1dNStOK5oqM01yWd4tO8pKPMn8PvuVtrSk3TkqNOo7uLkuR80ouErWleMJNNyvs7xWt+WSSP7ef8AgiZ8W9Z0b9kj4b22t6jcaposWp6tZQm7upLibT4oL128q1LeYRApY4iYKiDIAwAjfyXx3OOWcV5tUoqVOWIxtKLpRh7ONnSjJtJcvLdvSy1ctUrvm/oXh2P1nhvCVJVJupKhHka1lpLVtyd2k1q3zKKvyfDzS/pd8IX1lrtok1vMZbW7iSWFyEKt3JHOFwMcAnrzkZVfJo08PiVGStCq9YOcqkrNye8E6l5ac1k1ZL3bXRljJ4inKUHGKd3JzcZ80I8uiTUOXXV6qz3d9OXpL7wPpOqx4e33lCfNdUVt3s+0AnoTnGfccKv02Fwv1eMFJLWUWpyjNwcLPmjDm0ktbe8+ZX1TvY5IZnicPGKdevCKi7PnSlHmb1i+STk3a2iemz2J/D/ws8NWMpkFha+YCHDFNxOSCeG6HJ7g56HOBt9ivkOW1K1KtgbfWpXlUU5v3WlrZSUU29LLntZaWSalyYrETryVRWk21KMlrq1vOSkuZbuV9NVZvY9x0bQ9NtIh5VrHEE25C4CMRtx3UKeMDjHOQB0bCr9W9pGjjqNG8FLlqcqunquZN8l30lFtJ2tdGNOpUldt8spbR96zaVur0u22rNLS2lzk/iB4m0rw/p93dXEojS1RmdmdRjaucZO3OzGBzxjHHVvjs2r4zA1KtLDOOJw1WclFTpqVk1eUVap7kb6prmV1L3krKXbg4VEpcybi/ec0m5p32bvKNm2+Zpq17atLl/GP48/HXUvFWr3+g+FZJDbSO0U2pRzD90jZV0hP3nYovBAATPGfmC/M4dXdScakpVKz96jUjHzd0vfSSvZOMFKS1TdrS+wweGq0oxnJQqxahGynKU/eavJKM7qKaV9Unfqm0fKx0SCyhuZHje4lK+ZcSs3m3E2eBGhbku7Mo3Z3DqNuM169KDqQhKn7OhU/dp0ZQTp3UU2oNaQ9pa1+SUEn13HXqOvGMfcqRp+5UpezXNB8rla8XF6bxfLqr/FzNx+Qfj3os0nhnxA0zq9xJp13CIiyFrW3HSKI56PEfLZ92/CEeYDgN72WqUcTCsovCezm1h4NTlTqzqxvUXIrc0oc8lHnd1rJ2i3y+RiYU62ElSUZVKclaUJx0n+8v+6jJqLVN+7dO0lo1Fu5/LT+1tosUPxFgiTKokPl8ZKoEOSAnyHADAE9hg8ZxX9CcH1ZrATc/ZzlTquMYxfLUkrQ5W3+8UrXb2V1zKUVdI/IOJMHSp42mmpuorRjCbSnGmrPljCdSNScLpRV3J82kLJycfkOcNd3zqm6VmcRIMZzgbB37AY7cDIwcFvtYtxhZuKkqakmmpq+rjF+6n7u0ErtO6aalePylSvKtVnNQbcrcrlZPm5Yp2vZOSXu25qbi370mvfjqyaU0Js0nVo3kcO6lD8sabgxOTjDFSAQGTjhs7RXRGdJxhCFSlVU7wlJVKXKpaOHNZXi3zPljPkkpO8lGLkTKPK1BNcikpc/KuZRUbyhJSjFybldezipSTcWlKy5f9x6uLkf8r/8DiM//9X+c6x8Mv4n8G3sE9vcGaC3eONVjLHftcNGuMsCdzghgxBXByQ238gzHF+zxvtOf2NOhU/fOrOMKsYwnZVFzNQfMkoSqRjzLmu7R+H9hyqli1gowxDUqVWUYQhSSrV4xcLuE5ThGXs5TSpzjVcJU1reLSZ+d3ivRotG8SXGm3a/ZjHeJtkYFTCUflFiBIUg8HcFbpjCnan6Ll1WWLwlKvTjZSpRUVUThGVOdPlc6jk7u8k7Nyd4yle798+EzPBwpZhXounGMozjJTk5QlyxaSbSlJQUFd+0lB2a1UrSlHqZNIlv7C+ks7ZbltOskvpJwwjR4SwMiQRy+W07bsdFdyjZB4VV9eFJwo4dObnH2fNFJxqShzc0PgtFQ5IwvJRcejau25fMYvkoVqCm5ypQrKmo0mqtnValO9OMYpQpzppKpKMXyvm5+aScfM9Ns1vp7+KWNne9/d2L/LHGGDDJc5K/eUDBYL83JycUVKio1FTnyxcb8ypcztKfM+VcyVopO8VZ8zjpaN4nqSw1XEuomvZVFKDpShaCqQ5kleUpRi5XhLns1KSu5KbceWbwTeL4T8XLNqlpDJMgvNMeK5t0njIv4GtVmVZVaNniMhaN1HGAwI21UZTcYyp8zjRkpKcasXZ05dLqMZK6bal7sZ2Si7pnI6XvVMPVoOEpRcFaMJ2pptQdKV01K9pVNYS00k5JnHarbNFdXekkRrPZySwHyR5izokrOJvMXK7gGw56fKQSQuG1Tu1U5dYpyjJqMZpTXPGE1Gbi20lJSjFp05W5VexnFS9+jBJS9mo1E6PIuSEeZTTTm2o2XPpNcjctJXGaDr91oLanaxbDZ6xaPpt7DN80bQyEZlVQVQTRH50dlO1uRjbhqftPj53z01ZaNOT6aa8yveEYp/Dyp3SEpWTUau7jrDkb5k/tK3K0laLTTi1K9k/dP7Jv+CT3h6bRP2QPAsMirO1zquq3kAVl3fZZZEeKXgbM/MDnIw2dxHNfyd4gwqY7iHH4ujNujTxSpzvNKCqRhCEmoq8ppO6lFKc/duktj9/4dw8qGUZcqtFylVw9GcdlKHNJtXhCyc037skowW7u3737lfCD4k33g+eGzvZJZ9G3qUExzLau5G4o+CPLbncACPQNgGvjaVd4StCUZcsFJSlSp80nNxdpSSvNws1pD3Pd952vyn0OLbrQ9nTg5SXvJ6wgrbRvK7btaXWK95cu3L90aD8QdGvoftEOoKgkXzEh84EOT2ZdvQd92B6ZHC/oWEzXBYvDOdVxgoq0XL+JCfWSV+bTupRb3stYy+dxGW1pu86a9pKNuVVI6RW1lry7u8rcz6xVmXbr4kWNjOGlnhiwRuKTKFlHfdIwURqo7dT2AwS3n43FxwkPrODr1asbK9O6crtdIyXuqVru7Xd7rmVDK8TCV+WfJypNOV0m9l7sJNpre/XtdMzdb/aC8L6JYSySavBA0a7mU3CPksOFjAzvyVwe/fHG1uCfEuHxeDVPF2VSL5EpRhDlvZfvHdNpe9LTST7WTjtLK6tRpSpxhbdr3nJNNp2lFJNO7ak2lZXavyn51/HT49eJPiLdTaLpFzJp/h2Unz5cP592H6+UVyfL4+Yk99oAxXj8+Jptzw9WE6W6kqlOUpOz5VyzvyOKs3TtZ7yvqj1aGBqYVQtTdWPs379PXkXPeXW11D3rcu6bUZNe7852Ph2ffGMokLOMlfmdsD70hJUnJzuXcoJ5OcjbyTq0HP8A2hexre7OFVRcrwb5vfirqmmleFleLaTu/i7qlXDxwzgpuFVTc4RdOSaWii7xhFxcmuRQ5Got31T97X1XShHHEdjKIzuJG7aVU8Z5wQD83y7iDgHopr16eGxPuqEZYuNRclOpSUfaQ5ld296DTfMot3tGOto2R51SKp8qlHlbjDkq4e853vJJVb2Vpuzk1yuK6xvJnxz8bbGKW2vg6K8c9vcw5UbVAlR0JKDAydrbRs+Vueck162B54+7zy92or0avJNQUbKPvupPR3XI+aKdnJpXRyYr2s6CUlGsowty83NUjFX1V9bJ3s1bmlK3MkrH8nf7ZOnXWhfFK/0+Znme0gna3mdV3NaTkNF6EukZMe5j0wOMLX73wjCn/Z0bRnQg6lOS96Tgp8nJzOTlNypySi4tOUE4u8U3Jn49xDOTrtP2jqJuyqQcp00m0+X2iXO5JR92M5xUfetzJnyX4ahYNK67lnugLYOseTHFMQjMg7ZXjIKsdxywBbb9vUlTjUo+zcbRUpfxFeSir6XpxtU51zO8oL3bScUfM06TqWgnKbrRu1p7tOMvd0qar3nrL4rXU4x5kzWvv+Pi6unkLpFILGCUAgbItofYASOVxjAwo3HcCNqpQahNxopuMKcpxapQdP3FLl5eeTjLmk/aWes2204vmMa1Kp7R1ElKnTlL2kowhSjGVO0nFcqam6z+NytOTcWpe9yn+35x/fP/AI9SHdfyr/yb/wCWH//W/KP/AIQH+x7aRkgkGP3bojHnD4kkkTYMkKD1PCqxKAYr+fMVWhjcLLkXvzkvaSpRpRhKhWjGalTdSXM6blaLfva7TmleX9B4HLlhatarCrUULPnjzKdFKbSc3TvNJ8y5YRg7R9+XLC7lP8kv2svCw8P/ABOSeJGNvcWcGpeemxln82d4eBs2h1ACuQGDEgjHKr+ncLyjRyyFGokk4wpRpzjL2vLG+kXTsnTUtG1yuFpJX57n5rxLh/8Ahb9t7NuNNQjOT1koTk+WcaclUkqcY6NXlbmcablKLZ4NLq9zM8Jt1aJreX7OtutyvkzxPnzjICRtyeSuVRW4CbQxr6ykveo00684uKnGahUvKPPF2j9pSSTjzuzcLWtJQnL5itThXU3Kg6KlelWjGTXLSjeU2naq4qFqPLJa6Sp2XLEzIbNjrP2CN9g2/aIHLqFB6v5Y4V1dlPI3DPJPGFjEuTinGEVKXL7VU5Np2UnZz5b0+SMn7nJotLyTcYmEnFVVSqy9nKlJU4Ti7KnLkip0/elVSjVhHmunyqU+aN5tSO4v/BfiaTRhdXmjXsqPJ5yNDp008uAm/wC0i5jDSCPYNwVfkU9cKWVeJYmrCnJXlGNJK3MpRhVi1bla5UrNr3puPOoxTTk2lL06kYToOq3aFPmhzQUVOGmmsrVHbmu40XJKFle04xPI7S21nUdfhHh3S7vVb5JFs7bTrSwe9nkwzJ5ElskUjMrg/MX3/NgF8ivUliMNhqEK2LxFOhCFPm5+dpNJWvJyfK5SlaDsumn93zFh8RUryngsPPExu4RVKPNNU2o03OSg9I1LtXaUbJyi0n7v6o/BX/gmV4p+Kv8Awi3irx1Z6r4A0yW0gm1zw/Paxx6hdOjiRZbPgLDDexOAyMGeMK3TI2/mWf8AiHDAqdDLlHE1K0qklXhGpNxV3H2nJ7SbU47Q5uW+janax9hlHBlR4rB18wpuFGSp1alNWh7OTjFQhVjOElJrlk3yuCa95JKXNL+rL9n74SaR8Kvhh4S8HeHrJbDS9D0+O3toR94QKNxeUktl2OGZi3JPfNfieJrxxUauIxPPGpOrUr/vpRVScptKfNG6SqN83OlzOK1S1cD9gpqFOrThTg4xp8tNK8acIwiuVwXuRcpcqd3rHks9H70vpnTbI+RkAH0G7dkH72VAz37jsAM4G7zJfVpq7kqTvLWFJtudrKUrudnytJ2U7SWtmzrlS5dXNyi5vkcVJ2T+G/vOy5Wr3i4trTqo513Z6vZTGbSL/ULKQk7tl1MLc55O2N2CgZPG3HPTJGaJUJqPuSUFf3ZXV5KS+Lmimo6aSi1borXIlCUW5RspxjyxnNOTi5O3KuWN7vtK0YvvdKODqF34wuCbe91XVpVRQRmV2VnHRc4JDYOAcjjAGcivOrYXHOGk0+aT2k4pLpzOL5XFpLRdeqavHanOpCTpT5OeUU1TivZyfSV5Xcm7Xau0t1rb3ufh0e61CTypRPPMX3EzeY0SFRwCrkgHnGeMdQvelTpRlCMcXRlVTko8zp3TattJRU9G1PmafMla6+KOyjRkmnFQtopWa5VO/vaqLWqaemu7src3V2nhS0gMIJE88h/1ZTCRg5/1eW6Z5Khh6jOS691PDUqjSw9acOaF6d5ynGcopRcW3GL105oybu1ye7f3eanS00q2dNaxjKPLyfZSnFwaTVm1ySbsndpHZR+FBbrCn2cDzWyQyn5AcYwVUjcQG4Y8dAT8zN6FCGJpJyrYejinBNKW8mktJOPu8tnfRyTvZqTaSPDr12pS9p7O0JWvC851FyyknLnknzJ25dIaN2bXLGXDeLLH7MjxK8aKjPH5OAA/y8ZON+5Sd20ccAEDcSvoxp0nVcoKvgqyp3p+97ik3p7N1KqjCNS3vzupLX4muYTrQpPmi1Kbbhy1VFPZylO6tdc0YK3Ru+kIqEfib4iJa61/a9j9lmgTT5RDPdyonlyOUZ8QEkBgvytx03NjGAV1oUKtDEuHtIY2UnTTatCcVUbhBR251NqS1na2sbcyhPKtiqTaqThTgnGKi8P7tWnyptz9nKadmpXlf3ZqdrK8D+R79tXXB4p+OXxKe1Ky6doF/HoNu6KHHmWcIEvOecOHDA9uNxyAv9A5Bh4Zdg8BTqQUZ1aFOc4+05PZtXaUpWd05JKzhHm7ppyn+OZniKmMji6iSqKlW9kote0rVPZzkoTqT5asoJSioytKKSekopzR8r6JItmmnXLoqxG3knO/kyeXG2wleefMZSSCWx8y7cg19k6S5Yp+0lOE9akYJOChLn9h8SbUoRlNKSSfLqpRi4nhRrOq7qEYexhebhZPkqWTdS83JNS1uqcU3R5oyluMu7Zo0t7VgWjWze7kYybcyzzFZHGdxJIHDHI2/MOmadR6KpSTdSpGUpP2UuZOUpKE6nKrXpe6uWUXKUna8G7yzhCKrVKqhyJ0o05+1lGM5VVNSlON/aRm6k7xv8UFb3W5Nn+3v8v+1/47Ue9/e/8AJjGz7r74n//X+TfFOi5U3XlbIriJtxjVXJ+T/WgrgbVAI2lEznJYAHd/OWWVqUKMY04UFF+woQbak7uHNKDhKSkrNN1pKSk7JR9pflj/AEFiqs4Scpxjhoxq8nuOrUjVm5NSkpcznanPljaTScZcqldcx+Uf7ZvgOG5tNO8SRQNNFZpPoVxIoQOv2gi7s5GD4IXzY2jVgCQXA+T7rffZVX9jKLqV4xVJe9FuM48tSVuSnyL4b6VIvllOV3eTiuX5DPKUlVqTlNVsRVilTimqfuRTcml+7tGMLx/d88ouPM6kE7y/KXW/ItdUmSOSdPM2RuGGFZxtEvlgYPXeGCj5j6bRX6Tl9dezoTjyXfLJRp+9OFOSkoRceSnCV0k02opbO7bcfzPMKkY5glT9pKk3Uja84vlm3yqUI0/eTkoN/wDPxOUakpxTnLt9M8N6n4hdp/C+j6zrN7o0Au7mGws7i9NtpMQVLm4lEKuVWIyb3fbsjX53KgKa7cVicPQU44iNKjHVytCzcnB2Vb2VlGN+ZLlu5J3Sja0eejhcXPEc9KnH2eNnGE51ptezTfsqM4v2iak3Fx1cGuVOMm1KR/QH+xL+wj8ZkuPDF38Z5JvC/hrxt4fh1rwJcTXdvq1v4js7pAY9N+0kSW1hcywni1fLyfwbiuxfhsw47pYLDzhldHD4vl9zldCUnTjK83JyqpNqErezalOK9nZ8kHKJ9Zg+HFOdWdbG1MTUqSlGvheefsnGpJJuMdJQlBpS5naNpNwTVkfoTff8E7PBXwY1T/hYXwj8M6fa+I1mW98U6bc20NxbeJbMyiWZbIzxvJpmoQld6NbMqOVAMZQ4r8czjPM4z6FRV8HUhGXtVFqdOMEoPmnGEKT5dHKUY+7Si5W5eW3NL7rJ4UMrmqVPD1nR9m4uT5EqElHllOylz1FLlgvfk+WOk0uVo+tvC/hzTta0vSL+wjEdnPbwTmBoY1nimdsTW8zbdpaGVGj+QLkKAy5C18xhsOoVVL2EouUVadr1JyV3PT2ineLdrSsn8WsXKUvfj7SE6icnJxbVOpySd1KK5XyVHFyalKz5VzLs4qx9FXdhFp1rYwqfldUG1FKhFKrx8m7GeTtDLnocLzXPiMLiqscSqdKVJuUpSlLljsnem6kk4Wdt7RctEnBpylzUq+IVVXUm3Jp81W+zfK37zs5tPlTTS5UrxTOt0Wy+0xsEKnaoGHRQWOM4XO0rhcFccknJxgq3mLCYiCpxkoxml7VJXlFK3vO/tJuSdveu2vdi43bjI92nOtzKtNSk3ZS5n70mlK6vHmcXorbX05XaUVG3caNOULqW2BwyMTxtXrxlvXDY2/QDJolTxcYt+zU204zpK8ItfFG/xO/VRsvVXaj2+3re8oU1CElFSak3J6Je7y9Fq5OVne6eycqogRjiQuMnjAyCw43EjJAPoD9M/wAWbpZhSpWVJNJxc0pylaMrycF7ybe3LBRmr6NK3vROeIpScY6zta6kqlRR7crl8NrvS1+rTVi/ZaIC6SCEiKQ/Oy87uhJIwDuORhsEHpgZIp+1xXJD/ZatSd2oSbWnNJRcZRk5R91NtXlf+8tDSWLp04xjWUpTd3yyv7zVmua0292o8qu0ne75WjuLPwnaPiZ42UKu5fNjV0BHXauAQRz7+mOVr3cNCjRp/vcPVpVnapaLnGTha920pJpdHGFvdvrry+Ti8zjCU5RhKlGUvZtxlpJPeKi7QV22neMrS2X2QvLYIrLFjcoIVcMjFcHKj5iOOcZHBzjPBrpUcNGWlXFUY1IpqTXtE5J6ualrKN+X4ZJK6be6lxUqtOSdSLlGc5zjHn5W5Sj7ySbjZpNtaKNnZOLS93xPxNpCyzSKyJLJLulRZcxNExAJcyN1l5G0Kc84P9yuvD8/tJf7TCpGcOVKSoyg4xfSS5mqcXdTU1aWrvL3XHKOLnTb5pRq2hGDhXUHKMlNtNLnnG0Ve0JqLabm7JSlL5A+L+nRab4Y1q+2iKS0tb1127Wfz1gfy3BVVOeSCw5DDoQQV9HDqU6vLWhh3TcqcPaRTpyWt4Sc5uzSXJyylHlcXHl5ryOHGVHOM2qMFJ026ioVIuapJKfPyf8ALuEIpXeltE0r3l/GL8SfD11rNh458a3UM/maz488RXDXLlVEsMeoGJEiAKF2RQTIRvVQwHGcL+04PMb49YWE41IUMFRg4Rpu8Zwg/aKt7sotpSTXwue7lGUW5fF0ctVHK8Q3UkpVnQlR9peXNG9Wai4qlTfI1GU5e/y25rp8s4y+eL3TLzTbCFLkShkDrEvKYhuk3xjA2N8wEh6EBuAg4r6PD4qMpupeMZxcIcqtUk3FNe0hH3oqEJyhFSbTnup+4nH5zFYOrhKLsqlOaqck+WXO+SolLlspOUouE5yTny8vJam2knKxPYCe2vJGeNfJSxtc/d2obdNoGNpf+IHbtD7CSPuheiNSrTnKlFycqVFSlGVR8snKfKlNNVVG8tdHyxlJWtd83JVTnTaUI88ZUl7OpDmvU0nd6VYucqMpwcnOMoycFKbuj/bfwv8AeFaHHeP8n4n/0PnnT7vS/EOmpaLJc3TkGOJtPhe8uHJ3cQw9ZOCeVmDt8wbod34Bg8izHE+whQwFarGKhVnTpxnq3TVP2L9jTbpz54qMbRjZp6NuLP3nF4jLaNKFWeZYaMIuSjG8K0IxpxclCahO8Kkoe8rU5OzctZOKj4LJ+xj+0p+1p4qvvhh8DvhV4m8Xh1X+19Q1XTp9C0DSVaTIn1HXNSVLOG4tnHmhEkZ1CgDcoWvvMNkeYZY/a5hThljqXlhlU9+UopWinRfsoKLScYc0ozUm5KS53I+MxuYYfFwrSjiqToQqK1SjVw9RSndtywsYRcm03ZxVoPkWzUPZUvhX/wAEYPhz8APjHp3ij/gpzf8AifSvhEmt3Gm31l8LDNqOkQXkM8Udm/iTxBZRTzW+kA5XU4bSNLnypBcpJ5W416c89eDdLDwq1FD2crRgoxxMpKPInDk9pepzS5o8yV4RvHmjdy8iGV0MfiaMqdJe2rfvqbrJwoT5NLLmnJzlOfLGb1jTqp86SlKZ/Vjof7IP7AN/8JtD8K/BD4PfDew+FmqaNd6XpfibwJsl1W6sdTspIDeXXiy2lbUrh7qExvdRXc5ZZtokiG0pXzVfOqtbE08QqrnQhUck02sXOU378asajtebhZJ8s1rFQu0dVbL/AKrUnDE0sVSxUaLlerTU6EIJppKnO/PTdRqdOSlL3leNk05fDfwX+EPiax+GnjP9nzWbu11jUfgJ48vvDnhBr+W40vxBaeEZpW1bwLqul6mu+O8eKyZbWWWVYyXVo2Y5yvzGYYmNCdfDOMbVJ0pUlUdlSo1Hzc8dZ8rhJT5k4qEZJK73l9BgMbRxKw+KjLmrVMNyV5UZS5fa0Z8kqLiutRKklyuK2UtE2fQPw98T2/ifQtY0vxrbHQ/HXhRp9K8QaNfqkeoSG1TFrq0LLvjuLbUbXy5/OgLISxDg4avFrVqcKvs4xjUcJQVOo5RSm3G/NyPWLaUovminG1lJKSmerKsq1Vyp05vD1KSqRk3zU6VRtt0Z0WlKnNWvyR91p2jNqVjkPAfguDRnu5j/AMet3qupXcEDfKiLcTFl8gMoxGvLbQFySTgZ3Nx0a85fWFKlPn9tFKUYc8ItWlaXLJN2XLJ2TTeqcrI7pY+crU0ppw5FzS5EtO8VZe9flVmkmrazdz0vUrcbUQQxNHnJJH8IGMDGQCT6d+uM4rKUa2IU6cY1ZtQlzS5ILTmu953ajFWTfNJR1SWnNksQ3KcbuDk5Kz9pyqVRt+8vaQSm1e0Y83Jdyd27EFjLFbOrhtkccmHRQ27BPA43fKRkZHzNnnI4rwqscRCc6kVUnOSTg48kYtOKhNvTmahJJNTUeX7LvK0fWw9erKDSo80oNxXs3ZTcPtJ81lFtp6pdfeabUe8W3gvoUa2OVcqAT1yckEk7dpHPQZJwADgVh7LNXFOKdNfH7KU7S3s7qNOUEpO+9WS68qs2bwq148inT5UlzX5uWXn73LL3V110VvcTvIrNo8kcycKeq8AMc8E55yfoTgDgbcVvDB5q4SUqtKM/iqWqOygn7usXTumtNFKTei/u1PGzUVyRjzLmcXGavzXa5nPlgnG32ffa6J2aOl0m2zG2SJM/JtZQFUkBd2QXI9eFX0443ehhcNXpxSlUoRspNzspSSSbsoycU+/vt6Rsk3aUfHxmYSclTvHmhFr2vNdK61U3GMfdTtvHlS2s01LoHiOn2+6aWIOD+5ZicLkdAoDZxuOC3PK8txt9ChSxGJfNUx0IQhGUnanJ86eiV+Wm7WTfJCVtPtXsedWxUq7pwi1bl1lCVScG1GShG17R+Hecovm6u6UuL1qbdGWRFLuGJkwFLE/L8owSoI6k42jkBsNVSpqM1D+0aLjBLl5KMqsfd5ZNezlKTi4p2a52pTSfLZwNKOKcYxoqVNuL0vGzqaXUnZO7vLVqpFR5b31izy/W1kCANApKRkqNrO4YjO4ELyCOdwYDr8x+6vVTdKLvTxUJe1UNVQjFTcrtUpRuk3GKilH3LaOSd2zSk4RjVhGXs7xc+XlbhKU1dWlFzhdRu/ikndptNJQ+SfjXpr3HhrxBvyqRaNqt08Ug3K8iWc0gVu3UAEH5zycngL0YaEqlSjyypy5KkIRlDD8q9ypBe7CrCDkle8qkny7OKjfmOCdqsJybptVYScrwtHkcYNz05Pi0tFSWr5nFWlA/mS+Nvwxt7rwF8F/AWjWayat4/wBb1XUbyW0Rmlhs43uNQvnj28hZCUWSRidiEnqw2/ZZVV+qrH5hWnH6xUlUpRSSmoupVhCXNPV1JRXPy024qEYTdpJM4swcHDDUqEk5YRe2rOK5VJyppQi6jp8tO/PLm5JQtFW96TsfCX7RnhWPw1FpBst7FLSDT74NFh47mL5DDKZMfvEEJGTs3A55yDX1vD8vbYd1a6UqqlOdo3U04TaXIqa5vZWftVOUrw0gotRtH5nOYp0vaKSjKH7y1Og05uoo2hUlPnnzqTlGc1KySjFRlFuZ8zahfssMe5kkNzFazEoSVZoAYdrKPlDIMAhTxyTuXivqueNRSgo+zdSyU+aCmqivvF+0cVUu7qpyp3jZRfNE+eSanTqc9NXnLESrW5W/a+4lFKpUg+RwU5RlOKb5mn1h/t05X+5+tbnBp/O//Jj/0f1t/be+CXgr4mfs2/FPxB4c0zTPg58QPgV4KuL7R/Gfws0PSfDb65dfZ5nkOq6Ta2scHlMtoEjQXE0sJleRZ2I2t95llWnlOLwKweFwtKdeUq05exg/gqcsI2mptqMrVLylJuavppy/kX+1yx2X4mePxdXD5hiYUK2X1K1SWFcJzhT5pe8put7l3VjKnJxbhdJcx+LX/BKb/gpp+0V8NfA2gfCrUr6x8c6X4m+IWq2l/rWvPcRa/wCWss1uqi+hLmSPEYdopVcZOFKhQa+v4g4dy/jXhpcRZtFrHV6sqElh1GlCMcKqsIOCilyuUIJaKy31bZ9hk+fTwGeVMrpYSlPDYWCVCNaXOoOtCNaT+BN2UuRNy5m1zylJym5/0b+J49I+JHh64l1TRbIx6rcWjavY6kia3pt/JJaMyXJtLuKLybuFP3SzxyFnUDzAQAq/yXmuSxpVlUhWSco1OZuinKSoVVSXNL2kVJzTfNJwckm0n7zP1fKM6eJxdLDV8JRlTpVKzpuDcJQs3eMWou0JPeDWiuk03zHwbL4Ntfg3J4zu/hFfXnw8/syf+1r3SNDct4T1uVXlmlW+8MXbT2Vu85QiSbTXsj85Plk5r5iGHhNYn2d6M5OMpVIpOfwxk+W/MlJ6XlJTbceZ3duX7+N61SMcU1iqMKjcKdaPv0m4U4tUasWnTh77lycktVo5JWjwn7KPx81z46/tM+PNQ1DRrDw/9s+EGj3erWdlM97ZX+paXrt9Zw3yRSw2z2rtCu0oJpsAKokKrsas1ybD1KWDnOpVlOm50+dznzyvUvCUrTUPccb8vJKLvpy7G2Gy/DUk1TjyqvOGLTu+eCrUeaVJz150mo+9ywvu4PTl+wfG/huw/trUNeSG3TVreLSm+0iAkSwNJHBJayoZsvE8UxT5mYrtXHQV5ksupOXO5PmjRnOLtt7OUlru5Odm580pRd3aMdzqhQdOmqcKkoxcajqOKUZVHyt3k9fe9x+8tubZWsVGsYY28tUQJC7NCuz/AFe7YW/iIOd5wMKFwvXBCqdBRgq3NJynBNpNxWqm1rfnunrfn12a3PJlN05uas5SahdpaXi389Y630beijuY2p3KxTtbiIAOc7422MD3xlHByfbgcDgCvm8ZjJ4b2VGMVNylyc8trc2nufC7J2VrbX0u4nSsTOk8P7tOSqL2iSi4OF7+6mmrrRuTlGUm5XurJHJ30sdpMEVHbzJgHJl27sbGGQIyP4j0GM4POPm4Ic+LjRqNwpxdJ1FTjTVk3KaaTvflfLqr3d9WrHpYStV9vOKlFQg0mlHVxnZuKd9FaXLqpXWr5rs7Pw5qNvJGW+wkOs4RW+1NgNk/Oy+Uqsc84PoORgGt8Nh/aKpCdav7OM3FQpz5F7rtulzW02s7dL6nRiKbcakvaT5Kc/Zqldcri1B/FbnT97SzsrXSV2o9W9/KzqoWNUZckBEJGFJO1tgxnHJ55Oe2K9SeFoUpSvGpUSjSS5607rnl3TTdnrr98VZHjTqKjiJ0ZqdVcra/eOCVo81uWMZcydrWbl3ure9s6UryI3luIUAIKCNGDE7tzE4Ukn6/lkV5mIlSoVKvLRg5WXvOVSzTm4pOHNZpXulda99DWXs/YKsqcfeo+05G27SvJW5tLxtFe7yr/FGzR011p+ba0Msiy+ftiO6EfKCOCP3nUcd+cdFyd3r4OKlD2sadCH7ic+X2Tldxlre9Tqnb3dt/eslHxo41utQo06ap83tqnMmt4wbs4xhGMvi+KXvXV1b4Zcjc6SZrmW3a5+VFG1jCDj5dwOPMXkA4yMdM44BXtp4WdRVJRqQpez6Qw8E5X1fvcya3Vk+ZX1fNe0O5ucakaUZuPtKNStz3d42fK4Ru3pJtttvXayV2ctqulbbOWZpkZzvUEW+wgRlQpJEpycE8np2C9K5I4V01Koq9T91CV42glLlpKq7WjGUE5dpS7u92jSrzYagpczqRnFR5PeglfminpK/NFc1m3KPvfDpc+TPifZ2tzpep2t3GZ476G4spSG2OEmilhdlbDYyCTtXb/dGPvV6GF5PdrSh7R0/Y1JRqylUVSMqkbwve6vZXk5Se6SSdpcWIrQoU5uNG6q0JXTqTVmqMpKSs1d3Wt073slBJRPwU8DafZS/Hv4HaVfQtf23hzQfjNp9qs7KQ40hLeKKYhonKSSROyv8AM4BJYE5Ir6fHYdUcpp16DhR9pmyhGMKafJGtRqVGnKU25cvNyK3L7qV7tJk5fRhjMfVjVjHkeBoy5Epe66kKzlyvnTSccOoNNvRq1rI/Nn/goRYWmieJPEmi2MWwL4oN+90zAtJDc2FrLFaCHbtjW2aRgJlbfKGbco3YX3uHKkqVRL4uengpU27RdJV4SjKKUbRlblvdxim3e3NeUvHzur7OnTpShCpKjh6lVVOWK1WJnTajGUZqMnq3Jyno+VJH51aboMOolbHzmt9sOoyiZY1d90MH2gAqSqkMQUIJ4UnGMLu+qxGNeGjUrOlCpyShTcLuMWneMfe96ScHDni7t3ld/aR49XCxoVKkYzlGVLDVHB0lGjGLhUd5cqUpOpOL5ZTc2lFu0FzTP9tzy/f9P/tleqfLe0fZ/fH/AOVn/9k=",
				idDocumento: "1",										
				consecutivoPersona: "0",
				porcentaje: 90
			};
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.digitalizarImagenOS(request).then(
				function(data) {

					

					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							$rootScope.message("Exito", [jsonResponse.descripcion], "Aceptar");
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}
					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'guardaFirmasBiometricosOS'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};
		
		
		$scope.recuperaFirmasOS = function() {
			var request = {
				idSolicitud: "20180327152726152726543581",
				sucursal: "6318",
				usuario: "190000",
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.recuperaFirmasOS(request).then(
				function(data) {

					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							$rootScope.message("Exito", [jsonResponse.descripcion], "Aceptar");
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}
					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'guardaFirmasBiometricosOS'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
			
		};
		
		
		$scope.guardaPresupuesto = function() {
			
//			var jsonRequest = { 
//					"idSolicitud": $rootScope.solicitudJson.idSolicitud, 
//					"idPais": $rootScope.sucursalSession.idPais,
//					"idCanal": $rootScope.sucursalSession.idCanal,
//					"idSucursal": $rootScope.sucursalSession.idSucursal,
//					"idPresupuesto": $rootScope.generalService.getArrayValue("presupuestoC3"),
//					"idLinea": $rootScope.categoriaLinea.idLinea,
//					"idSubLinea": $rootScope.categoriaLinea.idLinea,
//					"idProducto": $rootScope.solicitudJson.idProducto
//				};
//			
			var jsonRequest = { 
				"idSolicitud": "20180904175715175715519807", 
				"idPais": 1,
				"idCanal": 1,
				"idSucursal": 2325,
				"idPresupuesto": 918539,
				"idLinea": 12345,
				"idSubLinea": 67890,
				"idProducto": 21
			};
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.guardarPresupuesto(jsonRequest).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							$rootScope.message("Exito", [jsonResponse.descripcion], "Aceptar");
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}
					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'guardarPresupuestoEnNOC'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};
		
		
//		$scope.actualizarStatuSolOS = function(){
//			$rootScope.waitLoaderStatus = LOADER_SHOW; 
//			/*
//			var x = {
//					idSolicitudOS: JSON.stringify($rootScope.solicitudJson),
//					status: "",
//					idMarca: "1",
//					idMotivoRechazo: "",
//					idDocumento: "",
//					idEmpleado: ""
//			}
//			obligadoSolidarioService.actualizarStatuSolOS( x ).then(
//				function(data){
//					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					if(data.data.codigo == RESPONSE_CODIGO_EXITO){													
//						modalService.alertModal("", [JSON.stringify(data.data.respuesta)]);						
//					}else
//						alert(data.data.descripcion);
//					
//				}, function(error){
//	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
//	                modalService.alertModal("Error "+error.status, [error.statusText]);
//					
//				}
//			);*/
//			$rootScope.waitLoaderStatus = LOADER_HIDE;
//			modalService.alertModal("Titulo Ventana", ["Hola", "Mundo"]);	
//		}
//		
//		
//		
		
		/******************************
		 * FIN SECCION COACREDITADO *
		 ******************************/
		
	});
		
});

