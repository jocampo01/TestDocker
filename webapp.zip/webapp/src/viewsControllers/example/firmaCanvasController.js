'use strict';

define(["app"], function (app) {

	app.controller("firmaCanvasController", function ($scope, $rootScope, $location, exampleService, solicitudService, modalService, callCenterService, clienteUnicoService) {
		
		var canvas = document.getElementById("canvas");		
	    var ctx = canvas.getContext("2d");
	    ctx.fillStyle = "#000";
	    ctx.fillRect (0, 0, 300, 300);
		var posx = 0;
		var posy = 0;
		
		$scope.pintar = function(e){	 		
				posx = e.clientX;
		    	posy = e.clientY;
		    	ctx.fillStyle = "#FFF";
		    	ctx.fillRect (posx, posy, 3, 3);
		};
		
	});
	
});	