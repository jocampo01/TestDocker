'use strict';

define(["app"], function (app) {
	
		app.controller('expedienteController', function($timeout, $http, $compile, $rootScope, $scope, ngDialog, generalService, expedienteService, modalService, buroService, 
													    solicitudService, documentosService, messageData, clienteUnicoService, validateService,recuperaSolicitudService) {
			
			
			
			var arrayImagesExpIpad = new Array();
			var idCliente = null, idAval = null; 
			var index = 0;
			var getimagesservice = false;
			var documentoEnviado = false;	
			var documentoEncolado = false;
			
			
			var documentoCargado = new Array(10);
				documentoCargado[IDENTIFICACION_OFICIAL.id] = false;						 
				documentoCargado[COMP_DOMICILIO.id] = false;						 
				documentoCargado[COMP_INGRESOS.id] = false;						 
				documentoCargado[COMP_PROPIEDAD.id] = false;
				documentoCargado[COMP_ARRAIGO_DOMICILIARIO.id] = false;
				documentoCargado[COMP_ARRAIGO_LABORAL.id] = false;
				documentoCargado[IDENTIFICACION_OFICIAL_AVAL.id] = false;						
				documentoCargado[COMP_DOMICILIO_AVAL.id] = false;						
				documentoCargado[COMP_INGRESOS_AVAL.id] = false;						
				documentoCargado[COMP_PROPIEDAD_AVAL.id] = false;
			
			$scope.backPath = {root:"/", menu:"/ochoPasos"};			
			$scope.vistaDatosUsuario = configuracion.datosUsuario.opcion=0;
			$scope.pageClass = generalService.calculaVistas($rootScope.paginaActual,$rootScope.paginaAnterior,$rootScope.recuperaSolicitud);
			
			$scope.showDocsPage = false;
			$scope.showPage = false;
			$scope.imagesDocsIpad = new Array();;	
			$scope.imagesDocsWS = null;
			$scope.fotoIpad = null;
			$scope.esGerente = false;									
			
			
			$scope.init = function(){
				$scope.isTienda = configuracion.origen.tienda;
				
				$scope.showPage = messageData;
				if( messageData  ){
					
					$scope.condicionamientoMCO = (($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.mesaControl.id && $rootScope.solicitudJson.marca == STATUS_SOLICITUD.mesaControl.marca.condicionadoMesa) && ($rootScope.solicitudJson.banderaIngresos == 1) && ($rootScope.condicionamientoIngMay20))?true:false;
					$scope.enviaOchoPasos = true;
					//Se recorre el objeto de los documentos para validar si el comprobante de ingresos tiene un motivo de rechazo y mostrarlo de acuerdo a su correspondiente tipificacion
					$scope.motivoRechazo="";
					$scope.compIngRechazado = false;
					angular.forEach( $rootScope.solicitudJson.documentos.documento, function(doc, key){
						if(doc.idDocumento == 3 && doc.status == 5){
							$scope.compIngRechazado = true;
							if(doc.idMotivoRechazo == 1){
								$scope.motivoRechazo="No coincide documento";
							}
							else if(doc.idMotivoRechazo == 2){
								$scope.motivoRechazo="Documento ilegible";
							}
							else if(doc.idMotivoRechazo == 3){
								$scope.motivoRechazo="Documento incorrecto";
							}
						}
					});
					
					//Condiciones para validar qué modal de confirmación se debe mostrar en el caso de un condicionamiento por MCO
					if($scope.condicionamientoMCO && ($rootScope.solicitudJson.capacidadPagoNoComprobable < 50 || $rootScope.solicitudJson.idColorNC == 6)){
						$scope.confirmarRechazoPorCambioCDP();
					}else if($scope.condicionamientoMCO && $scope.compIngRechazado){
						$scope.confirmarLiberacionPorCambioCDP();
					}
					
					$scope.origen = configuracion.origen.tienda == true? "TIENDA":"WEB";
					$scope.labelTiempo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO TIEMPO."+$scope.origen+".valor"];
					$scope.labelMin = " " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO MIN."+$scope.origen+".valor"];
					generalService.setArrayValue("sourcePath", null);
										
					if(  ($rootScope.userSession.idPuesto == PUESTO_GERENTE || 
							$rootScope.userSession.idPuesto == PUESTO_GERENTE_PRUEBA || ($rootScope.sucursalSession!=null  &&  generalService.isCanalExterno($rootScope.sucursalSession.idCanal)) )  &&						  
						 !generalService.existeSolicitud($rootScope.solicitudJson) ){						
						
						$scope.backPath = {root:"/buzonExpedientes", menu:"/buzonExpedientes"};
						generalService.setArrayValue("sourcePath", $scope.backPath.root );
						var solicitudId = generalService.getSolicitudId();								
						
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						solicitudService.loadSolicitud( solicitudId ).then(
								function(data){
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									
									if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
										var j = JSON.parse(data.data.respuesta.solicitudJson);																											
										
										if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
											$rootScope.solicitudJson = j.data;
											$rootScope.historicoMarcas = null;
				                			if(data.data.respuesta.historicoMarcas){
				                				var j = JSON.parse(data.data.respuesta.historicoMarcas);
				                				if(j.data[0].codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
				                					$rootScope.historicoMarcas=[];
				                					for(var i=0;i<j.data[0].data.length;i++){
				                						$rootScope.historicoMarcas[i]=j.data[0].data[i].marca;
				                					}
				                				}
				                				recuperaSolicitudService.cargaBanderas();
				                			}
											getExpediente();
										
										}else if(j.codigo == RESPONSE_CODIGO_ERROR_ID){
											$rootScope.message("Aviso", [j.descripcion], "Aceptar", $scope.backPath.root, "bgCafe", "cafeD");
										}
									}
									
								}, function(error){
									$rootScope.waitLoaderStatus = LOADER_HIDE;																				
								}
							);
						
					}else
						getExpediente();
																								
					
				}else
					$rootScope.message(ERROR_CARGA_PAGINA.titulo, [ERROR_CARGA_PAGINA.texto], "Aceptar", $scope.backPath.root, "bgCafe", "cafeD");

					
			};
			
			$scope.confirmarRechazoPorCambioCDP = function(){
		 		modalService.confirmModal("Notificación",["El comprobante de ingresos fue rechazado por el motivo: <b>"+ $scope.motivoRechazo +"</b>, ¿Desea digitalizar otro comprobante o cancelar la solicitud de línea de crédito?"], "Digitalizar nuevo documento", "Cancelar solicitud de LCR", "bgAzul", "btn gris", "btn azul" ).then(
						function(exito){
							$scope.rechazoPorCambioCDP();
							console.log("Solicitud rechazada");												
						},function(error){
							console.log("Digitalizar documento");
						}
				 );
		 		
		 	};
		 	
		 	$scope.confirmarLiberacionPorCambioCDP = function(){
		 		modalService.confirmModal("Notificación",["El comprobante de ingresos fue rechazado por el motivo: <b>"+ $scope.motivoRechazo +"</b>, ¿Desea digitalizar otro comprobante o liberar su línea de crédito como: Ingresos NO Comprobables, con una capacidad de pago de: <b>" + $rootScope.solicitudJson.capacidadPagoNoComprobable + "</b>"], "Digitalizar nuevo documento", "Liberar como NO comprobable", "bgAzul", "btn gris", "btn azul" ).then(
						function(exito){
							$scope.guardar();
							console.log("Liberar como NO comprobable");							
						},function(error){
							console.log("Digitalizar documento");
						}
				 );
		 		
		 	};
		 	
		 	/*Servicio que rechaza la solicitud siempre y cuando cumpla con lo siguiente.
			 * Que la CDP No Comprobable sea menor a 50
			 * ó
			 * Que el idColorNC sea igual a 6
			 * */
			 $scope.rechazoPorCambioCDP = function(){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
								
					solicitudService.rechazoPorCambioCDP($rootScope.solicitudJson.idSolicitud).then(
							function(data){
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var response = JSON.parse(data.data.respuesta);
								$rootScope.solicitudJson = response.data;
								
								if(response.codigo == 2){									

									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									var fechaTotal = generalService.getFechaRecuperacionSolicitudRechazada(0, 61);
									$rootScope.message( "AVISO", ["Lo sentimos, Infórmale a tu cliente que por politicas internas no podra levantar una solicitud hasta el: "+fechaTotal], "Aceptar", "/simulador", null, null,buildJsonDefault);																		
									
								}else{
								    $rootScope.message("Código " + response.codigo, ["Ocurrió un error al rechazar la solicitud, favor de intentarlo más tarde."], "Aceptar", null, "bgCafe", "cafeD");
								}
							}
						},function(error){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
						}
					);
			}
			 
			$scope.guardar=function(){
					//$rootScope.waitLoaderStatus = LOADER_SHOW;
						$timeout(function(){ 
							save(); 
							}, 1);									
			};
			
			function save(){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
																																																		
						var buroTmp = $rootScope.solicitudJson.consultaBuro;
						var matrizTmp = $rootScope.solicitudJson.consultaMatriz;
						var consultarBuro = -1;								
						
						$scope.cambioMonto = $rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo[0].monto;
						
						 if($rootScope.solicitudJson.banderaIngresos == 1 && ($rootScope.solicitudJson.idSeguimiento == 34 && $rootScope.solicitudJson.marca == 4001)){
							 $rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo[0].monto = 0;
							 $rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo[1].monto = $scope.cambioMonto;
							 	$rootScope.solicitudJson.banderaIngresos = 0;	
							 	$rootScope.solicitudJson.consultaBuro = 0;
								$rootScope.solicitudJson.consultaMatriz = 0;
								consultarBuro = 1;
							 
						 }								
						
								var solicitudJsonString = generalService.delete$$hashKey($rootScope.solicitudJson);																						
								
								solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: SECCION_PERSONALES } ).then(
									function(data){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
	
										if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
											var responseJson = JSON.parse(data.data.respuesta);		
											
											if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
													$rootScope.solicitudJson = responseJson.data;	
													generalService.setRespaldo($rootScope.solicitudJson);
													$rootScope.porcentajes.secciones[0].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje; 
													$rootScope.calculaDocumentos();
													
													//Si se cambia la CDP de una solicitud con periodicidad quincenal o mensual, se realiza un guardado por sección para cambiar la periodicidad a semanal.
//													if(($rootScope.solicitudJson.banderaIngresos == 0) && ($rootScope.solicitudJson.cotizacion.idPeriodicidad ==PERIODICIDAD.quincenal || $rootScope.solicitudJson.cotizacion.idPeriodicidad ==PERIODICIDAD.mensual)){
//													$scope.guardarSeccionNueve();
//													}
													
													if(generalService.productosQuickFixes()){
														generalService.locationPath( "/ochoPasos",true);
													}else{
														solicitudService.validaFolioCallCenter(JSON.parse(solicitudJsonString), responseJson.data)
																		.then(
																				function(data){
																					if(data == null){
																						if ($scope.enviaOchoPasos)																														
																							buroService.consultaBuro( "bgNaranja", "btn gris","btn naranja", null, null, consultarBuro, null );
																					}else
																						generalService.locationPath(data);
																				},function(error){
																					
																				}
																			);
													}
													
																																														
											}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
												var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
												$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
											}else{
												if(responseJson.codigo == ERROR_SOL_RECHAZADA){
													var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
													$rootScope.message(	"Error en solicitud", [ "La solicitud no puede ser modificada debido a que se encuentra Cancelada o Rechazada." ],
															"Aceptar", "/simulador",  $scope.titulo.colorModal , $scope.titulo.colorSeccion,buildJsonDefault);
												}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
													generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
													generalService.locationPath("/ficha");
												}else{
													$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = porcentajeant;
													$rootScope.message($scope.titulo.texto,["Error al guardar sección. Código " +
			                                        	"de error [" + responseJson.codigo + "] no identificado."], 
			                                        	"Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion,null,null,null);
													$rootScope.solicitudJson.consultaBuro = buroTmp;
													$rootScope.solicitudJson.consultaMatriz = matrizTmp;
												}
											}
										}else{
											$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = porcentajeant;
											$rootScope.message($scope.titulo.texto,["Error en la respuesta del servicio para guardar los datos de la sección de Datos Básicos. Por favor, reintente nuevamente."], "Aceptar", null, $scope.titulo.colorModal, $scope.titulo.colorSeccion);
											$rootScope.solicitudJson.consultaBuro = buroTmp;
											$rootScope.solicitudJson.consultaMatriz = matrizTmp;
											//Regresamos la bandera a 0 cuando el servicio no responda siempre y cuando se cumplan las condiciones 
											if($rootScope.solicitudJson.consultaBuro == 1 && $scope.existeEdicion==true)
												$rootScope.solicitudJson.cotizacion.clientes[0].bloqueado=0;
										}/* END IF-ELSE RESPONSE_CODIGO_EXITO */
										
									}, function(error){
										 $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = porcentajeant;
										 $rootScope.waitLoaderStatus = LOADER_HIDE;
										 $rootScope.solicitudJson.consultaBuro = buroTmp;
										 $rootScope.solicitudJson.consultaMatriz = matrizTmp;
										//Regresamos la bandera a 0 cuando el servicio no responda siempre y cuando se cumplan las condiciones 
										 if($rootScope.solicitudJson.consultaBuro == 1 && $scope.existeEdicion==true)
											 $rootScope.solicitudJson.cotizacion.clientes[0].bloqueado=0;
									}
								);	
			
		};	
		
		$scope.guardarSeccionNueve = function(){
	 		
	 		$rootScope.solicitudJson.cotizacion.idPeriodicidad = 1;
	 		$rootScope.solicitudJson.cotizacion.cambioPeriodicidad = 1;
	 		
	 		solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: SECCION_SOLICITUD } ).then(
		 			function(data){
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
		 					var responseJson = JSON.parse(data.data.respuesta);
		 					
		 					var fnStatusOK = function( esMalZonificada ){
								$scope.$parent.muestraAlertaNuevoBuro=false;
								$scope.$parent.muestraMensajeNuevoBuro=false;
								$scope.$parent.mensajeNuevoBuro=""
								$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO; //FIX COMMENT 01/04/2016
		 						$rootScope.solicitudJson = responseJson.data;
								if( esMalZonificada && typeof esMalZonificada !== 'undefined' ){
									var excepciones = [ SECCION_HOGAR.toString() ];
									generalService.bloqueoSecciones( $rootScope.solicitudJson, excepciones );
								}
								$rootScope.calculaDocumentos();
								$scope.$parent.buildMenuList();
								$scope.closeThisDialog(true);		
							
		 					};
		 					
		 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
								fnStatusOK();							
							}else if( responseJson.codigo == STATUS_SOLICITUD.malZonificada.guardarSeccion ){
								generalService.setDataBridge( {esMalZonificada:true} );
								fnStatusOK( true );
							}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
								var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
								$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
							}else{
								if(responseJson.codigo == ERROR_SOL_RECHAZADA){
									var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
									var marca = $rootScope.solicitudJson.marca;
									var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$rootScope.message(	"Error en solicitud", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],"Aceptar", "/simulador",null,null,buildJsonDefault);
								}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
									generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
									$scope.closeThisDialog(true);
									generalService.locationPath("/ficha");
								}else{
									$rootScope.message("Error al volver a cotizar",[ "Error al guardar sección. Código " +
									    "de error [" + responseJson.codigo + "] no identificado."],"Aceptar", null);
								}
		 					}
		 					
		 					//Se actualiza el status de la solicitud cuando el cliente decide cambiarse por la opción de No comprobables.
		 					if($rootScope.solicitudJson.idSeguimiento == 34 && $rootScope.solicitudJson.marca == 4001 && $rootScope.solicitudJson.banderaIngresos == 0){
		 						$scope.actualizaStatusTiendaMCO();
		 					}
		 					
		 				}else{
		 					$rootScope.message("Error",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
		 				}
		 			}, function(error){                     
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				$rootScope.message("Error al volver a cotizar",[ "Error en el servicio guardar solicitud sección 9"], "Aceptar", null);								
		 			}	
				);
		}
									
			
			$scope.getEnviosIpad = function(response){																	
				$rootScope.loggerIpad("getEnviosIpad", null, response);
				try{															
					
					if(response.codigo==RESPONSE_CODIGO_EXITO_IPAD){	
																	
						angular.forEach(response.peticiones, function(data){					
							if(data.service == "digitalizacion")
								arrayImagesExpIpad.push(data);
																																																															
						});
						
						if(arrayImagesExpIpad.length > 0)																		
							$rootScope.obtenerRecursoPendiente('expDivId', 'loadImagesIpad', arrayImagesExpIpad[index].identifier.toString());
						else
							getImagesService();
																														
					}else 	//si no hay images en ipad, se obtienen del servicio
						getImagesService();
					
				}catch(e){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("e", [e], "Aceptar", null, "bgCafe", "cafeD");
				}																
				
			};
						
			
			
			$scope.loadImagesIpad = function(response){	
				$rootScope.loggerIpad("loadImagesIpad", null, response);								
															
				if(response.codigo==RESPONSE_CODIGO_EXITO_IPAD){										
					
						var jsonImage = {
										identifier: response.peticion.identifier,
										idTipoDoc: response.peticion.parameters.idDocumento, 
										nombreDoc: '',
										urlDoc: null,
										imgB64: response.peticion.parameters.imagenB64,
										imgWidth: 0,
										imgHeight: 0,
										tipo: 'jpg' 
						};
												
						$scope.imagesDocsIpad.push(jsonImage);			
						
				}																
													
        		if(  $scope.imagesDocsIpad.length > 0  && $scope.imagesDocsIpad.length == arrayImagesExpIpad.length )        			        			        				   
	    			getImagesService();
					
        		else{
        			index++;
        			$rootScope.obtenerRecursoPendiente('expDivId', 'loadImagesIpad', arrayImagesExpIpad[index].identifier.toString());
        		}
        			
        		       
        		
			
			}
			
			
			
			function getExpediente(){
				
				if( generalService.existeSolicitud($rootScope.solicitudJson) ){
																					
						generalService.setRespaldo($rootScope.solicitudJson);														
						
						var bandRechazado = 0;
						for(var i=0;i<$rootScope.solicitudJson.documentos.documento.length;i++){
							if($rootScope.solicitudJson.documentos.documento[i].status == STATUS_RECHAZADO){
								bandRechazado = 1;
								break;
							}
						}
						
						$scope.esGerente = (
											 ($rootScope.userSession.idPuesto == PUESTO_GERENTE  || $rootScope.userSession.idPuesto == PUESTO_GERENTE_VENTAS_CREDITO || 
												$rootScope.userSession.idPuesto == PUESTO_GERENTE_PRUEBA || ($rootScope.sucursalSession!=null  &&  generalService.isCanalExterno($rootScope.sucursalSession.idCanal) ))  && 
											 $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && 
											 ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.ejecutivo ||
											 ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.docPendValidar && !bandRechazado) ||
											 ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expRechazado && !bandRechazado))
											);																													
											
						if($scope.esGerente  &&  generalService.isCanalExterno($rootScope.sucursalSession.idCanal)  &&  $rootScope.userSession.noEmpleado == $rootScope.solicitudJson.idEmpleado ){
												
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									modalService.alertModal("Aviso", ["La revisión del expediente debe realizarse por otro ejecutivo."]).closePromise.then(
											function(exito){
												generalService.locationPath($scope.backPath.menu);																
											},function(error){
												generalService.locationPath($scope.backPath.menu);														
											}
										);
									
												
						}else{
								angular.forEach( $rootScope.solicitudJson.documentos.documento, function(doc, key){																																													
									if( generalService.documentoEnviadoWS(doc.status) )
										documentoEnviado = true;	
									else if(doc.status == STATUS_ENCOLADO_IPAD )
										documentoEncolado = true;
										
								});
																
									
								if($scope.isTienda && documentoEncolado){																				
										// se obtienen imagenes del ipad
										$rootScope.obtenerEnviosXCliente('expDivId', 'getEnviosIpad', $rootScope.solicitudJson.cotizacion.clientes[0].idPersona);	
																				
																																												
								}else //se obtiene imagenes del servicio							
									getImagesService();	
								
						}	
					
																																																																												
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message(SIN_SOLICITUD.titulo, [SIN_SOLICITUD.texto], "Aceptar", $scope.backPath.root, "bgCafe", "cafeD");
				}
						
			};
			

			
			function getImagesService(){
				
				if( documentoEnviado ){
					var imagesRequest = {  cuenta: null, idTipoDocto: "0", status: 1, opcion: 1	};
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					
					
					imagesRequest.cuenta = $rootScope.solicitudJson.idSolicitud;
					
					if( !generalService.isEmpty( $rootScope.solicitudJson.cotizacion.clientes[0].clienteTienda) ){
						var cteTda = $rootScope.solicitudJson.cotizacion.clientes[0].clienteTienda.split("-");
						var sucursal = generalService.addZerosLeft(cteTda[1], 4);
						imagesRequest.cuenta = cteTda[0]+sucursal+cteTda[2]+cteTda[3];
					}
											
												
					documentosService.getImages( imagesRequest ).then(
							function(data){					
								
								if(data.data.codigo == RESPONSE_CODIGO_EXITO){										
									$scope.imagesDocsWS = data.data.respuesta;	
									loadPage();
								}else{
									$rootScope.message("Expediente", [data.data.descripcion], "Aceptar", $scope.backPath.menu, "bgCafe", "cafeD");
									$rootScope.waitLoaderStatus = LOADER_HIDE;
								}	
								
							},function(error){
								$rootScope.waitLoaderStatus = LOADER_HIDE;																
							}
					);
					
				}else
					loadPage();
				
			}
			
			function loadPage(){					
				$scope.htmlDocumentosDiv = "<div ng-include=\"'src/viewsControllers/expediente/docsExpediente.html'\" ></div>";												
			}
			
	
																		
	    });
		
		
		

		
});