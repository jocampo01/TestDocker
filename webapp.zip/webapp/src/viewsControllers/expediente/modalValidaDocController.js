'use strict';

var imagenes;

define(["app"], function (app) {
	
		app.controller('modalValidaDocController', function($rootScope, $scope, $location, $interval, generalService) {
			
			var numCamposOK = 0;
			var cantChecks = 0;
			var iddocumento = 0;
									
			$scope.showDivMotivo = true;
			$scope.autorizado = STATUS_VALIDADO;
			$scope.rechazado = STATUS_RECHAZADO;
			
			$rootScope.rechazo = { motivos : [ {id: '1', descripcion: "No coincide documento"},
					                           {id: '2', descripcion: "Documento ilegible"},
					                           {id: '3', descripcion: "Documento incorrecto"}
					                         ],
					               motivo : {id: '1', descripcion: "No coincide documento"} 
								 };
			$rootScope.rechazo.obsRechazo="";
			
						
									
			$scope.init = function(idDoc, images){
				
				imagenes = new Array();
				if(idDoc == IDENTIFICACION_OFICIAL.id || idDoc == IDENTIFICACION_OFICIAL_AVAL.id)
					for(var i=images.length-1; i>=0; i--)   
						imagenes.push(images[i])
				else
					imagenes = images;
				
				iddocumento = idDoc;
				botonesCheck();																			
				loadView();
				
				$scope.arrayInfo == null;
				var tipo;
				var infoDoc;
				
				angular.forEach($rootScope.solicitudJson.documentos.documento, function(docs, key){										
					if(docs.idDocumento ==  idDoc){
						infoDoc = docs;
					}																														
				});
				
				if(idDoc == IDENTIFICACION_OFICIAL.id || idDoc == IDENTIFICACION_OFICIAL_AVAL.id){
					if($rootScope.isExpedienteCte)
						tipo = ((idDoc==1)?$rootScope.solicitudJson.cotizacion.clientes[0]:$rootScope.solicitudJson.avales[0]);
					else
						tipo = $rootScope.solicitudOSJson.cotizacion.clientes[0];
					
					if(infoDoc.idTipoDocumento == 1){
						$scope.arrayInfo = [
							{							
								descripcion : "Nombre:",
								valor : tipo.nombre + ' ' + tipo.apellidoPaterno + ' ' + tipo.apellidoMaterno,
								valido: false
							},
							{
								descripcion : "Folio ID:",
								valor : tipo.folioIdentificacion,
								valido: false
							},
							{
								descripcion : "Fecha de nacimiento:",
								valor : tipo.fechaNaciomiento,
								valido: false
							},
							{
								descripcion : "Tipo:",
								valor : infoDoc.tipoDocumentoDes,
								valido: false
							}/*,
							{
								descripcion : "RFC:",
								valor : tipo.rfc,
								valido: false
							},
							{
								descripcion : "Vigencia de ID:",
								valor : infoDoc.fechaVigencia.split('/')[2],
								valido: false
							}*/ ];
					}else{
						var descripcionDocumento="";
						var descripcionVigencia="";
						var vigenciaLicencia=infoDoc.fechaVigencia;
						switch(infoDoc.idTipoDocumento){
							case 2:
								descripcionDocumento="No. de Pasaporte";
								descripcionVigencia="Vigencia";
								break;
							case 3:
								descripcionDocumento="No. de Cédula";
								descripcionVigencia="Fecha de expedición (máxima 10 años)";
								break;
							case 4:
								descripcionDocumento="No. de Licencia";
								descripcionVigencia="Vigencia";
								if(infoDoc.fechaVigencia == "31/12/2100")
									vigenciaLicencia="Permanente";
								break;
							case 5:
								descripcionDocumento="Matrícula";
								descripcionVigencia="Fecha de expedición (máxima a 3 años)";
								break;
							case 6:
								descripcionDocumento="Nacionalidad";
								descripcionVigencia="Vigencia";
								break;
							case 7:
								descripcionDocumento="NSS";
								descripcionVigencia="Vigencia";
								break;
						}

						$scope.arrayInfo = [
											{
												descripcion : "Nombre:",
												valor : tipo.nombre + ' ' + tipo.apellidoPaterno + ' ' + tipo.apellidoMaterno,
												valido: false
											}];
							
						if(descripcionDocumento != "" && tipo.folioIdentificacion != ""){
							$scope.arrayInfo.push(
								{
									descripcion : descripcionDocumento,
									valor : tipo.folioIdentificacion,
									valido: false
								}
							)
						}
						
						if(descripcionVigencia != "" && vigenciaLicencia != ""){
							$scope.arrayInfo.push(
									{
										descripcion : descripcionVigencia,
										valor : vigenciaLicencia,
										valido: false
									}
							)
						}
						
						if(infoDoc.tipoDocumentoDes != ""){
							$scope.arrayInfo.push(
									{
										descripcion : "Tipo:",
										valor : infoDoc.tipoDocumentoDes,
										valido: false
									}
							)
						}
						
					}
				}else if(idDoc == COMP_DOMICILIO.id || idDoc == COMP_DOMICILIO_AVAL.id){
					
					tipo = ((idDoc==2)?$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0]:$rootScope.solicitudJson.avales[0].datosHogar);
					
					var direccion = {};
					if( (infoDoc.idTipoDocumento == RECIBO_LUZ      && infoDoc.idCompania == TIPO_RECIBO_LUZ.CFE)   || 
						(infoDoc.idTipoDocumento == RECIBO_TELEFONO && infoDoc.idCompania == TIPO_RECIBO_TELEFONO.TELMEX)  ){
						direccion = {
							descripcion : "Validar que ambas direcciones coincidan:",
							valor : "<br><b>Dirección obtenida mediante OCR:</b> <br>" + 
									infoDoc.textoDigitalizacion + '<br><br>' +
									"<b>Dirección capturada en la solicitud:</b><br>"+ 
									tipo.calle,
							valido: false
						};
						
						if (tipo.manzana)
							direccion.valor = direccion.valor + ', MZ. ' + tipo.manzana;
						if (tipo.lote)
							direccion.valor = direccion.valor + ', LT. ' + tipo.lote;
						if (tipo.numeroExterior)
							direccion.valor = direccion.valor + ' # ' + tipo.numeroExterior;
						if (tipo.numeroInterior)
							direccion.valor = direccion.valor + ' '+tipo.numeroInterior;
						direccion.valor = direccion.valor +', COL. '+tipo.colonia+' C.P.'+tipo.cp+' Del.'+tipo.delegacion+', '+tipo.estado
					}else{
						direccion = {
							descripcion : "Dirección:",
							valor : tipo.calle,
							valido: false
						};

						if (tipo.manzana)
							direccion.valor = direccion.valor + ', MZ. ' + tipo.manzana;
						if (tipo.lote)
							direccion.valor = direccion.valor + ', LT. ' + tipo.lote;
						if (tipo.numeroExterior)
							direccion.valor = direccion.valor + ' # ' + tipo.numeroExterior;
						if (tipo.numeroInterior)
							direccion.valor = direccion.valor + ' '+tipo.numeroInterior;
						direccion.valor = direccion.valor +', COL. '+tipo.colonia+' C.P.'+tipo.cp+' Del.'+tipo.delegacion+', '+tipo.estado
					}
					
					$scope.arrayInfo = [ direccion,
										 {descripcion : "Tipo:", valor : infoDoc.tipoDocumentoDes, valido: false },
										 {descripcion : "Fecha menor a 3 meses.", valor : "", valido: false}
										];
					
				}else if(idDoc == COMP_INGRESOS.id || idDoc == COMP_INGRESOS_AVAL.id){
					
					tipo = ((idDoc==3)?$rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo[0]:$rootScope.solicitudJson.avales.flujoEfectivo[0]);
					
					$scope.arrayInfo = [
						{
							descripcion : "",
							valor : "Los ingresos mensuales declarados son $ "+generalService.numberWithCommas(tipo.monto) +" por favor valida que el comprobante corresponda a ese ingreso.",
							valido: false
						}];
					
				}else if( idDoc == COMP_PROPIEDAD.id || idDoc == COMP_PROPIEDAD_AVAL.id || idDoc == COMP_ARRAIGO_DOMICILIARIO.id || idDoc == COMP_ARRAIGO_LABORAL.id){
					
					tipo = ((idDoc==COMP_PROPIEDAD_AVAL.id)?$rootScope.solicitudJson.avales[0]:$rootScope.solicitudJson.cotizacion.clientes[0]);
					
					$scope.arrayInfo = [
						{							
							descripcion : "Nombre:",
							valor : tipo.nombre + ' ' + tipo.apellidoPaterno + ' ' + tipo.apellidoMaterno,
							valido: false
						},
//						{
//							descripcion : "Propiedades Capturadas:",
//							valor : infoDoc.tipodocumentoDes,
//							valido: false
//						},
//						{
//							descripcion : "Comprobantes que avalen la propiedad",
//							valor : COMP_PROPIEDAD_AVAL_LIST,
//							valido: false
//						},
						{
							descripcion : "Dirección:",
							valor : tipo.domicilios[0].calle + ' NUM. ' + 
									tipo.domicilios[0].numeroExterior + ' ' +
									tipo.domicilios[0].numeroInterior + ' COL. ' +
									tipo.domicilios[0].colonia + ' C.P.' +
									tipo.domicilios[0].cp + ' DEL/MUN.' +
									tipo.domicilios[0].delegacion + ', ' +
									tipo.domicilios[0].estado,
							valido: false
						},
						{
							descripcion : "Tipo:",
							valor : infoDoc.tipoDocumentoDes,
							valido: false
						},
						{
							descripcion : "Fecha menor a 3 meses.", 
							valor : "", 
							valido: false
						}];
				}
				
				cantChecks = $scope.arrayInfo.length;

			};
												
			
			$scope.validaElemento = function(elemenId, _checked){		
				
				
				var checksTrue = 0;
				$scope.arrayInfo[elemenId].valido = _checked;
								
				angular.forEach( $scope.arrayInfo, function(elemento, key){
					if(elemento.valido)						
						checksTrue++;
				
				})
				
				$scope.showDivMotivo = ($scope.arrayInfo.length == checksTrue)? false:true;													
				$scope.$apply();
					 
			};
			
			function botonesCheck(){
				
				var stopInterval = null, intervalCont = 1;
				
				var verifySlider = function(){
					$('#modal_validaDoc .iphone_check').iphoneStyle({
						checkedLabel: 'si',
						uncheckedLabel: 'no',
					});
				};
								
								
				var trySlider = function(){
					verifySlider();				
					if( intervalCont == 50 )
						$interval.cancel( stopInterval )
					else					
						intervalCont++;
					
				};
				
				stopInterval = $interval( trySlider, 100 );
				
			};
			
			function loadView(){
				$scope.origen = configuracion.origen.tienda == true? "TIENDA":"WEB";
				
				$scope.btnAutorizo = generalService.getDataInput("EXPEDIENTE","BOTON AUTORIZO",$scope.origen );
				$scope.btnNoAutorizo = generalService.getDataInput("EXPEDIENTE","BOTON NO AUTORIZO",$scope.origen );
			};
			
		});
	
});