'use strict';

var imagenes;

define(["app"], function (app) {
	
		app.controller('muestraDocController', function($rootScope, $scope, $location, $interval, generalService, $timeout, ngDialog) {			
									
			$scope.init = function(idDoc, images){
				
				$scope.comentario="Comentario asesor MCO:";
				imagenes = new Array();
				if(idDoc == IDENTIFICACION_OFICIAL.id || idDoc == IDENTIFICACION_OFICIAL_AVAL.id)
					for(var i=images.length-1; i>=0; i--)   
						imagenes.push(images[i])
				else
					imagenes = images;																						
				
				$scope.datosExp = [];
				$scope.index = 0;
				angular.forEach($rootScope.solicitudJson.documentos.documento, function(doc, key){										
					if(idDoc == doc.idDocumento){
						$scope.datosExp[$scope.index] = {
								idDocumento : doc.idDocumento,
								tipoDoc		: doc.documentoDes,
								observacion : doc.observacion
							}
						}																									
				});
				
			};
			
		});
	
});