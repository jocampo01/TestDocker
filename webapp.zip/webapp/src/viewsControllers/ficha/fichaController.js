'use strict';

define(["app"], function (app) {
	
	app.controller('fichaController', function( $rootScope, $scope, messageData, modalService, buroService,
												validateService, generalService, surtimientoService, tarjetaService,
												solicitudService, clienteUnicoService, documentosService ) {
		
		
		var fecha = new Date();
		var titulo = "Credito";
		/** Se agrega bandera para mostrar el boton de reactivación REQ 85337*/
		$scope.reactivar = false;
		var TIPO_FICHA_BLOQUEADA = "bloqueada", TIPO_FICHA_DEFAULT = "default";
		$scope.entregaTarjeta = 0;
		
		$scope.descCatalog = new Object();
//		$scope.descCatalog[21] = {label:"Consumo", idLi:"consumo"};
//		$scope.descCatalog[22] = {label:"Italika", idLi:"italika"};
//		$scope.descCatalog[23] = {label:"Telefonia", idLi:"telefonia"};
//		$scope.descCatalog[24] = {label:"Préstamo en efectivo", idLi:"prestamospersonales"};
//		$scope.descCatalog[25] = {label:"Crédito Inmediato", idLi:"tarjetaazteca"};
		
		$scope.descBloqueo = "";
		$scope.montoPrestamos = 0;
		$scope.datosCredito = {};	
		$scope.capacidadPago = 0;
		$scope.ID_PRODUCTO = ID_PRODUCTO;	
		$scope.canales = CANALES;
		$scope.limiteCredito = 0;
		/*OFERTA 30 DIAS*/
		$scope.cpComprobable = 0;
		$scope.cpNoComprobable = 0;
		$scope.activaOferta30Dias = false;
		$scope.mensaje30Dias = false;
		$scope.tipoComprobante = $rootScope.solicitudJson.cotizacion.statusCotizacion;
		/****************/
		
		$scope.init = function()
		{

			/*\Se agrega un evento para la bitacora\*/
//			(Búsqueda Cliente)
			$rootScope.addEvent( BITACORA.SECCION.busquedaCliente.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, 0, BITACORA.SECCION.busquedaCliente.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
			
			($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.bloqueoIntentos && generalService.getDataBridge().tipoFicha === FICHA.tipoFicha.bloqueada30dias)?$scope.mensaje30Dias = true:$scope.mensaje30Dias= false;
			$scope.montoPrestamos = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;
			$scope.pedido = $rootScope.solicitudJson.pedido;
			
			$scope.showPage = false;
			
			if( messageData  ){		
				var productos = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.CATALOGO PRODUCTOS"];						
				$scope.descCatalog = generalService.getProductosCredito(productos, ID_PRODUCTOS);
				
				$scope.backResponseBridge = generalService.getDataBridge();
				generalService.setDataBridge(null);
				if( !generalService.isEmpty( JSON.stringify($scope.backResponseBridge) ) ){
						
						if( $scope.backResponseBridge.origen == FICHA.origen.homonimos ){
														
							$scope.cargaTipoFicha( $scope.backResponseBridge.tipoFicha );
							$scope.servicioLCRporCU( $scope.backResponseBridge.cu, $scope.backResponseBridge.tipoFicha ); 
						}else{
							$scope.cargaTipoFicha($scope.backResponseBridge.tipoFicha);
							$scope.servicioLCRInterno();
						}
						
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$scope.showPage=false;
					generalService.cleanRootScope($rootScope);
					generalService.buildSolicitudJson($rootScope, null );
					$rootScope.message(ERROR_CARGA_PAGINA.titulo, [ERROR_CARGA_PAGINA.texto], "Aceptar", "/simulador","bgCafeZ", "cafeZ");
				}
																								
				
			}else{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.showPage=false;
				generalService.cleanRootScope($rootScope);
				generalService.buildSolicitudJson($rootScope, null );
				$rootScope.message(ERROR_CARGA_PAGINA.titulo, [ERROR_CARGA_PAGINA.texto], "Aceptar", "/simulador","bgCafeZ", "cafeZ");
			}										
		};/* END INIT FUNCTION */
		
		function loadView(){			
			
			$scope.isTienda = configuracion.origen.tienda; 
			$scope.origen = ($scope.isTienda == true) ? "TIENDA":"WEB";
			
			$scope._cpSemanalTxt = generalService.getDataInput("CREDITO","ETIQUETACPS",$scope.origen );
			$scope._labelTotal = generalService.getDataInput("CREDITO","ETIQUETATOTAL",$scope.origen );
			$scope._labelOcupado = generalService.getDataInput("CREDITO","ETIQUETAOCUPADO",$scope.origen );
			$scope._labelPP = generalService.getDataInput("CREDITO","ETIQUETAPP",$scope.origen );
			$scope._labelDisponible = generalService.getDataInput("CREDITO","ETIQUETADISP",$scope.origen );
			$scope._LDC = generalService.getDataInput("CREDITO","ETIQUETALDC",$scope.origen );						
			
			$scope._titulo = {
					estilo: "mainHeader cafeS",
					imagen: "images/header/suCredito.png",
					texto: "Su crédito"
			};
			$scope._btnTerminar = {
					estilo: "btn cafeZ",
					texto: "Terminar"
			};
			
			if($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
				
				if($rootScope.solicitudJson.banderaIngresos == 1){
					
					if($rootScope.campanasConvivencia($rootScope.solicitudJson.campana))
						$scope.limiteCredito =  $rootScope.solicitudJson.tarjetasCredito.tarjetaOro.limiteCreditoComprobable;
					else
						$scope.limiteCredito = $rootScope.solicitudJson.limiteCreditoComprobable;
						
				}else if($rootScope.solicitudJson.banderaIngresos == 0){
					
					if($rootScope.campanasConvivencia($rootScope.solicitudJson.campana))
						$scope.limiteCredito =  $rootScope.solicitudJson.tarjetasCredito.tarjetaOro.limiteCreditoNoComprobable;
					else
						$scope.limiteCredito = $rootScope.solicitudJson.limiteCreditoNoComprobable;
				}
					
					
			}
			
			if( $rootScope.solicitudJson.cotizacion.clientes[0].nombre )
				$scope.nombre = $rootScope.solicitudJson.cotizacion.clientes[0].nombre;
			else
				$scope.nombre = $rootScope.NombreFicha;
				
			
			if( $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno )
				$scope.apellidoPaterno = $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno;
			else
				$scope.apellidoPaterno = $rootScope.paternoFicha
			
			if( $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno )
				$scope.apellidoMaterno = $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno;
			else
				$scope.apellidoMaterno = $rootScope.maternoFicha;
			
			$scope.nombreCompleto = $scope.nombre + " " + $scope.apellidoPaterno + " " + $scope.apellidoMaterno;
			$scope.pedido = $rootScope.solicitudJson.cotizacion.idCotizacion;
			
			var capacidad = $rootScope.solicitudJson.banderaIngresos==1?$rootScope.solicitudJson.capacidadPagoComprobable:$rootScope.solicitudJson.capacidadPagoNoComprobable;
			$scope.monto=capacidad*$rootScope.solicitudJson.cotizacion.plazo;
			
			$scope.plazo=$rootScope.solicitudJson.cotizacion.plazo
			$scope.pagoSemanal=$rootScope.solicitudJson.cotizacion.pagoNormal;
			$scope.pagoOportuno=$rootScope.solicitudJson.cotizacion.pagoPuntual;
			$scope.ahorro=$rootScope.solicitudJson.cotizacion.pagoNormal - $rootScope.solicitudJson.cotizacion.pagoPuntual;
			
		};/* END LOAD VIEW FUNCTION */
		
		$scope.servicioLCRInterno = function()
		{
			//Meter validacion para no consultar el buro cunado sea una 1020
			
			//if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.pendienteDigitalizar){
				
				//$scope.cpComprobable = $rootScope.solicitudJson.capacidadPagoComprobable;
				//$scope.cpNoComprobable = $rootScope.solicitudJson.capacidadPagoNoComprobable;
				
				//$scope.activarOferta30Dias($scope.cpComprobable, $scope.cpNoComprobable, $scope.tipoComprobante);
			//}else{
				if( generalService.isDefined(generalService.getArrayValue("datosFicha")) ){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					var datosFicha = generalService.getArrayValue("datosFicha");
									
					$scope.pedidos = datosFicha.listaPedidosCentralCU;
					$scope._capacidadPago = (datosFicha.banderaIngresos == 1)? datosFicha.capacidadPagoComprobable : datosFicha.capacidadPagoNoComprobable;
					$scope._pagoPuntual = datosFicha.pagoPuntual;
					$scope._disponible = $scope._capacidadPago - datosFicha.pagoPuntual;
					$scope._semanasAtraso = 0;
					$scope._pagoRequerido = 0
					$scope.descBloqueo = "("+datosFicha.idBloqueo +" - "+datosFicha.descBloqueo+")";
													
					/*OFERTA 30 DIAS*/
					$scope._capacidadPago = ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.pendienteDigitalizar || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.CDPActualizada || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.bloqueoIntentos)?$rootScope.solicitudJson.capacidadPagoNoComprobable:$scope._capacidadPago;
					$scope.cpComprobable = $rootScope.solicitudJson.capacidadPagoComprobable;//datosFicha.capacidadPagoComprobable;
					$scope.cpNoComprobable = $rootScope.solicitudJson.capacidadPagoNoComprobable;//datosFicha.capacidadPagoNoComprobable;
					
					$scope.activarOferta30Dias($scope.cpComprobable, $scope.cpNoComprobable, $scope.tipoComprobante);
					/*****************/
					
					/** REQ 85337 Se valida si un cliente es candidato a reactivación */
					var cuArray = [];
					cuArray.push($rootScope.clienteUnicoFicha);
					validaReactivados(cuArray);
					
					$scope.showPage = messageData;
					generalService.setArrayValue("datosFicha", null);
					
				}else{
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					buroService.resultadoConsulta($rootScope.solicitudJson.idSolicitud,$rootScope).then(
							function(objRes){								
								$scope.datosCredito = objRes.datosCredito;
								$scope.resCon= objRes.resConsulta;				
			
								$scope.pedidos = $scope.resCon.pedidos;
								$scope._capacidadPago = $scope.resCon.capacidadPago;

								if ($rootScope.solicitudJson.idCanal == CANALES.elektra && 
										($rootScope.solicitudJson.idProducto==ID_PRODUCTO.italika||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.telefonia||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.consumo))
									$scope.pedidos[0].saldoPedido=0;
								
								if ($rootScope.solicitudJson.idCanal == CANALES.elektra && 
										($rootScope.solicitudJson.idProducto==ID_PRODUCTO.italika||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.telefonia||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.consumo))
									$scope._pagoPuntual = 0;
								else
									$scope._pagoPuntual = $scope.resCon.ocupado;

								if ($rootScope.solicitudJson.idCanal == CANALES.elektra && 
										($rootScope.solicitudJson.idProducto==ID_PRODUCTO.italika||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.telefonia||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.consumo))
									$scope._disponible = $scope.resCon.capacidadPago
								else
									$scope._disponible = $scope.resCon.disponible;
								
								/*OFERTA 30 DIAS*/
								$scope._capacidadPago = ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.pendienteDigitalizar || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.bloqueoIntentos)?$rootScope.solicitudJson.capacidadPagoNoComprobable:$scope._capacidadPago;
								$scope._disponible = ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.pendienteDigitalizar || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.bloqueoIntentos)?($scope._capacidadPago - $scope._pagoPuntual):$scope._disponible;
								
								$scope._capacidadPago = ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.CDPActualizada || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.bloqueoIntentos)?$rootScope.solicitudJson.capacidadPagoComprobable:$scope._capacidadPago;
								$scope._disponible = ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.CDPActualizada || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.bloqueoIntentos)?($scope._capacidadPago - $scope._pagoPuntual):$scope._disponible;
								
								$scope.cpComprobable = $rootScope.solicitudJson.capacidadPagoComprobable;//$scope.datosCredito.capacidadPagoComprobable;
								$scope.cpNoComprobable = $rootScope.solicitudJson.capacidadPagoNoComprobable;//$scope.datosCredito.capacidadPagoNoComprobable;
								
								$scope.activarOferta30Dias($scope.cpComprobable, $scope.cpNoComprobable, $scope.tipoComprobante);
								/****************/
								
								$rootScope.waitLoaderStatus = LOADER_HIDE;								
								$scope.showPage = messageData;
								
							}, function(error){
								$rootScope.message(titulo, [error], "Aceptar", null, "bgCafeZ", "cafeZ");
				                $rootScope.waitLoaderStatus = LOADER_HIDE; 								
							}
					);	
				}
			//}
		};/* END SERVICIO LCR INTENRO */
		
		$scope.servicioAutorizada = function( cu )
		{
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			solicitudService.getDatosLcrAutorizada( { clienteUnico: cu } ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					if( data.data.codigo == RESPONSE_CODIGO_EXITO ){								
						var jResponse = JSON.parse( data.data.respuesta );
						var respuesta = jResponse.data;
						console.log( respuesta );
						
						$scope.pedidos = respuesta.listaPedidosActivos;
						var pedidosTmp = [];
						
						$scope.pedidos.map(function(data){	
							if( data['descProducto'] != null )
								pedidosTmp.push( data );  
						});
						
						$scope.pedidos = pedidosTmp;						
						$scope.alternativas = respuesta.listaAlternativas;
						$scope.nombreCompleto = respuesta.nombre + " " + respuesta.apellidoPaterno + " " + " " + respuesta.apellidoMaterno;
						$scope._capacidadPago = respuesta.capacidadPagoTotal;
						$scope._pagoPuntual = respuesta.capacidadPagoOcupada;
						$scope._disponible = $scope._capacidadPago - $scope._pagoPuntual;
							
						$scope.showPage = messageData;
						
					}else{
						$rootScope.message(titulo, ["Error en la respuesta del servicio para obtener los datos de la LCR Autorizada. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafeZ", "cafeZ");
					}
					
				}, function(error){
					$rootScope.waitLoaderStatus = LOADER_HIDE; 		                					
					$rootScope.message(titulo, [ERROR_SERVICE], "Aceptar", null, "bgCafeZ", "cafeZ");
				}
			);
			
		};
		
		$scope.servicioBloqueada = function( cu )
		{
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			solicitudService.getDatosLcrBloqueada( {clienteUnico:cu} ).then(
				function(data){
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
						
//						$scope.descCatalog[195] = {label:"Crédito Inmediato", idLi:"tarjetaazteca"};
						
						var jResponse = JSON.parse( data.data.respuesta );
						var respuesta = jResponse.data;
						console.log( respuesta );
						
						$scope._pagoRequerido = respuesta.pagoRequerido;
						$scope._semanasAtraso = respuesta.semanasAtraso;						
						
						$scope.pedidos = respuesta.listaPedidosActivos;
						var pedidosTmp = [];
						
						$scope.pedidos.map(function(data){	
							if( data['descProducto'] != null )
								pedidosTmp.push( data );  
						});
						
						$scope.pedidos = pedidosTmp;						
						$scope.alternativas = respuesta.listaAlternativas;
						$scope.nombreCompleto = respuesta.nombre + " " + respuesta.apellidoPaterno + " " + " " + respuesta.apellidoMaterno;
						$scope._capacidadPago = respuesta.capacidadPagoTotal;
						$scope._pagoPuntual = respuesta.capacidadPagoOcupada;
						$scope._disponible = $scope._capacidadPago - $scope._pagoPuntual;
							
						/**
						* REQ 85337 se valida si el cliente es candidato para reactivación
						*/
						var cuArray = [];
						cuArray.push(cu);
						validaReactivados(cuArray);
						
						$scope.showPage = messageData;
						
					}else{
						$rootScope.message(titulo, ["Error en la respuesta del servicio para obtener los datos de la LCR Bloqueada. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafeZ", "cafeZ");
					}
					
				}, function(error){
		               $rootScope.waitLoaderStatus = LOADER_HIDE; 		                						
				}
			);
			
		};
		
		$scope.servicioLCRporCU = function( cu, tipoFicha )
		{
			
			switch( tipoFicha ){
				case FICHA.tipoFicha.bloqueada:
					$scope.muestraSoloProducto = true;
					$scope.servicioBloqueada( cu );
				break;
			case FICHA.tipoFicha.recompra:
					$scope.muestraSoloProducto = false;
					$scope.servicioAutorizada( cu );
				break;
			default:
					$scope.servicioLCRInterno();
			};
			
		};/*END SERVICIO LCR POR CU */
		
		$scope.cargaTipoFicha = function( tipoFicha )
		{
			
			switch( tipoFicha ){
				case FICHA.tipoFicha.bloqueada:
						$scope.tipoFicha = FICHA.tipoFicha.bloqueada;
					break;
				case FICHA.tipoFicha.recompra:
						$scope.tipoFicha = FICHA.tipoFicha.recompra;
					break;
				case FICHA.tipoFicha.bloqueada30dias:
					$scope.tipoFicha = FICHA.tipoFicha.bloqueada30dias;
					break;
				default:
					$scope.tipoFicha = FICHA.tipoFicha.predeterminada;
			};
			
			loadView();
									
		};/* END CARGA TIPO FICHA FUNCTION */
		
		$scope.terminarCredito = function()
		{
			
			generalService.buildSolicitudJson( $rootScope, null );
			generalService.locationPath( "/simulador" );
			
		};/* END TERMINAR CREDITO FUNCTION */
		
	    $scope.camelize = function(msn) {
	          // Restore original values
	    	if(generalService.isDefined(msn))
	    		return generalService.camelize(msn);
	    	else
	    		return null
	     };
	     
	     /*OFERTA 30 DIAS*/
	     $scope.oferta30Dias = function(){
	    	 if(!$scope.mensaje30Dias){
	    		 generalService.locationPath("/ochoPasos");
	    	 }
	     }
	     
	     $scope.activarOferta30Dias = function(cpComprobable, cpNoComprobable, tipoComprobante){
	    	 	if(cpComprobable > cpNoComprobable && tipoComprobante == 1 && $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.pendienteDigitalizar){
				$scope.activaOferta30Dias = true;
				$rootScope.solicitudJson.banderaIngresos = 1
			}else{
				$scope.activaOferta30Dias = false;
			}
	     }
	     /****************/
/**I-MOD REQ 85337 (VALIDA LINEA DE CREDITO PARA SABER SI ES UN REACTIVADO DE MOC A MOC)*/
	     function validaReactivados(ctesUnicosArray) { // DATOS HOMONIMOS
				$rootScope.waitLoaderStatus = LOADER_SHOW; 
				
				var requestJson = {
						tienda: $rootScope.sucursalSession.idSucursal,
						arrayCtesUnicos: ctesUnicosArray,
						idSolReact: $rootScope.idSolicitudFicha 
				};

				clienteUnicoService.getHomonimosBsqFonetica(requestJson).then(
						function(data) {
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var jsonResponse = JSON.parse(data.data.respuesta);

								if(jsonResponse.codigo == HOMONIMOS.homonimoReact) {
									/*
									 * Se encontró homónimo con Línea de Crédito para flujo de 
									 * Reactivados.
									 * Se habilita botón para reactivar línea de crédito
									 */
									console.log("Candidato a Reactivación");
									$scope.getSolicitudBazDig();
//									$scope.reactivar = true;
								}else if(jsonResponse.codigo == HOMONIMOS.homonimoReactTaz) {
									/*
									 * Se encontró homónimo con Línea de Crédito para flujo de 
									 * Reactivados.
									 * Se habilita botón para reactivar línea de crédito
									 */
									$scope.entregaTarjeta = 1;
									console.log("Candidato a Reactivación con taz");
									$scope.getSolicitudBazDig();
//									$scope.reactivar = true;
								}else if(jsonResponse.codigo == HOMONIMOS.previoLCR) {								
									/*
									 * Infórmale a tu cliente que no es posible generar su solicitud de 
									 * crédito en esta sucursal debido a que ya tiene una LCR asociada. 
									 * La tienda que le corresponde es: {sucursal}.
									 */
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									// CLIENTE_REACTIVADO_GESTORA
									$rootScope.message("Aviso ", 
										[jsonResponse.descripcion, "Cliente Único: " + ctesUnicosArray[0]], "Aceptar", null, null, null, null
									);
								} 
							} else {
								$rootScope.loggerIpad("Respuesta Servicio getHomonimosBsqFonetica",  generalService.displayMessage(data.data.descripcion));
								$rootScope.message("Error " + data.data.codigo, [generalService.displayMessage(data.data.descripcion)], "Aceptar");
							}
						}, function(error) {
							$rootScope.waitLoaderStatus = LOADER_HIDE; 
						}
				);
			};
//F-MOD REQ 85337 (VALIDA LINEA DE CREDITO PARA SABER SI ES UN REACTIVADO DE MOC A MOC)
/**I-MOD REQ 85337 (CREA SOLICITUD DE REACTIVADO)*/
			$scope.nuevaSolicitud = function(){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$rootScope.solicitudJson.tipoSolicitud = SOLICITUD_REACTIVADO;
				
				var jsonEnvio = {
					solicitudJson: JSON.stringify($rootScope.solicitudJson),
					opcion: HOMONIMOS.homonimoReact
				};
				
				clienteUnicoService.getCU( jsonEnvio ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jsonRespuesta = JSON.parse(data.data.respuesta);							
							
							if($rootScope.solicitudJsonAuxLSM != undefined){
								$scope.guardarPresupuesto(jsonRespuesta);
							}else{
								($rootScope.consultaFuncionalidad.nuevoFlujoLiberacion)?newFlowRelease(jsonRespuesta):consultaReactivado( jsonRespuesta.data.idSolicitud, jsonRespuesta );
							}
						}else{
							$rootScope.message("ERROR",["Error en la respuesta del servicio para generar la solicitud del homónimo. Por favor, reintente nuevamente."], "Aceptar", "/simulador");
						};
				
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE;
		           	    $rootScope.message("ERROR",["Ocurrió un error al consumir el servicio de enviar Cliente Unico"], "Aceptar", "/simulador");
					} 
				);
				
			};
			
			$scope.guardarPresupuesto = function(jsonRespuesta){

				var jsonRequest = {
					"idSolicitud": jsonRespuesta.data.idSolicitud, 
					"idPais": jsonRespuesta.data.idPais,
					"idCanal": jsonRespuesta.data.idCanal,
					"idSucursal": jsonRespuesta.data.idSucursal,
					"idPresupuesto": ($rootScope.presupuestoC3Servicio != undefined)?$rootScope.presupuestoC3Servicio.fcFolioParam:0,
					"idLinea": ($rootScope.categoriaLineaAux.linea != undefined)? $rootScope.categoriaLineaAux.linea:0 ,
					"idSubLinea": ($rootScope.categoriaLineaAux.subLinea != undefined)? $rootScope.categoriaLineaAux.subLinea:0,
					"idProducto": jsonRespuesta.data.idProducto,
					"montoDeseado": ($rootScope.categoriaLineaAux.montoDeseado != undefined) ? $rootScope.categoriaLineaAux.montoDeseado.replace(/[,$]/g,"").trim() : 0 
				};
				
				$rootScope.categoriaLineaAux = undefined;
				$rootScope.solicitudJsonAuxLSM = undefined;
				
				if($rootScope.firmaBuroAux != undefined && $rootScope.firmaPrivacidadAux != undefined){
					$rootScope.firmaPrivacidad = $rootScope.firmaPrivacidadAux;
					$rootScope.firmaBuro = $rootScope.firmaBuroAux;
					
					$rootScope.firmaBuroAux = undefined;
					$rootScope.firmaPrivacidadAux = undefined;
				}
				
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				solicitudService.guardarPresupuesto(jsonRequest).then(
					function(data) {
						($rootScope.consultaFuncionalidad.nuevoFlujoLiberacion)?newFlowRelease(jsonRespuesta):consultaReactivado( jsonRespuesta.data.idSolicitud, jsonRespuesta );
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
				});
			}
			
			function newFlowRelease (jsonRespuesta){
		 		$rootScope.waitLoaderStatus = LOADER_SHOW;
				  var x = {
						  idSolicitud : jsonRespuesta.data.idSolicitud,
						  idSeguimiento: jsonRespuesta.data.idSeguimiento,
						  marca: MARCAS_SOLICITUD.nuevoFlujoLiberacion
				  }
				  solicitudService.actualizarSolicitud(x).then(
						function(data){
							 $rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var responseJson = JSON.parse(data.data.respuesta);	
								if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									$rootScope.nuevoFlujoLiberacion = true;
									consultaReactivado( jsonRespuesta );
								}else{
									$rootScope.nuevoFlujoLiberacion = false;
									consultaReactivado( jsonRespuesta );
								}
							}else{
								$rootScope.message("Aviso ", ["Inconveniente al actualizar la solicitud. Favor de volver a intentar"],"Aceptar", "/simulador");
							}
						}, function(error){
							 $rootScope.waitLoaderStatus = LOADER_HIDE;
							 $rootScope.message("Aviso ", ["Inconveniente al actualizar la solicitud. Favor de volver a intentar"],"Aceptar", "/simulador");			
						});
		 	};
			
		 	var consultaReactivado = function(jsonRespuesta){ 
				$rootScope.waitLoaderStatus = LOADER_SHOW; 
				var x = {
				 idSolicitud: jsonRespuesta.data.idSolicitud
				};
				solicitudService.consultaReactivado(x).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							if (j.codigo == RESPONSE_REAC_EXITO)
								jsonRespuesta.data = $.extend(true, {}, j.data.solicitud); 
							$scope.validaRespuesta( jsonRespuesta );	
						}else{
							$rootScope.message("Aviso ", ["Inconveniente al actualizar la solicitud. Favor de volver a intentar"],"Aceptar", "/simulador");
						}
					}, function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Aviso ", ["Inconveniente al actualizar la solicitud. Favor de volver a intentar"],"Aceptar", "/simulador");
					}
				);
			};
			
			$scope.validaRespuesta = function( jsonRespuesta )
			{

				if( jsonRespuesta && jsonRespuesta != null ){
					try{
					    
						switch ( parseInt(jsonRespuesta.codigo) ) {
							case RESPONSE_ORIGINACION_CODIGO_EXITO:
								$scope.seteaDatos( jsonRespuesta, generalService.getPathSection( jsonRespuesta.data, null )  );
//								generalService.locationPath( generalService.getPathSection( jsonRespuesta.data, null ) );
								break;
							case HOMONIMOS_FLUJO_RECOMPRA:
								generalService.locationPath( "/ficha" );
									$scope.seteaDatos( jsonRespuesta, "/ficha" );
								break;
							case HOMONIMOS_FLUJO_RECOMPRA_2:
								$scope.seteaDatos( jsonRespuesta, "/ficha" );
							break;
							case HOMINOMOS_IMPOSIBLE_CONTINUAR_PROCESO:
									$rootScope.message("ERROR",[jsonRespuesta.descripcion], "Aceptar", "/simulador");
								break;
							case LINEA_CREDIMAX:
								var nombreCte = $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+ $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno;
								$rootScope.message("AVISO",["No es posible continuar con la solicitud ya que el cliente  "+nombreCte+"  es un cliente Activo en Micronegocio"], "Aceptar", "/simulador");
								break;
							case LINEA_MICRONEGOCIO:
								var nombreCte = $rootScope.solicitudJson.cotizacion.clientes[0].nombre+' '+ $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno;
								$rootScope.message("AVISO",["No es posible continuar con la solicitud ya que el cliente  "+nombreCte+"  es un cliente Activo en Micronegocio"], "Aceptar", "/simulador");
								break;
							default:
									$rootScope.message("Homonimos",["Error en la respuesta de código de éxito de originación. Código: " + jsonRespuesta.codigo], "Aceptar", "/simulador");
								break;
						}
				    }catch( e ){
				    	$rootScope.message("ERROR",[ e.message, e, e.type ], "Aceptar", "/simulador");
				    }
			    }else
					$rootScope.message("Homónimos",["Ocurrio un error al validar la respuesta de la solicitud"], "Aceptar", "/simulador");
			};
			
			$scope.seteaDatos = function( jsonRespuesta, path ){			
				if(path !== '/simulador')
					$rootScope.solicitudJson = jsonRespuesta.data;
				$scope.guardaSolicitud(path);
//				agregarIdentificacionOficial(path);		
			};/* END SETEA DATOS FUNCTION */
			
			function agregarIdentificacionOficial(_path){
				if (configuracion.origen.tienda){
					if($rootScope.isFirmaUnica){
						$rootScope.firmaPrivacidad = "data:image/png;base64," + $rootScope.imgPrivacidad.replace("data:image/png;base64,","");
						documentosService.encolarDocSimulador(_path, "homonimosDivId","responseEnvioImg1Ipad","responseEnvioImg2Ipad", "firmas", "responseEnvioFirmas","responseEnvioFirmaBuro");
					}else{
						if(!generalService.isEmpty($rootScope.imgPrivacidad) && !generalService.isEmpty($rootScope.imgBuro)){
							$rootScope.firmaPrivacidad = "data:image/png;base64," + $rootScope.imgPrivacidad.replace("data:image/png;base64,","");
							$rootScope.firmaBuro =       "data:image/png;base64," + $rootScope.imgBuro.replace("data:image/png;base64,","");
							documentosService.encolarDocSimulador(_path, "homonimosDivId","responseEnvioImg1Ipad","responseEnvioImg2Ipad", "firmas", "responseEnvioFirmas","responseEnvioFirmaBuro");
						}else{
							createContracts(_path);
						}
					}
				}else
	                generalService.locationPath(_path);
			};
			
			$scope.getSolicitudBazDig = function(){								
				$rootScope.waitLoaderStatus = LOADER_SHOW; 						 										
				
				solicitudService.getSolicitudBazDig( $rootScope.idSolicitudFicha ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == undefined)
							validateService.error(data);
						
						else if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							
							if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								$scope.soliResp = j.data;
								if (!$rootScope.productosTarjetas($scope.soliResp.idProducto))
									$scope.reactivar = true;
//								generalService.buildSolicitudJson($rootScope, null);
//								$scope.moverDatosreact(j.data);
//								console.log($rootScope.solicitudJson);
//								$scope.cancelar($scope.soliResp.idSolicitud)
							}else if(j.codigo == RESPONSE_CODIGO_ERROR_ID){
								$rootScope.message("Aviso",[generalService.displayMessage(j.descripcion)], "Aceptar");
							}
							
						}else
							$rootScope.message("Aviso",[generalService.displayMessage(alert(data.data.descripcion))], "Aceptar");
						
					}, function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						validateService.error(error);																				
					}
				);
			};
			
			var flujoLSMCotizador = true;
			$scope.crearSolicitud = function(){
				generalService.buildSolicitudJson($rootScope, null);
				$scope.moverDatosreact($scope.soliResp);
				console.log($rootScope.solicitudJson);
				
				if(flujoLSMCotizador && !generalService.esLineaSublineaMonto($rootScope)){
					$rootScope.faseGeneraReactivado = 1;
					$rootScope.solicitudJson.aceptaTerminos=0;
					$rootScope.solicitudJson.idSolicitud = $scope.soliResp.idSolicitud;
					generalService.locationPath("/simulador");
				}else{
					
					if($rootScope.solicitudJsonAuxLSM != undefined){
						var objetoCotizacionOriginal = JSON.parse(JSON.stringify($rootScope.solicitudJson.cotizacion)); 
						$rootScope.solicitudJson.cotizacion = JSON.parse(JSON.stringify($rootScope.solicitudJsonAuxLSM.cotizacion));
						$rootScope.solicitudJson.cotizacion.clientes = objetoCotizacionOriginal.clientes;
						
						$rootScope.solicitudJson.idProducto = $rootScope.solicitudJsonAuxLSM.idProducto;
					}
					
					$scope.cancelar($scope.soliResp.idSolicitud)
				}
			}
			$scope.cancelar = function(idSolicitud){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				var solicitud ={
					idSolicitud: idSolicitud,
					marca: STATUS_SOLICITUD.cancelada.idMotivoCancelacion.reactivacion,
					idSeguimiento: STATUS_SOLICITUD.cancelada.id,
				}

				solicitudService.actualizarSolicitud(solicitud).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							consultaINE();
						}else{
							$rootScope.message("Aviso ", [generalService.displayMessage(data.data.descripcion)],"Aceptar",null,null,null,null);
						}
					}, function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						validateService.error(error);	
					});		
			}
			
			function consultaINE(){
				$rootScope.solicitudJson = generalService.migrarDatosSolicitudLSM($rootScope.solicitudJson, $rootScope.solicitudJsonAuxLSM);
				
				if($rootScope.solicitudJson.tipoIdentificacion != $rootScope.solicitudJsonAuxLSM.tipoIdentificacion && $rootScope.solicitudJsonAuxLSM.tipoIdentificacion == 1){
					var jsonRequest =  {
							"jsonSolicitud": JSON.stringify($rootScope.solicitudJson),
							"folioDigitalizacion": null
					};
								
					$rootScope.waitLoaderStatus = LOADER_SHOW; 
					solicitudService.consultarIne( jsonRequest ).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == 1){
								var j = JSON.parse(data.data.respuesta);
							
								if(j.codigo == 2){
									$scope.nuevaSolicitud();
									console.log("cancelar Solicitud");
								}else{
									$rootScope.message("Error: " + j.codigo, [j.descripcion],"Aceptar","/simulador");
								}
							}else{
								$rootScope.message("Error MOC", ["Ocurrió un error al validar los datos del cliente, por favor intente nuevamente."],"Aceptar",null,null,null,null,null,null);
							}
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 
						}
					);
				}else{
					$scope.nuevaSolicitud();
					console.log("cancelar Solicitud");
				}
			}
			
			$scope.moverDatosreact = function(solicitud){
				$rootScope.solicitudJson.idProducto= solicitud.idProducto;
				$rootScope.solicitudJson.cotizacion.clientes[0].nombre = solicitud.cotizacion.clientes[0].nombre; 
				$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno = solicitud.cotizacion.clientes[0].apellidoPaterno; 
				$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno = solicitud.cotizacion.clientes[0].apellidoMaterno; 
				$rootScope.solicitudJson.cotizacion.clientes[0].idGenero = solicitud.cotizacion.clientes[0].idGenero; 
				$rootScope.solicitudJson.cotizacion.clientes[0].genero = solicitud.cotizacion.clientes[0].genero; 
				$rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento = solicitud.cotizacion.clientes[0].fechaNaciomiento;
			    $rootScope.solicitudJson.cotizacion.clientes[0].celular = solicitud.cotizacion.clientes[0].celular; 	
				$rootScope.solicitudJson.cotizacion.clientes[0].idNacionalidad = solicitud.cotizacion.clientes[0].idNacionalidad; 
				$rootScope.solicitudJson.cotizacion.clientes[0].nacionalidadDes = solicitud.cotizacion.clientes[0].nacionalidadDes; 
				$rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento = solicitud.cotizacion.clientes[0].idLugarNacimiento; 
				$rootScope.solicitudJson.cotizacion.clientes[0].lugarNacimientoDes = solicitud.cotizacion.clientes[0].lugarNacimientoDes; 
				$rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil = solicitud.cotizacion.clientes[0].idEstadoCivil;
				$rootScope.solicitudJson.cotizacion.clientes[0].estadoCivil = solicitud.cotizacion.clientes[0].estadoCivil;
				$rootScope.solicitudJson.cotizacion.clientes[0].curp = solicitud.cotizacion.clientes[0].curp; 
				$rootScope.solicitudJson.cotizacion.clientes[0].rfc = solicitud.cotizacion.clientes[0].rfc; 
				$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto = solicitud.cotizacion.clientes[0].idPuesto; 
				$rootScope.solicitudJson.cotizacion.clientes[0].puestoDes = solicitud.cotizacion.clientes[0].puestoDes;
				$rootScope.solicitudJson.cotizacion.clientes[0].idPuestoCU = solicitud.cotizacion.clientes[0].idPuestoCU; 
				$rootScope.solicitudJson.cotizacion.clientes[0].puestoCUDes = solicitud.cotizacion.clientes[0].puestoCUDes; 
				$rootScope.solicitudJson.cotizacion.clientes[0].idPuestoSPCU = solicitud.cotizacion.clientes[0].idPuestoSPCU; 
				$rootScope.solicitudJson.cotizacion.clientes[0].puestoSPCUDes = solicitud.cotizacion.clientes[0].puestoSPCUDes; 
				$rootScope.solicitudJson.cotizacion.clientes[0].idTipoTrabajo = solicitud.cotizacion.clientes[0].idTipoTrabajo; 
				$rootScope.solicitudJson.cotizacion.clientes[0].tipoTrabajoDes = solicitud.cotizacion.clientes[0].tipoTrabajoDes; 
				$rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo =   solicitud.cotizacion.clientes[0].flujoEfectivo;
				
				$rootScope.solicitudJson.cotizacion.clientes[0].editable = 0;
				$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = 0;
						
				$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico = solicitud.cotizacion.clientes[0].clienteUnico; 
				$rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova = solicitud.cotizacion.clientes[0].clienteAlnova;
				$rootScope.solicitudJson.cotizacion.clientes[0].clienteTienda = solicitud.cotizacion.clientes[0].clienteTienda
				
				
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0] = solicitud.cotizacion.clientes[0].domicilios[0];
			    $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje =0;
				$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].editable =0;
				
				$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos = solicitud.cotizacion.clientes[0].ingresosEgresos;
				$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje =0;
				$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.editable =0;
				$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo.guardado =0;
				
				$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0] = solicitud.cotizacion.clientes[0].datosEmpleo[0];
				$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje =0;
				$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].editable =0;
					
				$rootScope.solicitudJson.referencias.referencia = solicitud.referencias.referencia;
				$rootScope.solicitudJson.referencias.porcentaje=0;
				$rootScope.solicitudJson.referencias.editable=0;
				$rootScope.solicitudJson.cotizacion.clientes[0].huella = "1";
//				$rootScope.solicitudJson.cotizacion.clientes[0].foto = "1";
				
				if ($scope.backResponseBridge.origen != FICHA.origen.homonimos){
					$rootScope.solicitudJson.contratos.contrato[0].statusFirma = 0;
					$rootScope.solicitudJson.contratos.contrato[1].statusFirma = 0;
				}

				$rootScope.solicitudJson.cotizacion.montoTotal = solicitud.cotizacion.montoTotal; 
				$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche = solicitud.cotizacion.detallesCotizacion[0].enganche; 
				$rootScope.solicitudJson.cotizacion.plazo=solicitud.cotizacion.plazo;
				$rootScope.solicitudJson.cotizacion.idPlazo=solicitud.cotizacion.idPlazo;
				$rootScope.solicitudJson.cotizacion.pagoPuntual=solicitud.cotizacion.pagoPuntual;
				$rootScope.solicitudJson.cotizacion.pagoNormal=solicitud.cotizacion.pagoNormal;
				$rootScope.solicitudJson.cotizacion.ultimoAbono=solicitud.cotizacion.ultimoAbono; 
				$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto=solicitud.cotizacion.detallesCotizacion[0].idProducto;
				$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto=solicitud.cotizacion.detallesCotizacion[0].monto; 
				$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses=solicitud.cotizacion.detallesCotizacion[0].intereses;
				$rootScope.solicitudJson.ligarTazReactivacion = $scope.entregaTarjeta; 
			
				try{
					$rootScope.solicitudJson.cotizacion.idCotizacion = "";
					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idDetalle = "";
					$rootScope.solicitudJson.cotizacion.clientes[0].idPersona = "";
					$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idDomicilio = "";
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].idEmpleo = "";
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].domicilio.idDomicilio = "";
					
					for(var i=0;i<$rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS.length;i++){
						$rootScope.solicitudJson.cotizacion.clientes[0].preguntaPEPS[i].idPersona = "";	
					}
					
					$rootScope.solicitudJson.cotizacion.clientes[0].datosConyuge.idPersona = "";
					
					for(var i=0;i<$rootScope.solicitudJson.referencias.referencia.length;i++){
						$rootScope.solicitudJson.referencias.referencia[i].idPersona = "";	
					}
					
					for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
						$rootScope.solicitudJson.contratos.contrato[i].idPersona = "";	
					}
				}catch(e){}
			}
			$scope.guardaSolicitud = function(path){
					$scope.moverDatosreact($scope.soliResp);
					var solicitudJsonString = generalService.delete$$hashKey( $rootScope.solicitudJson );
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					solicitudService.saveSolicitudReact( { solicitudJson: solicitudJsonString, seccion: SECCION_HOGAR } ).then(
							function( data ){
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
									$rootScope.ocrColonia=null;
									var responseJson = JSON.parse(data.data.respuesta);
									if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
										if(path !== '/simulador'){
											$rootScope.solicitudJson = responseJson.data; 
										}
										agregarIdentificacionOficial(path);
									}
								}else{
									agregarIdentificacionOficial(path);		
								}
								
							}, function(error){
								agregarIdentificacionOficial(path);
							
							}
						);
					
			}
			
			function createContracts (_path){
				modalService.contratosOriginacion().then(
						function(exito){
							tipoFirma = ($rootScope.isFirmaUnica)?0:1;
                			firmaUnica(_path);
                		}
					);
			};
			
			function firmaUnica(_path){
				//Se prepara la petición para enviar al componente de firma única
				var jsonRequest = {
						titulo: "Aviso de Privacidad y Consulta a Buró de Crédito",
						contratos: ["Aviso de privacidad", "Caratula de buro"],
						rutasHTML: ["credito\\webapp\\documents\\AvisoPrivacidad.html",
						            "credito\\webapp\\documents\\BuroCredito.html"],
						parrafos: [
									"<html><body><p style=\"text-align:justify;\">Reconozco que "+
									"cada una de las firmas elctronicas que seran asentadas en los "+
									"documentos<br>que se identifican a continuacion, son pruebas "+
									"inequivoca de la manifestacion expresa de mi<br>voluntad, "+
									"reconociendo que no existe error, dolo o mala fe en la celebracion "+
									"de los actos que<br>a continuacion se "+
									"indican.</p><br></body></html>",
									"<html><body><p style=\"text-align:justify;\">Reconozco ante Banco Azteca, S.A. Institución de Banca Múltiple, que he otorgado mi"+
									"caautorización y manifiesto mi conformidad respecto de los documentos"+
									"documentos<br>que se identifican a continuacion, son pruebas "+
									"(1 y 2) y que he otorgado mi consentimiento y aceptación inequivoca respecto de los documentos numerales (3,4 y 5), aceptando las obligaciones que a mi cargo derivan de los citados"+
									"documentos en términos de las firmas electrónicas que, de manera individual, y trashaber"+
									"leído cada uno de los documentos antes"+
									"indicados, he asentado en cada uno de ellos de manera electrónica, lo cual"+
									"convalido y ratifico a través de la firma asentada en el presente documento."+
									"</p><br></body></html>"
						           ],
						tipoFirma: tipoFirma
				};
				
                if(configuracion.so.windows){
                	$rootScope.waitLoaderStatus = LOADER_SHOW;
                	$rootScope.capturarFirma2WV("avisosDivId","responseFirma2WV",jsonRequest);
                }else{
                	$rootScope.contratosOriginacion = true;
                	modalService.modalFirmaUnica().then(
    					    function(exito) {
    					        if (exito != undefined) {
    								$rootScope.responseFirmaUnica = exito;
    								$scope.bloqueaInput = false;
    							} else {
    					            console.log("Terminé de firmar los contratos con firma autografa");
    					        }
    					        documentosService.encolarDocSimulador(_path, "homonimosDivId","responseEnvioImg1Ipad","responseEnvioImg2Ipad", "firmas", "responseEnvioFirmas","responseEnvioFirmaBuro");
    					    },
    					    function(error) {
    					    	generalService.locationPath(_path);
    					    }
    					);
                }
			};
			
			$scope.responseFirma2WV = function(responseWV){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
					if($rootScope.isFirmaUnica){
						$rootScope.firmaPrivacidad = "data:image/png;base64," + responseWV.imgB64[0].replace("data:image/png;base64,","");
						$rootScope.imgPrivacidad = responseWV.imgB64[0];
						$rootScope.responseFirmaUnica = responseWV;
						$scope.bloqueaInput = false;
					}else{
						$rootScope.imgPrivacidad = responseWV.imgB64[0];
						$rootScope.firmaPrivacidad = "data:image/png;base64," + responseWV.imgB64[0].replace("data:image/png;base64,","");
						
						$rootScope.imgBuro = responseWV.img64;
						$rootScope.firmaBuro = "data:image/png;base64," + responseWV.imgB64[1].replace("data:image/png;base64,","");;
					}
					documentosService.encolarDocSimulador(_path, "homonimosDivId","responseEnvioImg1Ipad","responseEnvioImg2Ipad", "firmas", "responseEnvioFirmas","responseEnvioFirmaBuro");
				}else{
					$rootScope.message( "Nueva Originación Centralizada", ["Ocurrio un error con el componente de firma"], "Aceptar");
				}	
			};
			
//F-MOD REQ 85337 (CREA SOLICITUD DE REACTIVADO)
	});
		
});