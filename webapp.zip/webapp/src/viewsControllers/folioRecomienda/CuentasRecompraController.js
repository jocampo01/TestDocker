'use strict';

var imagenes = new Array();

define(["app"], function (app) {
	
		app.controller('CuentasRecompraController', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService) {

			$scope.selecciona = function (value, check){
				$scope.ngDialogData.cuentas[check].selec = false;
				for (var i =0; i < $scope.ngDialogData.cuentas.length; i++){
					if (check == i){
						$scope.ngDialogData.cuentas[i].selec = true;	
					}else{
						$scope.ngDialogData.cuentas[i].selec = false;						
					}
				}
			}
			
			$scope.init=function(){
				for (var i =0; i < $scope.ngDialogData.cuentas.length; i++){
					$scope.ngDialogData.cuentas[i].selec = false;
				}
				console.log($scope.ngDialogData.cuentas);
				$scope.objMonto=null;
				$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
				$scope.tituloHeader="Cuentas del cliente";
			};
			$scope.continuar = function(){
				var encontro = false;
				for (var i = 0; i < $scope.ngDialogData.cuentas.length; i++){
					if ($scope.ngDialogData.cuentas[i].selec){
						encontro = true;
						$scope.cuentaSel = $scope.ngDialogData.cuentas[i];
					}
				}
				if (encontro){
					$scope.confirm($scope.cuentaSel);	
				}
			}
		});
	
});