'use strict';

define(["app"], function (app) { 
	app.controller('codigoRecomiendaDialogController', function( $timeout, $scope, $rootScope, ngDialog, generalService, authService, loginService, modalService, solicitudService, recomiendaService){
		

		$scope.validando=false;
		$scope.validandoCelular = false;
		$scope.validandoCorreo = false;
		$scope.reenviando = false;
		$scope.reenviandoCelular = false;
		$scope.reenviandoCorreo = false;
		$scope.celularValidado = false;
		$scope.correoValidado = false;
		$scope.mensaje = {
				msj: "",
				color: "",
				origen: null
		};
		$scope.envioCodigo = {
				codeCelular:{
					code: null,
					success:null
				},									
				codeMail:{
					code: null,
					success:null
				},
				solicitudJson: null
		};
		
		var TEXTO_ACLARATIVO = '¿No has recibido tu código?<br />Continúa con la captura de la solicitud. ' +
			'Puedes validar más tarde.';
		
		$scope.init=function(){
			
			if( $scope.ngDialogData.tipoPersona == CLIENTE.id ){
				$scope.modelCelular = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
				$scope.modelCorreo = $rootScope.solicitudJson.cotizacion.clientes[0].email;
			}else{
				$scope.modelCelular = $rootScope.solicitudJson.avales[0].celular;
				$scope.modelCorreo = $rootScope.solicitudJson.avales[0].email;
			}
			
			if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
			
			$scope.titulo                  = generalService.getDataInput("CODIGO SEGURIDAD","TITULO"                   ,$scope.origen);
			$scope.codigoCelular           = generalService.getDataInput("CODIGO SEGURIDAD","CODIGO CELULAR"           ,null         );
			$scope.codigoCorreo            = generalService.getDataInput("CODIGO SEGURIDAD","CODIGO CORREO"            ,null         );
			$scope.celular                 = generalService.getDataInput("CODIGO SEGURIDAD","CELULAR"                  ,null         ); 
			$scope.correo                  = generalService.getDataInput("CODIGO SEGURIDAD","CORREO"                   ,null         );
			$scope.etiquetaCodigoSeguridad = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA CODIGO SEGURIDAD",$scope.origen);
			$scope.etiquetaCodigoCelular   = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA CODIGO CELULAR"  ,$scope.origen);
			$scope.etiquetaCodigoCorreo    = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA CODIGO CORREO"   ,$scope.origen);
			$scope.etiquetaRecepcionCodigo = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA RECEPCION CODIGO",$scope.origen);
			$scope.etiquetaRecepcionCodigo.texto="Reenviar código";
			$scope.etiquetaRegresar        = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA REGRESAR"        ,$scope.origen);
			$scope.etiquetaCorrecto        = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA CORRECTO"        ,$scope.origen);
			$scope.etiquetaReenviando      = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA REENVIANDO"      ,$scope.origen);
			$scope.etiquetaIncorrecto      = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA INCORRECTO"      ,$scope.origen);
			$scope.etiquetaEnviado         = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA ENVIADO"         ,$scope.origen);
			$scope.etiquetaNoEnviado       = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA NO ENVIADO"      ,$scope.origen);
			$scope.etiquetaCelularInvalido = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA CELULAR INVALIDO",$scope.origen);
			$scope.etiquetaCorreoInvalido  = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA CORREO INVALIDO" ,$scope.origen);
			$scope.btnValidarTarde         = generalService.getDataInput("CODIGO SEGURIDAD","BOTON VALIDAR TARDE"      ,$scope.origen);
			$scope.btnValidarCelular       = generalService.getDataInput("CODIGO SEGURIDAD","BOTON VALIDAR CELULAR"    ,$scope.origen);
			$scope.btnReenviarCelular      = generalService.getDataInput("CODIGO SEGURIDAD","BOTON REENVIAR CELULAR"   ,$scope.origen);
			$scope.btnValidarCorreo        = generalService.getDataInput("CODIGO SEGURIDAD","BOTON VALIDAR CORREO"     ,$scope.origen);
			$scope.btnReenviarCorreo       = generalService.getDataInput("CODIGO SEGURIDAD","BOTON REENVIAR CORREO"    ,$scope.origen);
			
			$scope.CLIENTE = CLIENTE;
			$scope.AVAL = AVAL;
			
			$scope.textoAval = "Ingresa el código de seguridad que le hemos enviado a tu <span style='font-weight:700;' class='fVerde'>Coacreditado</span>.";
			
			$scope.textoInicio = $scope.etiquetaCodigoCelular.texto;
			
			// Texto aclarativo.
			$scope.textoAclarativo = TEXTO_ACLARATIVO;
			
			if( $scope.modelCelular != "" && $scope.modelCorreo != ""){
				
				$scope.codigoCelular.visible = true;
				$scope.codigoCorreo.visible = true;
				
				if( $scope.ngDialogData.tipoPersona == CLIENTE.id ){
					if($rootScope.solicitudJson.envioCelular != 0)
						$scope.celularValidado = true;
					if($rootScope.solicitudJson.envioCorreo != 0)
						$scope.correoValidado = true;
				}else{
					if($rootScope.solicitudJson.avales[0].envioCelular != 0)
						$scope.celularValidado = true;
					if($rootScope.solicitudJson.avales[0].envioCorreo != 0)
						$scope.correoValidado = true;
				}
				
				
			}else{
				if ($scope.modelCelular != ""){
					$scope.codigoCelular.visible = true;
				}else{
					$scope.codigoCorreo.visible = true;
				}
			}
			
			$scope.textoCodigo = $scope.etiquetaRecepcionCodigo.texto;
			
			// Se invoca el método para validar tope de reenvíos.
//			cellMailCodeForwardingCheck();
			
			$scope.bandera = true;
			
			if($rootScope.consultaFuncionalidad.liberacionSinCodigo) {
				// Validar.
				if($scope.ngDialogData.validacion == 777) {
					$scope.showReenvio = false;
				}
				
				// Reenvío.
				if($scope.ngDialogData.validacion == 666) {
					$scope.showReenvio = true;
				}
				
				// Se configura la Etiqueta Inicio, según corresponda.
//				$scope.textoInicio = getLabelTextoInicio();
				
				$scope.bandera = false;
			}
		};


		
		function codeValidationError(opcion) {
			if(opcion == 1) { // Celular
				$scope.validandoCelular = false;
				$scope.codigocel = "";
			} else if(opcion == 2) { // Correo
				$scope.validandoCorreo = false;
				$scope.codigoEmail = "";
			} else { // No es una opción considerada.
				// TODO ¿Qué rayos?
				$scope.validandoCelular = false;
				$scope.codigocel = "";
				$scope.validandoCorreo = false;
				$scope.codigoEmail = "";
			}
				
			$scope.mensaje.color = $scope.etiquetaIncorrecto.estilo;
			$scope.mensaje.msj = $scope.etiquetaIncorrecto.texto;
		}
		$scope.valida = function(){
			if($scope.forCodigoCelular.$valid){
				$scope.validarFolio();
//				$scope.guardarFolioRecomendador();
			}
		}
		$scope.validarFolio = function(){
			var x= {folio: $scope.codigocel};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			recomiendaService.validarFolio(x).then(
				function(data) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var jsonResponse = JSON.parse(data.data.respuesta);
						console.log(jsonResponse);
						if (jsonResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							var jsonResponseCuentas = JSON.parse(jsonResponse.data);
							console.log(jsonResponseCuentas);
							$scope.guardarFolioRecomendador($scope.codigocel);
							$scope.mensaje.color = "";
							$scope.mensaje.msj = "";
						}else{
							$scope.mensaje.color = $scope.etiquetaIncorrecto.estilo;
							$scope.mensaje.msj = "El código capturado no es válido";
						}
					} else {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Error " + data.data.codigo, 
								[generalService.displayMessage(data.data.descripcion)], "Aceptar", null, "rojoR", "rojoR",null,null,null);
					}
				}, function(error) {
					console.log(error);
					$rootScope.waitLoaderStatus = LOADER_HIDE; 
				}
		);}
		
		$scope.guardarFolioRecomendador = function(codigocel){
			var x= {folio: codigocel,
					idSolicitud: $rootScope.solicitudJson.idSolicitud};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			recomiendaService.guardarFolioRecomendador(x).then(
				function(data) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var responseJson = JSON.parse(data.data.respuesta);
						if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
								$rootScope.solicitudJson = responseJson.data;
								$scope.closeThisDialog();
						}else{
							$scope.mensaje.color = $scope.etiquetaIncorrecto.estilo;
							$scope.mensaje.msj = generalService.displayMessage(data.data.descripcion);
						}
					} else {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Error " + data.data.codigo, 
								[generalService.displayMessage(data.data.descripcion)], "Aceptar", null, "rojoR", "rojoR",null,null,null);
					}
				}, function(error) {
					console.log(error);
					$rootScope.waitLoaderStatus = LOADER_HIDE; 
				}
		);}
		
	});
});