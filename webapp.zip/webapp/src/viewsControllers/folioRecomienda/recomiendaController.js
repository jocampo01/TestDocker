'use strict';

define(["app"], function (app) {
	
	app.controller('recomiendaController',['$rootScope', '$scope', '$location', 'messageData', 'generalService', 'modalService', 'solicitudService', 'tarjetaService', 'callCenterService', 'clienteUnicoService' , 'recomiendaService',
		function(  $rootScope, $scope, $location, messageData, generalService, modalService, solicitudService, tarjetaService, callCenterService, clienteUnicoService , recomiendaService){
		
		$scope.buscarNombre=true;
		$scope.obligatorioNombre=true;
		$scope.buscarCU=false;
		$scope.buscarTaz=false;
		$scope.obligatorioDes=true;
		$scope.obligatorioPaterno=true;
		$scope.obligatorioMaterno=true;
		$scope.obligatorioCU=true;
		$scope.obligatorioTaz=true;
		$scope.verHomonimos = false;
		
		var csstabs = {on:"tab tres rojoLi ", off:"tab tres rojoLi active"}; 
		$scope.tabFirmadoCSS =  csstabs.on;
		$scope.tabSinFirmaCSS =  csstabs.off;
		$scope.tabInformativosCSS = csstabs.off;
		$scope.busqueda=false;
		
		$scope.titulo="";
		$scope.mensaje="";
	
		
		/*Datos del cliente*/
		$scope.cliente = {
			nombre: "",
			aPaterno:"",
			aMaterno: "",
			fechaNacimiento:"",
			pais:"",
			canal:"",
			sucursal:"",
			folio:"",
			taz:"",
			tipo: "",
			tarjeta:"",
			
		};	
		
		$rootScope.datosGenerales=[{
			"cliente":"",
			"foto": ""
			
		}];
		
		$scope.foto=[];
		$scope.responseJSON="";
		$scope.marcoFoto="9j/4AAQSkZJRgABAQEAYABgAAD/4QAWRXhpZgAASUkqAAgAAAAAAAAAAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABgAGEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2SKKEwRkxISVHO2gxQ/8APJP++aIm/cR/7ooLVokSyMxxf3F/KomSP+4v5VITUTGrSJImVf7o/KomA9KdLMkeN7quf7x61nz6vYwvse5TJ9Of5VVkDLLGoWY+tKJY5RlJFceoNMY1SSJuMZ2/vH86haV/77fnT2NQMatJE3EaaX/no/8A31TYp5TcRgyOQWA+9TGNNhP+lRf74puKswTdz1GiiiuA6Dn42/cp/u0FqhRv3a/7tBat0jNilqoanqCafatM/J6Kv941aLVxXiO9NxqJh/gg+X6nvT2Ay7ieW4kMkzl3Jzk1ATSk0wmgB0VxLbyeZC7I3setdFpeti6xDckLN/C3Zq5gmmbyjAg4IOQfSqTsJnesaiY1XsLwXlkkucvjDj0apWNbIhjGNNgP+lRf74pGNJAf9Ki/31/nTfwsXU9UooorzjpOTDfKPpQWqLdxSFq6ktDJvUeWrzid900pLZO48nvXoLHIIrz28ga1upYTn5WwCR1pMERE0wmgmmE0IYE1GTSk0wmmJm94cmO2eLtw1bTGsjQIlWzabHzu2M/StNjW0VoZsaxogP8ApcP++v8AOmMaLc/6XD/10X+dXLZiW56zRRRXmHUcQW5pC1Ru3zH60wtXZFaGDJC1YPiGykuFW5iAPlKdwz/D1/xrYLUxyGUg8gjGKq1wucATTSasX9o9lctGwOzPyH+8Kpk1nYYpNNALsqjkk4xSE1f0e0a4u1mI/dxHOfU1SVxM6CytvsVosO7cRyTUjGlJqJjW6ViGDGi2P+mQf9dF/nUZNSWn/H5B/wBdF/nTl8LBbnrlFFFeWdR57I37xv8Aephamyt++f8A3qj3V3xWhzvckLUwtUE11DAuZZFQe5rFvPEajK2iZP8Afb/CnsIXxM/y24zzljiudJp89xLPIXlcu59agJqGUKTXQaA/+iSjv5mf0rnCadDdTWz74XKn27046MGdoTUZNY9tr6Nhbldh/vDpWnHNHMuY3Vx6g1unczH1Naf8fkH/AF0X+dQ1Naf8fkH/AF0X+dEvhYLc9coooryjrPLr+5W28+Z/uoSa5C41i8nYnzii/wB1OAK6jxDpWqTQSpDp13IWl6JCx4z16VzP/CO65/0B9Q/8Bn/wrs5lZamFmZ5cs2SST700mtH/AIR7XP8AoD6h/wCAz/4Uh8O67/0B7/8A8Bn/AMKOZdx2ZnE00mtI+HNd/wCgNf8A/gM/+FNPhvXf+gNqH/gM/wDhRdBZmYTTSa1P+Eb13/oDah/4DP8A4Un/AAjWu/8AQG1D/wABn/wp8yFZmZQCVbKkg+3WtP8A4RrXf+gNqH/gM/8AhR/wjWu/9AbUP/AZ/wDCnzILMgh1W8hYHzS4/uv3rqtLnW5ktZk4DOvHpzXOf8I1rv8A0BtQ/wDAZ/8ACuj8O6NqsCxifTLyPbNn54GHHr0pqas9RcruexUUUVwHQf/Z";
		$scope.fotoCargando="R0lGODlhyADIAPYPAP7+/tjY2Pz8/Pr6+vj4+OTk5Pb29vLy8uDg4PT09MjIyOjo6OLi4sbGxubm5tbW1pKSkurq6t7e3ry8vNDQ0MrKytzc3PDw8NTU1MDAwNra2u7u7sLCwuzs7M7Ozr6+vtLS0oaGhpCQkMzMzMTExLKysrCwsKioqJycnJiYmKCgoJSUlKSkpKKiopaWlqysrKqqqra2tpqamp6enqampq6urrS0tLi4uLq6uoqKioyMjHx8fISEhICAgH5+foiIiI6OjnJycnZ2dnBwcHp6eoKCgnR0dGZmZnh4eP///2xsbGpqagAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUEU/eDQ5Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8eHBhY2tldCBlbmQ9InIiPz4AIfkEBQUADwAsAAAAAMgAyAAAB/+ASYKDhIWGh4iJiouMjY6PkJGSk5SVlpeYmZqbnJ2en6ChoqOkpaanqKmqq6ytrq+wsbKztLW2t7i5uru8vb6/wMHCw8TFxsfIycrLzM3Oz9DR0tPU1dbX2Nna29zd3t/g4eLj5OXm5+jp6uvs7e7v8PHy8/T19vf4+fr7/P3+/wADChxIsKDBgwgTKswFoKHDhxAjSpxIsaLFixgxgsvIseNDARciRLggwKPJjBtPqpyYwEKAlwEsJFhJE2LKmjQFuIT50kJJnDRvAj15gSfPC0NXCk3aMYJRmB2YnlwqFaPTpwEiVPVIdaWBDRsINMWateMAsGKHdjU5oABPrRn/rz6Fa5WngwFA15rdeTQuWboWixq1kDboN5wOsPqsixUwxQF87eLUyzHyW8ZzMQ+efLimZZgaClOUa9SxRAIayFrg7A0x2QAFLpK+bNEtWQesu+FE/XpmxdkwTUM88Dp0bm5AF7yW8HMi8JfCHQqQ8Do61841B6Qmu+H334obXlvAe3zb0PBkNTSP+LzsRMivu+fFXlMAgtcLRn+fmJgsgqSUeURceqI91F50CbwWgG/ztZaUbVgx4Nx+EAnAwGu4AUjfbtthdYBEB0okGFYakKfWhji1FwBz7FEoHXUuNqgbU/CRFRVEIeIo3noyIjeRAAds8GFH6JFoYkM5OsQb/1lIcTSAAwhEwONDaxEAY0xNYmQhhjo2BlF/ETrJAAcTlNnAkBGtdSVMDDBo0YBkGWCgiwm+JudFAnRQQZl8TtDAlAB01QGGR1IE5lMSOjSiUVkCcOFtGB0AQp+USiBRV2s+pcGNFS2JFYM6PbVYQ3UaaRFqH1BK6Z9poghAh8uhOSF3DxkQmQV3NlTkU/K95wAJqqqawZRd3acgm7lGFCpWjQIAkkgkQbQoT5b+uMEIwQarALGuTqugBgsACoC3AajXkQCwwiTrQwlgkG22BXDrYESDHsuTBhsACuFLGqwbabqxRTSABBm8G+yoNrnakAGP2vuSBP4KACYDBXJEQP/DDvAocQMGq+pBs1Qq3BBImR5bQMUCGFDoSQMkMOUFHnRMKQnhVhSgsxGk+62UW0k0QAAy9/mBBCu3Ou+ph9qbaM/SYRt0mRi4abPIEiXQsL29Ms3A0xNUkPVFN1e4wWdYZcg0ABQEzUG81x3tZM4mn91Q2gZ/UOJUVCOt4NdbSWAwBf5yFHZFBxg7mLhMEUCmqgpwqtLgFQkw9r1SMx0BpRwwgLjgeb8tgQUFJCs3ABt4wEEDxvVo3uisVwV567CD3XnstFv0eu0nCUBAArz37vvvvhNwZEoGFKCzw/yejLtDEcCQQwjQRy/99NTnAANcGxlwPPL3Vtx6BEBQL/7/+NLrgNtG+3JPVsC1w0D+++OfIMBG26sPGu4CPA///tHnMMBG9rMX7gjAvwJC73+HqV8ANTBA/Rnwff5DXwBfw77YCcB9D3zfCRDYGk9NECbjWR74Mjg+IGQsJW1R4LE0UICiwW4BziNh/05wl0ChSAA4zKEOd6jD5UlEAAMIohCHSMQiCvEnt/Nh7ZKoxNgxsYmte6KyImABDbQpdgyzgAR4pjpt4ERysOpX6w4QxnyVx4s0SUDJYrK5oSzLKAgIXEekSID0GYVvVdnVU5T3uNlNUYUV7JkdjaKBCLjQdn58yOTsZTamDVJUZpxjIgGQAMPZC2R55N4VOee2xyTt/1hLk9vVGOm9S3VOAHBDXiFhh0oV3ouLU+uktMiGoYq17JBOMsCU6qg+C0SLInphmPriqKyJlfIiwnxJIx2iRvUxQHQhkyUAVKSYSEJklGL0yAXStcyRbcCVPHFcNGcEET1+awEuJJe5OIIuZv1oAeB8CSaLhbxnUuSNRlnXs0bCI3KtCHEXq6cpZelKCWByTrRyiK14QhhFVicwayTkQMn5kIjyqwNt1I6dpPMZhJVKU8d0SAcU+B+jUVSktcTIJ9n0EH82apSSuciT4jNRH0WkZJu8yEefkqwkUVJBlZtIMqkFqCpdyZcdsaRRlulTAKz0JZrjyAX4IoFSUiZIB/9oYzmLU6CmajShUhUS4qT4I1oGQJzTjBEA6qUYXOJNmitREYu6lJmbPpQpZI2IBxkFIrUCAE4gxeskL/LIAIQSoXWNCExh0k3DwNUkO70XNJHkVwAYQEFyfOtJVzId/OjHSxNRjn+0ipLBUsScIDxkUz9SPzxq1qY5aa13QDsR1PbEraV9LEdEixUEbG61H7GodSSpW4zslSeZpSxtJwJYQoY0t5s1yVNhI5vKPqSwjW1bdD1Cy9TNNrEUOW5PzpgNnNByuMyzLmI3U5O8OlUxpAWussiWXeJudy9POWiLlgseUeFWdsXFyEwvyhH59pWx/wXwfU1CALAkWLngvUh8g8OioQCfzcBRNK1UMMw699bEpU30cE46StqziTiNt5os7U5Mk7NAq8RyW4iMZ0zjGtv4xjjOsY53zOMe+/jHQA6ykIdM5CIb+chITrKSl8zkJjv5yVCOspSnTOUqW/nKWM6ylrfM5S57+ctgDrOYx0zmMpv5zGhOc0ACAQAh+QQFBQANACw8ADIAXABlAAAH/4ANgoOEhYaHiIYSiYyNjo+QkZKTlJWWl5iZmpucnZ6foKGio6SRBaWEi6iRqqULAbCxAa2rtbaXEgC6u7y9vr/AtLeMwsPGx8jJysvMzc7PnQvQ09TV1tfYtcXZ3JwCBxsHAN2aAhsSsRIE5JYACQyysNuG0tALwL0EDvGyG87zlQRE0MBPVq5jADEJuICuoCwN40w1SkjKHTyH8RhEZHdowCuM/C5s5DjInAWQ8TREGBnq1KUCseoRAnCgIcpYBdaRJEQA5s104naWHPgTloYNLEkCuFh0wQChhTYUDcAgQSabIAvg28rVl0+UFkRCPfTVoUoBn1wmk4rRwdOxif8EYI2FwCrcRgcIxrKAdBjFUAYKWJAQ4e3dw4gTK24wgIDjx5AjQx6AdueGDDBoaN7MubNnGBn8sdvwwrPp05xfdGCXAbXr0x/YZX5NezOMytkG1N6tmdyAE7xpw2Ad/HUG3NlIFz+tmuNl4Ms1g169U8CA69iza99OebH37xwlaFBbS0OKHTxKbEAOvgGIIEPiDyHy4QCyv5su7JDP/wcInd/hwN+AQ8jAgGGJCSADgQMKUcN6m8zlkFZdVYiPggwSuAMHdiHGQYYM6vAAgKZMFQCFFqboCwEQgMjgDAUgCFUCJgjhYoM2rMeVhFkZI0ABC97IXw8KdFgKeZQgWci1ACCEICR/EEjAHidKUvkLARkQ8WR8QdgwZXUbwADflgpMUmUqyAjAwApb6vAlKljh9wgBHvAgJBEyriKhnI8kgIONIOaQZyEyNXLmMQK1MCaBE7THmAQiEBgCiWhyUqgkl1pCgAI9yBfCod4l4MEHFCTwJiV8KnPdqY62ugyokpQVD6yu1mrrrbjmChWtuiaTi4rA6pKqNsEG+1E8w36SaSjJktKsJbz2Ku201FaLyLOHYTtKIAAh+QQFBQAXACw/ADgAWQBZAAAG/8CLcEgsGo/IpPLoWDqf0Kh0SkU2q9isdsvter/gsHhMLpvP6LR6zW67sde3fE6v2+/4vH7P7/v9cXiBf4SFawyGiVyDio1IiFkMAZOMVZCOmJmOlZp2DgCgoaKjpKWmnJ17qKmsra5el6+ys7SEAAIDubq7vLsCAI4JDwoNxcbHyMkVAQmJCRXJ0dLHFQeGD9PZ0g/AfwDE2uHGFYUC4ufFAoQC4OjZFere2O7ZD4bP9NLV3YTC7fkVHhyIZ+iWgIMIEypceJBfrYcQ68RKU6BGihkkrEW8YAGCiI8iUowwAPGADJAoWVgYUKsCypciSiwg2AqACZgvV3DQeOaTqb6fQE2VwAlTBgUCrigQxUkDwYCgohxMmkq16iQGULNCHQBjKc4YEWhiMsBhhdeXLhoccJhlFRkAEYaeRTnjAVIzE6fkJSJAQou5KGG4pbK3C6cRKQCDbMDWEYADEzwqtvek8B0HLxSfeDUgwIy5KcSmIqAg8VIWooUMVp0HwIYYkmGOeCigwAmYLcysZtJlwAMUIFVE2CiEQIARGu4SF3JwuXM5lvVanbr7ufXr2LNrJ1N9u/dO3dWE/w5lfKEgACH5BAUFABEALDcAMgBhAGYAAAb/QIBwSCwaj8iiIcJkWpbNqHRKrVqv2Kx2y+16v+CweEyudsrotLp5XrvfZrg8Tm5/C3Os5W3/7vNcf2J9gIWDYxZJiouLgmuEXo6GcpCTllqVl5p0m5RgHYqZnVGiYaVXF6Nwp6qXoEdQrZassoa0tYC3bLhNkqZGum7BTKllw7xRCMZcylwXvswGjEIJXB0B2NnYx1rNtd7MedxlsVXQh6O651nja3hX61TtVOVY4Mj4+VvD81TVV+/CBEwzUN+VerMMolPIUAoCbRAjXphGMUmxLQjFPIvIsUDFj0UKNmzVL0sBjtlegQRZEs0/VfFG5rk4KqYckTJz6tzJsycW/wACggodSnQoAJ9UCBTQgLKpNg0FCCBlQoCp06vZNEhFehKr1wA4c1r9elXD0Z4AyH49yxPAWLUozXKF69Qj0qp0OVrYendpXmxQCbCdutLI1MOIExuyAFVa4ccdFMTA8UCaYi8OSpjYbCKGhgG4bKIhEIOz6Q8OcKl8PC2A6dcmFNC8TEUB7NclMDhmfWQjVo+8p1W4DfuGhQHBh2RsZYH47QwLBJDp+hV48kUCODi/XWG2NYYDMGjebtpG5Uhqwy7vIqADggNGLtgmbxoHAtBZ7mV5WSVsFgEIoLDDgDAg5MAE9JnGASiF+MeFABT4MOCELSBXxAAalJbgZg8g4f9dKxf0MOGIHggACwjjJcjAGA5GIBopVIww4og5TORhAxtmMNgjTc1mgTaScDDjiDiYiIQABeBAXwy1/AiRIxYMOWEPDiwyQAA2bPfBTWoM4IKUA54g2CIGeJDiaxp0sRuZ1qC0mgRgDpgmJtq9NgF+esxxDUerCQBDnC6sqQiASm42gY1JJLABf1p8aMWeEa0GQAcigqmAkdMMsFQByMHxIhOQQiSpAB/EGcIGYOyYjptGGKBDnDHg2VOo2kgqBAhx+tBiLdYVQWtKRwwgIJgt8MXTr9sgwUCcO2CAFLIB2CqEACbECUEC10FmCqse8hAnB9LlI+0Q0I4LlJBghtCGkivcIkGACHGaEC4v2IbSLhIPMNtrtovsekW52LUQ5wnzygTwIg5IKGUO/FL0qTz3HmkDmDkUXNM+EXsYgpQ1WFzIw1IczEgFQ+awgccNbssnRQPgMCINHaBsiaOPZpyEpiSQwGnDPCch8jQCDIBpz0QTUS5tSH+cdBgGgLx0Exd0sC4aQQAAIfkEBQUADAAsOgAyAFgAZgAAB/+AAIKDhIWGh4iCCQyMjYuNkJGSk5SVlpeYmZqbnJ2en6ChopARo6anpqWoq6yRqq2wDK+hs7G2oLW3nQuxubq/mL7Aw5PCxMeMxsjEysvAzc660NG209SwEYm8172Ij9zY4MjW4qfkyeW4hufpmuztn++tCYmFB5sRAfr7+vKt2+0AwoP0bZg/TgcH9mJVUCErgQ6p+bs3DGJEUw3DXdzIzSLHUBk/ipQ4ciDFkihTqlzJsqXLlzBjypxJs6bNmzhz6tzJs2dJevWCCjV0wAKGAA4G5LwAomlTDBEE2BzwwKnVABekzlxgtSsICfRkSvDqtYBSmGPJdn0QdSihkNz/IqglG+AAgJYANMwli8DA3UoJfwkosNcrhgVnbcHtdGABUEIG0hZ2+qCDVlAnsdmQIQPFhwGGLgSYbFXDYmp5UXBefUPAoQgYSDt1AC+BitW4NSAaQFg2iA7HBFzI8OIFB7uEAuDGfeKxoQQWZAdIlUlAgCBHsh8xYoEQiOW4K1gCIHoyhr+/LmDXnt3I4wLgV6voEFTAgthzAwDgt8+jKA7ssUfCIAKYEB9nnwk1AAJz+eJcPadFUkOA2tVAyAIHclaAWwno1ZV+tixQyAsUZvdCJB9kWAMBbgGwQVVNBeAXAAdskBksJJb4gj0zZIgBJ8JFkBUyOVK4YyEjZMgC3XItCrJMkQEeSQgBJ2SowGURQcmelIRYkOEMgQGjpXYnTrLZgTck5tCYJiISgWoHSrARm0eUOUkGGb5gwEV0cmlPCxmCwGeJddbz3YEtXJAloX4WMsALGXJADZOI9BkUAhmiEGYsfWJyQ4YfoNeOpUF1ACd4NKzJaCYNHHhCk036pwmpQSXAQnwZqKqjW8otR4NdCtFanwKnTgBssIy2KABsILQF67PQCtIpkB/RaWG02GbrVgaEDqjtt+AWcoERFBpBabjoYksVudoZoVu68GIrgAEdfFBcBlnFK1QgACH5BAUFACIALDcAMgBaAGYAAAb/QIBwSCwaj8iiQcRsLpvQqHRKrVqv2Kx2y+16v+CweEwum8/otHrNbrvfcLIjTq/b7/i8fs/v++8baoF9g36Ff2ZziHFPi46PYAeQk5SLh1qXcZKVhFwGSUUJnF2KcJtYpWGZao2jkKtQp32yWLRarbVmtnSprmOwbKJxvWi7fLi+hsllxGgboNDRQ8BTyJjLTcbYk8/S3kjUwdvjWeHk5+jp6uvs7e7v8PHy8/T19vf4+fpun9/+SAYKWJAQQYC9AxoCKAygwRw6ARYWSkRwAACgfxgBbJDIMUABAvAKdOSoIQIZh3REjuRoAaUUa3w2ruyIQJg6BjNHflwXIWFO/4klDb6ByQWAgQ0DjBBQ+XOhhQtlbKYBcMHDhKsYBBhJIKGpRAZE+zi4SnYChSkCNvj0GqCDRkcEPpQl6wCJgAVrm2prc8DDhw8U+g0pMJcsCQJJCOD0ikDL3ivdhDCAEKJyCAgFiCAoTNYCtANdf2qwk4Cy5coQEAvZwPnqh4rQOuSlaaWZGAqnT4OAUqH1hKxZHMwEJhha2CgZclvOQIS1b7fSDCDoKEEom7pEPiiv/KEIBt8Vkno7EFGhBNVCEmyQWo6L9u0TlMhtndnfgQ2P2bxXHr+IBN8cgOTLfrn1R8QAJPg22iOwFUHgaQYSsYBvE+T3x4OWRTiEAFa1RrWBdZVgWJmGQxxAoUmjiBgCiUM84JsC6GXkj0tRqMiiEARk4BsCFsUEio2gbNYaB8f1AWQSAjTgWwA95pEANEcmEQGFFuoRZRIU+IZBiNutGI2JQ3IJnzQBtEaCjN7YpsWViXHA2QNN0tEglF3eaARhcxEpJn9baFAWCEU604WNXBzAAAJQpVjnP1qh6ShGKnb36KSUHuFBlxRUqqmmB5h2GgSBniOBp5cVUA8BF4xwlQfsxREEACH5BAUFAA0ALEYAdgA6ACIAAAf/gA2Cg4SEAhsBCwQAjI2Oj5CMAwYChZaXmAczQ5wrDJGgjwYFAaUOAJiplgMunK5GFKGhBxqltgWoqroKrr1ICbKQArW2tge6qgk9vb0johoUFBYDjwfFxRICwaACJcy9HI4RNTTlNDUdjojXthHbkQtG364WjQTk5uU11IwG7LYaFr1rNEDFPE4i+AGwkC+fBEcM/pka2CjAwSFBNDgC0dAcCEf+JAYANnBAjossBDKi0LFcLEcORCLQ9o7DRSSnHLFs+ZIgsX8b3l3YcfGGwpUtafRs1EHktGACalzkcQHSzo5LG0kQ6U5WAXkHPdDUmTQrI2sSA4YaIOOiCwOR7K42NMuIlERcoEBcDPIwbllQISWSfETgx8UTKh/JzUeX0QKZYxkJ+HBxR1e/PEMNExlUHZGLHyIr/htq3b+nkk9c/HFA1mJzFHRtlXgZQZCLH12TDpVApFoBKC7KSIwZ6za7/04RIDrPCIJtr11uI/DzWj0CPg7ug75bVgSJFgQQYDHPR1XumbcJsJAcwIAF2ZkpEA0qutKBpm2hFrAgOKcgN9BXX3fBfGeLA0e5hwAHHFz2jn2NgULABhsQ54gAAuqWHkUcUgRhhyC+o0FS9YRoImD45FODhSeeKIADKZ7jYIs0utdbNBrAVWMgACH5BAUFABUALDcAMgBgAGYAAAb/wIpwSCwaj8ikUKJsOp/QqHRKrVqv2Kx2y+16v+CweEwum6/MMzStTrLb8HhVAqjb7/i8fn9/y5F+f4KDhIVPCIaGHWCLiUSNjpGSk5SVlpeYmWKBmkqQnaCGnF8HoYihYh15p4OjYqytVp9/DE2uqLi5jIMIpUq1V8BdwrrFjrPGycoVt8vOx3zR0nnIcr6xz8/NYsTZ3t/g4eLj5OXm5+jpw+rsTt3t8PHyZhIa72b38tVkCAH+/wG2mVM1rWC0ffPUCIy0MCGYfA51NUxyAEGHAY4mSjmQJ4ENESBfLAjmBFYiAS9AqlyhId0DlTBdGHgGsQIBFDBhBsAzwAEC/wQRBDgD0CAnTAp3DoxowLTBiGvGNqwwqrKAnQFLmzIdIdSYgI9URZwQYGeBVq0R2iC8giCsCAgM7jA427SmF5NE+vnTyMLtjQF3ENBlireLhH+FiRzYAPUJBbcuCNoRPDhxl7VYEuAMq4Bs4MENLGfi4FYFRzyU6Yq+FGFq2J2rQK+uJMCE2xoE9KQ+i2CPXUIS3EKwqlt2lcZxWridALh4ZVQAPLhNsYHPbq2zJR1I4XaEkutNs0ea4LaFgWjgCTcRf8YBBLd00MuWhnwQWKolmls33mkAd6orLDBNeqFhEZ9BCO4xwGZGceCZfM+hkeCEeQxwA1UonCYNgewVIlJABwyq9IBBHKIhxwb3QaAAgiWiIoADFFBQHYv84UIhABzeqOOOPH5WWY9ABmmQWYNFIOSRSPKUlVZcJekkkhcs6ZSGT1bJowAE+ISAA/pZOU0QACH5BAUFAAsALDUAMgBiAGYAAAf/gAuCg4SFhoeIiYQWio2Oj5CRkpOUlZaXmJmam4YdnJ+gm56hpKWdpqiHo5irqaGMoa2TsK6QtJaytbqVuZIWAMDBwsPExcbEt5+9kcm7pcvO0YrQ0pwSuNXZjtTa2dyJF93P4uSE3+W65+iuHcXh67vqg/K7zbzE9OXvmfT78Jz5Il2wVypBpA4BEipMGNDStX+F/Gl72I0gNkUUx9kyJdFUgUYWFi7suGAZSV0nKaWEyLJaQ4wGFX28NPNTTUcrW6Z6qbOnT00XjgkdSixnqoE/DRlNyo+pU0cxKz6VttSVxVQ3p2rdyrWr169gw4odS7as2bO6sqJdG0ot27dw/7cKmCuAqN27ePPqLVoiB48ZFgREcyuNAAkeOxLv8IFBcNwFAh6IUEz5R1S2Ahy0oMx5Bwm4B2z46My5BdsBCn6Q7sxinYWqjwRoWLGadIW9e2FvEhCBRm3SKMwmuNHjN2cfMQj0zDdghGrjlFsUqCvMQIQDjstdJSQAQQrolEU8IDCMQAUT6EnoLkSYUEZNBGKAV8yDxOVBDdDrL1Egd7UBDcyXmAkdUDcMAvolGMMAm6wHDjECEDAZeDMgMIAxA9yQYIL9CSPABRF00JGDmxBQnHFAgGCAUA9smKAE1YWkkAXKPdKOUCQKMgAQvxXxAXZCJWCDi/rdCIAAMi60nf8uAnxQGwwRZJfICESixwEhF4ikUI6gEMAjZynQaFcEVZpQgpEAIKRlADxN8l4hDny5Qw4jrGhXk2WOYGCaa7LJUZJvGjLAAw2Ml5cEZcZwwDBqatmPXlxCQoCGVQbQSZ9tkgMABmXiQB6jmHp1QQlldgjqmpmKo0CZDVyID6bGtLeOA2WeaUyjIjWUAG68YvhBmRTsKQyuC6WajQaJ7nprqFoZEEOZGghFrELGRgMABWV+8OmyqDYSqDijlunAUNMyNNR9mp5XpQLbMOuUAM8SWUJQ5LpbyZKkUOoiBjbaS8kvveImAJUu3rCttP4mNZyLCNxVLpt3ZSkSvqQAkIA/umYGgNfDaJL7z0ASKOtwwm9xHPDJKONmcsost3yMxFrS6/LMMyOpJcVlGZBkABbYSfPPLg9wQQciCgv0UIEAACH5BAUFABQALDAANQBnAGMAAAf/gACCg4SFhoeIiYIRFI2Oj5CRkpOUlZaXmJmRjJqdnp+UBqCboKKjp5qcqKqora6vkKyws7SesrW4uZK3ur25EYqCpr7En7zFs8O0x8jFCKPMzdKd0dPWltXX2qTb0sqY2d3d4eKa36vl6bu26sTAheTtv4Xn8tLx9pUHqQH9/v34UD3L16yep4EEoVlCWCxgwnQOH0qcSJFCRE0I9lkyECyRwVYfa4XUNfJXRW0lT6pcybJlu4ujUrp8pXGmzZs4c+rcybOWgAEEDAgdSrSoUQMEBgjgKcCABiBLjkidSrWq1SUiGOIcoEGJ1a9gqSphoBMpkLBowUIYUDZq2rdT/5XInGgArl2pcyUScHsXrZKlOQeI6JsWwk4BCLwS/jrEQVlBBSAoXnxECQTHOTkSGmDgwIXPoEOLvnDggAEBHVOrXs26tevXsGPLnk27tu3aAlDf3s1bdYIGNFrYKACgJ6gBIFrIWC4DBYLixjHCYE6dRV6eHW5Q3y4DRDrNvQ8ZaDCD+/Yb0SkJeMDCPHcc6SUVqOHefID4jgBcmFDfvA38jRAwQnn9UTeDAmw9BFMjAdBQ4Hm3DHAAAdDdtEAJD1L3AgIDFIIYCCBacN1BvQxQAQoZLtcCCOARYgGIMIJwgUsCYJBicxzMKEkHMcKIAWAqATDACynagJkk6/UIo/+O3LwyYiUDENgfDBZQmIgDSsLYwUaZLOjJdPWp4EECwRiAQZYgJtASAB64h8IHG1wCAAJogqBBhSsNACZ1JhTQYUcH1AnCAYRE8M8/XmKkSQd7nhCAlakFUOdzhR7qT6KYaJUpBhyyFkGdGLQIgKGWBoBpO0miuYAhpFp6qjoF1BmAbpWW+mo5Bgh6wSGtHuqQqOG9JkGdFtBaq6s7XSAombyWaioohAYLm6RoEodIr4jq9CmaGEDKqrO3ajPAmWi+cy24OcWKZgB/nmvrQnTpGgy2lwZTkyTASosInWgiYGyz79oEALlZ5gsPuB09iUyqSlo7L7oC89vjA+0qQi87QDcBYMADSm6g2sXP4kSAxCCs+jHCHz+kcQQdeNsRyOamZsAGGxisb3gw36yzbDAD6PPPQBsXQbinBAIAIfkEBQUADwAsMAAyAGcAZgAAB/+AAIKDhIWGh4iJgwkPjY6MjpGSk5SVlpeYmZqbnJ2en6ChoqOkpaanqKmqq6cErJuur7Kzjg60t7i5uru8vb6/lbHAw8ShwsXImhLJzI0bq8/NldHF1NLX2A/Ho5DZ3tLbqwff5OXmntab6a2X4+QMu/Cc66MM3eeTDAH7/MvF8pgOEAJo7NIGRYP8ybpXTCE+gwF7EezkblPFTgwvMUAo6OIojw9DYqIHzGElBgQ4IiIwsRRKUCAzhUuVUZtIaQdVcpx5k5U+fkCD7sups2ghkpVqnkIqyYHRp4NsaYrZUyQBB0KBEoValGnVrw+9guXUcqzZs2h1ARAwoK3bt3D/47oVAOAsgAEFTuQIwbev37+Ac5yQCowwKQEFdABezNivjghjCQw40bgy4xN0uWqOmmrAXsug++bg+XBA6NN8B4z1jBq0DrMCKLeuDGPsxgVAZjMG0iGyoAgwPusOoQNG768vJRFIwLy58+fNDZBOS7062M3Ys2tHSCAAiQwexKoqO0wAggwT0qeH/Eu8LAARGqifz0G1dUsADlCYz38Cgu0IeZUSgDsF8EF//FFwHyUMcIBgfyAw494nAHRQwYMIFkBgIhtk5SF53ICAIYIeYGPYKANocOCI/GkgwH0COEACiwkKNEkC9lUFwAYX0qieAhG82BQ/yYECoiMmpSKA/wY+qpcBAgMW8hM/Ggj0FEgn3sJAk+kFYAAiF2SlwSlUfWKlIgLI52N4QlJigYdlglTmJdNJshFCAqw4IgkOZIZIBB4GICCZp6Q54gcSRIlIioEagBEyEmCIQQIqYfXhVLq4p+Z8I2zgpyIJBOrlJ0p9MmU/nBywKZ+fIoRAoFm6RFEkSWIiQAQMBGlUhx5qUGcoW6l0wISmvOnhcQtWAqiHtSbbCAEaBDqnKYpumF0BgW5kyqlBOWWtdqH26qizkwggQaALkEsJr1lZkKO6jSwZKLFoLRAoAm2m0mwy0ErrS7XfcmRpVhrCK4mxQvk6y6+/AIBwUOwZHMnAQFmQry3EDwzw8D7TokKvLgMMrAGyGE9CwAYbvJvLyRswXPLLMDfSccwwl0rzAx/PEggAIfkEBQUADQAsMAAyAGcAZQAAB/+ADYKDhIWGh4iJiRKKjY6PkJGSk5SVlpeYmZqbnJ2en6ChoqOkpaaVBaePjKqrrYkLAbKzAayvt7iaEgC8vb6/wMHCw7y2uYjGx8rLzM3Oz9DR0tPUhgvV2Nna25IX3N+dAgMDlMngjgIHHjgeCdrepgw8Q/Q+CgTniuaPCfP0/0AskMvHCce/g0OCtIggwBQ8R9dMDQiBEKGQG+5G7Vs2QEjFijw84Nu0UdPDTAJ0fPy4gkFDZLRonXQ085iClR+DnNggIFhNVRE9CYgRBGdFIh9GEowkQAIEoxV/gBiIKNWlArOCYrI6KYGCIlARyijwcukjARtseAxLz0iNjGb/Hw0ooILtPwhKoWndRCCASrsc4nbl4IMtip7EEisGwLXRhcWQhaGtYQTqYcGUBjCQYXQCZksEQPz46OPAqZLLDmTYcdAIhs8oN5QI4UMG6lCNYevezbuVuHHAgwsfPqDs7ggfTtBYzry58+cnMmxglhtTBBjPs2tvDmP6ZwEftovXnuFY9UzKx6tnDoOq4PXwl8MWkD6+eBgAYGewPz4w5gIAbIAdf9m98JNZF3AwIIE0wMDBgeBUJw4BFFZo4YUWDhDZhhx26OGHIIYo4ogklmjiiSimqCKIAkQggQYFwKXKecxsoAEtGpjWWyQJSBCTLBIYtyMiBGD14yzeDXlI9Is3HjkLjTsG6KOTtEB5y22ZJIAAlT9CqNtcXP5opTJjMhVBk2HKokEE+Q0JwAVTpilLAXlVgyUiBjAg5ywIHNBmVVstA0AEe8piAU/BlPlITYp2EmChGizgXitedrPYlnIWYMCfhtxZSE2VngIAmlRK8BgncdbSSaiQAJDqjxp0ICQmr6oqTQdULkDAYo0mwuorrv7IQAKcKpkIAXGaWqwle0XSrCVwXgLAARvoyNuvnXhq7LanYMvtIL02YuSR4X5r7rnopqvuuuaxS9AuK0KmbSvwxqtYLD/OC8qzV3apjL6jlOvuwAQX/Iy3OwJsrsKkBAIAIfkEBQUAGgAsMAA4AGcAWQAABv9AjXBILBqPyKRyuXQwn9CodEqtWpHOq3bL7Xq/4LB4TC6bz+i0es1uu9/w+Dorr9vv+Lx+zzcKBH1xCQEjAQSBbREqIowoGAOIaQSLjJUnBYCRZRWVnSIQMRcAeXRmAi2eni4Kh5pgAi6pqTMBkK5eNLKyL6W3Vw+6shATB6OkYgANwbIpI75bDi/LqS0WmUgMWgwB3L1W2VQEDzPTniYRxs9TAAcNseWMKxmt6lMCETHwlTC2et5bAxDk0keh3hUCFGTAKwGgocOHECNKnPgPzoEMK6YxNKhFwIISy5xxBGiBhSwUCUZ2MTBCYaUVElR6YUdChYwSFcuAk8mzp0/MPQD+CB1KtOjQdD4FHHigoIHTp1CjSlXw4ECdnOsOVJDKtSvUCil9PvBKtuuDiWjTqo2IlYqApmXjPq1wTaUAuXid1lUJNy/ZCj4BjPVLNkBPBgASbCXMtYKBnxoG9WVcIcBjmTuHBB3AubPnz53/QB5NurTpMZnVpD7NurXr15rawp5dxAG327hzc1t9Rzbtq7+78I4y3GBxaMExJ1/OXIxvDc+bS38Svfb069izay9yXMo23d22ix9Pvrx5PtXPqzedPk379V7eIwoCACH5BAUFABAALDAAMgBnAGYAAAb/QIBwSCwaj8jk0ABpNi1Mp3RKrVqv2Kx2y+16v+CweEwum5uds3o9FQwE545yTq/b6QMEh1MYmNNsgVoCHS07hzs3fmSAYAWCYIQ/iIgjZY1gFpBeAjCUiCEHjJukUgKTn4cxcGKYmXewsKipPgtjrl8WsbtznamILaxguKWCBb+ID63FxQMmyDsiBGHEzGwdPNAc1ErV1l0CHNA8F8NiF7zpdAki0CbCXN7fag/QPo9eckdR82UEhshQLIrXr1QBH9Aw5CtIakAMaDr4aZFXRZ+6O2E2hID2AR4Wi0MoMgNAoECAPncEKIDWQyQahlouTDBB8wYCAXYMrIAGw6MV/5dNEHi5oAnMgJk0k3IAGgDaDglEOgSYSnUq0C9CxQRIytVEiREJ6BA4AS3FQC5ZN7lE2jWpjQAD5jjoAa3oFbtxztho23ZCAZxIBtyA1mAK3oXWAHzgy5fEhiQXciDzUJGNxCwI6iBgzLcEBQNHBHj4xSMBTDNbObeNoSFukQEqPvnA4HPNVTSwOnBQ3dcBFQOeDqn4KwbfGuNe8uDg3VUBuiIHGFyo/eXyaQMP9jKnWQLD2dNXbmO5MGK7UurgIQmIsNu8rot1ynUBDT+whBvbK9Sngzw9AAMYlMCbAuk5IV4ZFyigmgb7zXGgNQ6wxdUN0zBzWIFODGBBDFyV4P/bac81eBF2E9ygwINk9Ifhiiy26OKLpNQHYxn/FaBBVTjmmKMGBVQInopjGHCjjkQWqYGPM3YBgElFNqljASLGAuQYAAzp5JVTMZikFwBg6eVUAGyppJVfGimmF0yWWeSUZ04BJQFkqlmVBd+1icUANspJFY912ikFkAAIIOighBZKaJh+Jqrooow2qoYFPFpXDJuOCoKihZWWAlKUUWXqaUwWYElpPxbIB4mk6V3wZVpspCnqjKMi9ulLZYT65ZSonnZhF6xuYRoWsQI7KwTBhlHsGqYO28+ou34EU6+aFpksBLZO1WxlykpRLVV45brosRheCgF9dHg7hVQ6gmSgLq9rXPsHkVdBm4W7WiSwwa9dTJsFujnepu9EpOYDb7Zf8IujuJ4aXBXCdkJ5hMJUbTqEqziCKybEVoWBb6YYB8BwuK0MTLAUEkcl8shbdPxxkmF1A+8cG8No8bkno7xvza9wGgu9N6dLBs8wAQ2Byp4KXdHL8eVo9KQhp3vHyqT8+xHONv+EtM5Y60x01VyTsnTXThjwNdhNXNAB1GUEAQAh+QQFBQAKACw2ADEAWgBnAAAH/4AAgoOEhYaHiIYCFx8vLx8dBgKJlJWWl5iWAUFHnUdGAQOZo6SlmBecnp1CF6aur64ZqqocsLa3lS+znjUKvr/AwcLDxMXGwwLHwjC7nTW40IgCCxQgEZOYJ81Hvcre3+C+ABc3MuYoFdiW2s3d4e/wv+M05vUyAdnb7vH84B/29VgkuMRu175+CIsBoAfQXANvBWcdTEgxGMOGMzqs01exYzAA/xqau6EsoqqJHilGQCHSHIJKJnmlnCmAQ0sZMEQliuls5swDLW6CoMSTm8+ZFG62GIioKMqj/Qy8uMmhmNNEC6DCk3ATRYSm+hAl0ApvQLmWJYg5JesxwoybFv8OrWVbUUCDmycIGJoL7mu0UQdY3PSwN2yhCGwXRdiQDByGmypaEeJL15eBACAyP9CIiUCNmx+CMWtX+ZcAzJlTa2BqCUHXBYR0NTNR2leE1LgzI9BJacCEmyXUcdj20FvWhABQ506NYYE6RB1U3CwwKEEqVULGdkRsDACG5csDSJZW4SYGQhauHxFioXFp5eBxW2BtKMGJlhoKJSBR4wWHC+71o903G8QXXwG8FRKASC0YwNZx4SxgIHgY+FWIAGfVM4MEANSmjIUJaDBheOMNQsAHLMlwA3cJQUjTBg+MmJsEBtQXwYAI4QjVAA58J2NqBQToYUcAGIDAj6p1OKT6Mi4qA8ABIiLJ4pLE0JeJAB3EKKMEVO5YwJZdBjMlQkVKMOGYYaa0CHypPSBkmjRF4GNqF8BJF48BPCCBjnb26eefgAYq6KCEFmrooYgmquiijDbq6KOQRirppJRWOiSflmaq6aacdnoopp6GSgyakpLqE6iipqrqqkeZqqirbXWKamVNpmplIrOKGcCuvO5qIQC5GgobIRH02uuvANQKabHG+uops83CWmqzznYKrbHSRnrtsc9SG0C2y3oL7qPb8jquo+VWy2m633ZL7bmNsgsvo/K6G22hyvYlLkL59lmvteJmMi+c/64b8F8Iw1IwqwyvGuyzA1cUCAAh+QQFBQAjACw3ADEAWgBnAAAG/8CRcEgsGo9I48Ez+XgOhKR0Sq1aqwhRaBuCIK7gsPhq0HK3kARgzW673/C4fE6vrynnM8jO7/v/bh95XBmAhoduAn8Tg1sZY5CRFxIIB2CMjY+Rm1YGFBOgExpXmIOanKhIBhyhoQV8pXmnqbRCABitoRkEdrFns7W0rLmgGr2NIcDBqMPEH2p0voTLwbjEoBR10o7UtQfXoRHRyMrdkQ/gEw2KctvJ5rQGGekIc+6FchvwVgAS6bvtyEHagOgPAQXpHgTMJMfBPjAR0k24EOdeHAMPwQj4BM4DOzf3Mqb6lk7cG4tvLIkEEyBdgwEnBa7kJC+dhJiZZhI5sOHAH/8G6T4YACnTispNBCQEWGqBIp8BCMFhIJqzmz4j/ZZqDYBgqJ0OEgmyEVR1ZYetaB1SEWDtWgUieBqBsKJ20walaLdq6FDnwId0YgEQMHMGAsaZGvLmlXAUiQV6bQoQ7vKqytUkjaUgUKy4gFc4BJrlcuDG018KCYpk7gTmAGfFGhZ8dFPgWoYBD+teOfs6r4YNAo5wbLVg32UxBhj0XgytzYC2Hiii0r3sAN7lWgvwcjPgAi9Uh/cJiJAY+1INEXSKCTyHgAPzWhmopxsmwWb47AvOOU4lfJgNFphXwHyYoULecgMSCA8BBfSWn35x8JcRAPYpZoGCKwGoV2oKSminTgQSWOAZhiSWaOKJKKao4oostujiizDGKOOMNNZo44045qjjjjz2uKJ/PsroYZAsPgjhG0MSiWGSLzIpBZAmOqnklEpCSeWV6q22jJQnajmGlyutBmaWkXA5Uo5WzkQdPGNumcRndKQZiZwyrknfmW6qZ+QcPGHp54tt/inooIQWYWahhxaq6KKMNkqlnSVCuk+gtCTqqFWXZqopJJRuaiOdf1q6TBAAIfkEBQUADQAsSAAxADoAIgAAB/+AAIKDhIWGhAYaFBQaCQOHkJGSk4URNTSYNDURApSen5EEl5mYNQSgqKkWpKQWqa+eFKyZFLC2kR6zmLWoAp2QBhsbp6C5uryfDh8fEo+EAwUB0gERxbo0yJMCJUFD3igLvwMW09MXn8az2ZECJN7vQz4Ojw7l0xa/k+ms65AbO/DesSAggJw9adUo7SPVz9AAGAHf9Thl8KAGYpIW0qIkwUhEbz5O1TsorYDCaw0RpfjoTUUnAhpISkugD6U+lkOMmBS0QGYACQ2CCh3aQOMuSQd44KyRb0BMmRsy2oQ04AbOHecIbfCpIZ8ho9giOUCCk4MhAQh8LsA11RABGjjuc2AkdIDrXEJgU2roxjJApGgyGUDKe8gABJwznB2C6fPAIcKFBCjAKWStpAg+JXgVBFlrEZwlNjuseLDD17aCBtjA6YMmpa0yNSjmjBpAASE4FXxC69NBoc4ACKjACeSupAQ+AxggJOsYoQA4g7hCNZIkAkKrdEkYNAAIThazPTGWaWDoKFKmBkFnKSRhKsxQCVlC7x7AB5w3BBDdz79BQZmOEUKABYtYsBwhk31URHn9NShUXRaJdhxZEXng4IUN2GaPBgGiQgFu8MgwAIYXClBdAcZ9goAL3gTBQgIkkiiAAeG9QkAEFmygH4mBAAAh+QQFBQASACw3ADEAWgBaAAAG/0CAcEgsGo9I42CBQDgIgqR0Sq1aq4dRY9sYXa7gsPg60HK3o8F4zV4vzudIe06fIuBcRn3PF97xDXpiEoSFhoeIiYqLjIh/eIJWHR4jDgKNmJmai49wDJskECKjJRubp6iMnWeRUyCjsCIoHZeptqmreVgpsbA3arfBmrlbrUgCH72wMwPCzo3EgVQOK8qjKM3P2o6A0lIEJtajMdvlhtHGRgHiIisR5qgI0N3pRAkq7BnwqR1S6EkCKrCTcaBPkg63/iHpwEsciH3wFCrBwY5FNojbJBYpwE6EPIzlNA4hAIOdjVogtYkU8oDdCoQpM9IzcmAGuwYAYsoEZEwACfJ2KAxsgwlSZIRq4jDoDDlzyAAb7E5cXJrowKZoCIgwYAehgLCPVCVE6CZHiIAT7G6gvNUBrE4BZs6kGYKAXYoLz9wuzSK34BAP7BTkDFtOQIQmC9QQaWltBgHCYQ007BUAMmENSGGZWFuIqE4EVjEuqOFLqGXIAzYUCH269TPPrmPLnk27tu3b/Qwagb33tu/fwIMLH068uPHjyJMrX868ufPn0KNLn069uvXr2LPv4x1RO6rcuolw906+vPnz6KWzbq03vfv38OPLbzQ+O9j21/Ue2LCeev35AAYooGX9xYSfdv+5l+CAmBw4W4HbQBhMEAAh+QQFBQAOACw3ADEAXABnAAAH/4AAgoOEhYaHiIYCFxERFwKJkZKTlJWWAAYWAZsBFgaXoKGilAKanJsWkKOrrKEXp6cXrbO0kR2wnB21u7wAEbibHQ7DxMXGx8jJysvMzcW/wLqWBxoaws7Y2cTSlNC43JMYJSbkFQkA2unqyd6w4JES5PImNwfr6Qv3w+2n74gGMebJ8yBAn8Fs/HI5AyFQHo6DEJslDDZpw7iGJnAUjMjx2MQA/goNUICR3Ah0HVPuAwZSUoGSJkpcUKlOArOPIQcRmAATA0qaHXEuCwAzhgGgKnEmOhCwpAWkSVnmFOABZoaNUDkqPdQBpokIWVNuFckBZoWwYqUeYgCzhD20Wv/VFjKAoyfcoFKPYYB5g8BdZTMRyh10wQZMBJcMgOCAwe/fZ4MBCBgBk4OqSQYq/NjBGUg+jgmy3YpGKELbnIUIaHDBufUOEY6Xfe74CljgYWVLjmgmYAEN18AtA7D519SpVINMl7RxLtEiHD2AAxcxoOO1ZpmOfxqkAWaASAZG5JAunUfsrLeJXejg6LIgBCVxDEBEwIIM8uRdEFjEMb2+AU0JVMAhAkTwAn74jVDdY9gUcJE8ChwjwAEZ8ICgdD7IZ5AEoSF1QQPyjEBAaiCIcKF0KBSAVTH+MWiMAAl0sN0gAjCgwonA6QDCgspc5yJ2JfiAY2s9fHDUjxwJkML/kK3B0MGKNMnSiyENMLmDCxJAqU2LSDrQwpA/KNglTV9e2AMOHY6pUgYX0rCAe7uk+eMBIZAHgQZaqtmRABgI2VoICpynJ1ACSKBCCCLEIOWUjM4iwKODRirppJRWaumlmGaq6aacdurpp6CGKuqopJZq6qmopqrqhqu26updXGoa66izvnqXj6fiaitacv5IXKq10sZpsNkQG1YHLRr716KIjGYbR6gJouyuB80W1rSiOuvOXb8O021HCxSibT+FWGtQet8Ok8AGvTaD7bgKFQsKtkDBGwy19oIELFd57Zqvrqv+u067aKXrjMD+9msrwgsrnIzBkjaXyL+SEOwpMcOvYuyqxpWamw7H2ngMayUUU0JvpCVTAjCD9IKsasqNxkyyw9Qac3LNOOO83sp3BQIAOw==";;
		
	
		$scope.days = dias;
		$scope.months = meses;
		$scope.years = [];
		
		$scope.mDia                = generalService.getDataInput("SIMULADOR","DIA NACIMIENTO"        ,null         );
		$scope.mMes                = generalService.getDataInput("SIMULADOR","MES NACIMIENTO"        ,null         );
		$scope.mAnio               = generalService.getDataInput("SIMULADOR","ANIO NACIMIENTO"       ,null         );
		var edadMinima = generalService.getDatafromCategory("SIMULADOR", "EDAD MINIMA", "VALOR.valor" );
		
		$scope.fecha={
			dia:"",
			mes:"",
			anio:""
		};
		$rootScope.idSeleccionado="";
		
		$rootScope.CU="";
		$scope.CU="";
		
		$scope.init = function(){						
			
		// La siguiente validación se ejecuta si la solicitud proviene de la NOC y se suigue el flujo normal.
		// Inicializar el JSON para para busqueda del cliente con recompra
			
			if(generalService.existeSolicitud($rootScope.solicitudJson)){
				
				var cu ='';
				$scope.foto=[];
				$rootScope.datosGenerales=[];
				
				cu = $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico.split("-");
				
				var inicializar = 
					{
					  "fechaNacimiento": "",
					  "pais": cu[0],
					  "canal": cu[1],
					  "sucursal": cu[2],
					  "folio": cu[3],
					  "taz": "",
					  "tipo": 2,
					  "tarjeta": ""
					}
				servicioBusqueda(inicializar);
				//clienteRecompra(inicializar);
				
			}
			
			for(var i=(new Date().getFullYear()- edadMinima);i >= new Date().getFullYear() - 75;i--)
				$scope.years.push(""+i);	
			
			$('#busquedaID').addClass('ng-hide');
			$rootScope.waitLoaderStatus = LOADER_HIDE;

				
		};
		
		
		$scope.iniciaHuella= function(id) {
			$rootScope.idSeleccionado=id;
			
			$rootScope.solicitudJson.cotizacion.clientes[0].nombre = $rootScope.datosGenerales[id].cliente.nombre;
			$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno = $rootScope.datosGenerales[id].cliente.apellidoPaterno;
			$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno = $rootScope.datosGenerales[id].cliente.apellidoMaterno;
			
			$rootScope.solicitudJson.cotizacion.clientes[0].clienteTienda = $rootScope.datosGenerales[id].cliente.datosSolicitud.clienteTienda;
			$rootScope.solicitudJson.idSolicitud = $rootScope.datosGenerales[id].cliente.datosSolicitud.idSolicitud;
			
			console.log($rootScope.datosGenerales[id]);
			clienteRecompra($rootScope.datosGenerales[id]);
			
		}
		
		var clienteRecompra= function(datosGenerales){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			recomiendaService.clienteServiceRecomienda(datosGenerales.cliente).then(
					function(data,status) {
						console.log("LLEGO A SUCCES");
						console.log(data);
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.status==200  && data.data.codigo==RESPONSE_CODIGO_EXITO){
			      			
							console.log("DENTRO DE 200");
							console.log("***********************");
							$scope.responseCliente=JSON.parse(data.data.respuesta);
							console.log($scope.responseCliente);
							
							if($scope.responseCliente.codigo==2)
							//if($scope.responseCliente.codigo==10100)
								generalService.locationPath("/fichaRecompra");
							
							else{
								$scope.titulo="Recomienda y Gana";
								$scope.mensaje=$scope.responseCliente.descripcion+" [CÓDIGO: "+$scope.responseCliente.codigo+"]";
								modalMensaje($scope.titulo,$scope.mensaje, "Aceptar", null, "rojoR", "rojoR",null,null,null);
							}
								
						}
						else{
							$scope.titulo="Recomienda y Gana";
							$scope.mensaje=data.data.descripcion+" [CÓDIGO: "+data.data.codigo+"]";
							modalMensaje($scope.titulo,$scope.mensaje);
							console.log("STATUS DIFERENTE DE 200 O CODIGO EXITO DIFERENTE DE 1");
						}
							
					}, function(error) {
						/*nunca pasara este caso*/
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						console.log("LLEGO A ERROR");
						console.log(error);
					}
			);
		}
		
		$scope.validadias = function(dia){
			
			if($scope.fecha.dia!="" && $scope.fecha.mes!="" && $scope.fecha.anio!=""){
				$scope.cliente.fechaNacimiento=$scope.fecha.anio+"-"+$scope.fecha.mes+"-"+$scope.fecha.dia;
				console.log($scope.cliente);
			}
				
			
			if (!dia){
			  	   var vAnno="";
			 	   var vMes="";
			 	   $scope.vDia=$scope.fecha.dia;
			 	   if (parseInt($scope.fecha.mes) && parseInt($scope.fecha.anio)){
			 		  vAnno=$scope.fecha.anio;
			 		  vMes=$scope.fecha.mes;
			           $scope.aniobisiesto(vAnno,vMes);
			           $scope.fecha.dia=$scope.vDia;
			 	   }
		 	   }
		 	  if (parseInt($scope.fecha.dia) && parseInt($scope.fecha.mes) && parseInt($scope.fecha.anio))
		 		  $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento = $scope.fecha.dia + "/" + $scope.fecha.mes + "/" + $scope.fecha.anio;
		 	   
		  	};
		 		 	
		 	$scope.aniobisiesto = function(vAnno,vMes){
		 		
		 		$scope.days=[];
		 		if ((vAnno % 4 == 0) && ((vAnno % 100 != 0) || (vAnno % 400 == 0))) {
		 			if (vMes == "02"){
		 				$scope.days = dias.slice(0,29);
		 				if ($scope.vDia>"29")
		 					$scope.vDia="29";
		 			}
		 		}else{
		 			if (vMes == "02"){
		 				$scope.days = dias.slice(0,28);
		 				if ($scope.vDia>"28")
		 					$scope.vDia="28";
		 			}
		 		}
		 		if (vMes=="04"||vMes=="06"||vMes=="09"||vMes=="11"){
		 			$scope.days = dias.slice(0,30);
		 			if ($scope.vDia>"30")
		 				$scope.vDia="30";
		 		}
		 		if (vMes=="01"||vMes=="03"||vMes=="05"||vMes=="07"||vMes=="08"||vMes=="10"||vMes=="12")			    		
		 			$scope.days = dias;
		 	};
		
		
		
		$scope.clickBusquedas = function() {
			
			$('#busquedaID').addClass('ng-hide');
			$('#recompraID').removeClass('ng-hide');
		}
		
		$scope.busquedaRecompra = function() {
			//buscar por nombre, cu o tarjeta azteca
			var tipo = 1;
			var esNombre = true;
			$scope.foto=[];
			$rootScope.datosGenerales=[];
			
			$scope.busqueda=true;
			
			
			if($scope.buscarNombre) {
				tipo = 1;
				console.log("BUSCA NOMBRE");
			}
			else if($scope.buscarCU) {
				console.log("BUSCA CU");
				tipo = 2;
			}
			else if($scope.buscarTaz) {
				console.log("BUSCA TAZ");
				tipo = 3;
			} 
			
			$scope.cliente.tipo=tipo;
			validaFormulario($scope.cliente);
			
		};
		
		var validaFormulario= function(cliente){
			if($scope.formRecompra.$valid){
				var coincidencias="";
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				var respuesta= servicioBusqueda(cliente);
			}
			else{
				$scope.titulo="MENSAJE FORMULARIO";
				$scope.mensaje="DATOS INCOMPLETOS";
				modalMensaje($scope.titulo,$scope.mensaje, "Aceptar", null, "rojoR", "rojoR",null,null,null);
				
			}
				
		}
		
	
	    var servicioBusqueda = function(cliente) {
	    	
	    		recomiendaService.consultaServiceRecomienda(cliente).then(
						function(data,status) {
							console.log("LLEGO A SUCCES");
							console.log(data);
							console.log("*******************");
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							console.log(data.data.codigo);
							console.log(data.status);
							if(data.status==200  && data.data.codigo==RESPONSE_CODIGO_EXITO){			      				
								console.log("DENTRO DE 200");
								$scope.responseJSON=JSON.parse(data.data.respuesta);
								
								if($scope.responseJSON.codigo==2){
									console.log("VALOR DEL RESPONSE: ");
//									$('#busquedaID').removeClass('ng-hide');
//									$('#recompraID').addClass('ng-hide');
									
									$scope.getFoto($scope.responseJSON);
								}
									
								else{
									if ($scope.responseJSON.codigo = 3601){
										$rootScope.message( "Recomienda y Gana", ["Lo sentimos, este cliente no puede ser cliente recomendador."], "Aceptar", null, "rojoR", "rojoR",null,null,null);
									}else{
									$scope.titulo="Recomienda y Gana";
									$scope.mensaje=$scope.responseJSON.descripcion+" [CÓDIGO: "+$scope.responseJSON.codigo+"]";
									modalMensaje($scope.titulo,$scope.mensaje, "Aceptar", null, "rojoR", "rojoR",null,null,null);
									console.log($scope.responseJSON.descripcion);
									}
								}
									
							}
							else{
								$scope.titulo="Recomienda y Gana";
								$scope.mensaje=data.data.descripcion+" [CÓDIGO: "+data.data.codigo+"]";
								modalMensaje($scope.titulo,$scope.mensaje, "Aceptar", null, "rojoR", "rojoR",null,null,null);
								console.log("STATUS DIFERENTE DE 200 O CODIGO EXITO DIFERENTE DE 1");
							}
								
						}, function(error) {
							/*nunca pasara este caso*/
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							console.log("LLEGO A ERROR");
							console.log(error);
						}
				);
	    }
		
		
	   $scope.getFoto = function(respuesta){
			$scope.arrayCU = [];
			$scope.arrayCUH = [];
			$scope.ind = 0;
			
			console.log("DENTRO DE GET FOTO");
			
			angular.forEach( respuesta.data, function(value, key){
				console.log(value);
				$scope.arrayCUH [$scope.ind] = parseInt(value.pais) + "-" + parseInt(value.canal) + "-" + parseInt(value.sucursal) + "-" +parseInt(value.folio);
//				$scope.arrayCU[$scope.ind] = {	    			
//		    			pais: parseInt(value.pais),
//		    			canal: parseInt(value.canal),
//		    			sucursal: parseInt(value.sucursal),
//		    			folio: parseInt(value.folio),
//		    			width: 120 
//		    	}
				
				$rootScope.datosGenerales.push({
					"cliente":value,
					"foto": $scope.fotoCargando,
					"cu":  parseInt(value.pais) + "-" + parseInt(value.canal) + "-" + parseInt(value.sucursal) + "-" +parseInt(value.folio),
					"ClienteAlnova": ""
					
				});
//				$scope.obtieneFoto($scope.arrayCU[$scope.ind],$scope.ind);
				$scope.ind++;
			});
			validaHuella($scope.arrayCUH);
//				$scope.getHomonimosBsqFonetica($scope.arrayCUH);
			
		};
		
		
		
		$scope.obtieneFoto = function(arrayCU,id){
			clienteUnicoService.getFotoCU(arrayCU).then(
					function(data){
						if(data.status==200 && data.data.codigo==RESPONSE_CODIGO_EXITO){
							var toJson=JSON.parse(data.data.respuesta);
							
							if(toJson.codigo==2){
								$rootScope.datosGenerales[id]["foto"]=toJson.data;
								$scope.foto.push(toJson);
							}
								
							else if(toJson.codigo==281){
								$scope.foto.push({
									"data": "9j/4AAQSkZJRgABAQEAYABgAAD/4QAWRXhpZgAASUkqAAgAAAAAAAAAAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABgAGEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2SKKEwRkxISVHO2gxQ/8APJP++aIm/cR/7ooLVokSyMxxf3F/KomSP+4v5VITUTGrSJImVf7o/KomA9KdLMkeN7quf7x61nz6vYwvse5TJ9Of5VVkDLLGoWY+tKJY5RlJFceoNMY1SSJuMZ2/vH86haV/77fnT2NQMatJE3EaaX/no/8A31TYp5TcRgyOQWA+9TGNNhP+lRf74puKswTdz1GiiiuA6Dn42/cp/u0FqhRv3a/7tBat0jNilqoanqCafatM/J6Kv941aLVxXiO9NxqJh/gg+X6nvT2Ay7ieW4kMkzl3Jzk1ATSk0wmgB0VxLbyeZC7I3setdFpeti6xDckLN/C3Zq5gmmbyjAg4IOQfSqTsJnesaiY1XsLwXlkkucvjDj0apWNbIhjGNNgP+lRf74pGNJAf9Ki/31/nTfwsXU9UooorzjpOTDfKPpQWqLdxSFq6ktDJvUeWrzid900pLZO48nvXoLHIIrz28ga1upYTn5WwCR1pMERE0wmgmmE0IYE1GTSk0wmmJm94cmO2eLtw1bTGsjQIlWzabHzu2M/StNjW0VoZsaxogP8ApcP++v8AOmMaLc/6XD/10X+dXLZiW56zRRRXmHUcQW5pC1Ru3zH60wtXZFaGDJC1YPiGykuFW5iAPlKdwz/D1/xrYLUxyGUg8gjGKq1wucATTSasX9o9lctGwOzPyH+8Kpk1nYYpNNALsqjkk4xSE1f0e0a4u1mI/dxHOfU1SVxM6CytvsVosO7cRyTUjGlJqJjW6ViGDGi2P+mQf9dF/nUZNSWn/H5B/wBdF/nTl8LBbnrlFFFeWdR57I37xv8Aephamyt++f8A3qj3V3xWhzvckLUwtUE11DAuZZFQe5rFvPEajK2iZP8Afb/CnsIXxM/y24zzljiudJp89xLPIXlcu59agJqGUKTXQaA/+iSjv5mf0rnCadDdTWz74XKn27046MGdoTUZNY9tr6Nhbldh/vDpWnHNHMuY3Vx6g1unczH1Naf8fkH/AF0X+dQ1Naf8fkH/AF0X+dEvhYLc9coooryjrPLr+5W28+Z/uoSa5C41i8nYnzii/wB1OAK6jxDpWqTQSpDp13IWl6JCx4z16VzP/CO65/0B9Q/8Bn/wrs5lZamFmZ5cs2SST700mtH/AIR7XP8AoD6h/wCAz/4Uh8O67/0B7/8A8Bn/AMKOZdx2ZnE00mtI+HNd/wCgNf8A/gM/+FNPhvXf+gNqH/gM/wDhRdBZmYTTSa1P+Eb13/oDah/4DP8A4Un/AAjWu/8AQG1D/wABn/wp8yFZmZQCVbKkg+3WtP8A4RrXf+gNqH/gM/8AhR/wjWu/9AbUP/AZ/wDCnzILMgh1W8hYHzS4/uv3rqtLnW5ktZk4DOvHpzXOf8I1rv8A0BtQ/wDAZ/8ACuj8O6NqsCxifTLyPbNn54GHHr0pqas9RcruexUUUVwHQf/Z"
								});
								
								$rootScope.datosGenerales[id]["foto"]=$scope.marcoFoto;
								console.log(toJson.descripcion);
							}
							
						}
						else{
							console.log("ERROR ESTATUS: "+data.status);
						}
							
						
					},function(error){
						/*Nunca pasara este caso*/
						console.log("ERROR EN OBTIENE FOTO");
						console.log(error);
					}
				);
		
		};	
						
		
		$scope.cambiaBuscador=function(opcBuscador){
			if(opcBuscador == 1){
				$scope.buscarNombre=true;
				$scope.buscarCU=false;
				$scope.buscarTaz=false;
			} 
			else if(opcBuscador == 2){
				$scope.buscarNombre=false;
				$scope.buscarCU=true;
				$scope.buscarTaz=false;
			}
			else{
				$scope.buscarNombre=false;
				$scope.buscarCU=false;
				$scope.buscarTaz=true;
			}
		};
		
		$scope.regresa = function(){
			generalService.cleanRootScope($rootScope);
			generalService.buildSolicitudJson($rootScope, null);
			generalService.locationPath("/menuWrapper");
	    }
		
		var modalMensaje=function(titulo, mensaje){	
			$rootScope.message( "Recomienda y Gana", [mensaje], "Aceptar", null, "rojoR", "rojoR",null,null,null);
		}
		
		$scope.showTipoPersona = function(TipoPersona){
			if(TipoPersona == 1){
				$scope.tabFirmadoCSS =  csstabs.on;
				$scope.tabSinFirmaCSS =  csstabs.off;
				$scope.tabInformativosCSS = csstabs.off;
				$scope.buscarNombre=true;
				$scope.buscarCU=false;
				$scope.buscarTaz=false;
			}else if (TipoPersona == 3){
				$scope.tabFirmadoCSS =  csstabs.off;
				$scope.tabSinFirmaCSS =  csstabs.on;
				$scope.tabInformativosCSS = csstabs.off;
				$scope.buscarNombre=false;
				$scope.buscarCU=true;
				$scope.buscarTaz=false;
			}else{
				$scope.tabFirmadoCSS =  csstabs.off;
				$scope.tabSinFirmaCSS =  csstabs.off;
				$scope.tabInformativosCSS = csstabs.on;
				$scope.buscarNombre=false;
				$scope.buscarCU=false;
				$scope.buscarTaz=true;
			}
			
			$scope.limpiaCampos();
		}
		
		$scope.limpiaCampos=function(){
			$scope.fecha={
					dia:"",
					mes:"",
					anio:""
				};
			$scope.cliente = {
					nombre: "",
					aPaterno:"",
					aMaterno: "",
					fechaNacimiento:"",
					pais:"",
					canal:"",
					sucursal:"",
					folio:"",
					taz:"",
					tipo: "",
					tarjeta:"",
					
				};	
		}

		$scope.obtenerDatosHomonimos = function(ctesUnicosArray) { // DATOS HOMONIMOS
			$scope.cu = ctesUnicosArray[0];
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var requestJson = {
					clienteUnico: $scope.cu
			};

			clienteUnicoService.obtenerInformacion(requestJson).then(
					function(data) {
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jsonResponse = JSON.parse(data.data.respuesta);
							
							if(jsonResponse.data != null){
								var clienteUnico = jsonResponse.data[0].fipais+ "-" + jsonResponse.data[0].ficanal + "-" + jsonResponse.data[0].fisucursal + "-" + jsonResponse.data[0].fifolio;
							}
							$rootScope.waitLoaderStatus = LOADER_HIDE; 
							if(jsonResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO) {
								$scope.homonimosData=JSON.parse(jsonResponse.data)[0];
								$scope.homonimosDataArray=JSON.parse(jsonResponse.data);
								
//								generalService.locationPath("/homonimos");
								var nacimientom = $scope.homonimosData.fcFechaNacimiento.substring(0,10).split("-")
								$scope.servicioFolio = {nombre: $scope.homonimosData.fcNombre + " "+ $scope.homonimosData.fcApellidoPaterno +" "+ $scope.homonimosData.fcApellidoMaterno, 
														clienteUnico: $scope.cu,
										                cuenta: "",
										                fechaNaciomiento: pad(nacimientom[2],2)+pad(nacimientom[1],2)+nacimientom[0],
										                clienteAlnova: $scope.homonimosData.fcClienteAlnova
										                };
								console.log($scope.servicioFolio);
								$scope.index = 0;
								$scope.cuentasRecomienda($scope.servicioFolio.clienteAlnova);
//								$scope.recomiendaGana($scope.servicioFolio);
//								$scope.abrirModal("12345678");	
							
							}else {
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								
								switch(jsonResponse.codigo) {
									case HOMONIMOS.errorConsulta:
										// Ha ocurrido un error al consultar homónimos.
										$rootScope.message("Error", 
											[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], 
											"Aceptar", null, "rojoR", "rojoR",null,null,null
										);
										break;
									default:
										$rootScope.message("Datos erróneos", 
											["error: " + jsonResponse.codigo], 
											"Aceptar", null, null, null, null, 
											"GENERAL", "ERROR GENERAL"
										);
								}
							}
						} else {
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							
							$rootScope.loggerIpad("Respuesta Servicio getHomonimosBsqFonetica", 
								generalService.displayMessage(data.data.descripcion));
							$rootScope.message("Error " + data.data.codigo, 
								[generalService.displayMessage(data.data.descripcion)], "Aceptar");
						}
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE; 
					}
			);
		};
		
		var validaHuella = function(cuArray){
	 		$rootScope.waitLoaderStatus = LOADER_SHOW;
	 		if (configuracion.origen.tienda)
				$rootScope.verificarHuella( 'codigoSolicitudId', 'responseVerificarHuellaIpad', cuArray );
			
			else{
				if( generalService.isProduccion()){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					modalService.huellaModal("bgAzul");
				}else{
					var response = { 
							codigo : VALIDA_HUELLA_RESPONSE.EXITO,
							matches: cuArray
							//matches: ["1-53-365-3608","1-1-4737-239","1-1-4737-244","1-1-4737-267","1-1-4737-268","1-1-4737-273","1-1-4737-282","1-1-4737-286","1-1-4737-289","1-1-4737-312"]
					}	
					$scope.responseVerificarHuellaIpad(response);
				}
					
			}
	 	};
	 	
	 	$scope.muestraHomonimos= function(arraysCU){
	 		$scope.arrayCU = [];
			$scope.arrayCUH = [];
			$scope.ind = 0;
			var datosGenerales = $rootScope.datosGenerales;
			$rootScope.datosGenerales = [];
			for (var i = 0; i < arraysCU.length; i++){
				var indexProducto = datosGenerales.map(function(d){
					return d["cu"];
				}).indexOf (arraysCU[i]);
				if( indexProducto !=-1 ){
					$rootScope.datosGenerales.push(datosGenerales[indexProducto]);
//					$scope.obtieneFoto($scope.arrayCU[$scope.ind],$scope.ind);
					$scope.arrayCU[$scope.ind] = {	    			
			    			pais: parseInt(datosGenerales[i].cliente.pais),
			    			canal: parseInt(datosGenerales[i].cliente.canal),
			    			sucursal: parseInt(datosGenerales[i].cliente.sucursal),
			    			folio: parseInt(datosGenerales[i].cliente.folio),
			    			width: 120 
			    	}
					$scope.obtieneFoto($scope.arrayCU[$scope.ind],$scope.ind);
					$scope.ind++;
				}
			}
			if ($rootScope.datosGenerales.length > 0)
				$scope.verHomonimos = true;
	 	}
	 	
	 	$scope.responseVerificarHuellaIpad = function( response ){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			$rootScope.loggerIpad("responseVerificarHuellaIpad", null, response);
			
			switch(response.codigo){
				case VALIDA_HUELLA_RESPONSE.EXITO:	
					if(Array.isArray(response.matches)){
						response.matches = $.unique(response.matches);
					}else{
						response.matches = response.matches.replace(/(\[)|(\]| )/g,'').split(",");
					}	
					if (response.matches.length == 1){
						$scope.getHomonimosBsqFonetica(response.matches);																
					}else{
						$scope.muestraHomonimos(response.matches);
					}
					break;
										
				case VALIDA_HUELLA_RESPONSE.ERROR:
					$rootScope.message("Error "+response.codigo,[ "Error al validar la huella."], "Aceptar");
					break;
					
				case VALIDA_HUELLA_RESPONSE.ERROR_COMPONENTE:
					$rootScope.message("Error "+response.codigo,[ "Error en componente de huella."], "Aceptar");
					break;
					
				case VALIDA_HUELLA_RESPONSE.COMPONENTE_CANCELADO_PORUSR:	
					$scope.endCotizador = false;
					break;
					
				case VALIDA_HUELLA_RESPONSE.NO_SE_ENCONTARON_HUELLAS:
					$rootScope.message( "Componete de huella", ["no se encontraron huellas."], "Aceptar");									
					break;
					
				case VALIDA_HUELLA_RESPONSE.NO_HAY_COINCIDENCIAS:
					$rootScope.message( "Componete de huella", ["no hay coincidencias."], "Aceptar");	
					break;
					
				default:
					$rootScope.message( "Componete de huella", ["Código "+response.codigo+" no definido. "], "Aceptar");					
					break;
					
			}							
	};
	$scope.abrirModal =function(folio){
		modalService.recomiendaModal("rojoR",folio,$scope).then( 
				function(estatus) {																												
					$scope.limpiaCampos();
				}, function(exito) {
					$scope.limpiaCampos();
				}
		);			
	}
	
	$scope.recomiendaGana = function(requestJson){

		$rootScope.waitLoaderStatus = LOADER_SHOW;
		recomiendaService.recomiendaGana(requestJson).then(
			function(data) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(data.data.codigo == RESPONSE_CODIGO_EXITO){
					console.log(data);
					var jsonResponse = JSON.parse(data.data.respuesta);
					switch (jsonResponse.codigo){
					case 3041:
					case 3039:
						$scope.abrirModal(jsonResponse.data);
						break;
					case 3032:
					case 3043:
						$rootScope.message( "Recomienda y Gana", ["Lo sentimos, tu cliente no tiene una Línea de Crédito o no cuenta con pedidos."], "Aceptar", null, "rojoR", "rojoR",null,null,null);
						break;
					case 3035:
						$rootScope.message( "Recomienda y Gana", ["Lo sentimos, para poder participar en la promoción es necesario estar al corriente en tus pagos"], "Aceptar", null, "rojoR", "rojoR",null,null,null);
						break;
					default:
					$rootScope.message( "Recomienda y Gana", [jsonResponse.descripcion], "Aceptar", null, "rojoR", "rojoR",null,null,null);
						break;
					}
				} else {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					console.log(data);
					$rootScope.message("Error " + data.data.codigo, 
						[generalService.displayMessage(data.data.descripcion)], "Aceptar", null, "rojoR", "rojoR",null,null,null);
				}
			}, function(error) {
				console.log(error);
				$rootScope.waitLoaderStatus = LOADER_HIDE; 
			}
	);
	}
	
	$scope.cuentasRecomienda = function(clienteAlnova){
		var x= {clienteAlnova: clienteAlnova};
		$rootScope.waitLoaderStatus = LOADER_SHOW;
		recomiendaService.cuentasRecomienda(x).then(
			function(data) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(data.data.codigo == RESPONSE_CODIGO_EXITO){
					var jsonResponse = JSON.parse(data.data.respuesta);
					console.log(jsonResponse);
					switch (jsonResponse.codigo){
					case RESPONSE_ORIGINACION_CODIGO_EXITO:
						var jsonResponseCuentas = JSON.parse(jsonResponse.data);
						console.log(jsonResponseCuentas.cuentas);
						if (jsonResponseCuentas.cuentas.length > 0){
							$scope.servicioFolio.clienteAlnova = $scope.homonimosDataArray[$scope.index].fcClienteAlnova;
							$scope.recomiendaCuentasModal(jsonResponseCuentas.cuentas);
						}else{
							$scope.index++
							if ($scope.index < $scope.homonimosDataArray.length && $scope.homonimosDataArray.length > 1){
								$scope.cuentasRecomienda($scope.homonimosDataArray[$scope.index].fcClienteAlnova)
							}else
								$rootScope.message( "Recomienda y Gana", ["Para poder ser un cliente recomendador es necesario tener una cuenta Guardadito. Apertura tu cuenta en el portal de Captación con el siguiente Cliente Único "+ $scope.servicioFolio.clienteUnico ], "Aceptar", null, "rojoR", "rojoR",null,null,null);
						}
//						$scope.abrirModal(jsonResponse.data);
						break;
					case 3037:
						$scope.index++
						if ($scope.index < $scope.homonimosDataArray.length && $scope.homonimosDataArray.length > 1){
							$scope.cuentasRecomienda($scope.homonimosDataArray[$scope.index].fcClienteAlnova)
						}else
							$rootScope.message( "Recomienda y Gana", ["Para poder ser un cliente recomendador es necesario tener una cuenta Guardadito. Apertura tu cuenta en el portal de Captación con el siguiente Cliente Único "+ $scope.servicioFolio.clienteUnico ], "Aceptar", null, "rojoR", "rojoR",null,null,null);
						break;
					case 3035:
						$rootScope.message( "Recomienda y Gana", ["Lo sentimos, para poder participar en la promoción es necesario estar al corriente en tus pagos"], "Aceptar", null, "rojoR", "rojoR",null,null,null);
						break;
					default:
						$rootScope.message( "Recomienda y Gana", [jsonResponse.descripcion], "Aceptar", null, "rojoR", "rojoR",null,null,null);
						break;
					}
				} else {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Error " + data.data.codigo, 
							[generalService.displayMessage(data.data.descripcion)], "Aceptar", null, "rojoR", "rojoR",null,null,null);
				}
			}, function(error) {
				console.log(error);
				$rootScope.waitLoaderStatus = LOADER_HIDE; 
			}
	);}
	
	$scope.recomiendaCuentasModal = function(cuentas){
    	modalService.recomiendaCuentasModal("Recomienda y Gana", "rojoR",$scope, cuentas).then( 
				function(cuentaSel){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$scope.servicioFolio.cuenta = cuentaSel.ctaSelect;
					$scope.recomiendaGana($scope.servicioFolio);
				}, function(exito){
//					$scope.closeThisDialog(true);
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message( "Recomienda y Gana", ["Para poder ser un cliente recomendador es necesario seleccionar una cuenta Guardadito"], "Aceptar", null, "rojoR", "rojoR",null,null,null);
				}
		);}
	
	function pad (n, length) {
	    var  n = n.toString();
	    while(n.length < length)
	         n = "0" + n;
	    return n;
	}

	$scope.getHomonimosBsqFonetica = function(ctesUnicosArray) { // DATOS HOMONIMOS
		$rootScope.waitLoaderStatus = LOADER_SHOW; 
		
		var requestJson = {
				tienda: $rootScope.sucursalSession.idSucursal,
				arrayCtesUnicos: ctesUnicosArray
		};

		clienteUnicoService.getHomonimosBsqFonetica(requestJson).then(
				function(data) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var jsonResponse = JSON.parse(data.data.respuesta);
						if(jsonResponse.codigo == HOMONIMOS.autyLiberada) {
							$scope.obtenerDatosHomonimos(ctesUnicosArray);
						} else if(jsonResponse.codigo == HOMONIMOS.empleado) {
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$rootScope.message("Aviso ", 
								["Lo sentimos, no es posible generar folio recomendador a empleados."], 
								"Aceptar", null, "rojoR", "rojoR",null,null,null
							);
						}else {

							switch(jsonResponse.codigo) {
								case HOMONIMOS.errorConsulta:
									// Ha ocurrido un error al consultar homónimos.
									$rootScope.message("Error", 
										[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], 
										"Aceptar", null, "rojoR", "rojoR",null,null,null
									);
									break;
								default:
									$rootScope.message("Datos erróneos", 
										["error: " + jsonResponse.codigo], 
										"Aceptar", null, null, null, null, 
										"GENERAL", "ERROR GENERAL"
									);
							}
						}
					} else {
						$rootScope.waitLoaderStatus = LOADER_HIDE;

						$rootScope.loggerIpad("Respuesta Servicio getHomonimosBsqFonetica", 
							generalService.displayMessage(data.data.descripcion));
						$rootScope.message("Error " + data.data.codigo, 
							[generalService.displayMessage(data.data.descripcion)], "Aceptar");
					}
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE; 
				}
		);
	};
	
	}]);
		
});



