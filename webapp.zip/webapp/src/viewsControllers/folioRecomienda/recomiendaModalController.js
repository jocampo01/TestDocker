'use strict';

define(["app"], function (app) {

    app.controller("recomiendaModalController", function ( $scope, $rootScope, $location, $timeout, generalService, modalService, clienteUnicoService, tarjetaService, validateService, recomiendaService ) {
		$scope.init = function(documentoId){
			loadView();						
		};
		
		$scope.mensaje = {
				msj: "",
				color: "",
				origen: null
		};

		function loadView(){				
			var origen = configuracion.origen.tienda ? "TIENDA":"WEB";
			$scope.isTienda = configuracion.origen.tienda;
			$scope.celular                 = generalService.getDataInput("CODIGO SEGURIDAD","CELULAR"                  ,null         );
			$scope.etiquetaIncorrecto      = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA INCORRECTO"      ,$scope.origen);

		};	
		
		
		$scope.enviaMensaje = function(){
			$scope.mensaje.color = "";
			$scope.mensaje.msj = "";	
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			var x = {
					folio : $scope.ngDialogData.folio,
					celular:generalService.limpiaFormato($scope.modelCelular,"NIP-@") 
			};
			
			recomiendaService.enviarFolioCelular(x).then(
					function(data){	
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jsonResponse = JSON.parse(data.data.respuesta);
							console.log(jsonResponse);
							if (jsonResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								console.log("Mensaje enviado");
								$scope.mensaje.msj = "Mensaje enviado correctamente";
							}else{
								$scope.mensaje.color = $scope.etiquetaIncorrecto.estilo;
								$scope.mensaje.msj = generalService.displayMessage(data.data.descripcion);								
							}
						}
					},function(error){		
						scope.mensaje.color = $scope.etiquetaIncorrecto.estilo;
						$scope.mensaje.msj = generalService.displayMessage(data.data.descripcion);
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						console.log("No se envio el mensaje");		
//						$scope.closeThisDialog(true);
					}
			 );
			
			
			console.log("celular: "+generalService.limpiaFormato($scope.modelCelular,"NIP-@"));
		}
		
		
		
		
	});
	
	
});