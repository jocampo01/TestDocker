'use strict';

define(["appFooter"], function (appFooter) { 

	appFooter.controller( "footerController", function( $rootScope, $scope, $location,$timeout) {  	  
		
		$scope.mostrarFooter=false;
		$scope.isTienda = configuracion.origen.tienda;		
		$scope.version=VERSION;
		var id_seccion = pathSeccion[ window.location.hash ];
		
		if( id_seccion && id_seccion === SECCION_SIMULADOR ){
						
			$scope.isSimulador = true;
			
			if( !$scope.isTienda ){
			
				$("#owl-carousel").owlCarousel({ 
					singleItem: true,
					pagination: false,
					navigation: true,
					navigationText: [
						"<i><img class='png' src='images/slidebox_previous.png'></i>",
						"<i><img class='png' src='images/slidebox_next.png'></i>"
					]
				});
				
			}
			
		}else{
			
			$scope.isSimulador = false;
			
		}
		
//		$timeout( function(){
//			var obj = setFooter();
//			modalService.alertModal("Footer says", ["Altura: " + obj.a, "ViewPort: " + obj.v], "OK", "bgAzul", "azul");
//		},1000);
		
	});
});	