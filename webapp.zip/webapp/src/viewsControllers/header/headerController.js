'use strict';

define(["app"], function (app) { 
	app.controller("headerController", function($rootScope, $scope, $timeout, $location, sessionService, modalService, generalService, solicitudService, validateService, clienteUnicoService) {  	  

		$scope.isTienda = configuracion.origen.tienda;
		$scope.busquedaCSS = "busqueda";
		$scope.muestraInicio=false;
		
		/*
		 * Bandera para esconder la caja de búsqueda.
		 */
		$rootScope.esconderBusqueda = true;
		
		$scope.nombrecamel = function(){
			 if($rootScope.userSession){
				 $scope.nombreCamelize = generalService.camelize($rootScope.userSession.nombre);
				 $scope.nombreCamelize = $scope.nombreCamelize + " " + generalService.camelize($rootScope.userSession.apellidoPaterno);
				 $scope.nombreCamelize = $scope.nombreCamelize + " " + generalService.camelize($rootScope.userSession.apellidoMaterno);
			 }else{
				 $scope.nombreCamelize = "";
			 }
			return $scope.nombreCamelize;
		 } 
		$scope.validaContratos=generalService.validaContratos;
				$scope.fotoclienteee = "images/avatar/avatar.gif";
		
		$scope.goMenu=function(){
			generalService.locationPath("/menuWrapper");
		};
		
		$scope.ruta = function(){
			if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
			$scope.etiquetaOpciones          = generalService.getDatafromCategory("HEADER", "ETIQUETA OPCIONES", $scope.origen+".valor" );
			$scope.etiquetaDatosBasicos      = generalService.getDatafromCategory("HEADER", "ETIQUETA DATOS BASICOS", $scope.origen+".valor" );
			$scope.etiquetaDatosHogar        = generalService.getDatafromCategory("HEADER", "ETIQUETA DATOS HOGAR", $scope.origen+".valor" );
			$scope.etiquetaDatosEmpleo       = generalService.getDatafromCategory("HEADER", "ETIQUETA DATOS EMPLEO", $scope.origen+".valor" );
			$scope.etiquetaGastos            = generalService.getDatafromCategory("HEADER", "ETIQUETA GASTOS", $scope.origen+".valor" );
			$scope.etiquetaObligadoSolidario = generalService.getDatafromCategory("HEADER", "ETIQUETA OBLIGADO SOLIDARIO", $scope.origen+".valor" );
			$scope.etiquetaReferencias       = generalService.getDatafromCategory("HEADER", "ETIQUETA REFERENCIAS", $scope.origen+".valor" );
			$scope.etiquetaExpediente        = generalService.getDatafromCategory("HEADER", "ETIQUETA EXPEDIENTE", $scope.origen+".valor" );
			$scope.etiquetaContratos         = generalService.getDatafromCategory("HEADER", "ETIQUETA CONTRATOS", $scope.origen+".valor" );
			$scope.etiquetaVisitaAsesor      = generalService.getDatafromCategory("HEADER", "ETIQUETA VISITA ASESOR", $scope.origen+".valor" );
			$scope.etiquetaHomonimos         = generalService.getDatafromCategory("HEADER", "ETIQUETA HOMONIMOS", $scope.origen+".valor" );
			$scope.etiquetaEstatus           = generalService.getDatafromCategory("HEADER", "ETIQUETA ESTATUS", $scope.origen+".valor" );
			var seccionId = $location.$$path;
			if ($scope.origen == "TIENDA"){
				$scope.direccionOpcion = $scope.etiquetaOpciones;				
			}else{
				$scope.direccionOpcion = "";
			}
/** INICIA_OS-FLUJO COACREDITADO **/
			$scope.regresaOchoPasos = seccionId === "/ochoPasosOS"?true:false;
			$scope.muestraInicio=true;
			switch(seccionId){
			case	 "/ochoPasosOS":
				$scope.direccionOS = $rootScope.banderaCoacreditado ? "> Salir del Coacreditado" : "> Salir del Obligado Solidario";
				$scope.direccionOpcion = "";
				$scope.direccion = "";
					break;
/** TERMINA_OS-FLUJO COACREDITADO **/
			case "/ochoPasos":	 
				if ($scope.origen == "WEB"){
					$scope.direccion = $scope.etiquetaOpciones;
				}else{
					$scope.direccion = "";
				}
					break;
			case "/datosPersonales":
				$scope.direccion = $scope.etiquetaDatosBasicos;
				break;
			case "/datosHogar":
				$scope.direccion = $scope.etiquetaDatosHogar;
				break;					
			case "/datosEmpleo":
				$scope.direccion = $scope.etiquetaDatosEmpleo;
				break;
			case "/ingresosGastos":
				$scope.direccion = $scope.etiquetaGastos;
				break;
			case "/aval":
				$scope.direccion = $scope.etiquetaObligadoSolidario;
				break;
			case "/referencias":
				$scope.direccion = $scope.etiquetaReferencias;
				break;
			case "/expediente":
				$scope.direccion = $scope.etiquetaExpediente;
				break;
			case "/contratos":
				$scope.direccion = $scope.etiquetaContratos;
				break;				
			case "/visitaAsesor":
				$scope.direccion = $scope.etiquetaVisitaAsesor;
				$scope.direccionOpcion = "";
				break;
			case "/homonimos":
				$scope.direccion = $scope.etiquetaHomonimos;
				$scope.direccionOpcion = "";
				break;
			case "/estatus":
				$scope.direccion = $scope.etiquetaEstatus;
				$scope.direccionOpcion = "";
				break;
			case "/":
				$scope.direccion = "";
				$scope.direccionOpcion = "";
				$scope.muestraInicio=false;
				break;
			case "/menuWrapper":
				$scope.direccion = "";
				$scope.direccionOpcion = "";
				$scope.muestraInicio=false;
				break;
		case "/simulador":
			$scope.direccion = "";
			$scope.direccionOpcion = "";
			$scope.muestraInicio=false;
			break;
			default:
				$scope.direccion = "";
				$scope.direccionOpcion = "";
				break;
			}
			
		}
		
		$rootScope.$on("$locationChangeStart", function() {
			$scope.ruta();
		});
	
		$scope.objSelected = function(selected) {					
			generalService.setArrayValue("selectedBusqueda", selected);
			
			// Workoaround. Doble originación de solicitudes desde el rechazo.
			$rootScope.solicitudesProceso = null;
			$rootScope.getSolicitudesEnProceso = false;
			
			$rootScope.contratosResponseCita = true;
			$rootScope.documetosResponseCita = true;
			// GENERA_CODIGO_CELULAR = 1;
			
			/* TOLUCA */
			if (selected && selected.originalObject && selected.originalObject.tipoLevantamiento == 3 
				&& $rootScope.userSession.existeOfflineNuevoFlujoConsumo) {
				/**
				 * sólo se toman estos atriburos del JSON original, para hacer el objeto más ligero, dado que 
				 * el original contiene mucha más información, incluso una cadena en b64 de foto.
				 */ 
				let depuredObject = {
					originalObject: {
						idSolicitud: selected.originalObject.idSolicitud,
						idEstatusSeguimiento: selected.originalObject.idEstatusSeguimiento,
						primerNombre: selected.originalObject.primerNombre,
						apellidoPaterno: selected.originalObject.apellidoPaterno,
						apellidoMaterno: selected.originalObject.apellidoMaterno,
						celular: selected.originalObject.celular,
						status: selected.originalObject.status,
						cu: selected.originalObject.cu,
						fcPersonaID: selected.originalObject.fcPersonaID,
						marcaID: selected.originalObject.marcaID,
						fiMotivoRechazoID: selected.originalObject.fiMotivoRechazoID,
						diasRechazo: selected.originalObject.diasRechazo,
						condicionID: selected.originalObject.condicionID,
						fiStatusLcrID: selected.originalObject.fiStatusLcrID,
						fiMotivoBloqueoID: selected.originalObject.fiMotivoBloqueoID,
						tieneCu: selected.originalObject.tieneCu,
						creditoInmediato: selected.originalObject.creditoInmediato,
						tipoPersona: selected.originalObject.tipoPersona,
						tipoLevantamiento: selected.originalObject.tipoLevantamiento 
					}
				};

				// Se levanta un Spinner.
				$rootScope.waitLoaderStatus = LOADER_SHOW;

				if (configuracion.so.windows) { // Es Güindous.
					// Se guarda el objeto para su posterior recuperación en la offline de Toluca.
					$rootScope.guardaDatosIpad('RomeoMustDie', angular.toJson(depuredObject), false);

					// Redirigir a la aplicación de Toluca.
					$timeout(function() { window.location.replace(PORTAL_CONSUMO_TOLUCA); }, 100);

					// Ya no se continúa con el proceso.
					return;
				} else if (false && configuracion.so.ios) { // Es Aypat. TODO El wrapper de iPad no está listo aún. 
					// Redirigir a la aplicación de Toluca.
					$rootScope.executeAction('', '', 
						{
							'nombre': 'redirectionToMoc',
							'carpeta': 'Originacion_Credito',
							'ruta': 'webapp/index.html',
							'jump': true,
							'data': {
								'RomeoMustDie': angular.toJson(depuredObject)
							}
						}
					);
					
					// Ya no se continúa con el proceso.
					return;
				} else {
					console.log('R U f*cki\' kidding me?!');

					// Se baja un Spinner.
					$rootScope.waitLoaderStatus = LOADER_HIDE;
				}
			}
			
			generalService.locationPath("/recuperaSolicitud");
		};
		
		$scope.getSolicitud = function(){
			
			imgDocumento[IDENTIFICACION_OFICIAL.id] = {imgB64:null, width:null, height:null};
			imgDocumento[COMP_DOMICILIO.id] = {imgB64:null, width:null, height:null};
			imgDocumento[COMP_INGRESOS.id] = {imgB64:null, width:null, height:null};
			imgDocumento[COMP_PROPIEDAD.id] = {imgB64:null, width:null, height:null};
			imgDocumento[COMP_ARRAIGO_DOMICILIARIO.id] = {imgB64:null, width:null, height:null};
			imgDocumento[COMP_ARRAIGO_LABORAL.id] = {imgB64:null, width:null, height:null};
			imgDocumento[IDENTIFICACION_OFICIAL_AVAL.id] = {imgB64:null, width:null, height:null};
			imgDocumento[COMP_DOMICILIO_AVAL.id] = {imgB64:null, width:null, height:null};
			imgDocumento[COMP_INGRESOS_AVAL.id] = {imgB64:null, width:null, height:null};
			imgDocumento[COMP_PROPIEDAD_AVAL.id] = {imgB64:null, width:null, height:null};
						
			generalService.buildSolicitudJson($rootScope, $rootScope.solicitudJson);						
			$rootScope.waitLoaderStatus = LOADER_SHOW; 						 
							
			solicitudService.getSolicitud( $scope.solId ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;

					if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
												
						if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							$rootScope.solicitudJson = j.data;						
							modalService.alertModal("OK "+j.codigo, [j.descripcion]);
							generalService.locationPath("/ochoPasos");
						
						}else if(j.codigo == RESPONSE_CODIGO_ERROR_ID){
							$rootScope.message("Aviso", [j.descripcion], "Aceptar", $scope.backPath.root, "bgCafe", "cafeD");
						}
						
					}else
						$rootScope.message("Error "+data.data.codigo, [generalService.displayMessage(data.data.descripcion)], "Aceptar");
					
				}, function(error){
					$rootScope.waitLoaderStatus = LOADER_HIDE;																							
				}
			);
		};
		
		
		$scope.obtieneFoto = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			var x = {
					ruta: 0,
					idSolicitud: $scope.solicitudCliente,
					cadena: null,
					tipoCadena: null,
					mano: null,
					dedo: null
			};
			clienteUnicoService.getFoto(x).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						$scope.resp = JSON.parse(data.data.respuesta);
						console.log($scope.resp);
						if ($scope.resp.codigo == 2) {
							var cadenaFoto = $scope.resp.data;
							$rootScope.fotoCte = 'data:image/png;base64,' + cadenaFoto;
							
						} else {
							$rootScope.fotoCte = 'data:image/png;base64,' + $scope.sombra;
						}
					} else {
						$rootScope.fotoCte = 'data:image/png;base64,' + $scope.sombra;
					};
				},
				function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
				});
		};
		
		$scope.getFoto = function(){
			var foo = function(param) {
				$scope.solicitudCliente = param;
			}
			$scope.obtieneFoto($scope.solicitudCliente, foo);
		};
		
		$scope.clearInput = function (id) {
	      if (id) {
	        $scope.$broadcast('angucomplete-alt:clearInput', id);
	      }
	      else{
	        $scope.$broadcast('angucomplete-alt:clearInput');
	      }
	    }

		$scope.initSession = function(){
			generalService.locationPath("/login");
		};
		
		// Variable para guardar una función postEnvío de encolados.
		var funcionPostEnvio;
		
		$scope.endSession = function() {
			// Arriba el spinner.
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			if(configuracion.so.windows) {
				// Función a ejecutar cuando se termine el envío de documentos.
				funcionPostEnvio = function() {
					$rootScope.executeAction("moduloTracker", "respuestaComponente", {"nombre": "logout"});
				};
				
				var SEND_QUEUED_DOCUMENTS;
				
				try {
					SEND_QUEUED_DOCUMENTS = $rootScope.consultaFuncionalidad.sndQdDcmntsWhnClsngSession;
				} catch(x) {
					SEND_QUEUED_DOCUMENTS = false;
				}
				
				if(SEND_QUEUED_DOCUMENTS) {
					// Función para el envío de documentos.
					sendAllQueuedDoctos();
				} else {
					funcionPostEnvio();
				}
			} else {
				sessionService.endSession().then(
					function(data) {
						// Abojo el spinner.
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						$rootScope.inSession = false;
						$rootScope.userSession = null;  
                		$rootScope.sucursalSession = null;
						
						generalService.cleanRootScope($rootScope);						
						generalService.buildSolicitudJson($rootScope, null);
						generalService.setArrayValue("initAPP", true);
						generalService.locationPath("/");
					}, function(error) {
						// Abajo el spinner.
						$rootScope.waitLoaderStatus = LOADER_HIDE;
					}
				);
			}
		};
		
		$scope.respuestaComponente = function(respuestaIpad) {
			// Abajo el spinner.
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			
			try {
				$rootScope.loggerIpad("respuestaComponente", null, respuestaIpad);
				
				if(!response.codigo == RESPONSE_CODIGO_EXITO_IPAD) {
					$rootScope.message("Error cerrar sesión", [respuestaIpad], 
						"Aceptar", null, null, null, null, null, null
					);
				}
			} catch(e) {
				$rootScope.message("Error cerrar sesión", 
					[e.message], "Aceptar", null, null, null, null, "GENERAL", "EXCEPCION COMPONENTE"
				);
			}
		};
		
		$rootScope.getSolicitudes = function() {		
			$rootScope.solicitudesProceso = null;
			$rootScope.getSolicitudesEnProceso = true;
			
			if($rootScope.inSession) {					 								
				$scope.busquedaCSS = "busquedaLoading";
				solicitudService.getSolicitudesProceso().then(
					function(data) {
						$rootScope.getSolicitudesEnProceso = false;
						$scope.busquedaCSS = "busqueda";

						if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO) {
							var response = JSON.parse(data.data.respuesta);
							
							$rootScope.solicitudesProceso = response.data;	
							
							for(var i = 0; i < $rootScope.solicitudesProceso.length; i++) {
								$rootScope.solicitudesProceso[i].buscar = $rootScope.solicitudesProceso[i].primerNombre 
									+ " " + $rootScope.solicitudesProceso[i].apellidoPaterno 
									+ " " + $rootScope.solicitudesProceso[i].apellidoMaterno 
									+ " " + $rootScope.solicitudesProceso[i].status;
							}
						}
					}, function(error) {	
						$rootScope.getSolicitudesEnProceso = false;
						$scope.busquedaCSS = "busqueda";
					}
				);			
			}
		};
		
		/***
		 * 
		 * Cosulta el servicio de busqueda por nombre
		 * 
		 * ***/
		$rootScope.obtenerSolicitudesPorNombre = function(tempFilterText){
			$rootScope.solicitudesProceso=null;
			$rootScope.getSolicitudesEnProceso=true;
			
			var jsonRequest =  {
					"nombreCliente":  tempFilterText
			};
			
			if($rootScope.inSession){					 								
				$scope.busquedaCSS = "busquedaLoading";
				solicitudService.obtenerSolicitudesPorNombre(jsonRequest).then(
					function(data){
						$rootScope.getSolicitudesEnProceso=false;
						$scope.busquedaCSS = "busqueda";

						if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
							var response = JSON.parse(data.data.respuesta);
							$rootScope.solicitudesProceso = response.data;
							
							for (var i = 0; i < $rootScope.solicitudesProceso.length; i++) {
						        	  $rootScope.solicitudesProceso[i].buscar = $rootScope.solicitudesProceso[i].primerNombre + " " + $rootScope.solicitudesProceso[i].apellidoPaterno + " " + $rootScope.solicitudesProceso[i].apellidoMaterno + " " + $rootScope.solicitudesProceso[i].status;
							}
							
						}
						
					}, function(error){	
						$rootScope.getSolicitudesEnProceso=false;
						$scope.busquedaCSS = "busqueda";
					}
				);			
			}
			
		};
		
//		$timeout(function(){
//			$rootScope.getSolicitudes(); 
//			 
//		 }, 500)
			

		$scope.goPage = function( pathDestino ){
			if($rootScope.paginaActual=="simulador" && configuracion.so.windows)
				generalService.locationPath("/menuWrapper");
			if (pathDestino == "/simulador"){
				generalService.cleanRootScope($rootScope);
				generalService.buildSolicitudJson($rootScope, null);
				generalService.locationPath("/menuWrapper");
/** INICIA_OS-FLUJO COACREDITADO **/
			}else if(pathDestino == "/ochoPasos"){
				generalService.locationPath("/ochoPasos");
/** TERMINA_OS-FLUJO COACREDITADO **/				
			}else{
				if( generalService.isEmpty( generalService.getArrayValue("sourcePath") ))
					validateService.path(pathDestino);				
				else
					generalService.locationPath(generalService.getArrayValue("sourcePath"));
			}
		};		
		
		/**
		 * Función para traer los clientes que tienen documentes pendientes de envío.
		 */
		function sendAllQueuedDoctos() {
			$rootScope.obtenerClientesConEnviosWV("encabezadoDiv", "getClientsWithPendingsResponse");
		};
		
		// Variable para los clientes, con sus pendientes.
		var pendings = {
			clientes: [],
			index: 0
		};
		
		/**
		 * Función de callback, para configurar los clientes con pendientes.
		 */
		$scope.getClientsWithPendingsResponse = function(response) {
			// ¿Qué nos trajo el viento?
			$rootScope.loggerIpad("getClientsWithPendingsResponse", null, response);
			
			// Si no se cuenta con la función, se define.
			if(!Array.isArray) {
				Array.isArray = function (value) {
					return Object.prototype.toString.call(value) === "[object Array]";
				};
			}
			
			var ok = false;
			
			if(typeof response !== "undefined") {
				try {
					// ¿Éxito rotundo?
					if(response.codigo == RESPONSE_CODIGO_EXITO_IPAD) {
						if(Array.isArray(response.clientes)) {
							if(response.clientes.length > 0) {
								// Habemus clientes.
								pendings.clientes = response.clientes;
								
								// Ahora hay que traer los documentos encolados.
								getQueuedDoctos("Let\'s go!");
								
								// Parece ser que todo fue bien.
								ok = true;
							}
						}
					}
				} catch(z) {}
			}
			
			if(!ok) {
				letsGoNow();
			}
		};
		
		/**
		 * Función para traer los encolados de un cliente.
		 * @param isItFirst. Si se provee de cualquier cosa a la función, se entiende que se debe iniciar con el primer
		 * cliente.
		 */
		function getQueuedDoctos(isItFirst) {
			// Es el primero
			if(typeof isItFirst !== "undefined") {
				// Vamos a empezar.
				pendings.index = -1;
			}
			
			if(++(pendings.index) < pendings.clientes.length) {
				$rootScope.obtenerEnviosXCliente("encabezadoDiv", "getPendingsResponse", 
						pendings.clientes[pendings.index].identifier);
			} else {
				// Sacar provecho de los hilos de arquitectura en los envíos.
				var useArqThreads = false;
				
				if(useArqThreads) {
					// Se recorre el arreglo de clientes.
					for(var i in pendings.clientes) {
						// Se recorre el arreglo de pendientes del cliente.
						for(var j in pendings.clientes[i].pendientes) {
							// Se envía el documento encolado.
							$rootScope.enviarDocumentoWV("encabezadoDiv", "onlyPrint", 
								pendings.clientes[i].identifier, pendings.clientes[i].pendientes[j].identifier
							);
						}
					}
					
					// Nos vamos.
					letsGoNow();
				} else {
					startSendClientPendings("Let\'s start!");
				}
			}
		};
		
		/**
		 * Función de callback, para el envío "simultáneo" de documentos encolados.
		 */
		$scope.onlyPrint = function(response) {
			// ¿Qué nos trajo el viento?
			$rootScope.loggerIpad("onlyPrint", null, response);
		}
		
		/**
		 * Función de callback, para configurar los pendientes de los clientes.
		 */
		$scope.getPendingsResponse = function(response) {
			// ¿Qué nos trajo el viento?
			$rootScope.loggerIpad("getPendingsResponse", null, response);
			
			// Si no se cuenta con la función, se define.
			if(!Array.isArray) {
				Array.isArray = function (value) {
					return Object.prototype.toString.call(value) === "[object Array]";
				};
			}
			
			if(typeof response !== "undefined") {
				try {
					if(response.codigo == RESPONSE_CODIGO_EXITO_IPAD) {
						if(Array.isArray(response.peticiones)) {
							if(response.peticiones.length > 0) {
								// Aquí están los documentos pendientes de envío.
								pendings.clientes[pendings.index].pendientes = response.peticiones;
								pendings.clientes[pendings.index].indexDocto = 0;
								pendings.clientes[pendings.index].size = response.peticiones.length;
							}
						}
					}
				} catch(y) {}
			}
			
			// Hay que obtener los documentos del cliente que sigue (si es que hay alguno).
			getQueuedDoctos();			
		};
		
		
		/**
		 * Función para empezar el envío de los documentos pendientes para cada cliente.
		 * @param isItFirst, si se provee de cualquier cosa a la función, se entiende que se debe empezar con el primer
		 * cliente. 
		 */
		function startSendClientPendings(isItFirst) {
			// Es el primero.
			if(typeof isItFirst !== "undefined") {
				// Vamos a empezar.
				pendings.index = -1;
			}
			
			if(++(pendings.index) < pendings.clientes.length) {
				// Se configuró algo pendiente, mediante el componente.
				if(typeof pendings.clientes[pendings.index].pendientes !== "undefined") {
					$rootScope.enviarDocumentoWV("encabezadoDiv", "sendDoctoResponse", 
						pendings.clientes[pendings.index].identifier, 
						pendings.clientes[pendings.index].pendientes[pendings.clientes[pendings.index].indexDocto].identifier
					);
				} else { // Por alguna razón no hay pendientes, para el cliente.
					// Seguimos con otro cliente, no pasa nada.
					startSendClientPendings();
				}
			} else {
				// Vámonos riendo.
				letsGoNow();
			}
		};
		
		/**
		 * Función de callback para el envío de documentos.
		 * Dado que el envío pudo o no llevarse a cabo, pero se debe continuar con el siguiente, no importa mucho 
		 * el éxito del proceso. 
		 */
		$scope.sendDoctoResponse = function(response) {
			// ¿Qué nos trajo el viento?
			$rootScope.loggerIpad("sendDoctoResponse", null, response);
			
			// Aún hay pendientes de envío para el cliente.
			if(++(pendings.clientes[pendings.index].indexDocto) < pendings.clientes[pendings.index].size) {
				$rootScope.enviarDocumentoWV("encabezadoDiv", "sendDoctoResponse", 
					pendings.clientes[pendings.index].identifier, 
					pendings.clientes[pendings.index].pendientes[pendings.clientes[pendings.index].indexDocto].identifier
				);
			} else { // Ya no hay pendientes para el cliente.
				// Vamos con otro cliente (si hay otro cliente).
				startSendClientPendings();
			}
		};
		
		/**
		 * Función para continuar con el proceso, en caso de que falle la recuperación de clientes con envíos pendientes
		 * o simplemente por que se terminó el proceso.
		 */
		function letsGoNow() {
			// Se desconfigura el arreglo de clientes, se configura el index en 0.
			pendings = {
				clientes: [],
				index: 0
			};
			
			// Función post-envío.
			if(typeof funcionPostEnvio !== "undefined") {
				funcionPostEnvio();
			}
		};
	});
});	