'use strict';

define(["app"], function (app) {
	
	app.controller('recuperaSolicitudController',function($rootScope, $scope,  messageData, modalService, generalService, solicitudService, clienteUnicoService, 
														  recuperaSolicitudService, tarjetaService, documentosService, obligadoSolidarioService, generalServiceOS) {
		
		var solicitudRechazadaMas30dias = null;
		//CBS No limpiar firmaPrivacidad y firmaBuro si se realiza esl cambio de sucursal.
		$rootScope.firmaPrivacidad = migrarSolicitud() === "aceptado"?$rootScope.firmaPrivacidad:undefined;
		$rootScope.firmaBuro = migrarSolicitud() === "aceptado"?$rootScope.firmaBuro:undefined;
		$rootScope.firmaCaratula = undefined;
		$rootScope.firmaSolicitud = undefined;
		$rootScope.firmaSeguroCliente = undefined;
		$rootScope.firmaSeguroCarta = undefined;
		$rootScope.firmaAcuseTaz = undefined;
		$rootScope.firmaSolicitudCreditoUno = undefined;
		$rootScope.firmaSolicitudCreditoDos = undefined;
		$rootScope.firmaBienes = undefined;
		
/** INICIA_OS-FLUJO COACREDITADO **/
		
		/** Limpiamos los valores de las firmas **/
		$rootScope.firmaPrivacidadOS = undefined;
		$rootScope.firmaBuroOS = undefined;
		$rootScope.firmaCaratulaOS = undefined;
		$rootScope.firmaSolicitudOS = undefined;
		$rootScope.firmaSeguroClienteOS = undefined;
		$rootScope.firmaSeguroCartaOS = undefined;
		
		$rootScope.nombreCamelOS = "";
		$rootScope.apellidoPaternoCamelOS = "";
		$rootScope.apellidoMaternoCamelOS = "";
		
		$rootScope.muestraObligadoSolidario = false;
		$rootScope.muestraOpcionOS = false;
		$rootScope.muestraMiniConsumo = false;
		
/** TERMINA_OS-FLUJO COACREDITADO **/

		$scope.init = function(){	
			
			if(messageData){
				
				var selected = generalService.getArrayValue("selectedBusqueda");
												
				
				if(selected){
										
					generalService.setArrayValue("selectedBusqueda", null);					
					$rootScope.waitLoaderStatus = LOADER_SHOW; 																																														
					
					
					try{
						var json = { "Response": selected.originalObject };		    		
				    	$rootScope.loggerServicios("cargaDato.IdSolicitudRecuperar", json);
					}catch (e) {
					}					
		    	
					var recuperasolicitud=null;
					if(selected.originalObject.captacion)
						recuperasolicitud = {continar: true, path: null};
					else
						recuperasolicitud = generalService.recuperarSolicitud( selected.originalObject );
					
					resetDatosEvento();					
					recuperaSolicitudService.loadSolicitud(selected.originalObject.idSolicitud, recuperasolicitud, $rootScope, selected.originalObject ).then(
							function(exito){
								if(recuperasolicitud.continar){
									if(exito){
										if(exito == RESPONSE_CODIGO_ERROR_ID){
											generalService.cleanRootScope($rootScope);
											generalService.buildSolicitudJson($rootScope, null);
							/** INICIA_OS**/
											generalService.buildSolicitudOSJson($rootScope, null);
							/** TERMINA_OS**/
											
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$rootScope.message( "Error "+RESPONSE_CODIGO_ERROR_ID, ["Problemas con la solicitud, Reintente mas tarde"], "Aceptar","/simulador");
										}else if(exito == SOLICITUD_EN_PROCESO_DE_ACTUALIZACION){

											generalService.cleanRootScope($rootScope);
											generalService.buildSolicitudJson($rootScope, null);
							/** INICIA_OS**/
											generalService.buildSolicitudOSJson($rootScope, null);
							/** TERMINA_OS**/
											
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$rootScope.message( "Error "+SOLICITUD_EN_PROCESO_DE_ACTUALIZACION, ["La solicitud se encuentra en el proceso de actualización de datos. Favor de finalizar el proceso de actualización de datos"], "Aceptar","/simulador");
											
										}else if(exito == RESPONSE_CODIGO_ERROR_BAZ_DIGITAL){
											generalService.cleanRootScope($rootScope);
											generalService.buildSolicitudJson($rootScope, null);
							/** INICIA_OS**/
											generalService.buildSolicitudOSJson($rootScope, null);
							/** TERMINA_OS**/
											
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$rootScope.message( "Error "+RESPONSE_CODIGO_ERROR_BAZ_DIGITAL, ["El cliente tiene una solicitud de BAZ Digital en proceso. Favor de recuperarla desde la aplicación."], "Aceptar","/simulador");
										}else if(exito == RESPONSE_CODIGO_ERROR_GENERAL){
											generalService.cleanRootScope($rootScope);
											generalService.buildSolicitudJson($rootScope, null);
							/** INICIA_OS**/
											generalService.buildSolicitudOSJson($rootScope, null);
							/** TERMINA_OS**/
											
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$rootScope.message( "Error "+RESPONSE_CODIGO_ERROR_GENERAL, ["Problemas con la solicitud, Reintente mas tarde"], "Aceptar","/simulador");
										}else{
											//CBS Si el cliente es apto para el cambio de sucursal saltarse las firmas
											if(migrarSolicitud()==="aceptado"){
												if($rootScope.requiereObligado){
													modalService.alertModal("AVISO",["Lo sentimos, el cliente debe acudir a la sucursal "+$rootScope.solicitudJson.idSucursal+" a continuar con su solicitud"], "Aceptar")
													generalService.buildSolicitudJson($rootScope, null);
													generalService.buildSolicitudOSJson($rootScope, null);
													generalService.locationPath("/simulador");
												}else
													recuperaFotoCliente($rootScope.solicitudJson.idSolicitud,exito,recuperasolicitud);
											}else
						     /** INICIA_OS**//** Buscamos que la solicitud tenga un Coacreditado **/
												$scope.recuperaSolicitudObligadoSolidario(exito,recuperasolicitud);
							/** TERMINA_OS**/
										}
										
										
										
									}else
										goPath(null)
								}else if(exito == RESPONSE_CODIGO_ERROR_BAZ_DIGITAL){
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									generalService.cleanRootScope($rootScope);
									generalService.buildSolicitudJson($rootScope, null);
									generalService.buildSolicitudOSJson($rootScope, null);
									$rootScope.message( "Aviso", ["El cliente tiene una solicitud de BAZ Digital en proceso. Favor de recuperarla desde la aplicación."], "Aceptar","/simulador");
								}else{							
									if(recuperasolicitud.path == "huella"){
										solicitudRechazadaMas30dias = selected.originalObject.idSolicitud;
										if(generalService.isEmpty(selected.originalObject.cu)){
											$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
										}else{
											validaHuella(selected.originalObject.cu);
										}
									}else
										goPath(null);
								}
																										
								
							},function(error){
								console.log("");
							}
						);
										
					
				}else
					generalService.locationPath("/simulador");
				
				
			}		
			
		};
		

		$scope.obtenerVerificacion = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.obtenerTipoVerificacion( $rootScope.solicitudJson.idSolicitud ).then(
					function(data){						
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							var response = JSON.parse(data.data.respuesta);
							$rootScope.tipoVerificacion = response.codigo;
							console.log("Tipo de Verificación: " + response.descripcion);
							generalService.locationPath( generalService.getPathSection($rootScope.solicitudJson,$rootScope.sucursalSession.idCanal) );
						}else{
							$rootScope.message("¡Error!", 
									["Respuesta: " + data.data.respuesta],
									"Aceptar"
							);
						}
					}, function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("¡Error!", 
								["Hubo un inconveniente al consumir el servicio que valida la verificación, favor de intentar nuevamente"],
								"Aceptar"
						);
					}
				);			
		};		
		
/** INICIA_OS-FLUJO COACREDITADO **/
		/** Inicia recuperar Coacreditado **/
		/** Lo primero es validar que exista un Coacreditado en base a  idSolicitudObligadoSolidario dentrp del JSON del cliente
		 *  Si existe Coacreditado lanzamos la busqueda de contrario continuamos con recuperar las firmas del cliente
		 *  Si la respuesta es exitosa o ocurrió algún error continuamos recuperando la información del cliente
		 *  Si existe Coacreditado entonces recuperar la solicitud del cliente y del Coacreditado
		 **/
		$scope.recuperaSolicitudObligadoSolidario = function(exito,recuperasolicitud){
			try{
				if($rootScope.solicitudJson.obligadoSolidario.idSolicitudObligadoSolidario != "" && $rootScope.solicitudJson.obligadoSolidario.idSolicitudObligadoSolidario != null){
					var request = {
						idSolicitudOS: $rootScope.solicitudJson.obligadoSolidario.idSolicitudObligadoSolidario,
					}
					
					obligadoSolidarioService.buscarSolicitudOS(request).then(
						function(data) {
							
							if ( data.data.codigo == RESPONSE_CODIGO_EXITO ) {
								
								var jsonResponse = JSON.parse( data.data.respuesta.solicitudJson );
								
								if( jsonResponse.codigo == 2 || jsonResponse.codigo == 420){
									
									$rootScope.solicitudOSJson = jsonResponse.data;
									
									try{
										$rootScope.historicoMarcasOS = null;
			                			if(data.data.respuesta.historicoMarcas){
			                				var j = JSON.parse(data.data.respuesta.historicoMarcas);
		                					$rootScope.historicoMarcasOS = [];
		                					for(var i=0;i<j.data.length;i++){
		                						$rootScope.historicoMarcasOS[i]=j.data[i].marca;
		                					}
//		                					$rootScope.banderaCoacreditado = generalServiceOS.consultaHistoricoMarcasOS([171])!=0?true:false;
		                					$rootScope.banderaCoacreditado = true;
			                			} else {
			                				$rootScope.message( "Invonveniente al recuperar la Solicitud", ["Ocurrio un invonveniente al recuperar la información, por favor, intentelo más tarde."], "Aceptar","/simulador");
			                			}
									}catch(error){
										$rootScope.message( "Invonveniente al recuperar la Solicitud", ["Ocurrio un invonveniente al recuperar la información, por favor, intentelo más tarde."], "Aceptar","/simulador");
									}
									
									$rootScope.nombreCamelOS=generalServiceOS.camelize($rootScope.solicitudOSJson.cotizacion.clientes[0].nombre);
									$rootScope.apellidoPaternoCamelOS=generalServiceOS.camelize($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno);
									$rootScope.apellidoMaternoCamelOS=generalServiceOS.camelize($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno);
									
									$scope.recuperaFirmas(exito,recuperasolicitud);
								}else{
									generalService.buildSolicitudOSJson($rootScope, null);
									$scope.recuperaFirmas(exito,recuperasolicitud);
								}
								
							} else {
								generalService.buildSolicitudOSJson($rootScope, null);
								$scope.recuperaFirmas(exito,recuperasolicitud);
							}
							
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
					});
				}else{
					generalService.buildSolicitudOSJson($rootScope, null);
					$scope.recuperaFirmas(exito,recuperasolicitud);
				}
			}catch(e){
				generalService.buildSolicitudOSJson($rootScope, null);
				$scope.recuperaFirmas(exito,recuperasolicitud);
			}
		}
		/** Termina recuperar Coacreditado **/
/** TERMINA_OS-FLUJO COACREDITADO **/
		
		//----------------------------------------------------------------------------------------------------------------------------
		$scope.obtenerCatalogos = function(catalogos, catalogosDes, numAtributos){
			var catalogosFinal = [];
						
			for(var i=0;i<catalogos.length;i++){				
				if(catalogos[i].descripcion === catalogosDes){
					var catalogosTmp = [];
					var cont = 0;
					
					for(var j=0;j<catalogos[i].listAtributos.length;j++){
						catalogosTmp.push(catalogos[i].listAtributos[j]);
						cont++;
						
						if(cont == numAtributos){
							catalogosFinal.push(catalogosTmp);
							catalogosTmp = [];
							cont = 0;
						}
					}
				}
			}
			
			return catalogosFinal;
		}
		
		$scope.obtenerParametros = function(catalogo, solicitudJsonParam, id, valor){
			var parametro = "";
			for(var i=0;i<catalogo.length;i++){
				var bandera = 0;
				for(var j=0;j<catalogo[i].length;j++){
					if(catalogo[i][j].id == id && catalogo[i][j].valor == solicitudJsonParam && bandera == 0){
						bandera = 1;
						j=0;
					}
					if(catalogo[i][j].id == valor && bandera == 1){
						parametro = catalogo[i][j].valor;
						break;
					}
				}
				
				if(bandera == 1){
					break;
				}
			}
			
			return parametro;
		}
		
		$scope.obtenerParametrosPais = function(catalogo, solicitudJsonParam){
			var parametro = "";
			for(var i=0;i<catalogo.length;i++){
				if(catalogo[i].id == solicitudJsonParam){
					parametro = catalogo[i].descripcion;
				}
			}
			
			return parametro;
		}
		
		$scope.mapearID = function(){
			try{
				var catalogos = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS"]; 
				
				var catalogosOcupacion = $scope.obtenerCatalogos(catalogos, "CATALOGO DE OCUPACION",4);
				var catalogosEstadoCivil = $scope.obtenerCatalogos(catalogos, "CATALOGO ESTADO CIVIL",4);
				var catalogoTipoempleo = $scope.obtenerCatalogos(catalogos, "CATALOGO PROFESION",4);
				var catalogoLugarNacimiento = $scope.obtenerCatalogos(catalogos, "CATALOGO ESTADOS",7);
				var catalogoGenero = $scope.obtenerCatalogos(catalogos, "CATALOGO GENERO",4);				
				var catalogoNacionalidad = [{id:1, descripcion:"Mexicana"},{id:2, descripcion:"Extranjera"}];
				
				$rootScope.solicitudJson.cotizacion.clientes[0].tipoTrabajoDes = ($scope.obtenerParametros(catalogosOcupacion,$rootScope.solicitudJson.cotizacion.clientes[0].idTipoTrabajo,1,2)).trim();
				$rootScope.solicitudJson.cotizacion.clientes[0].estadoCivil = ($scope.obtenerParametros(catalogosEstadoCivil,$rootScope.solicitudJson.cotizacion.clientes[0].idEstadoCivil,1,2)).trim();
				$rootScope.solicitudJson.cotizacion.clientes[0].puestoDes = ($scope.obtenerParametros(catalogoTipoempleo,$rootScope.solicitudJson.cotizacion.clientes[0].idPuesto,1,2)).trim();
				$rootScope.solicitudJson.cotizacion.clientes[0].lugarNacimientoDes = ($scope.obtenerParametros(catalogoLugarNacimiento,$rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento,1,2)).trim();
				$rootScope.solicitudJson.cotizacion.clientes[0].genero = ($scope.obtenerParametros(catalogoGenero,$rootScope.solicitudJson.cotizacion.clientes[0].idGenero,190,2)).trim();
				$rootScope.solicitudJson.cotizacion.clientes[0].nacionalidadDes = ($scope.obtenerParametrosPais(catalogoNacionalidad,$rootScope.solicitudJson.cotizacion.clientes[0].idNacionalidad)).trim();

				var catalogoOficios = $scope.obtenerCatalogos(catalogos, "CATALOGO OFICIOS",5);
				$rootScope.solicitudJson.cotizacion.clientes[0].puestoCUDes = ($scope.obtenerParametros(catalogoOficios,$rootScope.solicitudJson.cotizacion.clientes[0].idPuestoCU,364,362)).trim();
				$rootScope.solicitudJson.cotizacion.clientes[0].puestoSPCUDes = ($scope.obtenerParametros(catalogoOficios,$rootScope.solicitudJson.cotizacion.clientes[0].idPuestoSPCU,366,362)).trim();
			}catch(error){
				$rootScope.message( "Error", ["Ocurrio un error al extraer los datos. Comuniquese con soporte"], "Aceptar");
			}
		}
		
		//----------------------------------------------------------------------------------------------------------------------------
		
		function cuchupoMagico(recuperaFirmasParam1, recuperaFirmasParam2) {
			let arreglo = [
				{
					"idContrato": "1",
					"idPersona": "",
					"statusFirma": 0,
					"descripcion": "Aviso De Privacidad",
					"idTipoPersona": 1
				},
				{
					"idContrato": "2",
					"idPersona": "",
					"statusFirma": 0,
					"descripcion": "Buró de Crédito",
					"idTipoPersona": 1
				},
				{
					"idContrato": "3",
					"idPersona": "",
					"statusFirma": 0,
					"descripcion": "Contrato, Carátula y Anexo de Comisiones",
					"idTipoPersona": 1
				},
				{
					"idContrato": "4",
					"idPersona": "",
					"statusFirma": 0,
					"descripcion": "Solicitud de Crédito",
					"idTipoPersona": 1
				}
			];
			
			// Se configura el objeto de contratos.
			$rootScope.solicitudJson.contratos.contrato = arreglo;
			
			let guardar = {
				solicitudJson: angular.toJson($rootScope.solicitudJson), 
				seccion: SECCION_CONTRATOS
			};
			
			// Arriba el spinner.
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			// Se consume el servicio.
			solicitudService.saveSolicitud(guardar).then(
				function(success) {
					// Abajo el spinner.
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					if (success && success.data && success.data.codigo == RESPONSE_CODIGO_EXITO) {
						let response; 
						
						try {
							response = JSON.parse(success.data.respuesta);
						} catch(a) { console.log('¿Qué pasó, oiga?'); }
						
						if (response && response.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO) {
							$rootScope.solicitudJson = response.data;
							
							$scope.recuperaFirmas(recuperaFirmasParam1, recuperaFirmasParam2);
							
							return;
						}
					}
					
					// Se limpia el JSON de la solcitud.
					generalService.cleanRootScope($rootScope);
					// Se reconstruye el JSON de la solicitud.
					generalService.buildSolicitudJson($rootScope, null);
					
					$rootScope.message("AVISO", 
						["No se pudo configurar el objeto de contratos de la solicitud."], 
						"Aceptar", "/"
					);
				}, function(unsuccess) {
					// Abajo el spinner.
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					// Se limpia el JSON de la solcitud.
					generalService.cleanRootScope($rootScope);
					// Se reconstruye el JSON de la solicitud.
					generalService.buildSolicitudJson($rootScope, null);
					
					$rootScope.message("AVISO", 
						["Se tuvo un inconveniente al intentar configurar el objeto de contratos de la solicitud."], 
						"Aceptar", "/"
					);
				}
			);
		}
		
		$scope.recuperaFirmas=function(exitoLoad,recuperasolicitud){
		
			if( generalService.existeSolicitud($rootScope.solicitudJson) ){
				/**
				 * Dado que se presentan algunos casos de incompatibilidad con solicitudes BAz. Se detona un guardado
				 * de sección 8, contratos, para que el back pueda realizar la creación de estructura necesaria.
				 */
				if ($rootScope.solicitudJson && $rootScope.solicitudJson.contratos) {
					let arreglo = $rootScope.solicitudJson.contratos.contrato;
					
					if (!Array.isArray(arreglo)) {
						cuchupoMagico(exitoLoad, recuperasolicitud);
						
						return;
					}
				}
				
				$scope.mapearID();
				
				var x = {
						idSolicitud: $rootScope.solicitudJson.idSolicitud
				}
				
				documentosService.recuperaFirmas( x ).then(
					function(data){
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jResponse = JSON.parse(data.data.respuesta);
							
							if($rootScope.solicitudJson.campana !== "TAZORO" && $rootScope.solicitudJson.campana !== "TDCORO_CON" && $rootScope.solicitudJson.campana !== "TDCTECCONV"){
								var arrayContratos = $rootScope.solicitudJson.contratos.contrato;
								for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
									if(jResponse.data[i].idTipoContrato == arrayContratos[i].idContrato && arrayContratos[i].statusFirma != 0 
											&&!generalService.isEmpty(jResponse.data[0].firmaContrato))
										$rootScope.firmaPrivacidad =  "data:image/png;base64," + jResponse.data[0].firmaContrato;
									
									if(jResponse.data[i].idTipoContrato && arrayContratos[i].idContrato && arrayContratos[i].statusFirma != 0 
											&&!generalService.isEmpty(jResponse.data[1].firmaContrato))
										$rootScope.firmaBuro =  "data:image/png;base64," + jResponse.data[1].firmaContrato;
									
									if(jResponse.data[i].idTipoContrato && arrayContratos[i].idContrato && arrayContratos[i].statusFirma != 0 
											&&!generalService.isEmpty(jResponse.data[2].firmaContrato))
										$rootScope.firmaCaratula =  "data:image/png;base64," + jResponse.data[2].firmaContrato;
									
									if(jResponse.data[i].idTipoContrato && arrayContratos[i].idContrato && arrayContratos[i].statusFirma != 0){
										if(!generalService.isEmpty(jResponse.data[7].firmaContrato)){
											$rootScope.firmaSolicitud =  "data:image/png;base64," + jResponse.data[7].firmaContrato;
										}
										if(!generalService.isEmpty(jResponse.data[8].firmaContrato)){
											$rootScope.firmaSolicitudDos =  "data:image/png;base64," + jResponse.data[8].firmaContrato;
										}
										
										if(!generalService.isEmpty(jResponse.data[7].firmaContrato) && !generalService.isEmpty(jResponse.data[8].firmaContrato))
											$rootScope.solicitudJson.contratos.contrato[3].statusFirma = STATUS_CONTRATO.ENVIAD0;
									} 
									if(jResponse.data[i].idTipoContrato && arrayContratos[i].idContrato && arrayContratos[i].statusFirma != 0 
											&&!generalService.isEmpty(jResponse.data[4].firmaContrato))
										$rootScope.firmaSeguroCliente =  "data:image/png;base64," + jResponse.data[4].firmaContrato;
								
									if(jResponse.data[i].idTipoContrato && arrayContratos[i].idContrato && arrayContratos[i].statusFirma != 0 
											&&!generalService.isEmpty(jResponse.data[5].firmaContrato))
										$rootScope.firmaSeguroCarta =  "data:image/png;base64," + jResponse.data[5].firmaContrato;
									
									if(jResponse.data[i].idTipoContrato && arrayContratos[i].idContrato && arrayContratos[i].statusFirma != 0 
											&& !generalService.isEmpty(jResponse.data[6].firmaContrato))
										$rootScope.firmaAcuseTaz = "data:image/png;base64," + jResponse.data[6].firmaContrato;
									if(jResponse.data[i].idTipoContrato && arrayContratos[i].idContrato && arrayContratos[i].statusFirma != 0 
											&& !generalService.isEmpty(jResponse.data[9].firmaContrato))
										$rootScope.firmaBienes = "data:image/png;base64," + jResponse.data[9].firmaContrato;
								}
							}else{
								obtenerContratosTDC($rootScope.solicitudJson, jResponse);
							}
						}
/** INICIA_OS-FLUJO COACREDITADO **/
						/** Si todo es correcto lanzamos la búsqueda de las firmas para el Coacreditado **/
						$scope.recuperaFirmasOS(exitoLoad,recuperasolicitud);
						
					}, function(error){
						$scope.recuperaFirmasOS(exitoLoad,recuperasolicitud);
					}
				);
			}else
				$scope.recuperaFirmasOS(exitoLoad,recuperasolicitud);
/** TERMINA_OS-FLUJO COACREDITADO **/
		};
		
		function obtenerContratosTDC(solicitudJson, jResponse){
			for(var i=0;i<solicitudJson.contratos.contrato.length;i++){
				if($rootScope.solicitudJson.contratos.contrato[i].statusFirma != 3 && $rootScope.solicitudJson.contratos.contrato[i].statusFirma != 4){
					for(var j=0;j<solicitudJson.contratos.contrato.length;j++){
						if($rootScope.solicitudJson.contratos.contrato[i].idContrato == jResponse.data[j].idTipoContrato){
							if(jResponse.data[j].firmaContrato != null){
								if($rootScope.solicitudJson.contratos.contrato[i].idContrato === "1"){
									$rootScope.firmaPrivacidad =  "data:image/png;base64," + jResponse.data[j].firmaContrato;
									$rootScope.solicitudJson.contratos.contrato[i].statusFirma = 1;
									break;
								}else if($rootScope.solicitudJson.contratos.contrato[i].idContrato === "2"){
									$rootScope.firmaBuro =  "data:image/png;base64," + jResponse.data[j].firmaContrato;
									$rootScope.solicitudJson.contratos.contrato[i].statusFirma = 1;
									break;
								}else if($rootScope.solicitudJson.contratos.contrato[i].idContrato === "3"){

									if(!generalService.isEmpty(jResponse.data[7].firmaContrato)){
										$rootScope.firmaSolicitud =  "data:image/png;base64," + jResponse.data[7].firmaContrato;
									}
									if(!generalService.isEmpty(jResponse.data[8].firmaContrato)){
										$rootScope.firmaSolicitudDos =  "data:image/png;base64," + jResponse.data[8].firmaContrato;
									}
									break;
								}else if($rootScope.solicitudJson.contratos.contrato[i].idContrato === "4"){
									$rootScope.firmaCaratula =  "data:image/png;base64," + jResponse.data[j].firmaContrato;
									$rootScope.solicitudJson.contratos.contrato[i].statusFirma = 1;
									break;
								}else if($rootScope.solicitudJson.contratos.contrato[i].idContrato === "5"){
									$rootScope.firmaSeguroCliente =  "data:image/png;base64," + jResponse.data[j].firmaContrato;
									$rootScope.solicitudJson.contratos.contrato[i].statusFirma = 1;
									break;
								}else if($rootScope.solicitudJson.contratos.contrato[i].idContrato === "6"){
									$rootScope.firmaSeguroCarta =  "data:image/png;base64," + jResponse.data[j].firmaContrato;
									$rootScope.solicitudJson.contratos.contrato[i].statusFirma = 1;
									break;
								}
							}
						}
					}
				}
			}
		}
		
/** INICIA_OS-FLUJO COACREDITADO **/
		/** Inicia recuperar firmar del Coacreditado **/
		/** Revisamos que exista la solicitud del Coacreditado para poder recuperar las firmas 
		 *  Si todo esta bien vamos a recuperar las firmas
		 **/
		$scope.recuperaFirmasOS =function(exito,recuperasolicitud){
			
			if( generalService.existeSolicitud($rootScope.solicitudOSJson)){
				
				var x = {
						idSolicitud: $rootScope.solicitudOSJson.idSolicitud,
						sucursal:$rootScope.sucursalSession.idSucursal,
						usuario:$rootScope.userSession.noEmpleado
					};
				
				obligadoSolidarioService.recuperaFirmasOS(x).then(
					function(data) {
						
						if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
							
							var jResponse = JSON.parse(data.data.respuesta);
							var t = jResponse.data.length;
							
							for(var i = 0; i < $rootScope.solicitudOSJson.contratos.contrato.length; i++) {
								if(i < t) {
									if($rootScope.solicitudOSJson.contratos.contrato[i].statusFirma != 0 
											&& !generalService.isEmpty(jResponse.data[i].firmaContrato)) {
										switch(i) {
											case 0 : 
												$rootScope.firmaPrivacidadOS = "data:image/png;base64," 
													+ jResponse.data[i].firmaContrato;
												break;
											case 1 : 
												$rootScope.firmaBuroOS = "data:image/png;base64," 
													+ jResponse.data[i].firmaContrato;
												break;
											case 2 : 
												$rootScope.firmaCaratulaOS = "data:image/png;base64," 
													+ jResponse.data[i].firmaContrato;
												break;
											case 3 : 
												$rootScope.firmaSolicitudOS = "data:image/png;base64," 
													+ jResponse.data[i].firmaContrato;
												break;
											case 4 : 
												$rootScope.firmaSeguroClienteOS = "data:image/png;base64," 
													+ jResponse.data[i].firmaContrato;
												break;
											case 5 : 
												$rootScope.firmaSeguroCartaOS = "data:image/png;base64," 
													+ jResponse.data[i].firmaContrato;
												break;
											default:
										}
									}
								} else {
									break;
								}
							}
						} 
						/** Recuperar la foto del cliente **/
						recuperaFotoCliente($rootScope.solicitudJson.idSolicitud,exito,recuperasolicitud);
				}, function(error) {
					recuperaFotoCliente($rootScope.solicitudJson.idSolicitud,exito,recuperasolicitud);
				});
			}else{
				recuperaFotoCliente($rootScope.solicitudJson.idSolicitud,exito,recuperasolicitud);
			}
		}
		/* Termina recuperar firmar del Coacreditado*/
/** TERMINA_OS-FLUJO COACREDITADO **/
		
		var recuperaFotoCliente = function(idSolicitud,exitoLoad,recuperasolicitud){
			if(generalService.existeSolicitud($rootScope.solicitudJson)){
				var biometrico = {
					ruta: null,
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					cadena: null, tipoCadena: null, porcentaje:null
				};
				
				clienteUnicoService.getFoto( biometrico ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var responseJson = JSON.parse(data.data.respuesta);
							
							if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								$rootScope.fotoCte = 'data:image/jpg;base64,'+responseJson.data;
							}
						}
/** INICIA_OS-FLUJO COACREDITADO **/
						/** Lanzamos la busqueda sobre la foto del Coacreditado **/
						recuperaFotoClienteOS(idSolicitud,exitoLoad,recuperasolicitud);
					}, function(error){
						recuperaFotoClienteOS(idSolicitud,exitoLoad,recuperasolicitud);
					}
				);
			}else
				recuperaFotoClienteOS(idSolicitud,exitoLoad,recuperasolicitud);
		}
		
		
		/** Inicia recuperar foto de Coacreditado **/
		/** Recuperamos la foto del cliente siempre y cuando haya Coacreditado **/
		var recuperaFotoClienteOS = function(idSolicitud,exitoLoad,recuperasolicitud){
			
			if($rootScope.solicitudJson.obligadoSolidario && $rootScope.solicitudJson.obligadoSolidario.idSolicitudObligadoSolidario != "" && $rootScope.solicitudJson.obligadoSolidario.idSolicitudObligadoSolidario != null && !generalService.solicitudOSRechazado()){
			
				var biometrico = {
						idSolicitud: $rootScope.solicitudOSJson.idSolicitud,
						ruta: "foto_aval"
				};
				clienteUnicoService.getFoto( biometrico ).then(
						function(data){
							
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
								
								var responseJson = JSON.parse(data.data.respuesta);
								
								if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
									$rootScope.fotoOS = 'data:image/jpg;base64,'+responseJson.data;
								}else{
									$rootScope.fotoOS = "data:image/png;base64," + $rootScope.imgUsuario;
								}
							}else{
								$rootScope.fotoOS = "data:image/png;base64," + $rootScope.imgUsuario;
							}
							
							flujoPathNormal(exitoLoad,recuperasolicitud);
						}, function(error){
							flujoPathNormal(exitoLoad,recuperasolicitud);
						}
					);
				
			}else
				flujoPathNormal(exitoLoad,recuperasolicitud);
		}
		/** Termina recuperar foto de Coacreditado **/
/** TERMINA_OS-FLUJO COACREDITADO **/
		
		
		var flujoPathNormal = function(exito,recuperasolicitud){
			if(exito == 311){
				generalService.setDataBridge({ origen:FICHA.origen.recuperar, tipoFicha : FICHA.tipoFicha.bloqueada });
				goPath("/ficha");											
			}else
				goPath(recuperasolicitud.path);
		};
		
		var goPath=function(path){
			if(!$rootScope.ejecutarEncuentaPreaprobado){
				$rootScope.solicitudJson.banderaOfertaCP=1;
			}
			$rootScope.waitLoaderStatus = LOADER_HIDE;				
			$rootScope.solicitudJson.tipoDispositivo = configuracion.so.windows?"Windows":configuracion.so.ios?"iPad":configuracion.origen.portalWeb?"Web":"Dispositivo No Reconocido";
/** INICIO_OS **/
			$rootScope.muestraObligadoSolidario = false;
			$rootScope.muestraOpcionOS = false;
/** TERMINA_OS **/
			
			if( generalService.isEmpty(path) ){				
				
																									
				if( generalService.existeSolicitud($rootScope.solicitudJson) ){	
					//CBS El cliente es apto para las firmas, pero no tiene CU entonces no pedir la huella e iniciar el cambio de sucursal
					if(migrarSolicitud()==="aceptado"){
						if($rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico == "")
							$scope.obtenerNombreSucursal();
						else
							validaHuella($rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico);
						
					}else if( $rootScope.solicitudJson.idCanal != $rootScope.sucursalSession.idCanal  &&  generalService.isProduccion() && TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) == -1){
						modalService.alertModal("AVISO",["Lo sentimos la solicitud fue originada en otro canal."], "Aceptar")
						generalService.buildSolicitudJson($rootScope, null);
	/** INICIO_OS **/
						generalService.buildSolicitudOSJson($rootScope, null);
    /** TERMINA_OS **/					
						generalService.locationPath("/simulador");
						
					}else if($rootScope.solicitudJson.idPlataforma == PLATAFORMA.BAZDIGITAL){
						modalService.alertModal("AVISO",["Lo sentimos la solicitud fue originada en otra plataforma."], "Aceptar")
						generalService.buildSolicitudJson($rootScope, null);
	/** INICIO_OS **/
						generalService.buildSolicitudOSJson($rootScope, null);
	/** TERMINA_OS **/
						generalService.locationPath("/simulador");
						
						/**
						 * Esta validacion regresa a callcenter. Esto sólo sucede cuando el cliente debe irse a Callcenter y no se generó un folio ya que se salio de la vista
						 * Al recuperar la solicitud debe regresar a la vista de callcenter para generar el folio. La solicitud debería venir marcada y no debería tener un folio de callcenter
						 */
						
					}else if($rootScope.sucursalSession.idCanal == CANALES.soriana && ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinTaz || $rootScope.solicitudJson.marca == 5006 || $rootScope.solicitudJson.marca == 1007)) {
						generalService.locationPath("/estatus");
					}else if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) == -1 && $rootScope.consultaFuncionalidad.flujoMesaAltaUnica && $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.generada.id && $rootScope.solicitudJson.folioCallCenter == "" && ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.ocrEditaIne || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.noOcrIne || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.noOcrPasaporte)) {
						generalService.esValidoFlujoCallCenter($rootScope.solicitudJson);
						generalService.setArrayValue("pasoCallCenter", 'init')
						generalService.setArrayValue("encolarImagenes", true);
						generalService.setArrayValue("pathOrigen", 'visorAsesor');
						generalService.locationPath("/callCenter");
					}else if(  $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico == "")		
						generalService.locationPath(generalService.getPathSection($rootScope.solicitudJson,$rootScope.sucursalSession.idCanal));																												
						
					else
						validaHuella($rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico);
						
						
				}else if($rootScope.urlAnterior != "#/avisos"){
					generalService.buildSolicitudJson($rootScope, null);
	/** INICIO_OS **/
					generalService.buildSolicitudOSJson($rootScope, null);
	/** TERMINA_OS **/				
					generalService.locationPath("/simulador");
				
				}else
					generalService.locationPath("/simulador");
																																											
			}else				
				generalService.locationPath(path);																		
			
		};
		
		
		var validaHuella=function(cu){
			
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) > -1){
				$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
			}else if(configuracion.origen.tienda){
				$rootScope.waitLoaderStatus = LOADER_SHOW;							
				$rootScope.verificarHuella( 'fondoDivId', 'responseVerificarHuellaIpad', [cu]);
			}else if(generalService.isProduccion()){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				modalService.huellaModal("bgAzul");
			}else{
				$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
			}
		};
		
		
		$scope.responseVerificarHuellaIpad = function( response ){												
				$rootScope.loggerIpad("responseVerificarHuellaIpad", null, response);
				switch(response.codigo){
					case VALIDA_HUELLA_RESPONSE.EXITO:
						
						
						var continuar = function(){
						
							if(!generalService.isEmpty(solicitudRechazadaMas30dias)){
								
								solicitudService.validaSolicRechazada({idSolicitud:solicitudRechazadaMas30dias}).then(
										function(data) {
											$rootScope.waitLoaderStatus = LOADER_HIDE;
												
											if(data.data.codigo == RESPONSE_CODIGO_EXITO) {			
												var responseJson = JSON.parse(data.data.respuesta);
												
												if(responseJson.codigo == 2){
													if((responseJson.data.idProducto == 21 || responseJson.data.idProducto == 22 || responseJson.data.idProducto == 23 || responseJson.data.idProducto == 24 || responseJson.data.idProducto == 25) && !generalService.esLineaSublineaMonto($rootScope)){
														$rootScope.faseGeneraRechazo = 1;
														$rootScope.solicitudJson = responseJson.data;
														$rootScope.solicitudJson.aceptaTerminos=0;
														generalService.locationPath("/simulador");
													}else if($rootScope.firmaBuroAux != undefined && $rootScope.firmaPrivacidadAux != undefined){
														$rootScope.firmaPrivacidad = $rootScope.firmaPrivacidadAux;
														$rootScope.firmaBuro = $rootScope.firmaBuroAux;
														
														$rootScope.firmaBuroAux = undefined;
														$rootScope.firmaPrivacidadAux = undefined;
														
														generaSolicRechazada(solicitudRechazadaMas30dias);
													}else{
														$scope.modalAvisosWindows(solicitudRechazadaMas30dias);
													}
												}else if(responseJson.codigo == 820){
													var fechaTotal = generalService.getFechaRecuperacionSolicitudRechazada(responseJson.data.diasRechazo, 61);
													$rootScope.message( "AVISO", ["Lo sentimos, Infórmale a tu cliente que por politicas internas no podra levantar una solicitud hasta el: "+fechaTotal], "Aceptar", "/simulador", null, null, null, null, null);
												}else if(responseJson.data != undefined){
													if(responseJson.data.idProducto != 7){
														$rootScope.message( "Error "+responseJson.codigo, [responseJson.descripcion], "Aceptar","/simulador");
													}else{
														$rootScope.message( "Error "+responseJson.codigo, ["Aún no es posible originar créditos BIG"], "Aceptar","/simulador");
													}
												}else{
													$rootScope.message( "Error "+responseJson.codigo, [responseJson.descripcion], "Aceptar","/simulador");
												}
											}else{
												$rootScope.message( "Error Recuperar Solicitud", ["Error al recuperar la información del cliente, por favor, contacte al soporte."], "Aceptar","/simulador");
											}
												
										}, function(error){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$rootScope.message( "Error Recuperar Solicitud", ["Error al recuperar la información del cliente, por favor, contacte al soporte."], "Aceptar","/simulador");
										}
									);
								
								
								/** INICIA_OS-FLUJO COACREDITADO **/
								/**  La primera condición hace los siguiente:	**/	
							}else if( $rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescate  ||
									$rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescateFDos	|| 
									$rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescateFCuatro ){
														
											generalService.locationPath("/ochoPasos");
									
							}else if( $rootScope.solicitudJson.obligadoSolidario &&  $rootScope.solicitudJson.obligadoSolidario.idSolicitudObligadoSolidario == ""  && 
								    	  $rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.clienteAceptoProductoCosumo ){
											
											$rootScope.muestraOpcionOS = true;
											generalService.locationPath("/ochoPasos");	
										
							}else if( $rootScope.solicitudOSJson && ($rootScope.solicitudOSJson.idSeguimiento != STATUS_SOLICITUD.autorizada.id && 
								    ( $rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.clienteConOS || 
								      $rootScope.solicitudJson.obligadoSolidario && $rootScope.solicitudJson.obligadoSolidario.idSolicitudObligadoSolidario !== "" ))){
												
												var path = "";
												if( generalService.solicitudOSRechazado()){
														path = "/ochoPasos";
														$rootScope.muestraObligadoSolidario = true;

													}else if( generalService.tieneObligadoSolidario($rootScope.solicitudJson ) ){
																		
															path = "/ochoPasos";
															$rootScope.muestraObligadoSolidario = true;

													}else if( $rootScope.solicitudJson.consultaMatriz == 1 && $rootScope.solicitudJson.consultaBuro == 1 && !$rootScope.solicitudJson.banderaOfertaCP &&
															  $rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.clienteConOS ){
																		
															path = "/ochoPasos";
															$rootScope.muestraObligadoSolidario = true;

													}else if( $rootScope.solicitudOSJson.idSolicitud != "" ){

															$rootScope.muestraObligadoSolidario = true;
															$rootScope.muestraOpcionOS = true;

															/** Si cualquiera de las solicitudes, Coacreditado y Cliente, estan en Investigación, manda al trackink  **/
															if(( $rootScope.solicitudOSJson.idSeguimiento == 5 && $rootScope.solicitudOSJson.existeCita == 1 && $rootScope.solicitudOSJson.flujoSolicitudADN == 99 ) || 
															  ( $rootScope.solicitudOSJson.idSeguimiento == 102 || $rootScope.solicitudOSJson.idSeguimiento == 103 || $rootScope.solicitudOSJson.idSeguimiento == 17 )){
																			
																	path = "/estatusOS";
																		
															}else if($rootScope.solicitudJson.idSeguimiento == 3 || $rootScope.solicitudJson.idSeguimiento == 185){
																			
																path = "/ochoPasos";
																		
															}else if($rootScope.solicitudJson.idSeguimiento == 6 && $rootScope.solicitudJson.flujoSolicitudADN == 99){
																			
																path = "/ochoPasos";
																		
															}else if( $rootScope.solicitudOSJson.idSeguimiento == 5 && ($rootScope.solicitudOSJson.existeCita == 1 && $rootScope.solicitudOSJson.flujoSolicitudADN != 99) || 			
																	( $rootScope.solicitudOSJson.idSeguimiento == 5 && ( $rootScope.solicitudOSJson.existeCita == 0 && $rootScope.solicitudOSJson.flujoSolicitudADN != 99) ) ||
																	( $rootScope.solicitudOSJson.idSeguimiento == 6 &&  $rootScope.solicitudOSJson.flujoSolicitudADN != 99 )){
																	  
																		$rootScope.message( "Error al recuperar solicitud", ["Se detectó un problema al recuperar la solicitud, por favor, contacte a soporte."], "Aceptar","/simulador");
																		
															}else{
																			
																path = "/simulador";
																		
															}
																		
																	
													}else{
																		
														path = "/ochoPasos";		
														$rootScope.muestraObligadoSolidario = false;
														$rootScope.muestraOpcionOS = false;
																	
													}
													if(!generalService.solicitudOSRechazado() && generalService.validardiaDePago() && path == "/ochoPasos"){
														var respuestaSeccionOS = generalService.evaluaAgendaCita( $rootScope.solicitudOSJson );
														if(respuestaSeccionOS.porcentajeTotal == 100){
															if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.diaDePagoSeleccionado && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal)
																path = "/cuentasGuardadito";
															if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tipoDispersionSeleccionado || ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.diaDePagoSeleccionado && $rootScope.solicitudJson.idProducto != ID_PRODUCTO.prestamoPersonal))
																path = generalService.whichOneVisit(0);
														}
													}
													if($rootScope.solicitudOSJson.documentos.documento == null && 
															$rootScope.solicitudOSJson.idSeguimiento != 9){
														$rootScope.generarDocsOs();
													}else{
														generalService.locationPath(path);
													}
												
																	
																	
								/** Se agregó la validación para el Coacreditado para liberación **/
								/** TERMINA_OS-FLUJO COACREDITADO **/
								} else if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id &&
								     ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.autorizadoMesa ||
								      $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.certificadoItalikaActivado) && !generalService.isEmpty($rootScope.solicitudJson.diaPago)){
								if($rootScope.solicitudJson.tipoSolicitud == SOLICITUD_REACTIVADO ){
									var request = {
											idSolicitud: $rootScope.solicitudJson.idSolicitud,
											tarjeta: "1"
										};
										solicitudService.liberarLCR(request).then(
											function(data){
												$rootScope.waitLoaderStatus = LOADER_HIDE;
												if(data.data.codigo == RESPONSE_CODIGO_EXITO){
													var jResponse = JSON.parse(data.data.respuesta);
													if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
														$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.liberacionAplicada;
													}
													if($rootScope.solicitudJson.campana == CAMPANAS_REACTIVADOS.winback && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal)
														generalService.locationPath("/surtimiento");
													else
														generalService.locationPath("/estatus");

													generalService.locationPath("/estatus");
												}else{
													$rootScope.message("Error", ["Error en la respuesta del servicio liberar la LCR (Reactivado). Por favor, reintente nuevamente."],"Aceptar","/simulador","bgCafeZ", "cafeZ");
												}
											}
										);
								}else{
									if($rootScope.flujoSinTAZ)
										generalService.locationPath("/estatus");
									else
										tarjetaService.checkInvetario($rootScope.solicitudJson);
								}
								//CBS El cliente es aceptado para el cambio de sucursal o las condiciones para la migración continuar con el proceso de obtener el nombre de la sucursal
							}else if(migrarSolicitud()==="rechazado" || migrarSolicitud()==="aceptado"){
										$scope.obtenerNombreSucursal()
							}else{
								$scope.obtenerVerificacion();								
							}
														
						};
									
						continuar();
								
						break;
						
					case VALIDA_HUELLA_RESPONSE.ERROR:
						goSimulador();
						break;
						
					case VALIDA_HUELLA_RESPONSE.ERROR_COMPONENTE:
						goSimulador();
						break;
						
					case VALIDA_HUELLA_RESPONSE.COMPONENTE_CANCELADO_PORUSR:
						goSimulador();
						break;
						
					case VALIDA_HUELLA_RESPONSE.NO_SE_ENCONTARON_HUELLAS:
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						modalService.confirmModal("Sin huellas", ["No se encontraron huellas. Infórmale a tu cliente que para continuar con su proceso de crédito es necesario que realice un mantenimiento de biométricos. "], 
				                  "Cancelar", "Aceptar").then(
										  function(exito){	
											  generalService.esValidoFlujoCallCenter($rootScope.solicitudJson);
											  generalService.setArrayValue("pasoCallCenter", 'foto')
											  generalService.setArrayValue("encolarImagenes", false);
											  generalService.locationPath("/callCenter");
											  
										  },function(error){
											  goSimulador();														  														
										  }
									);
												
						break;
						
					case VALIDA_HUELLA_RESPONSE.NO_HAY_COINCIDENCIAS:
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						if(!generalService.isEmpty($rootScope.solicitudJson.folioCallCenter) 
								&& $rootScope.solicitudJson.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.SIN_RESPUESTA) {
							generalService.setArrayValue("pasoCallCenter", 'consultaCte');
						} else {
							// ¿La solicitud ya bajó correctamente a tienda?
							if($rootScope.solicitudJson.flujoSolicitudADN == 99) {
								// Se despliega un mensaje que insta a realizar un mantenimiento de biométricos.
								$rootScope.message("AVISO", 
										["Por favor, antes de continuar con tu proceso de crédito debes acudir con un " +
												"asesor", " financiero a realizar un mantenimiento de biométricos."], 
										"Aceptar", "/", null, null, null
								);
								
								return;
							} else {
								generalService.setArrayValue("pasoCallCenter", 'init');
							}
						}
																								
						generalService.esValidoFlujoCallCenter($rootScope.solicitudJson);
						generalService.setArrayValue("encolarImagenes", false);
						generalService.locationPath("/callCenter");	
						break;
						
					default:
						$rootScope.message( "Componete de huella", ["Código "+response.codigo+" no definido. "], "Aceptar");
						goSimulador();
						break;
						
				}				
											
		};
		
		/******************************************************************************************************************************************/
		$scope.modalAvisosWindows=function(solicitudRechazadaMas30dias){
			modalService.contratosOriginacion().then(
					function(exito){
						tipoFirma = ($rootScope.isFirmaUnica)?0:1;
            			firmaUnica(solicitudRechazadaMas30dias);
            		}
				);
		};
		
		var generaSolicRechazada= function(solicitudRechazadaMas30dias){
			var jsonRequest = {
				idSolicitud: $rootScope.solicitudJson.idSolicitud,
				jsonSolicitd:JSON.stringify($rootScope.solicitudJson),
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW
			solicitudService.generaSolicRechazada(jsonRequest).then(
				function(data) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
						
					if(data.data.codigo == RESPONSE_CODIGO_EXITO) {								
							var jResponse = JSON.parse(data.data.respuesta);							
							
							if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO) {
								$rootScope.solicitudJson = jResponse.data;
								$scope.avisoEnviado = false;

								$scope.guardarPresupuesto();
							} else {
								solicitudRechazadaMas30dias = null;
								$rootScope.solicitudJson.aceptaTerminos = 0;
								
								// Impresión del mensaje que corresponda.
								$rootScope.printGenSolRechServiceAnswer(jResponse);
							}
					}else{
						solicitudRechazadaMas30dias = null;
						$rootScope.solicitudJson.aceptaTerminos=0;
						$rootScope.message( "Error "+data.data.codigo, ["Error en la respuesta del servicio para generar una solicitud rechazada. Por favor, reintente nuevamente."], "Aceptar","/simulador");
					}
						
				}, function(error){
					solicitudRechazadaMas30dias = null;
					$rootScope.waitLoaderStatus = LOADER_HIDE; 		                						
				}
			);
		}
		
		$scope.guardarPresupuesto = function(){

			var jsonRequest = {
					"idSolicitud": $rootScope.solicitudJson.idSolicitud, 
					"idPais": $rootScope.solicitudJson.idPais,
					"idCanal": $rootScope.solicitudJson.idCanal,
					"idSucursal": $rootScope.solicitudJson.idSucursal,
					"idPresupuesto": ($rootScope.presupuestoC3Servicio != undefined)?$rootScope.presupuestoC3Servicio.fcFolioParam:0,
					"idLinea": ($rootScope.categoriaLineaAux.linea != undefined)? $rootScope.categoriaLineaAux.linea:0 ,
					"idSubLinea": ($rootScope.categoriaLineaAux.subLinea != undefined)? $rootScope.categoriaLineaAux.subLinea:0,
					"idProducto": $rootScope.solicitudJson.idProducto,
					"montoDeseado": ($rootScope.categoriaLineaAux.montoDeseado != undefined) ? $rootScope.categoriaLineaAux.montoDeseado.replace(/[,$]/g,"").trim() : 0 
				};
			
			$rootScope.categoriaLineaAux = undefined;
			$rootScope.solicitudJsonAuxLSM = undefined;
			
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				solicitudService.guardarPresupuesto(jsonRequest).then(
					function(data) {
						if($rootScope.consultaFuncionalidad.nuevoFlujoLiberacion){
							newFlowRelease();
						}else{
							SendSignOnLine();
						}
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
				});
		
		}
		
		/**
		 * Funcion para marcar la solicitudes cuando se origine desde rechazo.
		 **/
	 	function newFlowRelease(){
	 		var x = {
	 			idSolicitud : $rootScope.solicitudJson.idSolicitud,
	 			idSeguimiento: $rootScope.solicitudJson.idSeguimiento,
	 			marca: MARCAS_SOLICITUD.nuevoFlujoLiberacion
	 		}
			  
	 		$rootScope.waitLoaderStatus = LOADER_SHOW;
	 		solicitudService.actualizarSolicitud(x).then(
	 			function(data){
	 				$rootScope.waitLoaderStatus = LOADER_HIDE;
	 				
	 				if(data.data.codigo == RESPONSE_CODIGO_EXITO){
	 					var responseJson = JSON.parse(data.data.respuesta);	
	 					
	 					if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
	 						$rootScope.nuevoFlujoLiberacion = true;
	 					}else{
	 						$rootScope.nuevoFlujoLiberacion = false;
	 					}
	 					SendSignOnLine();
	 				}else{
	 					$rootScope.message("Aviso ", ["Error al actualizar la solicitud. Favor de volver a intentar"],"Aceptar",null,null,null,null);
	 				}
	 			}, function(error){
	 				$rootScope.waitLoaderStatus = LOADER_HIDE;
	 				$rootScope.message("Aviso ", ["Error en el servicio para actualizar la solicitud"],"Aceptar",null,null,null,null);				
	 			});
	 	};
		
		/**
		 * Función para identificar el error que el servicio responde.
		 * Ahora, todas las opciones están haciendo lo mismo —imprimir el error—, bastaría con
		 * hacerlo en el último CASE. No obstante, después cada caso podría agregar comportamiento
		 * específico.
		 */
		$rootScope.printGenSolRechServiceAnswer = function(json) {			
			switch(json.codigo) {
				case SOLICITUD_RECHAZADA.dbSaveError:
					// Ocurrió un error en la BD al guardar la solicitud.
					$rootScope.message("Error " + json.codigo, 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.dbUpdateError:
					// Error interno al intentar actualizar la BD.
					$rootScope.message("Error " + json.codigo, 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.getSolByIdError:
					// Error al obtener la solicitud mediante su ID.
					$rootScope.message("Error " + json.codigo, 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.clientUniqueInvError:
					// Ha ocurrido un error al invocar el servicio de Cliente Único.
					$rootScope.message("Error " + json.codigo, 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.LCRblockHomonimo:
					// Se encontró homónimo con Línea de Crédito bloqueada.
					$rootScope.message("Aviso", 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.LCRautNoLibHomonimo:
					// Se encontró homónimo con Línea de Crédito autorizada sin liberar.
					$rootScope.message("Aviso", 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.LCRInvestHomonimo:
					// Se encontró homónimo con Línea de Crédito en investigación.
					$rootScope.message("Aviso", 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.LCRautYlibHomonimo:
					// Se encontró homónimo con Línea de Crédito autorizada y liberada.
					$rootScope.message("Aviso", 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.HomonimosQueryError:
					// Ha ocurrido un error al consultar los homónimos.
					$rootScope.message("Error " + json.codigo, 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.EmployeeClient:
					// El cliente está registrado como empleado.
					$rootScope.message("Aviso", 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.previoPrestPrenda:
					/*
					 * Infórmale a tu cliente que no es posible generar su solicitud de crédito en 
					 * esta sucursal debido a que ya tiene un producto de Presta Prenda asociado.
					 * La tienda que le corresponde es {sucursal}.
					 */
					$rootScope.message("Aviso", 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.previoLCR:
					/*
					 * Infórmale a tu cliente que no es posible generar su solicitud de crédito en 
					 * esta sucursal debido a que ya tiene una LCR asociada. La tienda que le 
					 * corresponde es {sucursal}.
					 */
					$rootScope.message("Aviso", 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.waitXtime:
					// Favor de esperar {días} días para iniciar una nueva solicitud.
					$rootScope.message("Aviso", 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.previaSolicitud:
					/*
					 * Se encontró homónimo con alguna solicitud en proceso. Favor de acudir a la
					 * sucursal {sucursal}.
					 */
					$rootScope.message("Aviso", 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.Extranjero:
					// Se encontró homónimo con cliente extranjero.
					$rootScope.message("Aviso", 
							[json.descripcion], "Aceptar", "/simulador");
					break;
				case SOLICITUD_RECHAZADA.clienteError:
					//  Favor de Introducir los datos del cliente desde el simulador.
					$rootScope.message("Aviso", 
							[" Favor de Introducir los datos del cliente desde el simulador."], "Aceptar", "/simulador");
					break;
				default: 
					$rootScope.message("Error " + json.codigo, 
							["Código no identificado."], "Aceptar", "/simulador");
			}
		}
		/******************************************************************************************************************************************/
		
		
		var goSimulador = function(){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
/** INICIA_OS**/
			generalService.buildSolicitudOSJson($rootScope, null);
/** TERMINA_OS**/
			generalService.buildSolicitudJson($rootScope, null );			
			generalService.locationPath("/simulador");
		};
										
		
		/**
		 * CBS migrarSolicitud
		 * Revisar si es un usuario del TestEmplyes dejar continuar y no realizar el cambio de sucursal.
		 * Revisar las condiciones para aplicar el cambio de sucursal, si las condiciones son aptas continuar con el flujo para el cambio de sucursal.
		 * Revisar las condiciones de liberación si apto no mostrar mensaje y continuar con el flujo de lo contrario se mostrará el mensaje
		 * **/
		
		function migrarSolicitud(){
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) == -1){
				if(($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.generada.id || $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id) &&
					$rootScope.solicitudJson.tipoSolicitud != SOLICITUD_REACTIVADO && $rootScope.solicitudJson.idCanal != CANALES.presta_prenda && 
					$rootScope.solicitudJson.flujoSolicitudADN == 0 && $rootScope.solicitudJson.idSolicitudTienda == 0 &&
					$rootScope.solicitudJson.idSucursal != $rootScope.sucursalSession.idSucursal &&
					$rootScope.solicitudJson.idPlataforma != PLATAFORMA.BAZDIGITAL &&
					$rootScope.solicitudJson.existeCita == 0){
						$scope.aceptado = "aceptado";
					return "aceptado";
				}
						
				if($rootScope.solicitudJson.idSucursal != $rootScope.sucursalSession.idSucursal &&
					    ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && (
						 $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.ejecutivo || 
						 $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expCompleto  ||
						 $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente  ||
						 $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expRechazado ||
						 $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinLiberar ||
						 $rootScope.solicitudJson.marca == STATUS_SOLICITUD.mesaControl.marca.condicionadoMesa ||
						 $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.clienteVerdeJVC))){
							$scope.aceptado = "rechazado";
						return "rechazado"
				}
			}
			return "negado";
		}
		/**
		 * CBS Mostrar el mensaje de advertencia para dicho cambio, si se presenta algun error mostrar el mensaje correspondiente y regresar al simulador
		 * Si la respuesta el SI entonces invocar el servicio para el cambio.
		 * Respuesta del servicio OK enviar los documetnos recientemente firmados
		 * **/
		var flujoLSMCotizador = true;
		$scope.aplicarCambioSucursal = function(){
			var sucursalDestino = $rootScope.sucursalSession.idSucursal + " " + $rootScope.sucursalSession.nombreSucursal;
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			
			modalService.confirmModal("Aviso", ["Usted ya tiene una solicitud en proceso en la sucursal " + $rootScope.solicitudJson.idSucursal + " " + $scope.nombreSucursalOrigen,
											   "¿Desea cancelarla y generar una nueva en la sucursal " + sucursalDestino],
											   "Si","No")
			.then(
				  function(error){
					  generalService.cleanRootScope($rootScope);
					  generalService.buildSolicitudJson($rootScope, null);
			/** INICIA_OS**/
						generalService.buildSolicitudOSJson($rootScope, null);
			/** TERMINA_OS**/
					  generalService.locationPath("/simulador");
				  },
				  function(exito){  
					  if(flujoLSMCotizador && !generalService.esLineaSublineaMonto($rootScope)){
						  $rootScope.faseGeneraMigracionSuc = true;
						  $rootScope.solicitudJson.aceptaTerminos=0;
						  generalService.locationPath("/simulador");
					  }else{
						  $rootScope.waitLoaderStatus = LOADER_SHOW; 
						  var jsonRequest =  {
									"idSolicitud": $rootScope.solicitudJson.idSolicitud,
									"idPais": $rootScope.sucursalSession.idPais,
									"idCanal": $rootScope.sucursalSession.idCanal,
									"idSucursal": $rootScope.sucursalSession.idSucursal,
									"idEmpleado": $rootScope.userSession.noEmpleado,
									"terminal" :$rootScope.sucursalSession.terminalBancaria,
									"jsonSolicitud":$rootScope.solicitudJsonAuxLSM
									
							};
										
							
							solicitudService.migracionSolicitudNuevaSucursal( jsonRequest ).then(
								function(data){
									
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
										
										var responseJson = JSON.parse(data.data.respuesta);
										$rootScope.solicitudJson = responseJson.data;
										
										if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
											$rootScope.firmaPrivacidad = $rootScope.firmaPrivacidadAux;
											$rootScope.firmaBuro = $rootScope.firmaBuroAux;
											
											$rootScope.firmaBuroAux = undefined;
											$rootScope.firmaPrivacidadAux = undefined;
											
											$scope.guardarPresupuesto();
										}else{
											generalService.cleanRootScope($rootScope);
											generalService.buildSolicitudJson($rootScope, null);
								/** INICIA_OS**/
											generalService.buildSolicitudOSJson($rootScope, null);
								/** TERMINA_OS**/
											$rootScope.message( "Error " + data.data.codigo,["No se logró concluir el proceso de cambio de sucursal reitente más tarde"], "Aceptar","/simulador");
										}
									}else{
										generalService.cleanRootScope($rootScope);
										generalService.buildSolicitudJson($rootScope, null);
							/** INICIA_OS**/
										generalService.buildSolicitudOSJson($rootScope, null);
							/** TERMINA_OS**/
										$rootScope.message( "Error " + data.data.codigo,["No se logró concluir el proceso de cambio de sucursal reitente más tarde"], "Aceptar","/simulador");
									}
								}, function(error){
					                $rootScope.waitLoaderStatus = LOADER_HIDE; 	
									generalService.cleanRootScope($rootScope);
									generalService.buildSolicitudJson($rootScope, null);
						/** INICIA_OS**/
									generalService.buildSolicitudOSJson($rootScope, null);
						/** TERMINA_OS**/
									$rootScope.message( "Error ",["No se logró concluir el proceso de cambio de sucursal reitente más tarde"], "Aceptar","/simulador");
								}
							);
					  }
				}
			);
		
		}
		
		/**
		 * CBS Iniciamos el proceso para el cambio de sucursal, lo primero es obtner el nombre de la sucursal.
		 * Al obtener la respueta OK entonces validar $scope.aceptado == rechazado mostrar mensaje de la liberación.
		 * Si $scope.aceptado != rechazado entonces continuar con el proceso de cambio de sucursal
		 * **/
		$scope.obtenerNombreSucursal = function(){
			
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			var jsonRequest =  {
					"idPais": $rootScope.solicitudJson.idPais,
					"idCanal": $rootScope.solicitudJson.idCanal,
					"idSucursal": $rootScope.solicitudJson.idSucursal
			};
			
			solicitudService.getSucursalPorId(jsonRequest).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE; 
						if( data.data.codigo == RESPONSE_CODIGO_EXITO ){		 						 						 					
							
							var responseJson = JSON.parse(data.data.respuesta);
							$scope.nombreSucursalOrigen = responseJson.data.xpNombre != undefined? responseJson.data.xpNombre:"";
							$scope.idSucursalOrigen = $rootScope.solicitudJson.idSucursal;
							
							if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								if($scope.aceptado === "rechazado"){	
									generalService.cleanRootScope($rootScope);
									generalService.buildSolicitudJson($rootScope, null);
						/** INICIA_OS**/
									generalService.buildSolicitudOSJson($rootScope, null);
						/** TERMINA_OS**/
									$rootScope.message("Aviso ", ["La liberación de la Línea de crédito se debe realizar en la sucursal origen del cliente: " + $scope.idSucursalOrigen + " - " + $scope.nombreSucursalOrigen],"Aceptar", "/simulador");
								}else
									$scope.aplicarCambioSucursal();
							}else{
								generalService.cleanRootScope($rootScope);
								generalService.buildSolicitudJson($rootScope, null);
					/** INICIA_OS**/
								generalService.buildSolicitudOSJson($rootScope, null);
					/** TERMINA_OS**/
								$rootScope.message( "Error ",["Se presentó un error al obtener la información de la sucursal intente mas tarde"], "Aceptar","/simulador");
							}
						}else{
							$rootScope.waitLoaderStatus = LOADER_HIDE; 	
							generalService.cleanRootScope($rootScope);
							generalService.buildSolicitudJson($rootScope, null);
				/** INICIA_OS**/
							generalService.buildSolicitudOSJson($rootScope, null);
				/** TERMINA_OS**/
							$rootScope.message( "Error ",["Se presentó un error al obtener la información de la sucursal intente mas tarde"], "Aceptar","/simulador");
						}
						}, function(error){
							$rootScope.waitLoaderStatus = LOADER_HIDE; 	
							generalService.cleanRootScope($rootScope);
							generalService.buildSolicitudJson($rootScope, null);
				/** INICIA_OS**/
							generalService.buildSolicitudOSJson($rootScope, null);
				/** TERMINA_OS**/
							$rootScope.message( "Error ",["Se presentó un error al obtener la información de la sucursal intente mas tarde"], "Aceptar","/simulador");
						}
					);
		}
		
		// CBS Encola los documentos firmados
		$scope.agregarDocumentos = function(_path){
			if (configuracion.origen.tienda && _path != "/simulador" && _path != null)	
				documentosService.encolarDocSimulador(_path, "commoCtrlDivId", "responseEnvioImg1Ipad","responseEnvioImg2Ipad", "commoCtrlDivId", "responseEnvioFirmaAP","responseEnvioFirmaBuro");				
			else
				generalService.locationPath(_path);
		};
		
		
		
	 	/*
		 * Función que detona el envío en linea de las firmas del Aviso y del Buró
		 * Se valida que se tengan los B64 para prepararse para el envío 
		 */
		function SendSignOnLine(){
			$rootScope.enviarIdentificacion("/ochoPasos", null);
		};
		
	 	function firmaUnica(solicitudRechazadaMas30dias){
			//Se prepara la petición para enviar al componente de firma única
			var jsonRequest = {
					titulo: "Aviso de Privacidad y Consulta a Buró de Crédito",
					contratos: ["Aviso de privacidad", "Caratula de buro"],
					rutasHTML: ["credito\\webapp\\documents\\AvisoPrivacidad.html",
					            "credito\\webapp\\documents\\BuroCredito.html"],
					parrafos: [
								"<html><body><p style=\"text-align:justify;\">Reconozco que "+
								"cada una de las firmas elctronicas que seran asentadas en los "+
								"documentos<br>que se identifican a continuacion, son pruebas "+
								"inequivoca de la manifestacion expresa de mi<br>voluntad, "+
								"reconociendo que no existe error, dolo o mala fe en la celebracion "+
								"de los actos que<br>a continuacion se "+
								"indican.</p><br></body></html>",
								"<html><body><p style=\"text-align:justify;\">Reconozco ante Banco Azteca, S.A. Institución de Banca Múltiple, que he otorgado mi"+
								"caautorización y manifiesto mi conformidad respecto de los documentos"+
								"documentos<br>que se identifican a continuacion, son pruebas "+
								"(1 y 2) y que he otorgado mi consentimiento y aceptación inequivoca respecto de los documentos numerales (3,4 y 5), aceptando las obligaciones que a mi cargo derivan de los citados"+
								"documentos en términos de las firmas electrónicas que, de manera individual, y trashaber"+
								"leído cada uno de los documentos antes"+
								"indicados, he asentado en cada uno de ellos de manera electrónica, lo cual"+
								"convalido y ratifico a través de la firma asentada en el presente documento."+
								"</p><br></body></html>"
					           ],
					tipoFirma: tipoFirma
			};
			
            if(configuracion.so.windows){
            	$rootScope.waitLoaderStatus = LOADER_SHOW;
            	$rootScope.capturarFirma2WV("avisosDivId","responseFirma2WV",jsonRequest);
            }else{
            	$rootScope.contratosOriginacion = true;
            	modalService.modalFirmaUnica().then(
					    function(exito) {
					        if (exito != undefined) {
								$rootScope.responseFirmaUnica = exito;
								$scope.bloqueaInput = false;
							} else {
					            console.log("Terminé de firmar los contratos con firma autografa");
					        }
					    },
					    function(error) {
					    	solicitudRechazadaMas30dias = null;
							$rootScope.solicitudJson.aceptaTerminos=0;
							generalService.locationPath("/simulador");
					    }
					);
            }
		};
		
		$scope.responseFirma2WV = function(responseWV){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
				if($rootScope.isFirmaUnica){
					$rootScope.firmaPrivacidad = "data:image/png;base64," + responseWV.imgB64[0].replace("data:image/png;base64,","");
					$rootScope.imgPrivacidad = responseWV.imgB64[0];
					$rootScope.responseFirmaUnica = responseWV;
					$scope.bloqueaInput = false;
				}else{
					$rootScope.imgPrivacidad = responseWV.imgB64[0];
					$rootScope.firmaPrivacidad = "data:image/png;base64," + responseWV.imgB64[0].replace("data:image/png;base64,","");
					
					$rootScope.imgBuro = responseWV.img64;
					$rootScope.firmaBuro = "data:image/png;base64," + responseWV.imgB64[1].replace("data:image/png;base64,","");;
				}
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				generaSolicRechazada(solicitudRechazadaMas30dias);
			}else{
				$rootScope.message( "Nueva Originación Centralizada", ["Ocurrio un error con el componente de firma"], "Aceptar");
			}	
		};
						
	});
			
}); 