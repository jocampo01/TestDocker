'use strict';

define(["app"], function (app) {
        	
	app.controller("regresarController", function ($rootScope, $scope, generalService, modalService, validateService,validateServiceOS) {  	  	
		
		$scope.init=function(){
			if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
			
			$scope.textoBotonRegresar = generalService.getDataInput("OCHO PASOS","TEXTO BOTON REGRESAR",$scope.origen);
		};
		
		$scope.goPage = function(){					
			
			
			$rootScope.mapas = undefined;
			
			if( generalService.isEmpty( generalService.getArrayValue("sourcePath") )){
/** INICIA_OS-FLUJO COACREDITADO **/
				if($rootScope.showDatosHogarOS){
					validateServiceOS.path("/ochoPasosOS");
/** TERMINA_OS-FLUJO COACREDITADO **/
				}else{
					validateService.path("/ochoPasos");
				}
			}				
			else
				generalService.locationPath(generalService.getArrayValue("sourcePath"));
				
		};	
		
		
//		$scope.menuOchoPasos = function(){
//		
//			var currentPath = window.location.href.split('/').pop();
//			
//			/* NO MOVER EL SWITCH DE ORDEN POR QUE PUEDE FALLAR! */
//			switch( currentPath ){
//				
//				case 'datosHogar':
//						
//						if( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc )
//							$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc;
//						
//						if( $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc )
//							$rootScope.solicitudJson.avales[0].datosHogar.colonia = $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc;
//					break;
//				case 'aval':
//						
//						if( $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc )
//						$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia.desc;
//					
//						if( $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc )
//							$rootScope.solicitudJson.avales[0].datosHogar.colonia = $rootScope.solicitudJson.avales[0].datosHogar.colonia.desc;
//					break;
//			
//			}
//			
//			generalService.locationPath("/ochoPasos");
//			
//			
//		};		    				                         		
		

	        		
	});
	
});	