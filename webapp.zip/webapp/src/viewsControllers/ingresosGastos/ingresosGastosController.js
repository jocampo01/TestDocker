'use strict';

define(["app"], function (app) {

    app.controller("ingresosGastosController", function ($timeout, $scope, $rootScope, modalService, generalService, solicitudService, buroService,
    													 messageData, validateService, $filter, $locale) {
    	
    	$scope.vistaDatosUsuario = configuracion.datosUsuario.opcion=0;
    	$scope.pageClass = generalService.calculaVistas($rootScope.paginaActual,$rootScope.paginaAnterior,$rootScope.recuperaSolicitud);    
    	var currency = $filter('currency'), formats = $locale.NUMBER_FORMATS;
    	$scope.dependientes={};
    	$scope.dependientes={menores:$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores,mayores:$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores};
    	$scope.bloqueaSeccion = $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.editable;
    	var CONCEPTO = [];       	       	    	 
    	
		$scope.init = function(){     		 
			
			/*\Se agrega un evento para la bitacora\*/
//			(Gastos)
			$rootScope.addEvent( BITACORA.SECCION.gastos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje, BITACORA.SECCION.gastos.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
			
     		$scope.showPage = false;						
     		  		  		
			if( messageData ){
								
				loadView();
				
				var currency = $filter('currency'), formats = $locale.NUMBER_FORMATS;
				
				if( generalService.existeSolicitud($rootScope.solicitudJson) ){
					$rootScope.flujoEfectivo = new Array();
					if(parseInt($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores) >= 0 )
						var entero=null;
					else
						$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores=null;
					if(parseInt($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores) >= 0 )
						var entero=null;
					else
						$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores=null;
					generalService.setRespaldo($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo,true,
							                   $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores,
							                   $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores);
					
					
					angular.forEach(CONCEPTO, function(valueArray){	
						var ingresoGasto = null						
						
						angular.forEach($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo, function(valueJson){								
							if(valueArray.id == valueJson.idConcepto)
								ingresoGasto = valueJson;
						});
						
						
						if( ingresoGasto == null )							
							$rootScope.flujoEfectivo.push({"idTipo": parseInt(valueArray.tipo), "tipoDes":valueArray.tipoDesc, "idConcepto": valueArray.id, 
								                           "conceptoDes":valueArray.descripcion, "monto": "", orderId:valueArray.orderId });
						else{
							ingresoGasto.orderId = valueArray.orderId;							
							$rootScope.flujoEfectivo.push(ingresoGasto);
						}
														
											
																																						
					});
										
					
					
					$scope.showPage = messageData;
					convertir();
					if($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje > 0)
						$scope.porcMayor=true;
					$rootScope.waitLoaderStatus = LOADER_HIDE;
										
					
				}else					
					$rootScope.message(SIN_SOLICITUD.titulo, [SIN_SOLICITUD.texto], "Aceptar", "/", "bgVerde", "verde");				
				
			}else	
				$rootScope.message(ERROR_CARGA_PAGINA.titulo, [ERROR_CARGA_PAGINA.texto], "Aceptar", "/", "bgVerde", "verde");				
				
			
		};
		
		
		
//		$scope.filtroIngresos = function(flujoEfectivo){
//			return flujoEfectivo.idConcepto === 3 || flujoEfectivo.idConcepto === 4;
//		};
		
		
		$scope.filtroGastos = function(flujoEfectivo){
			return flujoEfectivo.idTipo === 2;
		};
				
		
//		$scope.$watch(function(scope){			
//			angular.forEach( scope.flujoEfectivo, function(ff){								
//				if(ff.monto == undefined) ff.monto = "";					
//			});																
//		});
						
		
		
		$scope.guardar=function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$timeout(function(){ save(); }, 1);
		};
		
		function save(){																
			var porcentajeAnt = $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje;
			$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje = cuentatext('ingresosGastosForm');
			
			
			$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo  = new Array();			
			angular.forEach( $rootScope.flujoEfectivo, function(ig){				
				try{	
					var monto = parseInt(generalService.cleanValue( ig.monto ));
					if( monto >= 0){
						ig.monto = monto;						
						$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo.push(ig);																		
					}
				}catch(e){ }									
			});
			
			if (parseInt($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores) >= 0 && $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores != "")
				$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores);
			else
				$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores = null;
			
			
			if (parseInt($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores) >= 0 && $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores != "")
				$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores);
			else
				$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores = null;
			
			var solicitudJsonString = generalService.delete$$hashKey($rootScope.solicitudJson);			
			if (offLine){				
				$rootScope.cargaDocumentos();
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.porcentajes.secciones[3].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje;
				generalService.locationPath("/ochoPasos");
			}else{
				solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: SECCION_INGRESOS_GASTOS } ).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;

							if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
								var responseJson = JSON.parse(data.data.respuesta);
								if(responseJson.codigo == 2){								   	    	 			                                                         
									$rootScope.solicitudJson = responseJson.data;
									
									/*\Se agrega un evento para la bitacora\*/
//									(Gastos)
									$rootScope.addEvent( BITACORA.SECCION.gastos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.guardar.id, $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje, BITACORA.SECCION.gastos.guardarEnBD );
									/*\Se agrega un evento para la bitacora\*/
									
									$rootScope.calculaDocumentos();
									$scope.datosActuales = JSON.stringify(DatosAnterioresArreglo('ingresosGastosForm'));
	
									$rootScope.porcentajes.secciones[3].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje;										
									
									solicitudService.validaFolioCallCenter(JSON.parse(solicitudJsonString), responseJson.data)
													.then(
															function(data){
																if(data == null){
																	buroService.consultaBuro("bgVerde", "btn gris", "btn verde");
																}else
																	generalService.locationPath(data);
															},function(error){																
															}
														);
									
								}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
								}else{
									if(responseJson.codigo == ERROR_SOL_RECHAZADA){
										var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
										var marca = $rootScope.solicitudJson.marca;
										var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
										var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
										$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],
												"Aceptar", "/simulador",  "bgVerde" , "verde",buildJsonDefault);
									}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
										generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
										generalService.locationPath("/ficha");
									}else{
										$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje = porcentajeAnt;
										$rootScope.message("Gastos",["Error al guardar sección. Código " +
				                             "de error [" + responseJson.codigo + "] no identificado."], 
				                             "Aceptar", null, "bgVerde", "verde");
									}
								}
							}else{
								$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje = porcentajeAnt;
								$rootScope.message("Gastos",["Error en la respuesta del servicio para guardar los datos de la sección de Gastos. Por favor, reintente nuevamente."], "Aceptar", null, "bgVerde", "verde");							
							}
						}, function(error){
							$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje = porcentajeAnt;					
			                $rootScope.waitLoaderStatus = LOADER_HIDE;
						}
					);
			}
		};				
		
		
		
		function convertir(){
			$scope.datosAnteriores = JSON.stringify(DatosAnterioresArreglo('ingresosGastosForm'));
		}
		
		
		function loadView(){			
			
			var idVivienda = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].idTipoVivienda; 											
			var viviendas = generalService.construirCatalogo("CATALOGO TIPO DE DOMICILIO");
			
			var viviendaDescripcion = null;
			
			if( idVivienda && idVivienda !== "" )				
				viviendaDescripcion = generalService.descripcionCatalogo( idVivienda, viviendas );
						
			$scope.origen = configuracion.origen.tienda == true? "TIENDA":"WEB";
			$scope.labelTiempo=MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO TIEMPO."+$scope.origen+".valor"];
			$scope.labelMin=" " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO MIN."+$scope.origen+".valor"];
			
			$scope.titulo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.TITULO."+$scope.origen+".valor"];
						
			$scope.showPregunta2 = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.ETIQUETA GASTOS.VISIBLE.valor"];
			$scope.pregunta2 = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.ETIQUETA GASTOS."+$scope.origen+".valor"];
			
			$scope.showPregunta3 = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.ETIQUETA DEPENDIENTES.VISIBLE.valor"];
			$scope.pregunta3 = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.ETIQUETA DEPENDIENTES."+$scope.origen+".valor"];
			
			$scope.btnGuardar = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.BOTON GUARDAR."+$scope.origen+".valor"];
			
			var array = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE"];
			$scope.datosFE = new Array(array.length);		
			for (var i=1;i <= array.length;i++){
				var mascara = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE.FORMATO["+i+"].valor"];
				var marcaAgua = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE.MARCA DE AGUA["+i+"].valor"];
				var tipo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE.ID TIPO["+i+"].valor"]; 
				var tipoDesc = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE.TIPO["+i+"].valor"];
				var buro = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE.BURO["+i+"].valor"];
				var long_max = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE.LONGMAX["+i+"].valor"];
				var obligatorio = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE.OBLIGATORIO["+i+"].valor"];
				var visible = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE.VISIBLE["+i+"].valor"];
				var campo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE.CAMPO["+i+"].valor"];
				var disabled = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE.DISABLED["+i+"].valor"];
				var idConcepto = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE.IDENTIFICADOR["+i+"].valor"];
				var imagen = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE.IMAGEN["+i+"].valor"];
				var orderId = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE.ORDERID["+i+"].valor"];
				var descJson = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.INGRESOS GASTO CLIENTE.DESCJSON["+i+"].valor"];				
				
				if( viviendaDescripcion )					
					if( descJson.toUpperCase().indexOf( "RENT" ) > -1 
							&& ( viviendaDescripcion.toUpperCase().indexOf( "RENT" ) < 0 
									&& viviendaDescripcion.toUpperCase().indexOf( "HIPO" ) < 0
									&& viviendaDescripcion.toUpperCase().indexOf( "PAGA" ) < 0) ){							
						visible = false;	obligatorio = false;
					}else if(descJson == 'RENTA')
						orderId = "3";
				
				CONCEPTO.push({id:parseInt(idConcepto), descripcion:descJson, tipo:tipo, tipoDesc:tipoDesc, orderId:parseInt(orderId)});
				$scope.datosFE[CONCEPTO[i-1].id] = {placeholder:marcaAgua, img:imagen, opcional: !obligatorio, visible:visible, longmax:long_max, formato: mascara, buro: buro, disabled: disabled };
			}
			$scope.showMayorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MAYOR EDAD.VISIBLE.valor"];
			$scope.labelMayorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MAYOR EDAD.MARCA DE AGUA.valor"];
			$scope.disabledMayorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MAYOR EDAD.DISABLED.valor"];
			$scope.sizeMayorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MAYOR EDAD.LONGITUD.valor"];
			$scope.opcionalMayorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MAYOR EDAD.OPCIONAL.valor"];
			$scope.buroMayorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MAYOR EDAD.BURO.valor"];
			$scope.longmaxMayorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MAYOR EDAD.LONGMAX.valor"];
			$scope.formatoMayorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MAYOR EDAD.FORMATO.valor"];
			
			$scope.showMenorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MENOR EDAD.VISIBLE.valor"];
			$scope.labelMenorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MENOR EDAD.MARCA DE AGUA.valor"];
			$scope.disabledMenorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MENOR EDAD.DISABLED.valor"];
			$scope.sizeMenorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MENOR EDAD.LONGITUD.valor"];
			$scope.opcionalMenorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MENOR EDAD.OPCIONAL.valor"];
			$scope.buroMenorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MENOR EDAD.BURO.valor"];
			$scope.longmaxMenorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MENOR EDAD.LONGMAX.valor"];
			$scope.formatoMenorEdad = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.GASTOS.NUM DEPENDIENTES MENOR EDAD.FORMATO.valor"];
			
						
		};	

	});
	
	
});