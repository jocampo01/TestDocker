'use strict';

define(["app"], function (app) {
        	
	app.controller("ipadController", function ($rootScope, $scope, $location, $timeout, sessionService, modalService, generalService, securityService, Digitalizadora, Huella, Camara, 
											   Reproductor, RecursoBase, TrackerAdmin, Visor, sesion, Envios, maquina, Firma, GPS, solicitudService, Impresora) {  	  
				
		
		var tracker = new TrackerAdmin('ipadController');	
		var trackerId = null, nombrePuntoControl = null;
		var _callbackfuncton;		
		var keyFunctionArray = new Array();
		var indexCargaDato = 0;
		var indexLoadData = 0;
		
		$rootScope.callBack = null;		
		
		
		$rootScope.executeAction = function (divId, callbackFuncton, jsonAction) {	
			try{
				maquina.openVC(divId, callbackFuncton,  jsonAction);
				$rootScope.loggerIpad("executeAction", jsonAction);
			}catch(e){
				console.log("error enexecuteAction "+e.message);				
			}
						
		};
			
		
		$rootScope.executeActionFunction = function (divId, callbackFuncton, jsonAction) {	
			try{	
				keyFunctionArray["executeActionFunction"] = callbackFuncton;	
				maquina.openVC(divId, "respuestaExecuteActionFunction",  jsonAction);
				$rootScope.loggerIpad("executeActionFunction", jsonAction);
			}catch(e){
				console.log("error enexecuteAction "+e.message);				
			}
						
		};		
		
		$rootScope.respuestaExecuteActionFunction = function(data){		
			var _callbackFunction = keyFunctionArray["executeActionFunction"];
			$rootScope.loggerIpad("respuestaExecuteActionFunction",null, data);
			_callbackFunction(data);			
		};
		
		$rootScope.executeActionResponseOff = function (response) {	
			try{	
				console.log(JSON.stringify(response));
				$rootScope.loggerIpad("executeActionResponseOff",null, response)
			}catch(e){
				console.log("error executeActionResponseOff "+e.message);
			}
						
		};
		
						
		
		$rootScope.loginIpadResponse = function (dataResponse) {	
			console.log("loginResponse "+JSON.stringify(dataResponse));	
			$rootScope.loggerIpad("loginIpadResponse",null, dataResponse);
			generalService.setFlagLogin(false);
        	console.log("ipad close loginOn  "+generalService.getFlagLogin());
        	
			if(dataResponse.codigo == RESPONSE_CODIGO_EXITO_IPAD){
				
				$rootScope.getSession('moduloTracker', function(dataSession){
						generalService.setArrayValue('ticket',dataSession.idSession);
				        $rootScope.inSession = true;
				        $rootScope.userSession = dataSession.datosUsuario;  
				        $rootScope.sucursalSession = dataSession.datosSucursal;
				                				                				         
				        var key = generalService.keyEmpBase64();		        				           			 						    			           			
					    securityService.setKeys(key, key);					    	
					 	
					}
				);	
					
			}
		};
				
		
		$rootScope.getSession = function (nombreDiv, callbackfunction) {	
			try{
				keyFunctionArray["ticketSesion"] = callbackfunction;
				sesion.getSession(nombreDiv, "respuestaSesion");
				$rootScope.loggerIpad("getSession", "get Session");
			}catch(e){
				modalService.alertModal("error de sesión",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");
			}
						
		};
		
		
		
		$rootScope.respuestaSesion = function(data){		
			var _callbackFunction = keyFunctionArray["ticketSesion"];										
			_callbackFunction(data);
			$rootScope.loggerIpad("respuestaSesion",data, null);
			$rootScope.loggerIpad("versionFront","VERSION: "+VERSION, null);
			
		};
		
		
		/* TOLUCA | Modificación mínima para evitar ser intrusivo. */
		$rootScope.cargaDato = function (nombreLlave, nombreDiv, callbackfunction, mostrarMensaje) {	
			try{	
				sesion.cargar(nombreDiv, callbackfunction, nombreLlave);
				$rootScope.loggerIpad("cargaDato", nombreLlave);
								
			}catch(e){
				if (typeof mostrarMensaje === 'undefined') {
					modalService.alertModal("error en carga de información",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");
				} else {
					try {
						angular.element('#' + nombreDiv).scope()[ callbackfunction ](undefined);
						angular.element('#' + nombreDiv).scope().$apply();
					} catch(x) { console.log('En serio lo intentamos, pero no pudo funcionar.'); }
				}
			}
		};
		
		
		/* TOLUCA | Modificación mínima para evitar ser intrusivo. */
		$rootScope.borraDato = function (nombreLlave, mostrarMensaje) {	
			try{	
				sesion.guardar(nombreLlave, "");
				$rootScope.loggerIpad("borraDato", nombreLlave);
								
			}catch(e){
				if (typeof mostrarMensaje === 'undefined') {
					modalService.alertModal("error al borrar el dato",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");
				}
			}
		};
			
		
		/* TOLUCA | Modificación mínima para evitar ser intrusivo. */
		$rootScope.guardaDatosIpad= function(key,value, mostrarMensaje){	
			try{
				sesion.guardar(key, value);
				$rootScope.loggerIpad("guardaDatosIpad", {"key": key, "value": value});
			} catch(e) {
			 	if (typeof mostrarMensaje === 'undefined') {
			 		modalService.alertModal("error al guardar",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");
			 	}
			}
		};
		 
		$rootScope.asignaTracker = function (id) {	
			try{
				trackerId = id;
				tracker.ponerId( id );
				$rootScope.loggerIpad("asignaTracker", {"id":id});
			}catch(e){
				modalService.alertModal("error eliminaTracker",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");
			}
						
		};
		
		$rootScope.eliminaTracker = function (id) {		
			try{
				trackerId = null;
				tracker.borrarId( id );
				$rootScope.loggerIpad("eliminaTracker", {"id":id});
			}catch(e){
				modalService.alertModal("error eliminaTracker",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");
			}
						
		};
		
		$rootScope.guardarPuntoDeControl = function (nombrePC, jsonObj) {	
			try{	
				tracker.guardarPuntoDeControl(nombrePC, jsonObj);
				$rootScope.loggerIpad("guardarPuntoDeControl", {"nombrePC": nombrePC, "jsonObj": jsonObj});
			}catch(e){
				modalService.alertModal("error guardarPuntoDeControl",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");
			}
						
		};
		
		$rootScope.recuperarPuntoDeControl = function (id, nombrePC, callbackfuncton) {
			try{
				_callbackfuncton = callbackfuncton;
				nombrePuntoControl = nombrePC;
				tracker.resolverId( id, "moduloTracker", "resolverPuntoDeControl" );
				$rootScope.loggerIpad("recuperarPuntoDeControl", {"nombrePC": nombrePC, "id": id});
			}catch(e){
				modalService.alertModal("error recuperarPuntoDeControl",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");
			}
						
		};
		
		
		$scope.resolverPuntoDeControl = function(response){
			try{
										
				if(response.nombrePuntoDeControl == nombrePuntoControl){					
					tracker.restaurarPuntoDeControl( trackerId, $scope, response.datos );					
					_callbackfuncton(response.datos);
					$rootScope.loggerIpad("resolverPuntoDeControl", null, response);
				}else								
					modalService.alertModal("restaurarPuntoDeControl",["El punto de control "+nombrePuntoControl+" no existe"], null, null, null);
				
			}catch(e){
				modalService.alertModal("error resolverPuntoDeControl",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");
			}
			
		};
									
		
		$rootScope.aplicarOCR_IFE = function (nombreDiv, callbackfunction) {			
			var jsonOCR = {};
			try{      
				Camara.ocr(nombreDiv, callbackfunction, jsonOCR);
				$rootScope.loggerIpad("aplicarOCR_IFE",jsonOCR);

			}catch(e){
            	modalService.alertModal("Error al capturar imagen",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");        	 
            }
		};
		
		$rootScope.aplicarOCR_Domicilio = function (nombreDiv, callbackfunction, jsonDomC) {   
            Camara.ocrDomicilio(nombreDiv, callbackfunction, jsonDomC);
            $rootScope.loggerIpad("aplicarOCR_Domicilio",jsonDomC);
        };

       
		/** Funcion para tomar fotos de los documentos en IPAD
		 * @param numfotos numero de fotos a tomar
		 * @param tiposfoto	arreglo con la descripci�n de las fotos a tomar (lo define Arquitectura que es due�o del componente )
		 * @param tipodocumento el tipo del documento al q se le toma la foto (lo define Arquitectura que es due�o del componente )
		 * @nombreDiv identificador del div donde se encunetra la funcion callback
		 * @callbackfunction funcion a la q se le enviara el json de respuesta del IPAD, tiene q se implementada en al controller local
		 * @returns Se envia el jason de respuesta a la funcion 'respuestaComponenteIpad' la cual tiene q se implementada en el controller local
		 */
		$rootScope.capturarImagenIpad = function (clienteId, numfotos, tiposfoto, tipodocumento, nombreDiv, callbackfunction, _numMax, titulo, subTiposfoto) {                       
            try{           	     
	             var jsonInput = {
	                     numFotos: numfotos,
	                     tiposFoto: tiposfoto,
	                     tipoDocumento: tipodocumento,
	                     numMax: _numMax,
	                     idCliente: clienteId,
	                     titulo: titulo,
	                     subTiposFoto: subTiposfoto,
	             };
	             Digitalizadora.digitalizar(nombreDiv, callbackfunction, jsonInput);
	             $rootScope.loggerIpad("capturarImagenIpad",jsonInput);	          	             
            }catch(e){
            	modalService.alertModal("Error al capturar imagen",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");           	 
            }

        };
        
        
        
        $rootScope.enviarImagen = function (idPersona, fileNameImg, nombreServicio, descDoc, nombreDiv, jsonServicio, callbackfunction) {  
        	try{    
        		RecursoBase.enviarRecurso(idPersona, fileNameImg, nombreServicio, descDoc, nombreDiv, callbackfunction, jsonServicio);
        		$rootScope.loggerIpad("enviarImagen",{"idPersona":idPersona, "fileNameImg": fileNameImg, "nombreServicio": nombreServicio, "descDoc": descDoc});	
        	}catch(e){
        		modalService.alertModal("Error al enviar la imagen",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");
        	}
            
        };
        
        
        
        $rootScope.capturarHuella = function( idDiv, stringDedos, funcionRetorno ){        	        	
        	/*Los dedos van de la mano izquida donde el menique es 1 al menique de la mano derecha que es 10*/
        	/* van separados por comas: ejm: '1,5,7' y con secuencia logica */
        	var jsonHuellas = {
                    huellas: stringDedos
            };
            
        	Huella.capturarHuellas( idDiv, funcionRetorno, jsonHuellas );      	
        	$rootScope.loggerIpad("capturarHuella",jsonHuellas);	
        };   
        
        
        
        $rootScope.verificarHuella = function( idDiv, funcionRetorno, ctesUnicosArray, callBackLocalFuntion ){        	        	
        	
        	var ctesUnicoString = "";
        	angular.forEach(ctesUnicosArray, function(CU){								
        		ctesUnicoString = ctesUnicoString + CU +",";
			});
        	       
        	
        	if( !generalService.isEmpty(callBackLocalFuntion) )
        		_callbackfuncton = callBackLocalFuntion;
        	
        	var jsonVeriFinger = {
                    componente: 200,
                    //CUs: "1-1-1486-27063, 1-1-2451-65362",
                    CUs: ctesUnicoString.substring(0, ctesUnicoString.length-1),
                    numIntentos: 3    //generalService.getDatafromCategory("CONSTANTES", "INTENTOS HUELLA", "VALOR.valor" )                
                };
        	        	
        	Huella.verificarHuella( idDiv, funcionRetorno, jsonVeriFinger );      	
        	$rootScope.loggerIpad("verificarHuella",jsonVeriFinger);	
        };   
        
        
        $rootScope.enviarHuellasIpad = function( idDiv, pais, sucursal, numSolicitud, fileName, funcionRetorno ){        	        	
        	try{
        		 var jsonHuellasCredito = {

        					"idPais": pais,
        					"idSucursal": sucursal,
        					"userSocket": "USRARQACERTUM",

        					"numSolicitud": numSolicitud,
        					"numFlujo": 2,

        					"xml": fileName
        				};

        				Huella.enviarHuellas(idDiv, funcionRetorno, jsonHuellasCredito);
        				$rootScope.loggerIpad("enviarHuellasIpad",jsonHuellasCredito);	
        	}catch(e){
        		$rootScope.waitLoaderStatus = LOADER_HIDE;
            	modalService.alertModal("Error al capturar imagen",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");          	 
            }
        	
        };   
        
        $rootScope.visualizaPdf = function (idDiv, archivo, nombreArchivo,mostrarBotonCancelar,mostrarLeyenda, funcionRetorno){
        	try{
     		
        		var jsonVisor = {
        				"documento": archivo,
        				"directorio": "PDFS",
        				"titulo": nombreArchivo,
        				"mostrarBotonCancelar":mostrarBotonCancelar,
        				"mostrarLeyenda":mostrarLeyenda
        		};
        		
        		
        		Visor.verDocumentoPDF(idDiv, funcionRetorno, jsonVisor);
        		$rootScope.loggerIpad("visualizaPdf",jsonVisor);	
        		
        	}catch(e){
        		$rootScope.waitLoaderStatus = LOADER_HIDE;
            	modalService.alertModal("Error al visualizar el documento",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");      
        	}
        };
                       		        
        
        
        $rootScope.tomarRostro = function (nombreDiv, respuesta) {
        	try{
        		//Se mandan a BD los eventos almacenados en memoria
				$rootScope.enviaEventos();
				
        		// Se llama un metodo del objeto Digitalizadora, esta es la linea que abrira el componente para abrir fotos             		
        		Camara.tomarFoto(nombreDiv, respuesta, {});
        		$rootScope.loggerIpad("tomarRostro","tomar Rostro");
        	}catch(e){
        		$rootScope.waitLoaderStatus = LOADER_HIDE;
        		modalService.alertModal("Error al capturar Rostro",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");           	 
            }
    	};
    	
    	
    	
    	$rootScope.obtenerEnviosXCliente = function (nombreDiv, callbackfunction, idCliente) {
        	try{             		        		
        		Envios.obtenerEnviosXCliente(nombreDiv, callbackfunction, idCliente);
        		$rootScope.loggerIpad("obtenerEnviosXCliente",{"idCliente": idCliente });
        	}catch(e){
        		$rootScope.waitLoaderStatus = LOADER_HIDE;
        		modalService.alertModal("Error al obtener los envios",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");         	 
            }
    	};
    	
    	
    	
    	$rootScope.obtenerRecursoPendiente = function (nombreDiv, callbackfunction, idPeticion) {
        	try{        		        		        		
//        		modalService.alertModal("obtenerRecursoPendiente",[nombreDiv, callbackfunction, idPeticion]);
        		Envios.obtenerRecursoPendiente(nombreDiv, callbackfunction, idPeticion);
        		$rootScope.loggerIpad("obtenerRecursoPendiente",{"idPeticion": idPeticion });
        	}catch(e){
        		$rootScope.waitLoaderStatus = LOADER_HIDE;
        		modalService.alertModal("Error al obtener el recurso",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");         	 
            }
    	};
    	
    	$rootScope.capturaTarjeta = function( scopeDiv, callBackFn, jsonObject )
    	{    		
    		try{        		
    			
    			var obj = jsonObject ? jsonObject : {};
        		Camara.ocrTarjeta( scopeDiv, callBackFn, obj );
        		$rootScope.loggerIpad("capturaTarjeta",jsonObject);
        	}catch( e ){
        		modalService.alertModal("Error al capturar la tarjeta",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");         	 
            }
    		
    	};
    	
    	$rootScope.ocrCodigoQR = function( scopeDiv, callBackFn, jsonObject )
    	{    		
    		try{        		
    			
    			var obj = jsonObject ? jsonObject : {};
        		Camara.ocrCodigo( scopeDiv, callBackFn, obj );
        		$rootScope.loggerIpad("ocrCodigoQR",jsonObject);
        	}catch( e ){
        		modalService.alertModal("Error al OCR QR",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");         	 
            }
    		
    	};
    	
    	$rootScope.reproducirVoz = function( scopeDiv, callBackFn, jsonObject )
    	{
    		
    		try{        		
    			var obj = jsonObject ? jsonObject : {};
        		Reproductor.reproducirVoz( scopeDiv, callBackFn, obj );
        		$rootScope.loggerIpad("reproducirVoz",jsonObject);
        	}catch( e ){
        		modalService.alertModal("Error al reproducir Voz",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");         	 
            }
    		
    	};
    	
    	
    
    	$scope.responseValidaHuellaInicio = function(ipadResponse){
    		modalService.alertModal("responseValidaHuellaInicio ",[ipadResponse.codigo]);
    		_callbackfuncton(ipadResponse);
    		$rootScope.loggerIpad("responseValidaHuellaInicio",null, ipadResponse);
    	};
    	    	    
    	
    	$scope.responseEnvioFotoIpadOf = function(responseIPAD){
    		$rootScope.loggerIpad("responseEnvioFotoIpadOf",null, responseIPAD);
			if( responseIPAD.codigo == RESPONSE_CODIGO_EXITO_IPAD )
				$rootScope.solicitudJson.cotizacion.clientes[0].foto = FOTO_ENCOLADO_IPAD;

		};	
		
		
		$scope.executeActionResponseExp = function(responseIpad){	    		    								
			$rootScope.loggerIpad("executeActionResponseExp",null, responseIpad);
			$rootScope.documetosResponseCita = true;
			if(responseIpad.codigo == RESPONSE_CODIGO_EXITO_IPAD){
				var arrayDocsId = generalService.getArrayValue("IdentificadoresDocs");
				
				angular.forEach( $rootScope.solicitudJson.documentos.documento, function(doc){						
					angular.forEach( arrayDocsId, function(id){
						if( doc.idDocumento == id)
							doc.status = STATUS_CAPTURADO;
					})										
				});
				
				var respaldo = generalService.getRespaldo();
				if( !generalService.isEmpty(respaldo) ){
					respaldo = JSON.parse(respaldo);
					angular.forEach( respaldo.documentos.documento, function(doc){	
						angular.forEach( arrayDocsId, function(id){
							if( doc.idDocumento == id)
								doc.status = STATUS_CAPTURADO;
						});
						
						
					});
					generalService.setRespaldo(respaldo);
				}								
			}		
			
		};
		

		$rootScope.obtenerClientesConEnviosWV = function( scopeDiv, callBackFn ){
			try{   
				Envios.obtenerClientesConEnvios( scopeDiv, callBackFn );
				$rootScope.loggerIpad("obtenerClientesConEnviosWV","obtenerClientes ConEnviosWV");
        	}catch( e ){
        		modalService.alertModal("Error al obtener lista",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");         	 
            }
		};

		$rootScope.capturarFirmaWV = function (divId, funcionCallback,jsonParameters) {											
			Firma.capturarFirma(divId,funcionCallback,jsonParameters);		
			$rootScope.loggerIpad("capturarFirmaWV",jsonParameters);
		};
		
		$rootScope.capturarFirma2WV = function (divId, funcionCallback,jsonParameters) {
			Firma.capturarFirma2(divId,funcionCallback,jsonParameters);		
			$rootScope.loggerIpad("capturarFirma2WV",jsonParameters);
		};
		
		$rootScope.enviarDocumentoWV = function (divId, funcionCallback,personaId, documentoId) {											
			Envios.enviarDocumento( divId, funcionCallback,personaId, documentoId );	
			$rootScope.loggerIpad("enviarDocumentoWV",{"personaId": personaId, "documentoId":documentoId});
		};
		
		$rootScope.obtenerGeolocalizacion = function( idDiv, callBackFn ){
			try{
				GPS.obtenerUbicacion( idDiv, callBackFn, {} );
				$rootScope.loggerIpad("obtenerGeolocalizacion","obtener Geolocalizacion");
			}catch( e ){
				modalService.alertModal("Error al obtener geolocalización",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");         	 
			}
		};
    	
		$rootScope.obtenerInformacionSucursal = function(idDiv, callBackFn){
			try{     
				maquina.obtenerInformacionSucursal(idDiv, callBackFn);
				$rootScope.loggerIpad("obtenerInformacionSucursal","obtener Informacion Sucursal");
	    	}catch( e ){
	    		modalService.alertModal("Error al obtener informacion sucursal",[e],null,null,null,"GENERAL", "EXCEPCION COMPONENTE");         	 
	        }
        };
        
        /**
         * Método de invocación al módulo Impresora del Wraper.
         * @param idDiv, cadena que describe el componente de html que contiene la referencia al controlador en el que 
         * se encuentra la función de callback.
         * 
         */
        $rootScope.imprimir = function(idDiv, callbackFunction, parameters, plantillaTicket) {
        	try {
        		if(typeof idDiv !== "undefined" && typeof callbackFunction !== "undefined" 
        			&& typeof parameters !== "undefined") {
        			// Se procede a la invocación.
        			
        			if(plantillaTicket){
        				Impresora.imprimirPDF(idDiv, callbackFunction, parameters);
        			}else{
        				Impresora.imprimirTicket(idDiv, callbackFunction, parameters);
        			}
        		} else {
        			// Bye, bye Spinner!
        			$rootScope.waitLoaderStatus = LOADER_HIDE;
        			
        			modalService.alertModal("¡Error!", "Faltan parámetros para la invocación.");
        		}
        	} catch(x) {
        		// Bye, bye Spinner!
    			$rootScope.waitLoaderStatus = LOADER_HIDE;
        		
        		modalService.alertModal("Fail!", [x.message], null, null, null, "GENERAL", "EXCEPCION COMPONENTE");
        	}
        };
    	
        
        /**
         * TOLUCA.
         * Función para invocar el componente que obtiene versiones presentes en la estación. 
         */
        $rootScope.getOfflineVersions = function(divID, callbackFunction, params) {
        	try {
        		// ¿No se tienen valores falsy para las entradas?
            	if (divID && callbackFunction && params) {
            		maquina.openVC(divID, callbackFunction, params);
            	} else {
            		throw {name:"Parámetros indefinidos", message:"Parámetros indefinidos."};
            	}
            	
            	// Se loguea la invocación.
    			$rootScope.loggerIpad("getOfflineVersions [SUCCESS]", params);
        	} catch(z) {
        		// Se loguea la invocación.
    			$rootScope.loggerIpad("getOfflineVersions [FAIL]", params, z);

				// Se invoca a la función para tratar errores.
				$rootScope.$emit("keepMovingNeverStop", {});    			
        	}
        }; 
        
	});
	
});	