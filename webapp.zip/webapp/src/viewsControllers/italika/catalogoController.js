'use strict'; 

define(["app"], function (app) {
	app.controller('catalogoController', function( $timeout, $scope, $rootScope, ngDialog, generalService, messageData, italikaService, modalService, validateService ) {
		
		var BUSQUEDA_POR = {SKU:1, DESCRIPCION:0};
		$scope.buscarDescripcion=true;
		$scope.obligatorioDes=true;
		$scope.obligatorioCod=false;
		$scope.buscarCodigo=false;
		$scope.busquedaAnterior="";
		$scope.catalogoProductos = new Array();
		$scope.paginador = {numRegistros:0, currentPage:0, pageSize: 0, numberOfPages:0};
		$scope.claveProducto={
				valor:"",
				enganche:0.0,
				engancheValor:""
		}
		$scope.init = function(){
			$scope.showPage = false;
			$scope.getTasaItalika();
			if( messageData ){
				$scope.cargaVista();
				$timeout(function(){
					$scope.showPage = messageData;
					$rootScope.waitLoaderStatus = LOADER_HIDE;
				}, 1);
			}
	    };
	    
		$scope.cargaVista=function(){
			if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
			$scope.titulo="Catálogo";
			$scope.paginador.pageSize = 5;
			if( generalService.isDefined(generalService.getArrayValue("cotizacionOfertaItalika")) )
				$scope.recotizando = true;
			else
				$scope.recotizando = false;
		};
		
		$scope.regresa=function(){
			if( generalService.isDefined(generalService.getArrayValue("cotizacionOfertaItalika")) )
				generalService.locationPath("/ochoPasos");
			else
				generalService.locationPath("/simulador");
		};
		
		$scope.cambiaBuscador=function(opcBuscador){
			if(opcBuscador == 1){
				$scope.buscarDescripcion=true;
				$scope.obligatorioDes=true;
				$scope.obligatorioCod=false;
				$scope.buscarCodigo=false;
			}else{
				$scope.buscarDescripcion=false;
				$scope.obligatorioDes=false;
				$scope.obligatorioCod=true;
				$scope.buscarCodigo=true;
			}
			$scope.claveProducto.valor=""
			$scope.busquedaAnterior="";
		};
		
		
		$scope.buscarProducto=function(){
			validateService.limpiaMascaras();
			if($scope.forBuscarCatalogo.$valid){
				$scope.catalogoProductos = new Array();
				var request = {
								porcentaje: '0',
								valor: $scope.claveProducto.valor,
								tipoPeticion: $scope.buscarDescripcion? BUSQUEDA_POR.DESCRIPCION:BUSQUEDA_POR.SKU,
								idSolicitud: $rootScope.solicitudJson.idSolicitud
							};
				
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				italikaService.consultaItalika(request).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var jResponse = JSON.parse(data.data.respuesta);
								
								if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){									
									var sku;	
									var index = -1;
									angular.forEach(jResponse.data, function(value, key){										
										if(value.sku != sku){
											value.precioSinEnganche = value.precioNeto
											$scope.catalogoProductos.push(value);
											index++;											
										}
										$scope.validaEnganche(index);																											
										sku = value.sku;
									});	
									
									$scope.paginador.numRegistros = $scope.catalogoProductos.length;
									$scope.paginador.numberOfPages = Math.ceil($scope.paginador.numRegistros/$scope.paginador.pageSize);
									$scope.Motos = $scope.catalogoProductos;
									
								}else if(jResponse.codigo == 1241){
									modalService.alertModal("Aviso",[jResponse.descripcion], "Aceptar", "bgAzulI", "italika");
									
								}else									
									modalService.alertModal("Error "+jResponse.codigo,[jResponse.descripcion], "Aceptar", "bgAzulI", "italika");								
								
							}else								
								modalService.alertModal("Error "+data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "bgAzulI", "italika");
							
																							
						}, function(error){											                
							$rootScope.waitLoaderStatus = LOADER_HIDE;
						}
					);
			}
		}
		
	
		$scope.buscaPrueba= function(){
			$scope.catalogoProductos=[];
			validateService.limpiaMascaras();
			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche = $rootScope.claveProducto.engancheValor;
			var sku;	
			var index = -1;
			angular.forEach($scope.Motos, function(value, key){
				if (!value.sku){
					value.sku = value.fiProdid;
					if(value.sku != sku){
						value.nombreProducto = value.fcNombreProducto
						value.precioSinEnganche = value.fnPrecio
						value.sku
						$scope.catalogoProductos.push(value);
						index++;											
					}
				}else{
					$scope.catalogoProductos.push(value);
					index++;
				}
				$scope.validaEnganche(index);
				sku = value.sku;
			});	
			
			$scope.paginador.numRegistros = $scope.catalogoProductos.length;
			$scope.paginador.numberOfPages = Math.ceil($scope.paginador.numRegistros/$scope.paginador.pageSize);
		}
		
		$scope.validaEnganche = function(index){
			if(!$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche)
				$scope.catalogoProductos[index].montoFinanciar = $scope.catalogoProductos[index].precioSinEnganche;
			else
				$scope.catalogoProductos[index].montoFinanciar = $scope.catalogoProductos[index].precioSinEnganche - $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche
			$scope.catalogoProductos[index].abonos  = $rootScope.Abonos($scope.catalogoProductos[index].montoFinanciar);
			$scope.catalogoProductos[index].enganche = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche
			if($scope.recotizando){
				$scope.catalogoProductos[index].aprobado = $scope.selecciona($scope.catalogoProductos[index]);
				if ($scope.catalogoProductos[index].precioSinEnganche < $scope.catalogoProductos[index].enganche){
					$scope.catalogoProductos[index].aprobado = false;
				}
			}else{
				$scope.catalogoProductos[index].aprobado = true;
				if ($scope.catalogoProductos[index].precioSinEnganche < $scope.catalogoProductos[index].enganche){
					$scope.catalogoProductos[index].aprobado = false;
				}
			}
		}
		
		
		$rootScope.Abonos = function (monto){
			var catalogoTasas = $scope.Tasas;
			var abono = {normal:0, puntual:0}
			for(var i = 0; i < catalogoTasas.length; i++){
				if (monto >= catalogoTasas[i].fnMontoInicial && monto <= catalogoTasas[i].fnMontoFinal && catalogoTasas[i].fiPlazo == 102){
					abono.normal = ((monto*(1+parseFloat(catalogoTasas[i].fnAbonoSemanalNormal)))/102);
					abono.puntual = ((monto*(1+parseFloat(catalogoTasas[i].fnAbonoSemanalPuntual)))/102); 
					return abono;
				}
			}
			return abono;
			
		}
		
		$scope.selecciona = function(producto){
			if ($rootScope.solicitudJson.capacidadPagoComprobable > 0){
				if ($rootScope.solicitudJson.capacidadPagoComprobable >= producto.abonos.puntual){
					return true;
				}else{
					return false;
				}
			}else{
				if ($rootScope.solicitudJson.capacidadPagoNoComprobable >= producto.abonos.puntual){
					return true;
				}else{
					return false;
				}
			}
			
		}
		
		$scope.productoSeleccionado=function(producto){	
			producto.montoFinanciar = producto.precioSinEnganche - $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche
			var pagos =$rootScope.Abonos(producto.montoFinanciar);
			producto.abonos=  pagos; 
//			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche 
			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = producto.precioSinEnganche
			 
			$rootScope.solicitudJson.cotizacion.pagoPuntual = producto.abonos.puntual
			$rootScope.solicitudJson.cotizacion.pagoNormal = producto.abonos.normal
			
			generalService.setArrayValue("productoItalika", producto);			
			generalService.locationPath("/cotizadorItalika");
		};
		
		$scope.getTasaItalika = function(){
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			italikaService.getTasaItalika(  ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var JsonResp = JSON.parse(data.data.respuesta);
						$scope.Tasas = JsonResp.data.tasasCDT;							
					}else
						modalService.alertModal("Error "+data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "bgAzulI", "italika");
				}, function(error){
	               $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
					
				}
			);
		};
		
		$scope.getProductoPorNombreItalika = function(){
			if ($scope.buscarCodigo){
				$scope.buscarProducto()
			}else{
				if($scope.forBuscarCatalogo.$valid){
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					italikaService.getProductoPorNombreItalika( {nombreProducto: $scope.claveProducto.valor} ).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var JsonResp = JSON.parse(data.data.respuesta);
								$scope.Motos = JsonResp.data.productosCDT;
								$scope.buscaPrueba()	
							}else      
								modalService.alertModal("Error "+data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "bgAzulI", "italika");
						}, function(error){
			               $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
							
						}
					);
				}
			}
		};
		
	});
});