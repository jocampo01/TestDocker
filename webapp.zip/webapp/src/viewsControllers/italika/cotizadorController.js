define(["app"], function (app) {
	
	app.controller('cotizadorController',function($scope, $rootScope, $routeParams, messageData, generalService, italikaService, modalService, solicitudService) {
		
		$scope.enganche = {};
		$scope.NuevoItalika = true;
		$scope.showPage = false;
		$scope.productoItalika = null;
		$scope.seCotizoItalika = false;	
		$scope.showPorcenjeEnganche = true;
		
		var tasas = new Array();
		var BUSQUEDA_POR = {SKU:1, DESCRIPCION:0};
				
		
		$scope.init = function(){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
		
			
			if( messageData ){	
				
				$scope.productoItalika = generalService.getArrayValue("productoItalika");	
				
				if(generalService.isDefined($scope.productoItalika)){
					$scope.enganche = {monto:null,porcentaje:0};
					loadView();
					if ($scope.NuevoItalika){
						$scope.enganche.monto = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche;
						calculaMontoAfinanciar($scope.productoItalika.precioSinEnganche, $scope.enganche.monto);	
					}else
						calculaMontoAfinanciar($scope.productoItalika.precioSinEnganche, 0);					
					$scope.showPage = messageData;
					
				}else
					generalService.locationPath("/simulador");
				
			}
			
		}
					
		
		$scope.regresar = function(){	
			generalService.setArrayValue("productoItalika", null);
			generalService.setArrayValue("seCotizoItalika", false);
			generalService.setArrayValue("nombreProducto", "");
			$scope.productoItalika = null;
			
			if(generalService.isDefined(generalService.getArrayValue("cotizacionOfertaItalika")) )				
				$rootScope.solicitudJson.cotizacion = JSON.parse(generalService.getArrayValue("cotizacionOfertaItalika"));		
						
			else{
				limpiaCotizacion();
				$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = 0;
				$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto = "0";
			}
			
			generalService.locationPath("/catalogoItalika");
							
		}
		
		
		$scope.$watch("enganche.porcentaje",function(){
			var porcentajeS = $scope.enganche.porcentaje.toString();
			if( porcentajeS.indexOf(".")==-1  && porcentajeS.length > 2){						
				$scope.enganche.porcentaje = parseFloat(porcentajeS.substring(0,2)+"."+porcentajeS.substring(2)).toFixed(2);				
			}
			
		},true);
		
		
		$scope.calculaEnganche = function(esPorcentaje){
			var enganche = 0;
			var monto = $scope.productoItalika.precioSinEnganche;
			
			if(esPorcentaje){
				
				if( $scope.enganche.porcentaje != null){
										
					if($scope.enganche.porcentaje > 90)
						$scope.enganche.porcentaje = 90;
						
					$scope.enganche.monto = Math.ceil( ($scope.enganche.porcentaje * monto) / 100 );
					enganche = $scope.enganche.monto;
					
					if( enganche > 1)
						calculaMontoAfinanciar(monto,enganche);
					
					else 
						reset();
						
				}else
					reset();													
					
				
				
			}else{
								
				if(  !generalService.isEmpty( $scope.enganche.monto ) ){
					
					enganche = parseInt(generalService.cleanValue( $scope.enganche.monto));	
					
					if(enganche < monto){
						
						$scope.enganche.porcentaje =  parseFloat((enganche * 100) / monto);
						
						if($scope.enganche.porcentaje > 90 ){
							$scope.enganche.porcentaje = 90;
							$scope.calculaEnganche(true);
						}else{
							if($scope.enganche.porcentaje == 0){
								$scope.enganche.monto = enganche = 0;
								reset();
							}else
								$scope.calculaEnganche(true);															
						}
							
						
					}else 
						reset();
					
				}else
					reset();																			
				
			}
			
		}
		
		
		
		$scope.guardar = function(){
			
			if(generalService.isDefined(generalService.getArrayValue("cotizacionOfertaItalika")) )
				guardarSeccion();
			else{
				generalService.setArrayValue("seCotizoItalika", $scope.seCotizoItalika);			
				generalService.setArrayValue("nombreProducto", $scope.productoItalika.nombreProducto);
				generalService.locationPath("/simulador");
			}						
			
		}
		
		
		$scope.calculaMonto=function(){	
			if (!$scope.NuevoItalika){
	 			var existePlazo = false;
	 		
	 			var monto = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;	 			
	 			var periodicidad = $rootScope.solicitudJson.cotizacion.idPeriodicidad;
	 			var plazo = $rootScope.solicitudJson.cotizacion.plazo;	
	 			
	 			var index2 =  $scope.radioPlazo.map(function(d){
					return d["radioValue"];			    			
				}).indexOf (plazo);
	 			
				if (index2 != -1){
					var plazoItalika  = $scope.radioPlazo[index2].objItalika;				
					var montoConIntereses = plazoItalika.abonoSemanalNormal * plazoItalika.plazo;
					
					$rootScope.solicitudJson.cotizacion.montoTotal = montoConIntereses;
					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses = montoConIntereses - monto;
					$rootScope.solicitudJson.cotizacion.pagoNormal = plazoItalika.abonoSemanalNormal;
					
					$rootScope.solicitudJson.cotizacion.pagoPuntual = plazoItalika.abonoSemanalPuntual;
					$rootScope.solicitudJson.cotizacion.ultimoAbono = plazoItalika.abonoSemanalNormal;				
					$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].cantidad = 1;
					
					$scope.seCotizoItalika = true;
					
				}else
					limpiaCotizacion();
			}
 			 		
		};
		
		
		$scope.consultaItalika = function(){
			$scope.radioPlazo = new Array();
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			var porcentaje = parseInt($scope.enganche.porcentaje); 
			
			var request = {
					porcentaje: porcentaje > 0 ? (porcentaje/100).toString() : porcentaje.toString(),
					valor: $scope.productoItalika.sku,
					tipoPeticion: BUSQUEDA_POR.SKU,
					idSolicitud: $rootScope.solicitudJson.idSolicitud
				};
			italikaService.consultaItalika(request).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jResponse = JSON.parse(data.data.respuesta);
							
							if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								
								if(jResponse.data.length > 0){
									
									angular.forEach(jResponse.data, function(value, key){
//										if(value.aprobado == 1)
										if(value.plazo == '102')
											$scope.radioPlazo.push( {radioId:key+1, estilo:"", radioValue:parseInt(value.plazo), radioLabel:value.plazo,spanId:"opc-cuanto-"+(key+1),
												                     disable:false, objItalika:value }  );										
									});		
																		
									
									var longPlazos = $scope.radioPlazo.length;
									$scope.radioPlazo[longPlazos-1].estilo = "ultimo";																											
									
									var index2 =  $scope.radioPlazo.map(function(d){
										return d["radioId"];							    			
									}).indexOf ($rootScope.solicitudJson.cotizacion.idPlazo);
									
									
									if (index2 == -1){
										if (PLAZOS_DEFAULT == 1){										
											$rootScope.solicitudJson.cotizacion.idPlazo = $scope.radioPlazo[longPlazos-1].radioId;
											$rootScope.solicitudJson.cotizacion.plazo = $scope.radioPlazo[longPlazos-1].radioValue;
										}else{
											$rootScope.solicitudJson.cotizacion.idPlazo = $scope.radioPlazo[0].radioId;
											$rootScope.solicitudJson.cotizacion.plazo = $scope.radioPlazo[0].radioValue;
										}
									}	
									
									$scope.calculaMonto();
									
								}else{
									modalService.alertModal("AVISO",["No se obtuvo información de los plazos","Cambia el monto del enganche e intenta de nuevo "], "Aceptar", "bgAzulI", "italika");
									reset();									
								}
									
								
							}else{
								modalService.alertModal("Error "+jResponse.codigo,[jResponse.descripcion], "Aceptar", "bgAzulI", "italika");
								reset();
							}									
																
							
						}else{							
							limpiaCotizacion();
							modalService.alertModal("Error "+data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "bgAzulI", "italika");
							
						}								
							
						
																						
					}, function(error){											                
						$rootScope.waitLoaderStatus = LOADER_HIDE;
					}
				);
		}
		
		
		var guardarSeccion = function(){	
	 		
			$rootScope.waitLoaderStatus = LOADER_SHOW;
	 		solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($rootScope.solicitudJson), seccion: SECCION_SOLICITUD } ).then(
		 			function(data){
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
		 					var responseJson = JSON.parse(data.data.respuesta);
		 					
		 					var fnStatusOK = function( esMalZonificada ){								
								$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO; //FIX COMMENT 01/04/2016
		 						$rootScope.solicitudJson = responseJson.data;
								if( esMalZonificada && typeof esMalZonificada !== 'undefined' ){
									var excepciones = [ SECCION_HOGAR.toString() ];
									generalService.bloqueoSecciones( $rootScope.solicitudJson, excepciones );
								}
								$rootScope.calculaDocumentos();	
								generalService.setArrayValue("cotizacionOfertaItalika", null);
								generalService.locationPath("/ochoPasos");	
							
		 					};
		 					
		 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
								fnStatusOK();							
							}else if( responseJson.codigo == STATUS_SOLICITUD.malZonificada.guardarSeccion ){
								generalService.setDataBridge( {esMalZonificada:true} );
								fnStatusOK( true );
							}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
								var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
								$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
							}else{
								$scope.seCotizoItalika = false;
								if(responseJson.codigo == ERROR_SOL_RECHAZADA){
									var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
									var marca = $rootScope.solicitudJson.marca;
									var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],"Aceptar", "/simulador",null,null,buildJsonDefault);
								}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
									generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
									generalService.locationPath("/ficha");
								}else{
									$rootScope.message("Volver a cotizar",[ERROR_SERVICE],"Aceptar", null);
								}
		 					}
		 				}else{
		 					$scope.seCotizoItalika = false;
		 					$rootScope.message("Volver a cotizar",[generalService.displayMessage(data.data.descripcion)], "Aceptar", null);
		 				}
		 			}, function(error){                    
		 				$scope.seCotizoItalika = false;
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				$rootScope.message("Error al volver a cotizar",[ERROR_SERVICE], "Aceptar", null);								
		 			}	
				);
		}
		
		var calculaMontoAfinanciar = function(monto, enganche){					
			
			var montoaFinanciar = monto - enganche;
			if ($scope.NuevoItalika){
				var pagos = $rootScope.Abonos(montoaFinanciar)
				$rootScope.solicitudJson.cotizacion.pagoPuntual = pagos.puntual;
				$rootScope.solicitudJson.cotizacion.pagoNormal = pagos.normal;
				$scope.seCotizoItalika = true;
				$scope.radioPlazo= [];
				$scope.radioPlazo.push( {radioId:1, estilo:"", radioValue:102, radioLabel:"102",spanId:"opc-cuanto-"+(1),
						                     disable:false, objItalika:{plazo:102} }  );											
				var longPlazos = $scope.radioPlazo.length;
				$scope.radioPlazo[longPlazos-1].estilo = "ultimo";																											
			
				var index2 =  $scope.radioPlazo.map(function(d){
					return d["radioId"];							    			
				}).indexOf ($rootScope.solicitudJson.cotizacion.idPlazo);
			
			
				if (index2 == -1){
					if (PLAZOS_DEFAULT == 1){										
						$rootScope.solicitudJson.cotizacion.idPlazo = $scope.radioPlazo[longPlazos-1].radioId;
						$rootScope.solicitudJson.cotizacion.plazo = $scope.radioPlazo[longPlazos-1].radioValue;
					}else{
						$rootScope.solicitudJson.cotizacion.idPlazo = $scope.radioPlazo[0].radioId;
						$rootScope.solicitudJson.cotizacion.plazo = $scope.radioPlazo[0].radioValue;
					}
				}
				
				var plazoItalika  = $scope.radioPlazo[0].objItalika;				
				var montoConIntereses = $rootScope.solicitudJson.cotizacion.pagoNormal * plazoItalika.plazo;
				
				$rootScope.solicitudJson.cotizacion.montoTotal = montoConIntereses;
				$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses = montoConIntereses - montoaFinanciar;
//				$rootScope.solicitudJson.cotizacion.pagoNormal = plazoItalika.abonoSemanalNormal;
				$rootScope.solicitudJson.cotizacion.ultimoAbono = $rootScope.solicitudJson.cotizacion.pagoNormal;				
				$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].cantidad = 1;
				
				$scope.seCotizoItalika = true;
				$scope.calculaEnganceNuevo();

			}else{
				$scope.consultaItalika();
			}
			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = montoaFinanciar;			
			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche = enganche;																								
			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto = $scope.productoItalika.sku.toString();
			
		}
		
		
		var reset = function(){
			$scope.seCotizoItalika = false;
			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = $scope.productoItalika.precioSinEnganche;
			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche = 0;
			
			$scope.enganche.monto = null;
			$scope.enganche.porcentaje = 0;
			
			calculaMontoAfinanciar($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto, 0);
		};
				
		
		var limpiaCotizacion = function(){
			$scope.seCotizoItalika = false;
	 		$rootScope.solicitudJson.cotizacion.montoTotal = 0.0;				
 			$rootScope.solicitudJson.cotizacion.pagoNormal = 0.0;				
 			$rootScope.solicitudJson.cotizacion.pagoPuntual = 0.0;
 			$rootScope.solicitudJson.cotizacion.ultimoAbono = 0.0;
 			$rootScope.solicitudJson.cotizacion.idPlazo = 0.0;
 			$rootScope.solicitudJson.cotizacion.plazo = 0.0;
 			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses = 0.0; 			
 			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].cantidad = 0.0;
 			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].enganche = 0;
 			$scope.enganche = {monto:null,porcentaje:0};
	 	};
	 	
		var loadView = function(){
			
			$scope.origen = configuracion.origen.tienda? "TIENDA":"WEB";
			
			$scope.textoBotonRegresar = generalService.getDataInput("OCHO PASOS","TEXTO BOTON REGRESAR",$scope.origen);
			$scope.etiquetaTiempo = generalService.getDataInput("SIMULADOR","ETIQUETA TIEMPO"       ,$scope.origen);
			$scope.pagoRequerido       = generalService.getDataInput("SIMULADOR","PAGO REQUERIDO"        ,$scope.origen);
			$scope.pagoRequerido.texto = $scope.pagoRequerido.texto.replace(/\\/g,'');
			$scope.pagoOportuno        = generalService.getDataInput("SIMULADOR","PAGO OPORTUNO"         ,$scope.origen);
			$scope.pagoOportuno.texto = $scope.pagoOportuno.texto.replace(/\\/g,'');
			
			$scope.etiquetaTiempo.texto = "Plazos"
			$scope.titulo = "Catálogo";																		
		}
		
		$scope.calculaEnganceNuevo = function(){
			var enganche = 0;
			var monto = $scope.productoItalika.precioSinEnganche;		
				if(  !generalService.isEmpty( $scope.enganche.monto.toString() ) ){
					enganche = parseInt(generalService.cleanValue( $scope.enganche.monto));	
					if(enganche < monto){
						$scope.enganche.porcentaje =  parseFloat((enganche * 100) / monto);
						$scope.porcentaje=""+$scope.enganche.porcentaje;
						$scope.porcentaje=$scope.porcentaje.substring(0,5);
					}
				}
		};
		
	});
	
});   