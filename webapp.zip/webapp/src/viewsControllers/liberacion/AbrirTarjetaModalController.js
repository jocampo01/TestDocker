'use strict';

define(["app"], function (app) {
//controlador para huellaModalview	 

	app.controller('tarjetaModalController', function($scope,  $rootScope, ngDialog, $location, solicitudService, modalService, callCenterService, clienteUnicoService,generalService ){
		$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";
		$scope.numTarjeta="";
		$scope.validaTarjeta = function(e){
			console.log($scope.numTarjeta);
			if (e.keyCode == 16){
//				$scope.confirm($scope.numTarjeta);
			} 
		}
		$scope.cerrar = function(){
			if ($scope.numTarjeta.length >= 16)
				$scope.confirm($scope.numTarjeta);
		}
	});
});
//controlador para huellaModalview		