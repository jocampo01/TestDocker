'use strict';

define(["app"], function (app) {
	
	app.controller('creditoController', function($rootScope, $scope, messageData, validateService, generalService, buroService, solicitudService, callCenterService, modalService) {
		
		
		var titulo = "Credito";		
		
		$scope.descCatalog = new Object();				
		$scope.resCon={};
		$scope.datosCredito = {};	
		$scope.resCon.capacidadPago = 0;
		$scope.diaPago = $rootScope.solicitudJson.diaPago;
		$scope.ID_PRODUCTO = ID_PRODUCTO;
		$scope.canales = CANALES;
		$scope.muestraProuctosAutorizados = false;
		$scope.mostrarDiaPagoReactivado=false;
		/**
		* REQ 85337
		* Se valida cuando se debe de mostrar el select de dia de pago
		*/
		$scope.consultarDiaPagoReactivado = function(){
			if (!$rootScope.productosTarjetas($rootScope.solicitudJson.idProducto) || $rootScope.solicitudJson.tipoSolicitud == SOLICITUD_REACTIVADO){
				return true;
			}else
				return false;
		}
		
		$scope.init = function(){			
						
			if( messageData  ){					
				
				$scope.radioProducto=[];
				
				var productos = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.CATALOGO PRODUCTOS"];						
				$scope.descCatalog = generalService.getProductosCredito(productos, ID_PRODUCTOS);
				$scope.hideRegresa = ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.evalucionCorrectaBateria || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.evalucionCorrectaBateriaMCO) ? true:false;
				
				if( generalService.existeSolicitud($rootScope.solicitudJson) ){
					
					loadView();										
					
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					buroService.resultadoConsulta($rootScope.solicitudJson.idSolicitud,$rootScope).then(
							function(objRes){								
								$scope.datosCredito = objRes.datosCredito;
								$scope.resCon= objRes.resConsulta;		
								
								if ($rootScope.solicitudJson.idCanal == CANALES.elektra && 
										($rootScope.solicitudJson.idProducto==ID_PRODUCTO.italika||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.telefonia||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.consumo))
									$scope.resCon.pedidos[0].saldoPedido=0;
								
								if ($rootScope.solicitudJson.idCanal == CANALES.elektra && 
										($rootScope.solicitudJson.idProducto==ID_PRODUCTO.italika||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.telefonia||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.consumo))
									$scope.resCon.ocupado = 0;

								if ($rootScope.solicitudJson.idCanal == CANALES.elektra && 
										($rootScope.solicitudJson.idProducto==ID_PRODUCTO.italika||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.telefonia||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.consumo))
									$scope.resCon.disponible = $scope.resCon.capacidadPago;
																								
								$scope.informaleCliente.texto="<h1>Infórmale a <b>{{ solicitudJson.cotizacion.clientes[0].nombre }} {{ solicitudJson.cotizacion.clientes[0].apellidoPaterno }} {{ solicitudJson.cotizacion.clientes[0].apellidoMaterno }}</b> que su "+$scope.resCon.descProducto+" fue:</h1><h1 style=\"margin:20px 0\"><span>AUTORIZADO</span></h1>"
								$scope.informaleCliente.texto = $scope.informaleCliente.texto.replace(/\\/g,'');
								
// I-MODIFICACION TDC (LEYENDAS TDC)												
								$scope.informaleClienteTDC.texto ="<h1><b>Infórmale a {{ solicitudJson.cotizacion.clientes[0].nombre }} {{ solicitudJson.cotizacion.clientes[0].apellidoPaterno }} {{ solicitudJson.cotizacion.clientes[0].apellidoMaterno }}</b><br></h1><h1 style=\"margin:20px 0\">  que su Tarjeta de Crédito fue: <span>AUTORIZADA</span> <br> con las siguientes características:</h1> ";
								$scope.informaleClienteTDC.texto =$scope.informaleClienteTDC.texto.replace(/\\/g,'');
// F-MODIFICACION TDC (LEYENDAS TDC)												
								/**
								 * Cambiar la bandera muestraCapacidadConsumo a true tambien cuando es canal soriana
								 */
								if(($rootScope.solicitudJson.idProducto == ID_PRODUCTO.consumo || $rootScope.solicitudJson.idProducto == ID_PRODUCTO.italika) && ($rootScope.sucursalSession.idCanal == CANALES.elektra || $rootScope.sucursalSession.idCanal == CANALES.soriana)){
									$scope.muestraCapacidadConsumo = true;
									var capacidadesCliente = obtenerCapacidadesPrestamoyProducto($rootScope.capacidadesPagoProducto);
									if($rootScope.solicitudJson.banderaIngresos == 1){
										$scope.montoOferta30DiasCP = capacidadesCliente.prestamoPersonal.capacidadPagoComprobable;
										$scope.montoOferta30DiasCC = capacidadesCliente.consumo.capacidadPagoComprobable;
									}else{
										$scope.montoOferta30DiasCP = capacidadesCliente.prestamoPersonal.capacidadPagoNoComprobable;
										$scope.montoOferta30DiasCC = capacidadesCliente.consumo.capacidadPagoNoComprobable;
									}
									
									
								}
								continuarCargaVista();
										
							}, function(error){
								$rootScope.message(titulo, [error], "Aceptar", null, "bgCafeZ", "cafeZ");
				                $rootScope.waitLoaderStatus = LOADER_HIDE; 								
							}
					);
				
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message(titulo, [SIN_SOLICITUD.texto], "Aceptar", "/", "bgCafeZ", "cafeZ");
				}
																									
				
			}else{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message(ERROR_CARGA_PAGINA.titulo, [ERROR_CARGA_PAGINA.texto], "Aceptar", "/", "bgCafeZ", "cafeZ");
			}
				
		};
			
		function obtenerCapacidadesPrestamoyProducto(capacidadesPagoProducto){
	    		var capacidadesOferta30Dias={
	    			prestamoPersonal:{
					capacidadPagoComprobable:0,
					capacidadPagoNoComprobable:0
				},
				consumo:{
					capacidadPagoComprobable:0,
					capacidadPagoNoComprobable:0
				}
			}
	    	
	    		for(var i=0; i< capacidadesPagoProducto.length;i++){
				if(capacidadesPagoProducto[i].producto == PRODUCTOS.prestamoPersonal.ID.valor){
					capacidadesOferta30Dias.prestamoPersonal.capacidadPagoComprobable   = capacidadesPagoProducto[i].capacidadPagoComprobable;
					capacidadesOferta30Dias.prestamoPersonal.capacidadPagoNoComprobable = capacidadesPagoProducto[i].capacidadPagoNoComprobable;
				}
				
				if($rootScope.solicitudJson.idProducto == $rootScope.capacidadesPagoProducto[i].producto){
					capacidadesOferta30Dias.consumo.capacidadPagoComprobable   = capacidadesPagoProducto[i].capacidadPagoComprobable;
					capacidadesOferta30Dias.consumo.capacidadPagoNoComprobable = capacidadesPagoProducto[i].capacidadPagoNoComprobable;
				}
			}
	    		
	    		return capacidadesOferta30Dias;
	    }
		
		/**
		 * Función para realizar el marcado de la solicitud, cuando llega a liberación sin haber
		 * sido certificada mediante el código celular.
		 * Se agrega aquí, de manera temporal, dado que pasado este punto, ya regresa a la pantalla de Liberación.
		 */
		function marcarCertificacionSinVerificiacionCelular() {
			var LIBERACION_SIN_CERTIFICAR_CELULAR = 5004;

			if($rootScope.solicitudJson.envioCelular != 1) {
				var solicitud = $rootScope.solicitudJson;

				solicitud.marca = LIBERACION_SIN_CERTIFICAR_CELULAR;

				solicitudService.actualizarSolicitud(solicitud).then(
						function(exito) {
							// Se deja constancia en los logs.
							$rootScope.loggerIpad("marcarCertificacionSinVerificiacionCelular", null, exito.data);
						}, function(error) {
							// Se deja constancia en los logs.
							$rootScope.loggerIpad("marcarCertificacionSinVerificiacionCelular", null, error.data);
						}
				);
			}
		}
		
		$scope.guardar = function(){							
			
			if( generalService.isEmpty($scope.diaPago) )
				$rootScope.message(titulo, ["Selecciona el día que el cliente desea realizar sus pagos."], "Aceptar", null, "bgCafeZ", "cafeZ", null, "CREDITO", "DIA PAGO");				
			else{

				/*\Se agregan eventos para la bitacora\*/
//				(Verificación Expediente)
				$rootScope.addEvent( BITACORA.SECCION.verificacionExpediente.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.liberar.id, 0, BITACORA.SECCION.verificacionExpediente.guardarEnBD );								
				/*\Se agregan eventos para la bitacora\*/
				
				if(TEST_EMPLOYEES_TAZ.indexOf($rootScope.userSession.noEmpleado.toString()) > -1 || 
						($rootScope.solicitudJson.idProducto==PRODUCTOS.tarjetaAzteca.ID.valor && $rootScope.solicitudJson.folioFlujoUnico != ""))
					$rootScope.flujoSinTAZ=true;
					
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				 solicitudService.setDiaPago( { idSolicitud: $rootScope.solicitudJson.idSolicitud, dia: $scope.diaPago, sinTaz: $rootScope.flujoSinTAZ } ).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							
/** INICIA_OS-FLUJO COACREDITADO **/
							$scope.esObligadoSoldario = $rootScope.solicitudOSJson && $rootScope.solicitudOSJson.idSolicitud != "";
/** TERMINA_OS-FLUJO COACREDITADO **/
							
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								
								var jresponse = data.data.respuesta;
								
								jresponse.solicitudJson = JSON.parse(jresponse.solicitudJson);
								
								if(jresponse.solicitudJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){																																		
									
									if( !$rootScope.flujoSinTAZ && !generalService.isEmpty(jresponse.inventarioTazResponseJson) ){
										
											jresponse.inventarioTazResponseJson = JSON.parse(jresponse.inventarioTazResponseJson);
																														
											if(jresponse.inventarioTazResponseJson.codigo == RESPONSE_TARJETA_CODIGO_EXITO || $scope.esObligadoSoldario){
												
												var flujoPorCanal = $scope.verificarCanal( $rootScope.sucursalSession.idCanal ); 
												
												if(!$scope.esObligadoSoldario && jresponse.hayTarjetas && ($rootScope.solicitudJson.tipoSolicitud != SOLICITUD_REACTIVADO || ($rootScope.solicitudJson.tipoSolicitud == SOLICITUD_REACTIVADO && $rootScope.solicitudJson.ligarTazReactivacion != 0)) && $rootScope.sucursalSession.idCanal != CANALES.soriana) {
													/*
													 * ¿Podría ser necesario el marcado de la solicitud por liberación 
													 * sin código de verificación celular?
													 */ 
													if($rootScope.consultaFuncionalidad.liberacionSinCodigo) {
														marcarCertificacionSinVerificiacionCelular();
													}
													
													generalService.locationPath("/liberacion");

												}else{
													if(generalService.isCanalExterno($rootScope.sucursalSession.idCanal && $rootScope.sucursalSession.idCanal != CANALES.soriana)){
														$rootScope.message("Inventario de tarjetas",  [ "No hay tarjetas disponibles." ], "Aceptar", null, "bgCafeZ", "cafeZ");
													}else{
														if ( configuracion.origen.tienda ){
															$rootScope.waitLoaderStatus = LOADER_SHOW;
															if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) > -1 )
																$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
															else
																$rootScope.verificarHuella( 'fondoDivId', 'responseVerificarHuellaIpad', [$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico]);
																
														}else{
															if( generalService.isProduccion() ){
																$rootScope.waitLoaderStatus = LOADER_HIDE;
																modalService.huellaModal("bgAzul");
															}else{
																$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
															}
														}														
													}															
												}
												
											}else
												$rootScope.message("Inventario de tarjetas",  [ "Error "+jresponse.inventarioTazResponseJson.codigo+". "+ERROR_SERVICE], "Aceptar", null, "bgCafeZ", "cafeZ");
																														
									}else{
										if($rootScope.flujoSinTAZ){
											if ( configuracion.origen.tienda ){
												$rootScope.waitLoaderStatus = LOADER_SHOW;
												if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) > -1 )
													$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
												else
													$rootScope.verificarHuella( 'fondoDivId', 'responseVerificarHuellaIpad', [$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico]);
													
											}else{
												if( generalService.isProduccion() ){
													$rootScope.waitLoaderStatus = LOADER_HIDE;
													modalService.huellaModal("bgAzul");
												}else{
													$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
												}
											}
										}else
											$rootScope.message("Inventario de tarjetas",  [ "Error:  No se obtuvo información sobre el inventario " ], "Aceptar", null, "bgCafeZ", "cafeZ");
									}
																																												
								}else
									$rootScope.message(titulo, ["Error "+jresponse.solicitudJson.codigo+". "+ERROR_SERVICE], "Aceptar", null, "bgCafeZ", "cafeZ");	
								
							}else
								$rootScope.message(titulo, [generalService.displayMessage(data.data.descripcion)], "Aceptar", null, "bgCafeZ", "cafeZ");
							
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 							
						}
				);
			}
			
		};
		
		$scope.responseVerificarHuellaIpad = function( response ){												
			$rootScope.loggerIpad("responseVerificarHuellaIpad", null, response);
			switch(response.codigo){
				case VALIDA_HUELLA_RESPONSE.EXITO:
					var request = {
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						tarjeta: "1"
					};
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					solicitudService.liberarLCR(request).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var jResponse = JSON.parse(data.data.respuesta);
								if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.liberacionAplicada;
									if($rootScope.solicitudJson.tipoSolicitud == SOLICITUD_REACTIVADO){
										if ($rootScope.solicitudJson.campana == CAMPANAS_REACTIVADOS.invitacion || $rootScope.solicitudJson.campana == CAMPANAS_REACTIVADOS.preaprobados)
											$rootScope.actualizaReactivado($rootScope.solicitudJson.idSolicitud);
										
										if($rootScope.solicitudJson.campana == CAMPANAS_REACTIVADOS.winback)
											generalService.locationPath("/surtimiento");
										else
											generalService.locationPath("/estatus");
										
									}else if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal){ // flujo prestamo personal	
										generalService.locationPath("/surtimiento");
									}else{
										var request = {
												idSolicitud: $rootScope.solicitudJson.idSolicitud
										};
													
										$rootScope.waitLoaderStatus = LOADER_SHOW;
										callCenterService.liberarPedidoSinTAZ( request ).then(
											function(data){
												$rootScope.waitLoaderStatus = LOADER_HIDE;
												if(data.data.codigo == RESPONSE_CODIGO_EXITO){
													var respuesta = JSON.parse(data.data.respuesta);
													if(respuesta.codigo == 2){								/** INICIA_OS-FLUJO COACREDITADO **/
														
														/*\Se agregan eventos para la bitacora\*/
//														(Surtimiento)
												    	$rootScope.addEvent( BITACORA.SECCION.surtimiento.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.surtir.id, 0, BITACORA.SECCION.surtimiento.guardarEnBD );								
														/*\Se agregan eventos para la bitacora\*/
												    	
														if($rootScope.sucursalSession.idCanal == CANALES.soriana || $scope.esObligadoSoldario) {
															$rootScope.solicitudJson = respuesta.data;
															generalService.locationPath("/estatus");
														} else {
															generalService.setDataBridge({origen: FICHA.origen.recuperar });
															if($rootScope.flujoSinTAZ){
																/** Aqui va mensaje intermedio de Felicidades **/
																modalService.liberarPRModal("¡FELICIDADES!", $rootScope.solicitudJson.idProducto ).then(
																		function(exito){
																			generalService.locationPath("/ficha");
																		}, function(error){
																			console.log("Error : " + error);
																});
															}else{
																generalService.locationPath("/ficha");
															}
														}
													}else{
														generalService.locationPath("/estatus");
													}
												} else {
													generalService.locationPath("/estatus");
												}
											}, function(error){
												$rootScope.waitLoaderStatus = LOADER_HIDE;
												generalService.locationPath("/estatus");
											}
										);
									}
								}else{
									generalService.locationPath("/estatus");
								}
							}else{
								generalService.locationPath("/estatus");
							}
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE;
			                generalService.locationPath("/estatus");
						}
					);
					break;
					
				case VALIDA_HUELLA_RESPONSE.ERROR:
					goSimulador();
					break;
					
				case VALIDA_HUELLA_RESPONSE.ERROR_COMPONENTE:
					goSimulador();
					break;
					
				case VALIDA_HUELLA_RESPONSE.COMPONENTE_CANCELADO_PORUSR:
					goSimulador();
					break;
					
				case VALIDA_HUELLA_RESPONSE.NO_SE_ENCONTARON_HUELLAS:
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					modalService.confirmModal("Sin huellas", ["No se encontraron huellas. Infórmale a tu cliente que para continuar con su proceso de crédito es necesario que realice un mantenimiento de biométricos. "], 
			                  "Cancelar", "Aceptar").then(
									  function(exito){	
										  generalService.esValidoFlujoCallCenter($rootScope.solicitudJson);
										  generalService.setArrayValue("pasoCallCenter", 'foto')
										  generalService.setArrayValue("encolarImagenes", false);
										  generalService.locationPath("/callCenter");
										  
									  },function(error){
										  goSimulador();														  														
									  }
								);
					break;
					
				case VALIDA_HUELLA_RESPONSE.NO_HAY_COINCIDENCIAS:
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					if( !generalService.isEmpty($rootScope.solicitudJson.folioCallCenter) && $rootScope.solicitudJson.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.SIN_RESPUESTA)
						generalService.setArrayValue("pasoCallCenter", 'consultaCte')
					else
						generalService.setArrayValue("pasoCallCenter", 'init')
																							
					generalService.esValidoFlujoCallCenter($rootScope.solicitudJson);
					generalService.setArrayValue("encolarImagenes", false);
					generalService.locationPath("/callCenter");	
					break;
					
				default:
					$rootScope.message( "Componete de huella", ["Código "+response.codigo+" no definido. "], "Aceptar");
					goSimulador();
					break;
					
			}				
										
		};
		
		var goSimulador = function(){
			$rootScope.waitLoaderStatus = LOADER_HIDE;	
			generalService.cleanRootScope($rootScope);
			generalService.buildSolicitudJson($rootScope, null );			
			generalService.locationPath("/simulador");
		};
		
		$scope.verificarCanal = function( canal )
		{
			
			if( !generalService.flujoPorDispersion() ){
				var myObject = {
						origen    : FICHA.origen.recuperar
				};							
				generalService.setDataBridge( myObject );
				return  "/ficha";
			}
			
			return "/surtimiento";
			
		};
		
		$scope.capacidadPago_porCanal = function( canal ){
			
			if( !generalService.flujoPorDispersion() ){
//				$rootScope.solicitudJson.cotizacion.pagoPuntual = 0;
				$scope._pagoPuntual=0;
			}
						
		};
		
	    $scope.camelize = function(msn) {
	          // Restore original values
	    	  return generalService.camelize(msn);
	     };
	     
		function loadView(){			
			
			$scope.isTienda = configuracion.origen.tienda; 
			$scope.origen = ($scope.isTienda == true)? "TIENDA":"WEB";
			
			$scope.capacidadPago_porCanal( $rootScope.sucursalSession.idCanal );
			
			$scope.diaSemana = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.CREDITO.CATDIASSEMANA"];									
			$scope.labelTitulo = generalService.getDataInput("CREDITO","TITULO",$scope.origen );
			$scope.CPsemanal = generalService.getDataInput("CREDITO","ETIQUETACPS",$scope.origen );
			$scope.labelDiaPago = generalService.getDataInput("CREDITO","ETIQUETADIAPAGO",$scope.origen );			
			$scope.labelTotal = generalService.getDataInput("CREDITO","ETIQUETATOTAL",$scope.origen );
			$scope.labelOcupado = generalService.getDataInput("CREDITO","ETIQUETAOCUPADO",$scope.origen );
			$scope.labelPP = generalService.getDataInput("CREDITO","ETIQUETAPP",$scope.origen );
			$scope.labelDisponible = generalService.getDataInput("CREDITO","ETIQUETADISP",$scope.origen );
			$scope.LDC = generalService.getDataInput("CREDITO","ETIQUETALDC",$scope.origen );						
			$scope.selectDiaPago = generalService.getDataInput("CREDITO","SELECT DIA PAGO",$scope.origen );						
			$scope.btnLiberacion = generalService.getDataInput("CREDITO","BOTON LIBERAR",$scope.origen );
			$scope.informaleCliente = generalService.getDataInput("CREDITO","ETIQUETA1",$scope.origen );
			$scope.informaleCliente.texto = $scope.informaleCliente.texto.replace(/\\/g,'');
/** I-MODIFICACION TDC (LEYENDAS TDC)*/															
			$scope.informaleClienteTDC = generalService.getDataInput("CREDITO","ETIQUETA1",$scope.origen );
			$scope.informaleClienteTDC.texto = $scope.informaleCliente.texto.replace(/\\/g,'');
/** F-MODIFICACION TDC (LEYENDAS TDC)	*/											
		}
		
		function continuarCargaVista(){
			/**
			 * Se agrega la consulta de día de pago para reactivados
			 * */
			if($scope.consultarDiaPagoReactivado())
				$scope.consultaDiaPago();
			else{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.showPage = true;
			}
		};
		
/** I-MODIFICACION TDC*/												
		$scope.continuar = function(){
			generalService.locationPath("/ochoPasos");	
		}
/** F-MODIFICACION TDC*/												
			
		/**
		 * Consulta dia de pago
		 * */
		$scope.consultaDiaPago = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			var jsonRequest =  {
					"clienteUnico": $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
					"tienda": $rootScope.solicitudJson.idSucursal
					};
			solicitudService.obtenerDiaDePago(jsonRequest).then(
	 			function(data){
	 				$rootScope.waitLoaderStatus = LOADER_HIDE;
	 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){		 						 						 					
	 					var responseJson = JSON.parse(data.data.respuesta);
	 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
	 						var diaPagoTienda = responseJson.data;
	 						if(!generalService.isEmpty(diaPagoTienda)){
	 							$scope.mostrarDiaPagoReactivado=true;
	 							$scope.diaPago=diaPagoTienda;
	 						}
	 						$scope.showPage = true;
						}else
							$rootScope.message("Consulta Día de Pago",  [ "No se pudo consultar correctamente el día de pago." ], "Aceptar", "/ochoPasos", "bgCafeZ", "cafeZ");
	 				}
	 			}, function(error){  
	 				$rootScope.waitLoaderStatus = LOADER_HIDE;
	 			}	
			);
		}
	});
		
});



