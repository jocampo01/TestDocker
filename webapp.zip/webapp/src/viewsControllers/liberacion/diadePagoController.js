'use strict';

define(["app"], function (app) {
//controlador para huellaModalview	 

	app.controller('diadePagoController', function(  $rootScope, $scope, ngDialog, $location, messageData, $timeout,validateService, generalService, modalService, tarjetaService, solicitudService, callCenterService, buroService){
		
		
		var titulo = "Día de Pago";
		$scope.descCatalog = new Object();
		$scope.msjSeleccionar = "";
		$scope.resCon={};
		$scope.resCon.capacidadPago = 0;
		$scope.mostrarDiaPagoReactivado=false;
		
		$scope.MaysPrimera = function (string) {
			  return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
			}
		

		$scope.consultarDiaPagoReactivado = function(){
			if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto) || $rootScope.solicitudJson.tipoSolicitud == SOLICITUD_REACTIVADO){
				return true;
			}else
				return false;
		}
		
		function loadView(){
			
			$scope.isTienda = configuracion.origen.tienda; 
			$scope.origen = ($scope.isTienda == true)? "TIENDA":"WEB";
			
			$scope.diaSemana = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.CREDITO.CATDIASSEMANA"];
			$scope.labelDiaPago = generalService.getDataInput("CREDITO","ETIQUETADIAPAGO",$scope.origen );			
			$scope.selectDiaPago = generalService.getDataInput("CREDITO","SELECT DIA PAGO",$scope.origen );		
			$scope.btnLiberacion = generalService.getDataInput("CREDITO","BOTON LIBERAR",$scope.origen );
			$scope.labelTitulo = generalService.getDataInput("CREDITO","TITULO",$scope.origen );
			
			$scope.CPsemanal = generalService.getDataInput("CREDITO","ETIQUETACPS",$scope.origen );			
			$scope.labelTotal = generalService.getDataInput("CREDITO","ETIQUETATOTAL",$scope.origen );
			$scope.labelOcupado = generalService.getDataInput("CREDITO","ETIQUETAOCUPADO",$scope.origen );
			$scope.labelPP = generalService.getDataInput("CREDITO","ETIQUETAPP",$scope.origen );
			$scope.labelDisponible = generalService.getDataInput("CREDITO","ETIQUETADISP",$scope.origen );
			
			$scope.msjSeleccionar = "En caso de ser autorizado el crédito, " +  $scope.labelDiaPago.texto.toLowerCase();
											
			if($scope.consultarDiaPagoReactivado())
				$scope.consultaDiaPago();
			else
				muestraVista();
		};
		
		$scope.consultaDiaPago = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			var jsonRequest =  {
					"clienteUnico": $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
					"tienda": $rootScope.solicitudJson.idSucursal
					};
			solicitudService.obtenerDiaDePago(jsonRequest).then(
	 			function(data){
	 				$rootScope.waitLoaderStatus = LOADER_HIDE;
	 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){		 						 						 					
	 					var responseJson = JSON.parse(data.data.respuesta);
	 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
	 						var diaPagoTienda = responseJson.data;
	 						if(!generalService.isEmpty(diaPagoTienda)){
	 							$scope.mostrarDiaPagoReactivado=true;
	 							$rootScope.solicitudJson.diaPago=diaPagoTienda;
	 						}
	 						muestraVista();
						}else
							$rootScope.message(titulo, ["Error al consultar el día de pago"], "Aceptar", "/ochoPasos", "bgCafeZ", "cafeZ", null, "CREDITO", null);
	 				}else
	 					$rootScope.message(titulo, ["Error inesperado en el servicio(DÍA DE PAGO), favor de reintentar"], "Aceptar", "/ochoPasos", "bgCafeZ", "cafeZ", null, "CREDITO", null);
	 			}, function(error){
	 				$rootScope.message(titulo, ["Error inesperado en el servicio(DÍA DE PAGO), favor de reintentar"], "Aceptar", "/ochoPasos", "bgCafeZ", "cafeZ", null, "CREDITO", null);
	 				$rootScope.waitLoaderStatus = LOADER_HIDE;
	 			}	
			);
		}
		
		$scope.init = function()
		{
			/*\Se agrega un evento para la bitacora\*/
			//(dia De Pago)
				$rootScope.addEvent( BITACORA.SECCION.diaDePago.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, 0, BITACORA.SECCION.diaDePago.guardarEnBD );
				
			/*\Se agrega un evento para la bitacora\*/
			$scope.showPage = false;
			$scope.hideRegresa = false;
			generalService.setArrayValue("sourcePath", "/ochoPasos");
			
			var productos = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.CATALOGO PRODUCTOS"];						
			$scope.descCatalog = generalService.getProductosCredito(productos, ID_PRODUCTOS);
			buroService.resultadoConsulta($rootScope.solicitudJson.idSolicitud,$rootScope).then(
					function(objRes){								
						$scope.datosCredito = objRes.datosCredito;
						$scope.resCon= objRes.resConsulta;	
						
						if ($rootScope.solicitudJson.idCanal == CANALES.elektra && 
								($rootScope.solicitudJson.idProducto==ID_PRODUCTO.italika||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.telefonia||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.consumo))
							$scope.resCon.pedidos[0].saldoPedido=0;
						
						if ($rootScope.solicitudJson.idCanal == CANALES.elektra && 
								($rootScope.solicitudJson.idProducto==ID_PRODUCTO.italika||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.telefonia||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.consumo))
							$scope.resCon.ocupado = 0;

						if ($rootScope.solicitudJson.idCanal == CANALES.elektra && 
								($rootScope.solicitudJson.idProducto==ID_PRODUCTO.italika||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.telefonia||$rootScope.solicitudJson.idProducto==ID_PRODUCTO.consumo))
							$scope.resCon.disponible = $scope.resCon.capacidadPago;

						/**
						 * Cambiar la bandera muestraCapacidadConsumo a true tambien cuando es canal soriana
						 */
						if(($rootScope.solicitudJson.idProducto == ID_PRODUCTO.consumo || $rootScope.solicitudJson.idProducto == ID_PRODUCTO.italika) && ($rootScope.sucursalSession.idCanal == CANALES.elektra || $rootScope.sucursalSession.idCanal == CANALES.soriana)){
							$scope.muestraCapacidadConsumo = true;
							var capacidadesCliente = obtenerCapacidadesPrestamoyProducto($rootScope.capacidadesPagoProducto);
							if($rootScope.solicitudJson.banderaIngresos == 1){
								$scope.montoOferta30DiasCP = capacidadesCliente.prestamoPersonal.capacidadPagoComprobable;
								$scope.montoOferta30DiasCC = capacidadesCliente.consumo.capacidadPagoComprobable;
							}else{
								$scope.montoOferta30DiasCP = capacidadesCliente.prestamoPersonal.capacidadPagoNoComprobable;
								$scope.montoOferta30DiasCC = capacidadesCliente.consumo.capacidadPagoNoComprobable;
							}
						}
						loadView();
								
					}, function(error){
						$rootScope.message(titulo, [error], "Aceptar", null, "bgCafeZ", "cafeZ");
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 								
					}
			);
		}
		
		function muestraVista(){
			$timeout(function(){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$scope.showPage = true;
			}, 1);	
		}
		
		function obtenerCapacidadesPrestamoyProducto(capacidadesPagoProducto){
    		var capacidadesOferta30Dias={
    			prestamoPersonal:{
				capacidadPagoComprobable:0,
				capacidadPagoNoComprobable:0
			},
			consumo:{
				capacidadPagoComprobable:0,
				capacidadPagoNoComprobable:0
			}
		}
    	
    		for(var i=0; i< capacidadesPagoProducto.length;i++){
			if(capacidadesPagoProducto[i].producto == PRODUCTOS.prestamoPersonal.ID.valor){
				capacidadesOferta30Dias.prestamoPersonal.capacidadPagoComprobable   = capacidadesPagoProducto[i].capacidadPagoComprobable;
				capacidadesOferta30Dias.prestamoPersonal.capacidadPagoNoComprobable = capacidadesPagoProducto[i].capacidadPagoNoComprobable;
			}
			
			if($rootScope.solicitudJson.idProducto == $rootScope.capacidadesPagoProducto[i].producto){
				capacidadesOferta30Dias.consumo.capacidadPagoComprobable   = capacidadesPagoProducto[i].capacidadPagoComprobable;
				capacidadesOferta30Dias.consumo.capacidadPagoNoComprobable = capacidadesPagoProducto[i].capacidadPagoNoComprobable;
			}
		}
    		
    		return capacidadesOferta30Dias;
    }
		
		var listadoCuentas = function(){
			tarjetaService.consultaCteAlnova($rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if (jsonResponse.codigo == TARJETA_WS_EXITO) {
							var cuentasData = jsonResponse.data;
							$scope.vaciarListaCuentas(cuentasData.consultaCuentasList);

							if ($scope.existeGuardadito) {
								$scope.manejador = "deposito";
							}else{
								$rootScope.guardaDatosIpad("IdSolicitudRecuperar",$rootScope.solicitudJson.idSolicitud);
								
								if(configuracion.so.windows){
									window.location.assign(PORTAL_CAPTACION+'#/Credito=' + $rootScope.solicitudJson.idSolicitud	+ "X");
								}else{
									$rootScope.executeAction( "surtimiento", "respuestaCaptacion", {nombre:"reLoadWebViewCaptacion"} );
								}
								
								$scope.ejecutaGuardadito=true;
							}
						} else {
							$rootScope.message("Error",[ jsonResponse.descripcion ],"Aceptar",null,"bgCafeZ","cafeZ");
							$scope.manejador = "principal";
						}
					} else
						$rootScope.message("Error", [generalService.displayMessage(data.data.descripcion)], "Aceptar", null, "bgCafeZ", "cafeZ");
				},
				function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
				});

		};
		
		$scope.guardarDiaPagoNvoFlujoLiberacion = function(){
			/*\Se agrega un evento para la bitacora\*/
			//(dia De Pago)
				$rootScope.addEvent( BITACORA.SECCION.diaDePago.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.guardar.id, 0, BITACORA.SECCION.diaDePago.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
			
			if( generalService.isEmpty($rootScope.solicitudJson.diaPago)){
				$rootScope.message(titulo, ["Selecciona el día que el cliente desea realizar sus pagos."], "Aceptar", null, "bgCafeZ", "cafeZ", null, "CREDITO", "DIA PAGO");
			}
			else{
				
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				solicitudService.guardarDiaPago( { idSolicitud: $rootScope.solicitudJson.idSolicitud, dia: $rootScope.solicitudJson.diaPago  } ).then(

						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								
								var jsonRespuesta = JSON.parse(data.data.respuesta.solicitudJson);
								
								if(jsonRespuesta.codigo == 2){
									//actualizamos JSON
									$rootScope.solicitudJson = jsonRespuesta.data;
									//redireccionamos al surtimiento
									if($rootScope.solicitudJson.idProducto == 24)
										generalService.locationPath("/cuentasGuardadito");
									else
										generalService.locationPath(generalService.whichOneVisit(0));
									
								}
								else{ //else del if(jsonRespuesta.codigo == 2)
									$rootScope.message(titulo, ["Error inesperado en el servicio, favor de reintentar"], "Aceptar", null, "bgCafeZ", "cafeZ", null, "CREDITO", null);
								}
								
							}
							else{ //else del if(data.data.codigo == RESPONSE_CODIGO_EXITO)
								var e = "Error";
								$rootScope.message(titulo, ["Error al guardar día de pago, favor de reintentar"], "Aceptar", null, "bgCafeZ", "cafeZ", null, "CREDITO", null);

							}
							
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 		
			                $rootScope.message(titulo, ["Error al guardar día de pago, favor de reintentar"], "Aceptar", null, "bgCafeZ", "cafeZ", null, "CREDITO", null);
						}
				
				);
				
			} //termina else de generalService.isEmpty($rootScope.solicitudJson.diaPago)
			
		};	//termina funcion guardarDiaPagoNvoFlujoLiberacion
 	
	});

	
	app.filter('primeraMayus', function(){
			return  function (string) {
		    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
			}
		} 			
	);
	
});