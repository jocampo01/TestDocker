'use strict';

define(["app"], function (app) {
	
	app.controller('liberacionController', function(  $rootScope, $scope, ngDialog, $location, messageData, $timeout,validateService, generalService, modalService, tarjetaService, solicitudService, callCenterService, clienteUnicoService){
		
		
//		$scope.validarCanal = function(canalActual){
//			return generalService.isCanalInterno(canalActual);
//			var banderaCanalesGS = false;
//			angular.forEach(CANALESGS, function(value, key) {
//				if(value == canalActual){
//					banderaCanalesGS = true;
//				}
//			});
//			return banderaCanalesGS;
//			
//		}
		$scope.ejecutarFolioFlujoUnico=true;
		$scope.confTipoWindows = configuracion.so.windows;
		var vozIpadCte = null;
		var vozIpadEjecutivo = null;
		$scope.disponible = 0;
		$scope.capacidadPago = 0;
		$scope.tarjetaNueva = {};
		$scope.tarjetaNueva = {valor:""};
		$scope.numtarjeta = {};
		$scope.numtarjeta = {numTAZ:""};
		$scope.flujoLiberacion={};
		$scope.flujoLiberacion={
				viejo: false,
				soriana: false,
				folioUnico: false,
// I-MODIFICACION TDC (SE AGREGA FLUJO TDC)
				bazDigital: false,
				TDC: false
// F-MODIFICACION TDC (SE AGREGA FLUJO TDC)
		};
		$scope.capturaTarjetas=true;
		$scope.existenTarjetas=false;
		$scope.btnFlujoLiberacion="Activar";
		$scope.modalSeleccionTAZ = true;
		switch(true){
			case $rootScope.sucursalSession.idCanal == CANALES.soriana:
				console.log("FLUJO SORIANA")
				$scope.flujoLiberacion.soriana=true;
				break;
			case $rootScope.solicitudJson.idPlataforma == 6:
				console.log("FLUJO BAZ DIGITAL")
				$scope.btnFlujoLiberacion="Entregar";
				$scope.flujoLiberacion.bazDigital=true;
				break;
// I-MODIFICACION TDC (SE AGREGA FLUJO TDC)			
			case generalService.isCanalInterno($rootScope.sucursalSession.idCanal) && FLUJO_FOLIO_UNICO && $rootScope.solicitudJson.idPlataforma != 6 && !$rootScope.productosTarjetas($rootScope.solicitudJson.idProducto):				
// F-MODIFICACION TDC (SE AGREGA FLUJO TDC)
				console.log("FLUJO FOLIO UNICO")
				$scope.btnFlujoLiberacion="Entregar";
				$scope.flujoLiberacion.folioUnico=true;
				break;
// I-MODIFICACION TDC (SE AGREGA FLUJO TDC)			
			case generalService.isCanalInterno($rootScope.sucursalSession.idCanal) && FLUJO_FOLIO_UNICO && $rootScope.solicitudJson.idPlataforma != 6 && $rootScope.productosTarjetas($rootScope.solicitudJson.idProducto):				
				console.log("FLUJO TDC")
				$scope.btnFlujoLiberacion="Entregar";
				$scope.flujoLiberacion.TDC = true;
				break;
// F-MODIFICACION TDC (SE AGREGA FLUJO TDC)
			default:				
				console.log("FLUJO VIEJO")
				$scope.flujoLiberacion.viejo=true;				
				break;
		};
		$scope.capturando=false;
		$scope.huellaValida=false;
		var codigoBarras={
				valeItalika:1,
				tarjetaAzteca:2
		};
		
		$scope.init = function(){
			
			/*\Se agregan eventos para la bitacora\*/
//			(Surtimiento) ¿Credito Inmediato?
			$rootScope.addEvent( BITACORA.SECCION.surtimiento.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, 0, BITACORA.SECCION.surtimiento.guardarEnBD );								
			/*\Se agregan eventos para la bitacora\*/
			
			if( ( $rootScope.userSession.idPerfil == PUESTO_GERENTE && $rootScope.userSession.idPuesto == PUESTO_GERENTE ) 
					|| ( $rootScope.userSession.idPerfil == PUESTO_GERENTE_VENTAS_CREDITO && $rootScope.userSession.idPuesto == PUESTO_GERENTE_VENTAS_CREDITO )
					|| ( $rootScope.userSession.idPerfil == PUESTO_EJECUTIVO && $rootScope.userSession.idPuesto == PUESTO_EJECUTIVO )
					|| ( $rootScope.userSession.idPerfil == ASESOR_DE_NEGOCIOS && $rootScope.userSession.idPuesto == ASESOR_DE_NEGOCIOS )
					|| ( $rootScope.userSession.idPerfil == PUESTO_ASESOR_CREDITO && $rootScope.userSession.idPuesto == PUESTO_ASESOR_CREDITO )
				  ){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if( messageData  ){					
					if( generalService.existeSolicitud( $rootScope.solicitudJson ) ){

						/** Flujo TAZ como producto **/
						if($rootScope.solicitudJson.idProducto == PRODUCTOS.tarjetaAzteca.ID.valor){
							
								if($rootScope.solicitudJson.tipoSolicitud == SOLICITUD_REACTIVADO
										&& generalService.isEmpty($rootScope.solicitudJson.folioFlujoUnico)
											&& !generalService.isEmpty($rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico)){
								/** Se consulta si el cliente Reactivado tiene una TAZ, si tiene en automatico se manda a cancelar, si no unicamente mostramos un mensaje **/	
									var cu = {
							    			clienteUnico: $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico 			
							    	};
									$rootScope.waitLoaderStatus = LOADER_SHOW;
									tarjetaService.consultarCancelarTAZ(cu).then(
										function(data){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											if(data.data.codigo == RESPONSE_CODIGO_EXITO){
												var j = JSON.parse(data.data.respuesta);
												
												if(j.codigo == 2){
													/** Si el cliente no tiene TAZ o la TAZ fue cancelada correctamente, procedemos a revisar el inventario **/
													//modalService.alertModal("Aviso", [JSON.stringify(j.data)]);
													consultarrInventarioTAZ();
												}else{
													$rootScope.message("Error", [generalService.displayMessage(j.descripcion)],"Aceptar","/ochoPasos","bgCafeZ", "cafeZ");
												}
											}else
												$rootScope.message("Error", [generalService.displayMessage(data.data.descripcion)],"Aceptar","/ochoPasos","bgCafeZ", "cafeZ");
										}, function(error){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$rootScope.message("Error", [generalService.displayMessage(data.data.descripcion)],"Aceptar","/ochoPasos","bgCafeZ", "cafeZ");
										}
									);
								
								}else{
									consultarrInventarioTAZ();
								}
						}else{
							loadView();
						}
						
						$scope.showPage = messageData;
						$timeout( function(){
							$("#owl-demo").owlCarousel({
								autoPlay: 5000,
								singleItem: true,
								pagination: true
							});
						},0);
					}else
						$rootScope.message(SIN_SOLICITUD.titulo, [SIN_SOLICITUD.texto], "Aceptar", "/", "bgCafeZ","cafeZ");
				}else
					$rootScope.message(ERROR_CARGA_PAGINA.titulo, [ERROR_CARGA_PAGINA.texto], "Aceptar", "/", "bgAzul","cafeZ");
			}else{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("Liberación de Tarjeta", ["El proceso de entrega de tarjeta lo debe realizar el gerente, sub gerente o asesor de servicios financieros.","Por favor, solicita su apoyo para continuar con la liberación de tu cliente."], "Aceptar", "/", "bgAzulD","AZULD");
			}
		};
		
		/** Revisamos que existan Tarjetas en el iventario, si no hay mostramos mensaje, rediriggimos y ocultamos la seccion**/
		function consultarrInventarioTAZ(){
			
			var x = {sucursal: $rootScope.sucursalSession.idSucursal,opcion: "01"};
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			tarjetaService.consultaInventarioTAZ(x).then(
		 			function(data){
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){		 						 						 					
		 					var responseJson = JSON.parse(data.data.respuesta);
		 					if( responseJson == true ){
		 						loadView();
							}else{
								$rootScope.mostrarSeccionTAZ = false;
								$rootScope.message("Aviso", ["Inventario Agotado de Tarjeta Azteca en Sucursal","Infórmale a tu cliente que puede regresar por su tarjeta azteca en 5 a 7 días hábiles.",
																" Por lo pronto, invítalo a adquirir con su capacidad de pago alguno de los siguientes productos que le ofrece Banco Azteca:", 
																"Préstamos personales","Consumo Elektra","Telefonía Elektra","Italika"],"Aceptar","/ochoPasos","bgCafeZ", "cafeZ");
							}
		 				}
		 			}, function(error){
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				$rootScope.message("Error", [generalService.displayMessage(data.data.descripcion)],"Aceptar","/simulador","bgCafeZ", "cafeZ");
		 			}	
				);
			
		}
		
		function loadView(){						
			$scope.isTienda = configuracion.origen.tienda; 
			$scope.origen = ($scope.isTienda == true)? "TIENDA":"WEB";
			$scope.labelTitulo = generalService.getDataInput("LIBERACION","TITULO",$scope.origen );
			$scope.btnFotoTaz = generalService.getDataInput("LIBERACION","BOTON FOTOTAZ",$scope.origen );
			if(configuracion.so.windows)
				$scope.btnFotoTaz.texto="Deslizar la tarjeta";
			$scope.labelBeneficios = generalService.getDataInput("LIBERACION","ETIQUETA BENEFICIOS",$scope.origen );			
			$scope.labelFotoTaz = generalService.getDataInput("LIBERACION","ETIQUETA FOTOTAZ",$scope.origen );
			$scope.inputTaz = generalService.getDataInput("LIBERACION","INPUT TARJETA",$scope.origen );
			$scope.inputTaz.longMax = "19";
			$scope.inputTaz.longMin = "0";
			$scope.inputTaz.formato = "T";
			$scope.labelNumtaz = generalService.getDataInput("LIBERACION","ETIQUETA NUMTAZ",$scope.origen );
			vozIpadCte = generalService.getDataInput("LIBERACION","ETIQUETA VOZ  IPDA CTE",$scope.origen ); 
			vozIpadEjecutivo = generalService.getDataInput("LIBERACION","ETIQUETA VOZ  IPDA EJECUTIVO",$scope.origen );
			
			/**
			 * En el front se muestran los beneficios de la tarjeta azteca solo para el flujo de la NOC (Cliente nuevo)
			 **/
			$scope.beneficios = [
				{VALOR : {valor :"Por ser cliente de crédito de Banco Azteca obtén tu Tarjeta Azteca sin costos ni comisiones adicionales por su recepción." },VISIBLE : {valor : true}},
				{VALOR : {valor :"Compra con ella en cualquier lugar del mundo en donde acepten tarjetas como medio de pago."},VISIBLE : {valor : true}},
				{VALOR : {valor :"Por cada Peso de capacidad de pago semanal puedes comprar $45 (por ejemplo, si tu capacidad de pago semanal es de $100, podrías comprar hasta $4,500 en cualquier comercio)" },VISIBLE : {valor : true}},
				{VALOR : {valor :"Recibe 10% de bonificación en tu primera compra (compra mínima $700)*" },VISIBLE : {valor : true}},
				{VALOR : {valor :"Retira efectivo en cajeros automáticos y tiendas de autoservicio**" },VISIBLE : {valor : true}},
				{VALOR : {valor :"La fecha y lugar de pago es la misma que los otros movimientos de tu línea de crédito." },VISIBLE : {valor : true}}
			]
			
			/**
			 * En el front se muestran los terminos y condiciones de la tarjeta azteca solo para el flujo de la NOC (Cliente nuevo)
			 **/
			$scope.terminosCondiciones = [
				{VALOR : {valor :"*Consulta términos y condiciones en www.bancoazteca.com.mx" },VISIBLE : {valor : $rootScope.solicitudJson.idProducto != ID_PRODUCTO.tarjetaCreditoTEC?true:false}},
				{VALOR : {valor :"**En cajeros automáticos hasta $6,000" },VISIBLE : {valor : $rootScope.solicitudJson.idProducto != ID_PRODUCTO.tarjetaCreditoTEC?true:false}}
			]
			
			
			$scope.listaBeneficios=["0% de interés si pagas antes de 14 días","Compra donde quieras y haz retiros de hasta $5,000 pesos",
			                        "Bonificación de hasta 10% en tu primer compra a crédito","Con pago puntual paga menos",
			                        "Sin comisión ni anualidad","Opción de 2 tarjetas adicionales sin costo"];
// I-MODIFICACION TDC (LISTA DE BENEFICIOS TDC)		
			if( $rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
				$scope.beneficios = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.LIBERACION.LISTA BENEFICIOS TARJETA"];
				if ($rootScope.solicitudJson.idProducto == ID_PRODUCTO.tarjetaCreditoEKT){
					$scope.beneficios=[{VALOR:{valor:"Programa de Lealtad Elektrapuntos acumulables: 30% sobre el total de tus compras del mes en Elektra y 10% en otros comercios"}, VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}},
					                   {VALOR:{valor:"20% de reembolso sobre el monto de tu primera compra (Topado a $500 pesos)."}},
					                   {VALOR:{valor:"Sin anualidad (Usa tu tarjeta al menos una vez al mes en compras y/o disposiciones y evita el cobro de $70 mensuales/comisión por no uso)."},VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}},
					                   {VALOR:{valor:"Seguros gratis (protección de precios y compras)."},VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}},
					                   {VALOR:{valor:"Pagos mensuales, puedes pagar el mínimo o el total de tu saldo para no generar intereses."},VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}},
					                   {VALOR:{valor:"Consulta Términos y Condiciones en www.bancoazteca.com.mx"},VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}}]
				}
				$scope.labelBeneficios.texto = "Explicale a tu solicitante los beneficios de la Tarjeta de Crédito " + $rootScope.camelize($rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc);
				
				if ($rootScope.solicitudJson.idProducto == ID_PRODUCTO.tarjetaCreditoTEC){
					$scope.beneficios=[{VALOR:{valor:"Sin pago de comisión si la usas por lo menos una vez al mes"}, VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}},
					                   {VALOR:{valor:"Puedes solicitar la domiciliación del pago mínimo o pago para no generar intereses de tu tarjeta con cargo a tu cuenta de Banco Azteca"}, VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}},
					                   {VALOR:{valor:"Puedes comprar a meses sin intereses"},VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}},
					                   {VALOR:{valor:"Disposición de efectivo hasta el 50% de tu límite de crédito"},VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}},
					                   {VALOR:{valor:"Aceptación Nacional e Internacional"},VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}},
					                   {VALOR:{valor:"Consulta Términos y Condiciones en www.bancoazteca.com.mx"},VISIBLE:{descripcion:"VISIBLE", id:124, idParametroLista:211, nombre:"VISIBLE", registro:1, valor:true}}];
					$scope.labelBeneficios.texto = "Explicale a tu solicitante los beneficios de la " + $rootScope.camelize($rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc);
				}
				
				if ($scope.confTipoWindows){
					$scope.dialogoEntregaTarjeta();
				}
			}
// F-MODIFICACION TDC (LISTA DE BENEFICIOS TDC)	
			if($rootScope.solicitudJson.idProducto==PRODUCTOS.tarjetaAzteca.ID.valor){
				$scope.labelBeneficios.visible = false;
			}
		};
			
		$scope.capturarTarjeta = function(){
			$scope.capturando=true;
			$scope.activar=false;
			$scope.numtarjeta.numTAZ="";
			switch(true){
				case $scope.confTipoWindows:
					$scope.dialogoTarjeta();
					break;
				case configuracion.origen.tienda:
					$scope.objetoOCR = {};
					/*
					 * Llamada al nuevo OCR
					 */
					if($scope.modalSeleccionTAZ){
						$scope.seleccionarTipoTarjeta();
					}else{
						$rootScope.executeAction( "liberacion", "respuestaCamaraTaz", {
							nombre:"leerTarjetaAzteca", 
							tipoTAZ: "numeroAtras"
						});
					}
					break;
			}
		};
		
		$scope.seleccionarTipoTarjeta = function(){
			ngDialog.openConfirm({
				template: 'src/viewsControllers/liberacion/tipoTarjetaView.html',
				controller: ['$scope', function($scope){
					$scope.init = function(images){
						imagenes = images;
					}
					
					$scope.confirmar = function() {
 						try {
 							// Se obtienen los elementos con la clase.
	 						var elementos = $(".owl-item");
	 						
	 						// Este será el índice de la credencial seleccionada, en el arreglo de credenciales.
	 						var selectedIndex; 
	 						
	 						// Se recorre el arreglo de elementos.
	 						for(var i in elementos) {
	 							// El elemento actual contiene la clase "active", es decir, es la seleccionada.
	 							if(elementos[i].classList.contains("active")) {
	 								// Se obtiene el valor del atributo "id", que es su índice en el arreglo.
	 								selectedIndex = parseInt(elementos[i].firstChild.attributes["id"].value);
	 								
	 								break;
	 							}
	 						}
	 						if(!isNaN(selectedIndex)){
	 							$rootScope.tipoTarjeta = (selectedIndex == 0) ? "numeroFrente" : "numeroAtras";
	 						}
 						} catch(x) {
 							console.log("No se pudo encontrar una clase active.");
 						}
 						
 						// Se cierra el modal, de manera "correcta".
 						$scope.confirm();
 					}
				}],
				data: {
 					title: "Tipo de Tarjeta", 
 					estiloTitulo: "cafeZ"
 				}
			}).then(
				function(success){
					//Ejecuta el componente para la tarjeta clasica y la nueva
					if($rootScope.tipoTarjeta != null){
						$rootScope.executeAction( "liberacion", "respuestaCamaraTaz", {
							nombre:"leerTarjetaAzteca", 
							tipoTAZ: $rootScope.tipoTarjeta
						});
					}else{
						modalService.alertModal( "Error componente", ["No se selecciono el tipo de Tarjeta"], "Aceptar", "bgCafeZ", "cafeZ");
					}
				}, function(reject){
					console.log("Se cancelo");
				}
				
			);
		};
		
		$scope.dialogoTarjeta = function(){
			modalService.deslizaTarjeta("bgCafeZ", "cafeZ").then(
				function(data){
					if(data)
						$scope.mueveNumTarjeta(data);
				},function(error){
					modalService.alertModal( "Error componente", ["No se pudo obtener el Número de Tarjeta"], "Aceptar", "bgCafeZ", "cafeZ");
				}
			);
		}
// I-MODIFICACION TDC 	
		$scope.dialogoEntregaTarjeta = function(){
			modalService.entregaTarjeta("bgCafeZ", "cafeZ").then(
				function(data){
					$scope.capturarTarjeta();
				},function(error){
					$scope.capturarTarjeta();
				}
			);
		}
// F-MODIFICACION TDC 
		
		$scope.respuestaCamara = function( data ){
			$rootScope.loggerIpad("respuestaCamara", null, data);
			/*
			 * Response Objects:
			 * #codigo: 0,1,2
			 * #mensaje: Descripcion del mensaje de error
			 * #nombre: Nombre del archivo
			 * #imagenReverso: imagen B64
			 * #numeroTarjeta: numero de la tarjeta
			 * #estaFirmada: bandera que indica si esta firmada
			 * */
			try{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				switch(data.codigo){
					case TARJETA_CAMARA_RESPONSE.EXITO:
						if(data.numeroTarjeta)
							$scope.mueveNumTarjeta(data.numeroTarjeta);
						break;
					case TARJETA_CAMARA_RESPONSE.INTENTOS_SOBRECARGADOS:
						modalService.alertModal( "AVISO", [data.mensaje], "Aceptar", "bgCafeZ", "cafeZ" );
						break;
					default:
						modalService.alertModal( "ERROR", [data.mensaje], "Aceptar", "bgCafeZ", "cafeZ" );
						break;
				}
			}catch(e){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				modalService.alertModal( "Error componente", ["No se pudo obtener el Número de Tarjeta" + e], "Aceptar", "bgCafeZ", "cafeZ");
			}
		};
		
		/*
		 * Respuesta del OCR para capturar la TAZ clasica / nueva
		 */
		$scope.respuestaCamaraTaz = function(data){
			$rootScope.loggerIpad("respuestaCamara", null, data);
			try{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				switch(data.codigo){
					case TARJETA_CAMARA_RESPONSE.EXITO:
						if(data.mensaje)
							$scope.mueveNumTarjeta(data.mensaje);
						break;
					case TARJETA_CAMARA_RESPONSE.INTENTOS_SOBRECARGADOS:
						modalService.alertModal( "AVISO", [data.mensaje], "Aceptar", "bgCafeZ", "cafeZ" );
						break;
					default:
						modalService.alertModal( "ERROR", [data.mensaje], "Aceptar", "bgCafeZ", "cafeZ" );
						break;
				}
			}catch(e){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				modalService.alertModal( "Error componente", ["No se pudo obtener el Número de Tarjeta" + e], "Aceptar", "bgCafeZ", "cafeZ");
			}
		};
		
		$scope.ocrTarjeta = function(opc){
			$scope.objetoOCR = {};
			$scope.tarjetade=opc;
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$rootScope.ocrCodigoQR("liberacion", "respuestaOCR", $scope.objetoOCR );
		};
		
		$scope.respuestaOCR = function( data ){
			$rootScope.loggerIpad("respuestaOCR", null, data);
			try{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				switch(data.codigo){
					case TARJETA_CAMARA_RESPONSE.EXITO:
						$scope.mueveNumTarjeta(data.respuesta)
						break;
					case TARJETA_CAMARA_RESPONSE.INTENTOS_SOBRECARGADOS:
						modalService.alertModal( "AVISO", [data.mensaje], "Aceptar", "bgCafeZ", "cafeZ" );
						break;
					default:
						modalService.alertModal( "ERROR", [data.mensaje], "Aceptar", "bgCafeZ", "cafeZ" );
						break;
				}
			}catch(e){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				modalService.alertModal( "Error componente", ["No se pudo obtener el Código de Tarjeta " + e], "Aceptar", "bgCafeZ", "cafeZ");
			}
		};
		
		$scope.mueveNumTarjeta=function(numTar){
			switch(true){
				case $scope.flujoLiberacion.viejo:
					$scope.numtarjeta.numTAZ = numTar;
					$scope.capturarNIP();
					break;
				case $rootScope.sucursalSession.idCanal == CANALES.soriana:
					$scope.tarjetaNueva.valor = numTar;
					switch($scope.tarjetade){
						case codigoBarras.tarjetaAzteca:
							$scope.capturarNIP();
							break;
					}
					break;
				case $scope.flujoLiberacion.folioUnico:
					$scope.numtarjeta.numTAZ = numTar;
					$scope.validaTarjeta();					
					break;
				case $scope.flujoLiberacion.bazDigital:
					$scope.numtarjeta.numTAZ = numTar;
					$scope.validaTarjeta();					
					break;
// I-MODIFICACION TDC (AGREGAR FLUJO TDC)				
				case $scope.flujoLiberacion.TDC:
					$scope.numtarjeta.numTAZ = numTar;
					$scope.activar=true;
//					$scope.validaTarjeta();					
					break;
// F-MODIFICACION TDC (AGREGAR FLUJO TDC)				
			
			}
		};
	
		$scope.validaTarjeta = function(){
			if ($scope.numtarjeta.numTAZ && $scope.numtarjeta.numTAZ.length == 16)
				$scope.validacionTarjeta();
		};
		
		$scope.validacionTarjeta=function(){
			var r = {
	    			numcta: "",
	    			numcontrato: "",
	    			numtaz: $scope.numtarjeta.numTAZ,
	    			opcion: "3"
	    	};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	tarjetaService.consultaTaz(r).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var jResponse = JSON.parse(data.data.respuesta);
						if(jResponse.codigo == RESPONSE_TARJETA_CODIGO_EXITO){
							if(jResponse.data == TARJETA_PENDIENTE_ENTREGA)
								$scope.activar=true;
							else{
								$scope.numtarjeta.numTAZ="";
								$rootScope.message("Consultar Tarjeta", ["Estatus de la tarjeta inválido"],"Aceptar",null,"bgCafeZ", "cafeZ");
							}
						}else
							$rootScope.message("Consultar Tarjeta", [jResponse.descripcion],"Aceptar",null,"bgCafeZ", "cafeZ");
					}else
						$rootScope.message("Error", [generalService.displayMessage(data.data.descripcion)],"Aceptar",null,"bgCafeZ", "cafeZ",null,"GENERAL", "ERROR GENERAL");
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                $rootScope.message("Liberación", ["Error al consultar estatus de tarjeta Azteca"],"Aceptar",null,"bgCafeZ", "cafeZ",null,"GENERAL", "ERROR GENERAL");
				}
			);
		};
		
		$scope.capturarNIP=function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			if(vozIpadCte != null && vozIpadCte.visible)
				$rootScope.reproducirVoz( "liberacion", "respuestaVozNIP", {"texto": vozIpadCte.texto} );
			else
				$scope.respuestaVozNIP({codigo:0, matches:"sin voz"});
		};
		
		$scope.respuestaVozNIP = function( response ){
			$rootScope.loggerIpad("respuestaVozNIP", null, response);
			try{
				$scope.ingresaNIP();
			}catch(e){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				modalService.alertModal( "Error al reproducir voz", [e], "Aceptar", "bgCafeZ", "cafeZ");
			}									
		};
		
		$scope.ingresaNIP = function(){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			modalService.nipModal().closePromise.then(
				function(exito) {
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					if(vozIpadEjecutivo != null && vozIpadEjecutivo.visible)
						$rootScope.reproducirVoz( "liberacion", "respuestaVozNIPFn", {"texto": vozIpadEjecutivo.texto} );
					else
						$scope.respuestaVozNIPFn({codigo:0, matches:"sin voz"});
				}, function(error) {
					modalService.alertModal( "Captura de NIP", [error], "Aceptar", "bgCafeZ", "cafeZ");
			});
		};
		
		$scope.respuestaVozNIPFn = function( response ){
			$rootScope.loggerIpad("respuestaVozNIPFn", null, response);
			try{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				switch(true){
					case $scope.flujoLiberacion.viejo:
						$scope.activar=true;
						break;
					case $scope.flujoLiberacion.soriana:
						$scope.capturaTarjetas=false;
						break;
				}
			}catch(e){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				modalService.alertModal( "Error al reproducir voz", [e], "Aceptar", "bgCafeZ", "cafeZ");
				
			}									
		};
		
		$scope.validarContratos = function(){
			var hayAcuseTaz = false;
			var contratos = $rootScope.solicitudJson.contratos.contrato;
			for(var i in contratos){
				if(contratos[i].idContrato == FIRMA_ACUSE_TAZ.id){
					if(contratos[i].statusFirma == STATUS_CONTRATO.ENVIAD0 || $scope.envioAcuseTaz)
						hayAcuseTaz = true;
					break;
				}
			}
			if( $rootScope.solicitudJson.idProducto == PRODUCTOS.tarjetaAzteca.ID.valor && generalService.masterFunction() &&
					$rootScope.flujoEsOchoPasos){
				if(!hayAcuseTaz)
					$scope.modalAcuseTaz()
				else
					$rootScope.flujoEsOchoPasos = false;
					generalService.locationPath("/ochoPasos");
			}else
				(hayAcuseTaz)?$scope.liberarLCR():$scope.modalAcuseTaz();
		}
		
		$scope.terminarFlujo=function(){
			if($scope.ejecutarFolioFlujoUnico){
				$scope.ejecutarFolioFlujoUnico=false;
				switch(true){
					case $scope.flujoLiberacion.viejo:
						if ($scope.activar)
							$scope.validarHuella();
						break;
					case $scope.flujoLiberacion.soriana:
						$scope.validarHuella();
						break;
					case $scope.flujoLiberacion.folioUnico:
						if ($scope.activar){
							$scope.validarHuella();
							}
						break;
					case $scope.flujoLiberacion.bazDigital:
						if ($scope.activar)
							$scope.validarHuella();
						break;
		// I-MODIFICACION TDC (AGREGAR FLUJO TDC)							
					case $scope.flujoLiberacion.TDC:
						if ($scope.activar)
							$scope.validarHuella();
						break;
		// F-MODIFICACION TDC (AGREGAR FLUJO TDC)					
				}
			}else if(!generalService.isEmpty($rootScope.solicitudJson.folioFlujoUnico) && $rootScope.solicitudJson.banderaEntregaTAZ == 1)
				$scope.validarContratos();
		};
		
		$scope.validarHuella=function(){
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) > -1 )
				$scope.huellaValida=true;
			if(!$scope.huellaValida){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$rootScope.verificarHuella( 'liberacion', 'responseVerificarHuellaIpad', [$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico]);
			}else
				$scope.ejecutaFlujoFinal();
		}
		
		$scope.responseVerificarHuellaIpad = function( response ){
			$rootScope.loggerIpad("responseVerificarHuellaIpad", null, response);
			try{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				switch(response.codigo){
					case VALIDA_HUELLA_RESPONSE.EXITO:
						$scope.huellaValida=true;
						$scope.ejecutaFlujoFinal();											
						break;
					case VALIDA_HUELLA_RESPONSE.NO_HAY_COINCIDENCIAS:
						modalService.alertModal("Liberación", ["La huella ingresada no coincide con el cliente."], "Aceptar", "bgCafeZ", "cafeZ");
						break;
					default:
						modalService.alertModal( "Error al verificar la huella", [response.mensaje], "Aceptar", "bgCafeZ", "cafeZ");
						break;
				}
			}catch(e){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				modalService.alertModal( "Error al verificar la huella", [e], "Aceptar", "bgCafeZ", "cafeZ");
			}
		};
		
		$scope.ejecutaFlujoFinal=function(){
			switch(true){
				case $scope.flujoLiberacion.viejo:
					$scope.activaTazInstantanea();
					break;
				case $scope.flujoLiberacion.soriana:
					$scope.ligarTarjeta("false");
					break;
				case $scope.flujoLiberacion.folioUnico:					
					ligaFolioUnico();					
					break;
				case $scope.flujoLiberacion.bazDigital:
					$scope.ligarTarjeta("false");
					break;
// I-MODIFICACION TDC (AGREGAR FLUJO TDC)				
				case $scope.flujoLiberacion.TDC:
					$scope.ligarTarjetaTDC();
					break;
// F-MODIFICACION TDC (AGREGAR FLUJO TDC)
			}
		};
		
		$scope.activaTazInstantanea=function(){
			var cu = $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico;								
			var cuArray = cu.split('-');
			var request = {
	    			idSolicitud: $rootScope.solicitudJson.idSolicitud,	    			
	    			cu: {pais:parseInt(cuArray[0]), canal:parseInt(cuArray[1]), sucursal:parseInt(cuArray[2]), folio:parseInt(cuArray[3])},
	    			numCteAlnova: $rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova,
	    			numTaz: $scope.tarjetaNueva.valor,
	    			nip: generalService.getArrayValue('nip')
	    	};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	tarjetaService.activaTazInstantanea( request ).then(
    			function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						if(generalService.isCanalExterno($rootScope.sucursalSession.idCanal))
							$scope.enviarMensaje(false,data.data.respuesta,request);
						else
							$scope.respuetaActivacion(data.data.respuesta,request);
					}else 
						modalService.alertModal("Entrega de tarjeta", [generalService.displayMessage(data.data.descripcion)], "Aceptar", "bgCafeZ", "cafeZ");
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE;
	                $rootScope.modalService.alertModal("Error en servidor", [ERROR_SERVICE], "Aceptar", "bgCafeZ", "cafeZ");
				});
		};
		
		
		var ligaFolioUnico = function(){
			var r = {
					pais: $rootScope.solicitudJson.idPais,
					canal: $rootScope.solicitudJson.idCanal,
					sucursal: $rootScope.solicitudJson.idSucursal,
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					numeroTarjeta: $scope.tarjetaNueva.valor,
					tipoUs: 2	    			
	    		};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.ligaFolioUnico(r).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var jResponse = JSON.parse(data.data.respuesta);
						
						if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							var labanda = false;
							if(jResponse.data){
								if('folioFlujoUnico' in $rootScope.solicitudJson){
									$rootScope.solicitudJson.folioFlujoUnico=jResponse.data;
									$rootScope.solicitudJson.banderaEntregaTAZ=1;
									labanda = true;
								}
							}
							/**
							 * Despues de Ligar La TAZ y Generar Folio Único
							 * Flujo para Liberar la LCR
							 **/
							if( $rootScope.solicitudJson.idProducto == PRODUCTOS.tarjetaAzteca.ID.valor && generalService.masterFunction() &&
									$rootScope.flujoEsOchoPasos){

									if (labanda)
										$scope.modalAcuseTaz()
									else
										$rootScope.message("Ligar Tarjeta", ["Codigo : "+jResponse.codigo, "Aviso: La tarjeta no se ligó forma correcta"],"Aceptar",null,"bgCafeZ", "cafeZ");
								}else
									(labanda)?$scope.modalAcuseTaz():$scope.liberarLCR();
								
						}else if(data.data.codigo == TARJETA_FOLIO_EN_PROCESO){
							$rootScope.message("Ligar Tarjeta", ["Codigo : "+jResponse.codigo, "Aviso: La solicitud esta siendo procesada. Por favor, espere un momento"],"Aceptar",null,"bgCafeZ", "cafeZ");
						}else{
							$rootScope.message("Ligar Tarjeta", ["Codigo : "+jResponse.codigo, "Error: "+jResponse.descripcion],"Aceptar",null,"bgCafeZ", "cafeZ");
						}	
												
					}else
						$rootScope.message("Error", [generalService.displayMessage(data.data.descripcion)],"Aceptar","/simulador","bgCafeZ", "cafeZ");
				}, function(error){
	               $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
					
				}
			);
		};
		
		$scope.liberarLCR = function(){
			var request = {
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					tarjeta: "1"
			};
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.liberarLCR(request).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jResponse = JSON.parse(data.data.respuesta);
							
							if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.liberacionAplicada;
								/**
								 * redireccionar a estatus cuando sean reactivados
								 * */
								if($rootScope.solicitudJson.tipoSolicitud == SOLICITUD_REACTIVADO){
									if ($rootScope.solicitudJson.campana == CAMPANAS_REACTIVADOS.invitacion || $rootScope.solicitudJson.campana == CAMPANAS_REACTIVADOS.preaprobados)
										$rootScope.actualizaReactivado($rootScope.solicitudJson.idSolicitud);
									// Se cambia de /estatus a /surtimiento para dejar surtir a todos los reactivados
									if($rootScope.solicitudJson.campana == CAMPANAS_REACTIVADOS.winback)
										generalService.locationPath("/surtimiento");
									else
										generalService.locationPath("/estatus");
								
								}else if(generalService.flujoPorDispersion()){
									generalService.locationPath("/surtimiento");								
								}else{
									var request = {
										idSolicitud: $rootScope.solicitudJson.idSolicitud
									};
												
									callCenterService.liberarPedidoSinTAZ( request ).then(
										function(data){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											if(data.data.codigo == RESPONSE_CODIGO_EXITO){
												var respuesta = JSON.parse(data.data.respuesta);
												
												if(respuesta.codigo == 2){
													
													/*\Se agregan eventos para la bitacora\*/
//													(Surtimiento)
											    	$rootScope.addEvent( BITACORA.SECCION.surtimiento.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.surtir.id, 0, BITACORA.SECCION.surtimiento.guardarEnBD );								
													/*\Se agregan eventos para la bitacora\*/
											    	
													generalService.setDataBridge({origen: FICHA.origen.recuperar });
													generalService.locationPath("/ficha");
												}else{
													generalService.locationPath("/estatus");
												}
											} else {
												generalService.locationPath("/estatus");
											}
										}, function(error){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
										}
									);
								}
							}else{
								generalService.locationPath("/estatus");
							}
					}else{
						generalService.locationPath("/estatus");
					}
				}
			);
		}
		
		$scope.ligarTarjeta=function(parametro){
			var r = {
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					numeroTarjeta: $scope.tarjetaNueva.valor,
					tipoTarjeta: 42,  //taz verde,
	    			cteUnico: $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
	    			cteAlnova: $rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova,
	    			ligarTarjeta: parametro
	    	};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			tarjetaService.ligar(r).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var jResponse = JSON.parse(data.data.respuesta);
						if(jResponse.codigo == RESPONSE_TARJETA_CODIGO_EXITO){
							$scope.modalAcuseTaz();
							if(generalService.isCanalExterno($rootScope.sucursalSession.idCanal))
								$scope.enviarMensaje(true);
							else
								$scope.continuarFlujo();
						}else{
							$rootScope.message("Ligar Tarjeta", [jResponse.descripcion],"Aceptar",null,"bgCafeZ", "cafeZ",null,"GENERAL", "ERROR GENERAL");
						}						
					}else
						$rootScope.message("Error", [generalService.displayMessage(data.data.descripcion)],"Aceptar",null,"bgCafeZ", "cafeZ",null,"GENERAL", "ERROR GENERAL");
				}, function(error){
	               $rootScope.waitLoaderStatus = LOADER_HIDE; 
	               $rootScope.message("Liberación", ["Error al consultar el servicio de ligar tarjeta."],"Aceptar",null,"bgCafeZ", "cafeZ");
					
				}
			);
		};
		
		$scope.enviarMensaje = function(soriana,respuesta,request){
			var x = {
					celular: $rootScope.solicitudJson.cotizacion.clientes[0].celular					
			}
			solicitudService.envioMensaje( x ).then(
					function(data){
						if(soriana)
							$scope.continuarFlujo()
						else
							$scope.respuetaActivacion(respuesta,request);
					}, function(error){
						if(soriana)
							$scope.continuarFlujo()
						else
							$scope.respuetaActivacion(respuesta,request);
					}
			);
		};
		
		$scope.continuarFlujo=function(){
			switch(true){
				case $scope.flujoLiberacion.soriana:
					//$scope.activaTazInstantanea();
					$scope.getFoliounicoCE();
					break;
				case $scope.flujoLiberacion.folioUnico:
					$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.tazEntregada;
					generalService.locationPath("/datosHogar");
					break;
				case $scope.flujoLiberacion.bazDigital:
					$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.tazEntregada;
					
					if($rootScope.solicitudJson.creditoInmediato==1)
						generalService.locationPath("/datosHogar");
					else
						$scope.dispersarCallCenter();
						
					break;
			}
		};
		
		$scope.verificarCanal = function(  ){
			if(generalService.flujoPorDispersion())
				return "/surtimiento";
			else{
				generalService.setDataBridge({origen: FICHA.origen.recuperar });
				return "/ficha";	
			}
		};
		
		$scope.respuetaActivacion=function(jresponse,request){
			jresponse.jsonResponseLCR = JSON.parse(jresponse.jsonResponseLCR);								
			if(jresponse.jsonResponseLCR.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
				jresponse.jsonResponseActivacion = JSON.parse(jresponse.jsonResponseActivacion);									
				try{
					if(jresponse.jsonResponseActivacion.codigo == RESPONSE_TARJETA_CODIGO_EXITO){
						jresponse.jsonResponseUpdStatus = JSON.parse(jresponse.jsonResponseUpdStatus);
						var flujoPorCanal = $scope.verificarCanal();
						if(jresponse.jsonResponseUpdStatus.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.tazActivada;
							if( request.nip!=undefined  &&  !generalService.isEmpty(request.nip) ){
								jresponse.jsonResponseNIP = JSON.parse(jresponse.jsonResponseNIP);
								if(jresponse.jsonResponseNIP.codigo != RESPONSE_TARJETA_CODIGO_EXITO)
									$rootScope.message("NIP", ["La tarjeta fue activada exitosamente pero hubo un error al registrar el NIP, coméntale al cliente que " +
									                           "lo puede registrar posteriormente."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
								else{
									$scope.capacidadPago = ($rootScope.solicitudJson.banderaIngresos == 1 || $rootScope.solicitudJson.banderaSolidario == 1)? $rootScope.solicitudJson.capacidadPagoComprobable : $rootScope.solicitudJson.capacidadPagoNoComprobable;
									$scope.disponible = $scope.capacidadPago - $rootScope.solicitudJson.cotizacion.pagoNormal;
									if ($scope.disponible <= 0)
										$rootScope.message("Confirmación", ["Infórmale a tu cliente que esta tarjeta la podrá ocupar una vez que surta su primer pedido."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
									else
										$rootScope.message("Confirmación", ["Tarjeta activada exitosamente."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
								}
							}else{
								$scope.capacidadPago = ($rootScope.solicitudJson.banderaIngresos == 1 || $rootScope.solicitudJson.banderaSolidario == 1)? $rootScope.solicitudJson.capacidadPagoComprobable : $rootScope.solicitudJson.capacidadPagoNoComprobable;
								$scope.disponible = $scope.capacidadPago - $rootScope.solicitudJson.cotizacion.pagoNormal;
								if ($scope.disponible <= 0)
									$rootScope.message("Confirmación", ["Infórmale a tu cliente que esta tarjeta la podrá ocupar una vez que surta su primer pedido."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
								else
									$rootScope.message("Confirmación", ["Tarjeta activada exitosamente."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
							}
						}else{
							if(jresponse.jsonResponseUpdStatus.codigo == 401)
								$rootScope.message("Actualizar Estatus", ["El estatus de la Línea de Crédito del cliente aun no está actualizado."], "Aceptar", null, "bgCafeZ", "cafeZ");
							else
								$rootScope.message("Actualizar Estatus", ["Codigo de error "+jresponse.jsonResponseUpdStatus.codigo, ERROR_SERVICE], "Aceptar", null, "bgCafeZ", "cafeZ");
						}
					}else{
						var respuestaAln=$scope.manejoErrorAlnova(jresponse.jsonResponseActivacion.data.descriptionCode);
						if (respuestaAln){
							$rootScope.message("Activar Tarjeta", [respuestaAln], "Aceptar", null, "bgCafeZ", "cafeZ");
						}else{
							if (jresponse.jsonResponseActivacion.data.descriptionCode){
								$rootScope.message("Activar Tarjeta", ["Codigo de error "+jresponse.jsonResponseActivacion.codigo,jresponse.jsonResponseActivacion.data.descriptionCode], "Aceptar", null, "bgCafeZ", "cafeZ");
							}else{
								$rootScope.message("Activar Tarjeta", ["Error al intentar activar tarjeta"], "Aceptar", null, "bgCafeZ", "cafeZ");
								$rootScope.loggerServicios("liberacionController", jresponse);
								$rootScope.waitLoaderStatus = LOADER_HIDE;
							}
						}
					}
				}catch( e ){
					$rootScope.message("Activar Tarjeta", ["Error "+ e.message ], "Aceptar", null, "bgCafeZ", "cafeZ");
				}								
			}else{
				if (jresponse.jsonResponseLCR.codigo == 401){
					$rootScope.waitLoaderStatus = LOADER_HIDE; 
					generalService.cleanRootScope($rootScope);
					generalService.buildSolicitudJson($rootScope, null);
					$rootScope.message("LCR", ["Esta solicitud de Línea de Crédito no se encuentra autorizada, por lo cual, no es posible continuar con el proceso."], "Aceptar", "/", "bgCafeZ", "cafeZ");
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE; 
					$rootScope.message("LCR", ["Codigo de error "+jresponse.jsonResponseLCR.codigo,ERROR_SERVICE], "Aceptar", null, "bgCafeZ", "cafeZ");
				}
			}
		};

		$scope.manejoErrorAlnova=function(mensaje){
			var ERRORES_ALNOVA={
				"(MPE0820)":"Tarjeta cancelada a petición del banco",
				"(MCE0317)":"Lo sentimos, esta tarjeta ya fue asignada previamente, intenta con otra"	
			};
			
			for(var key in ERRORES_ALNOVA){
				if(mensaje.indexOf(key)!=-1)
					return ERRORES_ALNOVA[key];
			}
			
			return "";
		};
		
// I-MODIFICACION TDC (SERVICIO LIGAR TDC)		
		$scope.ligarTarjetaTDC = function(){
			var cu = $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico;								
			var cuArray = cu.split('-');
			var cuenta =$rootScope.solicitudJson.tarjetasCredito.tarjetaOro.numeroCuenta
//			cuenta =  "01270673xx0312345678";
			var entidad  = cuenta.substring(0, 4); 
			var sucursal = cuenta.substring(4, 8); 
			var producto = cuenta.substring(10, 12);
			var cuenta   = cuenta.substring(12, 20);
			$rootScope.solicitudJson.tarjetasCredito.tarjetaOro.numeroTarjeta = $scope.tarjetaNueva.valor;
			var x = {
					clienteAlnova: $rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova,
					paisClienteUnico: cuArray[0],
					sucursalClienteUnico: cuArray[2],
					folioClienteUnico: cuArray[3] ,
					canalPedido: "10",
					sucursalPedido: "01",
					pedido: "0111100001" ,
					tipoTarjeta: $scope.buscarTipoTarjeta($scope.tarjetaNueva.valor),
					entidadCuenta: entidad,
					centroCuenta: sucursal,
					tipoProducto: producto,
					tipoSubProducto: "001",
					numeroCuenta: $rootScope.solicitudJson.tarjetasCredito.tarjetaOro.numeroCuenta,
					limiteCredito: ($rootScope.solicitudJson.banderaIngresos == 1)?$rootScope.solicitudJson.tarjetasCredito.tarjetaOro.limiteCreditoComprobable : $rootScope.solicitudJson.tarjetasCredito.tarjetaOro.limiteCreditoNoComprobable,
					estatusTarjeta: "B",
					estatusDomicilizacion: $rootScope.solicitudJson.tarjetasCredito.tarjetaOro.estatusDomicializacion,
					tarjetaEntrada: $scope.tarjetaNueva.valor,
					codigoAsesor: "OTROUSER",
					ticketYakana: generalService.getArrayValue('ticket'),
//					ticketYakana: generalService.getArrayValue('ticketTarjeta'),
					idSolicitud:   $rootScope.solicitudJson.idSolicitud
			}
			$rootScope.waitLoaderStatus = LOADER_SHOW;
		    tarjetaService.ligarTarjetaRevolvente(x).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							if (j.codigo ==  RESPONSE_ORIGINACION_CODIGO_EXITO){
								$rootScope.solicitudJson = j.data;
								$scope.modalAcuse();
							}else{
								modalService.alertModal("ERROR "+j.codigo, [j.descripcion, "Favor de intentar de nuevo"]);	
							}
							
						}else{
							modalService.alertModal("error", [data.data.descripcion]);	
						}
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
					}
				);
		}
		
		$scope.modalAcuse = function(){
			if (configuracion.origen.tienda)
				$rootScope.validarTienda = true;
			else
				$rootScope.validarTienda = false;
		    $scope.tituloAviso = {texto:"Acuse de entrega de la Tarjeta de Crédito "+ $rootScope.camelize($rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc)};
		    $rootScope.isAcuseTarjeta = true;
          	$scope.tituloFirma = "Firma Acuse de entrega de la Tarjeta de Crédito "+ $rootScope.camelize($rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc);              	              	
          	$scope.urlDoc = ($rootScope.solicitudJson.idProducto != 28)?"acuseTarjeta.html":"acuseTarjetaTEC.html";
          	$rootScope.title = "Acuse de entrega de la Tarjeta de Crédito "+ $rootScope.camelize($rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc);
          	$scope.negacionCheck = {texto:"", visible: false, textoMensaje:" la Contrato de Crédito.", botonAceptar: "Aceptar", cuentas: $scope.cuentasDomiciliar} 
		
//			$timeout( function(){
//				construirIframe();
//			}, 100 );
			
			$scope._btnNoAceptar = generalService.getDataInput("CONTRATOS","BOTON NO ACEPTAR", $scope.origen);
			$scope._btnAceptar = generalService.getDataInput("CONTRATOS","BOTON ACEPTAR", $scope.origen);
			$scope.txtModalContratos = generalService.getDataInput("CONTRATOS","TEXTO MODAL CONTRATOS", $scope.origen);
			
			var imagenesArray = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";				
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
							
				
			modalService.pdfViewModal($scope.urlDoc, $scope.tituloAviso.texto, $scope._btnAceptar.texto, "Cerrar", null, $scope._btnAceptar.estilo, null, true, $scope.esContratos, $scope.contratosAceptados, 0, $scope.txtModalContratos,imagenesArray, $scope.muestraAvisos, $scope.negacionCheck )
							.then(
									function(aceptar){
										var esAcuseTaz = false;
										$scope.archivafirmasAcuseTaz(esAcuseTaz);
										$scope.addOverflow();
									},function(noaceptar){
										 $rootScope.isAcuseTarjeta = false;
										$scope.addOverflow();
									}
								);				
		};
		
		//Se crea funcion para mostrar el contrato de acuse de Taz en el mismo se crea el json del contrato para agregarlo al Json general
		$scope.modalAcuseTaz = function(){
			
			if (configuracion.origen.tienda)
				$rootScope.validarTienda = true;
			else
				$rootScope.validarTienda = false;
		    $scope.tituloAviso = {texto:"Acuse de entrega de la Tarjeta de Crédito "};
          	$scope.tituloFirma = "Firma Acuse de entrega de la Tarjeta de Crédito ";              	              	
          	$scope.urlDoc = "acuseTaz.html";
          	$rootScope.isSolicitud = false;
          	$rootScope.isAcuseTaz = true;
          	$rootScope.title = "Acuse de entrega de la Tarjeta de Crédito";
          	$scope.negacionCheck = {texto:"No acepto Acuse de Tarjeta de Crédito", visible: true, textoMensaje:" Acuse de Tarjeta Azteca", botonAceptar: "Aceptar"};
			$scope._btnNoAceptar = generalService.getDataInput("CONTRATOS","BOTON NO ACEPTAR", $scope.origen);
			$scope._btnAceptar = generalService.getDataInput("CONTRATOS","BOTON ACEPTAR", $scope.origen);
			$scope.txtModalContratos = generalService.getDataInput("CONTRATOS","TEXTO MODAL CONTRATOS", $scope.origen);
			
			var imagenesArray = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";				
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
							
				
			modalService.pdfViewModal($scope.urlDoc, $scope.tituloAviso.texto, $scope._btnAceptar.texto, "Cerrar", null, $scope._btnAceptar.estilo, null, true, $scope.esContratos, $scope.contratosAceptados, 0, $scope.txtModalContratos,imagenesArray, $scope.muestraAvisos, $scope.negacionCheck )
			.then(
					function(aceptar){
						$rootScope.isAcuseTaz = true;						
						var esAcuseTaz = true;
						$scope.guardarContratos(esAcuseTaz);
						$scope.addOverflow();
					},function(noaceptar){
						 $rootScope.isAcuseTaz = false;
						$scope.addOverflow();
					}
				);					
		};
		
		
		
		/**
		 * Función para guardar la el objeto del contrato AcuseTaz en el json 
		 */
		
		$scope.guardarContratos = function (esAcuseTaz){
			
			var agregaAcuseTaz =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
				return d["idContrato"];
				
			}).indexOf (FIRMA_ACUSE_TAZ.id);
			if (agregaAcuseTaz == -1){
				
				var jsonAcuseTaz = {
						idContrato: FIRMA_ACUSE_TAZ.id,
						idPersona: $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
						statusFirma: STATUS_CONTRATO.SIN_FIRMA,
						descripcion: "acuseTaz",
						idTipoPersona: 1
					};
	
				$rootScope.solicitudJson.contratos.contrato.push(jsonAcuseTaz);
				
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($rootScope.solicitudJson), seccion: 8 } ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
							var responseJson = JSON.parse(data.data.respuesta);
							
							if(responseJson.codigo == 2){							
								$rootScope.solicitudJson.contratos = responseJson.data.contratos;
								if ($scope.origen == "TIENDA" && (configuracion.so.ios || configuracion.so.windows)){
									$scope.archivafirmasAcuseTaz(esAcuseTaz);
								}
							}
							$scope.firmarAcuse = false;
						}else{
							$scope.firmarAcuse = false;
							$rootScope.message("Error",["Ocurrio un error al guardar la sección de contratos. Favor de volver a intentar"], "Aceptar", null, "bgRosa", "btnRosaD");
						}
						
					}, function(error){
						$scope.firmarAcuse = false;
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Error",["Ocurrio un error al guardar la sección de contratos. Favor de volver a intentar"], "Aceptar", null, "bgRosa", "btnRosaD");
					}
				);
			}else{
				$scope.archivafirmasAcuseTaz(esAcuseTaz);
			}
		};
		
		
		/*
		 * Se crea funcion para preparar la firma del contrato de acuse de Taz, en el cual es llamado desde liberacionController por modalAcuseTaz
		 */
		 $scope.archivafirmasAcuseTaz = function(esAcuseTaz){
				var descripcion = FIRMA_ACUSE_TAZ.descripcion;
				var etiqueta =  FIRMA_ACUSE_TAZ.etiqueta;
				if(esAcuseTaz){
					$scope.imgFirma = $rootScope.imgAcuseTaz;
				}else{
					$scope.imgFirma = $rootScope.imgfirmaEntrega;
				}
				
				if (!generalService.isEmpty($rootScope.imgAcuseTaz) || !generalService.isEmpty($rootScope.imgfirmaEntrega)){
					$scope.b64Firma = $scope.imgFirma.replace("data:image/png;base64,","").trim();
		    		var biometrico = {
							ruta: null,
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							cadena: $scope.b64Firma,
							tipoCadena: descripcion,
							porcentaje: 100
					}
		    		$scope.enviaAcuseTaz(biometrico, esAcuseTaz);		
		    	}else{
					$rootScope.loggerIpad("La firma del:" + descripcion + "esta vacia", null);
					$rootScope.message("Aviso",["No se encuentra firma del contrato, favor de volver a reintentar"], "Aceptar", null, "bgCafeZ","cafeZ",null,null,null);
				}
			};
			
		$scope.enviaAcuseTaz = function (biometrico, esAcuseTaz){
			$rootScope.waitLoaderStatus = LOADER_SHOW;

			clienteUnicoService.setBiometrico( biometrico ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							if( $rootScope.solicitudJson.idProducto == PRODUCTOS.tarjetaAzteca.ID.valor && generalService.masterFunction() &&
							    $rootScope.flujoEsOchoPasos){
								generalService.locationPath("/ochoPasos");
							}else if(esAcuseTaz){
								$scope.liberarLCR();
								generalService.setRespaldo($rootScope.solicitudJson);
							}else{
								generalService.locationPath("/estatus");
							}	
							
						}else if(j.codigo == RESPONSE_CODIGO_ERROR_ID){
							$scope.firmarAcuse = false;
							$scope.activar = false;
							$rootScope.message("Error",[j.descripcion], "Aceptar", null, "bgCafeZ","cafeZ",null,null,null);
						}else{
							$scope.firmarAcuse = false;
							$scope.activar = false;
							$rootScope.message("Error",["Error al enviar el contrato. Por favor, espere unos minutos para reintentar"], "Aceptar", null, "bgCafeZ","cafeZ",null,null,null);
						}
					}else{
						$scope.firmarAcuse = false;
						$scope.activar = false;
						$rootScope.message("Error",["Error en la respuesta del servicio para guardar el contrato del cliente. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafeZ","cafeZ");
					}
				},function(error){
					$scope.firmarAcuse = false;
					$scope.activar = false;
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Error",["Servicio no disponible para enviar el contrato, favor de comunicarse con soporte."], "Aceptar", "/simulador", "bgCafeZ","cafeZ");
				});
		};
	
	$scope.addOverflow=function(){
		$( "html" ).removeClass( "overflowHiddenHTML");
		$( "body" ).addClass( "overflowInitialHTML");
	}
	
	
	$scope.buscarTipoTarjeta = function(tarjeta){
		var bin = tarjeta.substring(0, 8); 
		var index = TIPO_TARJETAS.map(function(d){
			return d["bin"];
			
		}).indexOf (bin);
		if( index !=-1 )
			return TIPO_TARJETAS[index].tipo;
		else
			return "";
	}
		$scope.cambioTarjeta=function(){
			if ($scope.numtarjeta.numTAZ){
				if($scope.numtarjeta.numTAZ.length == 19){
					$scope.activar=true;
				}else{
					$scope.activar=false;
				}				
			}else{
				$scope.activar=false;
			}
		}
// F-MODIFICACION TDC (SERVICIO LIGAR TDC)

//		$scope.activarTAZ=function(){
//			var cu = $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico;								
//			var cuArray = cu.split('-');
//			if($scope.valeItalikaActivado)
//				$scope.tarjetaValeItalika=null;
//			var request = {
//					idSolicitud: $rootScope.solicitudJson.idSolicitud,	    			
//	    			cu: {pais: parseInt(cuArray[0]), canal:parseInt(cuArray[1]), sucursal:parseInt(cuArray[2]), folio:parseInt(cuArray[3]) },
//	    			numCteAlnova: $rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova,
//	    			valeElectronico:{
//	    				numTaz: $scope.tarjetaValeItalika
//	    			},
//	    			tarjetaAzteca:{
//	    				numTaz: $scope.tarjetaNueva.valor,
//	        			nip: generalService.getArrayValue('nip')
//	    			}
//	    	};
//			$rootScope.waitLoaderStatus = LOADER_SHOW;
//			$scope.request=null;
//	    	tarjetaService.activarTarjetas( request ).then(
//					function(data){
//						$rootScope.waitLoaderStatus = LOADER_HIDE;
//						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
//							if(!$scope.valeItalikaActivado)
//								$scope.respuetaActivacion(data.data.respuesta.valeElectronico,request,1);
//							else
//								$scope.continuaTarjetaAzteca=true;
//							if($scope.continuaTarjetaAzteca)
//								$scope.respuetaActivacion(data.data.respuesta.tarjetaAzteca,request,2);
//						}else{
//							$rootScope.waitLoaderStatus = LOADER_HIDE; 
//							modalService.alertModal("Entrega de tarjeta", [ERROR_SERVICE], "Aceptar", "bgCafeZ", "cafeZ");
//						}
//					}, function(error){
//		                $rootScope.waitLoaderStatus = LOADER_HIDE;
//		                $rootScope.modalService.alertModal("Error en servidor", [ERROR_SERVICE], "Aceptar", "bgCafeZ", "cafeZ");
//					}
//			);
//		}
		
		$scope.dispersarCallCenter = function() {
			$rootScope.waitLoaderStatus = LOADER_SHOW;

			if (generalService.isBazDigital()) {
				var request = {
					idSolicitud : $rootScope.solicitudJson.idSolicitud,
					tipoPeticion : 1,
					idPlataforma : PLATAFORMA.BAZDIGITAL
				};

				callCenterService.dispersarTarjetas(request).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
							var jResponse = JSON.parse(data.data.respuesta);

							if (jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO) {
								generalService.setDataBridge({
									origen : FICHA.origen.recuperar
								});
								generalService.locationPath("/ficha");
							} else
								$rootScope.message("Dispersar CallCenter ", [ jResponse.descripcion, "Codigo de error " + jResponse.codigo ], "Aceptar");

						} else
							$rootScope.message("Dispersar CallCenter", [ generalService.displayMessage(data.data.descripcion) ], "Aceptar");


					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;

					}
				);

			}
			else
				$rootScope.message("AVISO ", [CTE_BAZ_DIGITAL], "Aceptar", null, "bgCafeZ", "cafeZ");

		};
		
		$scope.getFoliounicoCE = function(){
			var requestfolioCE = {
	    			idSolicitud: $rootScope.solicitudJson.idSolicitud,
	    			numTarjeta: $scope.tarjetaNueva.valor,
	    			tipoOperacion: 1
	    		};
			tarjetaService.generaFolioUnicoCE(requestfolioCE).then(
					function(data){
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							$scope.activaTazInstantanea();
						}else{
							$rootScope.modalService.alertModal("Error al guardar el pedido", [ERROR_SERVICE], "Aceptar", "bgCafeZ", "cafeZ");
						}
					}, function(error){
						$rootScope.modalService.alertModal("Error en servidor", [ERROR_SERVICE], "Aceptar", "bgCafeZ", "cafeZ");
					}
			);
		}
		
	});
});