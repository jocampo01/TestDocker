'use strict';

define(["app"], function (app) {


	app.controller("loginController", function ($scope, $rootScope,  $timeout,  modalService, 
			loginService, sessionService, securityService, generalService) {				

		$rootScope.waitLoaderStatus = LOADER_HIDE;
		$scope.loginRequest = { username: "", password: "" } 

		$rootScope.sessionid = null;


		$scope.simulador = function(){
			generalService.locationPath("/");
		};

		$scope.login = function(){
			
			
			$rootScope.consultaAbonos = {
					prestamosPersonales: [],
					preaprob  : [],
					sipa : [],
					winback : [],
					_30_30_30 : [],
					rescatePrestamo : []
					
			}
			
			var numeroIntentos = 3;
			$rootScope.contadorAbonos = {
					pp: numeroIntentos,
					preaprob  : numeroIntentos,
					sipa : numeroIntentos,
					winback : numeroIntentos,
					_30_30_30 : numeroIntentos,
					rescatePrestamo : numeroIntentos
			}

			$rootScope.waitLoaderStatus = LOADER_SHOW; 		    						   
			$scope.c = 0;
			loginService.login($scope.loginRequest).then(
					function(data){ //EXITO
						console.log("LOGIN  OK");

						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							$scope.c = data.data.respuesta.ticketSession.codigo;

							if(data.data.respuesta.ticketSession.codigo == HTTPCODE_OK){			                			

								securityService.setKeys(data.headers().key, data.headers().initial_vector);

								for( var i in window.routes ) 	            																						
									window.routes[i].requireLogin = false;


								localStorage['paths'] = JSON.stringify(window.routes);		
								generalService.setArrayValue('ticketTarjeta',data.data.respuesta.ticketSession.ticket);
								sessionService.getObjSessionId( data.data.respuesta.ticketSession.ticket ).then(
										function(exito){ //EXITO		

											if(exito.data.codigo == RESPONSE_CODIGO_EXITO){
		                		                		$rootScope.inSession = true;
		                		                		$rootScope.userSession = exito.data.respuesta.datosUsuario;  
		                		                		$rootScope.sucursalSession = exito.data.respuesta.datosSucursal;

												var key = generalService.keyEmpBase64();		        		                		           			 			                		        			    			           				
												securityService.setKeys(key, key);
												
												/**
										    		 * Servicio para consulta la funcionalidad por sucursal
										    		 * Se ejecuta cuando se Loguean en el Portal Web. 
										    		 **/
												loginService.consultaFuncionalidad({idPais:exito.data.respuesta.datosSucursal.idPais, idSucursal:exito.data.respuesta.datosSucursal.idSucursal, idCanal:exito.data.respuesta.datosSucursal.idCanal}).then(
							        			    		function(objetoFuncionalidad) {
							        			    			if(objetoFuncionalidad.data.codigo == RESPONSE_CODIGO_EXITO) {
							        			    				var jsonResponseFuncionalidad = JSON.parse(objetoFuncionalidad.data.respuesta);
							        			    				if(jsonResponseFuncionalidad.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							        			    					/**
				    												 * En caso de exito se mapea el objeto "consultaFuncionalidad" y continua al Simulador
				    												 **/
							        			    					$rootScope.consultaFuncionalidad =  jsonResponseFuncionalidad.data;
							        			    					//generalService.locationPath("/simulador");
							        			    					cargarAbonosPrestamoPersonal();
							        			    				}else{
							        			    					/**
				    												 * En caso de error, se continua al Simulador
				    												 **/
							        			    					//generalService.locationPath("/simulador");
							        			    					cargarAbonosPrestamoPersonal();
							        			    				}
							        			    			}else{
							        			    				/**
			    												 * En caso de error, se continua al Simulador
			    												 **/
							        			    				//generalService.locationPath("/simulador");
							        			    				cargarAbonosPrestamoPersonal();
							        			    		    }
							        			    		}, function(error) {
							        			    			/**
		    												 * En caso de error, se continua al Simulador
		    												 **/
							        			    			//generalService.locationPath("/simulador");
							        			    			cargarAbonosPrestamoPersonal();
							        			    		}
							        			    );
											} else
												modalService.alertModal("Error", ["No se pudo habilitar la sesión ",exito.data.descripcion]);		                		                		


										}, function(error){ //ERROR 				                					
											modalService.alertModal("Error", ["No se pudo habilitar la sesión ",error]);	                    	                    		                    		                  
										}
								);			                			 			                						                						                						                						                						                						                			
							}else{
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								modalService.alertModal("Error "+data.data.respuesta.ticketSession.codigo, [data.data.respuesta.ticketSession.status]);
							}
						}else{
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							modalService.alertModal("Error", [data.data.descripcion]);
						}

					}, function(error){ //ERROR
						$rootScope.waitLoaderStatus = LOADER_HIDE; 			                   			                    		                   
					}
			);
			
			var cargarAbonosPrestamoPersonal = function(){
				
				if($rootScope.contadorAbonos.pp <= 0){
					$rootScope.message("Aviso",["No se pudieron obtener los abonos de PrestamoPersonal correctamente"], "Aceptar", null);
					return null;
				}
				
				if($rootScope.consultaAbonos.prestamosPersonales == undefined || $rootScope.consultaAbonos.prestamosPersonales.length == 0){
					loginService.consultarAbonos({idPais:$rootScope.sucursalSession.idPais,idSucursal:$rootScope.sucursalSession.idSucursal , idCanal:$rootScope.sucursalSession.idCanal, campana:"PRESTAMO_PERSONAL", idProducto:24, periodicidad: 1, isRecompra: true  }).then(
				    		function(objetoAbonos) {
				    			if(objetoAbonos.data.codigo == RESPONSE_CODIGO_EXITO) {
				    				var jsonResponseAbonos = JSON.parse(objetoAbonos.data.respuesta);
				    				if(jsonResponseAbonos.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
				    					/**
									 * En caso de exito se mapea el objeto  continua a consultar los demas abonos
									 **/
				    					$rootScope.consultaAbonos.prestamosPersonales =  jsonResponseAbonos.data;
				    					if($rootScope.consultaAbonos.prestamosPersonales.length > 0){
				    						//cargarAbonosPreaprob();
				    						invocarAbonos();
				    						generalService.locationPath("/simulador");
				    					}
				    					else{
				    						$rootScope.contadorAbonos.pp --;
				    						cargarAbonosPrestamoPersonal();
				    					}
				    					
				    				}else{
				    					/**
									 * En caso de error, se continua al Simulador
									 **/
				    					$rootScope.contadorAbonos.pp --;
				    					cargarAbonosPrestamoPersonal();
				    				}
				    			}else{
				    				/**
								 * En caso de error, se continua al Simulador
								 **/
				    				$rootScope.contadorAbonos.pp --;
				    				cargarAbonosPrestamoPersonal();
				    		    }
				    		}, function(error) {
				    			/**
							 * En caso de error, se continua al Simulador
							 **/
				    			$rootScope.contadorAbonos.pp --;
				    			cargarAbonosPrestamoPersonal();
				    		}
				    );
				
				}
			}
			

			var invocarAbonos = function(){
				cargarAbonosPreaprob();
				cargarAbonosSIPA();
				cargarAbonosWinback();
				//cargarAbonos30_30_30();
				cargarAbonosRescate();
			}
			
				var cargarAbonosPreaprob = function(){
					
					if($rootScope.contadorAbonos.preaprob <= 0){
						$rootScope.message("Aviso",["No se pudieron obtener los abonos de Preaprobados correctamente"], "Aceptar", null);
						return null;
					}
					
					if($rootScope.consultaAbonos.preaprob == undefined || $rootScope.consultaAbonos.preaprob.length == 0){
						loginService.consultarAbonos({idPais:$rootScope.sucursalSession.idPais, idSucursal:$rootScope.sucursalSession.idSucursal, idCanal:$rootScope.sucursalSession.idCanal, campana:"PREAPROB", idProducto:24, periodicidad: 1, isRecompra: false  }).then(
					    		function(objetoAbonos) {
					    			if(objetoAbonos.data.codigo == RESPONSE_CODIGO_EXITO) {
					    				var jsonResponseAbonos = JSON.parse(objetoAbonos.data.respuesta);
					    				if(jsonResponseAbonos.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
					    					/**
										 * 
										 **/
					    					$rootScope.consultaAbonos.preaprob =  jsonResponseAbonos.data;
					    					if($rootScope.consultaAbonos.preaprob.length == 0){
					    						$rootScope.contadorAbonos.preaprob --; 
					    						cargarAbonosPreaprob();
					    					}
//					    					if($rootScope.consultaAbonos.preaprob.length > 0){
//					    						cargarAbonosSIPA();
//					    					}
//					    					else{
//					    						$rootScope.contadorAbonos.preaprob --; 
//					    						cargarAbonosPreaprob();
//					    					}
					    				}else{
					    					/**
										 * En caso de error, se continua al Simulador
										 **/
					    					$rootScope.contadorAbonos.preaprob --; 
					    					cargarAbonosPreaprob();
					    				}
					    			}else{
					    				/**
									 * En caso de error, se continua al Simulador
									 **/
					    				$rootScope.contadorAbonos.preaprob--;
					    				cargarAbonosPreaprob();
					    		    }
					    		}, function(error) {
					    			/**
								 * En caso de error, se continua al Simulador
								 **/
					    			$rootScope.contadorAbonos.preaprob--;
					    			cargarAbonosPreaprob();
					    		}
					    );
					}
				}
				
				var cargarAbonosSIPA = function(){
					
					if($rootScope.contadorAbonos.sipa <= 0){
						$rootScope.message("Aviso",["No se pudieron obtener los abonos correctamente"], "Aceptar", null);
						return null;
					}
					
					if($rootScope.consultaAbonos.sipa == undefined || $rootScope.consultaAbonos.sipa.length == 0){
						loginService.consultarAbonos({idPais:$rootScope.sucursalSession.idPais, idSucursal:$rootScope.sucursalSession.idSucursal, idCanal:$rootScope.sucursalSession.idCanal, campana:"SIPA", idProducto:24, periodicidad: 1, isRecompra: false  }).then(
					    		function(objetoAbonos) {
					    			if(objetoAbonos.data.codigo == RESPONSE_CODIGO_EXITO) {
					    				var jsonResponseAbonos = JSON.parse(objetoAbonos.data.respuesta);
					    				if(jsonResponseAbonos.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
					    					/**
										 * En caso de exito se mapea el objeto "consultaFuncionalidad" y continua al Simulador
										 **/
					    					$rootScope.consultaAbonos.sipa =  jsonResponseAbonos.data;
					    					if($rootScope.consultaAbonos.sipa.length == 0){
					    						$rootScope.contadorAbonos.sipa --; 
					    						cargarAbonosSIPA();
					    					}
					    					
//					    					if($rootScope.consultaAbonos.sipa.length > 0){
//					    						cargarAbonosWinback();
//					    					}
//					    					else{
//					    						$rootScope.contadorAbonos.sipa --; 
//					    						cargarAbonosSIPA();
//					    					}
					    				}else{
					    					/**
										 * En caso de error, se continua al Simulador
										 **/
					    					$rootScope.contadorAbonos.sipa--;
					    					cargarAbonosSIPA();
					    				}
					    			}else{
					    				/**
									 * En caso de error, se continua al Simulador
									 **/
					    				$rootScope.contadorAbonos.sipa--;
					    				cargarAbonosSIPA();
					    		    }
					    		}, function(error) {
					    			/**
								 * En caso de error, se continua al Simulador
								 **/
					    			$rootScope.contadorAbonos.sipa--;
					    			cargarAbonosSIPA();
					    		}
					    );
					}
				}
				
				
				var cargarAbonosWinback = function(){
					
					if($rootScope.contadorAbonos.winback <= 0){
						$rootScope.message("Aviso",["No se pudieron obtener los abonos correctamente"], "Aceptar", null);
						return null;
					}
					if($rootScope.consultaAbonos.winback == undefined || $rootScope.consultaAbonos.winback.length == 0){
						loginService.consultarAbonos({idPais:$rootScope.sucursalSession.idPais, idSucursal:$rootScope.sucursalSession.idSucursal , idCanal:$rootScope.sucursalSession.idCanal, campana:"WINBACK", idProducto:24, periodicidad: 1, isRecompra: false  }).then(
					    		function(objetoAbonos) {
					    			if(objetoAbonos.data.codigo == RESPONSE_CODIGO_EXITO) {
					    				var jsonResponseAbonos = JSON.parse(objetoAbonos.data.respuesta);
										
					    				if(jsonResponseAbonos.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
					    					/**
										 * En caso de exito se mapea el objeto "consultaFuncionalidad" y continua al Simulador
										 **/
					    					$rootScope.consultaAbonos.winback =  jsonResponseAbonos.data;
					    					if($rootScope.consultaAbonos.winback.length == 0){
					    						$rootScope.contadorAbonos.winback --; 
					    						cargarAbonosWinback();
					    					}
					    					
//					    					if($rootScope.consultaAbonos.winback.length > 0){
//					    						cargarAbonos30_30_30();
//					    						//cargarAbonosRescate();
//					    					}
//					    					else{
//					    						$rootScope.contadorAbonos.winback --; 
//					    						cargarAbonosWinback();
//					    					}
					    				}else{
					    					/**
										 * En caso de error, se continua al Simulador
										 **/
					    					$rootScope.contadorAbonos.winback --;
					    					cargarAbonosWinback();
					    				}
					    			}else{
					    				/**
									 * En caso de error, se continua al Simulador
									 **/
					    				$rootScope.contadorAbonos.winback --;
					    				cargarAbonosWinback();
					    		    }
					    		}, function(error) {
					    			/**
								 * En caso de error, se continua al Simulador
								 **/
					    			$rootScope.contadorAbonos.winback --;
					    			cargarAbonosWinback();
					    		}
					    );
					}
				}
				
				
				var cargarAbonos30_30_30 = function(){
					if($rootScope.contadorAbonos._30_30_30 <= 0){
						$rootScope.message("Aviso",["No se pudieron obtener los abonos correctamente"], "Aceptar", null);
						return null;
					}
					
					if($rootScope.consultaAbonos._30_30_30 == undefined  || $rootScope.consultaAbonos._30_30_30.length == 0){
						loginService.consultarAbonos({idPais:$rootScope.sucursalSession.idPais, idSucursal:$rootScope.sucursalSession.idSucursal , idCanal:$rootScope.sucursalSession.idCanal, campana:"30_30_30", idProducto:24, periodicidad: 1, isRecompra: false  }).then(
					    		function(objetoAbonos) {
					    			if(objetoAbonos.data.codigo == RESPONSE_CODIGO_EXITO) {
					    				var jsonResponseAbonos = JSON.parse(objetoAbonos.data.respuesta);
					    				if(jsonResponseAbonos.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
					    					/**
										 * En caso de exito se mapea el objeto "consultaFuncionalidad" y continua al Simulador
										 **/
					    					$rootScope.consultaAbonos._30_30_30 =  jsonResponseAbonos.data;
					    					if($rootScope.consultaAbonos._30_30_30.length == 0){
					    						$rootScope.contadorAbonos._30_30_30 --; 
					    						cargarAbonos30_30_30();
					    					}
					    					
//					    					if($rootScope.consultaAbonos._30_30_30.length > 0){
//					    						cargarAbonosRescate();
//					    					}
//					    					else{
//					    						$rootScope.contadorAbonos._30_30_30 --; 
//					    						cargarAbonos30_30_30();
//					    					}
					    					
					    				}else{
					    					/**
										 * En caso de error, se continua al Simulador
										 **/
					    					$rootScope.contadorAbonos._30_30_30 --; 
					    					cargarAbonos30_30_30();
					    				}
					    			}else{
					    				/**
									 * En caso de error, se continua al Simulador
									 **/
					    				$rootScope.contadorAbonos._30_30_30 --; 
					    				cargarAbonos30_30_30();
					    		    }
					    		}, function(error) {
					    			/**
								 * En caso de error, se continua al Simulador
								 **/
					    			$rootScope.contadorAbonos._30_30_30 --; 
					    			cargarAbonos30_30_30();
					    		}
					    );
					}
				}
				
				
				var cargarAbonosRescate = function(){
					if($rootScope.contadorAbonos.rescatePrestamo <= 0){
						$rootScope.message("Aviso",["No se pudieron obtener los abonos correctamente"], "Aceptar", null);
						return null;
					}
					if($rootScope.consultaAbonos.rescatePrestamo == undefined || $rootScope.consultaAbonos.rescatePrestamo.length == 0){
						loginService.consultarAbonos({idPais:$rootScope.sucursalSession.idPais, idSucursal:$rootScope.sucursalSession.idSucursal , idCanal:$rootScope.sucursalSession.idCanal, campana:"RESCATE_PRESTAMO", idProducto:24, periodicidad: 1, isRecompra: false  }).then(
					    		function(objetoAbonos) {
					    			if(objetoAbonos.data.codigo == RESPONSE_CODIGO_EXITO) {
					    				var jsonResponseAbonos = JSON.parse(objetoAbonos.data.respuesta);
					    				if(jsonResponseAbonos.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
					    					/**
										 * En caso de exito se mapea el objeto "consultaFuncionalidad" y continua al Simulador
										 **/
					    					$rootScope.consultaAbonos.rescatePrestamo =  jsonResponseAbonos.data;
					    					
					    					if($rootScope.consultaAbonos.rescatePrestamo.length == 0){
					    						$rootScope.contadorAbonos.rescatePrestamo --; 
					    						cargarAbonosRescate();
					    					}
					    					
//					    					if($rootScope.consultaAbonos.rescatePrestamo.length > 0){
//					    						//generalService.setArrayValue("consultaAbonosA", $rootScope.consultaAbonos);
//						    					generalService.locationPath("/simulador");
//					    					}
//					    					else{
//					    						$rootScope.contadorAbonos.rescatePrestamo --; 
//					    						cargarAbonosRescate();
//					    					}
					    					
					    				}else{
					    					/**
										 * En caso de error, se continua al Simulador
										 **/
					    					$rootScope.contadorAbonos.rescatePrestamo --;
					    					cargarAbonosRescate();
					    				}
					    			}else{
					    				/**
									 * En caso de error, se continua al Simulador
									 **/
					    				$rootScope.contadorAbonos.rescatePrestamo --;
					    				cargarAbonosRescate();
					    		    }
					    		}, function(error) {
					    			/**
								 * En caso de error, se continua al Simulador
								 **/
					    			$rootScope.contadorAbonos.rescatePrestamo --;
					    			cargarAbonosRescate();
					    		}
					    );
					}
				}
		};
	});
});