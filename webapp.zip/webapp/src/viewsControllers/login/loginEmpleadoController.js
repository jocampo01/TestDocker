'use strict';

define(["app"], function (app) {
	

	app.controller("loginEmpleadoController", function ($scope, $rootScope, $timeout,  modalService,  loginService, sessionService, securityService, generalService) {				
		
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		$scope.loginRequest = { username: "", password: "" } 
		 
		$rootScope.sessionid = null;
		
		
		$scope.simulador = function(){
			generalService.locationPath("/");
		};
		
		$scope.login = function(){									
							
			$rootScope.waitLoaderStatus = LOADER_SHOW; 		    						   
			$scope.c = 0;
			loginService.login($scope.loginRequest).then(
						function(data){ //EXITO
								console.log("LOGIN  OK");
			                	$rootScope.waitLoaderStatus = LOADER_HIDE; 
			                			
			                	
			                	if(data.data.codigo == RESPONSE_CODIGO_EXITO){
			                		$scope.c = data.data.respuesta.ticketSession.codigo;
			                		
			                		if(data.data.respuesta.ticketSession.codigo == HTTPCODE_OK){			                			
			                			
			                			securityService.setKeys(data.headers().key, data.headers().initial_vector);
			                			
			                			for( var i in window.routes ) 	            																						
								                window.routes[i].requireLogin = false;
			                			
			                			
			                			localStorage['paths'] = JSON.stringify(window.routes);		
			                			generalService.setArrayValue('ticketTarjeta',data.data.respuesta.ticketSession.ticket);
			                			sessionService.getObjSessionId( data.data.respuesta.ticketSession.ticket ).then(
		                						function(exito){ //EXITO		
		                							
		                		                	if(exito.data.codigo == RESPONSE_CODIGO_EXITO){
		                		                		$rootScope.inSession = true;
		                		                		$rootScope.userSession = exito.data.respuesta.datosUsuario;  
		                		                		$rootScope.sucursalSession = exito.data.respuesta.datosSucursal;
		                		                		
		                		                		var key = generalService.keyEmpBase64();		        
		                		           			 	
		                		        			    $timeout(function(){			           				
		                		        			    		securityService.setKeys(key, key);
		                		        			 	}, TIME_OUT_1SEG);
		                		        			    
		                		        			    /**
										    		 * Servicio para consulta la funcionalidad por sucursal
										    		 * Se ejecuta cuando se Loguean en el Portal Web.
										    		 **/
		                		        			    loginService.consultaFuncionalidad({idPais:exito.data.respuesta.datosSucursal.idPais, idSucursal:exito.data.respuesta.datosSucursal.idSucursal, idCanal:exito.data.respuesta.datosSucursal.idCanal}).then(
	                		                				function(objetoFuncionalidad) {
	                		                					if(objetoFuncionalidad.data.codigo == RESPONSE_CODIGO_EXITO) {
	                		                						var jsonResponseFuncionalidad = JSON.parse(objetoFuncionalidad.data.respuesta);
	                		                						if(jsonResponseFuncionalidad.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
	                		                							/**
				    												 * En caso de exito se mapea el objeto "consultaFuncionalidad" y continua al Menu
				    												 **/
	                		                							$rootScope.consultaFuncionalidad =  jsonResponseFuncionalidad.data;
	                		                							generalService.locationPath("/menuWrapper");
	                		                						}else{
	                		                							/**
				    												 * En caso de error, se continua al Menu
				    												 **/
	                		                							$rootScope.consultaFuncionalidad = {};
	                		                							generalService.locationPath("/menuWrapper");
	                		                						}
	                		                					}else{
	                		                						/**
			    												 * En caso de error, se continua al Menu
			    												 **/
	                		                						$rootScope.consultaFuncionalidad = {};
	                		                						generalService.locationPath("/menuWrapper");
	                		                				  }
	                		                				}, function(error) {
	                		                					/**
		    												 * En caso de error, se continua al Menu
		    												 **/
	                		                					$rootScope.consultaFuncionalidad = {};
	                		                					generalService.locationPath("/menuWrapper");
	                		                				}
		                		                		);
		                		                		
		                		                	}else
		                		                		console.log("error = "+exito.data.descripcion);
		                		                				                		                					                		                					                		               
		                		                			                		                				                					                				                		                			                
		                	    				}, function(error){ //ERROR 				                					
		                	    	                console.log(error);	                    	                    		                    		                  
		                	    				}
			                			);			                			 			                						                			
			                						                						                			
//			                			generalService.locationPath("/");
			                			
	
			                		}else
			                			modalService.alertModal("Error "+data.data.respuesta.ticketSession.codigo, [data.data.respuesta.ticketSession.status]);
			                		
			                	}else
			                		modalService.alertModal("Error", [data.data.descripcion]);
			                		                				                					                				                	
			                			                	
						}, function(error){ //ERROR
								$rootScope.waitLoaderStatus = LOADER_HIDE; 
			                    console.log(error);
			                    if(error.status != undefined)
			                    	alert("Error "+ error.status +"\n"+ error.statusText);
			                    else if(error.message != undefined)
			                    	alert("Error: \n"+error.message);
			                    		                   
						}
					);
			
			
	    };
	    
	    
	    
	});
	
		
	
	
});