'use strict';




define(["app"], function (app) {
	app.controller("menuController", function($rootScope, $scope, $location, generalService, solicitudService,modalService, buroService, ngDialog, loginService, validateService, validateServiceOS) {
		
		/**
		 * Mostrar o no las secciones de Datos del empleo y Gastos.
		 */
		$scope.mostrarSeccionEmpleo = true;
		$scope.mostrarSeccionGastos = true;
		$scope.mostrarSeccionReferencias = false;
		$scope.mostrarSeccionExpediente = true;
		$scope.mostrarSeccionContratos = true;
		$scope.quickFixes = generalService.productosQuickFixes();
		$scope.porcentajeQF =  (($rootScope.solicitudJson.cotizacion.clientes[0].porcentaje + $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje)/2).toFixed(0);
		
		try {
			// Se leen de BD.
			$scope.mostrarSeccionEmpleo = $rootScope.consultaFuncionalidad.muestraSeccionDatosEmpleo;
			$scope.mostrarSeccionGastos = $rootScope.consultaFuncionalidad.muestraSeccionGastos;

			// Si fue un crédito inmediato y por BD no se debe mostrar la sección, ¡pues la mostramos!
			$scope.mostrarSeccionEmpleo = !$scope.mostrarSeccionEmpleo ? 
					$rootScope.validaPreAprobados() ? true : generalService.masterFunction() 
							&& $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].bloqueado == 0 : true;
			$scope.mostrarSeccionGastos = !$scope.mostrarSeccionGastos ? 
					$rootScope.validaPreAprobados() ? true : generalService.masterFunction() : true;

			// Si ya bajó de manera correcta y fue rendida, pues se muestran las secciones, sí o sí.
			if($rootScope.solicitudJson.existeCita == 1 && $rootScope.solicitudJson.flujoSolicitudADN == 99 
				&& ($rootScope.solicitudJson.idSeguimiento == 6 || $rootScope.solicitudJson.idSeguimiento == 185)) {
				$scope.mostrarSeccionEmpleo = $rootScope.solicitudJson.cotizacion.clientes[0].idTipoTrabajo == 1;
				$scope.mostrarSeccionGastos = true;
			}
			
			if($rootScope.consultaFuncionalidad.mostrarReferencias){
				if(generalService.masterFunction())
					$scope.mostrarSeccionReferencias = true;
			}else
				$scope.mostrarSeccionReferencias = true;
			
			if($rootScope.esSolicitudCambaceo( $rootScope.solicitudJson.marca)){
				$scope.mostrarSeccionEmpleo = false;
				$scope.mostrarSeccionGastos = false;
				$scope.mostrarSeccionReferencias = false;
				$scope.mostrarSeccionExpediente = false;
				$scope.mostrarSeccionContratos = false;
			}
		} catch (x) {}
		
		$scope.origen = "WEB";
		if($scope.isTienda){
			$scope.origen = "TIENDA";
//			menu(2);
		}
		$scope.x = $("#menuId").offset();
		$rootScope.claseMenu= "fixed";
		
		$.fn.mobileFix = function (options) {
		    var $parent = $(this),
		        $fixedElements = $(options.fixedElements);

		    $(document)
		    .on('blur', options.inputElements, function(e) {
		    	$("#menuId").css("position", "fixed");
		    	$("#menuId").css("top", "");
//		    	$scope.x = $("#menuId").offset();
		    	$("#menuId").css("width", "18.75%;");
		    })
		    .on('focus', options.inputElements, function(e) {
		    	$scope.x = $("#menuId").offset();
		    	$("#menuId").css("top", $scope.x.top -23.9);
		    	$("#menuId").css("position", "absolute");
		    });

		    return this; // Allowing chaining
		};
		
		// Only on touch devices
		if (configuracion.origen.tienda && configuracion.so.ios) {
			setTimeout(function() {
	//			if (esIpad){
				    $("menuId").mobileFix({ // Pass parent to apply to
				        inputElements: "input,textarea,select", // Pass activation child elements
				        addClass: "fixfixed" // Pass class name
				    });
	//			}
			}, 500);
		}
		
		
		$scope.validaContratos = generalService.validaContratos;
		$scope.requiereAval = false;
		$scope.modelVistas = MODEL_VISTAS_JSON;
		
		if( generalService.existeSolicitud($rootScope.solicitudJson) )			
			$scope.requiereAval = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto > MONTO_PP_AVAL ?  true:false;
			
		$scope.goPage = function( pathDestino ){	
			/** INICIA_OS-FLUJO COACREDITADO **/
			if($rootScope.showDatosHogarOS){
				validateServiceOS.path(pathDestino);
			/** TERMINA_OS-FLUJO COACREDITADO **/
			}else
				validateService.path(pathDestino);					
		};	
		
		$scope.inputCode = {
				codeCelular:{
					code: null,
					success:null
				},									
				codeMail:{
					code: null,
					success:null
				},
				solicitudJson: $rootScope.solicitudJson
		}
		
//		$scope.CodigoValidar = function(opcion) {
//			
//			$scope.muestraAlertaCodigo = false;
//			$scope.muestraMensajeCodigo = false;
//	    	var tipoPersona = CLIENTE.id;
//			
//	    	var callModal = function( persona ){
//	    		modalService.codigoModal( null, opcion, persona ).then(
//					function(exito) {
//						$scope.goPage(opcion);
//					}, function(error) {
//						$scope.goPage(opcion);
//					}
//				);
//	    	};
//	    		    		
//		  	if( opcion == validacionPath[SECCION_AVAL].nombrePath )
//		  		tipoPersona = AVAL.id;
//		  				  		
//		  	if( ( $rootScope.solicitudJson.envioCelular == 0 || 
//		  			( $rootScope.solicitudJson.cotizacion.clientes[0].email != "" 
//		  			&& $rootScope.solicitudJson.envioCorreo == 0 ) 
//		  		) && tipoPersona == CLIENTE.id ){
//		  			callModal( tipoPersona );
//		  	}else if( ( $rootScope.solicitudJson.avales[0].envioCelular == 0 || 
//		  				( $rootScope.solicitudJson.avales[0].email != "" 
//		  					&& $rootScope.solicitudJson.avales[0].envioCorreo == 0 ) 
//		  			) && tipoPersona == AVAL.id && $rootScope.solicitudJson.avales[0].presencial == 1 ){
//		  			callModal( tipoPersona );
//		  	}else{
//		  		if( opcion != null && opcion )									
//		  			$scope.goPage(opcion);
//		  	}
//		  	
//		};
		
	});
});