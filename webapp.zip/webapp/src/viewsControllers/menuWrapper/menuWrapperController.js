'use strict';

define(["app"], function (app) {
	app.controller("menuWrapperController", function($timeout,$rootScope, $scope, $location, 
			generalService, modalService, buroService, validateService, solicitudService) {

		$scope.isProduccion=isProduccion;
		$scope.showPage=false;
		$scope.menuList = new Array();	

		$rootScope.encolarFirmasAvisoBuro = false;
		$rootScope.firmaPrivacidad = undefined;
		$rootScope.firmaBuro = undefined;
		$rootScope.firmaCaratula = undefined;
		$rootScope.firmaSolicitud = undefined;
		$rootScope.firmaSeguroCliente = undefined;
		$rootScope.firmaSeguroCarta = undefined;
		$rootScope.firmaAcuseTaz = undefined;
		$rootScope.firmaBienes = undefined;
		
		$rootScope.esValidoFlujoCallCenter = false;
		$rootScope.faseGeneraRechazo = undefined;
		$rootScope.faseGeneraReactivado = undefined;
		$rootScope.faseGeneraMigracionSuc = undefined;
		
		$rootScope.categoriaLineaAux = undefined;
		$rootScope.firmaBuroAux = undefined;
		$rootScope.firmaPrivacidadAux = undefined;
		$rootScope.solicitudJsonAuxLSM = undefined;
		$scope.sucursalBig = SUCURSALES.big_menuWrapper.indexOf($rootScope.sucursalSession.idSucursal);
		$rootScope.esFlujoVentas = ($rootScope.sucursalSession.workstation.indexOf("VTA") != -1)?true:false;

		$scope.estilo = {"padding" : "12px"}
		
		$scope.init=function(){
			if($rootScope.consultaFuncionalidad != null && $rootScope.consultaFuncionalidad != undefined){
				if($rootScope.consultaFuncionalidad.solicitudesNOC != null && $rootScope.consultaFuncionalidad.solicitudesNOC != undefined){
					if($rootScope.consultaFuncionalidad.solicitudesNOC && (VERSION_DESARROLLO || $rootScope.consultaFuncionalidad.versionFront == "" || $rootScope.consultaFuncionalidad.versionFront == VERSION)){
						versionCorrectaNOC();
					}else{
						if(!$rootScope.consultaFuncionalidad.solicitudesNOC)
							versionCorrectaNOC();
						else{
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							modalService.alertModalVersion("Nueva Originación de Crédito", ["La versión utilizada no es la más reciente:",VERSION]);
						}
					}
				}else{
					$rootScope.sucursalSession.muestraBig = true;
					$rootScope.sucursalSession.muestraNoc = false;
					$rootScope.sucursalSession.muestraBigNoc = $rootScope.sucursalSession.muestraBig && $rootScope.sucursalSession.muestraNoc;
					inicializarComponentes();
				}
			}else{
				$rootScope.sucursalSession.muestraBig = true;
				$rootScope.sucursalSession.muestraNoc = false;
				$rootScope.sucursalSession.muestraBigNoc = $rootScope.sucursalSession.muestraBig && $rootScope.sucursalSession.muestraNoc;
				inicializarComponentes();
			}

		
		};			
		
		function versionCorrectaNOC(){
			$scope.showPage=true;
			$rootScope.sucursalSession.muestraBig = true;
			$rootScope.sucursalSession.muestraNoc = $rootScope.consultaFuncionalidad.solicitudesNOC;
			$rootScope.sucursalSession.muestraBigNoc = $rootScope.sucursalSession.muestraBig && $rootScope.sucursalSession.muestraNoc;
			
			// Bandera para esconder la opción de búsqueda.
			var esconderBusqueda = true;
											
			if($rootScope.sucursalSession.muestraBigNoc) {
				esconderBusqueda = false;
			} else {
				if($rootScope.sucursalSession.muestraNoc) {
					esconderBusqueda = false;
				}
			}
			
			// Aquí se hace limpieza del rootScope, al parecer.
			inicializarComponentes();
			
			// Asignación del valor.
			$rootScope.esconderBusqueda = esconderBusqueda;
		};
		
		function inicializarComponentes(){
			if (configuracion.so.windows)
				$rootScope.obtenerClientesConEnviosWV( "liberacion", "onListaClientesRespuesta" );

			generalService.cleanRootScope($rootScope);
			generalService.buildSolicitudJson($rootScope, null);
/** INICIA_OS-FLUJO COACREDITADO **/
			generalService.buildSolicitudOSJson($rootScope, null);
/** TERMINA_OS-FLUJO COACREDITADO **/
			$scope.origen = "WEB";
			if($scope.isTienda){
				$scope.origen = "TIENDA";
			}

			$scope.validaContratos = generalService.validaContratos;
			$scope.requiereAval = false;
			$scope.modelVistas = MODEL_VISTAS_JSON;

			if( generalService.existeSolicitud($rootScope.solicitudJson) )			
				$scope.requiereAval = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto > MONTO_PP_AVAL ?  true:false;

			for (var i = 0;i < $scope.menuList.length; i++){
				if (!$scope.menuList[i].show)
					$scope.menuList.splice(i,1);
			}
			
			menuWrapperList();
			
			$rootScope.waitLoaderStatus = LOADER_HIDE; 	
		}
		
		function menuWrapperList(){
			
			if($rootScope.sucursalSession.muestraBig || $rootScope.sucursalSession.muestraBigNoc) {			
				$scope.menuList.push( 
						{
							texto: "Anaquel De Productos BIG",
							labelAvance: $scope.labelAvance,
							path: '/bigAnaquelProductos',
							image: 'images/menu/anaquelProductos.jpg',
							alt: "Originación",
							estilo: 'opc opDatosPersonales',
							estilo2: 'background-color: #47AD98',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: false,
							bloqueo: false,
							prioridad: 1
						}
				);

				$scope.menuList.push( 
						{
							texto: "Crédito Nómina",
							labelAvance: $scope.labelAvance,
							path: '/bigNomina',
							image: 'images/menu/iconoNomina2.jpg',
							alt: "Originación",
							estilo: 'opc opDatosPersonales',
							estilo2: 'background-color: #E2A14F',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: true,
							bloqueo: false,
							prioridad: 2
						}
				);
				
				$scope.menuList.push( 
						{
							texto: "Beneficios Nómina Azteca",
							labelAvance: $scope.labelAvance,
							path: '/nominaAzteca',
							image: 'images/menu/btnBeneficios1.png',
							alt: "Originación",
							estilo: 'opc opAdelantoNominca',
							estilo2: 'background-color: #9a5cb4',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: false,
							bloqueo: false,
							prioridad: 3
						}
				);
				
				$scope.menuList.push( 
						{
							texto: "Crédito Pensionados",
							labelAvance: $scope.labelAvance,
							path: '/bigPensionados',
							image: 'images/menu/iconoPensionados2.png',
							alt: "Originación",
							estilo: 'opc opDatosPersonales',
							estilo2: 'background-color: #F09F62',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: true,
							bloqueo: false,
							prioridad: 4
						}
				);
				
				$scope.menuList.push( 
						{
							texto: "Alta de Cliente",
							labelAvance: $scope.labelAvance,
							path: '/bigAltaCliente',
							image: 'images/menu/iconoAlta2.jpg',
							alt: "Alta de Cliente",
							estilo: 'opc opDatosHogar',
							estilo2: 'background-color: #D54B27',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: false,
							bloqueo: false,
							prioridad: 5
						}
				);
				
				$scope.menuList.push( 
						{
							texto: "Crédito Nómina Portabilidad",
							labelAvance: $scope.labelAvance,
							path: '/bigNominaPortabilidad',
							image: 'images/menu/opPortabilidad.jpg',
							alt: "Originación",
							estilo: 'opc opDatosPersonales',
							estilo2: 'background-color: #4cc37d',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: true,
							bloqueo: false,
							prioridad: 6
						}
				);
				
				$scope.menuList.push( 
						{
							texto: "Portafolio Financiero BIG",
							labelAvance: $scope.labelAvance,
							path: '/bigPortafolioFinanciero',
							image: 'images/menu/opPortafolio.png',
							alt: "Originación",
							estilo: 'opc opDatosPersonales',
							estilo2: 'background-color: #48CD76',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: true,
							bloqueo: false,
							prioridad: 7
						}
				);
				
				$scope.menuList.push( 
						{
							texto: "Adelanto de Nómina",
							labelAvance: $scope.labelAvance,
							path: '/adelantoNomina',
							image: 'images/menu/opIngresosGastos.jpg',
							alt: "Originación",
							estilo: 'opc opNominaAzteca',
							estilo2: 'background-color: #44B764',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: true,
							bloqueo: false,
							prioridad: 7
						}
				);
			} 

			$scope.menuList.push( 
					{
						texto: "Liberación de Créditos BIG",
						labelAvance: $scope.labelAvance,
						path: '/liberacionCreditosBIG',
						image: 'images/menu/opObligado.jpg',
						alt: "Originación",
						estilo: 'opc opLiberacionCreditosBIG',
						estilo2: 'background-color: #25b79c',
						showAlerta: false,
						showAuth: false,
						numAlerta: '0',
						tituloAlert: '',
						messageAlert: '',
						showMessageAlert: false,
						messageAuth: '',
						showMessageAuth: false,
						show: false,
						bloqueo: false,
						prioridad: 8
					}
			);

			if($rootScope.userSession.idPerfil != 735 && $rootScope.userSession.idPerfil != 122 && (!$rootScope.sucursalSession.muestraBig || $rootScope.sucursalSession.muestraBigNoc)) {
				$scope.menuList.push( 
						{
							texto: "Originación",
							labelAvance: $scope.labelAvance,
							path: '/simulador',
							image: 'images/menu/opOriginacion.jpg',
							alt: "Originación",
							estilo: 'opc opDatosPersonales',
							estilo2: '',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: true,
							bloqueo: false,
							prioridad: 1
						}
				);
				
				if($rootScope.consultaFuncionalidad.solicitudesEAZ){
					$scope.menuList.push( 
							{
								texto: "Empresario Azteca",
								labelAvance: $scope.labelAvance,
								path: '/empresarioAzteca',
								image: 'images/menu/empresarioazteca.jpg',
								alt: "Originación",
								estilo: 'opc opDatosPersonales',
								estilo2: 'background-color: #003e6f',
								showAlerta: false,
								showAuth: false,
								numAlerta: '0',
								tituloAlert: '',
								messageAlert: '',
								showMessageAlert: false,
								messageAuth: '',
								showMessageAuth: false,
								show: true,
								bloqueo: false,
								prioridad: 2
							}
					);
				}

				if($rootScope.userSession.idPuesto == PUESTO_GERENTE && $rootScope.userSession.idPerfil == PUESTO_GERENTE){
					$scope.menuList.push( 
							{
								texto: "Revisión de Expedientes",
								labelAvance: $scope.labelAvance,
								path: '/buzonExpedientes',
								image: 'images/menu/img_digitalizacion.jpg',
								alt: "Revisión de Expedientes",
								estilo: 'opc opDatosEmpleo',
								estilo2: '',
								showAlerta: false,
								showAuth: false,
								numAlerta: '0',
								tituloAlert: '',
								messageAlert: '',
								showMessageAlert: false,
								messageAuth: '',
								showMessageAuth: false,
								show: true,
								bloqueo: false,
								prioridad: 3
							}
					);
				}

				$scope.menuList.push( 
						{
							texto: "Captación",
							labelAvance: $scope.labelAvance,
							path: '/captacion',
							image: 'images/menu/img_captacion.jpg',
							alt: "Captación",
							estilo: 'opc opIngresosGastos',
							estilo2: '',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: false,
							bloqueo: false,
							prioridad: 4
						}
				);
				
				if($rootScope.consultaFuncionalidad.habilitarCambaceo){
					$scope.menuList.push( 
							{
								texto: "Cambaceo",
								labelAvance: $scope.labelAvance,
								path: '/cambaceo',
								image: 'images/menu/iconCambaceo.png',
								alt: "Originación",
								estilo: 'opc opCambaceo',
								estilo2: '',
								showAlerta: false,
								showAuth: false,
								numAlerta: '0',
								tituloAlert: '',
								messageAlert: '',
								showMessageAlert: false,
								messageAuth: '',
								showMessageAuth: false,
								show: true,
								bloqueo: false,
								prioridad: 7
							}
					);
				}
				

				$scope.menuList.push( 
						{
							texto: "Administración de Tarjetas",
							labelAvance: $scope.labelAvance,
							path: '/tarjetas',
							image: 'images/menu/opAdministradorTarjetas.jpg',
							alt: "Administración de Tarjetas",
							estilo: 'opc opContratos',
							estilo2: '',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: false,
							bloqueo: false,
							prioridad: 5
						}
				);

				$scope.menuList.push( 
						{
							texto: "Documentos pendientes de envío",
							labelAvance: $scope.labelAvance,
							path: '/encolado',
							image: 'images/menu/opDocumentosEncolados.jpg',
							alt: "Documentos Encolados",
							estilo: 'opc opDatosHogar',
							estilo2: '',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: true,
							bloqueo: false,
							prioridad: 6
						}
				);

				$scope.menuList.push( 
						{
							texto: "Mis Solicitudes",
							labelAvance: $scope.labelAvance,
							path: '/visorAsesor',
							image: 'images/menu/img_mis_documentos.png',
							alt: "Resumen de Solicitudes",
							estilo: 'opc opReferencias',
							estilo2: '',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: true,
							bloqueo: false,
							prioridad: 7
						}
				);

				$scope.menuList.push( 
						{
							texto: "Bitácora",
							labelAvance: $scope.labelAvance,
							path: '/bitacora',
							image: 'images/menu/opBitacora.jpg',
							alt: "Bitacora",
							estilo: 'opc opBitacora',
							estilo2: '',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: true,
							bloqueo: false,
							prioridad: 9
						}
				);
				if (PROMOCION_RECOMIENDA && ($rootScope.consultaFuncionalidad.solicitudesSIPA || $rootScope.canalesPRG($rootScope.sucursalSession.idCanal))){
					$scope.menuList.push( 
							{
								texto: "Recomienda y gana",
								labelAvance: $scope.labelAvance,
								path: '/recomienda',
								image: 'images/menu/iconPaga.png',
								alt: "Bitacora",
								estilo: 'opc opPaga',
								estilo2: '',
								showAlerta: false,
								showAuth: false,
								numAlerta: '0',
								tituloAlert: '',
								messageAlert: '',
								showMessageAlert: false,
								messageAuth: '',
								showMessageAuth: false,
								show: true,
								bloqueo: false,
								prioridad: 10
							}
					);
				}
			}
		if($rootScope.userSession.idPerfil != 735 && $rootScope.userSession.idPerfil != 122 ){
			$scope.menuList.push( 
					{
						texto: "Liberación de Línea de Crédito Banco Azteca Móvil",
						labelAvance: $scope.labelAvance,
						path: '/codigoSolicitud',
						image: 'images/menu/liberacion_credito2.png',
						alt: "Resumen de Solicitudes",
						estilo: 'opc opDatosPersonales',
						estilo2: 'background-color: #25B79C',
						showAlerta: false,
						showAuth: false,
						numAlerta: '0',
						tituloAlert: '',
						messageAlert: '',
						showMessageAlert: false,
						messageAuth: '',
						showMessageAuth: false,
						show: true,
						bloqueo: false,
						prioridad: 8
					}
			);
			if($rootScope.consultaFuncionalidad.recompraHabilitada){
				$scope.menuList.push( 
						{
							texto: "Recompra",
							labelAvance: $scope.labelAvance,
							path: '/recompra',
							image: 'images/menu/liberacion_credito2.png',
							alt: "Resumen de Solicitudes",
							estilo: 'opc opDatosPersonales',
							estilo2: 'background-color: #25B79C',
							showAlerta: false,
							showAuth: false,
							numAlerta: '0',
							tituloAlert: '',
							messageAlert: '',
							showMessageAlert: false,
							messageAuth: '',
							showMessageAuth: false,
							show: true,
							bloqueo: false,
							prioridad: 2
						}
				);
			}
		}	
		
		/** 
		 * Oculta todas las secciones excepto una, la de Portabilidad, si es un asesor financiero.
			**/
			if($scope.sucursalBig == -1){
				for (var i = 0;i < $scope.menuList.length; i++){
					if ($rootScope.userSession.idPerfil == 122){
						if( $scope.menuList[i].texto !== "Crédito Nómina Portabilidad" )
						$scope.menuList[i].show = false;
					}
				}
			}
			
			/**
			 * Oculta todas las opciones que redirijan a otro portal cuando estes de un equipo de ventas.
			 */
			if($rootScope.sucursalSession.workstation.indexOf("VTA") != -1){
				for (var i = 0;i < $scope.menuList.length; i++){
					$scope.menuList[i].show = false;
					if( $scope.menuList[i].texto == "Originación" || $scope.menuList[i].texto == "Documentos pendientes de envío" ||
							$scope.menuList[i].texto == "Cambaceo" || $scope.menuList[i].texto == "Mis Solicitudes"){
						$scope.menuList[i].show = true;
					}
				}
			}
		}
		
		$scope.onListaClientesRespuesta = function(data){
			try{

				if( data.codigo == RESPONSE_CODIGO_EXITO_IPAD ){					
					for (var i = 0;i < $scope.menuList.length; i++){
						if ($scope.menuList[i].path == '/encolado'){
							var num  = 0;
							angular.forEach(data.clientes, function(cte, key){
								num += cte.pending;
							});							
							if( num > 0){
								$scope.menuList[i].showAlerta = true;
								$scope.menuList[i].numAlerta = num;
								$scope.menuList[i].showMessageAlert = true;
								$scope.menuList[i].messageAlert = "Tiene documentos pendientes por enviar";
								break;
							}														
						}							
					}																					 
				} 
			} catch(e) {}
		}

		$scope.goPage = function( pathDestino ){					
			validateService.path(pathDestino);					
		};


		$scope.inputCode = {
				codeCelular:{
					code: null,
					success:null
				},									
				codeMail:{
					code: null,
					success:null
				},
				solicitudJson: $rootScope.solicitudJson
		}

		$scope.CodigoValidar = function(opcion) {
			$scope.opcion = opcion;

			if($rootScope.solicitudJson.envioCelular == 0 || ($rootScope.solicitudJson.cotizacion.clientes[0].email != "" && $rootScope.solicitudJson.envioCorreo == 0)){
				modalService.codigoModal().then(
						function(exito) {
							$scope.goPage(opcion);
						}, function(error) {
							$scope.goPage(opcion);
						});
			}else
				$scope.goPage(opcion);


		};

		$scope.tarjetas = function(){

			if (isProduccion){
				var URL = "https://200.38.122.132:8443/tarjetasWeb/indexWindows.jsp";
			}else{
				var URL = "http://10.51.81.99:8087/tarjetasWeb/indexWindows.jsp";
			}
			window.location.assign(URL);
		}

		$scope.captacion = function (){
			if (isProduccion){
				var URL=PORTAL_CAPTACION;				
			}else{
				var URL=PORTAL_CAPTACION;				
			}
			window.location.assign(URL);
		}

		$scope.bigNomina = function (){
			$rootScope.guardaDatosIpad("idProducto", 10);
			$rootScope.guardaDatosIpad("tipoCredito", 0);
			$timeout( function(){
				var URL=PORTAL_BIG_NOMINA;
				window.location.assign(URL);
			}, 500);
		}
		
		$scope.bigPensionados = function (){
			$rootScope.guardaDatosIpad("idProducto", 11);	
			$rootScope.guardaDatosIpad("tipoCredito", 1);
			$timeout( function(){
				var URL=PORTAL_BIG_NOMINA;
				window.location.assign(URL);
			}, 500);
		}
		
		$scope.adelantoNomina = function (){
			$rootScope.guardaDatosIpad("idProducto", 5);
			$rootScope.guardaDatosIpad("tipoCredito", 2);
			$timeout( function(){
				var URL=PORTAL_BIG_NOMINA;
				window.location.assign(URL);
			}, 500);
		}
		
		$scope.liberacionCreditosBIG = function (){
			$rootScope.guardaDatosIpad("idProducto", 25);
			$rootScope.guardaDatosIpad("tipoCredito", 25);
			$timeout( function(){
				var URL=PORTAL_LIBERACION_CREDITOS_BIG;
				window.location.assign(URL);
			}, 500);
		}
		
		$scope.nominaAzteca = function (){
			$rootScope.guardaDatosIpad("idProducto", 10);
			$rootScope.guardaDatosIpad("tipoCredito", 3);
			$timeout( function(){
				var URL=PORTAL_BIG_NOMINA;
				window.location.assign(URL);
			}, 500);
		}
		
		$scope.bigAltaCliente = function (){
			$rootScope.guardaDatosIpad("idProducto", 11);		
			$timeout( function(){
				var URL=PORTAL_BIG_ALTA_CLIENTE;
				window.location.assign(URL);
			}, 500);
		}
		
		$scope.bigNominaPortabilidad = function (){
			$rootScope.guardaDatosIpad("tipoProceso", "portabilidad");				
			$timeout( function(){
				var URL=PORTAL_BIG_NOMINA_PORTABILIDAD;
				window.location.assign(URL);
			}, 500);
		}
		
		$scope.bigPortafolioFinanciero = function (){
			$rootScope.guardaDatosIpad("tipoProceso","portafolio");				
			$timeout( function(){
				var URL=PORTAL_BIG_NOMINA_PORTABILIDAD;
				window.location.assign(URL);
			}, 500);
		}
		
		$scope.emprezarioAzteca = function (){
			$timeout( function(){
				var URL=PORTAL_EMPRESARIO_AZTECA;
				window.location.assign(URL);
			}, 500);
		}
		
		$scope.portalRecompra = function (){
			$timeout( function(){
				if(configuracion.so.windows)
					window.location.assign(PORTAL_RECOMPRA);
				else
					$rootScope.executeAction( "recompra", "respuestaRecompra", {nombre:"reLoadWebViewRecompra"} );
			}, 500);
		}

		$scope.location = function( pathDestino ){
			switch(pathDestino) {
			case '/captacion':
				$scope.captacion();
				break;
			case "/tarjetas":
				$scope.tarjetas();
				break;
			case "/bigNomina":
				$scope.bigNomina();
				break;
			case "/bigPensionados":
				$scope.bigPensionados();
				break;
			case "/liberacionCreditosBIG":
				$scope.liberacionCreditosBIG();
				break;
			case "":
				break;
			case "/nominaAzteca":
				$scope.nominaAzteca();
				break;
			case "/bigAltaCliente":
				$scope.bigAltaCliente();
				break;
			case "/bigNominaPortabilidad":
				$scope.bigNominaPortabilidad();
				break;
			case "/bigPortafolioFinanciero":
				$scope.bigPortafolioFinanciero();
				break;
			case "/empresarioAzteca":
				$scope.emprezarioAzteca();
				break;
			case "/recompra":
				$scope.portalRecompra();
				break;
			default:
				if(pathDestino == "/simulador"){
					/*\Se agrega un evento para la bitacora\*/
					//(Originación)
						$rootScope.addEvent( BITACORA.SECCION.originacion.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, 0, BITACORA.SECCION.originacion.guardarEnBD );				
					/*\Se agrega un evento para la bitacora\*/
				}else if(pathDestino == "/cambaceo"){	
					/*\Se agrega un evento para la bitacora\*/
					//(Cambaceo)
						$rootScope.addEvent( BITACORA.SECCION.cambaceo.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, 0, BITACORA.SECCION.cambaceo.guardarEnBD );
				}
				generalService.locationPath(pathDestino);	
			}
		};

		$scope.parImpar = function(numero) {
			if(numero % 2 == 0) {
				return true;
			}
			else {
				return false;
			}
			if (numero == 0) {
				return true;
			}
			console.log("Numeoro " + numero);
		}

	});
});