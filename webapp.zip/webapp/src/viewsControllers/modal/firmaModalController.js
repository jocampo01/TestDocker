'use strict';

define(["app"], function (app) {
	

	var firmaModalController = function ($scope, $rootScope, $location, $timeout,  modalService,  loginService, sessionService, securityService, generalService) {				
		
//		$rootScope.waitLoaderStatus = LOADER_HIDE; 			
		
		$scope.canvas = '<canvas type="ipad" id="canvas1" drawing1 opcional="false" value="{{firma1}}" ng-mouseup="click=false"   ng-mousedown="click=true" ng-mousemove="funcionMover()" style="background-color: white;" >'

		$scope.guardar = function(){
			if($scope.firma1){
				$scope.GetData1();
				$scope.imgFirma = $scope.imageData1;
				$scope.confirm($scope.imgFirma)
			}
		}
	    	    	   
		$scope.funcionMover=function(){
			if($scope.click)
				$scope.firma1='true';			
		}
		$scope.increment = function(id) {
			if ($scope.id == "canvas1") {
				$scope.firma1 = true;
			}

			$scope.$digest();
		};
	};
	
	app.controller('firmaModalController', [ '$scope', '$rootScope', '$location', '$timeout',  'modalService',  'loginService', 'sessionService', 'securityService', 'generalService', firmaModalController ]);		
	
	
});