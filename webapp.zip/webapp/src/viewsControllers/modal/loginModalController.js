'use strict';

define(["app"], function (app) {
	

	var loginModalController = function ($scope, $rootScope, $timeout,  modalService,  loginService, sessionService, securityService, generalService) {				
		
		$scope.loginRequest = { username: "", password: "" } 
		$scope.loading = false; 
		$rootScope.sessionid = null;
								
		
		
		$scope.simulador = function(){
			$rootScope.inSession = false;			
			generalService.buildSolicitudJson($rootScope, null);
			
			for (var prop in $rootScope) {
			    if (prop.substring(0,1) !== '$' && typeof $rootScope[prop] != 'function') {
			        delete $rootScope[prop];
			    }
			}
			
			
			window.location.replace(window.location.protocol+"//"+window.location.host + window.location.pathname);
			$scope.closeThisDialog();
		};
		
		$scope.login = function(){									
							
			$rootScope.waitLoaderStatus = LOADER_SHOW; 			    						   
			$scope.c = 0;
			loginService.login($scope.loginRequest).then(
						function(data){ //EXITO
								console.log("LOGIN  OK");
								$rootScope.waitLoaderStatus = LOADER_HIDE; 	
			                			
			                	
			                	if(data.data.codigo == RESPONSE_CODIGO_EXITO){
			                		$scope.c = data.data.respuesta.ticketSession.codigo;
			                		
			                		if(data.data.respuesta.ticketSession.codigo == HTTPCODE_OK){			                			
			                			
			                			securityService.setKeys(data.headers().key, data.headers().initial_vector);
			                			
			                			for( var i in window.routes ) 	            																						
								                window.routes[i].requireLogin = false;
			                			
			                			
			                			localStorage['paths'] = JSON.stringify(window.routes);			                						                											         			                			
			                			generalService.setArrayValue('ticketTarjeta',data.data.respuesta.ticketSession.ticket);       			
			                			sessionService.getObjSessionId( data.data.respuesta.ticketSession.ticket ).then(
			                						function(exito){ //EXITO		
			                							
			                		                	if(exito.data.codigo == RESPONSE_CODIGO_EXITO){
			                		                		$rootScope.inSession = true;
			                		                		$rootScope.userSession = exito.data.respuesta.datosUsuario;  
			                		                		$rootScope.sucursalSession = exito.data.respuesta.datosSucursal;
			                		                		
			                		                		var key = generalService.keyEmpBase64();
			                		                		securityService.setKeys(key, key);
			                		                		
			                		                		/**
											    		 * Servicio para consulta la funcionalidad por sucursal
											    		 * Se ejecuta cuando se Loguean en el Portal Web desde la modal de Login.
											    		 * La regla para este caso es que solo hay caso de exito
											    		 **/
			                		                		loginService.consultaFuncionalidad({idPais:exito.data.respuesta.datosSucursal.idPais, idSucursal:exito.data.respuesta.datosSucursal.idSucursal, idCanal:exito.data.respuesta.datosSucursal.idCanal}).then(
		                		                				function(objetoFuncionalidad) {
		                		                					if(objetoFuncionalidad.data.codigo == RESPONSE_CODIGO_EXITO) {
		                		                						var jsonResponseFuncionalidad = JSON.parse(objetoFuncionalidad.data.respuesta);
		                		                						if(jsonResponseFuncionalidad.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
		                		                							/**
					    												 * En caso de exito se mapea el objeto "consultaFuncionalidad" y continua al Menu
					    												 **/
		                		                							$rootScope.consultaFuncionalidad =  jsonResponseFuncionalidad.data;
		                		                						}else{
		                		                						}
		                		                					}else{
		                		                					}
		                		                				}, function(error) {		                		                					
		                		                				}
			                		                		);
			                		                	}else
			                		                		console.log("error = "+exito.data.descripcion);
			                		                				                		                					                		                					                		               
			                		                			                		                				                					                				                		                			                
			                	    				}, function(error){ //ERROR 				                					
			                	    	                console.log(error);	                    	                    		                    		                  
			                	    				}
			                			);			                						                						                						                	
			                			
	
			                		}else			                	
			                			modalService.alertModal("Error "+data.data.respuesta.ticketSession.codigo, [data.data.respuesta.ticketSession.status]);			                		
			                			
			                		
			                	}else
			                		modalService.alertModal("Error", [generalService.displayMessage(data.data.descripcion)]);
			                	
			                		
			                	generalService.setFlagLogin(false);
			                	console.log("close loginOn  "+generalService.getFlagLogin());
			                	$scope.closeThisDialog();	                				                					                				                	
			                			                	
						}, function(error){ //ERROR
							$rootScope.waitLoaderStatus = LOADER_HIDE;
			                    console.log(error);
			                    if(error.status != undefined)
			                    	alert("Error "+ error.status +"\n"+ error.statusText);
			                    else if(error.message != undefined)
			                    	alert("Error: \n"+error.message);
			                    
			                    $scope.closeThisDialog();
			                    		                   
						}
					);
			
			
	    };
	    	    	   
	};
	
	
	app.controller('loginModalController', [ '$scope', '$rootScope',  '$timeout',  'modalService',  'loginService', 'sessionService', 'securityService', 'generalService', loginModalController ]);		
	
	
});