'use strict';

define(["app"], function (app) {

    app.controller("messageModalController", function ( $scope ) {
    	
    			
		$scope.closeModal = function(){							
				$scope.closeThisDialog();
			
		};
		

	});
	
	
});