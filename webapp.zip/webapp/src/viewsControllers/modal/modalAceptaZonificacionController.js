'use strict';

define(["app"], function (app) {

    app.controller("modalAceptaZonificacionController", function ( $scope, $rootScope, $timeout, documentosService, expedienteService, generalService) {
    	
    });
});