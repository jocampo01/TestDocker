'use strict';

define(["app"], function (app) {

    app.controller("modalCambaceoController", function ( $scope, $rootScope, $timeout, documentosService, expedienteService, generalService, generalServiceOS,clienteUnicoService,sessionService, solicitudService,modalService) {
    	
    	
    		var codigoRespuestaHomonimos = null;
    		
	    $scope.mostrarResultadoBuro = false;
	    $scope.mostrarClientePresente = false;
	    var cusArray = null;
	    	
	    	$scope.init = function(codigosBuro){
	    			
	    		if( codigosBuro)
	    			$scope.respuestaBuro(codigosBuro);
	    		else
	    			$scope.marcasPrecalificado();
	    			
	
	 	}
    	
	    	$scope.respuestaBuro = function(codigosBuro){
	    		
	    		$scope.mostrarResultadoBuro = true;
	    		
				switch( codigosBuro ){
				
				case 1390:
					$scope.mensaje = "<div style='with:80%; font-size: 1.2em;' >Lo sentimos informale a tu cliente que por el momento no es candidato para otorgarle un Crédito en Banco Azteca <br></div>"; 
					break;
				case 1391:
					var edad;
					var edadAnio = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento.split("/")[2];
					var edadMes = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento.split("/")[1];
					var edadDia = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento.split("/")[0];
					edad = calcularEdad(edadAnio, edadMes, edadDia);
					
//					if($rootScope.solicitudJson.idProducto == 24 && edad>=21 && $rootScope.consultaFuncionalidad.habilitarPDRPrestamos){
//						$scope.mensaje = "<div style='text-align: justify;'> Contacta a tu cliente e infórmale que con un buen comportamiento de pago con nosotros, puede construir un buen historial de crédito."
//							+ "<br><br>"
//							+ "Le ofrecemos un  <b>Préstamo personal</b> de $2000 a $4000 pesos presentando garantías o un Coacreditado"
//				                    + "<br> </div>";
//					}else{
						$scope.mensaje = "<div style='text-align: justify;'> Indícale a tu cliente que tenemos una oferta disponible para él."
							+ "<br>Para continuar con su solicitud es necesario que acuda a sucursal con los siguientes documentos: <br><br>"
							+ "<ul style='margin-left: 60px;'>"
		                    + 	"<li>1. &nbsp; &nbsp; INE/IFE o Pasaporte</li>"
		                    + 	"<li>2. &nbsp; &nbsp; Comprobante de domicilio no mayor a 3 meses (sólo si su <br> &nbsp; &nbsp; &nbsp; &nbsp; domicilio no coincide con el registrado en su identificación)</li>"	
		                    + 	"<li>3. &nbsp; &nbsp; Comprobante de ingresos (sólo en caso de declarar ingresos <br> &nbsp; &nbsp; &nbsp; &nbsp; comprobables)</li>"	
		                    + "</ul> <br> </div>";   
//					}
					
					break;
				case 1392:
					$scope.mensaje = "<div style='text-align: justify;'> Indícale a tu cliente que tenemos una oferta disponible para él."
						+ "<br>Para continuar con su solicitud es necesario que acuda a sucursal con los siguientes documentos: <br><br>"
						+ "<ul style='margin-left: 60px;'>"
	                    + 	"<li>1. &nbsp; &nbsp; INE/IFE o Pasaporte</li>"
	                    + 	"<li>2. &nbsp; &nbsp; Comprobante de domicilio no mayor a 3 meses (sólo si su <br> &nbsp; &nbsp; &nbsp; &nbsp; domicilio no coincide con el registrado en su identificación)</li>"	
	                    + 	"<li>3. &nbsp; &nbsp; Comprobante de ingresos (sólo en caso de declarar ingresos <br> &nbsp; &nbsp; &nbsp; &nbsp; comprobables)</li>"	
	                    + "</ul> <br> </div>"; 
					break;
				case 1393:
					$scope.mensaje = "<div style='text-align: justify;'> Indícale a tu cliente que tenemos una oferta disponible para él."
						+ "<br>Para continuar con su solicitud es necesario que acuda a sucursal con los siguientes documentos: <br><br>"
						+ "<ul style='margin-left: 60px;'>"
	                    + 	"<li>1. &nbsp; &nbsp; INE/IFE o Pasaporte</li>"
	                    + 	"<li>2. &nbsp; &nbsp; Comprobante de domicilio no mayor a 3 meses (sólo si su <br> &nbsp; &nbsp; &nbsp; &nbsp; domicilio no coincide con el registrado en su identificación)</li>"	
	                    + 	"<li>3. &nbsp; &nbsp; Comprobante de ingresos (sólo en caso de declarar ingresos <br> &nbsp; &nbsp; &nbsp; &nbsp; comprobables)</li>"	
	                    + "</ul> <br> </div>";  
					break;
				}
	    	}
    	
    	
	    	$scope.marcasPrecalificado = function(){
	    		
	    		$scope.mostrarClientePresente = true;
	    		
				switch( $rootScope.solicitudJson.marca ){
				
				case STATUS_SOLICITUD.generada.marca.verificacionCambaceo :
					$scope.mensaje = " ¿Tu cliente se encuentra presente para continuar con la solicitud?"; 
					break;
				case STATUS_SOLICITUD.generada.marca.rescateCambaceo:
					if($rootScope.rescatePPFaseI || $rootScope.rescatePPFaseII){
						$scope.mensaje = " ¿Tu cliente se encuentra presente para continuar con la solicitud?";
					}else{
						$scope.mensaje = " ¿Tu cliente se encuentra presente para continuar con la solicitud?";
					}
					break;
				case STATUS_SOLICITUD.preautorizada.marca.inmediatoCambaceo:
					$scope.mensaje = " ¿Tu cliente se encuentra presente para continuar con la solicitud?"; 
					break;
				case STATUS_SOLICITUD.pendienteProceso.marca.alternativaCambaceo:
					$scope.mensaje = " ¿Tu cliente se encuentra presente para continuar con la solicitud?"; 
					break;
					case STATUS_SOLICITUD.rechazada.marca.rechazoCambaceo:
						$scope.mostrarClientePresente = false;
						$scope.mostrarResultadoBuro = true;
						$scope.mensaje = " <div style='with:80%; font-size: 1.2em;' >Lo sentimos informale a tu cliente que por el momento no es candidato para otorgarle un Crédito en Banco Azteca <br></div> "; 
						break;
				}
	    	}
	    	
	    	$scope.confirm = function(){
	    		(generalService.isEmpty($rootScope.solicitudJson.idSolicitud))?$scope.terminarMensaje():consultarHomonimos();
	    	}
	    	
	    	$scope.terminarMensaje = function(){
	    		generalService.cleanRootScope($rootScope);
				generalServiceOS.cleanRootScope($rootScope);
				generalService.buildSolicitudJson($rootScope, null);
				generalService.buildSolicitudOSJson($rootScope, null);
			    generalService.locationPath("/simulador");
			    $scope.closeThisDialog("fin");
	    	}
	    	
	    	var consultarHomonimos = function(){
	    		$rootScope.waitLoaderStatus = LOADER_SHOW;	
	    		
	    		var tipoBus = $rootScope.consultaFuncionalidad.habilitarBusquedaFoneticaCambaceo;
	    		
	    		if( TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) != -1 )
					tipoBus='1';
	    		
	    		var x = {
						solicitudJson: JSON.stringify($rootScope.solicitudJson),
						tipoBusqueda: tipoBus,
						tipoIdentificacion: 0,
						statusOcr: 0,
						folioDigitalizacion: "" 
				}
				clienteUnicoService.getHomonimosCambaceo( x ).then(
						function(data){
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								
								var j = JSON.parse(data.data.respuesta.solicitudJson);	
								$scope.jsondata = j.data;

								switch(j.codigo){
									case 2:								
										configuracion.estatus.opcion=0;
																		
										j.data.cotizacion.clientes[0].nombre = j.data.cotizacion.clientes[0].nombre.replace("\.","");;
										j.data.cotizacion.clientes[0].apellidoPaterno = j.data.cotizacion.clientes[0].apellidoPaterno.replace("\.","");;
										j.data.cotizacion.clientes[0].apellidoMaterno = j.data.cotizacion.clientes[0].apellidoMaterno.replace("\.","");;
										
										j.data.cotizacion.clientes[0].nombre = j.data.cotizacion.clientes[0].nombre.replace("-"," ");
										j.data.cotizacion.clientes[0].apellidoPaterno = j.data.cotizacion.clientes[0].apellidoPaterno.replace("-"," ");
										j.data.cotizacion.clientes[0].apellidoMaterno = j.data.cotizacion.clientes[0].apellidoMaterno.replace("-"," ");
										
										$rootScope.solicitudJson = j.data;	
										guardarInfoCambaceo();									
										break;
									case 126:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["No es posible continar con el proceso la solicitud se encuantra rechazada por 30 días"],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 316:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso "+j.codigo, [j.data],"Aceptar","/simulador",null,null,null);
										$scope.closeThisDialog("fin");
										break;
									case 307:
											cusArray = new Array();		
											var cusArrayHuella=new Array();
											var tieneHuella = false;									
											angular.forEach( j.data, function(cu_huella){
												cusArray.push(cu_huella.cu);
												if(cu_huella.huella == 1){
													cusArrayHuella.push(cu_huella.cu);
													tieneHuella = true;		
												}
											});
											
											if(tieneHuella){
												codigoRespuestaHomonimos = j.codigo;
												validaHuella(cusArrayHuella);
											}else
												flujoCallCenter();	
										break;
									case 384:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["El solicitante no tiene cuentas de inversión"],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 308:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["Error al consultar homónimos."],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 310:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["No se encontró coincidencia con huella"],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 311:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["Homónimos con LCR bloqueada"],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 312:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["Homónimos con LCR Autrizada"],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 313:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["Homónimos con LCR en investigación"],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 314:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["Homónimos con LCR rechazada o cancelada"],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 443:
									case 521:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["Indícale al cliente que por disposiciones de Banco Azteca no es posible brindarle el servicio solicitado. No es necesario que lo reportes con soporte Técnico."],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 661:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["Por favor verifica los datos de tu cliente debido a que no se encuentra en el Registro Nacional de Población."],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 760:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["Infórmale a tu cliente que para continuar con su solicitud", "es necesario proporcionar un número celular o fijo."],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 319:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["Ha ocurrido un error al consultar homonimos"],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 663:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["Por favor, verifíca los datos de tu cliente ya que estos no se encuentran en el registro del Instituto Nacional Electoral."],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 666:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["Infórmale a tu cliente que su credencial no está vigente, es necesario que presente otra identificación"],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 667:					
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["La clave de elector no es válida"],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 241:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["El número celular proporcionado se encuentra asociado a " +"otro cliente, por favor, captura un nuevo número."], "Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 906:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["Los parametros recibidos no son validos"],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									case 4003:
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Aviso ", ["Solicitud de cambaceo en proceso"],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
									default:	
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.message("Error: " + j.codigo, [j.descripcion],"Aceptar","/simulador");
										$scope.closeThisDialog("fin");
										break;
								}	
							}else{
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.loggerIpad("Respuesta Servicio getHomonimos", generalService.displayMessage(data.data.descripcion));
								$rootScope.message("Error " + data.data.codigo, [generalService.displayMessage(data.data.descripcion)], "Aceptar","/simulador");
								$scope.closeThisDialog("fin");
							}
//							if(j.codigo != 307)
//								$scope.closeThisDialog();
							
						}, function(error){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$rootScope.message("Error ", ["Se presentó un error al consultar el servicio de homónimos"], "Aceptar","/simulador");
							$scope.closeThisDialog("fin");
						}
					);
	    		
	    	}
	    	
		 	var validaHuella = function(cuArray){
		 		$rootScope.waitLoaderStatus = LOADER_SHOW;
		 		if (configuracion.origen.tienda )
					$rootScope.verificarHuella( 'fondoDivId', 'responseVerificarHuellaIpadC', cuArray );
				
				else{
					if( generalService.isProduccion() ){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						modalService.huellaModal("bgAzul");
					}else{
						var response = { 
								codigo : VALIDA_HUELLA_RESPONSE.EXITO,
								matches: cuArray
								//matches: ["1-53-365-3608","1-1-4737-239","1-1-4737-244","1-1-4737-267","1-1-4737-268","1-1-4737-273","1-1-4737-282","1-1-4737-286","1-1-4737-289","1-1-4737-312"]
						}	
						$scope.responseVerificarHuellaIpadC(response);
					}
						
				}
		 	};
		 	
		 	
			$scope.responseVerificarHuellaIpadC = function( response ){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.loggerIpad("responseVerificarHuellaIpadC", null, response);
				
				switch(response.codigo){
					case VALIDA_HUELLA_RESPONSE.EXITO:	
						
						if(codigoRespuestaHomonimos == 307){
						
							if(Array.isArray(response.matches)){
								response.matches = $.unique(response.matches);
							}else{
								response.matches = response.matches.replace(/(\[)|(\]| )/g,'').split(",");
							}
						
							getHomonimosBsqFonetica(response.matches);
							
						}
											
						break;
											
					case VALIDA_HUELLA_RESPONSE.ERROR:
						$rootScope.message("Error "+response.codigo,[ "Error al validar la huella."], "Aceptar","/simulador");
						break;
						
					case VALIDA_HUELLA_RESPONSE.ERROR_COMPONENTE:

						$rootScope.message("Error "+response.codigo,[ "Error en componente de huella."], "Aceptar","/simulador");
						break;
						
					case VALIDA_HUELLA_RESPONSE.COMPONENTE_CANCELADO_PORUSR:	
						$rootScope.message("Error "+response.codigo,[ "Validación de huella cancelado por el usuario"], "Aceptar","/simulador");
						break;
						
					case VALIDA_HUELLA_RESPONSE.NO_SE_ENCONTARON_HUELLAS:
						flujoCallCenter();											
						break;
						
					case VALIDA_HUELLA_RESPONSE.NO_HAY_COINCIDENCIAS:
						flujoCallCenter();	
						break;
						
					default:
						$rootScope.message( "Componete de huella", ["Código "+response.codigo+" no definido. "], "Aceptar","/simulador");		
						break;
						
				}
										
				$scope.closeThisDialog("fin");				
		};
		
		function flujoCallCenter(){
			generalService.esValidoFlujoCallCenter($rootScope.solicitudJson);
			generalService.setArrayValue("pasoCallCenter", 'init')
			generalService.setArrayValue("encolarImagenes", true);
			generalService.setArrayValue("cusArray", cusArray);
			generalService.setArrayValue("pathOrigen", 'simulador');
			generalService.locationPath("/callCenter");
			
		}
		
		function getHomonimosBsqFonetica(ctesUnicosArray) { // DATOS HOMONIMOS
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			
			var requestJson = {
					tienda: $rootScope.sucursalSession.idSucursal,
					arrayCtesUnicos: ctesUnicosArray
			};

			clienteUnicoService.getHomonimosBsqFonetica(requestJson).then(
					function(data) {
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jsonResponse = JSON.parse(data.data.respuesta);
							
							if(jsonResponse.data != null){
								var clienteUnico = jsonResponse.data[0].fipais+ "-" + jsonResponse.data[0].ficanal + "-" + jsonResponse.data[0].fisucursal + "-" + jsonResponse.data[0].fifolio;
							}

							if(jsonResponse.codigo == HOMONIMOS.bloqueo 
									|| jsonResponse.codigo == HOMONIMOS.autSinLiberar 
									|| jsonResponse.codigo == HOMONIMOS.investigacion 
									|| jsonResponse.codigo == HOMONIMOS.autyLiberada) {

								var jsonActualizaMarca = {
										jsonSolicitud: $rootScope.solicitudJson, 
										marca: 1021,
										cu: jsonResponse.data[0].fipais+ "-" + jsonResponse.data[0].ficanal + "-" + jsonResponse.data[0].fisucursal + "-" + jsonResponse.data[0].fifolio
									};

								actualizaMarcaSol(jsonActualizaMarca);
							} else if(jsonResponse.codigo == HOMONIMOS.noCoincide 
									|| jsonResponse.codigo == HOMONIMOS.bloqueo 
									|| jsonResponse.codigo == HOMONIMOS.autSinLiberar 
									|| jsonResponse.codigo == HOMONIMOS.investigacion 
									|| jsonResponse.codigo == HOMONIMOS.rechazo 
									|| jsonResponse.codigo == HOMONIMOS.autyLiberada 
									|| jsonResponse.codigo == HOMONIMOS.sinCredito) {
								generalService.homonimosData=jsonResponse;
								generalService.locationPath("/homonimos");
							} else if(jsonResponse.codigo == HOMONIMOS.homonimoReact) {
								/*
								 * Se encontró homónimo con Línea de Crédito para flujo de 
								 * Reactivados.
								 * Antes se usaba la variable CLIENTE_REACTIVADO_LCR.
								 */
								generalService.homonimosData=jsonResponse;
								generalService.locationPath("/homonimos");
							} else if(jsonResponse.codigo == HOMONIMOS.previoLCR) {								
								/*
								 * Infórmale a tu cliente que no es posible generar su solicitud de 
								 * crédito en esta sucursal debido a que ya tiene una LCR asociada. 
								 * La tienda que le corresponde es: {sucursal}.
								 */
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								// CLIENTE_REACTIVADO_GESTORA
//I-MODIFICACION (mensaje para pre aprobados TDC)
								if($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
									$rootScope.message("Aviso ", 
											["Notifícale a tu Cliente que tiene una tarjeta de crédito pre-aprobada, debe tramitarla en su Sucursal Gestora", "Cliente Único: " + clienteUnico], "Aceptar", "/simulador", null, null, null
										);
								}else{
//I-MODIFICACION (mensaje para pre aprobados TDC)
								$rootScope.message("Aviso ", 
									[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], "Aceptar" ,"/simulador", null, null, null
								);
								}
							} else if(jsonResponse.codigo == HOMONIMOS.empleado) {
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message("Aviso", ["Lo sentimos, no es posible otorgar créditos a empleados."], 
									"Aceptar", "/simulador");
							} else if(jsonResponse.codigo == HOMONIMOS.empleadoRechazado){
								$rootScope.message("Aviso ", ["Lo sentimos, cliente dado de baja por malos tratos."], "Aceptar","/simulador",null, null, null, null);
							}else if(jsonResponse.codigo == HOMONIMOS.lcrCancelada){								
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message("Aviso ", ["Infórmale a tu cliente que ya tiene una línea de crédito cancelada por lo que no es posible generar una nueva.", "No es necesario comunicarte a soporte técnico", "Cliente Único: " + clienteUnico], "Aceptar","/simulador", null, null, null);
							} else if(jsonResponse.codigo == HOMONIMOS.previoPP) {
								/*
								 * Infórmale a tu cliente que no es posible generar su solicitud de 
								 * crédito en esta sucursal debido a que ya tiene un producto de 
								 * Presta Prenda asociado. La tienda que le corresponde es: 
								 * {sucursal}. 
								 */
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message("Aviso ", 
									[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], "Aceptar","/simulador", null, null, null
								);
							}else {
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								
								switch(jsonResponse.codigo) {
									case HOMONIMOS.errorConsulta:
										// Ha ocurrido un error al consultar homónimos.
										$rootScope.message("Error", 
											[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], 
											"Aceptar","/simulador", null, null, null
										);
										break;
									case HOMONIMOS.waitXtime:
										/* Favor de esperar {días} días para iniciar una nueva 
										 * solicitud.
										 */
										$rootScope.message("AVISO", 
											[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], 
											"Aceptar","/simulador", null, null, null
										);
										break;
									case HOMONIMOS.homonimoSucc:
										/*
										 * Se encontró homónimo con alguna solicitud en proceso. 
										 * Favor de acudir a la sucursal {sucursal}.
										 */
										$rootScope.message("AVISO", 
												[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], 
												"Aceptar","/simulador", null, null, null
											);
										break;
									case HOMONIMOS.homonimoExtr:
										// Se encontró homónimo con cliente extranjero.
										$rootScope.message("AVISO", 
												[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], 
												"Aceptar","/simulador", null, null, null
											);
										break;
									case HOMONIMOS.exEmpleadoMalosTermi:
										// Se encontró homónimo con cliente extranjero.
										$rootScope.message("AVISO", 
												[jsonResponse.descripcion, "Cliente Único: " + clienteUnico], 
												"Aceptar","/simulador", null, null, null
											);
										break;
									default:
										$rootScope.message("Datos erróneos", 
											["error: " + jsonResponse.codigo], 
											"Aceptar","/simulador", null, null, null, 
											"GENERAL", "ERROR GENERAL"
										);
								}
							}
						} else {
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							
							$rootScope.loggerIpad("Respuesta Servicio getHomonimosBsqFonetica", 
								generalService.displayMessage(data.data.descripcion));
							$rootScope.message("Error " + data.data.codigo, 
								[generalService.displayMessage(data.data.descripcion)], "Aceptar");
						}
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE; 
					}
			);
		};
		
		var actualizaMarcaSol = function(jsonActualizaMarca){
			solicitudService.actualizaMarca(jsonActualizaMarca).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						$rootScope.message("Aviso ", ["Infórmale a tu cliente que ya cuenta con una línea de crédito, por lo cual, no es posible continuar con la solicitud.",
							"Cliente Único: " + jsonActualizaMarca.cu], "Aceptar", "/", null, null, null);
					} else {
						$rootScope.loggerIpad("Respuesta Servicio actualizaMarca", generalService.displayMessage(data.data.descripcion));
						$rootScope.message("Error " + data.data.codigo, [generalService.displayMessage(data.data.descripcion)], "Aceptar");
					}								
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 
	                $rootScope.message("Aviso ", ["Infórmale a tu cliente que ya cuenta con una línea de crédito, por lo cual, no es posible continuar con la solicitud.",
	                	"Cliente Único: " + jsonActualizaMarca.cu], "Aceptar", "/", null, null, null);
				}
			);
		}
		
		var guardarInfoCambaceo = function (){
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			var jsonSolicitud = { jsonSolicitud: JSON.stringify($rootScope.solicitudJson)}; 
			
			solicitudService.guardarDatosCambaceo(jsonSolicitud).then(
						function(data) {
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var j = JSON.parse(data.data.respuesta);							
								if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									switchearMarcas();
								}else{
									$rootScope.message("Nueva Originación Centralizada", 
											["Algo ha ido terriblemente mal al guardar la información del cambaceo.", "Favor de volver a entrar a la sección"], 
											"Aceptar"
										);
								}
							}
						}, function(error) {
							$rootScope.waitLoaderStatus = LOADER_HIDE;
						}
				);
			
		
		}
		
		var switchearMarcas = function(){
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			var marca = $rootScope.solicitudJson.marca;
							
			switch(marca){
				case 5012:
					var jsonSolicitud = {
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							idSeguimiento: STATUS_SOLICITUD.generada.id,
							marca: STATUS_SOLICITUD.generada.marca.enProceso
					};
					actualizarSolicitudCambaceo(jsonSolicitud);
					break;
				case 5013:
					$scope.idMarca = generalService.consultaHistoricoMarcas([STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescate,
						         					    					  STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescateFDos,
						        											  STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescateFCuatro,
						        											  117,93,120,123,126,5026,5027,5029,5030,5031]);
					var jsonSolicitud = {
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						idSeguimiento: STATUS_SOLICITUD.generada.id,
						marca: $scope.idMarca
					};
					if($scope.idMarca != 0)
						actualizarSolicitudCambaceo(jsonSolicitud);
					else{
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Nueva Originación Centralizada", 
								["Error del sistema, favor de volver a intentarlo nuevamente."], 
								"Aceptar","/cambaceo"
							);
					}	
					break;
				case 5014:
					var jsonSolicitud = {
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							idSeguimiento: STATUS_SOLICITUD.preautorizada.id,
							marca: STATUS_SOLICITUD.preautorizada.marca.fico
					};
					actualizarSolicitudCambaceo(jsonSolicitud);
					break;
				case 5015:
					var jsonSolicitud = {
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						idSeguimiento: STATUS_SOLICITUD.pendienteProceso.id,
						marca: STATUS_SOLICITUD.generada.marca.enProceso
					};
					actualizarSolicitudCambaceo(jsonSolicitud);
					break;
			}
		};
		
		var actualizarSolicitudCambaceo = function(jsonSolicitud){
			
			
			solicitudService.actualizarSolicitud(jsonSolicitud).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);							
							if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){									
								var marca = $rootScope.solicitudJson.marca;
								switch(marca){
								case 5012:
									$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.generada.id;
									$rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.enProceso;
									break;
								case 5013:
									$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.generada.id;
									$rootScope.solicitudJson.marca = $scope.idMarca;
									break;
								case 5014:
									$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.preautorizada.id;
									$rootScope.solicitudJson.marca = STATUS_SOLICITUD.preautorizada.marca.fico;
									break;
								case 5015:
									$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.pendienteProceso.id;
									$rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.enProceso;
									break;
								}
								
								$rootScope.solicitudJson.contratos.contrato[0].statusFirma = STATUS_CONTRATO.SIN_FIRMA;
								$rootScope.solicitudJson.contratos.contrato[1].statusFirma = STATUS_CONTRATO.SIN_FIRMA;
								$rootScope.solicitudJson.consultaBuro = 0;
								$rootScope.solicitudJson.consultaMatriz = 0;
								
								$scope.closeThisDialog("recargaCambaceo");
								
								// TODO Detonar el modal de Firma Única. modalService.modalFirmaUnica().then();
							}else{
								$rootScope.message("Nueva Originación Centralizada", 
										["Algo ha ido terriblemente mal al cambiar los status.", "Favor de volver a entrar a la sección"], 
										"Aceptar"
									);
							}
						}
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
					}
			);
			
		}
		
		/*********************************************************************
		Función que calcula la edad, recibe el año, mes y dia de nacimiento y
		devuelve la edad
		/********************************************************************/
		var calcularEdad = function (edadAnio, edadMes, edadDia) {
		    var hoy = new Date();
		    if(edadAnio == 0 || edadMes == 0 || edadDia == 0 )
		    	return 0;
		    var fechaNacimiento = new Date();
		    fechaNacimiento.setFullYear(edadAnio, edadMes-1, edadDia);
		    var edad = hoy.getFullYear() - fechaNacimiento.getFullYear();
		    var m = hoy.getMonth() - fechaNacimiento.getMonth();
		    if (m < 0 || (m === 0 && hoy.getDate() < fechaNacimiento.getDate())) {
		        edad--;
		    }
		    return edad;
		}
		
    });
});