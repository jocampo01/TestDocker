'use strict';

define(["app"], function (app) {

    app.controller("modalCotizadorTDCController", function ( $scope, $rootScope, $timeout, generalService,sessionService,constantesTDC,$compile, $filter, solicitudService, tarjetaService) {
    
		$scope.nombreClienteTDC = $rootScope.solicitudJson.cotizacion.clientes[0].nombre + " " + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno + " " + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno;
		$scope.cuClienteTDC = $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico;
		var jsonStatus = JSON.parse($rootScope.resultadoConsultaLCR.data);
		$scope.capacidadPagoTDC = jsonStatus.capacidadDePagoDisponible;
		$scope.aceptaTDC = false;
		$scope.valorSlider;
		
		$scope.nombre              = generalService.getDataInput("SIMULADOR","NOMBRE"                ,null         );
		$scope.textoCu 			   = generalService.getDataInput("SURTIMIENTO","TEXTO CLIENTE UNICO","VALOR");
		
		$scope.etiquetaNombreCliente = "Nombre del cliente: ";
		$scope.etiquetaCU = "Cliente Único: ";
		$scope.etiquetaCDPDisponible = "Capacidad de pago disponible: ";
		
		$scope.etiquetaCotizadorLimitesCredito = "Cotizador de límites de crédito TDC para";
		$scope.etiquetaClientesExistentes = "clientes existentes CREDIMAX";
		$scope.etiquetaLimiteCredito = "¿Cuál es el límite de crédito deseado para la TDC?";
		$scope.etiquetaCapPagoOcupada = "La capacidad de pago ocupada por TDC será de: ";
		
		$scope.init=function(){
			var limiteCredito = $rootScope.solicitudJson.observaciones;
			////se inicializa la variable que guarda la capacidad de pago necesaria con la minima permitida
//			$scope.cpNecesaria = constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[0].capacidadPago;
			/*for(var i = 0; i < constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC.length ; i++){
				if($scope.capacidadPagoTDC >= constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC.length - 1].capacidadPago){
					$scope.maxSlider = constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC.length - 1].limiteCredito;
					break;
				}else{
					if(i != constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC.length - 1){
						if($scope.capacidadPagoTDC >= constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[i].capacidadPago &&
								$scope.capacidadPagoTDC < constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[i+1].capacidadPago){
							$scope.maxSlider = constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[i].limiteCredito;
							break;
						}
					}
				}
			}
			
			if($scope.maxSlider > limiteCredito){
				for(var i = 0; i < constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC.length ; i++){
					if(limiteCredito >= constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC.length - 1].limiteCredito){
						$scope.maxSlider = constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC.length - 1].limiteCredito;
						break;
					}else{
						if(i != constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC.length - 1){
							if(limiteCredito >= constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[i].limiteCredito &&
									limiteCredito < constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[i+1].limiteCredito){
								$scope.maxSlider = constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[i].limiteCredito;
								break;
							}
						}
					}
				}
			}
			
			setTimeout(function(){$scope.sliderTDC(constantesTDC.INICIALIZADORES_TERMOMETRO.montoInicio, $scope.maxSlider, constantesTDC.INICIALIZADORES_TERMOMETRO.saltosSlider, $scope.valorSlider, '.amountTDC div')},500);*/
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			var jsonRequest = {
					capacidadPagoDisp: $scope.capacidadPagoTDC,
					limiteCredito: limiteCredito,
					campana: $rootScope.solicitudJson.campana
		 		};
//	 		var jsonRequest = {
//	 				capacidadPagoDisp: 230,
//	 				limiteCredito: 1500,
//	 				campana: "TDCORO_CON"
//	 		};
			solicitudService.validarLimiteEscClientes(jsonRequest).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if( data.data.codigo == RESPONSE_CODIGO_EXITO ){		 						 						 					
							var responseJson = JSON.parse(data.data.respuesta);
							if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
								$scope.resultados = JSON.parse(responseJson.data);
								
								if($scope.resultados.length > 0){
									$scope.cpNecesaria = $scope.resultados[0].capacidadPago;
									constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC = $scope.resultados;
									$scope.valorSlider = $scope.resultados[0].limiteCredito;
									setTimeout(function(){$scope.sliderTDC($scope.resultados[0].limiteCredito, $scope.resultados[$scope.resultados.length-1].limiteCredito, constantesTDC.INICIALIZADORES_TERMOMETRO.saltosSlider, $scope.valorSlider, '.amountTDC div')},500);
								}else{
									$scope.closeThisDialog();
									$rootScope.waitLoaderStatus = LOADER_SHOW;
				     				 solicitudService.cancelarSolicitud({idSolicitud:$rootScope.solicitudJson.idSolicitud}).then(
				     						 function(data){
				     							$rootScope.waitLoaderStatus = LOADER_HIDE;
				     							 if(data.data.codigo == RESPONSE_CODIGO_EXITO){
				     								 $rootScope.message("AVISO", ["Informa a tu cliente que estamos cuidando su historial crediticio, por el momento no podemos procesar su solicitud"],"Aceptar","/simulador");
				     							 }else{
				     								 $rootScope.message("Aviso ", ["Error al cancelar la solicitud"],"Aceptar",null,null,null,null);
				     							 }
				     						 }, function(error){
				     							 $rootScope.waitLoaderStatus = LOADER_HIDE;
				     							 $rootScope.message("Aviso ", ["Error al cancelar la solicitud"],"Aceptar",null,null,null,null);	
				     						 });
								}
								
							}else if(responseJson.codigo == ESC_CTE_CDP_NOVALIDA){
								$scope.closeThisDialog();
								$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar",null,null,null,null);
								$rootScope.waitLoaderStatus = LOADER_SHOW;
			     				 solicitudService.cancelarSolicitud({idSolicitud:$rootScope.solicitudJson.idSolicitud}).then(
			     						 function(data){
			     							$rootScope.waitLoaderStatus = LOADER_HIDE;
			     							 if(data.data.codigo == RESPONSE_CODIGO_EXITO){
			     								 $rootScope.message("AVISO", ["Informa a tu cliente que estamos cuidando su historial crediticio, por el momento no podemos procesar su solicitud"],"Aceptar","/simulador");
			     							 }else{
			     								 $rootScope.message("Aviso ", ["Error al cancelar la solicitud"],"Aceptar",null,null,null,null);
			     							 }
			     						 }, function(error){
			     							 $rootScope.waitLoaderStatus = LOADER_HIDE;
			     							 $rootScope.message("Aviso ", ["Error al cancelar la solicitud"],"Aceptar",null,null,null,null);	
			     						 });
							}else{
								$scope.closeThisDialog();
								$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar",null,null,null,null);
							}
						}else{
							$scope.closeThisDialog();
							$rootScope.message("Aviso ", [ERROR_SERVICE],"Aceptar",null,null,null,null);
						}
					}, function(error){  
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$scope.closeThisDialog();
//						generalService.locationPath( "/simulador" );
					}	
			);
			
			
		}
		
		$scope.aceptarTDC = function(){
			var CU = $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico;
			validaHuella(CU);
		}
		
		function validaHuella(cuArray){
			
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) > -1){
				$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
			}else if(configuracion.origen.tienda){
				$rootScope.waitLoaderStatus = LOADER_SHOW;							
				$rootScope.verificarHuella( 'fondoDivId', 'responseVerificarHuellaIpad', [cuArray]);
			}else if(generalService.isProduccion()){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				modalService.huellaModal("bgAzul");
			}else{
				$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
			}
		};

		$scope.responseVerificarHuellaIpad = function( response ){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			$rootScope.loggerIpad("responseVerificarHuellaIpad", null, response);

			switch(response.codigo){
				case VALIDA_HUELLA_RESPONSE.EXITO: 
					guardaSolicitud(); 
				break;
	
				case VALIDA_HUELLA_RESPONSE.ERROR:
					$rootScope.message("Error "+response.codigo,[ "Error al validar la huella."], "Aceptar");
				break;
	
				case VALIDA_HUELLA_RESPONSE.ERROR_COMPONENTE:
					$rootScope.message("Error "+response.codigo,[ "Error en componente de huella."], "Aceptar");
				break;
	
				case VALIDA_HUELLA_RESPONSE.COMPONENTE_CANCELADO_PORUSR:
				break;
	
				default:
					$scope.endCotizador = false;
					$rootScope.message( "Componete de huella", ["Código "+response.codigo+" no definido. "], "Aceptar"); 
				break;
			}
		};
		
		function guardaSolicitud(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			var jsonTemporal = $rootScope.solicitudJson;

			if(jsonTemporal.banderaIngresos == 1)
				jsonTemporal.tarjetasCredito.tarjetaOro.limiteCreditoComprobable = $scope.nuevoMontoSinFormato
			if(jsonTemporal.banderaIngresos == 0)
				jsonTemporal.tarjetasCredito.tarjetaOro.limiteCreditoNoComprobable = $scope.nuevoMontoSinFormato
				
			jsonTemporal.banderaOfertaCP = 1;
			jsonTemporal.tarjetasCredito.tarjetaOro.capacidadPagoDisponible = $scope.capacidadPagoTDC;
			
			var solicitudJsonString = generalService.delete$$hashKey(jsonTemporal);
			
			solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: SECCION_TAG_TARJETAS } ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
							var responseJson = JSON.parse(data.data.respuesta);
							if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								console.log("OK");
								$scope.closeThisDialog();
								$rootScope.solicitudJson = responseJson.data;
							}else if(responseJson.codigo == BURO_OTRA_SUCURSAL_CERCANA){
								$scope.closeThisDialog();
								$rootScope.message(	"Aviso", [ responseJson.descripcion ],"Aceptar", null,  null , null,null);
							}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){
								var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
								$scope.closeThisDialog();
								$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
							}else{
								if(responseJson.codigo == ERROR_SOL_RECHAZADA){
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$scope.closeThisDialog();
									$rootScope.message(	"Error en solicitud", [ "La solicitud no puede ser modificada debido a que se encuentra Cancelada o Rechazada." ],
											"Aceptar", "/simulador",  null,null,buildJsonDefault);
								}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
									$scope.closeThisDialog();
								}else{
									$scope.closeThisDialog();
									$rootScope.message("Aviso",["Error al guardar cotización (sección 9). Código [" + responseJson.codigo +"] no identificado"], "Aceptar", null, null, null);
								}
							}
						}else{
							var mensaje = "";
							if(data.data.descripcion == null || data.data.descripcion == undefined || data.data.descripcion == "")
								mensaje = "No se obtuvo una respuesta éxitosa al guardar la sección.";
							else
								mensaje = data.data.descripcion;
							
							$rootScope.message("Aviso",[generalService.displayMessage(mensaje)], "Aceptar");
							
						}
							
						
					}, function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Aviso",["Error en el servicio al guardar solicitud sección."], "Aceptar", null, null, null);
					}
			);
		}
	 	
	 	function obtenerAnchoSlider(){
			var ancho = document.getElementById('sliderTDC');
	 		$scope.anchoDivSlider = ancho.offsetWidth;
		}
	 	
	 	$scope.sliderTDC=function(min, max, step, value, indicador){
			var totalPasos = (max-min)/step;				//Cantidad de pasos
				obtenerAnchoSlider();
			var pasos = $scope.anchoDivSlider/totalPasos;	//Ancho del paso en pixeles
			
			function init(ui){
				/* Actualizar valor */
				$scope.valor = getValor(ui, value);
				
				formato($scope.valor);
				
				/* Position */
				var pos = position(ui, value);
				$(indicador).css('left', pos);
				$compile($("#nuevoMonto").html($scope.nuevoMonto).contents())($scope);
				equivalencias();
				var montoTemporal = $filter('currency')($scope.cpNecesaria, "$")
				$compile($("#cpNecesaria").html(montoTemporal).contents())($scope);
			}

			$( "#sliderTDC" ).slider({
				min: min,
				max: max,
				value: value,
				range: "min",
				step: step,
				animate: true,
				create: function( event, ui ){ 
					init(ui); 
					indicadores();
				},
				slide: function(event, ui){ 
					init(ui); 
				}
			});

			/* Coloca las lineas indicadoras */
			function indicadores(){
				/* Elementos li */
				var lista = $(indicador).siblings('ul');
				for (var i = 1; i <= totalPasos; i++) {
					if( i!=totalPasos ){
						lista.append('<li>|</li>');
					}else{
						lista.append('<li><table><tr><td class="tLeft">|</td><td class="tRight">|</td></tr></table></li>');
					}
				};
				
				/* Ancho de los li */
				lista.children().each(function(index, el) {
					var finalW = 99/totalPasos;
					$(this).css('width', finalW + '%');
				});
			}

			/* Regresa valor de selección en formato monetareo */
			function formato(valor){
				var moneda =  valor;
				$scope.nuevoMontoSinFormato = moneda
				var formato = '$' + moneda.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
				$(indicador).text(formato);
				$scope.nuevoMonto = formato;
			}

			/* Regresa la posición del indicador de acuerdo al valor de selección */
			function position(ui, value){
				obtenerAnchoSlider();
				pasos = $scope.anchoDivSlider/totalPasos;
				var valor = getValor(ui, value);
				var actual = (valor-min)/step;
				var finalPaso = (pasos*actual)-(39*0.5);
				return finalPaso;
			}

			/* Función que regresa el default del valor */
			function getValor(ui, value){
				var valor;
				if(ui.value == null){
					valor = value;
				}else{
					valor = ui.value;
				}
				$scope.valorSlider = valor;
				return valor;
			}
		}
		
		$scope.actualizaMonto = function(){
	 		$scope.nuevoMonto = $("#sliderTDC").slider("value");
	 	};
	 	
	 	$scope.cerrarModalTDC=function(){
	 		$scope.closeThisDialog();
	 	};
	 	
	 	function equivalencias(){
	 		for(var i = constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC.length - 1; i >= 0 ; i--){
				if($scope.nuevoMontoSinFormato == constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[i].limiteCredito){
					$scope.cpNecesaria = constantesTDC.TERMOMETRO_LINEA_CREDITO_TDC[i].capacidadPago;
					break;
				}
			}
	 	}
	 	
	 	$scope.noAceptarTDC = function(){
			var cteUco = $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico.split("-");
	 		$rootScope.waitLoaderStatus = LOADER_SHOW;
//			var cteUco = ("1-1-2325-130809").split("-");
			var x = {	pais: cteUco[0],
					 	canal: cteUco[1],
					 	sucursal: cteUco[2],
					 	folio: cteUco[3],
					 	statusPromo: QUEMAR_FOLIO_STATUS.aceptado
					 	};
		    tarjetaService.quemarFolioPreaprobado(x).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var j = JSON.parse(data.data.respuesta);
								if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									j = JSON.parse(j.data);
									if(j.issue.issue == false){
//										$scope.closeThisDialog();
										$rootScope.message("AVISO", [j.lstResponse[0].respuesta],"Aceptar","/ochoPasos",null,null,null);
									}else{
//					                	$scope.closeThisDialog();
										$rootScope.message("AVISO", [j.issue.fieldIssues[0].message],"Aceptar",null,null,null,null);
									}
								}else{
									
								}
							}else{
//			                	$scope.closeThisDialog();
								$rootScope.message("AVISO", ["Error al quemar el folio"],"Aceptar",null,null,null,null);
							}
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE;
//			                $scope.closeThisDialog();
			                $rootScope.message("Aviso",["Error al quemar el folio"], "Aceptar", null, null, null);
						}
			);
			
	 	}
	 	
	 	$scope.consultarPreaprobados = function(){
	 		$rootScope.waitLoaderStatus = LOADER_SHOW;
			 var x = { 
					 folio: folio
					 ,producto: ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)) ? $scope.productoSeleccionado : $rootScope.solicitudJson.idProducto
					 };
		    tarjetaService.consultaPreaprobadosXCU(x).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var j = JSON.parse(data.data.respuesta);
								if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO || (j.codigo == RESPONSE_REAC_EXITO && $rootScope.consultaFuncionalidad.campanaReactivado ) || j.codigo == HOMONIMOS.homonimoReact){
/*I-MODIFICAICON PREAPROBADOS 
* se valida respuesta de folio de campañas winback, invitados y preaprobados 
*/									var codigo = "";
									if (j.codigo == RESPONSE_REAC_EXITO || j.codigo == HOMONIMOS.homonimoReact ){
										codigo = j.codigo;
										j = j.data;
										j.lstResponse = [];
										j.lstResponse.push({campana: j.campana});
									}else{
/*F-MODIFICAICON PREAPROBADOS */
										j = JSON.parse(j.data);
									}
									
									/*I-MODIFICAICON PREAPROBADOS CAPTACION*/
									if($rootScope.campanasConvivencia(j.lstResponse[0].campana)){
										$scope.moverDatos(j, codigo);
									}else if( $rootScope.campanasPreaprobadosCaptacion(j.lstResponse[0].campana)){
										if($rootScope.canalesCaptacion($rootScope.sucursalSession.idCanal)){
//											Si entra aquí sabememos que en campana tiene "PREAPROB"
											$scope.moverDatos(j, codigo);
										}else{
											modalService.alertModal("AVISO",["Los clientes Pre Aprobados de Captacion se deberan ingresar por la opcion disponible en ADN."],"Aceptar",null,null,null,null);
										}
									}else{
										$scope.moverDatos(j, codigo);
									}
									/*F-MODIFICAICON PREAPROBADOS CAPTACION */
									
								}else if(j.codigo == HOMONIMOS.previoLCR){
									$rootScope.message("Aviso ", 
											[j.descripcion, "Cliente Único: " + parseInt($scope.foliioPre.folio.substr(0,2)) + "-"+ parseInt( $scope.foliioPre.folio.substr(2,2)) + "-" + parseInt( $scope.foliioPre.folio.substr(4,4))  + "-" +  parseInt( $scope.foliioPre.folio.substr(8,8))], "Aceptar", null, null, null, null
										);
									limpiarDatosSolicitudTDCOro(true);
								}else{
									limpiarDatosSolicitudTDCOro(true);
									if($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
										modalService.alertModal("AVISO",[j.descripcion],"Aceptar","verdeCred","verdeCred","verdeCred",null);
									}else{
										modalService.alertModal("AVISO",["El cliente único capturado no corresponde a un pre aprobado / inactivo, por favor, captura los datos del cliente para comenzar con su proceso de crédito."],"Aceptar",null,null,null,null);
									}
								}
							}else{
								limpiarDatosSolicitudTDCOro(true);
								if($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
									modalService.alertModal("AVISO",[data.data.descripcion],"Aceptar","verdeCred","verdeCred","verdeCred",null);
								}else{
									modalService.alertModal("AVISO",["El cliente único capturado no corresponde a un pre aprobado / inactivo, por favor, captura los datos del cliente para comenzar con su proceso de crédito."],"Aceptar",null,null,null,null);
								}
							}
							
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 
			                validateService.error(error);
							
						}
					);
	 	}
	 	
    });
});