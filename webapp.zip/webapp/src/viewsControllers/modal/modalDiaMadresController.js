'use strict';

define(["app"], function (app) {

    app.controller("modalDiaMadresController", function ( $scope, $rootScope, $timeout, documentosService, expedienteService, generalService, solicitudService) {
    	
    	$scope.mensajeCuerpo = "";
    	$scope.mensajePie = "";
    	
	    	$scope.init = function(cuerpo, pie){
	    		$scope.mensajeCuerpo = cuerpo;
	        	$scope.mensajePie = pie;
	 	}

    });
});