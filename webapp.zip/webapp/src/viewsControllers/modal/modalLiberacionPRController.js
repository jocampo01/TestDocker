'use strict';

define(["app"], function (app) {

    app.controller("modalLiberacionPRController", function ( $scope, $rootScope, $timeout, documentosService, expedienteService, generalService, solicitudService) {
    	
    	$scope.cargarMensaje = "";
    	
	    	$scope.init = function(producto){
	    		if( producto)
	    			$scope.leyendaProducto(producto);
	    		else
	    			$scope.leyendaProducto(21);
	 	}
    	
	    	$scope.leyendaProducto = function(producto){
	    		switch(producto){
	    			case PRODUCTOS.consumo.ID.valor: $scope.cargarMensaje = "<div style='text-align: center;'><b>En Banco Azteca le decimos que SÍ a la vida que quieres.</b><br/> <br/>"
						+ "Tienes un crédito aprobado por $6,000,  a un plazo de 54 semanas, con un enganche de 30%. <br/><br/>"
			            + "</div>";
		    			break;
	    			case PRODUCTOS.italika.ID.valor: $scope.cargarMensaje = "<div style='text-align: center;'><b>En Banco Azteca le decimos que SÍ a la vida que quieres.</b><br/> <br/>"
						+ "Tienes un crédito aprobado por $21,250,  a un plazo de 102 semanas, con un enganche de 30%. <br/><br/>"
			            + "</div>";
	    			break;
	    			case PRODUCTOS.telefonia.ID.valor: if(generalService.consultaHistoricoMarcas([STATUS_SOLICITUD.generada.marca.prodResTelefoniaConOS])!=0){
	    				
										    				$scope.cargarMensaje = "<div style='text-align: center;'><b>En Banco Azteca le decimos que SÍ a la vida que quieres.</b><br/> <br/>"
																+ "Tienes un crédito aprobado por $4,000,  a un plazo de 54 semanas, con un enganche de 10%. <br/><br/>"
													            + "</div>";
										    				
	    												}else if(generalService.consultaHistoricoMarcas([STATUS_SOLICITUD.generada.marca.prodResTelefoniaSinOSSegundaOferta])!=0){
	    													
	    													$scope.cargarMensaje = "<div style='text-align: center;'><b>En Banco Azteca le decimos que SÍ a la vida que quieres.</b><br/> <br/>"
																+ "Tienes un crédito aprobado por $4,000,  a un plazo de 54 semanas, con un enganche de 30%. <br/><br/>"
													            + "</div>";

														}else if(generalService.consultaHistoricoMarcas([STATUS_SOLICITUD.generada.marca.prodResTelefoniaSinOS])!=0){
															
															$scope.cargarMensaje = "<div style='text-align: center;'><b>En Banco Azteca le decimos que SÍ a la vida que quieres.</b><br/> <br/>"
																+ "Tienes un crédito aprobado por $1,800,  a un plazo de 54 semanas, con un enganche de 10%. <br/><br/>"
													            + "</div>";
														}
	    			break;
	    			default: $scope.cargarMensaje = "<div style='text-align: center;'><b>En Banco Azteca le decimos que SÍ a la vida que quieres.</b><br/> <br/>"
								+ "Tienes un crédito aprobado por $6,000,  a un plazo de 54 semanas, con un enganche de 30%. <br/><br/>"
					            + "</div>";
	    		}
	    	}

    });
});