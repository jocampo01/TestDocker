/**
 * 
 */'use strict';

define(["app"], function (app) {
	
	app.controller('modalMensajePreaprobadosController', function($rootScope, $scope, tarjetaService, solicitudService) {
		
		$scope.respuestas=[
		                   {
		                     idRespuesta:3,
		                     nombre:"Llamada del asesor"
		                   },
		                   {
		                	   idRespuesta:4,
		                     nombre:"En el ticket al realizar un abono o deposito"
		                   },
		                   {
		                	   idRespuesta:5,
		                     nombre:"Al realizar una remesa"
		                   },
		                   {
		                	   idRespuesta:6,
		                     nombre:"Por disposición de efectivo"
		                   },  
		                   {
		                	   idRespuesta:7,
		                     nombre:"Consulta de saldos y movimientos"
		                   }
		                 ];
		$scope.respuestaSeleccionada=0;
		$scope.respuestaDonde={
				"id":0
		}
		$scope.showPage=false;
		
		$scope.init=function(){
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			
			$scope.tituloHeader				=	"Crédito Pre-aprobado";
			$scope.textoPreguntaCliente		=	"¿Tu cliente sabia que tenia un crédito Pre-aprobado?";
			$scope.textoContinuar			=	"Continuar";
			$scope.textoNo					=	"No";
			$scope.textoSi					=	"Si";
			$scope.seleccioneOpcion			= 	"Seleccione una opción";
		};
		
		$scope.getBoton = function(respuestaDonde){
			if(respuestaDonde == 1){
				$scope.respuestaDonde.id=0;
				$scope.textoContinuar = "Continuar";
			}else
				$scope.textoContinuar = "Guardar";
		}
		
		$scope.continuar = function(){
			var fipreguntaid = 0;
			var firespuestaid = 0;
			if($scope.respuestaSeleccionada == 1){
				fipreguntaid = 2;
				firespuestaid = 0;
			}else{
				fipreguntaid = 2;
				firespuestaid = $scope.respuestaDonde.id.idRespuesta;
			}
				
			var jsonRequest = {				
						fcsolicitudid:$rootScope.solicitudJson.idSolicitud,
						fipaisid:$rootScope.solicitudJson.idPais,
						ficanalid:$rootScope.solicitudJson.idCanal,
						fisucursalid:$rootScope.solicitudJson.idSucursal,
						fipreguntaid:fipreguntaid,
						firespuestaid:firespuestaid,
						fcrespuestatxt:"" 
					};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
		    tarjetaService.guardarEncuestaPreaprobados(jsonRequest).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							marcarEncuentaRespondida($rootScope.solicitudJson);
						}, function(error){
							$rootScope.waitLoaderStatus = LOADER_HIDE; 
				        	modalService.alertModal("Error "+error.status, [error.statusText]);
						}
			);
	 	}
		
		function marcarEncuentaRespondida(solicitudJson){
			solicitudJson.marca = 1080;
			$rootScope.waitLoaderStatus = LOADER_SHOW;
		      
			solicitudService.actualizarSolicitud( solicitudJson,PROCESOS.PSC ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.ejecutarEncuentaPreaprobado=false;
					$scope.closeThisDialog(true);
				}, function(error){
					$rootScope.waitLoaderStatus = LOADER_HIDE; 
		        	modalService.alertModal("Error "+error.status, [error.statusText]);
				}
			);
		}
	});
});