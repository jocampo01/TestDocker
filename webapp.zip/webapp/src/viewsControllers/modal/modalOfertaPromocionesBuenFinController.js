'use strict';

define(["app"], function (app) {
	
		app.controller('modalOfertaPromocionesBuenFinController', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService, validateService) {
			
			var tipoTasaSP = tipoTasas.prestamoPersonal.id;
			var tipoTasaCP = tipoTasas.preaprobados.id;
			$scope.pagoPuntualSP=0;
			$scope.totalAPagarSP=0;
			$scope.pagoPuntualCP=0;
			$scope.totalAPagarCP=0;
			
			$scope.init=function(){
				$scope.objMonto=null;
				
				$scope.respaldoJsonSolicitud=null;
				$scope.respaldoJsonSolicitud=JSON.parse(JSON.stringify($rootScope.solicitudJson));
				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = parseInt($rootScope.solicitudJson.observaciones);
				$scope.respaldoJsonSolicitud.cotizacion.plazo = PLAZO_PREAPROBADO;

				$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
				$scope.isIpad=configuracion.so.ios;
//				$scope.tituloHeader="Promoción Pre aprobados Buen Fin";
				$scope.tituloHeader="Promoción El mejor Regalador";
				$scope.tituloHeaderDos=$rootScope.solicitudJson.campana == CAMPANAS_PREAPROBADO_CAPTACION.captacion ? "\"Pre aprobados Captación\"" : "\"Pre aprobados SIPA\"";
				$scope.messegeCreditoPersonal="¡Crédito Personal con 15% de descuento!";
				$scope.encabezadoTablaDer="Pago Con Promoción";
				
				$scope.messegeConElCredito="Con el crédito de Banco Azteca lo que quieres lo tienes de inmediato";
				$scope.messegeElBeneficio="El beneficio que te ofrecemos:";
				
				$scope.encabezadoTablaIzq="Pago Sin Promoción";
				$scope.textoMonto="Monto";
				$scope.monto= parseInt($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
				$scope.textoPlazo="Plazo";
				$scope.plazo= $scope.respaldoJsonSolicitud.cotizacion.plazo;
				$scope.textoPagoPuntual="Pago Puntual";
				
				$scope.textoTotalAPagar="Total a Pagar";
				
				
				calculaMontosSinPromocion();
				calculaMontosConPromocion();
				
				$scope.textoAhorras="Ahorras ";
				$scope.ahorro=$scope.totalAPagarSP - $scope.totalAPagarCP;
				$scope.messegeEnTodo=" en todo el plazo del crédito ";
				$scope.messegeAprovecha="¡Aprovecha esta exclusiva Promoción!";
				$scope.messegeENBAZSDL="En Banco Azteca Sueñas. Decides. Logras.";
				$scope.messegePresentando="Presentando:";
				$scope.messageArrayRequisitos=["Identificación Oficial (IFE/INE ó Pasaporte]","Comprobante de Domicilio"];
				$scope.messegeSiSeleccionas="Si seleccionas \"No Acepto\" el sistema te mostrará la oferta de cliente nuevo y la oferta de Pre aprobado ya no estará disponible.";
				$rootScope.mostrarOfertaCotizador=false;
				
			};
			
			
			var calculaMontosSinPromocion = function () {
				var monto 			= $scope.monto;
		 		var periodicidad 	= $scope.respaldoJsonSolicitud.cotizacion.idPeriodicidad;
		 		var plazo 			= $scope.plazo;
		 		
		 		var arrayTempAbonos =  $rootScope.consultaAbonos.prestamosPersonales; 
		 		for ( var i = 0; i < arrayTempAbonos.length; i++ ){	
		 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){ 						
		 			   $scope.pagoPuntualSP = parseFloat(arrayTempAbonos[i].puntual);
 					   $scope.totalAPagarSP = $scope.pagoPuntualSP * $scope.respaldoJsonSolicitud.cotizacion.plazo;
 					   $scope.ahorro=($scope.pagoPuntualSP*$scope.respaldoJsonSolicitud.cotizacion.plazo)-($scope.respaldoJsonSolicitud.cotizacion.pagoPuntual * $scope.respaldoJsonSolicitud.cotizacion.plazo );
 					   break;
 					}
		 		}
//		 		var arrayPlazoMonto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA",tipoTasaSP);
//		 		for ( var i = 1; i <= arrayPlazoMonto.length; i++ ){	
//		 			if (monto        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.MONTO["+i+"].valor",tipoTasaSP) &&
// 						periodicidad == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PERIODICIDADID["+i+"].valor",tipoTasaSP) &&
// 						plazo        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PLAZO["+i+"].valor",tipoTasaSP) ){ 						
// 					   var tasaNormal = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA NORMAL["+i+"].valor",tipoTasaSP));
// 					   var tasaPuntual = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA PUNTUAL["+i+"].valor",tipoTasaSP));
// 					   var idProducto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PRODUCTOID["+i+"].valor",tipoTasaSP);
// 					   var montoNormal = monto * tasaNormal;
// 					   var montoPuntual = monto * tasaPuntual;
// 					   var montoTotalPuntual = monto + montoPuntual;
// 					   $scope.pagoPuntualSP = Math.round(parseFloat(montoTotalPuntual / plazo));
// 					   $scope.totalAPagarSP = $scope.pagoPuntualSP * plazo;
// 					   break;
// 					}
//		 		}
			}
			
			var calculaMontosConPromocion = function () {
				var monto 			= $scope.monto;
		 		var periodicidad 	= $scope.respaldoJsonSolicitud.cotizacion.idPeriodicidad;
		 		var plazo 			= $scope.plazo;
		 		
		 		var arrayTempAbonos = $rootScope.consultaAbonos.preaprob;
	 			for (var i = 0; i < arrayTempAbonos.length;i++){
		 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){
		 				   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = monto;
		 				   $scope.respaldoJsonSolicitud.cotizacion.montoTotal = parseInt(arrayTempAbonos[i].precio) + parseInt(arrayTempAbonos[i].sobre);
	 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = parseInt(arrayTempAbonos[i].sobre);
	 					   $scope.respaldoJsonSolicitud.cotizacion.pagoNormal = parseFloat(arrayTempAbonos[i].normal);
	 					   $scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = parseFloat(arrayTempAbonos[i].puntual);
	 					   $scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = parseInt(arrayTempAbonos[i].ultimo);
	 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto = arrayTempAbonos[i].sku;
	 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = 1;
	 					   $scope.respaldoJsonSolicitud.cotizacion.plazo = plazo;
	 					   $scope.respaldoJsonSolicitud.cotizacion.idPlazo = plazo;
	 					   $scope.pagoPuntualCP = $scope.respaldoJsonSolicitud.cotizacion.pagoPuntual;
						   $scope.totalAPagarCP = $scope.pagoPuntualCP * plazo;
	 					   break; 
		 			}
		 		}
		 		
		 		
//		 		var arrayPlazoMonto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA",tipoTasaCP);
//		 		for ( var i = 1; i <= arrayPlazoMonto.length; i++ ){
// 					
//		 			if (monto        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.MONTO["+i+"].valor",tipoTasaCP) &&
// 						periodicidad == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PERIODICIDADID["+i+"].valor",tipoTasaCP) &&
// 						plazo        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PLAZO["+i+"].valor",tipoTasaCP) ){ 						
// 					   var tasaNormal = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA NORMAL["+i+"].valor",tipoTasaCP));
// 					   var tasaPuntual = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA PUNTUAL["+i+"].valor",tipoTasaCP));
// 					   var idProducto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PRODUCTOID["+i+"].valor",tipoTasaCP);
// 					   var montoNormal = monto * tasaNormal;
// 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = monto;
// 					   $scope.respaldoJsonSolicitud.cotizacion.montoTotal = (monto + montoNormal).toFixed(2);
// 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = parseInt($scope.respaldoJsonSolicitud.cotizacion.montoTotal - monto);
// 					   $scope.respaldoJsonSolicitud.cotizacion.pagoNormal = Math.round(parseFloat($scope.respaldoJsonSolicitud.cotizacion.montoTotal / plazo));
// 					   var montoPuntual = monto * tasaPuntual;
// 					   var montoTotalPuntual = monto + montoPuntual;
// 					   $scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = Math.round(parseFloat(montoTotalPuntual / plazo));
// 					   $scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = parseInt($scope.respaldoJsonSolicitud.cotizacion.montoTotal - $scope.respaldoJsonSolicitud.cotizacion.pagoNormal * (plazo - 1));
// 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto = idProducto;
// 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = 1;
// 					   $scope.respaldoJsonSolicitud.cotizacion.plazo = plazo;
// 					   $scope.respaldoJsonSolicitud.cotizacion.idPlazo = plazo; 
// 					   
// 					  $scope.pagoPuntualCP = $scope.respaldoJsonSolicitud.cotizacion.pagoPuntual;
//					  $scope.totalAPagarCP = $scope.pagoPuntualCP * plazo;
// 					   
// 					   break;
// 					}
//		 		}
		 		
		 		
		 		
			}
			
			$scope.aceptarOferta = function (){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$scope.respaldoJsonSolicitud.banderaIngresos = 0;
				$scope.respaldoJsonSolicitud.cotizacion.montoTotal = parseFloat($scope.respaldoJsonSolicitud.cotizacion.montoTotal);
				$scope.respaldoJsonSolicitud.banderaOfertaCP= 1;
		 		solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($scope.respaldoJsonSolicitud), seccion: SECCION_SOLICITUD } ).then(
			 			function(data){
			 				if( data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
			 					var responseJson = JSON.parse(data.data.respuesta);
			 					
			 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
			 						$rootScope.solicitudJson = responseJson.data;
			 						//I - MODIFICACION ACTUALIZAR CAPACIDAD DE PAGO
			 						var x = {	idSolicitud: $rootScope.solicitudJson.idSolicitud,
			 								idSucursal: $rootScope.solicitudJson.idSucursal ,
			 								idEmpleado: $rootScope.solicitudJson.idEmpleado ,
			 							};
			 							
			 					solicitudService.actualizarCapacidadPago(x).then(
			 						function(data){
			 							$rootScope.waitLoaderStatus = LOADER_HIDE;
			 							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
			 								var responseJson = JSON.parse(data.data.respuesta);		
			 								if(responseJson.codigo == 2){
			 									$rootScope.solicitudJson = responseJson.data;
			 									$scope.closeThisDialog(true);
			 								}else
			 									$rootScope.message( "Nueva Originación Centralizada", ["Ocurrio un problema, codigo " + responseJson.codigo, "Favor de reintentar"], "Aceptar");
			 							}else{
			 			    				$rootScope.message("Nueva Originación Centralizada",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
			 							}
			 						}, function(error){
			 			                $rootScope.waitLoaderStatus = LOADER_HIDE; 
			 			                validateService.error(error);
			 						}
			 					);
			 					//F - MODIFICACION ACTUALIZAR CAPACIDAD DE PAGO
			 						
								}else{
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									generalService.cleanRootScope($rootScope);							
									generalService.buildSolicitudJson($rootScope, null);
									$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
								}
			 					
			 				}else{
			 					$rootScope.waitLoaderStatus = LOADER_HIDE;
				 				generalService.cleanRootScope($rootScope);							
								generalService.buildSolicitudJson($rootScope, null);
								$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
			 				}
			 				
			 			}, function(error){                     
			 				$rootScope.waitLoaderStatus = LOADER_HIDE;
			 				generalService.cleanRootScope($rootScope);							
							generalService.buildSolicitudJson($rootScope, null);
							$rootScope.message("Error ",[" Favor de intentar nuevamente se detectó un problema "], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);								
			 			}	
					);
			}
			
			$scope.aceptarOfertaDos = function (){
				return $scope.respaldoJsonSolicitud;
			}


		});
});