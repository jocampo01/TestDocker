'use strict';

define(["app"], function (app) {
	
		app.controller('modalOpcionesDeCreditoController', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService) {
			
			$scope.init=function(){
				
				$scope.objMonto=null;
				$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
				$scope.isIpad=configuracion.so.ios;
				$scope.tituloHeader="¡Felicidades!";
				$scope.messegeCongrats="Línea de Crédito Autorizada";
				$scope.encabezadoTabla1="Monto Máximo";
				$scope.hasta="hasta";
				$scope.tiempoCompleto = false;
				$scope.CDP = false;
				$scope.tiempoLimiteCompleto="de 0 a 6 meses";
				$scope.tiempoLimite1="de 0 a 2 meses";
				$scope.tiempoLimite2="de 2 a 6 meses";
				$scope.messegeDinamic01="Su capacidad de pago ";				
				$scope.messegeDinamic02=" para ";				
				$scope.messegeDinamic03=" es de:";
				$scope.messegeDinamic04="Su límite de crédito es de:";
				
				$scope.producto=getProductName($rootScope.solicitudJson.idProducto);//"Mercancías"
				$scope.periodicidad=$rootScope.solicitudJson.cotizacion.periodicidad; //"Semanal"
				$scope.capacidadDePago=$rootScope.solicitudJson.banderaIngresos == 1 ? $rootScope.solicitudJson.capacidadPagoComprobable : $rootScope.solicitudJson.capacidadPagoNoComprobable;//300
				
				$scope.encabezadoTabla2="Tu cliente podrá tener";
				$scope.messegeStatic01="depués de 6 meses si tiene buen historial";
				$scope.messegeStatic02="crediticio por pagar puntualmente";
				$scope.messegeStatic03="Recuérdale que:";
				$scope.messegeStatic04="Recuérdale a tu cliente que:";
				$scope.messegeLista01="Si paga puntual, paga menos.";
				$scope.messegeLista02="Puede elegir en cuánto tiempo pagar.";
				$scope.messegeLista03="Sus abonos semanales serán fijos.";
				$scope.messegeLista04="Puede pagar en sucursales de Banco Azteca y a través de su APP móvil.";
				
				$scope.nvoPreaprob = $rootScope.campanaNvoPreaprob($rootScope.solicitudJson.campana);
				
				$scope.dosLimites=$scope.$parent.dosLimites;
				if($scope.nvoPreaprob){
					$scope.monto = parseInt($rootScope.solicitudJson.observaciones);
					$scope.CDP = true;
				}else{
					var resultadosJson=$scope.$parent.resultadosObtenerLimitesDeCreditoJson;
					if(resultadosJson.RESULTADO == 0 ){
						if(($rootScope.solicitudJson.idProducto==PRODUCTOS.italika.ID.valor ) && resultadosJson.DATA.length == 0){
							$scope.CDP = true;
						} else {
							$scope.data = resultadosJson.DATA;
							if($scope.dosLimites && $scope.data.length==2 && $scope.data[0].limitePeriodo == $scope.data[1].limitePeriodo){
								$scope.tiempoCompleto = true;
							}
						}
					}
				}
			};
			
			/**
			 * Función que obtiene los nombres de los productos
			 * */
			var getProductName = function(idProducto){
				switch(idProducto){
					case PRODUCTOS.consumo.ID.valor: //21
						return 'Mercancías';
					case PRODUCTOS.italika.ID.valor: //22
						return 'Italika';
					case PRODUCTOS.telefonia.ID.valor: //23
						return 'Telefonía';
					case PRODUCTOS.prestamoPersonal.ID.valor: //24
						return 'Personales';
					default:
						return '';
				}
			};
			
			$scope.continuaSurtirPorEjecutivo = function(){
				generalService.locationPath( "/credito" );
				$rootScope.informeRecomendado();
				$scope.closeThisDialog();
			}

		});
});