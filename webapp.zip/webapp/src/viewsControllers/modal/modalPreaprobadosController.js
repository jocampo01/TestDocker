'use strict';

define(["app"], function (app) {
	
	app.controller('modalPreaprobadosController', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService, validateService, buroService, modalService) {
		
		$scope.showPage=false;
		
		$scope.init=function(){

			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			$scope.isIpad=configuracion.so.ios;
			
			$scope.banderaTelefonia			=	($rootScope.solicitudJson.idProducto==ID_PRODUCTO.telefonia)?true:false;
			$scope.banderaItalika			=	($rootScope.solicitudJson.idProducto==ID_PRODUCTO.italika)?true:false;
			$scope.banderaTarjeta			=	($rootScope.solicitudJson.idProducto==ID_PRODUCTO.tarjetaazteca)?true:false;
			$scope.banderaConsumo			=	($rootScope.solicitudJson.idProducto==ID_PRODUCTO.consumo)?true:false;
			
			$scope.textoAdemascontupedido	=	"Además con tu pedido número: 19254010";
			$scope.textoFelicidades			=	"¡Felicidades!";
			$scope.textoCreditoPreaprobado	=	"¡Crédito al consumo Preaprobado!";
			$scope.textoCredTel				=	"¡Crédito Telefonia Preaprobado!";
			$scope.textoCredItalika			=	"¡Crédito Italika Preaprobado!";
			$scope.textoCredAzteca			=	"¡Tarjeta Azteca Preaprobado!";
			$scope.textoClientePreaprobado	=	"Para Banco Azteca eres un cliente especial, te ofrecemos un Crédito al consumo Preaprobado";
			$scope.textoClientePreaprobadoI	=	"el cual también podrás utilizar en cualquiera de las siguientes líneas:";
			$scope.textoLimiteCredito		=	"Tu limite de crédito es de:";
			$scope.textoCapacidadPago		=	"Tu capacidad de pago para";
			$scope.textoComprasElektra		=	"Compras en Elektra es de:";
			$scope.textoINE					=	"Identificacion oficial";
			$scope.textoComprobanteDomicilio	="Comprobante de domicilio";
			$scope.textoNoAcepto			=	"No Gracias";
			$scope.textoAcepto				=	"¡Quiero el Crédito!";
			
			$scope.textoClienteTelefonia	=	"Para <b>Banco Azteca</b> eres un cliente especial, <b>te ofrecemos</b> <b>un Crédito Telefonia</b>";
			$scope.textoClienteItalika		=	"Para <b>Banco Azteca</b> eres un cliente especial, <b>te ofrecemos</b> <b>un Crédito Italika</b>";
			$scope.textoClienteTarjeta		=	"Para <b>Banco Azteca</b> eres un cliente especial, <b>te ofrecemos</b> <b>una Tarjeta Azteca</b>";
			
			$scope.limiteCredito 			= parseInt($rootScope.solicitudJson.observaciones);
			
			/*\Se agrega un evento para la bitacora\*/
			$rootScope.addEvent( BITACORA.SECCION.oferta.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, 0, BITACORA.SECCION.oferta.guardarEnBD );
				
			/*\Se agrega un evento para la bitacora\*/
			
			for(var i=0;i<$rootScope.capacidadesPagoProducto.length;i++){
				if($rootScope.capacidadesPagoProducto[i].producto == $rootScope.solicitudJson.idProducto){
					if($rootScope.solicitudJson.banderaIngresos == 0)
						$scope.capacidadDePago = $rootScope.capacidadesPagoProducto[i].capacidadPagoNoComprobable;
					else
						$scope.capacidadDePago = $rootScope.capacidadesPagoProducto[i].capacidadPagoComprobable;
					break;
				}
			}
			
			$timeout(function(){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.showPage = true;
			}, 1);
		};
		
		$scope.aceptarOferta = function(){
			/*\Se agrega un evento para la bitacora\*/
			$rootScope.addEvent( BITACORA.SECCION.oferta.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.aceptar.id, 0, BITACORA.SECCION.oferta.guardarEnBD );
				
			/*\Se agrega un evento para la bitacora\*/
	 		$scope.guardarSeccion();
	 	}
		
		$scope.rechazarOferta = function(){
			/*\Se agrega un evento para la bitacora\*/
			$rootScope.addEvent( BITACORA.SECCION.oferta.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.noAceptar.id, 0, BITACORA.SECCION.oferta.guardarEnBD );
				
			/*\Se agrega un evento para la bitacora\*/
	 		$scope.closeThisDialog();
	 		
	 	}
		
		$scope.guardarSeccion = function() {
	        
	        $rootScope.solicitudJson.banderaOfertaCP= 1;
	        
	        $rootScope.waitLoaderStatus = LOADER_SHOW;
	 		solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($rootScope.solicitudJson), seccion: SECCION_SOLICITUD, bitacoraCotizacion: null },PROCESOS.PSC ).then(
		 			function(data){
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
		 					var responseJson = JSON.parse(data.data.respuesta);
		 					
		 					var fnStatusOK = function( esMalZonificada ){
								$scope.$parent.muestraAlertaNuevoBuro=false;
								$scope.$parent.muestraMensajeNuevoBuro=false;
								$scope.$parent.mensajeNuevoBuro=""
								$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO; //FIX COMMENT 01/04/2016
		 						$rootScope.solicitudJson = responseJson.data;
		 						
		 						try{
		 							$rootScope.solicitudJson.contratos.porcentaje = porcentajeSeccionDocumentos();
		 						}catch(e){}
		 						
								$rootScope.calculaDocumentos();
								
								$scope.confirm();
							
		 					};
		 					
		 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
								fnStatusOK(false);							
							}else if( responseJson.codigo == STATUS_SOLICITUD.malZonificada.guardarSeccion ){
								generalService.setDataBridge( {esMalZonificada:true} );
								fnStatusOK( true );
							}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
								var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
								$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
							}else{
								if(responseJson.codigo == ERROR_SOL_RECHAZADA){
									var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
									var marca = $rootScope.solicitudJson.marca;
									var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],"Aceptar", "/simulador",null,null,buildJsonDefault);
								}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
									generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
									$scope.closeThisDialog(true);
									generalService.locationPath("/ficha");
								}else{
									$rootScope.message("Error al volver a cotizar",[ "Error al guardar sección. Código " +
									    "de error [" + responseJson.codigo + "] no identificado."],"Aceptar", null);
								}
		 					}
		 					
		 				}else{
		 					$rootScope.message("Error",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
		 				}
		 			}, function(error){                     
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				$rootScope.message("Error al volver a cotizar",[ "Error del servicio guardar solicitud sección 9"], "Aceptar", null);								
		 			}	
				);
		}
		
		function porcentajeSeccionDocumentos(){
			var porcentaje = 0;
			
			if($rootScope.solicitudJson.idSeguimiento == 185 || $rootScope.solicitudJson.idSeguimiento == 6){
				for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
					if($rootScope.solicitudJson.contratos.contrato[i].statusFirma == 1 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 2 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 4){
						porcentaje = porcentaje + 100; 
					}
				}
				
				return porcentaje / $rootScope.solicitudJson.contratos.contrato.length;
			}else{
				for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
					if(($rootScope.solicitudJson.contratos.contrato[i].statusFirma == 1 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 2 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 4)){
						if(!generalService.validardiaDePago()){
							if(i==0 || i==1)
								porcentaje = porcentaje + 100;
						}else{
							if(i==0 || i==1 || i==2 || i==3)
								porcentaje = porcentaje + 100;
						}
					}
				}
				var numDocs  = generalService.validardiaDePago()?4:2;
				return porcentaje / numDocs;
			}
		}
		
	});
});