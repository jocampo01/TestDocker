'use strict';

define(["app"], function (app) {
	
	app.controller('modalPreaprobadosPPController', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService, validateService, buroService, modalService) {
		
		var sinInmediatoPorComprobables = false;
		var tipoTasa = tipoTasas.prestamoPersonal.id;
		
		// Sin créditos inmediatos, por sucursal, para comprobables.
		try {
			sinInmediatoPorComprobables = $rootScope.consultaFuncionalidad.sinInmediatoPorIngresosComprobables;
		} catch(e) {}
		
		$scope.MUESTRA_OFERTA=1;
		$scope.documentosDescCom = "";
		$scope.MUESTRA_OFERTA_COTIZADOR=2;
		$scope.MUESTRA_COTIZADOR=3;
		$scope.MUESTRA_ERROR=4;
		$scope.muestraRadios = false;
		$scope.OFERTA_EXITO=1;
		$scope.OFERTA_RECALCULAR=2;
		$scope.banderaComprobables = true;
		$scope.mostrarSugerido = true;
		$scope.banderaSugerido = false;
		$scope.esMenor = false;
		$scope.fechaNac = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento;
		$scope.creditoInmediatoHabilitado = $rootScope.consultaFuncionalidad.creditoInmediatoHabilitado;
		$rootScope.actualizoCotizacion=true;
		$scope.plazoSeleccionado = $rootScope.solicitudJson.cotizacion.plazo;
		$rootScope.armaJsonCotizacion();
		
		$scope.showPage=false;
		
		$scope.init=function(){

			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			$scope.isIpad=configuracion.so.ios;
			
			$scope.banderaPersonal			=	true;
			
			$scope.textoFelicidades			=	"¡Felicidades!";
			$scope.textoCreditoPreaprobado	=	"¡Crédito Personal Preaprobado!";
			$scope.textoClientePreaprobado	=	"Para <b>Banco Azteca</b> eres un cliente especial, <b>te ofrecemos</b> un <b>Crédito Personal</b>";
			$scope.textoClientePreaprobadoI	=	"<b>Preaprobado</b> el cual también podrás utilizar en cualquiera de las siguientes líneas:";
			$scope.textoLimiteCredito		=	"Tu limite de crédito es de:";
			$scope.textoCapacidadPago		=	"Tu capacidad de pago para";
			$scope.textoComprasElektra		=	"Compras en Elektra es de:";
			$scope.textoINE					=	"Identificacion oficial";
			$scope.textoComprobanteDomicilio	=	"Comprobante de domicilio";
			$scope.textoNoAcepto			=	"No Gracias";
			$scope.textoAcepto				=	"¡Quiero el Crédito!";
			
            $scope.textoAhorra				=	"Ahorra ";
            $scope.textoSemanales			=	" semanales";
            $scope.respaldoJsonSolicitud=null;
            $scope.pagoNormal              = $rootScope.solicitudJson.cotizacion.pagoNormal;
            $scope.pagoPuntual             = $rootScope.solicitudJson.cotizacion.pagoPuntual;
            $scope.cpagoComprobable    	   = $rootScope.solicitudJson.capacidadPagoComprobable;
            $scope.cNoComprobable      	   = $rootScope.solicitudJson.capacidadPagoNoComprobable;
            $scope.banderaIngresos         =($rootScope.solicitudJson.banderaIngresos==1)?true:false;
            $scope.banderaIngresosN         =($rootScope.solicitudJson.banderaIngresos==0)?true:false;
			
			/*\Se agrega un evento para la bitacora\*/
			$rootScope.addEvent( BITACORA.SECCION.oferta.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, 0, BITACORA.SECCION.oferta.guardarEnBD );
				
			/*\Se agrega un evento para la bitacora\*/
			$scope.objMonto=null;
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			$scope.tituloHeader="Cotizador";
			$scope.opcion=$scope.MUESTRA_COTIZADOR;
			$scope.tipoOferta=$scope.OFERTA_EXITO;
			$scope.mostrarDocumentos=false;
			$scope.alcanzaMoto=false;
			$scope.listaDocumentos=[];
			$scope.muestraOfertaItalika=false;
			$scope.muestraOfertaConsumo=false;
			$scope.condicionesMostrarPantallas();
			$scope.isCreditoInmediato = $rootScope.solicitudJson.creditoInmediato==1?true:false;
			$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";
			$scope.respaldoJsonSolicitud=null;
			$scope.isComprobable=false;
			$scope.periodicidad="semanas";
			$scope.inicializaSlider();
			$scope.labelAntesModal =  '<p>Si paga puntual</p><h3>{{respaldoJsonSolicitud.cotizacion.pagoPuntual | currency:$:0}}</h3>';
			$scope.labelAhorroModal = '<p class="fVerde" style="margin-bottom:2px !important;">Se ahorra</p><h4 class="fVerde" style="font-size:14px;">{{respaldoJsonSolicitud.cotizacion.pagoNormal - respaldoJsonSolicitud.cotizacion.pagoPuntual | currency:$:0}} {{respaldoJsonSolicitud.cotizacion.periodicidad | lowercase}}</h4><h5 class="fVerde" style="margin-top:5px;font-size:13px;">{{(respaldoJsonSolicitud.cotizacion.pagoNormal - respaldoJsonSolicitud.cotizacion.pagoPuntual)*respaldoJsonSolicitud.cotizacion.plazo | currency:$:0}} total</h5>';
			//			$scope.labelAhorro = '<p class="fVerde">Su ahorro</p><h3 class="fVerde">{{solicitudJson.cotizacion.pagoNormal - solicitudJson.cotizacion.pagoPuntual | currency:$:0}}</h3><p class="fVerde">{{solicitudJson.cotizacion.periodicidad | lowercase}}es</p>';
//			$scope.labelAhorro = '<h4 class="fVerde">{{solicitudJson.cotizacion.pagoNormal - solicitudJson.cotizacion.pagoPuntual | currency:$:0}} {{solicitudJson.cotizacion.periodicidad | lowercase}}</h4>';
//			$scope.labelAhorroTotal = '<h4 class="fVerde">{{(solicitudJson.cotizacion.pagoNormal - solicitudJson.cotizacion.pagoPuntual)*solicitudJson.cotizacion.plazo | currency:$:0}} total</h4>';
			$scope.labelPlazoModal = '<p>Plazo</p><h3>{{respaldoJsonSolicitud.cotizacion.plazo}} semanas</h3>';/*<p>semanas</p>';*/
			$scope.labelPagoModal = '<p>Pagará</p><h3>{{respaldoJsonSolicitud.cotizacion.pagoNormal | currency:$:0}}</h3>';/*<p>{{solicitudJson.cotizacion.periodicidad | lowercase}}mente</p>'*/;
			$scope.respaldoJsonSolicitud=JSON.parse(JSON.stringify($rootScope.solicitudJson));
			$scope.montoCampo = $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto;
			
			if (!$scope.muestraCPComprobable && $scope.muestraCPNoComprobable ){
				$scope.banderaComprobables = false;
			}
			$scope.calculaMaximos();
			
			$scope.banderaSugerido = true;
			
			$scope.banderaComprobables = ($scope.banderaComprobableAux)?true:false;
			
			// Bandera para controlar las leyendas de crédito inmediato o Felicidades.
			$scope.immediateCredit = false;
					
			// Se invoca para ver si el monto original podría ser crédito inmediato.
			wouldBeImmediateCredit();
			
			//Bandera que indica si la solicitud es de una campaña winback \*/
			$scope.isWinback = false;
			if( $rootScope.consultaFuncionalidad.habilitarPromocionesBuenFin ){
				$scope.isWinback = ( $rootScope.solicitudJson.campana == CAMPANAS_REACTIVADOS.winback && $rootScope.solicitudJson.idProducto==ID_PRODUCTO.prestamoPersonal )? true : false;
				if($scope.isWinback)
					initWinback();
			}
			//Bandera que indica si sera el front que imprime tickets \*/
			$scope.isWithTicket = true;
			if( $scope.isWithTicket )
				initWithTicket();
			
			$timeout(function(){
				$scope.showPage=true;
			}, 1)
		};
		
		$scope.aceptarOferta = function(){
			/*\Se agrega un evento para la bitacora\*/
			$rootScope.addEvent( BITACORA.SECCION.oferta.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.aceptar.id, 0, BITACORA.SECCION.oferta.guardarEnBD );
				
			/*\Se agrega un evento para la bitacora\*/
	 		$scope.guardarSeccion();
	 	}
		
		$scope.rechazarOferta = function(){
			/*\Se agrega un evento para la bitacora\*/
			$rootScope.addEvent( BITACORA.SECCION.oferta.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.noAceptar.id, 0, BITACORA.SECCION.oferta.guardarEnBD );
				
			/*\Se agrega un evento para la bitacora\*/
	 		$scope.closeThisDialog();
	 		
	 	}
		
		var initWinback=function(){
			$scope.objMonto=null;
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			$scope.isIpad=configuracion.so.ios;
			$scope.backupHeader = $scope.tituloHeader.slice();
			$scope.tituloHeader = "";
			$scope.messegeConElCredito="Con el crédito de Banco Azteca lo que quieres lo tienes de inmediato";
			$scope.messegeCreditoPersonal="";
			$scope.messegeElBeneficio="El beneficio que te ofrecemos:";
			
			$scope.encabezadoTablaIzq="Pago Sin Promoción";
			$scope.encabezadoTablaDer="";
			$scope.textoMonto="Monto";
//			$scope.monto=10000;
			$scope.textoPlazo="Plazo";
//			$scope.plazo=100;
			$scope.textoPagoPuntual="Pago Puntual";
			$scope.pagoPuntualSP;
//			$scope.pagoPuntualCP=185;
			$scope.textoTotalAPagar="Total a Pagar";
//			$scope.totalAPagarSP=21500;
			$scope.totalAPagarCP=18500;
			
			$scope.textoAhorras="Ahorras ";
			$scope.ahorro=($scope.pagoPuntualSP*$scope.respaldoJsonSolicitud.cotizacion.plazo)-($scope.respaldoJsonSolicitud.cotizacion.pagoPuntual * $scope.respaldoJsonSolicitud.cotizacion.plazo );
			$scope.messegeEnTodo=" en todo el plazo del crédito ";
			$scope.messegeAprovecha="¡Aprovecha esta exclusiva Promoción!";
			$scope.messegeENBAZSDL="En Banco Azteca Sueñas. Decides. Logras.";
//			$scope.messegeSiSeleccionas="Si seleccionas \"No acepto\" el sistema te mostrará la oferta de cliente nuevo y la oferta de Pre aprobado ya no estará disponible.";
//			$scope.preAprobado=false;
			
			if($rootScope.solicitudJson.campana == CAMPANAS_REACTIVADOS.winback){
//				$scope.tituloHeader="Promoción Winback Buen Fin";
				$scope.tituloHeader="Promoción El mejor Regalador";
				$scope.tituloHeaderDos="\"Reactiva a tus clientes = Regreso a Casa\"";
				$scope.messegeCreditoPersonal="¡Crédito Personal con 50% de descuento!";
				$scope.encabezadoTablaDer="Promoción 50%";
			} /*else if ($rootScope.solicitudJson.campana == CAMPANAS_PREAPROBADO_CAPTACION.captacion){
				$scope.tituloHeader="Promoción Pre aprobados Buen Fin";
				$scope.messegeCreditoPersonal="¡Crédito Personal Pre aprobado con 10% de descuento!";
				$scope.encabezadoTablaDer="Promoción 10%";
				$scope.preAprobado=true;
			}*/
			tipoTasa = tipoTasas.winback.id;
//			var tipoTasa = tipoTasas.prestamoPersonal.id;
//			arrayPlazoMonto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA",tipoTasa);
//			console.log(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA",tipoTasas.winback.id));
		};
		
		var initWithTicket=function(){
			$scope.objMonto=null;
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			$scope.isIpad=configuracion.so.ios;				
			$scope.textoSolicitado="Solicitado autorizado";
			$scope.textoMaximoAutorizado="Autorizado máximo";
			$scope.textoMonto="Monto";
			$scope.textoMonto="Monto";
			$scope.textoPlazo="Plazo:";
			$scope.textoSemanas=" semanas";
			$scope.textoPagoSemanal="Pago Semanal:";
			$scope.textoTotalAPagar="Total a Pagar:";
			$scope.textoNormal="Normal: ";
			$scope.textoPuntual="Puntual: ";
			$scope.textoAhorra="Ahorra ";
			$scope.textoSemanales=" semanales";
			$scope.textoGenerar="Generar presupuesto";
			
		};
		
		$scope.condicionMuestraBoton = false;
	 	if($rootScope.consultaFuncionalidad.flujoTicketMoc){
	 		$scope.condicionMuestraBoton = (configuracion.origen.tienda && configuracion.so.windows && ($rootScope.sucursalSession.idCanal==1 || $rootScope.sucursalSession.idCanal == 9 || $rootScope.sucursalSession.idCanal == 39));	
	 	}
		$scope.imprimirPresupuesto =  function(){
			var montoImporteSolicitado 	= $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto;
			var montoCreditoSolicitado 	= $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto;
			var sobreprecioSolicitado 	= (($scope.respaldoJsonSolicitud.cotizacion.pagoPuntual * $scope.respaldoJsonSolicitud.cotizacion.plazo) - $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
			var montoTotalSolicitado 	= ($scope.respaldoJsonSolicitud.cotizacion.pagoPuntual * $scope.respaldoJsonSolicitud.cotizacion.plazo);
			var montoTotalSolicitadoNormal 	= ($scope.respaldoJsonSolicitud.cotizacion.pagoNormal * $scope.respaldoJsonSolicitud.cotizacion.plazo);
			var skuSolicitado 			= $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto;
			var plazoSolicitado 			= $scope.respaldoJsonSolicitud.cotizacion.plazo;
			var pagoNormal				= $scope.respaldoJsonSolicitud.cotizacion.pagoNormal;
			var pagoPuntual 				= $scope.respaldoJsonSolicitud.cotizacion.pagoPuntual;
			
			if( $scope.muestraCPComprobable && $scope.banderaComprobables){
				var montoImporteMaximo 		= $scope.maxCom.monto;
				var montoCreditoMaximo 		= $scope.maxCom.monto;
				var sobreprecioMaximo 		= (($scope.maxCom.pagoPuntual * $scope.maxCom.plazo) - montoImporteMaximo);
				var montoTotalMaximo 		= ($scope.maxCom.pagoPuntual * $scope.maxCom.plazo);
				var montoTotalMaximoNormal	= ($scope.maxCom.pagoNormal * $scope.maxCom.plazo);
				var skuMaximo 				= $scope.maxCom.idProducto;
				var plazoMaximo 				= $scope.maxCom.plazo;
				var pagoNormalMaximo 		= $scope.maxCom.pagoNormal;
				var pagoPuntualMaximo		= $scope.maxCom.pagoPuntual;
			} else if($scope.muestraCPNoComprobable && !$scope.banderaComprobables){
				var montoImporteMaximo 		= $scope.maxNoCom.monto;
				var montoCreditoMaximo 		= $scope.maxNoCom.monto;
				var sobreprecioMaximo 		= (($scope.maxNoCom.pagoPuntual * $scope.maxNoCom.plazo) - montoImporteMaximo);
				var montoTotalMaximo 		= ($scope.maxNoCom.pagoPuntual * $scope.maxNoCom.plazo);
				var montoTotalMaximoNormal	= ($scope.maxNoCom.pagoNormal * $scope.maxNoCom.plazo);
				var skuMaximo 				= $scope.maxNoCom.idProducto;
				var plazoMaximo 				= $scope.maxNoCom.plazo;
				var pagoNormalMaximo 		= $scope.maxNoCom.pagoNormal;
				var pagoPuntualMaximo		= $scope.maxNoCom.pagoPuntual;
			}

	 		var jsonOferta = {
	 				monto:montoImporteSolicitado,
	 				plazo:plazoSolicitado,
	 				pNormal:pagoNormal,
	 				pPuntual:pagoPuntual,
	 				montoMax:montoImporteMaximo,
	 				plazoMax:plazoMaximo,
	 				pNormalMax:pagoNormalMaximo,
	 				pPuntualMax:pagoPuntualMaximo,
	 				idPeriodicidad:$rootScope.solicitudJson.cotizacion.idPeriodicidad,
	 				producto:$rootScope.solicitudJson.idProducto,
	 				sku: $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto,
	 				capacidadePago: $rootScope.solicitudJson.capacidadPagoComprobable
	 		}
			
			$rootScope.generarPlantillaImpresion(2, $rootScope.solicitudJson, $rootScope.userSession, $rootScope.sucursalSession, undefined, jsonOferta);
		};
		
		var calculaMontosSinPromocion = function () {
			var monto 			= $scope.nuevoMonto;
	 		var periodicidad 	= $scope.respaldoJsonSolicitud.cotizacion.idPeriodicidad;
	 		var plazo 			= $scope.nuevoPlazo;
	 		var tipoTasaSP		= tipoTasas.prestamoPersonal.id;
	 		var arrayTempAbonos =  $rootScope.consultaAbonos.prestamosPersonales; 
	 		for ( var i = 0; i < arrayTempAbonos.length; i++ ){	
	 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){ 						
	 			   $scope.pagoPuntualSP = parseFloat(arrayTempAbonos[i].puntual);
					   $scope.totalAPagarSP = $scope.pagoPuntualSP * $scope.respaldoJsonSolicitud.cotizacion.plazo;
					   $scope.ahorro=($scope.pagoPuntualSP*$scope.respaldoJsonSolicitud.cotizacion.plazo)-($scope.respaldoJsonSolicitud.cotizacion.pagoPuntual * $scope.respaldoJsonSolicitud.cotizacion.plazo );
					   break;
					}
	 		}
		}
		
		$scope.inicializaSlider=function(){
			if($rootScope.buroHandler){
				$scope.buildSlider();
			}
		};
		
		$scope.condicionesMostrarPantallas=function(){
			$scope.muestraOfertaItalika=false;
			$scope.muestraOfertaConsumo=false;
			if($rootScope.solicitudJson.idCanal==CANALES.sams) {
				$scope.muestraOfertaItalika=true;
				if($rootScope.buroHandler)
					$scope.alcanzaMoto=true;
				else
					$scope.alcanzaMoto=false;
			}else if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.consumo ||
					 $rootScope.solicitudJson.idProducto == ID_PRODUCTO.italika ||
					 $rootScope.solicitudJson.idProducto == ID_PRODUCTO.telefonia){
				$scope.muestraOfertaConsumo=true;
				$scope.evaluarCPenConsumo();
				$scope.docuemntosConsumo();
			}
			$scope.evaluarCPenConsumo();	
			var muestraOferta=false;
			var muestraCotizador=false;
			var error=false;
			$rootScope.onceOfert=false;
			$rootScope.mostrarOfertaCotizador=false;
//			if($rootScope.solicitudJson.banderaOfertaCP == 0 && $rootScope.onceOfert)
					muestraOferta=true;						
			
			switch($rootScope.buroConditional){
				case BURO_RECALCULAR_PLAZO:
				case BURO_AUTORIZADO_PORCOMPROBAR:
					$scope.tituloHeader="¡Lo sentimos!";
					muestraCotizador=true;
					$scope.tipoOferta=$scope.OFERTA_RECALCULAR;
					$scope.generaVariablesMejorOferta();
					
					if($scope.$parent.cotizarNFL)
						$scope.tituloHeader="¡Felicidades!";
					
					break;
				case BURO_AUTORIZADO_SCORE:
				case RESPONSE_ORIGINACION_CODIGO_EXITO:
					if(muestraOferta)
						$scope.tituloHeader="¡Felicidades!";
					muestraCotizador=true;
					break;
				default:
					error=true;
			}
			
			if(error)
				$scope.opcion=$scope.MUESTRA_ERROR;
			else if(muestraOferta && muestraCotizador)
				$scope.opcion=$scope.MUESTRA_OFERTA_COTIZADOR;
			else if(muestraOferta)
				$scope.opcion=$scope.MUESTRA_OFERTA;
			else if(muestraCotizador)
				$scope.opcion=$scope.MUESTRA_COTIZADOR;
		};
		
		function validaPlazosVista(arrayPlazos){
			var plazos = arrayPlazos;
			$scope.banderaComprobableAux = 0;
			$scope.banderaNoComprobableAux = 0;
			
			for(var i=0;i<plazos.length;i++){
				if(plazos[i].cpNoComprobable != null){
					$scope.banderaNoComprobableAux = 1;
				}
				
				if(plazos[i].cpComprobable != null){
					$scope.banderaComprobableAux = 1;
				}
			}
			
			if($rootScope.solicitudJson.capacidadPagoComprobable == $rootScope.solicitudJson.capacidadPagoNoComprobable){
				if($scope.banderaNoComprobableAux){
					$scope.banderaNoComprobableAux = 1;
					$scope.banderaComprobableAux = 0;
				}else if($scope.banderaComprobableAux){
					$scope.banderaNoComprobableAux = 0;
					$scope.banderaComprobableAux = 1;
				}else{
					$scope.banderaNoComprobableAux = 0;
					$scope.banderaComprobableAux = 0;
				}
			}
		}
		
		$scope.evaluarCPenConsumo=function(){
			$scope.muestraCPNoComprobable=false;
			$scope.muestraCPComprobable=false;
			$scope.muestraCPNoComprobableInmediato=false;
			$scope.muestraCPComprobableInmediato=false;
			
			var arrayPlazos = generalService.getPlazos( $rootScope );
			validaPlazosVista(arrayPlazos);
			
			var ingresoComp=$scope.getTipoIngreso(3);
			var ingresoNoComp=$scope.getTipoIngreso(4);
			
			var mostrarCDPComprobable = false;
			var mostrarCDPNoComprobable = false;
			if($rootScope.capacidadesPagoProducto){
				for(var i=0;i<$rootScope.capacidadesPagoProducto.length;i++){
					if($rootScope.capacidadesPagoProducto[i].producto == $rootScope.solicitudJson.idProducto){
						mostrarCDPComprobable = ($rootScope.capacidadesPagoProducto[i].mostrarCDPComprobable == 1);
						mostrarCDPNoComprobable = ($rootScope.capacidadesPagoProducto[i].mostrarCDPNoComprobable == 1);
						break;
					}
				}
			}
			
			switch($rootScope.ofertaMCO){
	        case 0:		  
	        	if(ingresoComp) {
					$scope.muestraCPComprobable=true;
					$scope.muestraRadios = false;
					$scope.banderaComprobableAux = 1;
				}else if(ingresoNoComp) {
					$scope.muestraCPNoComprobable=true;
					$scope.muestraRadios = false;
					$scope.banderaComprobableAux = 0;
				}										
	          break;
	        case 1:
	        	if($rootScope.consultaFuncionalidad.validarPorCDP && $rootScope.solicitudJson.banderaIngresos == 1){
					$scope.muestraCPComprobable=true;
					$scope.muestraRadios = false;
					$scope.banderaComprobableAux = 1;
				}else if(mostrarCDPComprobable) {
					$scope.muestraCPComprobable=true;
					$scope.muestraRadios = false;
					$scope.banderaComprobableAux = 1;
				}
	          break;
	        case 2:
	        	if(mostrarCDPNoComprobable) {
					$scope.muestraCPNoComprobable=true;
					$scope.muestraRadios = false;
					$scope.banderaComprobableAux = 0;
				}		          
	          break;
	      }
			if(arrayPlazos){
				if(arrayPlazos.length>0){
					if($rootScope.solicitudJson.creditoInmediato == 1 && $scope.muestraCPComprobable)
						$scope.muestraCPComprobableInmediato=true;
					if($rootScope.solicitudJson.creditoInmediato == 1 && $scope.muestraCPNoComprobable)
						$scope.muestraCPNoComprobableInmediato=true;
				}
			}
		};
		
		$scope.getTipoIngreso=function(tipoIngreso){
			var arrayFlujo = $rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo;
			for(var efectivo in arrayFlujo){
				if(arrayFlujo[efectivo].idConcepto==tipoIngreso && arrayFlujo[efectivo].monto > 0)
					return true;
			}
			return false;

		};
		
		$scope.generaVariablesMejorOferta=function(){
			var arrayPlazos = generalService.getPlazos( $rootScope );
			if(arrayPlazos){
				var monto = parseInt($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto);
				
				var index = arrayPlazos.map(function(d){
					return d["monto"];
					
				}).indexOf (monto);
				if (index != -1){
					$scope.montoOferta = parseInt($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto);
				}else{
					var montoMayor = $scope.regresaMayor(arrayPlazos, "monto");
					$scope.montoOferta=montoMayor.valor; 
					index = montoMayor.posicion;
				}
				
				var plazo = $rootScope.solicitudJson.cotizacion.plazo;
				var arrelgoPlazos =arrayPlazos[index];
				if (arrayPlazos[index].cpNoComprobable){
					var index1 = arrelgoPlazos.cpNoComprobable.indexOf( plazo );		
					if( index1 != -1 ){
						$scope.plazoOferta=plazo;
						$scope.Montocomprobables = false;
					}else{
							if (arrayPlazos[index].cpComprobable)
								index1 = arrelgoPlazos.cpComprobable.indexOf( plazo );	
							else
								index1 = -1;
						
							if( index1 != -1 ){
								$scope.plazoOferta=plazo;
								$scope.Montocomprobables = true;
							}else{
								var plazoMayor = $scope.regresaMayor(arrayPlazos[index].cpNoComprobable);
								$scope.Montocomprobables = false;
								if (!plazoMayor.encontro){
									plazoMayor = $scope.regresaMayor(arrayPlazos[index].cpComprobable);
									$scope.Montocomprobables = true;
								}
								index1 = plazoMayor.posicion;
								$scope.plazoOferta=plazoMayor.valor
							}
					}
				}else{
					if (arrayPlazos[index].cpComprobable)
						var index1 = arrelgoPlazos.cpComprobable.indexOf( plazo );
					else
						var index1 = -1;
					$scope.Montocomprobables = true;
					if( index1 != -1 ){
						$scope.plazoOferta=plazo;
					}else{
						plazoMayor = $scope.regresaMayor(arrayPlazos[index].cpComprobable);
						index1 = plazoMayor.posicion;
						$scope.plazoOferta=plazoMayor.valor
					}
				}
				console.log("comprobables " + $scope.Montocomprobables)
				if ($scope.Montocomprobables){
					if($rootScope.solicitudJson.creditoInmediato == 1)
						$scope.creditoInmediatoOferta=true;
					else
						$scope.creditoInmediatoOferta=false;
				}else{
					if($rootScope.solicitudJson.creditoInmediato == 1)
						$scope.creditoInmediatoOferta=true;
					else
						$scope.creditoInmediatoOferta=false;
				}
//				$scope.montoOferta=montoMayor.valor; 
//				$scope.plazoOferta=plazoMayor.valor
				$scope.periodicidadOferta="semanas";
//				$scope.actualizaPlazo($scope.plazoOferta);
				$scope.respaldoNuevoPlazo=$scope.plazoOferta;
//				$scope.creditoInmediatoOferta=false;
			}
		};
		
		
		$scope.buildSlider = function(){
			
			var cambiaMontoCallback = function( valorSlider ){
		 		$timeout( function(){ 
	 				angular.element( document.getElementById( "volverCotizar" ) ).scope().reBuildSlider( valorSlider );
	 			}, 0);
			};
					
			var plazos = generalService.getPlazos($rootScope );
			  
			var arrayMontos = plazos.map( function(d){
				return d['monto'];
			});
			
			arrayMontos = generalService.mergeSort(arrayMontos);
			
			var monto = parseInt($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto);
			var index = arrayMontos.indexOf( monto );

			var _min = Math.min.apply( 0, arrayMontos );
			var _max = Math.max.apply( 0, arrayMontos );
							
			if( index == -1 )
				monto = _max;
			  
			$scope.minMonto = _min;
			$scope.maxMonto = _max;
			
			var step=500;
			var len = arrayMontos.length;
			
			if( arrayMontos[0] )
				if( arrayMontos[1] )
					step = arrayMontos[1]-arrayMontos[0];
			
			var fnCrearSliderCallBack = function(){
				slider( _min , _max, step, monto, '.amountVolCotizar div', arrayMontos, cambiaMontoCallback, "#sliderVolCotizar");
			};
			
			$scope.createSliderThread( 'sliderVolCotizar', fnCrearSliderCallBack, true );
			
		};
		
		
		
		$scope.reBuildSlider = function ( valorSlider )
		{		

			var cambiaMontoCallback = function(){								

				
				
				$scope.plazosCotizador = $scope.calculaPlazosTermometroNuevo( valorSlider);				
				if($scope.plazoSeleccionado != 0){
					var plazoEncontrado = false;
					for(var plazo in $scope.plazosCotizador){
						if($scope.plazosCotizador[plazo] == $scope.plazoSeleccionado){
							plazoEncontrado = true;
							break;
						}
					}
					
					if(!plazoEncontrado)
						$scope.plazoSeleccionado = 0;
				}
				var plazo = $scope.respaldoNuevoPlazo?$scope.respaldoNuevoPlazo:$rootScope.solicitudJson.cotizacion.plazo;
				$scope.respaldoNuevoPlazo = plazo;
				var encontro = false;
				for (var i = 0; i < $scope.plazosCotizador.length; i++){
					if ($scope.plazosCotizador[i] >= $scope.respaldoNuevoPlazo){
						plazo = $scope.plazosCotizador[i];
						encontro = true
						break;
					}
				 }
				 if (!encontro){
				 	plazo = $scope.plazosCotizador[$scope.plazosCotizador.length - 1]
				 }
				 console.log(plazo);
				
//				var plazo = $scope.respaldoNuevoPlazo?$scope.respaldoNuevoPlazo:$rootScope.solicitudJson.cotizacion.plazo;
				
				$timeout(function(){
					$scope.actualizaMonto();	 		
					$scope.validaPlazoComprobableInmediato(plazo,valorSlider);
					$scope.calculaNuevosMontos();						
				}, 50)
		 		
				var index = $scope.plazosCotizador.indexOf( plazo );
				$scope.deshabilitarRecalcular = true;
		 		$scope.actualizaMonto();
		 		$scope.calculaMaximos();
				if(index != -1 ){
					if(plazo = plazo)
					$scope.validaPlazoComprobableInmediato( plazo, valorSlider ); 
					$scope.calculaNuevosMontos();
					$timeout( function(){
						$('.requisitosCot ul li > a').each(function(){
							if( parseInt($(this).text()) == parseInt(plazo) ){
								if(!$(this).hasClass( "active" )){
									limpiarClasePlazos();
									$( this ).addClass('active'); 
								}
								return;
							};
						});
						$scope.actualizaPlazo();
					}, 10 );
				}else{
					$scope.mostrarDocumentos=false;
					limpiarClasePlazos();
					$scope.nuevoPlazo=0;
					$scope.actualizaPlazo($scope.plazosCotizador[$scope.plazosCotizador.length - 1]);
				}
								
			};
			
			$scope.createSliderThread( 'sliderVolCotizar', cambiaMontoCallback, false );
			$timeout(function(){$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
			if($scope.nuevoMonto != $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto)
				$scope.buildSliderNoCom($scope.banderaComprobables);
			}, 100);
			
			
			// Intentando actualizar la bandera immediateCredit.
			wouldBeImmediateCredit();
	 	};/* END UISLIDER FUNCTION */
	 	
		$scope.createSliderThread = function( idSlider, fnCrearSliderCallBack, isFirstTime ){											
			
			var stopInterval = null, intervalCont = 1;
			
			var verifySlider = function(){
				var sliderVal = $( "#" + idSlider ).slider( "value" );
				return !(isNaN( sliderVal ));
			};
							
			var trySlider = function(){					
				if( verifySlider() ){
					$interval.cancel( stopInterval )
					if( fnCrearSliderCallBack && fnCrearSliderCallBack != null )
						fnCrearSliderCallBack();
				}else if( intervalCont == 100 )
					$interval.cancel( stopInterval )
				else{
					intervalCont++;
					if( isFirstTime )
						if( fnCrearSliderCallBack && fnCrearSliderCallBack != null )
							fnCrearSliderCallBack();
				}
			};
			stopInterval = $interval( trySlider, 100 );
									
			
		};/* END THREAD SLIDER FUNCTION */
		
		
		$scope.calculaPlazosTermometroNuevo = function( valor){
			var arrayPlazos = generalService.getPlazos( $rootScope ); 
			
			var index = arrayPlazos.map( function(d){
				return d['monto'];
			}).indexOf( parseInt(valor) );
			
			if( arrayPlazos.length == 0 ){
				$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
				$scope.opcion=$scope.MUESTRA_ERROR;
				return [];
			}			
			
			if( index != -1 ){
				
				var plazos = [];
				var _comprobables = arrayPlazos[index].cpComprobable;
				var _noComprobables = arrayPlazos[index].cpNoComprobable;
				
				_comprobables = _comprobables ? _comprobables : [];
				_noComprobables = _noComprobables ? _noComprobables : [];
				
				var comprobables = _comprobables;
				var noComprobables = _noComprobables;
				
				if (!$scope.banderaComprobables){
					comprobables = noComprobables
				}
				
				for( var i = 0; i < comprobables.length; i++ ){	
					if( plazos.indexOf( comprobables[i] ) == -1 ){
						plazos.push( comprobables[i] );
					}	
				}/* END FOR */
				
				return plazos.sort( function( a, b ){
					return a-b;/* Invert to asc */
				});
				
			}/* END IF INDEX */
			return [];
			
		};
		
		
		
		
		$scope.calculaPlazosTermometro = function( valor){
			var arrayPlazos = generalService.getPlazos( $rootScope ); 
			
			var index = arrayPlazos.map( function(d){
				return d['monto'];
			}).indexOf( parseInt(valor) );
			
			if( arrayPlazos.length == 0 ){
				$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
				$scope.opcion=$scope.MUESTRA_ERROR;
				return [];
			}			
			
			if( index != -1 ){
				
				var plazos = [];
				var _comprobables = arrayPlazos[index].cpComprobable;
				var _noComprobables = arrayPlazos[index].cpNoComprobable;
				
				_comprobables = _comprobables ? _comprobables : [];
				_noComprobables = _noComprobables ? _noComprobables : [];
				
				if( _comprobables.length > _noComprobables.length ){
					var comprobables = _comprobables;
					var noComprobables = _noComprobables;
				}else{
					var comprobables = _noComprobables;
					var noComprobables = _comprobables;
				}	
				
				for( var i = 0; i < comprobables.length; i++ ){
						
					if( noComprobables[i] ){
						
						if( plazos.indexOf( comprobables[i] ) == -1 ){
							plazos.push( comprobables[i] );
						}
						
						if( plazos.indexOf( noComprobables[i] ) == -1 ){
							plazos.push( noComprobables[i] );
						}
						
					}else{
						if( plazos.indexOf( comprobables[i] ) == -1 ){
							plazos.push( comprobables[i] );
						}
					}
						
				}/* END FOR */
				
				return plazos.sort( function( a, b ){
					return a-b;/* Invert to asc */
				});
				
			}/* END IF INDEX */
			return [];
			
		};
		
		
		$scope.validaPlazoComprobableInmediato = function( plazo, monto ){
			var arrayPlazos = generalService.getPlazos( $rootScope ); 
			var tiposComprobantes=null;
			var indexPlazo = arrayPlazos.map( function(d){
				return d[ 'monto' ];
			}).indexOf( parseInt(monto) );
			
			var index = -1;
			var comprobante = false;
			var tiposComprobantes = null;
			
			if( indexPlazo != -1 && !$scope.banderaComprobables){
				
				var condicionRequeridaC = arrayPlazos[indexPlazo].requeridoComprobable;
				var condicionRequeridaNC = arrayPlazos[indexPlazo].requeridoNoComprobable;
				
				if( condicionRequeridaC != '' && condicionRequeridaC != null )
					condicionRequeridaC = condicionRequeridaC.split(",");
				if( condicionRequeridaNC != '' && condicionRequeridaNC != null )
					condicionRequeridaNC = condicionRequeridaNC.split(",");
				
				if( arrayPlazos[indexPlazo].cpNoComprobable ){
					
					index = arrayPlazos[indexPlazo].cpNoComprobable.indexOf( parseInt(plazo) );
					
					if( typeof condicionRequeridaNC == "object" && index != -1 && condicionRequeridaNC != null ){
						comprobante = true;
						tiposComprobantes = arrayPlazos[indexPlazo].requeridoNoComprobable;
					}
			
					if( index == -1 ){
						
						index = arrayPlazos[indexPlazo].cpComprobable.indexOf( parseInt(plazo) );
						
						if( typeof condicionRequeridaC == "object" && condicionRequeridaC != null){
							comprobante = true;
							tiposComprobantes = arrayPlazos[indexPlazo].requeridoComprobable;
						}
						
						if( index != -1 )
							comprobante = true;
												
					}
					
				}else{
					
					if( arrayPlazos[indexPlazo].cpComprobable && $scope.banderaComprobables){
						
						index = arrayPlazos[indexPlazo].cpComprobable.indexOf( parseInt(plazo) );
						
						if( typeof condicionRequeridaC == "object" && condicionRequeridaC != null ){
							comprobante = true;
							tiposComprobantes = arrayPlazos[indexPlazo].requeridoComprobable; 
						}
						
						if( index != -1 )
							comprobante = true;
						
					}
					
				}
				$scope.objMonto=arrayPlazos[indexPlazo];	
			}					
			$scope.isCreditoInmediato=false;
			//validar si ese plazo tiene credito inmediato
			if( comprobante ){
				$scope.isComprobable=true;
				if($rootScope.solicitudJson.creditoInmediato)
					$scope.isCreditoInmediato = generalService.masterFunction();
					// $scope.isCreditoInmediato = (generalService.validaEdad($scope.fechaNac) || $scope.creditoInmediatoHabilitado==false) ? false : true;			
				$scope.listaDocumentos=[{desc:IDENTIFICACION_OFICIAL_INE.descripcion, id:IDENTIFICACION_OFICIAL_INE.id },{desc:COMP_DOMICILIO.descripcion, id: COMP_DOMICILIO.id}];
				//					if(tiposComprobantes.split(",").indexOf("CI")!=-1){
				if ($scope.banderaComprobables){
					$scope.listaDocumentos.push({desc:COMP_INGRESOS.descripcion, id:COMP_INGRESOS.id });
				}


//				for (var i = 0; i < $scope.listaDocumentos.length;){
//				var borrarRegistro = $scope.searchID($scope.listaDocumentos[i].id)
//				if (borrarRegistro){
//				$scope.listaDocumentos.splice(i,1);
//				}else{
//				i++	
//				}

//				}
				if ($scope.listaDocumentos.length > 0){
					$scope.mostrarDocumentos=true;
					$scope.documentosDescCom = $scope.crearLista($scope.listaDocumentos);
				}else
					$scope.mostrarDocumentos=false;
			}else{
				$scope.listaDocumentos=[{desc:IDENTIFICACION_OFICIAL_INE.descripcion, id:IDENTIFICACION_OFICIAL_INE.id },{desc:COMP_DOMICILIO.descripcion, id: COMP_DOMICILIO.id}];
				if ($scope.banderaComprobables){
					tiposComprobantes = arrayPlazos[indexPlazo].requeridoComprobable;
//					if(tiposComprobantes.split(",").indexOf("CI")!=-1){
					$scope.listaDocumentos.push({desc:COMP_INGRESOS.descripcion, id:COMP_INGRESOS.id });
//					}
				}
//				for (var i = 0; i < $scope.listaDocumentos.length;){
//					var borrarRegistro = $scope.searchID($scope.listaDocumentos[i].id)
//					if (borrarRegistro){
//						 $scope.listaDocumentos.splice(i,1);
//					}else{
//						i++	
//					}
					
//				}
				if ($scope.listaDocumentos.length > 0){
					$scope.mostrarDocumentos=true;
					$scope.documentosDescCom = $scope.crearLista($scope.listaDocumentos);
				}else{
					$scope.mostrarDocumentos=false;
				}
				
				
				if($rootScope.solicitudJson.creditoInmediato)
					$scope.isCreditoInmediato = generalService.masterFunction();
					// $scope.isCreditoInmediato = (generalService.validaEdad($scope.fechaNac) || $scope.creditoInmediatoHabilitado==false) ? false : true;
//					$scope.mostrarDocumentos=false;
//					$scope.listaDocumentos=[];
					$scope.isComprobable=false;
			}
			
			return comprobante;
			
		};
		
		
		function limpiarClasePlazos(){
			$('.requisitosCot ul li > a').each(function(){
	 			$( this ).removeClass('active');
	 	    });
			
		};/* END LIMPIAR CLASE PLAZO FUNCTION */
		
		$scope.onSeleccionaPlazoCombo = function(){	 		 		 	
	 		$scope.actualizaMonto();
	 		$scope.actualizaPlazoCombo($scope.plazoSeleccionado);		 		
	 		$scope.validaPlazoComprobableInmediato($scope.nuevoPlazo,$scope.nuevoMonto);
	 		$scope.calculaNuevosMontos();
	 		if ($scope.banderaSugerido){
				$scope.mostrarSugerido = false;
			}
	 	};/* END CONDICIONES TERMOMETRO FUNCTION */
		
	 	$scope.onSeleccionaPlazo = function(valor,ui){	 		 		 	
	 		$scope.actualizaMonto();
	 		$scope.actualizaPlazo(ui.target.parentNode);		 		
	 		$scope.validaPlazoComprobableInmediato($scope.nuevoPlazo,$scope.nuevoMonto);
	 		$scope.calculaNuevosMontos();
	 		if ($scope.banderaSugerido){
				$scope.mostrarSugerido = false;
			}
	 	};/* END CONDICIONES TERMOMETRO FUNCTION */
	 	
	 	$scope.actualizaMonto=function(){
	 		$scope.nuevoMonto= $( "#sliderVolCotizar" ).slider( "value" );
	 	};
	 	
	 	$scope.actualizaPlazo=function(nuevoPlazo){
	 		var plazo;
 			if(nuevoPlazo){
 				limpiarClasePlazos();
 				$(nuevoPlazo).addClass('active');
 			}
	 		$('.requisitosCot ul li > a').each(function(){
		 		if( $( this ).hasClass('active') ){
		 			plazo = parseInt( $(this).text() ); 
		 			return;
		 		};
		 	});
	 		$scope.nuevoPlazo= plazo;
	 		$scope.respaldoNuevoPlazo= plazo;
	 	};
	 	
	 	$scope.actualizaPlazoCombo=function(nuevoPlazo){
	 		$scope.nuevoPlazo= nuevoPlazo;
	 		$scope.respaldoNuevoPlazo= nuevoPlazo;
	 	};
	 	
	 	/**
		 *Valida que el cliente sea menor a 22 años de acuerdo a lo que devuelve la funcion validaEdad 
		 **/
	 	// $scope.esMenor = (generalService.validaEdad($scope.fechaNac) || !generalService.validaCreditoInmediatoProducto()) ? true : false;
	 	
	 	if(generalService.masterFunction()) {
	 		$scope.esMenor = false;
	 		$scope.isCreditoInmediato = true;
	 	} else {
	 		$scope.esMenor = true;
	 		$rootScope.isCreditoInmediato = false;
	 	}
	 	
	 	$scope.volverACotizar = function(detalle){
	 		
	 		if (!detalle){
	 			console.log("normal");
	 		}else{
	 			$scope.nuevoPlazo = detalle.plazo;
	 			$scope.nuevoMonto =  detalle.monto;
	 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = detalle.monto;
	 			$scope.respaldoJsonSolicitud.cotizacion.montoTotal = detalle.montoTotal;
	 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = detalle.intereses;
	 			$scope.respaldoJsonSolicitud.cotizacion.pagoNormal = detalle.pagoNormal;
	 			$scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = detalle.pagoPuntual;
	 			$scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = detalle.ultimoAbono;
	 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto = detalle.idProducto;
	 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = detalle.cantidad;
	 			$scope.respaldoJsonSolicitud.cotizacion.plazo = detalle.plazo;
	 			$scope.respaldoJsonSolicitud.cotizacion.idPlazo = detalle.idPlazo; 
	 			console.log(detalle);
	 		}
			$scope.respaldoJsonSolicitud=JSON.parse(JSON.stringify($rootScope.solicitudJson));
			$scope.respaldoJsonSolicitud.banderaOfertaCP= 1;
	 		if($scope.opcion==$scope.MUESTRA_OFERTA){
	 			$rootScope.waitLoaderStatus = LOADER_SHOW;
	 			$scope.guardarSeccion();
	 		}else{
				if( $scope.nuevoPlazo &&  $scope.nuevoMonto){
		 			$rootScope.waitLoaderStatus = LOADER_SHOW;
 		 			if($scope.calculaNuevosMontos()){
	 		 			$scope.validaCreditoInmediatoIngresos();
	 		 			$scope.guardarSeccion();
 		 			}

				}
	 		}
	 	};
	 	
		/**
		 * Función que valida las banderas de imgreso 
		 * Si la bandera de ingresos esta en 0 pero es un cliente verde con ingresos no comprobables la bandera de credito inmediato sera 1
		 * Si el cliente tiene la bandera de ingresos en 1, es verde, con ingresos comprobables, el credito inmediato es 1
		 * en cualquier otro caso, el credito inmediato es 0 
		 * Esta funcion se manda a llamar al seleccionar ingresos comprobables o no comprobables en el cotizador
		 **/
	 	$scope.validaCreditoInmediatoPorColor = function(){
	 		
	 		if($rootScope.solicitudJson.banderaIngresos == 0 && ($rootScope.solicitudJson.idColorNC == 1 || $rootScope.solicitudJson.idColorNC == 2 || $rootScope.solicitudJson.idColorNC == 3 || $rootScope.solicitudJson.idColorNC == 7)){
	 			$scope.respaldoJsonSolicitud.creditoInmediato = 1;
	 	
	 		}else{
	 			if($rootScope.solicitudJson.banderaIngresos == 1 && ($rootScope.solicitudJson.idColor == 1 || $rootScope.solicitudJson.idColor == 2 || $rootScope.solicitudJson.idColor == 3 || $rootScope.solicitudJson.idColor == 7)){
	 				$scope.respaldoJsonSolicitud.creditoInmediato = 1;
		 	
		 		} else {
		 			$scope.respaldoJsonSolicitud.creditoInmediato = 0;
		 		}
	 		}
	 	};
	 	
	 	$scope.cotizarConsumo = function(ingresos){
	 		$rootScope.waitLoaderStatus = LOADER_SHOW;
	 		$scope.respaldoJsonSolicitud.banderaOfertaCP= 1;
	 		$scope.respaldoJsonSolicitud.banderaIngresos = ingresos;
	 		$scope.guardarSeccion();
	 	};
	 	
	 	$scope.seleccionarOtraMoto=function(){		 		
	 		$scope.closeThisDialog(true);		 				 		
	 		generalService.setArrayValue("cotizacionOfertaItalika", JSON.stringify($rootScope.solicitudJson.cotizacion));
	 		generalService.locationPath("/catalogoItalika");		 		
	 	};
		
		/**
		 *En esta funcion primero se manda llamar la funcion validaCreditoInmediatoPorColor para enviar la bandera de credito inmediato correctamente al guardar la seccion
		 *posteriormente se valida la edad y si es menor a 22 años el credito inmediato sera 0 
		 **/
	 	$scope.validaCreditoInmediatoIngresos=function(){
	 		$scope.validaCreditoInmediatoPorColor();
	 		
	 		// if(generalService.validaEdad($scope.fechaNac) || !generalService.validaCreditoInmediatoProducto() || $rootScope.solicitudJson.creditoInmediatoInhabilitado>0) 	
	 			// $scope.respaldoJsonSolicitud.creditoInmediato = 0;
	 		
	 		/**
	 		 * Si masterFunction dice que no es credito inmediato se setea la bandera de credito inmediato en 0
	 		 */
	 		if(!generalService.masterFunction())
	 			$scope.respaldoJsonSolicitud.creditoInmediato = 0;
	 							
			if($scope.banderaComprobables)
				$scope.respaldoJsonSolicitud.banderaIngresos = 1;
			else
				$scope.respaldoJsonSolicitud.banderaIngresos = 0;
	 		
	 	};
	 	
		$scope.calculaNuevosMontos = function(){	 
			
	 			var monto =  $scope.nuevoMonto;
		 		var periodicidad = $scope.respaldoJsonSolicitud.cotizacion.idPeriodicidad;
		 		var plazo = $scope.nuevoPlazo;			 	
		 		
		 		if($scope.muestraOfertaItalika){
		 			var pagoNormal;
		 			var pagoPuntual;
		 			for(var abonoItalika in $scope.objMonto.abonoSemanal){
		 				if($scope.objMonto.abonoSemanal[abonoItalika].plazo==plazo){
		 					pagoNormal=$scope.objMonto.abonoSemanal[abonoItalika].pagoNormal;
		 					pagoPuntual=$scope.objMonto.abonoSemanal[abonoItalika].pagoPuntual;
		 					break;	
		 				}			 						 					
		 			}
		 			if(pagoNormal && pagoPuntual){				
		 				var montoConIntereses = pagoNormal * plazo;
		 				
		 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = monto;
		 				$scope.respaldoJsonSolicitud.cotizacion.montoTotal = montoConIntereses;
		 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = montoConIntereses - monto;
		 				$scope.respaldoJsonSolicitud.cotizacion.pagoNormal = pagoNormal;
		 				
		 				$scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = pagoPuntual;
		 				$scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = pagoNormal;				
		 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = 1;
	 					$scope.respaldoJsonSolicitud.cotizacion.plazo = plazo;
	 					$scope.respaldoJsonSolicitud.cotizacion.idPlazo = plazo; 
		 							 				
		 			}else
		 				return null;
		 		}else{			 			
		 			var arrayTempAbonos =  $scope.isWinback ? $rootScope.consultaAbonos.winback : $rootScope.consultaAbonos.prestamosPersonales;
		 			for (var i = 0; i < arrayTempAbonos.length;i++){
			 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){
			 				   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = monto;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.montoTotal = parseFloat(arrayTempAbonos[i].sobre);
//		 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = parseInt($rootScope.solicitudJson.cotizacion.montoTotal - monto);
			 				   $scope.respaldoJsonSolicitud.cotizacion.montoTotal = parseInt(arrayTempAbonos[i].precio) + parseInt(arrayTempAbonos[i].sobre);
		 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = parseInt(arrayTempAbonos[i].sobre);
		 					   $scope.respaldoJsonSolicitud.cotizacion.pagoNormal = parseFloat(arrayTempAbonos[i].normal);
		 					   $scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = parseFloat(arrayTempAbonos[i].puntual);
		 					   $scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = parseInt(arrayTempAbonos[i].ultimo);
		 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto = arrayTempAbonos[i].sku;
		 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = 1;
		 					   $scope.respaldoJsonSolicitud.cotizacion.plazo = plazo;
		 					   $scope.respaldoJsonSolicitud.cotizacion.idPlazo = plazo; 
		 					   break; 
			 			}
			 		}
		 			
//			 		var arrayPlazoMonto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA",tipoTasa);
//			 		for ( var i = 1; i <= arrayPlazoMonto.length; i++ ){
//	 					
//			 			if (monto        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.MONTO["+i+"].valor",tipoTasa) &&
//	 						periodicidad == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PERIODICIDADID["+i+"].valor",tipoTasa) &&
//	 						plazo        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PLAZO["+i+"].valor",tipoTasa) ){ 						
//	 					   var tasaNormal = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA NORMAL["+i+"].valor",tipoTasa));
//	 					   var tasaPuntual = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA PUNTUAL["+i+"].valor",tipoTasa));
//	 					   var idProducto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PRODUCTOID["+i+"].valor",tipoTasa);
//	 					   var montoNormal = monto * tasaNormal;
//	 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = monto;
//	 					   $scope.respaldoJsonSolicitud.cotizacion.montoTotal = monto + montoNormal;
//	 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = parseInt($scope.respaldoJsonSolicitud.cotizacion.montoTotal - monto);
//	 					   $scope.respaldoJsonSolicitud.cotizacion.pagoNormal = Math.round(parseFloat($scope.respaldoJsonSolicitud.cotizacion.montoTotal / plazo));
//	 					   var montoPuntual = monto * tasaPuntual;
//	 					   var montoTotalPuntual = monto + montoPuntual;
//	 					   $scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = Math.round(parseFloat(montoTotalPuntual / plazo));
//	 					   $scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = parseInt($scope.respaldoJsonSolicitud.cotizacion.montoTotal - $scope.respaldoJsonSolicitud.cotizacion.pagoNormal * (plazo - 1));
//	 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto = idProducto;
//	 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = 1;
//	 					   $scope.respaldoJsonSolicitud.cotizacion.plazo = plazo;
//	 					   $scope.respaldoJsonSolicitud.cotizacion.idPlazo = plazo; 
//	 					   break;
//	 					}
//	 					
//			 		}
		 		}
		 		
		 		if($scope.isWinback)
		 			calculaMontosSinPromocion();
		 		
		 		return true;
		 		
	 	};
	 			 	
	 	$scope.guardarSeccion = function() {
	 		/**
	 		 * Se valida la bandera de creditoInmediato, antes de guardar.
	 		 */
	 		(function() {
	 			// Qué monto lleva la solicitud.
	 			var monto = $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto;
	 			
	 			// ¿Se están comprobando ingresos?
	 			var comprobando = $scope.banderaComprobables;
	 			
	 			// Se obtiene el detalle de buró.
	 			var detalleBuro = generalService.getPlazos($rootScope);
	 			
	 			// A priori, no es crédito inmediato.
	 			var immediateCreditProbability = false;
	 			
	 			if(!comprobando || !sinInmediatoPorComprobables) {
	 				// Se recorre el arreglo de detalle de Buró.
		 			for(var i in detalleBuro) {
		 				// El monto de la posición actual hace match en monto.
		 				if(detalleBuro[i].monto == monto) {
		 					// ¿Se desea comprobar ingresos?
		 					if(comprobando) {
		 						// Se valida que el detalle buró tenga crédito inmediato, comprobando.
		 						if($rootScope.solicitudJson.creditoInmediato == 1) {
		 							// Es probable que sea un crédito inmediato.
		 							immediateCreditProbability = true;
		 							
		 							break;
		 						}
		 					} else {
		 					// Se valida que el detalle buró tenga crédito inmediato, sin comprobar ingresos.
		 						/*if(detalleBuro[i].noComprobableInm == 1) {*/
		 							// Es probable que sea un crédito inmediato.
		 							immediateCreditProbability = true;
		 							
		 							break;
		 						/*}*/
		 					}
		 				}
		 			}
	 			}
	 			
	 			// ¿Hay posibilidad de crédito inmediato?
	 			if(immediateCreditProbability) {
	 				// ¿cómo debe ir la bandera de ingresos?
	 				$scope.respaldoJsonSolicitud.banderaIngresos = comprobando ? 1 : 0;
	 				
	 				// Señora masterFunction, haga usted favor de hacer su magia.
	 				$scope.respaldoJsonSolicitud.creditoInmediato = generalService.masterFunction(
	 						$scope.respaldoJsonSolicitud) ? 1 : 0;		 				
	 			} else {
	 				// No hay crédito inmediato para vos, señor/a.
	 				$scope.respaldoJsonSolicitud.creditoInmediato = 0;
	 			}
	 		})();
	 		
	 		/**Modificación para que los winback se vayan a crédito Inmediato\*/
	 		if( $scope.isWinback && $rootScope.consultaFuncionalidad.creditoInmediatoWinbackHabilitado ) {		 	
 				$scope.respaldoJsonSolicitud.creditoInmediato = 1;
			}
	 		
	 		/* Cuando MCO autoriza una solicitud con una CDP específica, entonces al seleccionar la nueva alternativa
	         *  se setea el valor de ofertaSeleccionadaMCO  a 2 para que ya no se se muestre la notificación de volver a cotizar 
	         *  */
	        if($scope.respaldoJsonSolicitud.ofertaSeleccionadaMCO == 1)
	          $scope.respaldoJsonSolicitud.ofertaSeleccionadaMCO = COTIZADOR_MCO;
	 		
	        $scope.respaldoJsonSolicitud.banderaOfertaCP= 1;
	        
	        generaGuardadoCotizacion();
	        
	        var cadenaJsonCotizacion = null;
	        if($rootScope.JsonCotizacion!=null)
	        	cadenaJsonCotizacion=JSON.stringify($rootScope.JsonCotizacion);
	        
	        $rootScope.waitLoaderStatus = LOADER_SHOW;
	 		solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($scope.respaldoJsonSolicitud), seccion: SECCION_SOLICITUD, bitacoraCotizacion: cadenaJsonCotizacion },PROCESOS.PSC ).then(
		 			function(data){
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
		 					var responseJson = JSON.parse(data.data.respuesta);
		 					
		 					var fnStatusOK = function( esMalZonificada ){
								$scope.$parent.muestraAlertaNuevoBuro=false;
								$scope.$parent.muestraMensajeNuevoBuro=false;
								$scope.$parent.mensajeNuevoBuro=""
								$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO; //FIX COMMENT 01/04/2016
		 						$rootScope.solicitudJson = responseJson.data;
		 						
		 						try{
		 							$rootScope.solicitudJson.contratos.porcentaje = porcentajeSeccionDocumentos();
		 						}catch(e){}
		 						
								if( esMalZonificada && typeof esMalZonificada !== 'undefined' ){
									var excepciones = [ SECCION_HOGAR.toString() ];
									generalService.bloqueoSecciones( $rootScope.solicitudJson, excepciones );
								}
								$rootScope.calculaDocumentos();
								
								if($rootScope.solicitudJson.idProducto == 25)
									$scope.$parent.buildMenuList();	
								
								$scope.confirm();		
							
		 					};
		 					
		 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
								fnStatusOK(false);							
							}else if( responseJson.codigo == STATUS_SOLICITUD.malZonificada.guardarSeccion ){
								generalService.setDataBridge( {esMalZonificada:true} );
								fnStatusOK( true );
							}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
								var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
								$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
							}else{
								if(responseJson.codigo == ERROR_SOL_RECHAZADA){
									var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
									var marca = $rootScope.solicitudJson.marca;
									var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],"Aceptar", "/simulador",null,null,buildJsonDefault);
								}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
									generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
									$scope.closeThisDialog(true);
									generalService.locationPath("/ficha");
								}else{
									$rootScope.message("Error al volver a cotizar",[ "Error al guardar sección. Código " +
									    "de error [" + responseJson.codigo + "] no identificado."],"Aceptar", null);
								}
		 					}
		 					
		 					//Se actualiza el status de la solicitud cuando el cliente decide cambiarse por la opción de No comprobables.
		 					if($rootScope.solicitudJson.idSeguimiento == 34 && $rootScope.solicitudJson.marca == 4001 && $rootScope.solicitudJson.banderaIngresos == 0){
		 						$scope.actualizaStatusTiendaMCO();
		 					}
		 					
		 				}else{
		 					$rootScope.message("Error",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
		 				}
		 			}, function(error){                     
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				$rootScope.message("Error al volver a cotizar",[ "Error del servicio guardar solicitud sección 9"], "Aceptar", null);								
		 			}	
				);
		}
	 	
	 	function generaGuardadoCotizacion(){
	 		if($rootScope.actualizoCotizacion){
	 			if(($scope.respaldoJsonSolicitud.idSeguimiento == STATUS_SOLICITUD.generada.id || $scope.respaldoJsonSolicitud.idSeguimiento == STATUS_SOLICITUD.preautorizada.id) &&
	 				$scope.respaldoJsonSolicitud.idSolicitudTienda==0)
	 				$rootScope.JsonCotizacion.tipoOferta=2;
	 			else
	 				$rootScope.JsonCotizacion.tipoOferta=3;
	 			$rootScope.JsonCotizacion.canalEnvio=0;
	 			$rootScope.JsonCotizacion.montoSolicitado=$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto;
	 			$rootScope.JsonCotizacion.plazoSolicitado=$scope.respaldoJsonSolicitud.cotizacion.plazo;
	 			$rootScope.JsonCotizacion.periodicidad=$scope.respaldoJsonSolicitud.cotizacion.idPeriodicidad;
	 			$rootScope.JsonCotizacion.sku=$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto;
	 			$rootScope.JsonCotizacion.abonoNormalSolicitado=$scope.respaldoJsonSolicitud.cotizacion.pagoNormal;
	 			$rootScope.JsonCotizacion.abonoPuntualSolicitado=$scope.respaldoJsonSolicitud.cotizacion.pagoPuntual;
	 			if($scope.muestraCPComprobable && $scope.banderaComprobables){
		 			$rootScope.JsonCotizacion.montoMaximo=$scope.maxCom.monto;
		 			$rootScope.JsonCotizacion.plazoMaximo=$scope.maxCom.plazo;
		 			$rootScope.JsonCotizacion.abonoNormalMaximo=$scope.maxCom.pagoNormal;
		 			$rootScope.JsonCotizacion.abonoPuntualMaximo=$scope.maxCom.pagoPuntual;
	 			}else{
	 				$rootScope.JsonCotizacion.montoMaximo=$scope.maxNoCom.monto;
		 			$rootScope.JsonCotizacion.plazoMaximo=$scope.maxNoCom.plazo;
		 			$rootScope.JsonCotizacion.abonoNormalMaximo=$scope.maxNoCom.pagoNormal;
		 			$rootScope.JsonCotizacion.abonoPuntualMaximo=$scope.maxNoCom.pagoPuntual;
	 			}
	 		}else{
	 			$rootScope.JsonCotizacion=null;
	 		}
	 	};
	 	
	 	function porcentajeSeccionDocumentos(){
			var porcentaje = 0;
			
			if($rootScope.solicitudJson.idSeguimiento == 185 || $rootScope.solicitudJson.idSeguimiento == 6){
				for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
					if($rootScope.solicitudJson.contratos.contrato[i].statusFirma == 1 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 2 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 4){
						porcentaje = porcentaje + 100; 
					}
				}
				
				return porcentaje / $rootScope.solicitudJson.contratos.contrato.length;
			}else{
				for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
					if(($rootScope.solicitudJson.contratos.contrato[i].statusFirma == 1 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 2 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 4)){
						if(!generalService.validardiaDePago()){
							if(i==0 || i==1)
								porcentaje = porcentaje + 100;
						}else{
							if(i==0 || i==1 || i==2 || i==3)
								porcentaje = porcentaje + 100;
						}
					}
				}
				var numDocs  = generalService.validardiaDePago()?4:2;
				return porcentaje / numDocs;
			}
		}
	 	
	 	$scope.regresaMayor = function(arreglo, campo){
			var auxiliar = 0;
			var posicion = 0;
			var encontro = false;
			if (arreglo){
				for(var i = 0; i< arreglo.length; i++){
					if (campo){
						if (auxiliar < arreglo[i][campo]){
							auxiliar =arreglo[i][campo];
							posicion = i;	
							encontro = true
						}	
					}else{
						if (auxiliar < arreglo[i]){
							auxiliar =arreglo[i];
							posicion = i;
							encontro = true
						}	
					}
				}
			}
			return {"posicion": posicion, "valor": auxiliar, "encontro": encontro};
		}
	 	
	 	
	 	$scope.searchID = function(documentoId){
	 		var returnStatus = false;
	 		
			if($rootScope.solicitudJson.documentos.documento != null){
				var lenDoc = $rootScope.solicitudJson.documentos.documento.length;
				var index = -1;
				
				
				if( lenDoc > 0 ){
					
					var data = $rootScope.solicitudJson.documentos.documento;
					
					index = data.map( function(d){
						return d['idDocumento'];
					}).indexOf( documentoId ); /* IDENTIFICACION */
					
					if( index >= 0 ){
						returnStatus = data[index].status == STATUS_CAPTURADO ? 
								true : data[index].status == STATUS_VERIFICADO ?
								true : data[index].status == STATUS_ENCOLADO_IPAD ?
								true : data[index].status == STATUS_VALIDADO ? true : false;  
					}
									
				}
			}				
			
			return returnStatus;
			
		};/* END SEARCH ID FUNCTION */
		
		
		$scope.docuemntosConsumo = function(){		
				var arrayPlazos = generalService.getPlazos( $rootScope );
				$scope.DocumentosComprobanbles=[{desc:IDENTIFICACION_OFICIAL_INE.descripcion, id:IDENTIFICACION_OFICIAL_INE.id},{desc:COMP_INGRESOS.descripcion, id:COMP_INGRESOS.id},{desc:COMP_DOMICILIO.descripcion, id: COMP_DOMICILIO.id}];
				for (var i = 0; i < $scope.DocumentosComprobanbles.length;){
					var borrarRegistro = $scope.searchID($scope.DocumentosComprobanbles[i].id)
					if (borrarRegistro){
						 $scope.DocumentosComprobanbles.splice(i,1);
					}else{
						i++	
					}
					
				}
				$scope.DocumentosNoComprobables=[{desc:IDENTIFICACION_OFICIAL_INE.descripcion, id:IDENTIFICACION_OFICIAL_INE.id },{desc:COMP_DOMICILIO.descripcion, id: COMP_DOMICILIO.id}];
				for (var i = 0; i < $scope.DocumentosNoComprobables.length;){
					var borrarRegistro = $scope.searchID($scope.DocumentosNoComprobables[i].id)
					if (borrarRegistro){
						 $scope.DocumentosNoComprobables.splice(i,1);
					}else{
						i++	
					}
					
				}
				if ($scope.DocumentosComprobanbles.length > 0){
					$scope.mostrarDocumentosCom=true;
					$scope.documentosDescCom = $scope.crearLista($scope.DocumentosComprobanbles);
				}else
					$scope.mostrarDocumentosCom=false;
				
				if ($scope.DocumentosNoComprobables.length > 0){
					$scope.mostrarDocumentosNoCOm=true;
					$scope.documentosDescnoCom = $scope.crearLista($scope.DocumentosComprobanbles);
				}else
					$scope.mostrarDocumentosNoCOm=false;	
				
				
		}
		
		$scope.crearLista = function(array){
			var aux = []
			if (array.length == 1){
				aux[0] = array[0].desc
			}else{
//				for(var i = 0; i < array.length; i++){
//					if (i == (array.length - 1) ){
//						aux = aux + " y " + array[i].desc;
//					}else if (i == 0)  {
//						aux =  array[i].desc;
//					}else{
//						aux = aux + ", " + array[i].desc;
//					}
//						
//				}
				for(var i = 0; i < array.length; i++){
					aux[i]=array[i].desc;
				}
			}
			return aux;
		}
		
		$scope.radiosingresos = function(valor){
			$scope.banderaComprobables = valor;
			if($scope.banderaComprobables){
				$scope.buildSliderNoCom(true);
				$timeout(function(){$scope.buildSliderNoCom(true);
				if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxCom.monto)
					$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = $scope.maxCom.monto;
				$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto, 0);
				}, 1)
			}else{
				$scope.buildSliderNoCom(false);
				$timeout(function(){$scope.buildSliderNoCom(false);
				if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxNoCom.monto)
					$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = $scope.maxNoCom.monto;
				$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto, 0);
				}, 1)
			}
			
			// Actualizar la bandera immediateCredit.
			wouldBeImmediateCredit();
		}
		
		$scope.buildSliderNoCom = function(comprobables){
			
			var cambiaMontoCallback = function( valorSlider ){
		 		$timeout( function(){ 
	 				angular.element( document.getElementById( "volverCotizar" ) ).scope().reBuildSlider( valorSlider );
	 			}, 0);
			};
				
			var plazosArray = generalService.getPlazos($rootScope );
			var plazos=[]; 
			if (comprobables){
				for (var i = 0; i < plazosArray.length; i++){
					if (plazosArray[i].cpComprobable == null || plazosArray[i].cpComprobable.length == 0){
						continue;
					}else{
						plazos.push(plazosArray[i]);							
					}
				}
			}else{
				for (var i = 0; i < plazosArray.length; i++){
					if (plazosArray[i].cpNoComprobable == null || plazosArray[i].cpNoComprobable.length == 0){
						continue;
					}else{
						plazos.push(plazosArray[i]);							
					}
				}
			}
				
			
			var arrayMontos = plazos.map( function(d){
				return d['monto'];
			});
			
			arrayMontos = generalService.mergeSort(arrayMontos);
			
			var monto = parseInt( $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
			var index = arrayMontos.indexOf( monto );

			var _min = Math.min.apply( 0, arrayMontos );
			var _max = Math.max.apply( 0, arrayMontos );
							
			if( index == -1 ){
				var aprox = $scope.buscaMontoAproximado(monto, $scope.banderaComprobables, 100, false);
				monto = aprox.monto;
			}
			  
			$scope.minMonto = _min;
			$scope.maxMonto = _max;
			
			var step=500;
			var len = arrayMontos.length;
			
			if( arrayMontos[0] )
				if( arrayMontos[1] )
					step = arrayMontos[1]-arrayMontos[0];
			
			var fnCrearSliderCallBack = function(){
				slider( _min , _max, step, monto, '.amountVolCotizar div', arrayMontos, cambiaMontoCallback, "#sliderVolCotizar");
			};
			
			$scope.createSliderThread( 'sliderVolCotizar', fnCrearSliderCallBack, true );
			
		};
		
		
		$scope.buscaMonto = function(){								
			$scope.plazosCotizador = $scope.calculaPlazosTermometroNuevo( valorSlider);	
			if($scope.plazoSeleccionado != 0){
				var plazoEncontrado = false;
				for(var plazo in $scope.plazosCotizador){
					if($scope.plazosCotizador[plazo] == $scope.plazoSeleccionado){
						plazoEncontrado = true;
						break;
					}
				}
				
				if(!plazoEncontrado)
					$scope.plazoSeleccionado = 0;
			}
			
			var plazo = 100;
			var index = $scope.plazosCotizador.indexOf( plazo );
			$scope.deshabilitarRecalcular = true;
			if(index != -1 ){
//				if(plazo = plazo)
				$scope.validaPlazoComprobableInmediato( plazo, valorSlider ); 
				$scope.calculaNuevosMontos();
				$timeout( function(){
					$('.requisitosCot ul li > a').each(function(){
						if( parseInt($(this).text()) == parseInt(plazo) ){
							if(!$(this).hasClass( "active" )){
								limpiarClasePlazos();
								$( this ).addClass('active'); 
							}
							return;
						};
					});
					$scope.actualizaPlazo();
				}, 10 );
			}else{
				$scope.mostrarDocumentos=false;
				limpiarClasePlazos();
				$scope.nuevoPlazo=0;
			}
							
		};
		
		$scope.calculaMaximos = function(){
			var arrayPlazos = generalService.getPlazos( $rootScope );
			arrayPlazos.sort(function (a, b) {
				  if (a.monto > b.monto) {
				    return 1;
				  }
				  if (a.monto < b.monto) {
				    return -1;
				  }
				  // a must be equal to b
				  return 0;
				});
			for(var i = 0; i < arrayPlazos.length; i++){
				if (arrayPlazos[i].cpComprobable == null || arrayPlazos[i].cpComprobable.length == 0){
//					continue
				}else{
					$scope.maxComproblable = arrayPlazos[i];
				}
				if (arrayPlazos[i].cpNoComprobable == null || arrayPlazos[i].cpNoComprobable.length == 0){
//					continue
				}else{
					$scope.maxNoComproblable = arrayPlazos[i];
				}
			}
			
			if (!$scope.maxComproblable){
				
			}else{
				$scope.montoProComprobable = ($scope.maxComproblable.monto + $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto)/2;
				$scope.montoProComprobable = redondearValor($scope.montoProComprobable, 100);
				$scope.plazoMaxComprobables = $scope.maxComproblable.cpComprobable[ $scope.maxComproblable.cpComprobable.length - 1]
				$scope.maxCom  = $scope.calculaNuevosMontosMax($scope.maxComproblable.monto, $scope.plazoMaxComprobables);
				if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxCom.monto && $scope.banderaComprobables){
					$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto =  $scope.maxCom.monto;
				}
				var detalleCom = $scope.buscaMontoAproximado($scope.montoProComprobable, true,100, true);
				$scope.detalleCom = $scope.calculaNuevosMontosMax(detalleCom.monto, detalleCom.plazo);					
			}
			
			if (!$scope.maxNoComproblable){
				
			}else{
				$scope.montoProNoComprobable = ($scope.maxNoComproblable.monto + $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto)/2;
				$scope.montoProNoComprobable = redondearValor($scope.montoProNoComprobable, 100);
				$scope.plazoMaxNoComprobables = $scope.maxNoComproblable.cpNoComprobable[ $scope.maxNoComproblable.cpNoComprobable.length - 1]
				$scope.maxNoCom = $scope.calculaNuevosMontosMax($scope.maxNoComproblable.monto, $scope.plazoMaxNoComprobables);
				if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxNoCom.monto && !$scope.banderaComprobables){
					$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = $scope.maxNoCom.monto;
				}
				var detalleNoCom = $scope.buscaMontoAproximado($scope.montoProNoComprobable, false,100, true);
				$scope.detalleNoCom = $scope.calculaNuevosMontosMax(detalleNoCom.monto, detalleNoCom.plazo);
			}
			if ($scope.banderaSugerido && $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto != $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto ){
				$scope.mostrarSugerido = false;
			}
		}
		$scope.buscaMontoAproximado = function(monto, comprobable, unidad, menor){
			var arrayPlazos = generalService.getPlazos( $rootScope );
			arrayPlazos.sort(function (a, b) {
				  if (a.monto > b.monto) {
				    return 1;
				  }
				  if (a.monto < b.monto) {
				    return -1;
				  }
				  // a must be equal to b
				  return 0;
				});
			var encontro = false;
			var detalle = {};
			if (comprobable){
				
				while (!encontro) {
					var index = arrayPlazos.map(function(d){
						return d["monto"];
						
					}).indexOf (monto);
					if (index != -1){
						if(!arrayPlazos[index].cpComprobable){
							if (menor){									
								monto = monto - unidad;
							}else{
								monto = monto + unidad;
							}
						}else{
							detalle.plazo = arrayPlazos[index].cpComprobable[ arrayPlazos[index].cpComprobable.length - 1];
							detalle.monto = monto;
							encontro = true;
							$scope.hayPromedio= true;
							break;
						}
					}else{
						if (menor){									
							monto = monto - unidad;
						}else{
							monto = monto + unidad;
						}
					}
					if (monto < 2000 || monto > arrayPlazos[arrayPlazos.length - 1].monto){
						encontro = true;
						$scope.hayPromedio= false;
					}
				}
			}else{
				while (!encontro) {
					var index = arrayPlazos.map(function(d){
						return d["monto"];
						
					}).indexOf (monto);
					if (index != -1){
						if(!arrayPlazos[index].cpNoComprobable){
							if (menor){									
								monto = monto - unidad;
							}else{
								monto = monto + unidad;
							}
						}else{
							detalle.plazo = arrayPlazos[index].cpNoComprobable[arrayPlazos[index].cpNoComprobable.length - 1]
							detalle.monto = monto; 
							encontro = true;
							$scope.hayPromedio= true;
							break;
						}
					}else{
						if (menor){									
							monto = monto - unidad;
						}else{
							monto = monto + unidad;
						}
					}
					if (monto < 2000 || monto > arrayPlazos[arrayPlazos.length - 1].monto){
						encontro = true;
						$scope.hayPromedio= false;
					}
				}
			}
			return detalle;
		}
		$scope.calculaNuevosMontosMax = function(nuevoMonto, nuevoPLazo){	 
			
			var arrayTempAbonos =  $scope.isWinback ? $rootScope.consultaAbonos.winback : $rootScope.consultaAbonos.prestamosPersonales;
 			var monto =  nuevoMonto;
	 		var periodicidad = $rootScope.solicitudJson.cotizacion.idPeriodicidad;
	 		var plazo = nuevoPLazo;
	 		
	 		for ( var i = 0; i < arrayTempAbonos.length; i++ ){
	 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){ 						
					   var calculo = {};
					   calculo.monto = monto;
					   calculo.montoTotal = parseInt(arrayTempAbonos[i].precio) + parseInt(arrayTempAbonos[i].sobre);
				   calculo.intereses = parseInt(arrayTempAbonos[i].sobre);
					   calculo.pagoNormal =parseFloat( arrayTempAbonos[i].normal );
					   calculo.pagoPuntual = parseFloat(arrayTempAbonos[i].puntual);
					   calculo.ultimoAbono = parseInt(arrayTempAbonos[i].ultimo);
					   calculo.idProducto = arrayTempAbonos[i].sku;
					   calculo.cantidad = 1;
					   calculo.plazo = plazo;
					   calculo.idPlazo = plazo; 
					   break;
					}
	 		}
	 		
	 		
//	 		var arrayPlazoMonto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA",tipoTasa);
//		 		for ( var i = 1; i <= arrayPlazoMonto.length; i++ ){
// 					
//		 			if (monto        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.MONTO["+i+"].valor",tipoTasa) &&
// 						periodicidad == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PERIODICIDADID["+i+"].valor",tipoTasa) &&
// 						plazo        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PLAZO["+i+"].valor",tipoTasa) ){ 						
// 					   var tasaNormal = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA NORMAL["+i+"].valor",tipoTasa));
// 					   var tasaPuntual = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA PUNTUAL["+i+"].valor",tipoTasa));
// 					   var idProducto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PRODUCTOID["+i+"].valor",tipoTasa);
// 					   var montoNormal = monto * tasaNormal;
// 					   var calculo = {};
// 					   calculo.monto = monto;
// 					   calculo.montoTotal = monto + montoNormal;
// 					   calculo.intereses = parseInt(calculo.montoTotal - monto);
// 					   calculo.pagoNormal = Math.round(parseFloat(calculo.montoTotal / plazo));
// 					   var montoPuntual = monto * tasaPuntual;
// 					   var montoTotalPuntual = monto + montoPuntual;
// 					   calculo.pagoPuntual = Math.round(parseFloat(montoTotalPuntual / plazo));
// 					   calculo.ultimoAbono = parseInt(calculo.montoTotal -calculo.pagoNormal * (plazo - 1));
// 					   calculo.idProducto = idProducto;
// 					   calculo.cantidad = 1;
// 					   calculo.plazo = plazo;
// 					   calculo.idPlazo = plazo; 
// 					   break;
// 					}
// 					
//		 		}
	 		return calculo;
	 		
 	};
 	function redondearValor(valor, unidad){
		var valorDes = Math.ceil(valor / unidad) * unidad
		var valorAnt = valorDes - unidad;
		
		var valorR1 = valorDes - valor;
		var valorR2 = valor - valorAnt;
		
		if(valorR1 <= valorR2){
			return valorDes; 
		}else{
			return valorAnt; 
		}
		
	}
		
 	
 	$scope.promediaMonto=function(){
 		if ($scope.montoCampo.length > 5){
	 		var valor = generalService.limpiaFormato( $scope.montoCampo, "NIP-$" );
	 		
	 		if (valor < MONTO_MAX_SALTOS){
	 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = redondearValor(valor, 100);
	 		}else{		 			
	 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = redondearValor(valor, 500);
	 		}
	 		if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto < 2000)
	 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = 2000;
	 		if ($scope.banderaComprobables){
	 			if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxCom.monto){
	 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = $scope.maxCom.monto;
	 			}
	 		}else{
	 			if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxNoCom.monto){
	 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto =$scope.maxNoCom.monto;
	 			}
	 		}
	 		$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto, 0);
	 		console.log($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
	 		if($scope.banderaComprobables){
				$scope.buildSliderNoCom(true);
				$timeout(function(){$scope.buildSliderNoCom(true);}, 1)
			}else{
				$scope.buildSliderNoCom(false);
				$timeout(function(){$scope.buildSliderNoCom(false);}, 1)
			}
 		}else{
 			if ($scope.montoCampo.length > 4 && $scope.montoCampo.length < 6){
 				$timeout(function(){
 					if ($scope.montoCampo.length > 4){
		 				var valor = generalService.limpiaFormato( $scope.montoCampo, "NIP-$" );
		 				
		 				if (valor < MONTO_MAX_SALTOS){
				 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = redondearValor(valor, 100);
				 		}else{		 			
				 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = redondearValor(valor, 500);
				 		}
		 				
				 		if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto < 2000)
				 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = 2000;
				 		if($scope.banderaComprobables){
				 			if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxCom.monto){
				 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = $scope.maxCom.monto;
				 			}
				 		}else{
				 			if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxNoCom.monto){
				 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto =$scope.maxNoCom.monto;
				 			}
				 		}
				 		$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto, 0);
				 		console.log($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
				 		if($scope.banderaComprobables){
							$scope.buildSliderNoCom(true);
							$timeout(function(){$scope.buildSliderNoCom(true);}, 1)
						}else{
							$scope.buildSliderNoCom(false);
							$timeout(function(){$scope.buildSliderNoCom(false);}, 1)
						}
 					}
 				}, 500);
 			}
 		}
 		
 		// Actualizando la bandera immediateCredit.
 		wouldBeImmediateCredit();
 	}
	   
 	function number_format(amount, decimals) {

 	    amount += ''; // por si pasan un numero en vez de un string
 	    amount = parseFloat(amount.replace(/[^0-9\.]/g, '')); // elimino cualquier cosa que no sea numero o punto

 	    decimals = decimals || 0; // por si la variable no fue fue pasada

 	    // si no es un numero o es igual a cero retorno el mismo cero
 	    if (isNaN(amount) || amount === 0) 
 	        return parseFloat(0).toFixed(decimals);

 	    // si es mayor o menor que cero retorno el valor formateado como numero
 	    amount = '' + amount.toFixed(decimals);

 	    var amount_parts = amount.split('.'),
 	        regexp = /(\d+)(\d{3})/;

 	    while (regexp.test(amount_parts[0]))
 	        amount_parts[0] = amount_parts[0].replace(regexp, '$1' + ',' + '$2');

 	    return amount_parts.join('.');
 	}
 	$scope.cambio=function(){
 		$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto, 0);
 		
 		// Actualizando la bandera immediateCredit.
 		wouldBeImmediateCredit();
 	}
 	
 	function wouldBeImmediateCredit() {
 		try {
 			// El monto seleccionado.
 			var montoSeleccionado;
	 		
	 		if(typeof $scope.montoCampo == "string") {
	 			montoSeleccionado = parseFloat($scope.montoCampo.replace(",", ""));
	 		} else {
	 			montoSeleccionado = $scope.montoCampo;
	 		}
	 				 		
	 		// Se declara una copia del JSON. Nótese que no sólo se pasa la referencia al nuevo control remoto.
 			var solicitud = JSON.parse(JSON.stringify($scope.respaldoJsonSolicitud));
	 		
 			if(typeof montoSeleccionado !== "undefined" && typeof solicitud !== "undefined") {
 				var comprobando = $scope.banderaComprobables;
 		 		
 				if(comprobando && sinInmediatoPorComprobables) {
 					$scope.immediateCredit = false;
 				} else {
 					var detalleBuro = generalService.getPlazos($rootScope);
	 	 			
	 	 			for(var i in detalleBuro) {
	 	 				if(detalleBuro[i].monto == montoSeleccionado) {
	 	 					// ¿Se desea comprobar ingresos?
	 	 					if(comprobando) {
	 	 						// Se valida que el detalle buró tenga crédito inmediato, comprobando.
//	 	 						if(detalleBuro[i].comprobableInm == 1) {
//	 	 							// Se configura la bandera de ingresos.
//	 	 							solicitud.banderaIngresos = 1;
	 	 							
	 	 							// ¿Qué dice la masterFunction?
	 	 							$scope.immediateCredit = generalService.masterFunction(solicitud);
	 	 							
	 	 							break;
//	 	 						} else { // No hay credito inmediato para el monto.
//	 	 							$scope.immediateCredit = false;
//	 	 							
//	 	 							break;
//	 	 						}
	 	 					} else {
	 	 						// Se valida que el detalle buró tenga crédito inmediato, sin comprobar ingresos.
//	 	 						if(detalleBuro[i].noComprobableInm == 1) {
//	 	 							// Se configura la bandera de ingresos.
//	 	 							solicitud.banderaIngresos = 0;
	 	 							
	 	 							// ¿Qué dice la masterFunction?
	 	 							$scope.immediateCredit = generalService.masterFunction(solicitud);
	 	 							
	 	 							break;
//	 	 						} else { // No hay credito inmediato para el monto.
//	 	 							$scope.immediateCredit = false;
//	 	 							
//	 	 							break;
//	 	 						}
	 	 					}
	 	 				}
	 	 			}
 				}
 			}
 		} catch(x) {
 			$scope.immediateCredit = false;
 		}
 	};
 	
 	
	});

});