/**
 * 
 */'use strict';

define(["app"], function (app) {

    app.controller("modalProResConsumoController", function ( $scope, $rootScope, $timeout, generalService, generalServiceOS,clienteUnicoService,sessionService, modalService, solicitudService) {
    		
    	$scope.init = function(producto){
    		
    		if( producto)
    			cargarVista(producto);
    		else
    			cargarVista(21);
 	}
    	
    	function cargarVista(producto){
    		var mensaje = $rootScope.consultaFuncionalidad.habilitarOSConsumo?"Registrando un Coacreditado":"Sin registrar Coacreditado";
    		
    		if($rootScope.consultaFuncionalidad.habilitarOSConsumo){
    			$scope.cargarMensaje = "<div style='text-align: justify;'>Infórmale a tu cliente que el producto y monto cotizado no fueron autorizados, sin embargo," +
    			" tiene la siguiente alternativa de ser aprobado su crédito de <b>Consumo Elektra</b> después de una visita a su domiciliio:" + "<br/>"
    			            + "<br/>"
    						+ "<table style='width: 60%;padding: 3%;margin-left: 20%;'>"			            			
    							+ "<tr>"
    								+ "<td valign='top'> &nbsp;&nbsp;-&nbsp;&nbsp; </td>"
    								+ "<td>"
    									+ "Le prestamos un monto mínimo de $1,500 y hasta un monto maximo $4,000 para Electrónica y $6,000 para Mercancias"
    								+ "</td>"
    							+ "</tr>"
    							+ "<tr>"
    							+ "<td> &nbsp;&nbsp;-&nbsp;&nbsp; </td>"
    								+ "<td>"
    									+ "Plazo único de 54 semanas"
    								+ "</td>"
    							+ "</tr>"
    							+ "<tr>"
    							+ "<td> &nbsp;&nbsp;-&nbsp;&nbsp; </td>"
    								+ "<td>"
    									+ "Enganche requerido del 30%"
    								+ "</td>"
    							+ "</tr>"
    							+ "<tr>"
    							+ "<td> &nbsp;&nbsp;-&nbsp;&nbsp; </td>"
    								+ "<td>"
    									+ mensaje
    								+ "</td>"
    							+ "</tr>"
    						+"</table>"

    			            + "</div>";
    		}else{
    			
    			if(producto==21){
    				$scope.cargarMensaje = "<div style='text-align: center;'>¡Creemos en ti! Con un buen comportamiento de pago con nostros, puedes " +
					"construir un buen historial de crédito. <br/> <br/>"
						+ "<b>TE OFRECEMOS PARA CONSUMO $6,000 con un mínimo de 30% de enganche.</b>"
			            + "</div>";
    			}else{
    				$scope.cargarMensaje = "<div style='text-align: center;'>¡Creemos en ti!  y aunque hoy no podemos darte el crédito personal solicitado, " +
    						"con un buen comportamiento de pago con nosotros, puedes construir un buen historial de crédito.. <br/> <br/>"
						+ "<b>TE OFRECEMOS CRÉDITO PARA CONSUMO EN ELEKTRA POR $6,000 con un mínimo de 30% de enganche.</b>"
			            + "</div>";
    			}
    			
    		}
    		
    		}
    	
    	
    
    	
    	$scope.rechazar = function(){
    		$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.rechazada.id;
    		$rootScope.solicitudJson.idMotivoRechazo = STATUS_SOLICITUD.rechazada.idMotivoRechazo.clienteNoAceptaMiniConsumo;
    		$rootScope.waitLoaderStatus = LOADER_SHOW;
    		
    		solicitudService.actualizarSolicitud( $rootScope.solicitudJson ).then(
    				function(data){
    					
    						$rootScope.waitLoaderStatus = LOADER_HIDE;
    						generalService.cleanRootScope($rootScope);
    						generalServiceOS.cleanRootScope($rootScope);
    						generalService.buildSolicitudJson($rootScope, null);
    						generalService.buildSolicitudOSJson($rootScope, null);
    						$scope.closeThisDialog();
    						generalService.locationPath("/simulador");
    						
    					}, function(error) {
	    						$rootScope.waitLoaderStatus = LOADER_HIDE;
	    						generalService.cleanRootScope($rootScope);
	    						generalServiceOS.cleanRootScope($rootScope);
	    						generalService.buildSolicitudJson($rootScope, null);
	    						generalService.buildSolicitudOSJson($rootScope, null);
	    						modalService.alertModal("Error "+error.status, [error.statusText]);
	    						generalService.locationPath("/simulador");
					}
    				);
    		}
    	
    });
});