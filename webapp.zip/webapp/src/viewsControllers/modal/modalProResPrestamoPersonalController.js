/**
 * 
 */'use strict';

define(["app"], function (app) {

    app.controller("modalProResPrestamoPersonalController", function ( $scope, $rootScope, $timeout, generalService, $location, $interval, solicitudService, buroService,generalServiceOS) {
    	
    	var tipoTasa = tipoTasas.ppRescate.id;
    	$scope.aceptaOS = "0";
    	$scope.opcPrestamo=0;
    	$scope.mostrarSlider=true;
    	$scope.mostrarPlazos=true;
    	
    	$scope.$parent.muestraTermometro = true;
    	$scope.MUESTRA_OFERTA=1;
		$scope.documentosDescCom = "";
		$scope.MUESTRA_OFERTA_COTIZADOR=2;
		$scope.MUESTRA_COTIZADOR=3;
		$scope.MUESTRA_ERROR=4;
		$scope.muestraRadios = false;
		$scope.OFERTA_EXITO=1;
		$scope.OFERTA_RECALCULAR=2;
		$scope.banderaComprobables = true;
		$scope.mostrarSugerido = true;
		$scope.banderaSugerido = false;
		$scope.esMenor = false;
		$scope.fechaNac = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento;
		$scope.creditoInmediatoHabilitado = $rootScope.consultaFuncionalidad.creditoInmediatoHabilitado;
    	$scope.limitCredOS = 4000;
    	$scope.limitCredGarantias = 3900;
    	$scope.mostrarOpcGarantias = true;
    	$scope.sinOferta=$rootScope.solicitudJson.marca==STATUS_SOLICITUD.generada.marca.prodResPrestamoMatriz?true:false;
    	$scope.conOS=$rootScope.solicitudJson.marca==STATUS_SOLICITUD.generada.marca.clienteAceptoProductoCosumo||$rootScope.rescatePPObligado?true:false;
    	$scope.conGarantias=$rootScope.solicitudJson.marca==STATUS_SOLICITUD.generada.marca.prodResPrestamoConGarantias||$rootScope.rescatePPGarantias?true:false;

    	$scope.mostrarCuatroMil = false;
    	
    	var arrayPlazosG = generalService.getPlazos( $rootScope );
    	var arrayPlazosGarantias=[];
    	
    	if($rootScope.rescatePPGarantias){
			for(var i = 0, j = 0; i < arrayPlazosG.length; i++){
				if( arrayPlazosG[i].monto ==2000){
					arrayPlazosGarantias[0] = arrayPlazosG[i];
				}
			}
			$rootScope.buroHandler=arrayPlazosGarantias;
    	}
    	
    	if($rootScope.buroHandler!=null && $rootScope.buroHandler.length > 1){
    		$scope.mostrarCuatroMil = true;
    	}
    	
    	$scope.arregloMontos=[];
    	$scope.OpcMonto = 0;
    	
    	$scope.isCDT = generalService.isCDT();
    	
    	
    	$scope.init = function(marca){
    		/*$scope.cargarMensaje = "<div style='text-align: center;'>Infórmale a tu cliente que el préstamo personal no fue autorizado por el monto que él solicita," +
			" pero podria llevarse uno a su medida si nos proporciona un Coacreditado:" + "<br/><br/>"
				+ "Ingresa el monto a cotizar ($2,000 a $4,000): <br/><br/> "
	            + "</div>";*/
    		
    		$scope.cargarMensaje = "<div style='text-align: center;'> <b>¡Creemos en ti!</b> con un buen comportamiento de pago con nosotros, " +
    				"puedes construir un buen historial de crédito. <br/><br/> </div>";

    		$scope.mensajeGarantias = "<div style='text-align: center;'> * Las Garantías Prendarías deben cubrir el doble del préstamo solicitado y serán registradas en el proceso de " +
    				"verificación </div>";
    		
    		$scope.mensajeAutorizacion = "<div style='text-align: center;'> La autorización del crédito está sujeta a cumplir con estos requisitos y esperar resultado de visita en domicilio.  </div>";
    		
    		$scope.mensajeCOS="Coacreditado";
    		$scope.mensajeCGP="Garantías Prendarias";
    		
    		$scope.descripcion="Préstamo:";
    		$scope.textoPagoNormal="Pago semanal:";
    		$scope.textoPagoPuntual="Pago puntual:";
    		$scope.textoPlazo="Plazo:";
    		
    		$scope.objMonto=null;
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			$scope.tituloHeader="Cotizador";
			$scope.opcion=$scope.MUESTRA_COTIZADOR;
			$scope.tipoOferta=$scope.OFERTA_EXITO;
			$scope.mostrarDocumentos=false;
			$scope.alcanzaMoto=false;
			$scope.listaDocumentos=[];
			$scope.muestraOfertaItalika=false;
			$scope.muestraOfertaConsumo=false;
			$scope.condicionesMostrarPantallas();
			$scope.isCreditoInmediato = $rootScope.solicitudJson.creditoInmediato==1?true:false;
			$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";
			$scope.respaldoJsonSolicitud=null;
			$scope.isComprobable=false;
			$scope.periodicidad="semanas";
			$scope.inicializaSlider();
    		
			$scope.respaldoJsonSolicitud=JSON.parse(JSON.stringify($rootScope.solicitudJson));
			$scope.montoCampo = $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto;

			
			if (!$scope.muestraCPComprobable && $scope.muestraCPNoComprobable ){
				$scope.banderaComprobables = false;
			}
			$scope.calculaMaximos();
			
			$scope.banderaComprobables = ($scope.banderaComprobableAux)?true:false;
    	}
    	
    	function redondearValor(valor, unidad){
			var valorDes = Math.ceil(valor / unidad) * unidad
			var valorAnt = valorDes - unidad;
			
			var valorR1 = valorDes - valor;
			var valorR2 = valor - valorAnt;
			
			if(valorR1 <= valorR2){
				return valorDes; 
			}else{
				return valorAnt; 
			}
			
		}
    	
    	$scope.calculaMaximos = function(){
			var arrayPlazos = generalService.getPlazos( $rootScope );
			arrayPlazos.sort(function (a, b) {
				  if (a.monto > b.monto) {
				    return 1;
				  }
				  if (a.monto < b.monto) {
				    return -1;
				  }
				  // a must be equal to b
				  return 0;
				});
			for(var i = 0; i < arrayPlazos.length; i++){
				if (!arrayPlazos[i].cpComprobable){
//					continue
				}else{
					$scope.maxComproblable = arrayPlazos[i];
				}
				if (!arrayPlazos[i].cpNoComprobable){
//					continue
				}else{
					$scope.maxNoComproblable = arrayPlazos[i];
				}
			}
			
			if ($scope.maxComproblable){
				
					$scope.montoProComprobable = ($scope.maxComproblable.monto + $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto)/2;
					$scope.montoProComprobable = redondearValor($scope.montoProComprobable, 100);
					$scope.plazoMaxComprobables = $scope.maxComproblable.cpComprobable[ $scope.maxComproblable.cpComprobable.length - 1]
					$scope.maxCom  = $scope.calculaNuevosMontosMax($scope.maxComproblable.monto, $scope.plazoMaxComprobables);
					
					if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxCom.monto && $scope.banderaComprobables){
						$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto =  $scope.maxCom.monto;
					}
					var detalleCom = $scope.buscaMontoAproximado($scope.montoProComprobable, true,100, true);
					$scope.detalleCom = $scope.calculaNuevosMontosMax(detalleCom.monto, detalleCom.plazo);					
			}
			
			if ($scope.maxNoComproblable){
				
					$scope.montoProNoComprobable = ($scope.maxNoComproblable.monto + $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto)/2;
					$scope.montoProNoComprobable = redondearValor($scope.montoProNoComprobable, 100);
					$scope.plazoMaxNoComprobables = $scope.maxNoComproblable.cpNoComprobable[ $scope.maxNoComproblable.cpNoComprobable.length - 1]
					$scope.maxNoCom = $scope.calculaNuevosMontosMax($scope.maxNoComproblable.monto, $scope.plazoMaxNoComprobables);
					
					if ( ($scope.maxNoCom!=undefined)&&($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxNoCom.monto && !$scope.banderaComprobables)){
						$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = $scope.maxNoCom.monto;
					}
					
					var detalleNoCom = $scope.buscaMontoAproximado($scope.montoProNoComprobable, false,100, true);
					$scope.detalleNoCom = $scope.calculaNuevosMontosMax(detalleNoCom.monto, detalleNoCom.plazo);
			}
			
			if ($scope.banderaSugerido && $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto != $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto ){
				$scope.mostrarSugerido = false;
			}
		}
    	
    	    	
    	$scope.rechazar = function(){
    		var x = {
			    idSolicitud : $rootScope.solicitudJson.idSolicitud,
			    idSeguimiento: STATUS_SOLICITUD.rechazada.id,
			    idMotivoRechazo: STATUS_SOLICITUD.rechazada.idMotivoRechazo.rechazoPrestamoRescate
			}
    		
    		$rootScope.waitLoaderStatus = LOADER_SHOW;
    		solicitudService.actualizarSolicitud( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.cleanRootScope($rootScope);
					generalService.buildSolicitudJson($rootScope, null);
					generalService.buildSolicitudOSJson($rootScope, null);
					$scope.closeThisDialog();
					generalService.locationPath("/simulador");
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.cleanRootScope($rootScope);
					generalService.buildSolicitudJson($rootScope, null);
					generalService.buildSolicitudOSJson($rootScope, null);
					modalService.alertModal("Error "+error.status, [error.statusText]);
					$scope.closeThisDialog();
					generalService.locationPath("/simulador");
			});
    	}
    	
    	$scope.inicializaSlider=function(){
			if($rootScope.buroHandler){
				$scope.buildSlider();
			}
		};
    	
    	$scope.buildSlider = function(){
			
			var cambiaMontoCallback = function( valorSlider ){
		 		$timeout( function(){ 
	 				angular.element( document.getElementById( "volverCotizar" ) ).scope().reBuildSlider( valorSlider );
	 			}, 0);
			};
			
			if( $scope.$parent.muestraTermometro){
				
				var plazos = generalService.getPlazos($rootScope );
				  
				var arrayMontos = plazos.map( function(d){
					return d['monto'];
				});
				
				arrayMontos = generalService.mergeSort(arrayMontos);
				$scope.arregloMontos = arrayMontos;
				
				var monto = parseInt($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto);
				var index = arrayMontos.indexOf( monto );

				var _min = Math.min.apply( 0, arrayMontos );
				var _max = Math.max.apply( 0, arrayMontos );
								
				if( index == -1 )
					monto = _max;
				  
				$scope.minMonto = _min;
				$scope.maxMonto = _max;
				
				var step=500;
				var len = arrayMontos.length;
				
				if( arrayMontos[0] )
					if( arrayMontos[1] )
						step = arrayMontos[1]-arrayMontos[0];
				
				var fnCrearSliderCallBack = function(){
					slider( _min , _max, step, monto, '.amountVolCotizar div', arrayMontos, cambiaMontoCallback, "#sliderVolCotizar");
				};
				
				$scope.createSliderThread( 'sliderVolCotizar', fnCrearSliderCallBack, true );
				
			}
			
		};
		
		$scope.buildSliderNoCom = function(comprobables){
			
			var cambiaMontoCallback = function( valorSlider ){
		 		$timeout( function(){ 
	 				angular.element( document.getElementById( "volverCotizar" ) ).scope().reBuildSlider( valorSlider );
	 			}, 0);
			};
			
			if( $scope.$parent.muestraTermometro){
				
				var plazosArray = generalService.getPlazos($rootScope );
				var plazos=[]; 
				if (comprobables){
					for (var i = 0; i < plazosArray.length; i++){
						if (!plazosArray[i].cpComprobable){
							continue;
						}else{
							plazos.push(plazosArray[i]);							
						}
					}
				}else{
					for (var i = 0; i < plazosArray.length; i++){
						if (!plazosArray[i].cpNoComprobable){
							continue;
						}else{
							plazos.push(plazosArray[i]);
						}
					}
				}
				
				var arrayMontos = plazos.map( function(d){
					return d['monto'];
				});
				
				arrayMontos = generalService.mergeSort(arrayMontos);
				$scope.arregloMontos = arrayMontos;
				
				var monto = parseInt( $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
				var index = arrayMontos.indexOf( monto );

				var _min = Math.min.apply( 0, arrayMontos );
				var _max = Math.max.apply( 0, arrayMontos );
								
				if( index == -1 ){
					var aprox = $scope.buscaMontoAproximado(monto, $scope.banderaComprobables, 100, false);
					monto = aprox.monto;
				}
				  
				$scope.minMonto = _min;
				$scope.maxMonto = _max;
				
				var step=500;
				var len = arrayMontos.length;
				
				if( arrayMontos[0] )
					if( arrayMontos[1] )
						step = arrayMontos[1]-arrayMontos[0];
				
				var fnCrearSliderCallBack = function(){
					slider( _min , _max, step, monto, '.amountVolCotizar div', arrayMontos, cambiaMontoCallback, "#sliderVolCotizar");
				};
				
				$scope.createSliderThread( 'sliderVolCotizar', fnCrearSliderCallBack, true );
				
			}
			
		};
		
		$scope.reBuildSlider = function ( valorSlider )
		{		

			var cambiaMontoCallback = function(){								


				$scope.plazosCotizador = $scope.calculaPlazosTermometroNuevo( valorSlider);
				
				if( $scope.plazosCotizador.length == 1  ){
					$scope.mostrarPlazos=false;
					if(valorSlider >= 4000){
						$scope.mostrarSlider=true;
					}else{
						$scope.mostrarSlider=false;
					}
				}else{
					$scope.mostrarPlazos=true;
				}
				
				if( $scope.minMonto==$scope.maxMonto ){
					$scope.mostrarSlider=false;
				}
				
				var plazo = $scope.respaldoNuevoPlazo?$scope.respaldoNuevoPlazo:$rootScope.solicitudJson.cotizacion.plazo;
				$scope.respaldoNuevoPlazo = plazo;
				var encontro = false;
				for (var i = 0; i < $scope.plazosCotizador.length; i++){
					if ($scope.plazosCotizador[i] >= $scope.respaldoNuevoPlazo){
						plazo = $scope.plazosCotizador[i];
						encontro = true
						break;
					}
				 }
				 if (!encontro){
				 	plazo = $scope.plazosCotizador[$scope.plazosCotizador.length - 1]
				 }
				 console.log(plazo);
				
				
				$timeout(function(){
					$scope.actualizaMonto();	 		
					$scope.validaPlazoComprobableInmediato(plazo,valorSlider);
					$scope.calculaNuevosMontos();						
				}, 50)
		 		
				var index = $scope.plazosCotizador.indexOf( plazo );
				$scope.deshabilitarRecalcular = true;
		 		$scope.actualizaMonto();
		 		$scope.calculaMaximos();
				if(index != -1 ){
					if(plazo = plazo)
					$scope.validaPlazoComprobableInmediato( plazo, valorSlider ); 
					$scope.calculaNuevosMontos();
					$timeout( function(){
						$('.requisitosCotDos ul li > a').each(function(){
							if( parseInt($(this).text()) == parseInt(plazo) ){
								if(!$(this).hasClass( "active" )){
									limpiarClasePlazos();
									$( this ).addClass('active'); 
								}
								return;
							};
						});
						$scope.actualizaPlazo();
					}, 10 );
				}else{
					$scope.mostrarDocumentos=false;
					limpiarClasePlazos();
					$scope.nuevoPlazo=0;
					$scope.actualizaPlazo($scope.plazosCotizador[$scope.plazosCotizador.length - 1]);
				}
								
			};
			
			$scope.createSliderThread( 'sliderVolCotizar', cambiaMontoCallback, false );
			$timeout(function(){$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
			
			if($scope.nuevoMonto != $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto)
				$scope.buildSliderNoCom($scope.banderaComprobables);
			}, 100);
			
			
			// Intentando actualizar la bandera immediateCredit.
			//wouldBeImmediateCredit();
	 	};/* END UISLIDER FUNCTION */
	 	
	 	function number_format(amount, decimals) {

	 	    amount += ''; // por si pasan un numero en vez de un string
	 	    amount = parseFloat(amount.replace(/[^0-9\.]/g, '')); // elimino cualquier cosa que no sea numero o punto

	 	    decimals = decimals || 0; // por si la variable no fue fue pasada

	 	    // si no es un numero o es igual a cero retorno el mismo cero
	 	    if (isNaN(amount) || amount === 0) 
	 	        return parseFloat(0).toFixed(decimals);

	 	    // si es mayor o menor que cero retorno el valor formateado como numero
	 	    amount = '' + amount.toFixed(decimals);

	 	    var amount_parts = amount.split('.'),
	 	        regexp = /(\d+)(\d{3})/;

	 	    while (regexp.test(amount_parts[0]))
	 	        amount_parts[0] = amount_parts[0].replace(regexp, '$1' + ',' + '$2');

	 	    return amount_parts.join('.');
	 	}
	 	
	 	$scope.createSliderThread = function( idSlider, fnCrearSliderCallBack, isFirstTime ){											
			
			var stopInterval = null, intervalCont = 1;
			
			var verifySlider = function(){
				var sliderVal = $( "#" + idSlider ).slider( "value" );
				return !(isNaN( sliderVal ));
			};
							
			var trySlider = function(){					
				if( verifySlider() ){
					$interval.cancel( stopInterval )
					if( fnCrearSliderCallBack && fnCrearSliderCallBack != null )
						fnCrearSliderCallBack();
				}else if( intervalCont == 100 )
					$interval.cancel( stopInterval )
				else{
					intervalCont++;
					if( isFirstTime )
						if( fnCrearSliderCallBack && fnCrearSliderCallBack != null )
							fnCrearSliderCallBack();
				}
			};
			stopInterval = $interval( trySlider, 100 );
									
			
		};/* END THREAD SLIDER FUNCTION */
	 	
	 	$scope.reBuildSlider = function ( valorSlider )
		{		
			var cambiaMontoCallback = function(){
				
				$scope.plazosCotizador = $scope.calculaPlazosTermometroNuevo( valorSlider);
				
				if( $scope.plazosCotizador.length == 1  ){
					$scope.mostrarPlazos=false;
					if(valorSlider >= 4000){
						$scope.mostrarSlider=true;
					}else{
						$scope.mostrarSlider=false;
					}
				}else{
					$scope.mostrarPlazos=true;
				}
				
				if( $scope.minMonto==$scope.maxMonto ){
					$scope.mostrarSlider=false;
				}
				
				var plazo = $scope.respaldoNuevoPlazo?$scope.respaldoNuevoPlazo:$rootScope.solicitudJson.cotizacion.plazo;
				$scope.respaldoNuevoPlazo = plazo;
				var encontro = false;
				for (var i = 0; i < $scope.plazosCotizador.length; i++){
					if ($scope.plazosCotizador[i] >= $scope.respaldoNuevoPlazo){
						plazo = $scope.plazosCotizador[i];
						encontro = true
						break;
					}
				 }
				 if (!encontro){
				 	plazo = $scope.plazosCotizador[$scope.plazosCotizador.length - 1]
				 }
				 console.log(plazo);
				
//				var plazo = $scope.respaldoNuevoPlazo?$scope.respaldoNuevoPlazo:$rootScope.solicitudJson.cotizacion.plazo;
				
				$timeout(function(){
					$scope.actualizaMonto();	 		
					$scope.validaPlazoComprobableInmediato(plazo,valorSlider);
					$scope.calculaNuevosMontos();						
				}, 50)
		 		
				var index = $scope.plazosCotizador.indexOf( plazo );
				$scope.deshabilitarRecalcular = true;
		 		$scope.actualizaMonto();
		 		$scope.calculaMaximos();
				if(index != -1 ){
					if(plazo = plazo)
					$scope.validaPlazoComprobableInmediato( plazo, valorSlider ); 
					$scope.calculaNuevosMontos();
					$timeout( function(){
						$('.requisitosCotDos ul li > a').each(function(){
							if( parseInt($(this).text()) == parseInt(plazo) ){
								if(!$(this).hasClass( "active" )){
									limpiarClasePlazos();
									$( this ).addClass('active'); 
								}
								return;
							};
						});
						$scope.actualizaPlazo();
					}, 10 );
				}else{
					$scope.mostrarDocumentos=false;
					limpiarClasePlazos();
					$scope.nuevoPlazo=0;
					$scope.actualizaPlazo($scope.plazosCotizador[$scope.plazosCotizador.length - 1]);
				}
								
			};
			
			$scope.createSliderThread( 'sliderVolCotizar', cambiaMontoCallback, false );
			$timeout(function(){$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
			
			if($scope.nuevoMonto != $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto)
				$scope.buildSliderNoCom($scope.banderaComprobables);
			}, 100);
			
			
			// Intentando actualizar la bandera immediateCredit.
			//wouldBeImmediateCredit();
	 	};/* END UISLIDER FUNCTION */
	 	
	 	function limpiarClasePlazos(){
			$('.requisitosCotDos ul li > a').each(function(){
	 			$( this ).removeClass('active');
	 	    });
			
		};/* END LIMPIAR CLASE PLAZO FUNCTION */
	 	
	 	$scope.onSeleccionaPlazo = function(valor,ui){	 		 		 	
	 		$scope.actualizaMonto();
	 		$scope.actualizaPlazo(ui.target.parentNode);		 		
	 		$scope.validaPlazoComprobableInmediato($scope.nuevoPlazo,$scope.nuevoMonto);
	 		$scope.calculaNuevosMontos();
	 		if ($scope.banderaSugerido){
				$scope.mostrarSugerido = false;
			}
	 	};/* END CONDICIONES TERMOMETRO FUNCTION */
    	
	 	$scope.actualizaMonto=function(){
	 		$scope.nuevoMonto= $( "#sliderVolCotizar" ).slider( "value" );
	 	};
	 	
	 	$scope.actualizaPlazo=function(nuevoPlazo){
	 		var plazo;
 			if(nuevoPlazo){
 				limpiarClasePlazos();
 				$(nuevoPlazo).addClass('active');
 			}
	 		$('.requisitosCotDos ul li > a').each(function(){
		 		if( $( this ).hasClass('active') ){
		 			plazo = parseInt( $(this).text() ); 
		 			return;
		 		};
		 	});
	 		$scope.nuevoPlazo= plazo;
	 		$scope.respaldoNuevoPlazo= plazo;
	 	};
	 	
	 	$scope.validaPlazoComprobableInmediato = function( plazo, monto ){
			var arrayPlazos = generalService.getPlazos( $rootScope ); 
			var tiposComprobantes=null;
			var indexPlazo = arrayPlazos.map( function(d){
				return d[ 'monto' ];
			}).indexOf( parseInt(monto) );
			
			var index = -1;
			var comprobante = false;
			var tiposComprobantes = null;
			
			if( indexPlazo != -1 && !$scope.banderaComprobables){
				
				var condicionRequeridaC = arrayPlazos[indexPlazo].requeridoComprobable;
				var condicionRequeridaNC = arrayPlazos[indexPlazo].requeridoNoComprobable;
				
				if( condicionRequeridaC != '' && condicionRequeridaC != null )
					condicionRequeridaC = condicionRequeridaC.split(",");
				if( condicionRequeridaNC != '' && condicionRequeridaNC != null )
					condicionRequeridaNC = condicionRequeridaNC.split(",");
				
				if( arrayPlazos[indexPlazo].cpNoComprobable ){
					
					index = arrayPlazos[indexPlazo].cpNoComprobable.indexOf( parseInt(plazo) );
					
					if( typeof condicionRequeridaNC == "object" && index != -1 && condicionRequeridaNC != null ){
						comprobante = true;
						tiposComprobantes = arrayPlazos[indexPlazo].requeridoNoComprobable;
					}
			
					if( index == -1 ){
						
						index = arrayPlazos[indexPlazo].cpComprobable.indexOf( parseInt(plazo) );
						
						if( typeof condicionRequeridaC == "object" && condicionRequeridaC != null){
							comprobante = true;
							tiposComprobantes = arrayPlazos[indexPlazo].requeridoComprobable;
						}
						
						if( index != -1 )
							comprobante = true;
					
					}
					
				}else{
					
					if( arrayPlazos[indexPlazo].cpComprobable && $scope.banderaComprobables){
						
						index = arrayPlazos[indexPlazo].cpComprobable.indexOf( parseInt(plazo) );
						
						if( typeof condicionRequeridaC == "object" && condicionRequeridaC != null ){
							comprobante = true;
							tiposComprobantes = arrayPlazos[indexPlazo].requeridoComprobable; 
						}
						
						if( index != -1 )
							comprobante = true;
						
					}
					
				}
				$scope.objMonto=arrayPlazos[indexPlazo];	
			}					
			$scope.isCreditoInmediato=false;
			//validar si ese plazo tiene credito inmediato
			if( comprobante ){
				$scope.isComprobable=true;
				if(arrayPlazos[indexPlazo].comprobableInm)
					$scope.isCreditoInmediato = generalService.masterFunction();
				$scope.listaDocumentos=[{desc:IDENTIFICACION_OFICIAL_INE.descripcion, id:IDENTIFICACION_OFICIAL_INE.id },{desc:COMP_DOMICILIO.descripcion, id: COMP_DOMICILIO.id}];
					
				if ($scope.banderaComprobables){
					$scope.listaDocumentos.push({desc:COMP_INGRESOS.descripcion, id:COMP_INGRESOS.id });
				}

				if ($scope.listaDocumentos.length > 0){
					$scope.mostrarDocumentos=true;
					$scope.documentosDescCom = $scope.crearLista($scope.listaDocumentos);
				}else
					$scope.mostrarDocumentos=false;
			}else{
				$scope.listaDocumentos=[{desc:IDENTIFICACION_OFICIAL_INE.descripcion, id:IDENTIFICACION_OFICIAL_INE.id },{desc:COMP_DOMICILIO.descripcion, id: COMP_DOMICILIO.id}];
				if ($scope.banderaComprobables){
					tiposComprobantes = arrayPlazos[indexPlazo].requeridoComprobable;

					$scope.listaDocumentos.push({desc:COMP_INGRESOS.descripcion, id:COMP_INGRESOS.id });

				}

				if ($scope.listaDocumentos.length > 0){
					$scope.mostrarDocumentos=true;
					$scope.documentosDescCom = $scope.crearLista($scope.listaDocumentos);
				}else{
					$scope.mostrarDocumentos=false;
				}
				
				
				if(arrayPlazos[indexPlazo].noComprobableInm)
					$scope.isCreditoInmediato = generalService.masterFunction();
					$scope.isComprobable=false;
			}
			
			return comprobante;
			
		};
		
		$scope.calculaNuevosMontos = function(){
			
 			var monto =  $scope.nuevoMonto;
	 		var periodicidad = $scope.respaldoJsonSolicitud.cotizacion.idPeriodicidad;
	 		var plazo = $scope.nuevoPlazo;			 	
	 		
	 		if($scope.muestraOfertaItalika){
	 			var pagoNormal;
	 			var pagoPuntual;
	 			for(var abonoItalika in $scope.objMonto.abonoSemanal){
	 				if($scope.objMonto.abonoSemanal[abonoItalika].plazo==plazo){
	 					pagoNormal=$scope.objMonto.abonoSemanal[abonoItalika].pagoNormal;
	 					pagoPuntual=$scope.objMonto.abonoSemanal[abonoItalika].pagoPuntual;
	 					break;	
	 				}			 						 					
	 			}
	 			if(pagoNormal && pagoPuntual){				
	 				var montoConIntereses = pagoNormal * plazo;
	 				
	 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = monto;
	 				$scope.respaldoJsonSolicitud.cotizacion.montoTotal = montoConIntereses;
	 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = montoConIntereses - monto;
	 				$scope.respaldoJsonSolicitud.cotizacion.pagoNormal = pagoNormal;
	 				
	 				$scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = pagoPuntual;
	 				$scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = pagoNormal;				
	 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = 1;
 					$scope.respaldoJsonSolicitud.cotizacion.plazo = plazo;
 					$scope.respaldoJsonSolicitud.cotizacion.idPlazo = plazo; 
	 							 				
	 			}else
	 				return null;
	 		}else{
	 			var arrayTempAbonos =  $rootScope.consultaAbonos.rescatePrestamo;
	 			for (var i = 0; i < arrayTempAbonos.length;i++){
		 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){
		 				   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = monto;
		 				   
//	 					   $scope.respaldoJsonSolicitud.cotizacion.montoTotal = parseFloat(arrayTempAbonos[i].sobre);
//	 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = parseInt($rootScope.solicitudJson.cotizacion.montoTotal - monto);
		 				   $scope.respaldoJsonSolicitud.cotizacion.montoTotal = parseInt(arrayTempAbonos[i].precio) + parseInt(arrayTempAbonos[i].sobre);
	 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = parseInt(arrayTempAbonos[i].sobre);
	 					   $scope.respaldoJsonSolicitud.cotizacion.pagoNormal = parseFloat(arrayTempAbonos[i].normal);
	 					   $scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = parseFloat(arrayTempAbonos[i].puntual);
	 					   $scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = parseInt(arrayTempAbonos[i].ultimo);
	 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto = arrayTempAbonos[i].sku;
	 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = 1;
	 					   $scope.respaldoJsonSolicitud.cotizacion.plazo = plazo;
	 					   $scope.respaldoJsonSolicitud.cotizacion.idPlazo = plazo; 
	 					   break; 
		 			}
		 		}
//		 		var arrayPlazoMonto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA",tipoTasa);
//		 		for ( var i = 1; i <= arrayPlazoMonto.length; i++ ){
// 					
//		 			if (monto        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.MONTO["+i+"].valor",tipoTasa) &&
// 						periodicidad == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PERIODICIDADID["+i+"].valor",tipoTasa) &&
// 						plazo        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PLAZO["+i+"].valor",tipoTasa) ){ 						
// 					   var tasaNormal = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA NORMAL["+i+"].valor",tipoTasa));
// 					   var tasaPuntual = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA PUNTUAL["+i+"].valor",tipoTasa));
// 					   var idProducto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PRODUCTOID["+i+"].valor",tipoTasa);
// 					   var montoNormal = monto * tasaNormal;
// 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = monto;
// 					   $scope.respaldoJsonSolicitud.cotizacion.montoTotal = monto + montoNormal;
// 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = parseInt($scope.respaldoJsonSolicitud.cotizacion.montoTotal - monto);
// 					   $scope.respaldoJsonSolicitud.cotizacion.pagoNormal = Math.round(parseFloat($scope.respaldoJsonSolicitud.cotizacion.montoTotal / plazo));
// 					   var montoPuntual = monto * tasaPuntual;
// 					   var montoTotalPuntual = monto + montoPuntual;
// 					   $scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = Math.round(parseFloat(montoTotalPuntual / plazo));
// 					   $scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = parseInt($scope.respaldoJsonSolicitud.cotizacion.montoTotal - $scope.respaldoJsonSolicitud.cotizacion.pagoNormal * (plazo - 1));
// 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto = idProducto;
// 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = 1;
// 					   $scope.respaldoJsonSolicitud.cotizacion.plazo = plazo;
// 					   $scope.respaldoJsonSolicitud.cotizacion.idPlazo = plazo; 
// 					   break;
// 					}
// 					
//		 		}
	 		}
	 		
	 		if($scope.isWinback)
	 			calculaMontosSinPromocion();
	 		
	 		return true;
	 		
 	};
		
 	
 	$scope.volverACotizar = function(detalle){
 		if (!detalle){
 			console.log("normal");
 		}else{
 			$scope.nuevoPlazo = detalle.plazo;
 			$scope.nuevoMonto =  detalle.monto;
 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = detalle.monto;
 			$scope.respaldoJsonSolicitud.cotizacion.montoTotal = detalle.montoTotal;
 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = detalle.intereses;
 			$scope.respaldoJsonSolicitud.cotizacion.pagoNormal = detalle.pagoNormal;
 			$scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = detalle.pagoPuntual;
 			$scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = detalle.ultimoAbono;
 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto = detalle.idProducto;
 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = detalle.cantidad;
 			$scope.respaldoJsonSolicitud.cotizacion.plazo = detalle.plazo;
 			$scope.respaldoJsonSolicitud.cotizacion.idPlazo = detalle.idPlazo; 
 			console.log(detalle);
 		}
		$scope.respaldoJsonSolicitud=JSON.parse(JSON.stringify($rootScope.solicitudJson));
		$scope.respaldoJsonSolicitud.banderaOfertaCP= 1;
 		if($scope.opcion==$scope.MUESTRA_OFERTA){
 			$rootScope.waitLoaderStatus = LOADER_SHOW;
 			$scope.guardarSeccion();
 		}else{
			if( $scope.nuevoPlazo &&  $scope.nuevoMonto){
	 			$rootScope.waitLoaderStatus = LOADER_SHOW;
		 			if($scope.calculaNuevosMontos()){
 		 			$scope.validaCreditoInmediatoIngresos();
 		 			$scope.guardarSeccion();
		 			}

			}else if(!$scope.nuevoPlazo){
				$rootScope.message( "Aviso", ["Favor de seleccionar un plazo"], "Aceptar");
			}else if(!$scope.nuevoMonto){
				$rootScope.message( "Aviso", ["Favor de seleccionar el monto"], "Aceptar");
			}
 		}
 	};
 	
 	$scope.condicionesMostrarPantallas=function(){
		$scope.muestraOfertaItalika=false;
		$scope.muestraOfertaConsumo=false;
		if($rootScope.solicitudJson.idCanal==CANALES.sams) {
			$scope.muestraOfertaItalika=true;
			if($rootScope.buroHandler)
				$scope.alcanzaMoto=true;
			else
				$scope.alcanzaMoto=false;
		}else if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.consumo ||
				 $rootScope.solicitudJson.idProducto == ID_PRODUCTO.italika ||
				 $rootScope.solicitudJson.idProducto == ID_PRODUCTO.telefonia){
			$scope.muestraOfertaConsumo=true;
			$scope.evaluarCPenConsumo();
			$scope.docuemntosConsumo();
		}
		$scope.evaluarCPenConsumo();	
		var muestraOferta=false;
		var muestraCotizador=false;
		var error=false;
		$rootScope.onceOfert=false;
		$rootScope.mostrarOfertaCotizador=false;
//		if($rootScope.solicitudJson.banderaOfertaCP == 0 && $rootScope.onceOfert)
				muestraOferta=true;						
		
		switch($rootScope.buroConditional){
			case BURO_RECALCULAR_PLAZO:
			case BURO_AUTORIZADO_PORCOMPROBAR:
				$scope.tituloHeader="¡Lo sentimos!";
				muestraCotizador=true;
				$scope.tipoOferta=$scope.OFERTA_RECALCULAR;
				$scope.generaVariablesMejorOferta();
				break;
			case BURO_AUTORIZADO_SCORE:
			case RESPONSE_ORIGINACION_CODIGO_EXITO:
				if(muestraOferta)
					$scope.tituloHeader="¡Felicidades!";
				muestraCotizador=true;
				break;
			default:
				error=true;
		}
		
		if(error)
			$scope.opcion=$scope.MUESTRA_ERROR;
		else if(muestraOferta && muestraCotizador)
			$scope.opcion=$scope.MUESTRA_OFERTA_COTIZADOR;
		else if(muestraOferta)
			$scope.opcion=$scope.MUESTRA_OFERTA;
		else if(muestraCotizador)
			$scope.opcion=$scope.MUESTRA_COTIZADOR;
	};
	
	function validaPlazosVista(arrayPlazos){
		var plazos = arrayPlazos;
		$scope.banderaComprobableAux = 0;
		$scope.banderaNoComprobableAux = 0;
		
		for(var i=0;i<plazos.length;i++){
			if(plazos[i].cpNoComprobable != null){
				$scope.banderaNoComprobableAux = 1;
			}
			
			if(plazos[i].cpComprobable != null){
				$scope.banderaComprobableAux = 1;
			}
		}
		
		if($rootScope.solicitudJson.capacidadPagoComprobable == $rootScope.solicitudJson.capacidadPagoNoComprobable){
			if($scope.banderaNoComprobableAux){
				$scope.banderaNoComprobableAux = 1;
				$scope.banderaComprobableAux = 0;
			}else if($scope.banderaComprobableAux){
				$scope.banderaNoComprobableAux = 0;
				$scope.banderaComprobableAux = 1;
			}else{
				$scope.banderaNoComprobableAux = 0;
				$scope.banderaComprobableAux = 0;
			}
		}
	}
	
	$scope.evaluarCPenConsumo=function(){
		$scope.muestraCPNoComprobable=false;
		$scope.muestraCPComprobable=false;
		$scope.muestraCPNoComprobableInmediato=false;
		$scope.muestraCPComprobableInmediato=false;
		
		var arrayPlazos = generalService.getPlazos( $rootScope );
		validaPlazosVista(arrayPlazos);
		
		var ingresoComp=$scope.getTipoIngreso(3);
		var ingresoNoComp=$scope.getTipoIngreso(4);
		
		if($rootScope.solicitudJson.capacidadPagoNoComprobable >= 50 && 
				(ingresoNoComp || ingresoComp)) {
			$scope.muestraCPNoComprobable=true;
		}
		
		if($rootScope.solicitudJson.capacidadPagoComprobable >= 50 && ingresoComp) {
			$scope.muestraCPComprobable=true;
		}
		
		if ($scope.muestraCPNoComprobable && $scope.muestraCPComprobable ){
			$scope.muestraRadios = true;
		}
		if(arrayPlazos){
			if(arrayPlazos.length>0){
				if(arrayPlazos[0].comprobableInm == 1 && $scope.muestraCPComprobable)
					$scope.muestraCPComprobableInmediato=true;
				if(arrayPlazos[0].noComprobableInm == 1 && $scope.muestraCPNoComprobable)
					$scope.muestraCPNoComprobableInmediato=true;
			}
		}
	};
 	
	$scope.getTipoIngreso=function(tipoIngreso){
		var arrayFlujo = $rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo;
		for(var efectivo in arrayFlujo){
			if(arrayFlujo[efectivo].idConcepto==tipoIngreso)
				return true;
		}
		return false;

	};
	
	$scope.calculaNuevosMontosMax = function(nuevoMonto, nuevoPLazo){
		
		var monto =  nuevoMonto;
 		var periodicidad = $rootScope.solicitudJson.cotizacion.idPeriodicidad;
 		var plazo = nuevoPLazo;	
 		
 		var arrayTempAbonos =  $rootScope.consultaAbonos.rescatePrestamo;
 		for ( var i = 0; i < arrayTempAbonos.length; i++ ){
 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){
				   var calculo = {};
				   calculo.monto = monto;
//				   calculo.montoTotal = parseFloat(arrayTempAbonos[i].sobre);
//				   calculo.intereses = parseInt(calculo.montoTotal - monto);
				   calculo.montoTotal = parseInt(arrayTempAbonos[i].precio) + parseInt(arrayTempAbonos[i].sobre);
				   calculo.intereses = parseInt(arrayTempAbonos[i].sobre);
				   calculo.pagoNormal =parseFloat( arrayTempAbonos[i].normal );
				   calculo.pagoPuntual = parseFloat(arrayTempAbonos[i].puntual);
				   calculo.ultimoAbono = parseInt(arrayTempAbonos[i].ultimo);
				   calculo.idProducto = arrayTempAbonos[i].sku;
				   calculo.cantidad = 1;
				   calculo.plazo = plazo;
				   calculo.idPlazo = plazo; 
				   break;
				}
 		}
 		
 		return calculo;
		
//			var monto =  nuevoMonto;
// 		var periodicidad = $rootScope.solicitudJson.cotizacion.idPeriodicidad;
// 		var plazo = nuevoPLazo;			 	
// 		var arrayPlazoMonto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA",tipoTasa);
//	 		for ( var i = 1; i <= arrayPlazoMonto.length; i++ ){
//					
//	 			if (monto        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.MONTO["+i+"].valor",tipoTasa) &&
//						periodicidad == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PERIODICIDADID["+i+"].valor",tipoTasa) &&
//						plazo        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PLAZO["+i+"].valor",tipoTasa) ){ 						
//					   var tasaNormal = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA NORMAL["+i+"].valor",tipoTasa));
//					   var tasaPuntual = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA PUNTUAL["+i+"].valor",tipoTasa));
//					   var idProducto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PRODUCTOID["+i+"].valor",tipoTasa);
//					   var montoNormal = monto * tasaNormal;
//					   var calculo = {};
//					   calculo.monto = monto;
//					   calculo.montoTotal = monto + montoNormal;
//					   calculo.intereses = parseInt(calculo.montoTotal - monto);
//					   calculo.pagoNormal = Math.round(parseFloat(calculo.montoTotal / plazo));
//					   var montoPuntual = monto * tasaPuntual;
//					   var montoTotalPuntual = monto + montoPuntual;
//					   calculo.pagoPuntual = Math.round(parseFloat(montoTotalPuntual / plazo));
//					   calculo.ultimoAbono = parseInt(calculo.montoTotal -calculo.pagoNormal * (plazo - 1));
//					   calculo.idProducto = idProducto;
//					   calculo.cantidad = 1;
//					   calculo.plazo = plazo;
//					   calculo.idPlazo = plazo; 
//					   break;
//					}
//					
//	 		}
// 		return calculo;
 		
	};
	
	$scope.buscaMontoAproximado = function(monto, comprobable, unidad, menor){
		var arrayPlazos = generalService.getPlazos( $rootScope );
		arrayPlazos.sort(function (a, b) {
			  if (a.monto > b.monto) {
			    return 1;
			  }
			  if (a.monto < b.monto) {
			    return -1;
			  }
			  // a must be equal to b
			  return 0;
			});
		var encontro = false;
		var detalle = {};
		if (comprobable){
			
			while (!encontro) {
				var index = arrayPlazos.map(function(d){
					return d["monto"];
					
				}).indexOf (monto);
				if (index != -1){
					if(!arrayPlazos[index].cpComprobable){
						if (menor){									
							monto = monto - unidad;
						}else{
							monto = monto + unidad;
						}
					}else{
						detalle.plazo = arrayPlazos[index].cpComprobable[ arrayPlazos[index].cpComprobable.length - 1];
						detalle.monto = monto;
						encontro = true;
						$scope.hayPromedio= true;
						break;
					}
				}else{
					if (menor){									
						monto = monto - unidad;
					}else{
						monto = monto + unidad;
					}
				}
				if (monto < 2000 || monto > arrayPlazos[arrayPlazos.length - 1].monto){
					encontro = true;
					$scope.hayPromedio= false;
				}
			}
		}else{
			while (!encontro) {
				var index = arrayPlazos.map(function(d){
					return d["monto"];
					
				}).indexOf (monto);
				if (index != -1){
					if(!arrayPlazos[index].cpNoComprobable){
						if (menor){									
							monto = monto - unidad;
						}else{
							monto = monto + unidad;
						}
					}else{
						detalle.plazo = arrayPlazos[index].cpNoComprobable[arrayPlazos[index].cpNoComprobable.length - 1]
						detalle.monto = monto; 
						encontro = true;
						$scope.hayPromedio= true;
						break;
					}
				}else{
					if (menor){									
						monto = monto - unidad;
					}else{
						monto = monto + unidad;
					}
				}
				if (monto < 2000 || monto > arrayPlazos[arrayPlazos.length - 1].monto){
					encontro = true;
					$scope.hayPromedio= false;
				}
			}
		}
		return detalle;
	}
	
	$scope.calculaPlazosTermometroNuevo = function( valor){
		var arrayPlazos = generalService.getPlazos( $rootScope ); 
		
		var index = arrayPlazos.map( function(d){
			return d['monto'];
		}).indexOf( parseInt(valor) );
		
		if( arrayPlazos.length == 0 ){
			$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
			$scope.opcion=$scope.MUESTRA_ERROR;
			return [];
		}			
		
		if( index != -1 ){
			
			var plazos = [];
			var _comprobables = arrayPlazos[index].cpComprobable;
			var _noComprobables = arrayPlazos[index].cpNoComprobable;
			
			_comprobables = _comprobables ? _comprobables : [];
			_noComprobables = _noComprobables ? _noComprobables : [];
			
			var comprobables = _comprobables;
			var noComprobables = _noComprobables;
			
			if (!$scope.banderaComprobables){
				comprobables = noComprobables
			}
			
			for( var i = 0; i < comprobables.length; i++ ){	
				if( plazos.indexOf( comprobables[i] ) == -1 ){
					plazos.push( comprobables[i] );
				}	
			}/* END FOR */
			
			return plazos.sort( function( a, b ){
				return a-b;/* Invert to asc */
			});
			
		}/* END IF INDEX */
		return [];
		
	};
	
	$scope.crearLista = function(array){
		var aux = []
		if (array.length == 1){
			aux[0] = array[0].desc
		}else{
			for(var i = 0; i < array.length; i++){
				aux[i]=array[i].desc;
			}
		}
		return aux;
	};
	
	$scope.buscaMonto = function(){								
		$scope.plazosCotizador = $scope.calculaPlazosTermometroNuevo( valorSlider);				
		
		if( $scope.plazosCotizador.length == 1  ){
			$scope.mostrarPlazos=false;
			if(valorSlider >= 4000){
				$scope.mostrarSlider=true;
			}else{
				$scope.mostrarSlider=false;
			}
		}else{
			$scope.mostrarPlazos=true;
		}
		
		if( $scope.minMonto==$scope.maxMonto ){
			$scope.mostrarSlider=false;
		}
		
		
		var plazo = 100;
		var index = $scope.plazosCotizador.indexOf( plazo );
		$scope.deshabilitarRecalcular = true;
		if(index != -1 ){
//			if(plazo = plazo)
			$scope.validaPlazoComprobableInmediato( plazo, valorSlider ); 
			$scope.calculaNuevosMontos();
			$timeout( function(){
				$('.requisitosCotDos ul li > a').each(function(){
					if( parseInt($(this).text()) == parseInt(plazo) ){
						if(!$(this).hasClass( "active" )){
							limpiarClasePlazos();
							$( this ).addClass('active'); 
						}
						return;
					};
				});
				$scope.actualizaPlazo();
			}, 10 );
		}else{
			$scope.mostrarDocumentos=false;
			limpiarClasePlazos();
			$scope.nuevoPlazo=0;
		}
						
	};
	
	$scope.promediaMonto=function(){
		
 		if($scope.OpcMonto === "2"){
 			$scope.montoCampo = "2,000";
 		}else if($scope.OpcMonto === "3"){
 			$scope.montoCampo = "3,000";
 			if($scope.opcPrestamo==4){
 				$scope.aceptaOS = "5";
				$scope.opcPrestamo=5;
 			}
 		}else{
 			$scope.montoCampo = "4,000";
 			if($scope.opcPrestamo==4){
 				$scope.aceptaOS = "5";
				$scope.opcPrestamo=5;
 			}
 		}
		
		if ($scope.montoCampo.length > 5){
	 		var valor = generalService.limpiaFormato( $scope.montoCampo, "NIP-$" );
	 		
	 		if (valor < MONTO_MAX_SALTOS){
	 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = redondearValor(valor, 100);
	 		}else{		 			
	 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = redondearValor(valor, 500);
	 		}
	 		if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto < 2000)
	 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = 2000;
	 		if ($scope.banderaComprobables){
	 			if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxCom.monto){
	 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = $scope.maxCom.monto;
	 			}
	 		}else{
	 			if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxNoCom.monto){
	 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto =$scope.maxNoCom.monto;
	 			}
	 		}
	 		$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto, 0);
	 		console.log($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
	 		if($scope.banderaComprobables){
				$scope.buildSliderNoCom(true);
				$timeout(function(){$scope.buildSliderNoCom(true);}, 1)
			}else{
				$scope.buildSliderNoCom(false);
				$timeout(function(){$scope.buildSliderNoCom(false);}, 1)
			}
 		}else{
 			if ($scope.montoCampo.length > 4 && $scope.montoCampo.length < 6){
 				$timeout(function(){
 					if ($scope.montoCampo.length > 4){
		 				var valor = generalService.limpiaFormato( $scope.montoCampo, "NIP-$" );
		 				
		 				if (valor < MONTO_MAX_SALTOS){
				 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = redondearValor(valor, 100);
				 		}else{		 			
				 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = redondearValor(valor, 500);
				 		}
		 				
				 		if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto < 2000)
				 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = 2000;
				 		if($scope.banderaComprobables){
				 			if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxCom.monto){
				 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = $scope.maxCom.monto;
				 			}
				 		}else{
				 			if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxNoCom.monto){
				 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto =$scope.maxNoCom.monto;
				 			}
				 		}
				 		$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto, 0);
				 		console.log($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
				 		if($scope.banderaComprobables){
							$scope.buildSliderNoCom(true);
							$timeout(function(){$scope.buildSliderNoCom(true);}, 1)
						}else{
							$scope.buildSliderNoCom(false);
							$timeout(function(){$scope.buildSliderNoCom(false);}, 1)
						}
 					}
 				}, 500);
 			}
 		}
 		
 	};
 	
 	$scope.cambio=function(){
 		$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto, 0);
 	};

 	$scope.validarOS = function(){
		console.log("Validar Seccion: " + $scope.aceptaOS);
		$scope.opcPrestamo = parseInt($scope.aceptaOS);
		
		if(($scope.OpcMonto === "4" || $scope.OpcMonto === "3") && $scope.opcPrestamo==4){
			$scope.OpcMonto = "2";
			$scope.promediaMonto();
		}
		
	};
	
	$scope.volverACotizar = function(detalle){
 		if (!detalle){
 			console.log("normal");
 		}else{
 			$scope.nuevoPlazo = detalle.plazo;
 			$scope.nuevoMonto =  detalle.monto;
 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = detalle.monto;
 			$scope.respaldoJsonSolicitud.cotizacion.montoTotal = detalle.montoTotal;
 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = detalle.intereses;
 			$scope.respaldoJsonSolicitud.cotizacion.pagoNormal = detalle.pagoNormal;
 			$scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = detalle.pagoPuntual;
 			$scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = detalle.ultimoAbono;
 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto = detalle.idProducto;
 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = detalle.cantidad;
 			$scope.respaldoJsonSolicitud.cotizacion.plazo = detalle.plazo;
 			$scope.respaldoJsonSolicitud.cotizacion.idPlazo = detalle.idPlazo; 
 			console.log(detalle);
 		}
		$scope.respaldoJsonSolicitud=JSON.parse(JSON.stringify($rootScope.solicitudJson));
		$scope.respaldoJsonSolicitud.banderaOfertaCP= 1;
 		if($scope.opcion==$scope.MUESTRA_OFERTA){
 			$rootScope.waitLoaderStatus = LOADER_SHOW;
 			$scope.guardarSeccion();
 		}else{
			if( $scope.nuevoPlazo &&  $scope.nuevoMonto){
	 			$rootScope.waitLoaderStatus = LOADER_SHOW;
		 			if($scope.calculaNuevosMontos()){
 		 			//$scope.validaCreditoInmediatoIngresos();
 		 			$scope.guardarSeccion();
		 			}

			}else if(!$scope.nuevoPlazo){
				$rootScope.message( "Aviso", ["Favor de seleccionar un plazo"], "Aceptar");
			}else if(!$scope.nuevoMonto){
				$rootScope.message( "Aviso", ["Favor de seleccionar el monto"], "Aceptar");
			}
 		}
 	};
 	
 	$scope.guardarSeccion = function() {
 		/**
 		 * Se valida la bandera de creditoInmediato, antes de guardar.
 		 */
 		(function() {
 			// Qué monto lleva la solicitud.
 			var monto = $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto;
 			
 			// ¿Se están comprobando ingresos?
 			var comprobando = $scope.banderaComprobables;
 			
 			// Se obtiene el detalle de buró.
 			var detalleBuro = generalService.getPlazos($rootScope);
 			
 			// A priori, no es crédito inmediato.
 			var immediateCreditProbability = false;
 			
 			// ¿Hay posibilidad de crédito inmediato?
 			if(immediateCreditProbability) {
 				// ¿cómo debe ir la bandera de ingresos?
 				$scope.respaldoJsonSolicitud.banderaIngresos = comprobando ? 1 : 0;
 				
 				// Señora masterFunction, haga usted favor de hacer su magia.
 				$scope.respaldoJsonSolicitud.creditoInmediato = generalService.masterFunction(
 						$scope.respaldoJsonSolicitud) ? 1 : 0;		 				
 			} else {
 				// No hay crédito inmediato para vos, señor/a.
 				$scope.respaldoJsonSolicitud.creditoInmediato = 0;
 			}
 		})();
 		
 		solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($scope.respaldoJsonSolicitud), seccion: SECCION_SOLICITUD } ).then(
	 			function(data){
	 				//$rootScope.waitLoaderStatus = LOADER_HIDE;
	 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
	 					
	 					if(  $scope.sinOferta ){
	 					
	 					//Consumir el servicio de actualizar producto
						var json = {
								idSolicitud: $rootScope.solicitudJson.idSolicitud,
								opcion: $scope.opcPrestamo
						}
	 					
						buroService.actualizarProductoConsumo( json ).then(
								function(data){
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									
									if( data.data.codigo != undefined ){
										var responseJson = JSON.parse(data.data.respuesta);
										
										if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
											
											if($scope.opcPrestamo==4){
												$rootScope.rescatePPGarantias =true;
											}else{
												$rootScope.requiereObligado = true;
												$rootScope.rescatePPObligado = true;
											}
											
											$rootScope.capacidadesPagoProducto = responseJson.data.capacidadesPagoProducto;
											$rootScope.solicitudJson = responseJson.data.solicitud;
											$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO
											$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
											$rootScope.mostrarOfertaCotizador = false;
											$rootScope.onceOfert = true;
											
											$scope.$parent.muestraAlertaNuevoBuro=false;
											$scope.$parent.muestraMensajeNuevoBuro=false;
											$scope.$parent.mensajeNuevoBuro="";
											
											$rootScope.calculaDocumentos();
											
											/** if( $rootScope.solicitudJson.marca==STATUS_SOLICITUD.generada.marca.prodResPrestamoConGarantias ){
												$rootScope.message("Aviso Importante",["Informale a tu cliente que recibira una vista del JV donde tendra que presentar " +
														"un equivalente en garantias 2 a 1 para poder concluir su prestamo."], "Aceptar");
											} **/
											
											$scope.closeThisDialog(true);
											
										} else{
											generalService.cleanRootScope($rootScope);							
											generalService.buildSolicitudJson($rootScope, null);
											if($rootScope.solicitudOSJson){
												generalServiceOS.cleanRootScope($rootScope);
												generalService.buildSolicitudOSJson($rootScope, null);
											}
											$scope.closeThisDialog(false);
											$rootScope.message("Error " + responseJson.codigo,[responseJson.descripcion], "Aceptar", "/simulador", "bgazul");
										} 
										
									}else {
										generalService.cleanRootScope($rootScope);							
										generalService.buildSolicitudJson($rootScope, null);
										if($rootScope.solicitudOSJson){
											generalServiceOS.cleanRootScope($rootScope);
											generalService.buildSolicitudOSJson($rootScope, null);
										}
										$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul");
									}
									
								}, function(error){
									generalService.cleanRootScope($rootScope);							
									generalService.buildSolicitudJson($rootScope, null);
									if($rootScope.solicitudOSJson){
										generalServiceOS.cleanRootScope($rootScope);
										generalService.buildSolicitudOSJson($rootScope, null);
									}
									$rootScope.message("Error ",[" Favor de intentar nuevamente se detectó un problema "], "Aceptar", "/simulador", "bgazul");
								}	  
							  );
						
		 				}else{
		 					var responseJson = JSON.parse(data.data.respuesta);
		 					
		 					$rootScope.solicitudJson = responseJson.data;
		 					$rootScope.waitLoaderStatus = LOADER_HIDE;
		 					$scope.closeThisDialog(true);
		 				}
	 				}else{
	 					$rootScope.waitLoaderStatus = LOADER_HIDE;
	 					$rootScope.message("Error",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
	 				}
	 			}, function(error){                     
	 				$rootScope.waitLoaderStatus = LOADER_HIDE;
	 				$rootScope.message("Error al volver a cotizar",[ "Error del servicio guardar solicitud sección 9"], "Aceptar", null);								
	 			}	
			);
 		
	}
 	
 	
    });
});