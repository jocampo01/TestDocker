'use strict';

define(["app"], function (app) {

    app.controller("modalProResTelefoniaController", function ( $scope, $rootScope, $timeout, documentosService, expedienteService, generalService, generalServiceOS, solicitudService) {
    	
	    $scope.aceptaOS = "0";
	    $rootScope.opcTelefonia = 0;
	    $scope.mostrarOS = $rootScope.consultaFuncionalidad.habilitarOSTelefonia;
	    
	    	$scope.init = function(codigosBuro){
	    		if( codigosBuro)
	    			$scope.respuestaBuro(codigosBuro);
	    		else
	    			$scope.respuestaBuro(1270);
	 	}
    	
	    	$scope.respuestaBuro = function(codigosBuro){
	    		
	    		$scope.mostrarResultadoBuro = true;
	    		
				//switch( codigosBuro ){
				//case 1270:
	    		/** 
					$scope.mensaje = "<div style='text-align: justify;'>Infórmale a tu cliente que el producto y monto cotizados no fueron autorizados, sin"
									+ " embargo, tiene las siguientes alternativas de ser aprobado su crédito de <b>Telefonía</b>, después de una visita a su domicilio:" + "<br/><br/>"
				                    +	"</div>";
					$scope.mensajeSOSEnMen = "<ul><br/>"
	                    + 	"<li style='padding-right: 25px;' > &nbsp;- Le prestamos hasta "+ OPCION_TELEFONIA[0].monto +" para que compre el teléfono que quiera dejando un enganche mínimo del "+ OPCION_TELEFONIA[0].enganche + ".</li>"
	                    + 	"<li> &nbsp;- Plazo único de " + OPCION_TELEFONIA[0].plazo + " semanas" + "</li>"
	                    + "</ul>";
					$scope.mensajeSOSEnMay = "<ul><br/>"
	                    + 	"<li style='padding-right: 25px;' > &nbsp;- Le prestamos hasta "+ OPCION_TELEFONIA[1].monto +" para que compre el teléfono que quiera dejando un enganche mínimo del "+ OPCION_TELEFONIA[1].enganche + ".</li>"
	                    + 	"<li> &nbsp;- Plazo único de " + OPCION_TELEFONIA[1].plazo + " semanas" + "</li>"
	                    + "</ul>";
					$scope.mensajeCOS = "<ul><br/>"
	                    + 	"<li style='padding-right: 25px;' > &nbsp;- Le prestamos hasta "+ OPCION_TELEFONIA[2].monto +" para que compre el teléfono que quiera dejando un enganche mínimo del "+ OPCION_TELEFONIA[2].enganche + ".</li>"
	                    + 	"<li> &nbsp;- Plazo único de " + OPCION_TELEFONIA[2].plazo + " semanas" + "</li>"
	                    + "</ul>"; **/
					//break;
				//}
	    		
	    		
	    		$scope.mensaje = "<div style='text-align: center;'><b>¡Creemos en ti!</b> Con un buen comportamiento de pago con nostros, puedes " +
    					"construir un buen historial de crédito." + "<br/><br/>"
                    +	"</div>";
	    		
				$scope.mensajeSOSEnMen = ""+ OPCION_TELEFONIA[0].monto +" Con enganche mínimo de "+ OPCION_TELEFONIA[0].enganche + " sin Coacreditado";
				
				$scope.mensajeSOSEnMay = ""+ OPCION_TELEFONIA[1].monto +" Con enganche mínimo de "+ OPCION_TELEFONIA[1].enganche + " sin Coacreditado";
				
				$scope.mensajeCOS = ""+ OPCION_TELEFONIA[2].monto +" Con enganche mínimo de "+ OPCION_TELEFONIA[2].enganche + " con Coacreditado";
	    	}
	    	
	    	$scope.rechazar = function(){
	    		var x = {
				    idSolicitud : $rootScope.solicitudJson.idSolicitud,
				    idSeguimiento: STATUS_SOLICITUD.rechazada.id,
				    idMotivoRechazo: STATUS_SOLICITUD.rechazada.idMotivoRechazo.rechazoTelefoniaRescate
				}
	    		
	    		$rootScope.waitLoaderStatus = LOADER_SHOW;
				solicitudService.actualizarSolicitud( x ).then(
					 function(data){
						 $rootScope.waitLoaderStatus = LOADER_HIDE;
						 generalService.cleanRootScope($rootScope);
						 generalService.buildSolicitudJson($rootScope, null);
						 generalService.buildSolicitudOSJson($rootScope, null);
						 $scope.closeThisDialog();
						 generalService.locationPath("/simulador");
					 }, function(error) {
						 $rootScope.waitLoaderStatus = LOADER_HIDE;
 						 generalService.cleanRootScope($rootScope);
 						 generalService.buildSolicitudJson($rootScope, null);
 						 generalService.buildSolicitudOSJson($rootScope, null);
 						 modalService.alertModal("Error "+error.status, [error.statusText]);
 						 $scope.closeThisDialog();
 						 generalService.locationPath("/simulador");
				});
	    	}
	    	
	    	
	    	$scope.validarOS = function(){
	    		console.log("Validar Seccion: " + $scope.aceptaOS);
	    		$rootScope.opcTelefonia = parseInt($scope.aceptaOS);
	    	}
    	
    });
});