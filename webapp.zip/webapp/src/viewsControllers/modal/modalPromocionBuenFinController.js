'use strict';

define(["app"], function (app) {
	
	app.controller('modalPromocionBuenFinController', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService, validateService, buroService, modalService) {
		
		$scope.showPage=false;
		$scope.intentoImpresion=1;
		
		$scope.init=function(){

			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			$scope.isIpad=configuracion.so.ios;
			
			$scope.textoFelicidades			=	"¡Felicidades!";
			$scope.textoGanaste				=	"¡"+$rootScope.solicitudJson.cotizacion.clientes[0].nombre+" Ganaste!";
			$scope.textoCredito				=	$scope.ngDialogData.jsonResponsePromo.mensaje;
			
			$scope.textoAdemascontupedido	=	"¡Además participas en el Gran Concurso por $50,000!";
			$scope.textoNumPedido			=	" con tu pedido número: " +  $rootScope.solicitudJson.pedido;
			//$scope.textoParticipaPromocion	=	"participas en nuestra promoción:";
			//$scope.textoPodrasGanar			=	"En la que podrás ganar una camioneta último modelo";
			$scope.textoPermiso				=   "Permiso DGRTC/1914/2019";
			$scope.textoTerminoCondiciones	=	"Consulta términos y condiciones en www.bancoazteca.com";
			
			$scope.mostrarTextoFolio = false;
			
			if($scope.ngDialogData.jsonResponsePromo.folioCupon != null && $scope.ngDialogData.jsonResponsePromo.folioCupon != ""){
				$scope.mostrarTextoFolio = true;
				$scope.textoFolio				=	"Cupón: "+$scope.ngDialogData.jsonResponsePromo.folioCupon;
			}
			$scope.btnShowContinuar = true;
			$scope.textoAceptar				=	"Continuar";
			
			$timeout(function(){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.showPage = true;
			}, 1);	
			
		};
		
		$scope.continuar = function(){
			$scope.btnShowContinuar=false;
			if($scope.intentoImpresion < 3)
				imprimirTicketBuenFin($scope.ngDialogData.jsonResponsePromo);
			else
				$scope.confirm();
		}
		
		var imprimirTicketBuenFin = function(jsonResponsePromo){
			var mensajeTicket = jsonResponsePromo.mensaje;
			var folioPromo = "";
			if(jsonResponsePromo.folioCupon != null && jsonResponsePromo.folioCupon != "")
				folioPromo = jsonResponsePromo.folioCupon;
			var jsonEntrada = {
				nombre: generalService.camelize($rootScope.solicitudJson.cotizacion.clientes[0].nombre),
				clienteUnicoCliente: $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
				noPedido: $rootScope.solicitudJson.pedido,
				mensajeTicket: mensajeTicket,
				folioPromo: folioPromo
			}
			$rootScope.plantillaImpresionSurtimiento(jsonEntrada);
			if($scope.intentoImpresion < 3)
				preguntarImpresion(jsonResponsePromo);
			else
				message("¿Sin impresión?", ["Captura la pantalla con el folio participante de tu cliente y entrégasela para hacer válida su promoción.",
				                            "",
				                            "Realiza los siguientes pasos:",
				                            "    1. Selecciona en el teclado el botón:  \"Imprimir pantalla\"",
				                            "    2. Ingresa al menú \"Herramientas\" > Impresión de pantallas.  ",
				                            "    3. Busca el cupón de tu cliente e imprímelo.",], "Aceptar");
		};
		
		var preguntarImpresion = function(jsonResponsePromo){
			var colorDialogo = "bgAzul";
			var botonDialogo = "btnAzul";
			modalService.confirmModal("Advertencia", ["¿Deseas imprimir nuevamente?"], "No","Si",colorDialogo, "btnCancel", botonDialogo)
			.then(
				function(confirm){
					$scope.intentoImpresion=$scope.intentoImpresion+1;
					imprimirTicketBuenFin(jsonResponsePromo);
				},function(cancel){
					$scope.confirm();
				}
			);
		}
		
		var message = function(titulo, listaTexto, labelButton){
			modalService.alertModal(titulo, listaTexto, labelButton).closePromise.then(
													function(exito){
														$scope.btnShowContinuar=true;
													},function(error){
														$scope.btnShowContinuar=true;
													}
											 );
		};
		
	});
});