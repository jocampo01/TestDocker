'use strict';

define(["app"], function (app) {
	
	app.controller('modalRescateConsumoF3Controller', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService, validateService, buroService, modalService) {
		
		$scope.showPage=false;
		
		$scope.init=function(){
			var consultaLinea = false;
			if($rootScope.categoriaLinea.linea == 0){
				consultaLinea=true;
			}else{
				var lineaValida = false;
				for(var i=0;i<LINEA_DE_PRODUCTO_CONSUMO.length;i++){
					if($rootScope.categoriaLinea.linea == LINEA_DE_PRODUCTO_CONSUMO[i].id){
						lineaValida = true;
						break;
					}			
				}
				if(!lineaValida)
					consultaLinea=true;
			}
			if(consultaLinea){
				$rootScope.categoriaLinea = {linea: 0,lineaDes: "",subLinea: 0,subLineaDes: "",montoDeseado: ""};
				var jsonRequest = {
					    			idSolicitud : $rootScope.solicitudJson.idSolicitud
								  };
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				solicitudService.consultaLineaProducto(jsonRequest).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var responseJson = JSON.parse(data.data.respuesta);
							if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
								var linea = parseInt(responseJson.data.fclinea);
								if(linea > 0){
									$rootScope.categoriaLinea.linea=linea;
									var lineaValida = false;
									for(var i=0;i<LINEA_DE_PRODUCTO_CONSUMO.length;i++){
										if($rootScope.categoriaLinea.linea == LINEA_DE_PRODUCTO_CONSUMO[i].id){
											lineaValida = true;
											break;
										}
									}
									if(!lineaValida)
										$rootScope.categoriaLinea.linea=6;
								}else
									$rootScope.categoriaLinea.linea=6;
							}else
								$rootScope.categoriaLinea.linea=6;
							cargaVista();					
						}else{
							$scope.closeThisDialog(true);
							$rootScope.message("Error ",["Consulta de Línea Producto"], "Aceptar", "/simulador", "bgazul");
						}
				}, function(error) {
					$scope.closeThisDialog(true);
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Error ",["Consulta de Línea Producto"], "Aceptar", "/simulador", "bgazul");
				});
			}else
				cargaVista();
			
			
		};
		
		var cargaVista = function (){
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			$scope.isIpad=configuracion.so.ios;
			
			$scope.tituloHeader				=	$scope.ngDialogData.title;
			$scope.banderaLineaB			=	($rootScope.categoriaLinea.linea==LINEA_DE_PRODUCTO_CONSUMO[1].id || $rootScope.categoriaLinea.linea==LINEA_DE_PRODUCTO_CONSUMO[5].id)?true:false;
			$scope.banderaLineaC			=	($rootScope.categoriaLinea.linea==LINEA_DE_PRODUCTO_CONSUMO[0].id || $rootScope.categoriaLinea.linea==LINEA_DE_PRODUCTO_CONSUMO[6].id || $rootScope.categoriaLinea.linea==LINEA_DE_PRODUCTO_CONSUMO[7].id)?true:false;
			$scope.banderaLineaE			=	($rootScope.categoriaLinea.linea==LINEA_DE_PRODUCTO_CONSUMO[2].id || $rootScope.categoriaLinea.linea==LINEA_DE_PRODUCTO_CONSUMO[4].id)?true:false;
			$scope.banderaElectronica		=	($rootScope.categoriaLinea.linea==LINEA_DE_PRODUCTO_CONSUMO[3].id)?true:false;
			
			$scope.textoInvitalos			=	"Invítalo a mantener un ";
			$scope.textoBuenComportamiento	=	"buen comportamiento de pago. ";
			$scope.textoUnBuenHistorial		=	"Un buen historial crediticio, le da más ";
			$scope.textoBeneficios			=	"beneficios.";
			
			$scope.textoTenemosDe			=	"Tenemos estas 2 alternativas de ";
			$scope.textoTenemos				=	"Tenemos estas 2 alternativas ";
			$scope.textoTenemosAlternativa	=	"Tenemos esta alternativa para tu cliente:";
			$scope.textoConsumo				=	"Consumo";
			$scope.textoParaTu				=	" para tu cliente:";
			
			$scope.textoSinOs				=	"Sin Co acreditado";
			$scope.textoConOs				=	"Con Co acreditado";
			$scope.textoLlevate				=	"llévate hasta";

			$scope.textoMontoMin			=	"Monto mínimo de crédito $2,000";
			$scope.textoPlazoUnico			=	"Plazo único: 54 semanas";
			$scope.textoPlazoUnicoDos		=	"Plazo único: 50 semanas";
			
			$scope.textoPlazoCincuenta		=	"a un plazo de 50 semanas";
			$scope.textoPlazoCincuentayCuatro	=	"a un plazo de 54 semanas";

		
			$scope.creditoConsumo = {	sinOS : {	montoMaximo : [{id : 1, valor : 8000}, {id : 2, valor : 6000}, {id : 5, valor : 4000}],
													requisitos	: ["Con 30% de enganche mínimo", "Con 20% de enganche mínimo"],
													plazo		: [54]},
										conOS : {	montoMaximo : [{id : 3, valor : 8000}, {id : 4, valor : 6000}, {id : 6, valor : 4000}],
													requisitos	: ["Con 10% de enganche mínimo"],
													plazo		: [54, 50]}
			};
						
			$scope.seleccion = { 	creditoConsumo		: {habilitado : false, valores : {"montoMaximo":0,"requisito":0,"plazo":0}}}	
			
			$scope.textoNoAcepto="No me interesa";
			$scope.textoAcepto="Si me interesa";
			
			$scope.textoElMonto="* El monto máximo de crédito es diferente de acuerdo a la línea que tu cliente seleccione";
			$scope.textoConsultaMontos="Consulta montos máximos";
			
			$timeout(function(){
				cargaSeleccion();
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.showPage = true;
			}, 1);	
		}
		
		var cargaSeleccion = function(){
			if(generalService.getArrayValue("21Rescate") != null)
				$scope.seleccion.creditoConsumo = generalService.getArrayValue("21Rescate");
			generalService.setArrayValue("21Rescate",null);
		};
		
		$scope.aceptarOferta = function (){
			if($scope.seleccion.creditoConsumo.valores.montoMaximo > 0){
//				$rootScope.solicitudJson.banderaOfertaCP= 1;
				guardarSeccion();
			}else{
				$rootScope.message("AVISO",[ "Favor de elegir una opción"], "Aceptar");	
			}
		};
		
		var guardarSeccion = function() {
			$rootScope.waitLoaderStatus = LOADER_SHOW;
//	 		solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($rootScope.solicitudJson), seccion: SECCION_SOLICITUD } ).then(
//		 			function(data){
//		 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
		 					switch($scope.seleccion.creditoConsumo.valores.montoMaximo){
		 						case $scope.creditoConsumo.sinOS.montoMaximo[0].id:
		 						case $scope.creditoConsumo.sinOS.montoMaximo[1].id:
		 							$scope.opcion=93;
		 							break;
		 						default:
		 							$scope.opcion=159;
		 					}
							var json = {
								idSolicitud: $rootScope.solicitudJson.idSolicitud,
								idProductoSeleccionado:PRODUCTOS.consumo.ID.valor,
								opcion: $scope.opcion
							}
		 					
							buroService.actualizaProductoRescate( json ).then(
									function(data){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										
										if( data.data.codigo != undefined ){
											var responseJson = JSON.parse(data.data.respuesta);
											
											if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
												
												if($scope.opcion==159)
													$rootScope.requiereObligado = true;
												
												$rootScope.capacidadesPagoProducto = responseJson.data.capacidadesPagoProducto;
												$rootScope.solicitudJson = responseJson.data.solicitud;
												$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO
												$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
												$rootScope.mostrarOfertaCotizador = false;
												$rootScope.onceOfert = true;
												
												$scope.$parent.muestraAlertaNuevoBuro=false;
												$scope.$parent.muestraMensajeNuevoBuro=false;
												$scope.$parent.mensajeNuevoBuro="";
												
												$rootScope.calculaDocumentos();
												$scope.closeThisDialog(true);
												
											} else{
												generalService.cleanRootScope($rootScope);							
												generalService.buildSolicitudJson($rootScope, null);
												if($rootScope.solicitudOSJson){
													generalServiceOS.cleanRootScope($rootScope);
													generalService.buildSolicitudOSJson($rootScope, null);
												}
												$scope.closeThisDialog(false);
												$rootScope.message("Error " + responseJson.codigo,[responseJson.descripcion], "Aceptar", "/simulador", "bgazul");
											} 
											
										}else {
											generalService.cleanRootScope($rootScope);							
											generalService.buildSolicitudJson($rootScope, null);
											if($rootScope.solicitudOSJson){
												generalServiceOS.cleanRootScope($rootScope);
												generalService.buildSolicitudOSJson($rootScope, null);
											}
											$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul");
										}
										
									}, function(error){
										generalService.cleanRootScope($rootScope);							
										generalService.buildSolicitudJson($rootScope, null);
										if($rootScope.solicitudOSJson){
											generalServiceOS.cleanRootScope($rootScope);
											generalService.buildSolicitudOSJson($rootScope, null);
										}
										$rootScope.message("Error ",[" Favor de intentar nuevamente se detectó un problema "], "Aceptar", "/simulador", "bgazul");
									}	  
								  );
//		 				}else{
//		 					$rootScope.waitLoaderStatus = LOADER_HIDE;
//		 					$rootScope.message("Error",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
//		 				}
//		 			}, function(error){                     
//		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
//		 				$rootScope.message("Error al volver a cotizar",[ "Error del servicio guardar solicitud sección 9"], "Aceptar", null);								
//		 			}	
//				);
	 		
		};
		
		$scope.consulta = function (){
			if($scope.seleccion.creditoConsumo.valores.montoMaximo > 0)
				generalService.setArrayValue("21Rescate",$scope.seleccion.creditoConsumo);
			modalService.rescateConsumoFaseIII_2Modal("En Banco Azteca le decimos SÍ a nuestros clientes", $rootScope.solicitudJson.marca ).then(
					function(estatus) {
						generalService.setArrayValue("21Rescate",null);
						$scope.showPage=false;
						$timeout(function(){
							$scope.showPage = true;
						}, 500);	
					}, function(exito) {
						generalService.setArrayValue("21Rescate",null);
						$scope.showPage=false;
						$timeout(function(){
							$scope.showPage = true;
						}, 500);	
					}
				);
		};
		
		$scope.rechazar = function(){
    		var x = {
			    idSolicitud : $rootScope.solicitudJson.idSolicitud,
			    idSeguimiento: STATUS_SOLICITUD.rechazada.id,
			    idMotivoRechazo: STATUS_SOLICITUD.rechazada.idMotivoRechazo.clienteNoAceptaMiniConsumo
			}
    		
    		$rootScope.waitLoaderStatus = LOADER_SHOW;
    		solicitudService.actualizarSolicitud( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.cleanRootScope($rootScope);
					generalService.buildSolicitudJson($rootScope, null);
					generalService.buildSolicitudOSJson($rootScope, null);
					$scope.closeThisDialog();
					generalService.locationPath("/simulador");
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.cleanRootScope($rootScope);
					generalService.buildSolicitudJson($rootScope, null);
					generalService.buildSolicitudOSJson($rootScope, null);
					modalService.alertModal("Error "+error.status, [error.statusText]);
					$scope.closeThisDialog();
					generalService.locationPath("/simulador");
			});
    	};
	});
});