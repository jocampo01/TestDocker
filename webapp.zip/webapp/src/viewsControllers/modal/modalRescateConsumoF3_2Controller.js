'use strict';

define(["app"], function (app) {
	
	app.controller('modalRescateConsumoF3_2Controller', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService, validateService, buroService, modalService) {
		
		$scope.showPage=false;
		
		$scope.init=function(){

			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			$scope.isIpad=configuracion.so.ios;
			
			$scope.textoMontosMaximos		=	"Montos máximos por línea";
			$scope.textoLineaBlanca			=	"Línea Blanca";
			$scope.textoColchonesyBox		=	"Colchones y Boxes";
			$scope.textoComputo				=	"Cómputo";
			
			$scope.textoMuebles				=	"Muebles";
			$scope.textoElectronicaY		=	"Electrónica y Entretenimiento";
			$scope.textoTransporte			=	"Transporte";
			$scope.textoAccesorios			=	"Accesorios";
			
			$scope.textoMontoMin			=	"Monto mínimo de crédito $2,000";
					
			$scope.creditoConsumo = {	sinOS : {	montoMaximo : [{id : 1, valor : 8000}, {id : 2, valor : 6000}, {id : 5, valor : 4000}],
													requisitos	: ["Con 30% de enganche mínimo", "Con 20% de enganche mínimo"]},
										conOS : {	montoMaximo : [{id : 3, valor : 8000}, {id : 4, valor : 6000},  {id : 6, valor : 4000}],
													requisitos	: ["Con 10% de enganche mínimo"],
													OS			: ["+ Co acreditado"]}
			};
						
			$timeout(function(){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.showPage = true;
			}, 1);	
			
		};
		
	});
});