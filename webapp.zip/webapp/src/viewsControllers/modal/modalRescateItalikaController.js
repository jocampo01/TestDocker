/**
 * 
 */'use strict';

define(["app"], function (app) {

    app.controller("modalRescateItalikaController", function ( $scope, $rootScope, $timeout, generalService, generalServiceOS,clienteUnicoService,sessionService, modalService, solicitudService) {
    		
    	$scope.init = function(marca){
    		cargarVista();
 	}
    	
    	function cargarVista(){

    		/** var mensaje = $rootScope.consultaFuncionalidad.habilitarOSItalika? "Y deberá presentar un <span style= ' font-weight: bold;'> Coacreditado</span> de la linea de crédito, el cual también recibirá a uno de nuestros ejecutivos a su domicilio"
	            + "<br><br>"
	            +	"Recuerda que si con esta opción de crédito no le alcanza al cliente para llevarse el producto deseado, dejando un poco más de en ganche puede hacerlo":""; **/
    		
    		/**$scope.cargarMensaje = "<div style='text-align: justify;'>Infórmale a tu cliente que por el momento le podemos otorgar la siguiente alternativa de Crédito:" + "<br/>"
					            + "<br/>"
						            + "<div style='background: #e2e1dd;font-size:  0.8em;width: 70%;color: #7b7a74;padding: 3%;margin-left: 13%;'>" 
								            + "<ul>"
								            + 	"<li> &nbsp;&nbsp;&nbsp;&nbsp;* Crédito solo para italika en tienda" + "</li>"
								            + 	"<li> &nbsp;&nbsp;&nbsp;&nbsp;* Monto máximo de $18,000 pesos con enganche del 10% </li>"
								            + 	"<li> &nbsp;&nbsp;&nbsp;&nbsp;* Abono semanal $150 pesos a un plazo de 102 semanas" + "</li>"
								            + "</ul>" 
						            +"</div>"
					            + "<br>"
					            +	mensaje 
					            + "</div>";**/
    		/**
    		$scope.cargarMensaje = "<div style='text-align: justify;'>Infórmale a tu cliente que el producto y monto cotizados no fueron autorizados, sin embargo, tiene" +
    				" las siguientes alternativas de ser aprobado su crédito de <b>Italika</b> después de una visita a su domicilio:" + "<br/>"
            + "<br/>"
	            + "<div style='background: #e2e1dd;width: 60%;color: #7b7a74;padding: 3%;margin-left: 20%;'>" 
			            + "<ul style='text-align: left;'>"
			            + 	"<li>* Le prestamos hasta $21,250 para que compre la moto que quiera, dejando un enganche mínimo del 30% </li>"
			            + 	"<li>* Plazo único de <span style= ' font-weight: bold;'> 102 semanas </span>" + "</li>"
			            + "</ul>" 
	            +"</div>"
            + "<br>"
            +	mensaje 
            + "</div>";
    		**/
    	
    		if($rootScope.consultaFuncionalidad.habilitarOSItalika){
    			$scope.cargarMensaje = "<div style='text-align: justify;'>Infórmale a tu cliente que por el momento le podemos otorgar la siguiente alternativa de Crédito:" + "<br/>"
	            + "<br/>"
		            + "<div style='background: #e2e1dd;font-size:  0.8em;width: 70%;color: #7b7a74;padding: 3%;margin-left: 13%;'>" 
				            + "<ul>"
				            + 	"<li> &nbsp;&nbsp;&nbsp;&nbsp;* Crédito solo para italika en tienda" + "</li>"
				            + 	"<li> &nbsp;&nbsp;&nbsp;&nbsp;* Monto máximo de $18,000 pesos con enganche del 10% </li>"
				            + 	"<li> &nbsp;&nbsp;&nbsp;&nbsp;* Abono semanal $150 pesos a un plazo de 102 semanas" + "</li>"
				            + "</ul>" 
		            +"</div>"
	            + "<br>"
	            +	"Y deberá presentar un <span style= ' font-weight: bold;'> Coacreditado</span> de la linea de crédito, el cual también recibirá a uno de nuestros ejecutivos a su domicilio"
	            + "<br><br>"
	            +	"Recuerda que si con esta opción de crédito no le alcanza al cliente para llevarse el producto deseado, dejando un poco másde en ganche puede hacerlo" 
	            + "</div>";
    		}else{
    			$scope.cargarMensaje = "<div style='text-align: center;'><b>¡Creemos en ti!</b> Con un buen comportamiento de pago con nostros, puedes " +
				"construir un buen historial de crédito. <br/> <br/>"
					+ "<b>TE OFRECEMOS PARATU ITALIKA $21,250 con un mínimo de 30% de enganche.</b> <br/><br/>"
		            + "</div>";
    		}
    		
    	}
    	
    	
    
    	
    	$scope.rechazar = function(){
    		$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.rechazada.id;
    		$rootScope.solicitudJson.idMotivoRechazo = STATUS_SOLICITUD.rechazada.idMotivoRechazo.clienteNoAceptaRescateItalika;
    		$rootScope.waitLoaderStatus = LOADER_SHOW;
    		
    		solicitudService.actualizarSolicitud( $rootScope.solicitudJson ).then(
    				function(data){
    						$rootScope.waitLoaderStatus = LOADER_HIDE;
    						$rootScope.codigoBuro = null;
    						generalService.cleanRootScope($rootScope);
    						generalServiceOS.cleanRootScope($rootScope);
    						generalService.buildSolicitudJson($rootScope, null);
    						generalService.buildSolicitudOSJson($rootScope, null);
    						$scope.closeThisDialog();
    						generalService.locationPath("/simulador");
    						
    					}, function(error) {
	    						$rootScope.waitLoaderStatus = LOADER_HIDE;
	    						$rootScope.codigoBuro = null;
	    						generalService.cleanRootScope($rootScope);
	    						generalServiceOS.cleanRootScope($rootScope);
	    						generalService.buildSolicitudJson($rootScope, null);
	    						generalService.buildSolicitudOSJson($rootScope, null);
	    						modalService.alertModal("Error "+error.status, [error.statusText]);
	    						generalService.locationPath("/simulador");
					}
    				);
    		}
    	
    });
});