'use strict';

define(["app"], function (app) {
	
	app.controller('modalRescateItalikaF3Controller', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService, validateService, buroService, modalService) {
		
		$scope.showPage=false;
		
		$scope.init=function(){

			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			$scope.isIpad=configuracion.so.ios;
			
			$scope.tituloHeader				=	$scope.ngDialogData.title;
			$scope.banderaLineaB			=	false;
			
			$scope.textoInvitalos			=	"Invítalo a mantener un ";
			$scope.textoBuenComportamiento	=	"buen comportamiento de pago. ";
			$scope.textoUnBuenHistorial		=	"Un buen historial crediticio, le da más ";
			$scope.textoBeneficios			=	"beneficios.";
			
			$scope.textoTenemosDe			=	"Tenemos estas 2 alternativas de ";
			$scope.textoTenemos				=	"Tenemos estas 2 alternativas ";
			$scope.textoItalika				=	"crédito Italika";
			$scope.textoParaTu				=	" para tu cliente:";
			
			$scope.textoSinOs				=	"Sin Coacreditado";
			$scope.textoConOs				=	"Con Coacreditado";
			$scope.textoLlevate				=	"llévate hasta";

			$scope.textoPlazoUnico			=	"Plazo único: 101 semanas";

		
			$scope.italika = {	conOS : {	montoMaximo : [{id : 1, valor : 21250}],
											requisitos	: ["Con 10% de enganche mínimo"]},
								sinOS : {	montoMaximo : [{id : 2, valor : 21250}],
											requisitos	: ["Con 30% de enganche mínimo"]}
							};
						
			$scope.seleccion = { 	italika		: {habilitado : false, valores : {"montoMaximo":0,"requisito":0,"plazo":0}}}	
			
			$scope.textoNoAcepto="No me interesa";
			$scope.textoAcepto="Si me interesa";
			
			$scope.textoElMonto="* El monto máximo de crédito es diferente de a cuerdo a la linea que tu cliente seleccione";
			$scope.textoConsultaMontos="Consulta montos máximos";
			
			$timeout(function(){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.showPage = true;
			}, 1);	
			
		};
					
		$scope.aceptarOferta = function (){
			if($scope.seleccion.italika.valores.montoMaximo > 0){
//				$rootScope.solicitudJson.banderaOfertaCP= 1;
				guardarSeccion();
			}else{
				$rootScope.message("AVISO",[ "Favor de elegir una opción"], "Aceptar");	
			}
		};
		
		var guardarSeccion = function() {
			$rootScope.waitLoaderStatus = LOADER_SHOW;
//	 		solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($rootScope.solicitudJson), seccion: SECCION_SOLICITUD } ).then(
//		 			function(data){
//		 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
		 					if($scope.seleccion.italika.valores.montoMaximo == $scope.italika.sinOS.montoMaximo[0].id)
	 							$scope.opcion=120;
	 						else
	 							$scope.opcion=162;
							var json = {
								idSolicitud: $rootScope.solicitudJson.idSolicitud,
								idProductoSeleccionado:PRODUCTOS.italika.ID.valor,
								opcion: $scope.opcion
							}
		 					
							buroService.actualizaProductoRescate( json ).then(
									function(data){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										
										if( data.data.codigo != undefined ){
											var responseJson = JSON.parse(data.data.respuesta);
											
											if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
												
												if($scope.opcion==162)
													$rootScope.requiereObligado = true;
												
												$rootScope.capacidadesPagoProducto = responseJson.data.capacidadesPagoProducto;
												$rootScope.solicitudJson = responseJson.data.solicitud;
												$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO
												$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
												$rootScope.mostrarOfertaCotizador = false;
												$rootScope.onceOfert = true;
												
												$scope.$parent.muestraAlertaNuevoBuro=false;
												$scope.$parent.muestraMensajeNuevoBuro=false;
												$scope.$parent.mensajeNuevoBuro="";
												
												$rootScope.calculaDocumentos();
												$scope.closeThisDialog(true);
												
											} else{
												generalService.cleanRootScope($rootScope);							
												generalService.buildSolicitudJson($rootScope, null);
												if($rootScope.solicitudOSJson){
													generalServiceOS.cleanRootScope($rootScope);
													generalService.buildSolicitudOSJson($rootScope, null);
												}
												$scope.closeThisDialog(false);
												$rootScope.message("Error " + responseJson.codigo,[responseJson.descripcion], "Aceptar", "/simulador", "bgazul");
											} 
											
										}else {
											generalService.cleanRootScope($rootScope);							
											generalService.buildSolicitudJson($rootScope, null);
											if($rootScope.solicitudOSJson){
												generalServiceOS.cleanRootScope($rootScope);
												generalService.buildSolicitudOSJson($rootScope, null);
											}
											$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul");
										}
										
									}, function(error){
										generalService.cleanRootScope($rootScope);							
										generalService.buildSolicitudJson($rootScope, null);
										if($rootScope.solicitudOSJson){
											generalServiceOS.cleanRootScope($rootScope);
											generalService.buildSolicitudOSJson($rootScope, null);
										}
										$rootScope.message("Error ",[" Favor de intentar nuevamente se detectó un problema "], "Aceptar", "/simulador", "bgazul");
									}	  
								  );
//		 				}else{
//		 					$rootScope.waitLoaderStatus = LOADER_HIDE;
//		 					$rootScope.message("Error",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
//		 				}
//		 			}, function(error){                     
//		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
//		 				$rootScope.message("Error al volver a cotizar",[ "Error del servicio guardar solicitud sección 9"], "Aceptar", null);								
//		 			}	
//				);
		}
		
		$scope.rechazar = function(){
    		var x = {
			    idSolicitud : $rootScope.solicitudJson.idSolicitud,
			    idSeguimiento: STATUS_SOLICITUD.rechazada.id,
			    idMotivoRechazo: STATUS_SOLICITUD.rechazada.idMotivoRechazo.clienteNoAceptaRescateItalika
			}
    		
    		$rootScope.waitLoaderStatus = LOADER_SHOW;
    		solicitudService.actualizarSolicitud( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.cleanRootScope($rootScope);
					generalService.buildSolicitudJson($rootScope, null);
					generalService.buildSolicitudOSJson($rootScope, null);
					$scope.closeThisDialog();
					generalService.locationPath("/simulador");
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.cleanRootScope($rootScope);
					generalService.buildSolicitudJson($rootScope, null);
					generalService.buildSolicitudOSJson($rootScope, null);
					modalService.alertModal("Error "+error.status, [error.statusText]);
					$scope.closeThisDialog();
					generalService.locationPath("/simulador");
			});
    	};
    	$scope.ofertaRescate = function(){
			modalService.rescateItalikaModal();
		}
	});
});