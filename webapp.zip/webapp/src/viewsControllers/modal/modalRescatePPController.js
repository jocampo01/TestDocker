'use strict';

var imagenes = new Array();

define(["app"], function (app) {
	
	app.controller('modalRescatePPController', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService, validateService, buroService, modalService) {
		
		$scope.showPage=false;
		var arrayMontosPlazos = generalService.getPlazos( $rootScope );
		if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.prodRescatePPPrestamo){
			$scope.rescatePPPrestamo = true;
			arrayMontosPlazos.sort(function (a, b) {
				  if (a.monto > b.monto) {
				    return 1;
				  }
				  if (a.monto < b.monto) {
				    return -1;
				  }
				  // a must be equal to b
				  return 0;
			});
		}else
			$scope.rescatePPPrestamo = false;
		var produtosRescate = $rootScope.consultaFuncionalidad.productosAptosRescate.split(",");
		$scope.rescatePPConsumo = false;
		$scope.rescatePPTelefonia = false;
		$scope.rescatePPItalika = false;
		for(var i=0;i<produtosRescate.length;i++){
			switch(parseInt(produtosRescate[i])){
				case PRODUCTOS.consumo.ID.valor:
					$scope.rescatePPConsumo = true;
					break;
				case PRODUCTOS.telefonia.ID.valor:
					$scope.rescatePPTelefonia = true;
					var fechaNacimientoSplit = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento.split("/");
					var fechaNacimiento = fechaNacimientoSplit[2]+fechaNacimientoSplit[1]+fechaNacimientoSplit[0];
					var yyyy = new Date().getFullYear() - 22;
					var fechaDia = new Date();
					var mm = ((fechaDia.getMonth() + 1) < 10 ? '0' : '') + (fechaDia.getMonth() + 1);
					var dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
					var fechaValida = yyyy+mm+dd;
					if($rootScope.solicitudJson.hitBuro && fechaNacimiento > fechaValida)
						$scope.rescatePPTelefonia = false;
					break;
				case PRODUCTOS.italika.ID.valor:
					$scope.rescatePPItalika = true;
					break;
			}
		}
		var tipoTasa = tipoTasas.ppRescate.id;
		$scope.productoElegido=0;
		$scope.garantiasOpcionales=true;
		$rootScope.actualizoCotizacion=true;
		$rootScope.armaJsonCotizacion();
		
		$scope.init=function(){

			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			$scope.isIpad=configuracion.so.ios;
			
			$scope.tituloHeader				=	$scope.ngDialogData.title;
			
			$scope.textoInvitalos			=	"Invítalo a mantener un ";
			$scope.textoBuenComportamiento	=	"buen comportamiento de pago. ";
			$scope.textoUnBuenHistorial		=	"Un buen historial crediticio, le da más ";
			$scope.textoBeneficios			=	"beneficios.";
			
			$scope.textoMontoMaximo 		=	"Monto máximo";
			$scope.textoRequisito			=	"Requisitos";
			$scope.textoPlazo				=	"Plazo";

			$scope.textoSinOs				=	"Sin Coacreditado";
			$scope.textoConOs				=	"Con Coacreditado";
			$scope.textoLlevate				=	"llévate hasta";

			$scope.prestamoPersonal = {	montoMaximo : [],
										requisitos	: [ {id : 1, valor : "Con Garantías Prendarias *", visible : true},{id : 2, valor : "Con Coacreditado", visible : true}]
								      };
			if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.prodRescatePPPrestamo)
				cargaMontosPlazos();
			
			$scope.creditoConsumo = {	sinOS : {	montoMaximo : [{id : 1, valor : 8000}],
													requisitos	: ["Con 30% enganche min."],
													plazo		: [54]},
										conOS : {	montoMaximo : [{id : 2, valor : 8000}],
													requisitos	: ["Con 10% enganche min."],
													plazo		: [54]}	
			};
			
			$scope.telefonia = {	sinOS : {	montoMaximo : [{id : 1, valor : 4000}],
												requisitos	: ["Con 30% enganche min."],
												plazo		: [54]},
									conOS : {	montoMaximo : [{id : 2, valor : 4000}],
												requisitos	: ["Con 10% enganche min."],
												plazo		: [50]}	
			};
			
			$scope.italika = {	sinOS : {	montoMaximo : [{id : 1, valor : 21250}],
											requisitos	: ["Con 30% enganche min."],
											plazo		: [101]},
								conOS : {	montoMaximo : [{id : 2, valor : 21250}],
											requisitos	: ["Con 10% enganche min."],
											plazo		: [101]}	
			};
			
			$scope.seleccion = { 	prestamoPersonal 	: {habilitado : false, valores : {"montoMaximo":0,"requisito":0,"plazo":0}},
								 	creditoConsumo		: {habilitado : false, valores : {"montoMaximo":0,"requisito":0,"plazo":0}},
								 	telefonia			: {habilitado : false, valores : {"montoMaximo":0,"requisito":0,"plazo":0}},
								 	italika				: {habilitado : false, valores : {"montoMaximo":0,"requisito":0,"plazo":0}}}	
			
			$scope.textoLasGarantias="* Las Garantías Prendarias deben cubrir 1.5 veces el valor del préstamo solicitado y serán registradas en el proceso de verificación";
			$scope.textoNoAcepto="No me interesa";
			$scope.textoGenerar="Generar presupuesto";
			$scope.textoAcepto="Si me interesa";
			
			//Bandera que indica si sera el front que imprime tickets \*/
			$scope.isWithTicket = true && $scope.rescatePPPrestamo;
			if( $scope.isWithTicket )
				initWithTicket();
			
			$timeout(function(){
				cargaSeleccion();
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.showPage = true;
			}, 1);	
			
		};
		
		var initWithTicket=function(){
			$scope.isIpad=configuracion.so.ios;				
			$scope.textoGenerar="Generar presupuesto";
			$scope.bloqueaBotones = false;
			$scope.muestraBotonImprimir = true;
		};
		
		$scope.condicionMuestraBoton = false;
	 	if($rootScope.consultaFuncionalidad.flujoTicketMoc){
	 		$scope.condicionMuestraBoton = (configuracion.origen.tienda && configuracion.so.windows && ($rootScope.sucursalSession.idCanal==1 || $rootScope.sucursalSession.idCanal == 9 || $rootScope.sucursalSession.idCanal == 39));	
	 	}
		$scope.imprimirPresupuesto =  function(){
			if( $scope.productoElegido == PRODUCTOS.prestamoPersonal.ID.valor) {
				var respSolicitudJson 		= $.extend( true, {}, $rootScope.solicitudJson);
				calculaMontos();
				var montoImporteSolicitado 	= $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;
				var montoCreditoSolicitado 	= $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;
				var sobreprecioSolicitado 	= (($rootScope.solicitudJson.cotizacion.pagoPuntual * $rootScope.solicitudJson.cotizacion.plazo) - $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto);
				var montoTotalSolicitado 	= ($rootScope.solicitudJson.cotizacion.pagoPuntual*$rootScope.solicitudJson.cotizacion.plazo);
				var montoTotalSolicitadoNormal 	= ($rootScope.solicitudJson.cotizacion.pagoNormal*$rootScope.solicitudJson.cotizacion.plazo);
				var skuSolicitado 			= $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto;
				var plazoSolicitado 			= $rootScope.solicitudJson.cotizacion.plazo;
				var pagoNormalSolicitado		= $scope.solicitudJson.cotizacion.pagoNormal;
				var pagpPuntualSolicitado	= $scope.solicitudJson.cotizacion.pagoPuntual;
				$rootScope.solicitudJson	= $.extend( true, {}, respSolicitudJson);
				
				var cotizacionMaxima 		= calculaMontosMaximos();
				var montoImporteMaximo 		= cotizacionMaxima.detallesCotizacion[0].monto;
				var montoCreditoMaximo 		= cotizacionMaxima.detallesCotizacion[0].monto;
				var sobreprecioMaximo 		= ((cotizacionMaxima.pagoPuntual * cotizacionMaxima.plazo) - cotizacionMaxima.detallesCotizacion[0].monto);
				var montoTotalMaximo 		= (cotizacionMaxima.pagoPuntual*cotizacionMaxima.plazo);
				var montoTotalMaximoNormal	= (cotizacionMaxima.pagoNormal*cotizacionMaxima.plazo);
				var skuMaximo 				= cotizacionMaxima.detallesCotizacion[0].idProducto;
				var plazoMaximo 				= cotizacionMaxima.plazo;
				var pagoNormalMaximo 		= cotizacionMaxima.pagoPuntual;
				var pagoPuntualMaximo		= cotizacionMaxima.pagoNormal;
				
				var jsonOferta = {
		 				monto:montoImporteSolicitado,
		 				plazo:plazoSolicitado,
		 				pNormal:pagoNormalSolicitado,
		 				pPuntual:pagpPuntualSolicitado,
		 				montoMax:montoImporteMaximo,
		 				plazoMax:plazoMaximo,
		 				pNormalMax:pagoNormalMaximo,
		 				pPuntualMax:pagoPuntualMaximo,
		 				idPeriodicidad:$rootScope.solicitudJson.cotizacion.idPeriodicidad,
		 				producto:$rootScope.solicitudJson.idProducto,
		 				sku: $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto,
		 				capacidadePago: $rootScope.solicitudJson.capacidadPagoComprobable
		 		}
				
				$rootScope.generarPlantillaImpresion(2, $rootScope.solicitudJson, $rootScope.userSession, $rootScope.sucursalSession, undefined, jsonOferta);
			}
		};
		
		var cargaSeleccion = function(){
			switch(true){
				case generalService.getArrayValue("24Rescate") != null:
					$scope.seleccion.prestamoPersonal = generalService.getArrayValue("24Rescate");
					break;
				case generalService.getArrayValue("21Rescate") != null:
					$scope.seleccion.creditoConsumo = generalService.getArrayValue("21Rescate");
					break;
				case generalService.getArrayValue("23Rescate") != null:
					$scope.seleccion.telefonia = generalService.getArrayValue("23Rescate");
					break;
				case generalService.getArrayValue("22Rescate") != null:
					$scope.seleccion.italika = generalService.getArrayValue("22Rescate");
					break;
			}
			generalService.setArrayValue("21Rescate",null);
			generalService.setArrayValue("22Rescate",null);
			generalService.setArrayValue("23Rescate",null);
			generalService.setArrayValue("24Rescate",null);
		};
		
		var cargaMontosPlazos = function(){
			$scope.prestamoPersonal.montoMaximo=[];
			$scope.plazos=[];
			var idMontos=0;
			for(var i = 0; i < arrayMontosPlazos.length; i++){
				var datosMontos={id : 0, valor : 0, visible : true, plazos: []};
				idMontos=idMontos+1;
				datosMontos.id=idMontos;
				datosMontos.valor=arrayMontosPlazos[i].monto;
				if($rootScope.solicitudJson.banderaIngresos == 1){
					var plazosCpComprobable=ordenarPlazos(arrayMontosPlazos[i].cpComprobable);
					for(var x = 0;x < plazosCpComprobable.length;x++){
						datosMontos.plazos.push(plazosCpComprobable[x]);
						$scope.plazos.push(plazosCpComprobable[x]);
					}
				}else{
					var plazosCpNoComprobable=ordenarPlazos(arrayMontosPlazos[i].cpNoComprobable);
					for(var x = 0;x < plazosCpNoComprobable.length;x++){
						datosMontos.plazos.push(plazosCpNoComprobable[x]);
						$scope.plazos.push(plazosCpNoComprobable[x]);
					}
				}
				$scope.prestamoPersonal.montoMaximo.push(datosMontos);
			}
			$scope.plazos = ordenarPlazos($scope.plazos);
			$scope.plazos = eliminarDuplicados($scope.plazos);
		};
		
		var ordenarPlazos = function(arrayPlazos){
			arrayPlazos.sort(function (a, b) {
				  if (a > b) {
				    return 1;
				  }
				  if (a < b) {
				    return -1;
				  }
				  // a must be equal to b
				  return 0;
			});
			return arrayPlazos;
		};
		
		var eliminarDuplicados = function(plazos){
			var arrayPlazos = [];
			var ind = 1;
			arrayPlazos.push(plazos[0]);
			for(var i=1;i<plazos.length;i++){
				if(arrayPlazos[ind-1] != plazos[i]){
					ind++;
					arrayPlazos.push(plazos[i]);
				}
			}
			return arrayPlazos;
		}
		
		$scope.limpiaOtros = function (seleccionado,cambio){
			$scope.productoElegido=0;
			if(seleccionado == 'prestamoPersonal'){
				$scope.seleccion.creditoConsumo.valores = {"montoMaximo":0,"requisito":0,"plazo":0};
				$scope.seleccion.telefonia.valores		= {"montoMaximo":0,"requisito":0,"plazo":0};
				$scope.seleccion.italika.valores		= {"montoMaximo":0,"requisito":0,"plazo":0};
				if(cambio==1 || cambio==2){
					if(cambio==2){
						if($scope.seleccion.prestamoPersonal.valores.requisito == 1){
							for(var i=0;i<$scope.prestamoPersonal.montoMaximo.length;i++){
								if($scope.prestamoPersonal.montoMaximo[i].valor == 2000){
									$scope.seleccion.prestamoPersonal.valores.montoMaximo = $scope.prestamoPersonal.montoMaximo[i].id;
								}else
									$scope.prestamoPersonal.montoMaximo[i].visible=false;
							}
						}else{
							for(var i=0;i<$scope.prestamoPersonal.montoMaximo.length;i++){
								$scope.prestamoPersonal.montoMaximo[i].visible=true;
							}
						}
					}else{
						for(var i=0;i<$scope.prestamoPersonal.montoMaximo.length;i++){
							if($scope.prestamoPersonal.montoMaximo[i].id == $scope.seleccion.prestamoPersonal.valores.montoMaximo){
								if($scope.prestamoPersonal.montoMaximo[i].valor > 2000){
									$scope.garantiasOpcionales=false;
									$scope.prestamoPersonal.requisitos[0].visible=false;
									$scope.seleccion.prestamoPersonal.valores.requisito=2;
								}else{
									$scope.garantiasOpcionales=true;
									$scope.prestamoPersonal.requisitos[0].visible=true;
									$scope.seleccion.prestamoPersonal.valores.requisito=0;
								}
								break;
							}
						}
					}
					for(var i=0;i<$scope.prestamoPersonal.montoMaximo.length;i++){
						if($scope.prestamoPersonal.montoMaximo[i].id == $scope.seleccion.prestamoPersonal.valores.montoMaximo)
							$scope.plazos = $scope.prestamoPersonal.montoMaximo[i].plazos;
					}
					if($scope.plazos.length == 1){
						$scope.seleccion.prestamoPersonal.valores.plazo=$scope.plazos[0];
					}else{
						var encontrado=false;
						for(var i=0;i<$scope.plazos.length;i++){
							if($scope.plazos[i] == $scope.seleccion.prestamoPersonal.valores.plazo)
								encontrado=true;
						}
						if(!encontrado)
							$scope.seleccion.prestamoPersonal.valores.plazo=0;
					}
				}
				if($scope.prestamoPersonal.montoMaximo.length==1)
					$scope.seleccion.prestamoPersonal.valores.montoMaximo = $scope.prestamoPersonal.montoMaximo[0].id;
				if($scope.seleccion.prestamoPersonal.valores.montoMaximo > 0 && $scope.seleccion.prestamoPersonal.valores.requisito > 0 && $scope.seleccion.prestamoPersonal.valores.plazo > 0)
					$scope.productoElegido=PRODUCTOS.prestamoPersonal.ID.valor;
				$scope.muestraBotonImprimir = true;
			} else if(seleccionado == 'creditoConsumo'){
				$scope.seleccion.prestamoPersonal.valores 	= {"montoMaximo":0,"requisito":0,"plazo":0};
				if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.prodRescatePPPrestamo)
					cargaMontosPlazos();
				$scope.prestamoPersonal.requisitos[0].visible=true;
				$scope.garantiasOpcionales=true;
				$scope.seleccion.telefonia.valores			= {"montoMaximo":0,"requisito":0,"plazo":0};
				$scope.seleccion.italika.valores			= {"montoMaximo":0,"requisito":0,"plazo":0};
				$scope.productoElegido=PRODUCTOS.consumo.ID.valor;
				$scope.muestraBotonImprimir = false;
			} else if(seleccionado == 'telefonia'){
				$scope.seleccion.prestamoPersonal.valores 	= {"montoMaximo":0,"requisito":0,"plazo":0};
				if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.prodRescatePPPrestamo)
					cargaMontosPlazos();
				$scope.prestamoPersonal.requisitos[0].visible=true;
				$scope.garantiasOpcionales=true;
				$scope.seleccion.creditoConsumo.valores		= {"montoMaximo":0,"requisito":0,"plazo":0};
				$scope.seleccion.italika.valores			= {"montoMaximo":0,"requisito":0,"plazo":0};
				$scope.productoElegido=PRODUCTOS.telefonia.ID.valor;
				$scope.muestraBotonImprimir = false;
			} else if(seleccionado == 'italika'){
				$scope.seleccion.prestamoPersonal.valores 	= {"montoMaximo":0,"requisito":0,"plazo":0};
				if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.prodRescatePPPrestamo)
					cargaMontosPlazos();
				$scope.prestamoPersonal.requisitos[0].visible=true;
				$scope.garantiasOpcionales=true;
				$scope.seleccion.creditoConsumo.valores		= {"montoMaximo":0,"requisito":0,"plazo":0};
				$scope.seleccion.telefonia.valores			= {"montoMaximo":0,"requisito":0,"plazo":0};
				$scope.productoElegido=PRODUCTOS.italika.ID.valor;
				$scope.muestraBotonImprimir = false;
			}
		};
				
		$scope.aceptarOferta = function (){
			$scope.opcion=0;
			switch($scope.productoElegido){
				case PRODUCTOS.prestamoPersonal.ID.valor:
					calculaMontos();
					if($scope.seleccion.prestamoPersonal.valores.requisito == 1)
						$scope.opcion=150;
					else
						$scope.opcion=151;
					break;
				case PRODUCTOS.consumo.ID.valor:
					if($scope.seleccion.creditoConsumo.valores.montoMaximo == 1)
						$scope.opcion=93;
					else
						$scope.opcion=159;
					break;
				case PRODUCTOS.telefonia.ID.valor:
					if($scope.seleccion.telefonia.valores.montoMaximo == 1)
						$scope.opcion=136;
					else
						$scope.opcion=128;
					break;
				case PRODUCTOS.italika.ID.valor:
					if($scope.seleccion.italika.valores.montoMaximo == 1)
						$scope.opcion=120;
					else
						$scope.opcion=162;
					break;
			}
			actualizarProductoRescate($rootScope.solicitudJson.cotizacion);
		};
		
		var calculaMontos = function () {
			var monto = 0;
			for(var i=0;i<$scope.prestamoPersonal.montoMaximo.length;i++){
				if($scope.prestamoPersonal.montoMaximo[i].id == $scope.seleccion.prestamoPersonal.valores.montoMaximo){
					monto = $scope.prestamoPersonal.montoMaximo[i].valor;
					break;
				}
			}
	 		var periodicidad 	= $rootScope.solicitudJson.cotizacion.idPeriodicidad;
	 		var plazo 			= $scope.seleccion.prestamoPersonal.valores.plazo;
	 		
	 		var arrayTempAbonos =  $rootScope.consultaAbonos.rescatePrestamo;
 			for (var i = 0; i < arrayTempAbonos.length;i++){
	 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){
	 				   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = monto; //su prestamo
// 					   $rootScope.solicitudJson.cotizacion.montoTotal = parseFloat(arrayTempAbonos[i].sobre);
// 					   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses = parseInt($rootScope.solicitudJson.cotizacion.montoTotal - monto);
	 				   $rootScope.solicitudJson.cotizacion.montoTotal = parseInt(arrayTempAbonos[i].precio) + parseInt(arrayTempAbonos[i].sobre);
	 				   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses = parseInt(arrayTempAbonos[i].sobre);
					   
 					   $rootScope.solicitudJson.cotizacion.pagoNormal = parseFloat(arrayTempAbonos[i].normal); //pagara
 					   $rootScope.solicitudJson.cotizacion.pagoPuntual = parseFloat(arrayTempAbonos[i].puntual); //pago puntual
 					   $rootScope.solicitudJson.cotizacion.ultimoAbono = parseInt(arrayTempAbonos[i].ultimo);
 					   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto = arrayTempAbonos[i].sku;
 					   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].cantidad = 1;
 					   $rootScope.solicitudJson.cotizacion.plazo = plazo;
 					   $rootScope.solicitudJson.cotizacion.idPlazo = plazo; 
 					   break; 
	 			}
	 		}
	 		
	 		
//	 		var arrayPlazoMonto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA",tipoTasa);
//	 		for ( var i = 1; i <= arrayPlazoMonto.length; i++ ){
//					
//	 			if (monto        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.MONTO["+i+"].valor",tipoTasa) &&
//					periodicidad == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PERIODICIDADID["+i+"].valor",tipoTasa) &&
//					plazo        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PLAZO["+i+"].valor",tipoTasa) ){ 						
//				   var tasaNormal = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA NORMAL["+i+"].valor",tipoTasa));
//				   var tasaPuntual = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA PUNTUAL["+i+"].valor",tipoTasa));
//				   var idProducto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PRODUCTOID["+i+"].valor",tipoTasa);
//				   var idPlazo = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PLAZO["+i+"].id",tipoTasa);
//				   var montoNormal = monto * tasaNormal;
//				   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = monto;
//				   $rootScope.solicitudJson.cotizacion.montoTotal = parseFloat((monto + montoNormal).toFixed(2));
//				   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses = parseInt($rootScope.solicitudJson.cotizacion.montoTotal - monto);
//				   $rootScope.solicitudJson.cotizacion.pagoNormal = Math.round(parseFloat($rootScope.solicitudJson.cotizacion.montoTotal / plazo));
//				   var montoPuntual = monto * tasaPuntual;
//				   var montoTotalPuntual = monto + montoPuntual;
//				   $rootScope.solicitudJson.cotizacion.pagoPuntual = Math.round(parseFloat(montoTotalPuntual / plazo));
//				   $rootScope.solicitudJson.cotizacion.ultimoAbono = parseInt($rootScope.solicitudJson.cotizacion.montoTotal - $rootScope.solicitudJson.cotizacion.pagoNormal * (plazo - 1));
//				   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto = idProducto;
//				   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].cantidad = 1;
//				   $rootScope.solicitudJson.cotizacion.idPlazo = idPlazo; 
//				   $rootScope.solicitudJson.cotizacion.plazo = plazo;
//				   break;
//				}
//	 		}
		}
		
		var calculaMontosMaximos = function () {
			var monto = $scope.prestamoPersonal.montoMaximo[ $scope.prestamoPersonal.montoMaximo.length - 1 ].valor;
	 		var periodicidad 		= $rootScope.solicitudJson.cotizacion.idPeriodicidad;
	 		var plazo 				= $scope.plazos[ $scope.plazos.length - 1];
	 		var cotizacionMaxima 	= $.extend( true, {}, $rootScope.solicitudJson.cotizacion);
	 		var arrayTempAbonos =  $rootScope.consultaAbonos.rescatePrestamo;
 			for (var i = 0; i < arrayTempAbonos.length;i++){
	 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){
	 				cotizacionMaxima.detallesCotizacion[0].monto = monto; //su prestamo
	 				cotizacionMaxima.montoTotal = parseInt(arrayTempAbonos[i].precio) + parseInt(arrayTempAbonos[i].sobre);
	 				cotizacionMaxima.detallesCotizacion[0].intereses = parseInt(arrayTempAbonos[i].sobre);
					   
	 				cotizacionMaxima.pagoNormal = parseFloat(arrayTempAbonos[i].normal); //pagara
	 				cotizacionMaxima.pagoPuntual = parseFloat(arrayTempAbonos[i].puntual); //pago puntual
	 				cotizacionMaxima.ultimoAbono = parseInt(arrayTempAbonos[i].ultimo);
	 				cotizacionMaxima.detallesCotizacion[0].idProducto = arrayTempAbonos[i].sku;
	 				cotizacionMaxima.detallesCotizacion[0].cantidad = 1;
	 				cotizacionMaxima.plazo = plazo;
	 				cotizacionMaxima.idPlazo = plazo; 
 					break; 
	 			}
	 		}
 			return cotizacionMaxima;
		}
		
		var actualizarProductoRescate = function(cotizacion){
			cotizacion.clientes[0]=null;
			
			generaGuardadoCotizacion(cotizacion);
			
			var cadenaJsonCotizacion = null;
	        if($rootScope.JsonCotizacion!=null)
	        	cadenaJsonCotizacion=JSON.stringify($rootScope.JsonCotizacion);
	        
			var json = {
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					idProductoSeleccionado: $scope.productoElegido,
					opcion: $scope.opcion,
					cotizacion: $scope.productoElegido==PRODUCTOS.prestamoPersonal.ID.valor?JSON.stringify(cotizacion):null,
					bitacoraCotizacion: cadenaJsonCotizacion
				}
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			buroService.actualizaProductoRescate( json, PROCESOS.BDC ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
							var responseJson = JSON.parse(data.data.respuesta);
							
							if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
								
								if($scope.opcion==151 || $scope.opcion==159 || $scope.opcion==162 || $scope.opcion==128)
									$rootScope.requiereObligado = true;
								
								if($scope.productoElegido == PRODUCTOS.prestamoPersonal.ID.valor){
									if($scope.opcion==150)
										$rootScope.rescatePPGarantias=true;
									else
										$rootScope.rescatePPObligado=true;
								}
								
								$rootScope.capacidadesPagoProducto = responseJson.data.capacidadesPagoProducto;
								$rootScope.solicitudJson = responseJson.data.solicitud;
								$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO
								$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
								$rootScope.mostrarOfertaCotizador = false;
								$rootScope.onceOfert = true;
								
								$scope.$parent.muestraAlertaNuevoBuro=false;
								$scope.$parent.muestraMensajeNuevoBuro=false;
								$scope.$parent.mensajeNuevoBuro="";
								
								$rootScope.calculaDocumentos();
								$scope.closeThisDialog(true);
								
							}else{
								generalService.cleanRootScope($rootScope);							
								generalService.buildSolicitudJson($rootScope, null);
								if($rootScope.solicitudOSJson){
									generalServiceOS.cleanRootScope($rootScope);
									generalService.buildSolicitudOSJson($rootScope, null);
								}
								$scope.closeThisDialog(false);
								$rootScope.message("Error " + responseJson.codigo,[responseJson.descripcion], "Aceptar", "/simulador", "bgazul");
							} 
							
						}else {
							generalService.cleanRootScope($rootScope);							
							generalService.buildSolicitudJson($rootScope, null);
							if($rootScope.solicitudOSJson){
								generalServiceOS.cleanRootScope($rootScope);
								generalService.buildSolicitudOSJson($rootScope, null);
							}
							$scope.closeThisDialog(false);
							$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul");
						}
						
					}, function(error){
						generalService.cleanRootScope($rootScope);							
						generalService.buildSolicitudJson($rootScope, null);
						if($rootScope.solicitudOSJson){
							generalServiceOS.cleanRootScope($rootScope);
							generalService.buildSolicitudOSJson($rootScope, null);
						}
						$scope.closeThisDialog(false);
						$rootScope.message("Error ",[" Favor de intentar nuevamente se detectó un problema "], "Aceptar", "/simulador", "bgazul");
					}	  
				  );
		}
		
		function generaGuardadoCotizacion(cotizacion){
	 		if($scope.productoElegido==PRODUCTOS.prestamoPersonal.ID.valor && $rootScope.actualizoCotizacion){
	 			if(($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.generada.id || $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id) &&
	 				$rootScope.solicitudJson.idSolicitudTienda==0)
		 			$rootScope.JsonCotizacion.tipoOferta=2;
		 		else
		 			$rootScope.JsonCotizacion.tipoOferta=3;
	 			$rootScope.JsonCotizacion.canalEnvio=0;
	 			$rootScope.JsonCotizacion.montoSolicitado=cotizacion.detallesCotizacion[0].monto;
	 			$rootScope.JsonCotizacion.plazoSolicitado=cotizacion.plazo;
	 			$rootScope.JsonCotizacion.periodicidad=cotizacion.idPeriodicidad;
	 			$rootScope.JsonCotizacion.sku=cotizacion.detallesCotizacion[0].idProducto;
	 			$rootScope.JsonCotizacion.abonoNormalSolicitado=cotizacion.pagoNormal;
	 			$rootScope.JsonCotizacion.abonoPuntualSolicitado=cotizacion.pagoPuntual;
	 			var cotizacionMaxima = calculaMontosMaximos();
	 			$rootScope.JsonCotizacion.montoMaximo=cotizacionMaxima.detallesCotizacion[0].monto;
	 			$rootScope.JsonCotizacion.plazoMaximo=cotizacionMaxima.plazo;
	 			$rootScope.JsonCotizacion.abonoNormalMaximo=cotizacionMaxima.pagoNormal;
	 			$rootScope.JsonCotizacion.abonoPuntualMaximo=cotizacionMaxima.pagoPuntual;
	 		}else{
	 			$rootScope.JsonCotizacion=null;
	 		}
	 	};
		
		$scope.consulta = function (){
			switch(true){
				case $scope.seleccion.prestamoPersonal.valores.montoMaximo > 0:
				case $scope.seleccion.prestamoPersonal.valores.requisito > 0:
				case $scope.seleccion.prestamoPersonal.valores.plazo > 0:
					generalService.setArrayValue("24Rescate",$scope.seleccion.prestamoPersonal);
					break;
				case $scope.seleccion.creditoConsumo.valores.montoMaximo > 0:
					generalService.setArrayValue("21Rescate",$scope.seleccion.creditoConsumo);
					break;
				case $scope.seleccion.telefonia.valores.montoMaximo > 0:
					generalService.setArrayValue("23Rescate",$scope.seleccion.telefonia);
					break;
				case $scope.seleccion.italika.valores.montoMaximo > 0:
					generalService.setArrayValue("22Rescate",$scope.seleccion.italika);
					break;
			}
			$scope.bloqueaBotones = true;
			modalService.rescateConsumoFaseIII_2Modal("En Banco Azteca le decimos SÍ a nuestros clientes", $rootScope.solicitudJson.marca ).then(
					function(estatus) {
						$scope.showPage=false;
						$scope.bloqueaBotones = false;
						$timeout(function(){
							$scope.showPage = true;
						}, 500);	
					}, function(exito) {
						$scope.showPage=false;
						$scope.bloqueaBotones = false;
						$timeout(function(){
							$scope.showPage = true;
							
						}, 500);	
					}
				);
		};
		
		$scope.rechazar = function(){
    		var x = {
			    idSolicitud : $rootScope.solicitudJson.idSolicitud,
			    idSeguimiento: STATUS_SOLICITUD.rechazada.id,
			    idMotivoRechazo: STATUS_SOLICITUD.rechazada.idMotivoRechazo.rechazoPrestamoRescate
			}
    		
    		$rootScope.waitLoaderStatus = LOADER_SHOW;
    		solicitudService.actualizarSolicitud( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.cleanRootScope($rootScope);
					generalService.buildSolicitudJson($rootScope, null);
					generalService.buildSolicitudOSJson($rootScope, null);
					$scope.closeThisDialog();
					generalService.locationPath("/simulador");
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.cleanRootScope($rootScope);
					generalService.buildSolicitudJson($rootScope, null);
					generalService.buildSolicitudOSJson($rootScope, null);
					modalService.alertModal("Error "+error.status, [error.statusText]);
					$scope.closeThisDialog();
					generalService.locationPath("/simulador");
			});
    	};
	});
});