'use strict';

define(["app"], function (app) {
	

	var nipModalController = function ($scope, $rootScope, $location, $timeout,  modalService,  loginService, sessionService, securityService, generalService) {				
		$scope.messageNIPiguales="";
		
		$scope.init=function(){
		
			if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
			
			$scope.model = {
					titulo: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.TITULO."+$scope.origen+".valor"],
					inputCapturaNIP: { placeholder: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.INPUT NIP.MARCAAGUA.valor"],
									   maxlength  : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.INPUT NIP.LONGMAX.valor"],
									   minlength  : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.INPUT NIP.LONGMIN.valor"],
									   formato    : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.INPUT NIP.FORMATO.valor"]},
					inputConfirmaNIP:{ placeholder: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.INPUT CONFIRMA NIP.MARCAAGUA.valor"],
									   maxlength  : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.INPUT CONFIRMA NIP.LONGMAX.valor"],
									   minlength  : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.INPUT CONFIRMA NIP.LONGMIN.valor"],
									   formato    : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.INPUT CONFIRMA NIP.FORMATO.valor"]},
					btnCanelar:{ label  : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.BOTON CANCELAR."+$scope.origen+".valor"],
								 visible: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.BOTON CANCELAR.VISIBLE.valor"]},
					btnAceptar:{ label  : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.BOTON ACEPTAR."+$scope.origen+".valor"],
								 visible: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.BOTON ACEPTAR.VISIBLE.valor"]},
				};
		
		}
		
		$scope.validaNIP=function(varNip){
			if(varNip.$valid){
				if($scope.NIP.length == $scope.model.inputCapturaNIP.minlength && $scope.confirmaNIP.length == $scope.model.inputCapturaNIP.minlength )
					$scope.validaNIPIguales();
				else if($scope.NIP.length == $scope.model.inputCapturaNIP.minlength){
					var arrayNIP = $scope.NIP.split("");
					if(arrayNIP[0] == arrayNIP[1] && arrayNIP[1] == arrayNIP[2] && arrayNIP[2] == arrayNIP[3]){
						$scope.nipInvalido = true;
						$scope.mensaje=MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.ETIQUETA IGUALES."+$scope.origen+".valor"];
					}
					if(!$scope.nipInvalido){
						var valorInicial = [];
						var sigNum = valorInicial[0] = parseInt(arrayNIP[0]);
						for(var a=1; a < arrayNIP.length; a++){
							sigNum = sigNum + 1;
							if (sigNum > 9)
								sigNum = valorInicial[a] = 0;
							else
								valorInicial[a]= sigNum;
						}
						valorInicial = valorInicial.join("");
						if(parseInt($scope.NIP) == parseInt(valorInicial)){
							$scope.nipInvalido = true;
							$scope.mensaje=MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.ETIQUETA CONSECUTIVOS."+$scope.origen+".valor"];
						}
					}
					if(!$scope.nipInvalido){
						var valorInicial = [];
						var antNum = valorInicial[0] = parseInt(arrayNIP[0]);
						for(var a=1; a < arrayNIP.length; a++){
							antNum = antNum - 1;
							if (antNum < 0)
								antNum = valorInicial[a] = 9;
							else
								valorInicial[a]= antNum;
						}
						valorInicial = valorInicial.join("");
						if(parseInt($scope.NIP) == parseInt(valorInicial)){
							$scope.nipInvalido = true;
							$scope.mensaje=MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.ETIQUETA DESCENDENTE."+$scope.origen+".valor"];
						}
					}
					if(!$scope.nipInvalido){
						var dosIguales = false;
						for(var a=0; a < arrayNIP.length - 1; a++){
							if (parseInt(arrayNIP[a]) == parseInt(arrayNIP[a + 1]))
								dosIguales = true;
						}
						if(dosIguales){
							$scope.nipInvalido = true;
							$scope.mensaje=MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.ETIQUETA IGUALES CONTINUO."+$scope.origen+".valor"];
						}
					}
					if($scope.nipInvalido){
						$scope.NIP = "";
						$scope.confirmaNIP = "";
					}
				}else
					$scope.nipInvalido = false;
			}else{
				$scope.confirmaNIP = "";
				$scope.nipInvalido = false;
			}
		};
		
		$scope.validaNIPIguales=function(){
			if($scope.confirmaNIP.length == $scope.model.inputCapturaNIP.minlength){
				if( $scope.NIP != $scope.confirmaNIP){
					$scope.messageNIPiguales=MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.ETIQUETA NO COINCIDE."+$scope.origen+".valor"];
					$scope.confirmaNIP = "";
				}
				if($scope.NIP == $scope.confirmaNIP )
					$scope.messageNIPiguales="";
			}
		};
		
		$scope.setNIP = function(){
			if($scope.messageNIPiguales=='' && !$scope.nipInvalido && $scope.NIP.length==$scope.model.inputCapturaNIP.minlength && $scope.confirmaNIP.length==$scope.model.inputCapturaNIP.minlength){
				if( generalService.isEmpty($scope.NIP) || generalService.isEmpty($scope.confirmaNIP) )
					$scope.messageNIPiguales=MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.MENSAJE NIP VACIO."+$scope.origen+".valor"];
				
				else if( $scope.NIP != $scope.confirmaNIP)
					$scope.messageNIPiguales=MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.MODAL NIP.MENSAJE CONFIRMA NIP."+$scope.origen+".valor"];
				
				else{			
					if( !generalService.isEmpty($scope.NIP) )
						generalService.setArrayValue('nip', $scope.NIP );
					
					$scope.closeThisDialog();
				}
			}
						
		};
		
			   
	};
	
	
	app.controller('nipModalController', [ '$scope', '$rootScope', '$location', '$timeout',  'modalService',  'loginService', 'sessionService', 'securityService', 'generalService', nipModalController ]);		
	
	
});