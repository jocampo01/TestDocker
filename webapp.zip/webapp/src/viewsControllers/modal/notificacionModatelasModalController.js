'use strict';

define(["app"], function (app) {

    app.controller("notificacionModatelasModalController", function ( $scope, $rootScope, $location, $timeout, generalService, modalService) {
    	
    	$scope.compDomicilioObj = {id:null, tipo:null,anio:null, mes:null,dia:null, imagen:null}
    	$scope.msj = "";
    	
    	
		$scope.init = function(documentoId){
			loadView();						
		};
						
		
		function loadView(){				
			var origen = configuracion.origen.tienda ? "TIENDA":"WEB";
			$scope.isTienda = configuracion.origen.tienda;
			
					var nombretarjeta = $rootScope.solicitudJson.idProducto == ID_PRODUCTO.modatelas? "Modatelas ":""
					
					var _textoHeader = "Infórmale a tu cliente que su tarjeta "+nombretarjeta+"fue pre autorizada y se la podemos entregar hoy mismo con un límite de crédito de $2,000";
					
					var cuerpoDlg = new Array();
					angular.forEach( $rootScope.solicitudJson.documentos.documento, function(doc, key){
						if(doc.status == STATUS_PENDIENTE )
							cuerpoDlg.push(doc.documentoDes );							
					});
					
					if(cuerpoDlg.length > 0)
						_textoHeader += " presentando:";
					
					
					var  textoFooter = "Infórmale que un ejecutivo realizará una visita a su domicilio";
					
					$scope.ngDialogData = {
							title: "Notificación",
							estiloTitulo: "bgAzul",
							textoHeader: _textoHeader,
							estiloLi: "azulLi",
							message: cuerpoDlg,
							textoFooter: textoFooter,
							nameConfirmButton: "No está interesado", 
							nameCancelButton: "Continuar", 
							estiloBotonConfirm: "btn gris", 
							estiloBotonCancel: "btn azul",
					}
												
											
		};	

	});
	
	
});