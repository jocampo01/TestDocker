'use strict';

define(["app"], function (app) {
	
	app.controller('rescateCreditoEnEfectivoController', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService, validateService, buroService, modalService) {
		
		$scope.showPage=false;
		var arrayMontosPlazos = generalService.getPlazos( $rootScope );
		$rootScope.actualizoCotizacion=true;
		$scope.productoElegido=0;
		$rootScope.armaJsonCotizacion();
		
		$scope.rescateDespuesRendicion =  ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id) ? true : false;

		$scope.init=function(){

			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			$scope.isIpad=configuracion.so.ios;
			
			$scope.tituloHeader				=	$scope.ngDialogData.title;

			$scope.textoInvitalos			=	"Invítalo a mantener un ";
			$scope.textoBuenComportamiento	=	"buen comportamiento de pago. ";
			$scope.textoUnBuenHistorial		=	"Un buen historial crediticio, le da más ";
			$scope.textoBeneficios			=	"beneficios.";
			
			$scope.textoTenemosDe			=	"Tenemos estas 2 alternativas de ";
			$scope.textoTenemosUna          =    "Tenemos esta alternativa de ";

			$scope.textopp				    =	"crédito personal";
			$scope.textoParaTu				=	" para tu cliente:";
			
			$scope.textoConOs				=	"Con Coacreditado";
			
			$scope.textoPlazoUnico			=	"Plazo único: ";
			$scope.textoSemanas             = 	" semanas";
							
			$scope.textoPagoSemanal			=	"Pago Semanal";
			$scope.textoNormal				=	"Normal: ";
			$scope.textoPuntual				=	"  |  Puntual: ";
			$scope.textoAhorra				=	"Ahorra ";
			$scope.textoSemanales			=	" semanales";
			
			$scope.textoGenerar				= 	"Generar presupuesto";
			$scope.textoNoAcepto			=	"No me interesa";
			$scope.textoAcepto				=   $scope.rescateDespuesRendicion ? "Aceptar" : "Si me interesa";
			
			
			
			$scope.textoLasGarantias		=	"* Las Garantías Prendarias deben cubrir 1.5 veces el valor del préstamo solicitado y serán registradas en el proceso de verificación";
			
			
			$scope.prestamoPersonal = {	montoMaximo : [],
					requisitos	: [ {id : 1, valor : "Con Co acreditado", visible : false},{id : 2, valor : "*Con Garantías", visible : true}]
			      };

			if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.prodResPrestamoMatriz ||  $scope.rescateDespuesRendicion ){
				cargaMontosPlazos();
			}
			
			$scope.seleccion = { 	prestamoPersonal 	: {habilitado : false, valores : {"montoMaximo":0, "requisito":0, "requisito2":0, "plazo":$scope.prestamoPersonal.montoMaximo[0].plazos[0] }}}
			
			//Bandera que indica si sera el front que imprime tickets \*/
			$scope.isWithTicket = true;
			if( $scope.isWithTicket )
				initWithTicket();
			
			$timeout(function(){
				cargaSeleccion();
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.showPage = true;
			}, 1);
			
		};

		var initWithTicket=function(){
			$scope.isIpad=configuracion.so.ios;				
			$scope.textoGenerar="Generar presupuesto";
			$scope.bloqueaBotones = false;
			$scope.muestraBotonImprimir = true;
		};
		$scope.condicionMuestraBoton = false;
	 	if($rootScope.consultaFuncionalidad.flujoTicketMoc){
	 		$scope.condicionMuestraBoton = (configuracion.origen.tienda && configuracion.so.windows && ($rootScope.sucursalSession.idCanal==1 || $rootScope.sucursalSession.idCanal == 9 || $rootScope.sucursalSession.idCanal == 39));	
	 	}
		var cargaSeleccion = function(){	
			if(generalService.getArrayValue("24Rescate") != null)
				$scope.seleccion.prestamoPersonal = generalService.getArrayValue("24Rescate");
			generalService.setArrayValue("24Rescate",null);
			
		};
		
		var montoSeleccionado = function() {
			var monto = 0;
			for(var i=0;i<$scope.prestamoPersonal.montoMaximo.length;i++){
				if($scope.prestamoPersonal.montoMaximo[i].id == $scope.seleccion.prestamoPersonal.valores.montoMaximo){
					monto = $scope.prestamoPersonal.montoMaximo[i].valor;
					return monto; 
					break;
				}
			}return monto; 
		}
		
		var calculaMontosTicket = function () {
			let monto = montoSeleccionado();
			
			for(let i=0;i<$scope.prestamoPersonal.montoMaximo.length;i++){
				if($scope.prestamoPersonal.montoMaximo[i].id == $scope.seleccion.prestamoPersonal.valores.montoMaximo){
					monto = $scope.prestamoPersonal.montoMaximo[i].valor;
					break;
				}
			}
			let cotizacionTicket 	= $.extend( true, {}, $rootScope.solicitudJson.cotizacion);
	 		let periodicidad 	= cotizacionTicket.idPeriodicidad;
	 		let plazo 			= $scope.seleccion.prestamoPersonal.valores.plazo;
	 		
	 		let arrayTempAbonos =  $rootScope.consultaAbonos.rescatePrestamo;
 			for (let i = 0; i < arrayTempAbonos.length;i++){
	 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){
	 				   cotizacionTicket.detallesCotizacion[0].monto = monto; //su prestamo
	 				   cotizacionTicket.montoTotal = parseInt(arrayTempAbonos[i].precio) + parseInt(arrayTempAbonos[i].sobre);
	 				   cotizacionTicket.detallesCotizacion[0].intereses = parseInt(arrayTempAbonos[i].sobre);
					   cotizacionTicket.pagoNormal = parseFloat(arrayTempAbonos[i].normal); //pagara
 					   cotizacionTicket.pagoPuntual = parseFloat(arrayTempAbonos[i].puntual); //pago puntual
 					   cotizacionTicket.ultimoAbono = parseInt(arrayTempAbonos[i].ultimo);
 					   cotizacionTicket.detallesCotizacion[0].idProducto = arrayTempAbonos[i].sku;
 					   cotizacionTicket.detallesCotizacion[0].cantidad = 1;
 					   cotizacionTicket.plazo = plazo;
 					   cotizacionTicket.idPlazo = plazo; 
 					   return cotizacionTicket; 
	 			}
	 		}
	 	}
		
		var calculaPagoNormal = function (monto, plazo) {
			let periodicidad 	=	$rootScope.solicitudJson.cotizacion.idPeriodicidad;
	 		let arrayTempAbonos =	$rootScope.consultaAbonos.rescatePrestamo;
 			let pagoNormal		=	0;
	 		for (let i = 0; i < arrayTempAbonos.length;i++){
	 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){
	 				pagoNormal = parseFloat(arrayTempAbonos[i].normal);
	 				break
	 			}
	 		}
	 		return pagoNormal;
	 	}
		
		var calculaPagoPuntual = function (monto, plazo) {
			let periodicidad 	=	$rootScope.solicitudJson.cotizacion.idPeriodicidad;
	 		let arrayTempAbonos =	$rootScope.consultaAbonos.rescatePrestamo;
 			let pagoPuntual		=	0;
	 		for (let i = 0; i < arrayTempAbonos.length;i++){
	 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){
	 				pagoPuntual =  parseFloat(arrayTempAbonos[i].puntual);
	 				break
	 			}
	 		}
	 		return pagoPuntual;
	 	}
		
		var calculaMontos = function () {
			var monto = montoSeleccionado();
			
			for(var i=0;i<$scope.prestamoPersonal.montoMaximo.length;i++){
				if($scope.prestamoPersonal.montoMaximo[i].id == $scope.seleccion.prestamoPersonal.valores.montoMaximo){
					monto = $scope.prestamoPersonal.montoMaximo[i].valor;
					break;
				}
			}
	 		var periodicidad 	= $rootScope.solicitudJson.cotizacion.idPeriodicidad;
	 		var plazo 			= $scope.seleccion.prestamoPersonal.valores.plazo;
	 		
	 		var arrayTempAbonos =  $rootScope.consultaAbonos.rescatePrestamo;
 			for (var i = 0; i < arrayTempAbonos.length;i++){
	 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){
	 				   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = monto; //su prestamo
// 					   $rootScope.solicitudJson.cotizacion.montoTotal = parseFloat(arrayTempAbonos[i].sobre);
// 					   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses = parseInt($rootScope.solicitudJson.cotizacion.montoTotal - monto);
	 				   $rootScope.solicitudJson.cotizacion.montoTotal = parseInt(arrayTempAbonos[i].precio) + parseInt(arrayTempAbonos[i].sobre);
	 				   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses = parseInt(arrayTempAbonos[i].sobre);
					   
 					   $rootScope.solicitudJson.cotizacion.pagoNormal = parseFloat(arrayTempAbonos[i].normal); //pagara
 					   $rootScope.solicitudJson.cotizacion.pagoPuntual = parseFloat(arrayTempAbonos[i].puntual); //pago puntual
 					   $rootScope.solicitudJson.cotizacion.ultimoAbono = parseInt(arrayTempAbonos[i].ultimo);
 					   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto = arrayTempAbonos[i].sku;
 					   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].cantidad = 1;
 					   $rootScope.solicitudJson.cotizacion.plazo = plazo;
 					   $rootScope.solicitudJson.cotizacion.idPlazo = plazo; 
 					   break; 
	 			}
	 		}
	 	}
		
		$scope.aceptarOferta = function (){
			if(montoSeleccionado() != 0){
				if( $scope.rescateDespuesRendicion  ){ 
					if($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto != montoSeleccionado())
						guardarSeccion();
					else {
						$scope.closeThisDialog(true);
					}
				} else if($scope.productoElegido == PRODUCTOS.prestamoPersonal.ID.valor ){
					calculaMontos();
					
					if($scope.seleccion.prestamoPersonal.valores.requisito == 2 || $scope.seleccion.prestamoPersonal.valores.requisito2 == 2)
						$scope.opcion=150;
					else
						$scope.opcion=151;
					
					actualizarProductoRescate($rootScope.solicitudJson.cotizacion);	
				}				
			}
		};
		
		var calculaMontosMaximos = function () {
			var monto = $scope.prestamoPersonal.montoMaximo[ $scope.prestamoPersonal.montoMaximo.length - 1 ].valor;
	 		var periodicidad 		= $rootScope.solicitudJson.cotizacion.idPeriodicidad;
	 		var plazo 				= $scope.plazos[ $scope.plazos.length - 1];
	 		var cotizacionMaxima 	= $.extend( true, {}, $rootScope.solicitudJson.cotizacion);
	 		var arrayTempAbonos =  $rootScope.consultaAbonos.rescatePrestamo;
 			for (var i = 0; i < arrayTempAbonos.length;i++){
	 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){
	 				cotizacionMaxima.detallesCotizacion[0].monto = monto; //su prestamo
	 				cotizacionMaxima.montoTotal = parseInt(arrayTempAbonos[i].precio) + parseInt(arrayTempAbonos[i].sobre);
	 				cotizacionMaxima.detallesCotizacion[0].intereses = parseInt(arrayTempAbonos[i].sobre);
					   
	 				cotizacionMaxima.pagoNormal = parseFloat(arrayTempAbonos[i].normal); //pagara
	 				cotizacionMaxima.pagoPuntual = parseFloat(arrayTempAbonos[i].puntual); //pago puntual
	 				cotizacionMaxima.ultimoAbono = parseInt(arrayTempAbonos[i].ultimo);
	 				cotizacionMaxima.detallesCotizacion[0].idProducto = arrayTempAbonos[i].sku;
	 				cotizacionMaxima.detallesCotizacion[0].cantidad = 1;
	 				cotizacionMaxima.plazo = plazo;
	 				cotizacionMaxima.idPlazo = plazo; 
 					break; 
	 			}
	 		}
 			return cotizacionMaxima;
		}
		
		var actualizarProductoRescate = function(cotizacion){

			cotizacion.clientes[0]=null;
			
			generaGuardadoCotizacion(cotizacion);
			
			var cadenaJsonCotizacion = null;
	        if($rootScope.JsonCotizacion!=null)
	        	cadenaJsonCotizacion=JSON.stringify($rootScope.JsonCotizacion);
	        
			var json = {
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					idProductoSeleccionado: $scope.productoElegido,
					opcion: $scope.opcion,
					cotizacion: $scope.productoElegido==PRODUCTOS.prestamoPersonal.ID.valor?JSON.stringify(cotizacion):null,
					bitacoraCotizacion: cadenaJsonCotizacion
				}
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			buroService.actualizaProductoRescate( json, PROCESOS.BDC ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
							var responseJson = JSON.parse(data.data.respuesta);
							
							if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
								
								if($scope.opcion==151 || $scope.opcion==159 || $scope.opcion==162 || $scope.opcion==128)
									$rootScope.requiereObligado = true;
								
								if($scope.productoElegido == PRODUCTOS.prestamoPersonal.ID.valor){
									if($scope.opcion==150)
										$rootScope.rescatePPGarantias=true;
									else
										$rootScope.rescatePPObligado=true;
								}
								
								$rootScope.capacidadesPagoProducto = responseJson.data.capacidadesPagoProducto;
								$rootScope.solicitudJson = responseJson.data.solicitud;
								$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO
								$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
								$rootScope.mostrarOfertaCotizador = false;
								$rootScope.onceOfert = true;
								
								$scope.$parent.muestraAlertaNuevoBuro=false;
								$scope.$parent.muestraMensajeNuevoBuro=false;
								$scope.$parent.mensajeNuevoBuro="";
								
								$rootScope.calculaDocumentos();
								
								
								$scope.closeThisDialog(true);
								generalService.locationPath("/ochoPasos");
								
							}else{
								generalService.cleanRootScope($rootScope);							
								generalService.buildSolicitudJson($rootScope, null);
								if($rootScope.solicitudOSJson){
									generalServiceOS.cleanRootScope($rootScope);
									generalService.buildSolicitudOSJson($rootScope, null);
								}
								$scope.closeThisDialog(false);
								$rootScope.message("Error " + responseJson.codigo,[responseJson.descripcion], "Aceptar", "/simulador", "bgazul");
							} 
							
						}else {
							generalService.cleanRootScope($rootScope);							
							generalService.buildSolicitudJson($rootScope, null);
							if($rootScope.solicitudOSJson){
								generalServiceOS.cleanRootScope($rootScope);
								generalService.buildSolicitudOSJson($rootScope, null);
							}
							$scope.closeThisDialog(false);
							$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul");
						}
						
					}, function(error){
						generalService.cleanRootScope($rootScope);							
						generalService.buildSolicitudJson($rootScope, null);
						if($rootScope.solicitudOSJson){
							generalServiceOS.cleanRootScope($rootScope);
							generalService.buildSolicitudOSJson($rootScope, null);
						}
						$scope.closeThisDialog(false);
						$rootScope.message("Error ",[" Favor de intentar nuevamente se detect� un problema "], "Aceptar", "/simulador", "bgazul");
					}	  
				  );
		}
		
		function generaGuardadoCotizacion(cotizacion){
	 		if($scope.productoElegido==PRODUCTOS.prestamoPersonal.ID.valor && $rootScope.actualizoCotizacion){
	 			if(($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.generada.id || $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id) &&
	 				$rootScope.solicitudJson.idSolicitudTienda==0)
		 			$rootScope.JsonCotizacion.tipoOferta=2;
		 		else
		 			$rootScope.JsonCotizacion.tipoOferta=3;
	 			$rootScope.JsonCotizacion.canalEnvio=0;
	 			$rootScope.JsonCotizacion.montoSolicitado=cotizacion.detallesCotizacion[0].monto;
	 			$rootScope.JsonCotizacion.plazoSolicitado=cotizacion.plazo;
	 			$rootScope.JsonCotizacion.periodicidad=cotizacion.idPeriodicidad;
	 			$rootScope.JsonCotizacion.sku=cotizacion.detallesCotizacion[0].idProducto;
	 			$rootScope.JsonCotizacion.abonoNormalSolicitado=cotizacion.pagoNormal;
	 			$rootScope.JsonCotizacion.abonoPuntualSolicitado=cotizacion.pagoPuntual;
	 			var cotizacionMaxima = calculaMontosMaximos();
	 			$rootScope.JsonCotizacion.montoMaximo=cotizacionMaxima.detallesCotizacion[0].monto;
	 			$rootScope.JsonCotizacion.plazoMaximo=cotizacionMaxima.plazo;
	 			$rootScope.JsonCotizacion.abonoNormalMaximo=cotizacionMaxima.pagoNormal;
	 			$rootScope.JsonCotizacion.abonoPuntualMaximo=cotizacionMaxima.pagoPuntual;
	 		}else{
	 			$rootScope.JsonCotizacion=null;
	 		}
	 	};
		$scope.rechazar = function(){
    		var x = {
			    idSolicitud : $rootScope.solicitudJson.idSolicitud,
			    idSeguimiento: STATUS_SOLICITUD.rechazada.id,
			    idMotivoRechazo: STATUS_SOLICITUD.rechazada.idMotivoRechazo.rechazoPrestamoRescate
			}
    		
    		$rootScope.waitLoaderStatus = LOADER_SHOW;
    		solicitudService.actualizarSolicitud( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.cleanRootScope($rootScope);
					generalService.buildSolicitudJson($rootScope, null);
					generalService.buildSolicitudOSJson($rootScope, null);
					$scope.closeThisDialog();
					generalService.locationPath("/simulador");
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.cleanRootScope($rootScope);
					generalService.buildSolicitudJson($rootScope, null);
					generalService.buildSolicitudOSJson($rootScope, null);
					modalService.alertModal("Error "+error.status, [error.statusText]);
					$scope.closeThisDialog();
					generalService.locationPath("/simulador");
			});
    	};
    	
    	
    	var cargaMontosPlazos = function(){
			$scope.prestamoPersonal.montoMaximo=[];
			$scope.plazos=[];
			var idMontos=0;
			for(var i = 0; i < arrayMontosPlazos.length; i++){
				var datosMontos={id : 0, valor : 0, pagoNormal : 0, pagoPuntual : 0, visible : true, plazos: []};
				idMontos=idMontos+1;
				datosMontos.id		=	idMontos;
				datosMontos.valor	=	arrayMontosPlazos[i].monto;
				if($rootScope.solicitudJson.banderaIngresos == 1){
					var plazosCpComprobable=ordenarPlazos(arrayMontosPlazos[i].cpComprobable);
					for(var x = 0;x < plazosCpComprobable.length;x++){
						datosMontos.plazos.push(plazosCpComprobable[x]);
						$scope.plazos.push(plazosCpComprobable[x]);
					}
				}else{
					var plazosCpNoComprobable=ordenarPlazos(arrayMontosPlazos[i].cpNoComprobable);
					for(var x = 0;x < plazosCpNoComprobable.length;x++){
						datosMontos.plazos.push(plazosCpNoComprobable[x]);
						$scope.plazos.push(plazosCpNoComprobable[x]);
					}
				}
				datosMontos.pagoNormal	=	calculaPagoNormal(datosMontos.valor,datosMontos.plazos[0]);
				datosMontos.pagoPuntual =	calculaPagoPuntual(datosMontos.valor,datosMontos.plazos[0]);
				$scope.prestamoPersonal.montoMaximo.push(datosMontos);
			}
			$scope.plazos = ordenarPlazos($scope.plazos);
			$scope.plazos = eliminarDuplicados($scope.plazos);
		};
		
		var ordenarPlazos = function(arrayPlazos){
			arrayPlazos.sort(function (a, b) {
				  if (a > b) {
				    return 1;
				  }
				  if (a < b) {
				    return -1;
				  }
				  // a must be equal to b
				  return 0;
			});
			return arrayPlazos;
		};

		var eliminarDuplicados = function(plazos){
			var arrayPlazos = [];
			var ind = 1;
			arrayPlazos.push(plazos[0]);
			for(var i=1;i<plazos.length;i++){
				if(arrayPlazos[ind-1] != plazos[i]){
					ind++;
					arrayPlazos.push(plazos[i]);
				}
			}
			return arrayPlazos;
		}
		
		$scope.limpiaOtros = function (seleccionado,cambio){
			$scope.productoElegido=0;
			$scope.seleccion.prestamoPersonal.valores.requisito = 2; //con garantias
									
				for(var i=0;i<$scope.prestamoPersonal.montoMaximo.length;i++){
					if($scope.prestamoPersonal.montoMaximo[i].id == $scope.seleccion.prestamoPersonal.valores.montoMaximo)
						$scope.plazos = $scope.prestamoPersonal.montoMaximo[i].plazos;
				}
				
				if($scope.plazos.length == 0){
					$scope.seleccion.prestamoPersonal.valores.plazo=0;
				}else{
					  $scope.seleccion.prestamoPersonal.valores.plazo = $scope.plazos[0];					
		
				}
				
				if(cambio==1){
					if($scope.seleccion.prestamoPersonal.valores.requisito == 0 && $scope.seleccion.prestamoPersonal.valores.requisito2 !=0)
						$scope.seleccion.prestamoPersonal.valores.requisito =	$scope.seleccion.prestamoPersonal.valores.requisito2;
					$scope.seleccion.prestamoPersonal.valores.requisito2	=	0;						
					$scope.seleccion.prestamoPersonal.valores.montoMaximo	= 	$scope.prestamoPersonal.montoMaximo[0].id;
				} else if(cambio==2){
					if($scope.seleccion.prestamoPersonal.valores.requisito2 == 0 && $scope.seleccion.prestamoPersonal.valores.requisito1 !=0)
						$scope.seleccion.prestamoPersonal.valores.requisito2 = $scope.seleccion.prestamoPersonal.valores.requisito;
					$scope.seleccion.prestamoPersonal.valores.requisito		=	0;						
					$scope.seleccion.prestamoPersonal.valores.montoMaximo	=	$scope.prestamoPersonal.montoMaximo[1].id;
				}

				if($scope.seleccion.prestamoPersonal.valores.montoMaximo > 0 && $scope.seleccion.prestamoPersonal.valores.plazo > 0 && ($scope.rescateDespuesRendicion || $scope.seleccion.prestamoPersonal.valores.requisito > 0 || $scope.seleccion.prestamoPersonal.valores.requisito2 > 0) ){
					$scope.productoElegido=PRODUCTOS.prestamoPersonal.ID.valor;
					$scope.muestraBotonImprimir = true;
				}
		};
		
		$scope.imprimirPresupuesto =  function(){
			let cotizacion = calculaMontosTicket();
	 		let jsonCotizacion = {
	 				monto			:	cotizacion.detallesCotizacion[0].monto,
	 				plazo			:	cotizacion.plazo,
	 				pNormal			:	cotizacion.pagoNormal,
	 				pPuntual		:	cotizacion.pagoPuntual,
	 				idPeriodicidad	:	cotizacion.idPeriodicidad,
	 				producto		:	$rootScope.solicitudJson.idProducto,
	 				sku				:	cotizacion.detallesCotizacion[0].idProducto,
	 				capacidadePago	:	$rootScope.solicitudJson.capacidadPagoComprobable
	 		}
	 		
	 		
	 		$rootScope.generarPlantillaImpresion(1, $rootScope.solicitudJson, $rootScope.userSession, $rootScope.sucursalSession, jsonCotizacion, undefined);
	 	};
		
	 	
	 	var guardarSeccion = function() {
	 		calculaMontos();
	 		generaGuardadoCotizacion($rootScope.solicitudJson.cotizacion);
			
			var cadenaJsonCotizacion = null;
	        if($rootScope.JsonCotizacion!=null)
	        	cadenaJsonCotizacion=JSON.stringify($rootScope.JsonCotizacion);
	        $rootScope.waitLoaderStatus = LOADER_SHOW;
	 		solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($rootScope.solicitudJson), seccion: SECCION_SOLICITUD, bitacoraCotizacion: cadenaJsonCotizacion }, PROCESOS.PSC ).then(
		 			function(data){
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
		 					var responseJson = JSON.parse(data.data.respuesta);
		 					$rootScope.solicitudJson = responseJson.data;
		 					$scope.closeThisDialog(true);
		 				}	
		 			}, function(error){                     
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				$rootScope.message("Aviso ", ["Inconveniente al actualizar la solicitud. Favor de volver a intentar"],"Aceptar", "/simulador");								
		 			}	
				);
		};
    	
	});
});