'use strict';

define(["app"], function (app) { 
	app.controller('seguroDialogController', function( $timeout, $scope, $rootScope, ngDialog, generalService, authService, loginService, modalService, solicitudService, tarjetaService, buroService){
		
		$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";
		$scope.acepto = false;
		$scope.isVidaMaxunificado = $rootScope.consultaFuncionalidad.habilitarFlujoSeguroVidamaxUnificado;
		$scope.nuevoSeguroVidaMax = $rootScope.consultaFuncionalidad.habilitarFlujoSeguroVidamax;
		var capacidadPago = $rootScope.solicitudJson.capacidadPagoComprobable - $rootScope.solicitudJson.cotizacion.pagoNormal
		$rootScope.solicitudJson.seguroDeVida = {
		          "nombreSeguro": "",
		          "opcionSeguro": 0,
		          "idSeguro": "",
		          "precioSeguro": 0,
		          "sobrePrecioSeguro": 0,
		          "abonoSeguro": 0,
		          "ultimoAbonoSeguro": 0,
		          "totalSeguro": 0,
		          "clavePromocion": "",
		          "comisionVenta": 0,
		          "montoFinal": 0,
		          "montoInicial": 0,
		          "esDefault": 0
		       };
			
		if($scope.seguros){
			if($scope.seguros.listaPlanes){
				for(var i=0;i<$scope.seguros.listaPlanes.length;i++){
					$scope.seguros.listaPlanes[i].color = "";
				}
			}
		}
		
		$scope.init=function(){		
				/*\Se agrega un evento para la bitacora\*/
				//(oferta Seguro)
					$rootScope.addEvent( BITACORA.SECCION.ofertaSeguro.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, 0, BITACORA.SECCION.ofertaSeguro.guardarEnBD );
				
				/*\Se agrega un evento para la bitacora\*/
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			if( generalService.existeSolicitud($rootScope.solicitudJson) ){
				
				$scope.pagoPuntual = $rootScope.solicitudJson.cotizacion.pagoPuntual;											
				buroService.resultadoConsulta($rootScope.solicitudJson.idSolicitud,$rootScope).then(
						function(objRes){								
							$scope.datosCredito = objRes.datosCredito;
							$scope.resCon= objRes.resConsulta;	
							$scope.cpDisponible = $scope.resCon.disponible;
							
																							
							$scope.informaleCliente.texto="<h1>Infórmale a <b>{{ solicitudJson.cotizacion.clientes[0].nombre }} {{ solicitudJson.cotizacion.clientes[0].apellidoPaterno }} {{ solicitudJson.cotizacion.clientes[0].apellidoMaterno }}</b> que su "+$scope.resCon.descProducto+" de:</h1><h1 style=\"margin:20px 0\"><span>{{ resCon.montoAutorizado | currency:\"$\":0  }}</span> fue  <span>AUTORIZADO</span></h1>"
							$scope.informaleCliente.texto = $scope.informaleCliente.texto.replace(/\\/g,'');
							
							$rootScope.waitLoaderStatus = LOADER_HIDE;								
							$scope.showPage = true;
									
						}, function(error){
							$rootScope.message(titulo, [error], "Aceptar", null, "bgCafeZ", "cafeZ");
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 								
						}
				);
			
			}else{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message(titulo, [SIN_SOLICITUD.texto], "Aceptar", "/", "bgCafeZ", "cafeZ");
			}
			
			
			
			
			$scope.modelCelular = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
			
			if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
			
			var productos = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.CATALOGO PRODUCTOS"];						
			$scope.descCatalog = generalService.getProductosCredito(productos, ID_PRODUCTOS);
			
			$scope.titulo            = generalService.getDataInput("MODAL SEGURO","TITULO",$scope.origen);
			$scope.informaleModel    = generalService.getDataInput("MODAL SEGURO","ETIQUETA INFORMALE",$scope.origen);
			$scope.informaleView     = $scope.informaleModel.texto.split("{{}}"); 
			$scope.seleccionSeguroTexto = "Pídele a tu cliente que seleccione una opción:";
			$scope.por      		 = generalService.getDataInput("MODAL SEGURO","ETIQUETA POR",$scope.origen);
			$scope.periodicidad      = generalService.getDataInput("MODAL SEGURO","ETIQUETA PERIODICIDAD",$scope.origen);
			$scope.beneficios        = generalService.getDataInput("MODAL SEGURO","ETIQUETA BENEFICIOS",$scope.origen);
			
			
			$scope.diaSemana = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.CREDITO.CATDIASSEMANA"];									
			$scope.labelTitulo = generalService.getDataInput("CREDITO","TITULO",$scope.origen );
			$scope.CPsemanal = generalService.getDataInput("CREDITO","ETIQUETACPS",$scope.origen );
			$scope.labelDiaPago = generalService.getDataInput("CREDITO","ETIQUETADIAPAGO",$scope.origen );			
			$scope.labelTotal = generalService.getDataInput("CREDITO","ETIQUETATOTAL",$scope.origen );
			$scope.labelOcupado = generalService.getDataInput("CREDITO","ETIQUETAOCUPADO",$scope.origen );
			$scope.labelPP = generalService.getDataInput("CREDITO","ETIQUETAPP",$scope.origen );
			$scope.labelDisponible = generalService.getDataInput("CREDITO","ETIQUETADISP",$scope.origen );
			$scope.LDC = generalService.getDataInput("CREDITO","ETIQUETALDC",$scope.origen );						
			$scope.selectDiaPago = generalService.getDataInput("CREDITO","SELECT DIA PAGO",$scope.origen );						
			$scope.btnLiberacion = generalService.getDataInput("CREDITO","BOTON LIBERAR",$scope.origen );
			$scope.informaleCliente = generalService.getDataInput("CREDITO","ETIQUETA1",$scope.origen );
			$scope.informaleCliente.texto = $scope.informaleCliente.texto.replace(/\\/g,'');
			$scope.confirmacionSegurotexto = "Pídele a tu cliente que seleccione una opción y coloque su huella";
			if($scope.nuevoSeguroVidaMax){
				$scope.informaleView[1] = " que aún tiene capacidad de pago disponible y en este momento puede adquirir el Seguro Nuevo Vidamax para proteger a su familia en caso de que llegue a faltar.";
				$scope.seleccionSeguroTexto = "¿Por qué cantidad le gustaría proteger a su familia durante la vigencia del crédito?";
				$scope.confirmacionSegurotexto = "¿Acepta que se incluya el seguro?";
				$scope.beneficios.texto = "INCLUYE en caso de fallecimiento:";
			}
			
			
			
			if ($scope.seguros.listaPlanes){
				if ($scope.seguros.listaPlanes.length > 5)
					$scope.ClaseCarrucel = "opciones owl-carousel"
				else{
					$scope.ClaseCarrucel = "center"
				}
				$timeout(function(){
					if ($scope.seguros.listaPlanes.length > 5){
						$("#owl-example2").owlCarousel({
							items: 5
						});
					}
					 $rootScope.waitLoaderStatus = LOADER_HIDE;
				 }, 100)
			}
		};
		
		$scope.seleccionSeguro = function(id){
			if ($scope.idSeleccion)
				$scope.cambiaColor();
			$scope.idSeleccion=id;
			$scope.cambiaColor(id);
			$scope.acepto = true;
//			$scope.validaHuella();
						
		};
			
		
		$scope.cambiaColor = function(id){			
			var index = $scope.seguros.listaPlanes.map(function(d){
				return $scope.isVidaMaxunificado? d["productoId"]:d["sku"];
				
			}).indexOf ($scope.idSeleccion);
			if (index != -1){
				if (id){					
					$scope.seguros.listaPlanes[index].color = "verdeS";
					$scope.pagoPuntual = $rootScope.solicitudJson.cotizacion.pagoPuntual +  $scope.seguros.listaPlanes[index].precio;					
					$scope.cpDisponible =  $scope.resCon.disponible - $scope.seguros.listaPlanes[index].precio;	
					
					
					var indexP = $scope.resCon.pedidos.map(function(d){
						return d["descProducto"];						
					}).indexOf ($scope.nuevoSeguroVidaMax?"Seguro Nuevo Vidamax":"Seguro Vidamax");
					
					if(indexP == -1)
						$scope.resCon.pedidos.push({descProducto:$scope.nuevoSeguroVidaMax?"Seguro Nuevo Vidamax":"Seguro Vidamax", saldoPedido:$scope.seguros.listaPlanes[index].precio });
					else
						$scope.resCon.pedidos[indexP].saldoPedido = $scope.seguros.listaPlanes[index].precio;					
					
				}else{					
					$scope.seguros.listaPlanes[index].color = "";
				}
			}
		}
		$scope.validaHuella = function()
		{
			/*\Se agrega un evento para la bitacora\*/
			//(oferta Seguro)
				$rootScope.addEvent( BITACORA.SECCION.ofertaSeguro.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.aceptar.id, 0, BITACORA.SECCION.ofertaSeguro.guardarEnBD );
				
			/*\Se agrega un evento para la bitacora\*/
//			if(configuracion.origen.tienda && TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) == -1){
//				$rootScope.waitLoaderStatus = LOADER_SHOW;
//				$rootScope.verificarHuella( 'seguroID', 'responseVerificarHuellaIpad', 
//						[$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico] );
//			}else
				$scope.responseVerificarHuellaIpad( {codigo:0, matches:["OK"]} );
			
		};/* END VALIDA HUELLA FUNCTION */
		
		$scope.responseVerificarHuellaIpad = function( response ){
			try{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(response.codigo == VALIDA_HUELLA_RESPONSE.EXITO ){						
					var index = $scope.seguros.listaPlanes.map(function(d){
						return $scope.isVidaMaxunificado? d["productoId"] : d["sku"];
						
					}).indexOf ($scope.idSeleccion);
					if (index != -1)
						$scope.SeguroSel = $scope.seguros.listaPlanes[index];
					
					console.log($scope.SeguroSel);
					
//					var index2 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
//						return d["idContrato"];
//						
//					}).indexOf (FIRMA_SEGURO_CLIENTE.id);
//					if (index2 == -1){
//						$rootScope.solicitudJson.contratos.contrato.push( 
//								{idContrato: FIRMA_SEGURO_CLIENTE.id,
//									idPersona: "",
//									statusFirma: 0,
//									descripcion: FIRMA_SEGURO_CLIENTE.etiqueta,
//									idTipoPersona: 1
//								});
//					}
					if (index != -1)
						$scope.SeguroSel = $scope.seguros.listaPlanes[index];
					
					console.log($scope.SeguroSel);
					
//					var index2 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
//						return d["idContrato"];
//						
//					}).indexOf (FIRMA_SEGURO_CARTA.id);
//					if (index2 == -1){
//						$rootScope.solicitudJson.contratos.contrato.push( 
//								{idContrato: FIRMA_SEGURO_CARTA.id,
//									idPersona: "",
//									statusFirma: 0,
//									descripcion: FIRMA_SEGURO_CARTA.etiqueta,
//									idTipoPersona: 1
//								});
//					}
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					$scope.guardar();
//					$scope.closeThisDialog();
//					generalService.locationPath("/");
					
				}
		
			}catch(e){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.closeThisDialog();
			}									
				
		};/* END RESPONSE VERIFICAR HUELLA IPAD FUNCTION */
			
			
	    $scope.guardar = function(){
	    	var esDefault = 0
	    	if (!$scope.isVidaMaxunificado && $scope.SeguroSel.esDefault)
	    		esDefault = 1
	    	else
	    		esDefault = 0
	    	$rootScope.solicitudJson.banderaSeguro = 1;
	    	
	    	if(!$rootScope.solicitudJson.seguroDeVida){
	    		$rootScope.solicitudJson.seguroDeVida = {"abonoSeguro": $scope.SeguroSel.precio};
	    	}
	    	$rootScope.solicitudJson.seguroDeVida.abonoSeguro = $scope.SeguroSel.precio;
	    	$rootScope.solicitudJson.seguroDeVida.clavePromocion = $scope.isVidaMaxunificado? "" : $scope.SeguroSel.cveProm.toString();
	    	$rootScope.solicitudJson.seguroDeVida.comisionVenta = $scope.isVidaMaxunificado? 1 : $scope.SeguroSel.comisionVenta;
	    	$rootScope.solicitudJson.seguroDeVida.esDefault = esDefault;
	    	$rootScope.solicitudJson.seguroDeVida.idSeguro = $scope.isVidaMaxunificado? $scope.SeguroSel.productoId.toString() : $scope.SeguroSel.sku.toString();
	    	$rootScope.solicitudJson.seguroDeVida.montoFinal = $scope.SeguroSel.montoFinal;
	    	$rootScope.solicitudJson.seguroDeVida.montoInicial= $scope.isVidaMaxunificado? 0 : $scope.SeguroSel.montoInicial;
	    	$rootScope.solicitudJson.seguroDeVida.nombreSeguro  = $scope.SeguroSel.nombre;
	    	$rootScope.solicitudJson.seguroDeVida.opcionSeguro = $scope.isVidaMaxunificado? 1 : $scope.SeguroSel.tipo;
	    	$rootScope.solicitudJson.seguroDeVida.precioSeguro = $scope.SeguroSel.precioCalculado; 
	    	var _sobreprecio = $scope.isVidaMaxunificado? $scope.SeguroSel.sobrePrecio :$scope.SeguroSel.sobrePrecioCalculado;
	    	$rootScope.solicitudJson.seguroDeVida.sobrePrecioSeguro = _sobreprecio;
	    	$rootScope.solicitudJson.seguroDeVida.totalSeguro = $scope.SeguroSel.precioCalculado + _sobreprecio;
	    	$rootScope.solicitudJson.seguroDeVida.ultimoAbonoSeguro = $scope.SeguroSel.precio;
	    	$rootScope.solicitudJson.seguroDeVida.tasaSeguro = $scope.isVidaMaxunificado? $rootScope.seguros.tasaSeguro : 0.0;

	    	$scope.confirm();
//	    	$scope.guardaSeccionSeguro();
	    }
	    
	    
	    $scope.cerrar= function(){
	    	/*\Se agrega un evento para la bitacora\*/
			//(oferta Seguro)
				$rootScope.addEvent( BITACORA.SECCION.ofertaSeguro.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.noAceptar.id, 0, BITACORA.SECCION.ofertaSeguro.guardarEnBD );
				
			/*\Se agrega un evento para la bitacora\*/
	    	$rootScope.solicitudJson.banderaSeguro = 1;
	    	$rootScope.solicitudJson.seguroDeVida = {
			          "nombreSeguro": "",
			          "opcionSeguro": 0,
			          "idSeguro": "",
			          "precioSeguro": 0,
			          "sobrePrecioSeguro": 0,
			          "abonoSeguro": 0,
			          "ultimoAbonoSeguro": 0,
			          "totalSeguro": 0,
			          "clavePromocion": "",
			          "comisionVenta": 0,
			          "montoFinal": 0,
			          "montoInicial": 0,
			          "esDefault": 0
			       };
	    	$scope.guardaSeccionSeguro(true);
	    }
	    
		
	    $scope.camelize = function(msn) {
	          // Restore original values
	    	  return generalService.camelize(msn);
	     };
	     
	    $scope.guardaSeccionSeguro = function(banderaCierra){
	    	var solicitudJsonString = generalService.delete$$hashKey($rootScope.solicitudJson);
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
		    solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: SECCION_SEGUROS } ).then(
		    		function(data){
		    			$rootScope.waitLoaderStatus = LOADER_HIDE;
		    			
		    			if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
		    				var responseJson = JSON.parse(data.data.respuesta);							
		    				if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
		    					$rootScope.solicitudJson = responseJson.data;	
		    					generalService.setRespaldo($rootScope.solicitudJson);
		    					if (banderaCierra)
		    						$scope.closeThisDialog();
		    					else
		    						$scope.confirm();
		    				}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
								var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
								$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
							}else{
		    					if(responseJson.codigo == ERROR_SOL_RECHAZADA){
		    						var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
									var marca = $rootScope.solicitudJson.marca;
									var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
		    						$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],
		    								"Aceptar", "/simulador",null,null,buildJsonDefault);
		    					}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
									generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
									generalService.locationPath("/ficha");
								}else{
		    						$rootScope.message("Seguro VidaMax",[$scope.mensajeError], "Aceptar", null, null, null);
								}
		    				}
		    			}else{
		    				$rootScope.message("Seguro VidaMax",[generalService.displayMessage(data.data.descripcion)], "Aceptar", null, null, null);
		    			}
		    			
		    		}, function(error){
		    			$rootScope.waitLoaderStatus = LOADER_HIDE;
		    		}
		    );	
	    }
	    
	    
	    $scope.getDescripcionProducto=function(idProducto){			
	 		return generalService.getDescripcionProducto(idProducto,$rootScope);
	 	};

	});
});