'use strict';

define(["app"], function (app) {

    app.controller("showMessageContratosController", function ( $scope, $rootScope, $timeout, documentosService, expedienteService, generalService) {
    	$scope.init = function(){
    		
    	}
    });
});