'use strict';

define(["app"], function (app) {

    app.controller("tipoIdentOficialModalController", function ( $scope, $rootScope, generalService) {
    	    	 
    	
    	var TIPOS_IDENTIFICACION = {IFE:1, INE:2, FME:IDENT_FME};
    	var _nacionalidades = null;
    	$scope.tipoIdentOficialObj = {id:null}
    	$scope.listaTipoIdOficial = new Array();
    	
    	
		$scope.init = function(nacionalidades){
			_nacionalidades = nacionalidades;
			loadView();						
		};
					
		
		$scope.capturarImagenIpadResponse = function(responseIpad){
			$rootScope.loggerIpad("capturarImagenIpadResponse", null, responseIpad);
			if(responseIpad.codigo == RESPONSE_CODIGO_EXITO_IPAD){
				
				if(responseIpad.arrArchBase64.length > 0){
					generalService.setArrayValue('nomsImgIFE',responseIpad.arrNomArchBase64);
		 			generalService.setArrayValue('imgsIFE',responseIpad.arrArchBase64);
		 			
		 			angular.element(document.getElementById('simulador')).scope().removeNacionalidad(NAC_MEXICANA);
				}	 				 		
				
			}else{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("",[responseIpad.mensaje], "Aceptar");
			}
									
			$scope.closeThisDialog();
		};
		
		
		$scope.fotoImagenIpad = function(){
			if($scope.tipoIdentOficialObj.id == TIPOS_IDENTIFICACION.FME){
				$rootScope.capturarImagenIpad($rootScope.solicitudJson.cotizacion.clientes[0].idPersona,2, ["Capturar IFE (frente)", "Capturar IFE (reverso)"],
						IDENTIFICACION_OFICIAL.id,'tipoIdentOficialModalId',"capturarImagenIpadResponse", 2, IDENTIFICACION_OFICIAL.descripcion, null);
				
			}else{
				$rootScope.solicitudJson.cotizacion.clientes[0].idNacionalidad = NAC_MEXICANA;				
				$rootScope.solicitudJson.cotizacion.clientes[0].nacionalidadDes = generalService.descripcionCatalogo(NAC_MEXICANA, _nacionalidades);
				
				
				angular.element(document.getElementById('simulador')).scope().bloqueaNacionalidad(NAC_MEXICANA);				
				$rootScope.aplicarOCR_IFE('ocrDiv','respuestaComponente');				
				$scope.closeThisDialog();
			}
													
		};
				
		
		function loadView(){				
			var origen = configuracion.origen.tienda ? "TIENDA":"WEB";
			$scope.isTienda = configuracion.origen.tienda;
			
			$scope.listaTipoIdOficial = [{id:1, descripcion:"IFE"},{id:2, descripcion:"INE"},{id:IDENT_FME, descripcion:"FME"}];
												
						
		};	
		
		

	});
	
	
});