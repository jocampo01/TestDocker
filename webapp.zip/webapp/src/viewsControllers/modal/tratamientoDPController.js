'use strict';

define(["app"], function (app) {

    app.controller("tratamientoDPController", function ( $scope, $rootScope, $timeout, documentosService, expedienteService, generalService) {
    	$scope.init = function(){
    		
    	}
    	
    	$scope.verificarCheckbox = function(valor){
    		if(valor == 1 || valor == 2){
    			$scope.bloquearBotonAceptar = true;
    		}
    		$rootScope.solicitudJson.tratamientoDatos = ($scope.tratamiento1)? 1:0;
    		$rootScope.solicitudJson.transferenciaDatos = ($scope.tratamiento2) ? 1:0;
    	}
    });
});