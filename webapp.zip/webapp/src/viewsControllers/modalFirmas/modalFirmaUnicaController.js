'use strict';

define(["app"], function (app) {
	app.controller('modalFirmaUnicaController', function($scope,  $rootScope, $location, $timeout, generalService, modalService){

		var tipoFirma = 1;
		var csstabs = {on:"tab dos cafeLi active", off:"tab dos cafeLi"};
		$scope.muestraTipoModalUnicaAutografa = ($rootScope.isFirmaUnica)?false:true;/** Variable para controlar el tipo de modal que se mostrará, true firma autografa, false, firma única**/
		$scope.condicionMuestraContratos = $rootScope.contratosOriginacion;/** Variable para controlar que contrato se van a mostar, true AP y BC, false CC y SC**/
		$scope.bloquearBtnFirmar = true;
		var contadorVeces = 0;
		
		var timeStampHoraAvisoPrivacidad = "";
		var timeStampHoraBuroCredito = "";
		var timeStampHoraContratoCredito = "";
		var timeStampHoraSolicitudCredito = "";
		var timeStampHoraAnexoBienes = "";
		$rootScope.firmaUnica = undefined;
		$scope.checkAviso = false;
		$scope.checkBuro = false;
		$rootScope.isAvisoWSD = false;
		$rootScope.isBuroWSD = false;
		
		/**
		 * Esta función la utilizan ambos flujos
		 **/
		$scope.init = function(){
			
			//$rootScope.firmaPrivacidad = undefined;
			//$rootScope.firmaBuro = undefined;
			/**
			 * Estilos para los Tabs
			 **/
			$scope.tabFirmadoCSS =  csstabs.on;
			$scope.tabSinFirmaCSS =  csstabs.off;
			$scope.tabFirmadoSCSS = csstabs.on;
			/**
			 * URL del contrato por default
			 * Esto aplica para estampar el html del contrato en la vista principal 
			 **/
			$scope.urlDoc = "AvisoPrivacidad.html";
			$scope.contratoView = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";
			
			/**
			 * La variable 'tabActivo' por default se toma el TAB de Aviso de Privacidad
			 * La variable 'visualizaContrato', true muestra el contrato en toda la pantalla, false, deja la vista de acuerdo al tipo de firma que se este realizando
			 **/
			$scope.tabActivo = 1;
			$scope.visualizaContrato = false;
			
			if($scope.condicionMuestraContratos){
				/** 
				 * Si es el primer bloque de contratos
				 * 'muestraContratos' Bander para habilitar el primer bloque de contratos a nivel de vista
				 * 'visualizaDoc' Se visualiza el primer documento AP por default
				 * 'tabActivo' El valor 1 corresponde al Aviso de Privacidad, esta variable es para dar estilo al TAB
				 * 'title' Titulo del PAD de firmas
				 **/
				$scope.muestraContratos = true;
				$scope.visualizaDoc("1");
				$scope.tabActivo = 1;
				$scope.title = "Firma Aviso Privacidad";
			}else{
				/** 
				 * Es el segundo bloque de contratos
				 * 'muestraContratos' Si es el segundo bloque de contratos
				 * 'visualizaDoc' Se visualiza el primer documento CC por default
				 * 'tabActivo' El valor 3 corresponde al Contrato de Crédito, esta variable es para dar estilo al TAB
				 * 'title' Titulo del PAD de firmas
				 **/
				$scope.muestraContratos = false;
				$scope.visualizaDoc("3");
				$scope.tabActivo = 3;
				$scope.title = "Firma Consulta al Buró de Crédito";
			}
			
			if($scope.checkAviso){
				document.getElementById("checkAviso").checked = true;
			}else if($scope.checkBuro){
				document.getElementById("checkBuro").checked = true;
			}
		};
		
		/**
		 * Esta función solo la utiliza la firma autografa
		 **/
		$scope.estilosTabs = function(TipoPersona){
			if($scope.condicionMuestraContratos){/** Si es el primer bloque de contratos **/
				if(TipoPersona == 1){/** 'TipoPersona' evalua la condición para activar  desactivar, 1 corresponde al AP **/
					/**
					 * 'tabFirmadoCSS' Se aplica estilo para simular que el TAB está seleccionado
					 * 'tabSinFirmaCSS' Se aplica estilo para simular que el TAB no está seleccionado
					 * 'tabActivo' El valor 1 corresponde al Aviso de Privacidad, esta variable es para dar estilo al TAB
					 * 'title' Titulo del PAD de firmas
					 **/
					$scope.tabFirmadoCSS =  csstabs.on;
					$scope.tabSinFirmaCSS =  csstabs.off;
					$scope.tabActivo = 1;
					$scope.title = "Firma Aviso Privacidad";
				}else{
					/**
					 * 'tabFirmadoCSS' Se aplica estilo para simular que el TAB está seleccionado
					 * 'tabSinFirmaCSS' Se aplica estilo para simular que el TAB no está seleccionado
					 * 'tabActivo' El valor 1 corresponde al Aviso de Privacidad, esta variable es para dar estilo al TAB
					 * 'title' Titulo del PAD de firmas
					 **/
					$scope.tabFirmadoCSS =  csstabs.off;
					$scope.tabSinFirmaCSS =  csstabs.on;
					$scope.tabActivo = 2;
					$scope.title = "Firma Consulta al Buró de Crédito";
				}
			}else if($rootScope.hayContratoBienes){
				if(TipoPersona == 3){/** 'TipoPersona' evalua la condición para activar  desactivar, 3 corresponde al CC **/
					/**
					 * 'tabFirmadoCSS' Se aplica estilo para simular que el TAB está seleccionado
					 * 'tabSinFirmaCSS' Se aplica estilo para simular que el TAB no está seleccionado
					 * 'tabActivo' El valor 1 corresponde al Aviso de Privacidad, esta variable es para dar estilo al TAB
					 * 'title' Titulo del PAD de firmas
					 **/
					$scope.tabFirmadoCSS =  csstabs.on;
					$scope.tabSinFirmaCSS =  csstabs.off;
					$scope.tabFirmadoSCSS = csstabs.on;
					$scope.tabActivo = 3;
					$scope.title = "Firma Contrato y Carátula de Crédito";
				}else if(TipoPersona == 4){
					/**
					 * 'tabFirmadoCSS' Se aplica estilo para simular que el TAB está seleccionado
					 * 'tabSinFirmaCSS' Se aplica estilo para simular que el TAB no está seleccionado
					 * 'tabActivo' El valor 1 corresponde al Aviso de Privacidad, esta variable es para dar estilo al TAB
					 * 'title' Titulo del PAD de firmas
					 **/
					$scope.tabFirmadoCSS =  csstabs.off;
					$scope.tabSinFirmaCSS =  csstabs.on;
					$scope.tabFirmadoSCSS = csstabs.on;
					$scope.tabActivo = 4;
					$scope.title = "Firma Solicitud de Crédito";
				}else if(TipoPersona == 5){
					/**
					 * 'tabFirmadoCSS' Se aplica estilo para simular que el TAB está seleccionado
					 * 'tabSinFirmaCSS' Se aplica estilo para simular que el TAB no está seleccionado
					 * 'tabActivo' El valor 1 corresponde al Aviso de Privacidad, esta variable es para dar estilo al TAB
					 * 'title' Titulo del PAD de firmas
					 **/
					$scope.tabFirmadoCSS =  csstabs.on;
					$scope.tabSinFirmaCSS =  csstabs.on;
					$scope.tabFirmadoSCSS = csstabs.off;
					$scope.tabActivo = 5;
					$scope.title = "Firma Anexo de Bienes";
				}
			}else{
				if(TipoPersona == 3){/** 'TipoPersona' evalua la condición para activar  desactivar, 3 corresponde al CC **/
					/**
					 * 'tabFirmadoCSS' Se aplica estilo para simular que el TAB está seleccionado
					 * 'tabSinFirmaCSS' Se aplica estilo para simular que el TAB no está seleccionado
					 * 'tabActivo' El valor 1 corresponde al Aviso de Privacidad, esta variable es para dar estilo al TAB
					 * 'title' Titulo del PAD de firmas
					 **/
					$scope.tabFirmadoCSS =  csstabs.on;
					$scope.tabSinFirmaCSS =  csstabs.off;
					$scope.tabActivo = 3;
					$scope.title = "Firma Contrato y Carátula de Crédito";
				}else if(TipoPersona == 4){
					/**
					 * 'tabFirmadoCSS' Se aplica estilo para simular que el TAB está seleccionado
					 * 'tabSinFirmaCSS' Se aplica estilo para simular que el TAB no está seleccionado
					 * 'tabActivo' El valor 1 corresponde al Aviso de Privacidad, esta variable es para dar estilo al TAB
					 * 'title' Titulo del PAD de firmas
					 **/
					$scope.tabFirmadoCSS =  csstabs.off;
					$scope.tabSinFirmaCSS =  csstabs.on;
					$scope.tabActivo = 4;
					$scope.title = "Firma Solicitud de Crédito";
				}
			}
			
			/**
			 * Visualiza el documento dependiendo de la variable 'TipoPersona'
			 * 1 AP
			 * 2 BC
			 * 3 CC
			 * 4 SC
			 **/
			$scope.visualizaDoc(TipoPersona+"");
		}
		
		/**
		 * Esta función la utilizan ambos flujos
		 **/
		$scope.visualizaDoc =  function (id){
			switch (id){
				case "1":       	              	
		          	$scope.urlDoc = "AvisoPrivacidad.html";
		          	$scope.title = "Firma Aviso Privacidad";
				break;
				case "2":
					$scope.urlDoc = "BuroCredito.html";
					$scope.title = "Firma Consulta al Buró de Crédito";
				break;
				case "3":
					$scope.urlDoc = "ContratoCaratulaCredito.html";
					$scope.title = "Firma Contrato y Carátula de Crédito";
				break;
				case "4":
					$scope.urlDoc = "SolicitudCredito.html";
					$scope.title = "Firma Solicitud de Crédito";
				break;
				case "5":
					$scope.urlDoc = "AnexoBienes.html";
					$scope.title = "Firma Anexo de Bienes";
				break;
		        default:
		        	break;
			}
			
			/**
			 * Construye el Frame para incrustar un HTML dentro de otro HTML
			 **/
			$timeout( function(){construirIframe();}, 100 );
			
			/**
			 * Prepara el entorno para para agregar un html dentro de la vista principal
			 * 'contratoView' es la variable que contine la ruta del contrato
			 **/
			$scope.contratoView = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			
			/**
			 * 'muestraTipoModalUnicaAutografa' Variable para controlar el tipo de modal que se mostrará, true firma autografa, false, firma única
			 * 'contadorVeces' evita que al iniciar la vista, se visualice el contrato sin antes seleccionarlo
			 **/
			if(!$scope.muestraTipoModalUnicaAutografa && contadorVeces > 0){
				$scope.visualizaContrato = true;
			}else{
				contadorVeces++;
			}
		};
		
		/**
		 * Esta función la utilizan ambos flujos
		 **/
		var construirIframe = function(){
			/**
			 * Construye el frame con base al index principal
			 **/
			
			var divIframe = $( '#contenedor' );
			var iframe = document.createElement('iframe');

			iframe.height= "100%";
			iframe.width = "100%";
			iframe.id = "iframe";
			iframe.src = "pdf/web/viewer.jsp?urlDoc='" + $scope.urlDoc + "'";
			iframe.scrolling = "no";
			iframe.style.marginBottom = "15px";

			divIframe.append( iframe );
		};
		
		/**
		 * Esta función la utilizan ambos flujos
		 **/
		$scope.firmarContratos = function(numeroFirma){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			/**
			 * 'tipoFirma' contiene el número de firma, en caso de 
			 * 1 Firma normal
			 * 2 Segunda firma en el contrato de Solicitud de Crédito
			 * 3 Firma Única
			 **/
			tipoFirma = numeroFirma;
			
			/**
			 * Levanta el modal para firmar desde el iPad
			 **/
			modalService.firmas($scope.title).then(
				function(exito){
					$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
				},function(error){
					$scope.responseFirmaWV({codigo: 1, img64:null});
				}
			);
		}
		
		/**
		 * Esta función la utilizan ambos flujos
		 **/
		$scope.responseFirmaWV = function(responseWV){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){/** Codigo de exito del frame de firmas es 0* */
				if($scope.muestraTipoModalUnicaAutografa){/** 'muestraTipoModalUnicaAutografa' si es firma autografa **/
					if($scope.tabActivo == 1){/** El conrtrato seleccionado en las TAB es AP **/
						$rootScope.firmaPrivacidad = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");	
						$rootScope.imgPrivacidad = responseWV.img64;
						$rootScope.isAvisoWSD = true;
					}else if($scope.tabActivo == 2){/** El conrtrato seleccionado en las TAB es BC **/
						$rootScope.firmaBuro = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
						$rootScope.isBuroWSD = true;
					}else if($scope.tabActivo == 3){/** El conrtrato seleccionado en las TAB es CC **/
						$rootScope.firmaCaratula = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
						$rootScope.isContratoCaratulaWSD = true;
						$rootScope.isCaratulaWSD = true;
						$rootScope.imgCaratula = responseWV.img64;
					}else if($scope.tabActivo == 4){/** El conrtrato seleccionado en las TAB es SC **/
						if(tipoFirma == 1){/** 'tipoFirma' si es 1 se estampa la primera firma, si es 2 estampa la segunda firma **/
							$rootScope.firmaSolicitud = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
							$rootScope.firmaSolUnoWSD = true;
							$rootScope.imgSolicitud = responseWV.img64;
						}else{
							$rootScope.firmaSolicitudDos = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
							$rootScope.firmaSolDosWSD = true;
							$rootScope.imgSolicitudDos = responseWV.img64;
						}
					}else if($scope.tabActivo == 5){/** El conrtrato seleccionado en las TAB es AB **/
						$rootScope.firmaBienes = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
						$rootScope.isBienesWSD = true;
						$rootScope.imgFirmaBienes = responseWV.img64;
					}
				}else{
					if(tipoFirma == 3){/** 'tipoFirma' si es 3 guarda la firma autografa **/
						$rootScope.firmaUnica = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
						$rootScope.firmaPrivacidad = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
						$rootScope.responseFirmaUnica = responseWV;
						$rootScope.imgPrivacidad = responseWV.img64;
					}
				}
			}	
		};
		
		/**
		 * Esta función la utilizan ambos flujos
		 **/
		$scope.continuarSolicitud = function(){
			var puedeContinuar =  true;
			var respuesta = {};
			
			if($scope.muestraTipoModalUnicaAutografa){/** 'muestraTipoModalUnicaAutografa' si es firma autografa **/
				if($scope.condicionMuestraContratos && ($scope.firmaPrivacidad == null || $scope.firmaPrivacidad == "" || $scope.firmaPrivacidad == undefined)){/** Si es el primer bloque de firmas y no firmó AP, te muestra el contrato para que se firme**/
					$scope.estilosTabs(1);
					puedeContinuar =  false
				}else if($scope.condicionMuestraContratos && ($scope.firmaBuro == null || $scope.firmaBuro == "" || $scope.firmaBuro == undefined)){/** Si es el primer bloque de firmas y no firmó BC, te muestra el contrato para que se firme**/
					$scope.estilosTabs(2);
					puedeContinuar =  false
				}else if(!$scope.condicionMuestraContratos && ($scope.firmaCaratula == null || $scope.firmaCaratula == "" || $scope.firmaCaratula == undefined)){/** Si es el segundo bloque de firmas y no firmó CC, te muestra el contrato para que se firme**/
					$scope.estilosTabs(3);
					puedeContinuar =  false
				}else if(!$scope.condicionMuestraContratos && ($scope.firmaSolicitud == null || $scope.firmaSolicitud == "" || $scope.firmaSolicitud == undefined)){/** Si es el segundo bloque de firmas y no firmó SC firma 1, te muestra el contrato para que se firme**/
					$scope.estilosTabs(4);
					puedeContinuar =  false
				}else if(!$scope.condicionMuestraContratos && ($scope.firmaSolicitudDos == null || $scope.firmaSolicitudDos == "" || $scope.firmaSolicitudDos == undefined)){/** Si es el segundo bloque de firmas y no firmó SC firma 2, te muestra el contrato para que se firme**/
					$scope.estilosTabs(4);
					puedeContinuar =  false
				}else if($rootScope.hayContratoBienes){ /** Si es el segundo bloque de firmas y no se ha dado check al contrato de SC, se queda en la misma pantalla **/
					if(!$scope.condicionMuestraContratos && ($scope.firmaBienes == null || $scope.firmaBienes == "" || $scope.firmaBienes == undefined)){
						$scope.estilosTabs(5);
						puedeContinuar =  false;
					}
				}
			}else{
				/**
				 * Contruye el objeto que necesita el front para poder continuar con el guardado de la firma única
				 **/
				respuesta = {
					"horaAvisoPrivacidad": "",
					"imgB64": [],
					"horaBuroCredito": "",
					"codigo": 0,
					"mensaje": "Firma capturada correctamente",
					"identificador": []
				}
				
				if($scope.condicionMuestraContratos && ($scope.firmaUnica == null || $scope.firmaUnica == "" || $scope.firmaUnica == undefined)){ /** Si es el primer bloque de firmas y la firma esta vacia, se queda en la misma pantalla **/
					puedeContinuar =  false;
				}else if($scope.condicionMuestraContratos && timeStampHoraAvisoPrivacidad == ""){ /** Si es el primer bloque de firmas y no se ha dado check al contrato de AP, se queda en la misma pantalla **/
					puedeContinuar =  false;
				}else if($scope.condicionMuestraContratos && timeStampHoraBuroCredito == ""){ /** Si es el primer bloque de firmas y no se ha dado check al contrato de BC, se queda en la misma pantalla **/
					puedeContinuar =  false;
				}else if(!$scope.condicionMuestraContratos && timeStampHoraContratoCredito == ""){ /** Si es el segundo bloque de firmas y no se ha dado check al contrato de CC, se queda en la misma pantalla **/
					puedeContinuar =  false;
				}else if($rootScope.hayContratoBienes){ /** Si es el segundo bloque de firmas y no se ha dado check al contrato de SC, se queda en la misma pantalla **/
					if(!$scope.condicionMuestraContratos && timeStampHoraSolicitudCredito == ""){
						puedeContinuar =  false;
					}
				}
				
				if(puedeContinuar){/** Si todo esta OK entonces construte el objeto con los timeStamp de AP y BC y la firma Única **/
					respuesta.horaAvisoPrivacidad = timeStampHoraAvisoPrivacidad;
					respuesta.horaBuroCredito = timeStampHoraBuroCredito;
					respuesta.imgB64.push($scope.firmaUnica.replace("data:image/png;base64,",""));
				}
			}
			
			if(puedeContinuar){
				if($scope.muestraTipoModalUnicaAutografa){/** Si es firma autografa cierra el modal sin enviar parametros **/
					if($location.$$url == "/simulador"){
						/*\Se agrega un evento para la bitacora\*/
						//(originación)
						$rootScope.addEvent( BITACORA.SECCION.originacion.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.continuar.id, 0, BITACORA.SECCION.originacion.guardarEnBD );
						/*\Se agrega un evento para la bitacora\*/
					}
					$scope.confirm();
				}else{/** Si es firma única cierra el modal enviando parámetros **/
					if($location.$$url == "/simulador"){
						/*\Se agrega un evento para la bitacora\*/
						//(originación)
						$rootScope.addEvent( BITACORA.SECCION.originacion.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.continuar.id, 0, BITACORA.SECCION.originacion.guardarEnBD );
						/*\Se agrega un evento para la bitacora\*/
					}
					$scope.confirm(respuesta);
				}
			}
		}
		
		/**
		 * Esta función solo la utiliza la firma única
		 **/
		$scope.regresaVistaPrincipalFirmaUnica = function(){
			/**
			 * Solo pone la bandera 'visualizaContrato' para regresa a la vista principal de la firma única 
			 **/
			
			$scope.visualizaContrato = false;
		}
		
		/**
		 * Esta función solo la utiliza la firma única
		 **/
		$scope.obtenerTimeStampFirma = function(id){
			/**
			 * Crea el timeStamp y la deposita en las variables correspondientes
			 * timeStampHoraAvisoPrivacidad - timeStamp al AP
			 * timeStampHoraBuroCredito - timeStamp al BC
			 * timeStampHoraContratoCredito - timeStamp al CC
			 * timeStampHoraSolicitudCredito - timeStamp a la SC
			 **/
			var timeStamp = Date.now();
			
			if(id == 1){
				if(timeStampHoraAvisoPrivacidad == ""){
					$scope.checkAviso = true;
					timeStampHoraAvisoPrivacidad = timeStamp+"";
				}else{
					$scope.checkAviso = false;
					timeStampHoraAvisoPrivacidad = "";
				}
				
			}else if(id == 2){
				if(timeStampHoraBuroCredito == ""){
					$scope.checkBuro = true;
					timeStampHoraBuroCredito = timeStamp+"";
				}else{
					$scope.checkBuro = false;
					timeStampHoraBuroCredito = "";
				}
				
			}else if(id == 3){
				timeStampHoraContratoCredito = timeStamp+"";
			}else if(id == 4){
				timeStampHoraSolicitudCredito = timeStamp+"";
			}else if(id == 5){
				timeStampHoraAnexoBienes = timeStamp+"";
			}
			
			if(timeStampHoraAvisoPrivacidad != "" && timeStampHoraBuroCredito != ""){
				$scope.bloquearBtnFirmar = false;
			}else{
				$scope.bloquearBtnFirmar = true;
				$rootScope.firmaUnica = undefined;
			}
		}
		
		/**
		 * Esta función solo la utiliza la firma autografa
		 * Es para cerrar el modal sin nunguna accion
		 **/
		$scope.cancelar = function(){
			/*$rootScope.firmaPrivacidad = undefined;
			$rootScope.firmaBuro = undefined;
			$rootScope.firmaCaratula = undefined;
			$rootScope.firmaSolicitud = undefined;
			$rootScope.firmaSolicitudDos = undefined;
			$rootScope.firmaSolicitudDos = undefined;*/
			
			/*\Se agrega un evento para la bitacora\*/
//			(Contratos)
			$rootScope.addEvent( BITACORA.SECCION.contratos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.cancelar.id, $rootScope.solicitudJson.contratos.porcentaje, BITACORA.SECCION.contratos.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
			
			$scope.closeThisDialog();
			generalService.locationPath("/ochoPasos");
		};
		
		$scope.cerrar = function(){
			
			/*\Se agrega un evento para la bitacora\*/
//			(Contratos)
			$rootScope.addEvent( BITACORA.SECCION.contratos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.cancelar.id, $rootScope.solicitudJson.contratos.porcentaje, BITACORA.SECCION.contratos.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
			
			$scope.closeThisDialog();
			if($rootScope.isOrigenModal){
				generalService.locationPath("/ochoPasos");
				$rootScope.isOrigenModal = false;
			}else{
				$rootScope.firmaUnica = undefined;
			}
		};
		
	});
});