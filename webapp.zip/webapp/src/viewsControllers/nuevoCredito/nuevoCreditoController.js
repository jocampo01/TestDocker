'use strict';

define(["app"], function (app) {

app.controller('nuevoCreditoController', function( $scope, $rootScope, ngDialog, 
													generalService, modalService, $timeout, messageData ) {
	$scope.vistaNuevoCredito=configuracion.nuevoCredito.opcion;
	$scope.numCuenta=4040;
    $scope.cotizar = function(){
		configuracion.simulador.opcion=1;
		configuracion.datosUsuario.opcion=1;
		generalService.locationPath("/simulador");
	};
	
	$scope.init = function()
	{
		
		$scope.showPage = false;
		
		if( messageData ){
			
			$timeout(function(){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.showPage = messageData;
			}, TIME_OUT_VIEW_MODEL);			
			
		}
		
		
	}
	
//SERVICIO
/*	
	var params={xml:$scope.xmlSimulador,celular:$scope.celular,email:$scope.correo};
	
	$scope.guardaNuevoCredito=function(){
		$rootScope.waitLoaderStatus = LOADER_SHOW;		
		nuevoCreditoService.guardaNuevoCredito(params).then(
				function(data) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					console.log("Exito");
					console.log(data);
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					console.log("Error");
				});	
    };
*/	
//SERVICIO  
	//funcion para abrir el dialogo huella
	  $scope.abrirDialogo = function(){			  		
		  modalService.huellaModal("bgcafeC");
	  }; 
});

});