'use strict';

define([ "app" ], function(app) {
	app.controller('simuladorOSController', function($q, $compile, $scope, $timeout, $rootScope, $interval, ngDialog, modalService, generalService, generalServiceOS, authService, callCenterService,
		clienteUnicoService, solicitudService, buroService, messageData, sessionService, securityService, validateService, documentosService, loginService, obligadoSolidarioService) {

		generalService.setDataBridge(null);
		generalService.buildSolicitudOSJson($rootScope, null);
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		
		$scope.opcionElegidaIdComplementaria = false;
		$rootScope.marcaIdComplementaria = false;
		$rootScope.seleccionIDComplementaria = false;
		
		$scope.nAnno = null;
		$scope.nMes = null;
		$scope.nDia = null;
		$scope.correoInvalido = true;
		var cusArray = null;
		
		var dd = "";
		var mm = "";
		var aaaa = "";
		var yyyy = "";
		var yy75 = "";
		var fechaDia = "";
		var fechaDia1 = "";
		var edadMinima = "";
		var edadMaxima = "";
		var etiquetaFrente = "";
		var etiquetaReverso = "";
		var codigoRespuestaHomonimos = null;
		var contadorCel = 0;
		var tipoCredencialSeleccionado;


		/** Incializa el método INIT **/
		$scope.init = function() {
			/*\Se agrega un evento para la bitacora\*/
//			(Coacreditado)
			$rootScope.addEvent( BITACORA.SECCION.coacreditado.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, 0, BITACORA.SECCION.coacreditado.guardarEnBD );
			
			/*\Se agrega un evento para la bitacora\*/
			
			contadorCel = 0;
			
			$scope.showPage = false;
			$scope.bandCE = false;
			$scope.respCE = "";
			$scope.menCE = "Captura la clave de elector";

			/** Para el OCR oblgatorio se deja por si el requerimiento lo pide, de lo contrario quitar estas validaciones **/
			try {
				$scope.ocrRequired = $rootScope.consultaFuncionalidad.ocrobligatorio;
			} catch (x) {
				$scope.ocrRequired = false;
			}

			/** Para el OCR oblgatorio se deja por si el requerimiento lo pide, de lo contrario quitar estas validaciones **/
			if ($scope.ocrRequired) 
				$scope.bloqueaINEPass = true;
			 else 
				$scope.bloqueaINEPass = false;
			
			/** Esta bandera siempre nace en true, los campos de entrada estan bloqueadas. **/
			$scope.bloqueaInput = true;
			
			if (messageData) {
				var continuar = false;
				
				$scope.obligarAvisos();
				$scope.isTienda = configuracion.origen.tienda;
				$scope.checkAvisos = $rootScope.solicitudOSJson.aceptaTerminos;
				$scope.vistaSimulador = configuracion.simulador.opcion;
				$scope.vistaDatosUsuario = configuracion.datosUsuario.opcion;
				
				/** Invoca la función para cargar la vista de la página **/
				$scope.cargapagina();

				/** Inicia time out para extraer la descripción del genero, además de inicializar día, mes, año **/
				$timeout(function() {
					if ($rootScope.solicitudOSJson.cotizacion.clientes[0].idGenero != "F" || $rootScope.solicitudOSJson.cotizacion.clientes[0].idGenero != "M")
						$rootScope.solicitudOSJson.cotizacion.clientes[0].idGenero = "";

					if (!parseInt($scope.nDia))
						$scope.nDia = "";
					if (!parseInt($scope.nMes))
						$scope.nMes = "";
					if (!parseInt($scope.nAnno))
						$scope.nAnno = "";

					$scope.showPage = messageData;
				}, 0);
			}
			
			// Variable para forzar la selección de un tipo de credencial.
			tipoCredencialSeleccionado = false;
			$scope.anioRegistroID = "";
		};
		
		$scope.check1SolicitarModel = false;
		$scope.check2SolicitarModel = false;
		$scope.esObligatorio = true;
		$scope.validarApellidos = function(parametro){
			if($rootScope.faseGeneraRechazo == 1 || $rootScope.faseGeneraReactivado == 1 || $rootScope.faseGeneraMigracionSuc == 1){
				$scope.check1SolicitarModel = false;
				$scope.check2SolicitarModel = false;
				$scope.esObligatorio = false;
			}else{
				if(parametro == 1){
					$scope.check1SolicitarModel = ($scope.check1SolicitarModel == false);
					
					if($scope.check1SolicitarModel){
						$rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno = "";
						$scope.deshabilitarMaterno = true;
						$scope.manejoErroresMaterno = false;
						
						if($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno.length > 0){
							$scope.esObligatorio = false;
							$scope.forSimulador.$invalid = false;
						}else{
							$scope.esObligatorio = true;
							$scope.forSimulador.$invalid = true;
						}
					}else{
						$scope.deshabilitarMaterno = false;
						$scope.manejoErroresMaterno = true;
						
						if($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno.length > 0 && $rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno.length > 0){
							$scope.esObligatorio = false;
							$scope.forSimulador.$invalid = false;
						}else{
							$scope.esObligatorio = true;
							$scope.forSimulador.$invalid = true;
						}
					}
					
				}else if(parametro == 2){
					$scope.check2SolicitarModel = ($scope.check2SolicitarModel == false);
					
					if($scope.check2SolicitarModel){
						$rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno = "";
						$scope.deshabilitarPaterno = true;
						$scope.manejoErroresPaterno = false;
						
						if($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno.length > 0){
							$scope.esObligatorio = false;
							$scope.forSimulador.$invalid = false;
						}else{
							$scope.esObligatorio = true;
							$scope.forSimulador.$invalid = true;
						}
					}else{
						$scope.deshabilitarPaterno = false;
						$scope.manejoErroresPaterno = true;
						
						if($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno.length > 0 && $rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno.length > 0){
							$scope.esObligatorio = false;
							$scope.forSimulador.$invalid = false;
						}else{
							$scope.esObligatorio = true;
							$scope.forSimulador.$invalid = true;
						}
					}
				}
			}
			
			$scope.validaApellidos($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno, $rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno, 0, 3);
		}
		

		$scope.obligarAvisos = function() {
			if ($rootScope.solicitudOSJson.aceptaTerminos == 0) {
				/** La sucursal demanda el OCR como obligatorio**/
				if ($scope.ocrRequired){
					$scope.bloqueaINEPass = true;
				}else{ 
					$scope.bloqueaInput = true;
				}					
			} else {
				/** La sucursal tiene el OCR obligatorio. **/
				if ($scope.ocrRequired) {
					$scope.bloqueaINEPass = false;
				
					/** Es web. No hay botón de OCR. **/
					//if (!$scope.isTienda) 
						$scope.bloqueaInput = false;
				} else 
					$scope.bloqueaInput = false;
			}
		};

		/** Carga la página **/
		$scope.cargapagina = function() {
			if ($rootScope.solicitudJson.idSolicitud == '' && !generalService.getArrayValue("solicitudRecuperada")){
				generalService.buildSolicitudOSJson($rootScope, null);
				$rootScope.fotoOS = "data:image/png;base64,"+$rootScope.imgUsuario;
				$rootScope.cp = "";
				
			}
			//generalService.buildSolicitudJson($rootScope, null);
			$scope.vistaSimulador = configuracion.simulador.opcion;
			$scope.vistaDatosUsuario = configuracion.datosUsuario.opcion;


			if (configuracion.origen.tienda)
				$scope.origen = "TIENDA";
			else
				$scope.origen = "WEB";

			$scope.ID_PRODUCTO = ID_PRODUCTO;
			$scope.titulo = generalService.getDataInput("SIMULADOR", "TITULO", $scope.origen);
			$scope.nombre = generalService.getDataInput("SIMULADOR", "NOMBRE", null);
			$scope.aPaterno = generalService.getDataInput("SIMULADOR", "APELLIDO PATERNO", null);
			$scope.aMaterno = generalService.getDataInput("SIMULADOR", "APELLIDO MATERNO", null);
			$scope.genero = generalService.getDataInput("SIMULADOR", "GENERO", null);
			$scope.celular1 = generalService.getDataInput("SIMULADOR", "CELULAR", null);
			$scope.telefonoCasaOS = generalService.getDataInput("SIMULADOR", "CELULAR", null);
			$scope.correo = generalService.getDataInput("SIMULADOR", "CORREO", null);
			$scope.mDia = generalService.getDataInput("SIMULADOR", "DIA NACIMIENTO", null);
			$scope.mMes = generalService.getDataInput("SIMULADOR", "MES NACIMIENTO", null);
			$scope.mAnio = generalService.getDataInput("SIMULADOR", "ANIO NACIMIENTO", null);
			$scope.terminosCondiciones = generalService.getDataInput("SIMULADOR", "TERMINOS Y CONDICIONES", $scope.origen);
			$scope.digitalizar = generalService.getDataInput("SIMULADOR", "TEXTO DIGITALIZAR", "VALOR");
			$scope.etiquetaDatos = generalService.getDataInput("SIMULADOR", "ETIQUETA DATOS", $scope.origen);
			$scope.etiquetaNacimiento = generalService.getDataInput("SIMULADOR", "ETIQUETA NACIMIENTO", $scope.origen);
			$scope.pagoRequerido = generalService.getDataInput("SIMULADOR", "PAGO REQUERIDO", $scope.origen);
			$scope.folioIdent = generalService.getDataInput("DATOS BASICOS", "FOLIO IDENTIFICACION", $scope.origen);
			$scope.claveElector = generalService.getDataInput("DATOS BASICOS", "CLAVE ELECTOR", $scope.origen);
			$scope.btnDigitalizar = generalService.getDataInput("SIMULADOR", "BOTON DIGITALIZAR", $scope.origen);
			$scope.btnSolicitar = generalService.getDataInput("SIMULADOR", "BOTON SOLICITAR", $scope.origen);
			$scope.lugarNacimiento = generalService.getDataInput("DATOS BASICOS", "LUGAR NACIMIENTO", null);
			$scope.generos = generalService.construirCatalogoIdString("CATALOGO GENERO");
			$scope.lugaresNacimiento = generalService.construirCatalogo("CATALOGO ESTADOS");
			$scope.folioIdent.deshabilitado = $scope.claveElector.deshabilitado;
			$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";
			edadMinima = generalService.getDatafromCategory("SIMULADOR", "EDAD MINIMA", "VALOR.valor");
			edadMaxima = generalService.getDatafromCategory("SIMULADOR", "EDAD MAXIMA", "VALOR.valor");
			etiquetaFrente = generalService.getDatafromCategory("SIMULADOR", "ETIQUETA FRENTE", "VALOR.valor");
			etiquetaReverso = generalService.getDatafromCategory("SIMULADOR", "ETIQUETA REVERSO", "VALOR.valor");
			
			$scope.valueAnioRegistro = true;
			$scope.valueNumEmision = true;
			
			/** Carga el arreglo para la fecha de nacimiento tomando en cuenta la edad miníma y edad maxima **/
			fechaDia = new Date();
			
			yyyy = new Date().getFullYear() - edadMinima;
			yy75 = new Date().getFullYear() - edadMaxima;
			
			fechaDia1 = new Date();
			
			aaaa = fechaDia.getFullYear();
			dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
			mm = ((fechaDia.getMonth() + 1) < 10 ? '0' : '') + (fechaDia.getMonth() + 1);
			
			$scope.days = dias;
			$scope.months = meses;
			$scope.years = [];
			
			for (var i = (new Date().getFullYear() - edadMinima); i >= new Date().getFullYear() - 75; i--)
				$scope.years.push("" + i);
		};

		/** Valida unicamente los días cada vez que se selecciona una fecha**/
		$scope.validadias = function(dia) {
			if (!dia) {
				var vAnno = "";
				var vMes = "";
				$scope.vDia = $scope.nDia;
				if (parseInt($scope.nMes) && parseInt($scope.nAnno)) {
					vAnno = $scope.nAnno;
					vMes = $scope.nMes;
					$scope.aniobisiesto(vAnno, vMes);
					$scope.nDia = $scope.vDia;
				}
			}
			
			/** Valida los día seleccionado para agregar el formato correcto **/
			if (parseInt($scope.nDia) && parseInt($scope.nMes) && parseInt($scope.nAnno))
				$rootScope.solicitudOSJson.cotizacion.clientes[0].fechaNaciomiento = $scope.nDia + "/" + $scope.nMes + "/" + $scope.nAnno;

		};

		/** Valida cuando el año es biciesto **/
		$scope.aniobisiesto = function(vAnno, vMes) {
			$scope.days = [];
			if ((vAnno % 4 == 0) && ((vAnno % 100 != 0) || (vAnno % 400 == 0))) {
				if (vMes == "02") {
					$scope.days = dias.slice(0, 29);
					if ($scope.vDia > "29")
						$scope.vDia = "29";
				}
			} else {
				if (vMes == "02") {
					$scope.days = dias.slice(0, 28);
					if ($scope.vDia > "28")
						$scope.vDia = "28";
				}
			}
			if (vMes == "04" || vMes == "06" || vMes == "09" || vMes == "11") {
				$scope.days = dias.slice(0, 30);
				if ($scope.vDia > "30")
					$scope.vDia = "30";
			}
			if (vMes == "01" || vMes == "03" || vMes == "05" || vMes == "07" || vMes == "08" || vMes == "10" || vMes == "12")
				$scope.days = dias;
		};

		/** Dependiendo del apellido que se introduzca, se hace obligatorio uno y el otro opcional **/
		$scope.validaApellidos = function(aPaterno, aMaterno, origen, tipo){
	 		var validaXPaterno = false;
	 		var validaXMaterno = false;
	 		
	 		if($rootScope.faseGeneraRechazo == 1 || $rootScope.faseGeneraReactivado == 1 || $rootScope.faseGeneraMigracionSuc == 1){
	 			$scope.check1SolicitarModel = true;
				$scope.check2SolicitarModel = true;
				$scope.manejoErroresMaterno = false;
				$scope.manejoErroresPaterno = false;
				$scope.esObligatorio = false;
			}else{
		 		if(aPaterno != undefined && aPaterno.length >= 1){
		 			if(aPaterno.length >= 2 && aPaterno[0] == "X" && aPaterno[1] == "X"){
		 				$scope.manejoErroresPaterno = true;
		 				$scope.esObligatorio = true;
						$scope.forSimulador.$invalid = true;
						validaXPaterno = true;
		 			}else{
		 				if(!$scope.check1SolicitarModel && !$scope.check2SolicitarModel){
		 					if($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno.length > 0 && $rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno.length > 0){
				 				$scope.esObligatorio = false;
				 				$scope.forSimulador.$invalid = false;
				 				$scope.manejoErroresPaterno = false;
		 					}else{
				 				$scope.esObligatorio = true;
				 				$scope.forSimulador.$invalid = true;
		 					}
		 				}else{
		 					if($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno.length > 0){	
				 				$scope.esObligatorio = false;
				 				$scope.forSimulador.$invalid = false;
				 				$scope.manejoErroresPaterno = false;
		 					}else{
				 				$scope.esObligatorio = true;
				 				$scope.forSimulador.$invalid = true;
		 					}	
		 				}
		 			}
		 		}else if($scope.check1SolicitarModel){
		 			$scope.manejoErroresPaterno = true;
	 				$scope.esObligatorio = true;
					$scope.forSimulador.$invalid = true;
		 		}
		 		
		 		if(aMaterno != undefined && aMaterno.length >= 1){
		 			if(aMaterno.length >= 2 && aMaterno[0] == "X" && aMaterno[1] == "X"){
		 				$scope.manejoErroresMaterno = true;
		 				$scope.esObligatorio = true;
						$scope.forSimulador.$invalid = true;
						validaXMaterno = true;
		 			}else{
		 				if(!$scope.check1SolicitarModel && !$scope.check2SolicitarModel){
		 					if($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno.length > 0 && $rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno.length > 0){	
				 				$scope.esObligatorio = false;
				 				$scope.forSimulador.$invalid = false;
				 				$scope.manejoErroresMaterno = false;
		 					}else{
				 				$scope.esObligatorio = true;
				 				$scope.forSimulador.$invalid = true;
		 					}
		 				}else{
		 					if($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno.length > 0){	
				 				$scope.esObligatorio = false;
				 				$scope.forSimulador.$invalid = false;
				 				$scope.manejoErroresMaterno = false;
		 					}else{
				 				$scope.esObligatorio = true;
				 				$scope.forSimulador.$invalid = true;
		 					}	
		 				}
		 			}
		 		}else if($scope.check2SolicitarModel){
		 			$scope.manejoErroresMaterno = true;
	 				$scope.esObligatorio = true;
					$scope.forSimulador.$invalid = true;
		 		}
		 		
		 		if($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno != undefined && $rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno.length > 0 && tipo == 1 && !validaXPaterno){
 					$scope.manejoErroresPaterno = false;
 				}else if(($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno == undefined || $rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno == "") && origen == 1 && tipo == 1){
 					$scope.manejoErroresPaterno = true;
 				}else if($scope.forSimulador.apPaterno.$touched && tipo == 1){
 					$scope.manejoErroresPaterno = true;
 				}
 				
 				if($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno != undefined && $rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno.length > 0 && tipo == 2 && !validaXMaterno){
 					$scope.manejoErroresMaterno = false;
 				}else if(($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno == undefined || $rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno == "") && origen == 1 && tipo == 2){
 					$scope.manejoErroresMaterno = true;
 				}else if($scope.forSimulador.apMaterno.$touched && tipo == 2){
 					$scope.manejoErroresMaterno = true;
 				}
 				
 				if(!$scope.check1SolicitarModel && !$scope.check2SolicitarModel && (validaXPaterno || validaXMaterno)){
 					$scope.esObligatorio = true;
					$scope.forSimulador.$invalid = true;
 				}
 				
 				if($scope.forSimulador.nombre.$invalid || $scope.forSimulador.apPaterno.$invalid || $scope.forSimulador.apMaterno.$invalid || $scope.forSimulador.genero.$invalid || $scope.forSimulador.lugarNacimiento.$invalid || $scope.forSimulador.celular.$invalid || $scope.forSimulador.nDia.$invalid || $scope.forSimulador.nMes.$invalid || $scope.forSimulador.nAnno.$invalid){
 					$scope.forSimulador.$invalid = true;
 				}
			}
	 	}

		/** Invoca el componente para realizar OCR **/
		$scope.ocrIFE = function(response) {
			/*\Se agrega un evento para la bitacora\*/
			//(coacreditado)
				$rootScope.addEvent( BITACORA.SECCION.coacreditado.id, BITACORA.SUBSECCION.capturaFotoCoacreditado.id, BITACORA.ACCION.iniciarDigitalizacion.id, 0, BITACORA.SECCION.coacreditado.guardarEnBD );
			
			/*\Se agrega un evento para la bitacora\*/
			
				//Se mandan a BD los eventos almacenados en memoria
				$rootScope.enviaEventos();	
				
			if ($scope.isTienda) {
				if ($scope.doctoIdentificacion == 'ine') {
					try {
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						$rootScope.aplicarOCR_IFE('ocrDiv', 'respuestaComponente');
			

					} catch (e) {
						modalService.alertModal("Error al capturar imagen", [ e ], null, null, null);
					}
				}
			}
		};
		
		$scope.getClassRadioButton = function() {
			return "css-greenS-custom";
		}
		
		$scope.getClassLabel = function() {
			return "css-label-greenS-custom";
		}
		
		
		/**
		 * Función para validar que todos los datos ingresados para el COACREDITADO sean correctos. 
		 * AQUÍ SE MANDA A LLAMAR LA FUNCIÓN QUE EJECUTA EL SERVICIO DE LA BUSQUEDA DE HOMONIMOS PARA EL 
		 * COACREDITADO
		 */
		
		$scope.consultaHomonimo=function(){
			var fechaSel = $scope.nAnno + "/" + $scope.nMes + "/" + $scope.nDia;
			var fechaMin = yy75 + "/" + mm + "/" + dd;
			if (($scope.nAnno == yyyy && $scope.nMes > mm) || ($scope.nAnno == yyyy && $scope.nMes == mm && $scope.nDia > dd)){										
				$rootScope.message( "Datos inválidos", ["El cliente no cumple con la edad mínima requerida por las políticas internas, por lo cual, no es posible continuar con el proceso."] , "Aceptar", null, null, "botonSimulador",null,"GENERAL","EDAD MINIMA");
				$scope.endCotizador = false;
			}else{
				if (fechaSel <= fechaMin){										
					$rootScope.message( "Datos inválidos", ["El cliente supera la edad máxima definida en las políticas internas, por lo cual, no es posible continuar con el proceso."] , "Aceptar", null, null, "botonSimulador",null,"GENERAL","EDAD MAXIMA");
					$scope.endCotizador = false;
				}else{
					$scope.endCotizador = true;
					
					$rootScope.solicitudOSJson.cotizacion.clientes[0].fechaNaciomiento=$scope.nDia + "/" + $scope.nMes + "/" + $scope.nAnno;
					generalService.calculaPorcentaje($rootScope)
					
					$rootScope.solicitudOSJson.tipoCampania = CASO_CELULAR;
					
					if (CASO_CELULAR == 3){
						$rootScope.solicitudOSJson.envioCelular = 1;
					}
					
					if (!$scope.celular1.valor && CASO_CELULAR != 1){
						modalService.telefonoModal(CASO_CELULAR).then(
							function(exito) {
								$scope.celular1.valor = $rootScope.solicitudOSJson.cotizacion.clientes[0].celular;
								$timeout( function(){ 
						 			$scope.homonimosObligadoSolidario();
						 		}, 100);
							}, function(error) {
								$scope.celular1.valor = $rootScope.solicitudOSJson.cotizacion.clientes[0].celular;
								$timeout( function(){ 
						 			$scope.homonimosObligadoSolidario();
						 		}, 100);
							}
						);
					}else{
						$scope.homonimosObligadoSolidario();
					}
				}
			}
		};
		
		
		/**
		 * SE IMPLEMENTA SEL SERVICIO DE BÚSQUEDA DE HOMÓNIMOS PARA EL COACREDITADO
		 */
		$scope.homonimosObligadoSolidario = function(){
			$scope.nombreIncorrecto = false;
			$scope.apPatIncorrecto = false;
			$scope.apMatIncorrecto = false;
			$scope.clvEIncorrecto = false;
			$scope.folioIncorrecto = false;
			$scope.numEmisionIncorrecto = false;
			
			$scope.endCotizador = true;
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
			validateService.limpiaMascaras();						
			
			var tipoBus=TIPO_BUSQUEDA;
			
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) != -1 || !isProduccion)
				tipoBus='1';
			
			$scope.respaldoOSJson = $rootScope.solicitudOSJson
			$scope.respaldoJson = $rootScope.solicitudOSJson
			
			if($rootScope.solicitudOSJson.cotizacion.clientes[0].genero == ""){
				switch($rootScope.solicitudOSJson.cotizacion.clientes[0].idGenero){
					case 'F': 
						$rootScope.solicitudOSJson.cotizacion.clientes[0].genero = $scope.getDescripcionCatalogo('F',$scope.generos);
					break;
					case 'M': 	 					
						$rootScope.solicitudOSJson.cotizacion.clientes[0].genero = $scope.getDescripcionCatalogo('M',$scope.generos);
					break;
				}
			}
			
			$rootScope.solicitudOSJson.aceptaConsultaBuro = 1;
			$rootScope.solicitudOSJson.idProducto = $rootScope.solicitudJson.idProducto;
			
			if($scope.doctoIdentificacion == 'ine'){
				$rootScope.solicitudOSJson.tipoIdentificacion = 1;
			}else if($scope.doctoIdentificacion == 'passport'){
				$rootScope.solicitudOSJson.tipoIdentificacion = 2;
			}
			
			var b64FirmaAvisoOS = $rootScope.imgPrivacidadOS.replace("data:image/png;base64,", "").trim();
			
			var x = {
					solicitudOSJson: JSON.stringify($scope.respaldoOSJson),
					idSolicitudCliente : $rootScope.solicitudJson.idSolicitud,
					huella: "",
					tipoBusqueda: tipoBus, /*CU FONETICA, 2 -> 360 :   1: CU*/
					terminal: $rootScope.sucursalSession.terminalBancaria.trim(),
					nombreSucursal: $rootScope.sucursalSession.nombreSucursal, 
					tipoIdentificacion: $scope.doctoIdentificacion == 'ine' ? '1' : '2',
				    statusOcr: 0, 
				    folioDigitalizacion: $rootScope.folioDigitalizacion != undefined ? $rootScope.folioDigitalizacion : "",
				    firmaAvisoOS: b64FirmaAvisoOS ? b64FirmaAvisoOS : "",
				    envioBody: true
				}
			
			if($scope.doctoIdentificacion == 'ine' && $scope.ocrIfeNew != $scope.ocrIfeOld && $rootScope.solicitudOSJson.banderaOCR==1) {
				x.statusOcr = 2;
			}
			
			if($rootScope.solicitudOSJson.banderaOCR==1 && $scope.doctoIdentificacion == 'ine' && $scope.ocrIfeNew == $scope.ocrIfeOld) {
				x.statusOcr = 1;
			}
			
			if($rootScope.solicitudOSJson.banderaOCR==0 && $scope.doctoIdentificacion == 'ine') {
				x.statusOcr = 0;
			}
			
			obligadoSolidarioService.busquedaHomonimosOS( x ).then(
				function(data){
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
							
						var j = JSON.parse(data.data.respuesta);
	
						switch(j.codigo){
							case 2:						
								configuracion.estatus.opcion=0;
														
								j.data.cotizacion.clientes[0].nombre = j.data.cotizacion.clientes[0].nombre.replace("\.","");;
								j.data.cotizacion.clientes[0].apellidoPaterno = j.data.cotizacion.clientes[0].apellidoPaterno.replace("\.","");;
								j.data.cotizacion.clientes[0].apellidoMaterno = j.data.cotizacion.clientes[0].apellidoMaterno.replace("\.","");;
					
								j.data.cotizacion.clientes[0].nombre = j.data.cotizacion.clientes[0].nombre.replace("-"," ");
								j.data.cotizacion.clientes[0].apellidoPaterno = j.data.cotizacion.clientes[0].apellidoPaterno.replace("-"," ");
								j.data.cotizacion.clientes[0].apellidoMaterno = j.data.cotizacion.clientes[0].apellidoMaterno.replace("-"," ");

								$rootScope.solicitudOSJson = j.data;
								$rootScope.fotoOS = "data:image/png;base64," + $rootScope.imgUsuario;
								continuarHomonimosCodigoDos();
								break;
								
							case 307:
								$scope.endCotizador = false;
								cusArray = new Array();		
								var cusArrayHuella=new Array();
								var tieneHuella = false;									
								
								angular.forEach( j.data, function(cu_huella){
									cusArray.push(cu_huella.cu);
									
									if(cu_huella.huella == 1){
										cusArrayHuella.push(cu_huella.cu);
										tieneHuella = true;		
									}
								});
						
								if(tieneHuella){
									codigoRespuestaHomonimos = j.codigo;
									validaHuella(cusArrayHuella);
								}else{
									flujoCallCenter();
								}
								
								break;
							case 351:
								/** Limpiar el formulario **/
								clearForm();
								$rootScope.message("Aviso ", ["Tu candidato no puede ser Coacreditado de tu crédito debido a que cuenta con una solicitud MOC en proceso"],"Aceptar");
								break;
							case 352:
								/** Limpiar el formulario **/
								clearForm();
								$rootScope.message("Aviso ", ["Tu candidato no puede ser Coacreditado de tu crédito debido a que ya esta ligado con otro cliente"],"Aceptar");
								break;
							case 354:
								/** Limpiar el formulario **/
								clearForm();
								$rootScope.message("Aviso ", ["Tu candidato no puede ser Coacreditado de tu crédito debido a que cuenta con una solicitud MOC en proceso"],"Aceptar");
								break;
							case 355:
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message("Aviso ", ["Cliente agotó sus oportunidades para tener un Coacreditado"],"Aceptar","/menuWrapper");
								break;
							case 356:
							case 357:
								/** Limpiar el formulario **/
								clearForm();
								$rootScope.message("Aviso ", ["Tu candidato no puede ser Coacreditado de tu crédito debido a que ya esta ligado con otro cliente"],"Aceptar");
								break;
							case 358:
							case 359:
								/** Limpiar el formulario **/
								clearForm();
								$rootScope.message("Aviso ", ["Tu candidato no puede ser Coacreditado de tu crédito debido a que cuenta con una solicitud MOC en proceso"],"Aceptar");
								break;
							case 661:
								clearForm();
								$rootScope.message("Aviso ", ["Por favor verifica los datos de tu Coacreditado debido a que no se encuentra en el Registro Nacional de Población."],"Aceptar",null,null,null,null);
								break;
							case 663:
								$rootScope.message("Aviso ", ["Por favor, verifíca los datos de tu Coacreditado ya que estos no se encuentran en el registro del Instituto Nacional Electoral."],"Aceptar",null,null,null,null);
								break;
							case 666:
								validarDatosErroneos(j.data);
								break;
							case 667:
								$rootScope.message( "Aviso",["¨Por favor, verifica que la clave de elector y la fecha de nacimiento del Coacreditado estén capturadas correctamente"], "Aceptar");
								break;
							case 912:
								clearForm();
								$rootScope.message("Aviso ", ["Por políticas internas no es posible continuar con el proceso"],"Aceptar",null,null,null,null);
								break;
							default:	
								/** Limpiar el formulario **/
								clearForm();
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message( "Error inesperado Código [" + j.codigo + "] no identificado", ["Detalle del error: " + j.descripcion], "Aceptar");
							break;
						}	
					}else{
						$rootScope.waitLoaderStatus = LOADER_HIDE;
					}
				}, function(error){						
					$rootScope.waitLoaderStatus = LOADER_HIDE;
				}
			);
	 	};
		
	 	/**
	 	 * Función que invoca cuando el servicio de homonimos, responde con un código 2 y ya se valido promociones BUEN FIN
	 	 **/
	 	function continuarHomonimosCodigoDos(){
	 		/**
			 * Se valida que sea INE y que se haya hecho OCR además de que ocrIfeNew sea igual a ocrIfeOld para detectar la edicion de datos
			 * sino hubo edicion la solicitud continua de manera normal y se envia a 8 pasos de lo contrario se envia a CallCenter 
			 * TODAS LAS SOLICITUDES QUE TENGAN COMO IDENTIFICACION OFICIAL EL PASAPORTE SE VAN A IR POR FLUJO DE CALLCENTER
			 */
			if($rootScope.consultaFuncionalidad.flujoMesaAltaUnica && TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) == -1) {
				if( $scope.doctoIdentificacion == 1 || $scope.doctoIdentificacion == 3) {
					if(($rootScope.solicitudOSJson.banderaOCR==0 && $scope.doctoIdentificacion == 1) || ($rootScope.solicitudOSJson.banderaOCR==1 && $scope.ocrIfeNew == $scope.ocrIfeOld) || $scope.doctoIdentificacion == 3) {
						$scope.agregarIdentificacionOficial("/ochoPasosOS", 0);
					} else {
						flujoCallCenter();
					}
				} else {
					flujoCallCenter();
				}
		    } else {
		    		$scope.agregarIdentificacionOficial("/ochoPasosOS");
		    }
	 	}
	 	
	 	/**
		 * SERVICIO PARA VERIFICAR EL STATUS DE LA LCR PARA EL FLUJO DEL COACREDITADO
		 */
		function consultarSatusLCR(ctesUnicosArray) { // DATOS HOMONIMOS
		$rootScope.waitLoaderStatus = LOADER_SHOW; 
		
		//SE RECIBE COMO PARÁMETRO EL JSON DE LA SOLICITUD DEL COACREDITADO
		var clientes = JSON.stringify(ctesUnicosArray).split("\[").join("").split("\]").join("").split("\"").join("");
		$scope.respaldoOSJson.marca = STATUS_SOLICITUD.generada.marca.nuevaOriginacion;
		var requestJson = {
				tienda: $rootScope.sucursalSession.idSucursal,
				arrayCtesUnicos: clientes,
				idSolicitudCliente: $rootScope.solicitudJson.idSolicitud,
				solicitudOSJson: JSON.stringify($scope.respaldoOSJson)
		};

		obligadoSolidarioService.getHomonimosOS(requestJson).then(
				function(data) {
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						switch (jsonResponse.codigo) {
						case 315:
						case 314:
						case 316:
							generalService.homonimosData=jsonResponse;
							generalService.locationPath("/homonimosOS");
							break;
						case 337:
							/** Limpiar el formulario **/
							clearForm();
							$rootScope.message("Aviso ", [" Tu candidato no puede ser Coacreditado de tu crédito debido a que presenta atraso en su linea de crédito"], "Aceptar");
							break;
						case 312:
							/** Limpiar el formulario **/
							clearForm();
							$rootScope.message("Aviso ", ["No es posible realizar el registro de tu candidato para ser Coacreditado,","ya que tiene una solicitud de línea de crédito pendiente de liberar"], "Aceptar");
							break
						case 313:
							/** Limpiar el formulario **/
							clearForm();
							$rootScope.message("Aviso ", ["No es posible realizar el registro de tu candidato para ser Coacreditado,","ya que tiene una solicitud pendiente de investigar"], "Aceptar");
							break;
						case 317:
							/** Limpiar el formulario **/
							clearForm();
							$rootScope.message("Aviso ", [" Tu candidato no puede ser Coacreditado de tu crédito debido a que una Línea de Crédito cancelada"], "Aceptar");
							break;
						case 321:
							/** Limpiar el formulario **/
							clearForm();
							$rootScope.message("Aviso ", [" Tu candidato no puede ser Coacreditado de tu crédito debido a que se detectó que es un empleado"], "Aceptar");
							break;
						case 350:
							/** Limpiar el formulario **/
							clearForm();
							$rootScope.message("Aviso ", [" Tu candidato no puede ser Coacreditado de tu crédito debido a que se detectó que ya es Coacreditado"], "Aceptar");
							break;
						case 311:
							/** Limpiar el formulario **/
							clearForm();
							$rootScope.message("Aviso ", [" Tu candidato no puede ser Coacreditado de tu crédito debido a que presenta un bloqueo en su linea de crédito"], "Aceptar");
							break;
						case 320:
							/** Limpiar el formulario **/
							clearForm();
							$rootScope.message("Aviso ", [" Tu candidato no puede ser Coacreditado de tu crédito debido a que presenta un bloqueo en su linea de crédito por Presta Prenda"], "Aceptar");
							break;
						case 333:
							/** Limpiar el formulario **/
							clearForm();
							$rootScope.message("Aviso ", [" Tu candidato no puede ser Coacreditado de tu crédito debido a que ya tiene ligado un producto Presta Prenda"], "Aceptar");
							break;
						case 319:
							/** Limpiar el formulario **/
							clearForm();
							$rootScope.message("Error ", [" Ha ocurrido un error al consultar los homónimos "], "Aceptar");
							break;
						case 308:
							/** Limpiar el formulario **/
							clearForm();
							$rootScope.message("Aviso ", [" Ha ocurrido un error al invocar el servicio de cliente único "], "Aceptar");
							break;
							default:
								/** Limpiar el formulario **/
								clearForm();
								$rootScope.loggerIpad("Respuesta Servicio validarStatusLCR", generalService.displayMessage(data.data.descripcion));
								$rootScope.message("Error " + jsonResponse.codigo, ["Hemos detectado un error favor de reitentar"], "Aceptar");
								break;
								
						}
						
					} else {
						/** Limpiar el formulario **/
						clearForm();
						$rootScope.loggerIpad("Respuesta Servicio validarStatusLCR", generalService.displayMessage(data.data.descripcion));
						$rootScope.message("Error " + data.data.codigo, [generalService.displayMessage(data.data.descripcion)], "Aceptar");
					}
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE; 
				}
		);
	};
	
	/** Limpar el formulario sin recargar el controller 
	 *  Esconde el spinner.
	 *  Limpia el rootScope pero solo para el Coacreditado
	 *  Construye buevamente el JSON del Coacreditado
	 *  Se invoca nuevamente el init para aplicar la configuración unicial del controller
	 *  Limpia el formulario nuevamente
	 *  Quita los estilos creados por el ontouch
	 *  Quita los estilos creados por el ontouch  
	**/
	var clearForm = function(){
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		generalServiceOS.cleanRootScopeOS();
		generalServiceOS.buildSolicitudOSJson($rootScope, null);
		$scope.init();
		$scope.limpiarDatosOCR();
		$scope.forSimulador.$setPristine();
		$scope.forSimulador.$setUntouched();
	}
	
	var actualizaMarcaSol = function(jsonActualizaMarca){
		solicitudService.actualizaMarca(jsonActualizaMarca).then(
			function(data){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(data.data.codigo == RESPONSE_CODIGO_EXITO){
					$rootScope.message("Aviso ", ["Infórmale a tu cliente que ya cuenta con una línea de crédito, por lo cual, no es posible continuar con la solicitud.",
						"Cliente Único: " + jsonActualizaMarca.cu], "Aceptar", "/", null, null, null);
				} else {
					$rootScope.loggerIpad("Respuesta Servicio actualizaMarca", generalService.displayMessage(data.data.descripcion));
					$rootScope.message("Error " + data.data.codigo, [generalService.displayMessage(data.data.descripcion)], "Aceptar");
				}								
			}, function(error){
                $rootScope.waitLoaderStatus = LOADER_HIDE; 
                $rootScope.message("Aviso ", ["Infórmale a tu cliente que ya cuenta con una línea de crédito, por lo cual, no es posible continuar con la solicitud.",
                	"Cliente Único: " + jsonActualizaMarca.cu], "Aceptar", "/", null, null, null);
			}
		);
	}
		
		
		/** Respuesta del componente del OCR **/
		$scope.respuestaComponente = function(response) {
	 		// Se realiza la limpieza previa, para quitar "residuos" de una ejecución anterior.
			$scope.limpiarDatosOCR();
	 		
	 		if(typeof response !== "undefined") {
	 			// Se realiza una transformada de ¿whiplash? para lograr que se pinte los datos extraídos. 
		 		if(typeof response.persona !== "undefined") {
		 			response.mensaje = response.persona;
		 		}

		 		// ¿Qué trajo el viento?
		 		$rootScope.loggerIpad("respuestaComponente", null, response);
	 			
	 			// El componente pudo extraer datos.
		 		if(response.codigo == 0) {
		 			// Si trae una Ñ, por el encoding, hay que realizar el cambio.
			 		response = JSON.parse(JSON.stringify(response).replace(/Ã‘/g, "Ñ"));
		 			
		 			// Variable para una posible fecha de nacimiento.
		 			var possibleBday;
		 			
		 			// Variable que funciona como marca si no se encuentra alguna propiedad.
		 			var notFound = "not found!"
		 			
		 			// Estructura JSON para ir colocando los campos que se evalúan.
		 			var extractedData = {
		 				vigencia: "",
		 				nombre: "",
		 				patronimico: "",
		 				matronimico: "",
		 				folioCentral: "",
		 				calle: "",
		 				cp: "",
		 				genero: "",
		 				fechaNacimiento: "",
		 				curp: "",
		 				claveElector: "",
		 				folioIdentificacion: "",
		 				colonia: ""
		 			};
		 			
		 			try {
		 				// Se tiene un objeto persona.
			 			if(typeof response.persona !== "undefined") {
			 				// Alguna respuesta trae un JSON hecho cadena, así que hay que parsearlo.
			 				if(typeof response.persona === "string") {
			 					// Se quita el primer caracter si no es una llave; es un parásito.
			 					if(response.persona.length > 1 && response.persona[0] != "{") {
			 						response.persona = response.persona.substring(1);
			 					}
			 					
			 					// Se parsea el JSON.
			 					response.persona = JSON.parse(response.persona);
			 				}
			 				
			 				// Extrayendo el año de vigencia.
			 				if(typeof response.persona.anioVigencia !== "undefined") {
			 					extractedData.vigencia = response.persona.anioVigencia;
			 				} else if(typeof response.persona.Vigencia !== "undefined") {
			 					extractedData.vigencia = response.persona.Vigencia;
			 				} else {
			 					extractedData.vigencia = notFound;
			 				}
			 				
			 				// Extrayendo el nombre.
			 				if(typeof response.persona.nombre !== "undefined") {
			 					extractedData.nombre = response.persona.nombre; 
			 				} else if(typeof response.persona.Nombre !== "undefined") {
			 					extractedData.nombre = response.persona.Nombre;
			 				} else {
			 					extractedData.nombre = notFound;
			 				}
			 				
			 				// Extrayendo el apellido paterno.
			 				if(typeof response.persona.apPaterno !== "undefined") {
			 					extractedData.patronimico = response.persona.apPaterno; 
			 				} else if(typeof response.persona.ApellidoPaterno !== "undefined") {
			 					extractedData.patronimico = response.persona.ApellidoPaterno;
			 				} else {
			 					extractedData.patronimico = notFound;
			 				}
			 				
			 				// Extrayendo el apellido materno.
			 				if(typeof response.persona.apMaterno !== "undefined") {
			 					extractedData.matronimico = response.persona.apMaterno; 
			 				} else if(typeof response.persona.ApellidoMaterno !== "undefined") {
			 					extractedData.matronimico = response.persona.ApellidoMaterno;
			 				} else {
			 					extractedData.matronimico = notFound;
			 				}
			 				
			 				// Extrayendo el folio central.
			 				if(typeof response.persona.FolioCentral !== "undefined") {
			 					extractedData.folioCentral = response.persona.FolioCentral;
			 				} else {
			 					extractedData.folioCentral = notFound;
			 				}
			 				
			 				// Extrayendo la calle.
			 				if(typeof response.persona.calle !== "undefined") {
			 					extractedData.calle = response.persona.calle;
			 				} else if(typeof response.persona.Calle !== "undefined") {
			 					extractedData.calle = response.persona.Calle;
			 				} else {
			 					extractedData.calle = notFound;
			 				}
			 				
			 				// Extrayendo el código postal.
			 				if(typeof response.persona.cp !== "undefined") {
 								
			 					extractedData.cp = response.persona.cp;
			 					
			 				} else if(typeof response.persona.CP !== "undefined") {

 								extractedData.cp = response.persona.CP;
 							
			 				} else {
			 					extractedData.cp = notFound;
			 				}
			 				
			 				// Extrayendo género.
			 				if(typeof response.persona.genero !== "undefined") {
			 					extractedData.genero = response.persona.genero;
			 				} else if(typeof response.persona.Sexo !== "undefined") {
			 					extractedData.genero = response.persona.Sexo;
			 				} else {
			 					extractedData.genero = notFound;
			 				}
			 				
			 				// Extrayendo la fecha de nacimiento.
			 				if(typeof response.persona.fechaNacimiento !== "undefined") {
			 					extractedData.fechaNacimiento = response.persona.fechaNacimiento; 
			 				} else if(typeof response.persona.FechaNacimiento !== "undefined") {
			 					extractedData.fechaNacimiento = response.persona.FechaNacimiento;
			 				} else if(typeof response.persona.fechaNAcimiento !== "undefined") {
			 					extractedData.fechaNacimiento = response.persona.fechaNAcimiento;
			 				} else {
			 					extractedData.fechaNacimiento = notFound;
			 				}
			 				
			 				// Extrayendo la CURP.
			 				if(typeof response.persona.curp !== "undefined") {
			 					extractedData.curp = response.persona.curp;
			 				} else if(typeof response.persona.Curp !== "undefined") {
			 					extractedData.curp = response.persona.Curp;
			 				} else {
			 					extractedData.curp = notFound;
			 				}
			 				
			 				// Extrayendo la clave de elector.
			 				if(typeof response.persona.claveElector !== "undefined") {
			 					extractedData.claveElector = response.persona.claveElector;
			 				} else if(typeof response.persona.claveLector !== "undefined") {
			 					extractedData.claveElector = response.persona.claveLector;
			 				} else if(typeof response.persona.ClaveElector !== "undefined") {
			 					extractedData.claveElector = response.persona.ClaveElector;
			 				} else {
			 					extractedData.claveElector = notFound;
			 				}
			 				
			 				// Extrayendo el folio de identificación.
			 				if(typeof response.persona.folio !== "undefined") {
			 					extractedData.folioIdentificacion = response.persona.folio; 
			 				} else if(typeof response.persona.Folio !== "undefined") {
			 					extractedData.folioIdentificacion = response.persona.Folio; 
			 				} else {
			 					extractedData.folioIdentificacion = notFound;
			 				}
			 				
			 				// Extrayendo la colonia.
			 				if(typeof response.persona.colonia !== "undefined") {
			 					extractedData.colonia = response.persona.colonia;
			 				} else if(typeof response.persona.Colonia !== "undefined") {
			 					extractedData.colonia = response.persona.Colonia;
			 				} else {
			 					extractedData.colonia = notFound;
			 				}
			 			}
		 			} catch(x) {}
		 				 			
		 			// Se obtuvo un año de vigencia.
		 			if(extractedData.vigencia != "" &&  extractedData.vigencia != notFound && 
		 					!isNaN(parseInt(extractedData.vigencia))) {
		 				var fechaVigOCR = "31/12/" + extractedData.vigencia;
		 				
		 				generalService.setArrayValue('fechaVigenciaIFE', fechaVigOCR);

		 				$rootScope.solicitudOSJson.cotizacion.clientes[0].fechaVigenciaIdentificacion = 
		 					REGEX_FECHA.test(fechaVigOCR) ? fechaVigOCR : "";
		 			} else {
		 				$rootScope.solicitudOSJson.cotizacion.clientes[0].fechaVigenciaIdentificacion = "";
		 			}
		 			
		 			// Se obtuvo un nombre.
		 			if(extractedData.nombre != "" && extractedData.nombre != notFound) {
		 				$rootScope.solicitudOSJson.cotizacion.clientes[0].nombre = extractedData.nombre.trim();
		 			}
		 			
		 			// Se obtuvo un apellido paterno.
		 			if(extractedData.patronimico != "" && extractedData.patronimico != notFound) {
		 				$rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno = 
		 					extractedData.patronimico.trim();
		 			}
		 			
		 			// Se obtuvo un apellido materno.
		 			if(extractedData.matronimico != "" && extractedData.matronimico != notFound) {
		 				$rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno = 
		 					extractedData.matronimico.trim();
		 			}
		 			
		 			// Se obtuvo un folio central.
		 			if(extractedData.folioCentral != "" && extractedData.folioCentral != notFound) {
		 				// Se respalda el Folio Central para su posterior uso.
	 					$rootScope.folioDigitalizacion = extractedData.folioCentral.trim();
		 			} else { 
		 				// Es AyPad.
	 					if(configuracion.so.ios) {
	 						$rootScope.folioDigitalizacion = -999;
	 					} else {
	 						// Para que se ponga vacío al momento de consumir HOMÓNIMOS
	 						$rootScope.folioDigitalizacion = undefined;
	 					}
		 			}
		 			
		 			// Habemus calle.
		 			if(extractedData.calle != "" && extractedData.calle != notFound) {
		 				$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].calle = 
		 					extractedData.calle.substring(0,49).replace(REGEX_TEXTO, "");
		 			}
		 			
		 			// Habemus código postal.
		 			if(extractedData.cp != "" && extractedData.cp != notFound && extractedData.cp.length == 5
		 					&& !isNaN(+ extractedData.cp)) {
		 				$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].cp = extractedData.cp;
		 			}
		 			
		 			// Habemos género.
		 			if(extractedData.genero != "" && extractedData.genero != notFound) {
		 				switch(extractedData.genero) {
			 				case 'M':
			 					$rootScope.solicitudOSJson.cotizacion.clientes[0].idGenero = "F";
			 					$rootScope.solicitudOSJson.cotizacion.clientes[0].genero = 
			 						$scope.getDescripcionCatalogo('F', $scope.generos);
			 					break;
			 				case 'H': 	 					
			 					$rootScope.solicitudOSJson.cotizacion.clientes[0].idGenero = "M";
			 					$rootScope.solicitudOSJson.cotizacion.clientes[0].genero = 
			 						$scope.getDescripcionCatalogo('M', $scope.generos);
			 					break;
			 				default: // Nothing to do.
		 				}
		 			}
		 			
		 			// Variable que determina si ya se ha obtenido una fecha de nacimiento válida.
		 			var fnOk = false;
		 			
		 			// Habemus fecha de nacimiento.
		 			if(extractedData.fechaNacimiento != "" && extractedData.fechaNacimiento != notFound) {
		 				try {
		 					var fnArray = extractedData.fechaNacimiento.split("/");
			 				
			 				fnOk = desglosaFechaNacimiento(fnArray[0] + fnArray[1] + fnArray[2]);
		 				} catch(x) {console.log("What happened, Miss Simone?");}
		 			}

		 			// Se intenta configurar el estado de nacimiento, con base a la CURP.
		 			if(extractedData.curp != "" && extractedData.curp != notFound) {
		 				try {
		 					var cveEdo = extractedData.curp.substring(11, 13).toUpperCase();
			 				var catalogoEdos = 
			 					MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.CATALOGO ESTADOS"];
			 				
			 				for(var i in catalogoEdos) {
			 					if(catalogoEdos[i].CLAVE.valor.toUpperCase() == cveEdo) {
			 						// Se configura la descripción del lugar de nacimiento.
			 						$rootScope.solicitudOSJson.cotizacion.clientes[0].lugarNacimientoDes = 
			 							catalogoEdos[i].ETIQUETA.valor;
			 						// Se configura el identificador del lugar de nacimiento.
			 						$rootScope.solicitudOSJson.cotizacion.clientes[0].idLugarNacimiento = 
			 							parseInt(catalogoEdos[i].ID.valor);
			 						break;
			 					}
			 				}
			 				
			 				// Se intenta obtener una fecha de nacimiento.
		 					possibleBday = extractedData.curp.substring(4, 10);
		 					
		 					// Se intenta sacar una fecha de nacimiento válida.
			 				if(!fnOk && !generalService.isEmpty(possibleBday) && !isNaN(parseInt(possibleBday))) {
			 					fnOk = desglosaFechaNacimiento(possibleBday);
			 				}
		 				} catch(x){console.log("What happened, Miss Simone?");}
		 			}
		 				 			
		 			// Habemus clave de elector.
		 			if(extractedData.claveElector != "" && extractedData.claveElector != notFound) {
		 				// Se configura la clave de elector del cliente.
		 				$rootScope.solicitudOSJson.cotizacion.clientes[0].claveElector = 
		 					generalService.checkLength(extractedData.claveElector, 18);
		 				
		 				if(!fnOk) {
		 					try {
		 		 				// Se obtiene una fecha de nacimiento mediante la subcadena de la clave de elector.
		 			 			possibleBday = claveElector.substring(6, 12);
		 			 			
		 			 			// A ver si se puede obtener una fecha de nacimiento.
		 			 			desglosaFechaNacimiento(possibleBday);
	 		 				} catch(x) {console.log("What happened, Miss Simone?");}
		 				}
		 			}
		 			
		 			// Habemus folio de identificación.
		 			if(extractedData.folioIdentificacion != "" && extractedData.folioIdentificacion != notFound) {
		 				// Se configura el folio de identificación del cliente.
			 			$rootScope.solicitudOSJson.cotizacion.clientes[0].folioIdentificacion = 
			 				generalService.checkLength(extractedData.folioIdentificacion, 13);
		 			}
		 			
		 			// Habemus colonia.
		 			if(extractedData.colonia != "" && extractedData.colonia != notFound) {
		 				try {
		 				// Se configura la colonia.
				 		$rootScope.ocrColonia = extractedData.colonia.replace("COL ",'').toUpperCase().trim();
		 				} catch(x) {console.log("What happened, Miss Simone?");}
		 			}
		 			
		 			// Se configura la bandera que indica que se hizo OCR.
		 			$rootScope.ocrCapturado = true;
		 			
		 			// Se configuran los identificadores de registros en bóveda y las imágenes obtenidas.
		 			if(response.nombres != null && response.nombres.length > 0 
		 					&& response.imagenes != null && response.imagenes.length > 0) {
		 				generalService.setArrayValue('nomsImgIFE',response.nombres);
		 				generalService.setArrayValue('imgsIFE', response.imagenes);
		 			}
		 			
		 			// Se activa la bandera para indicar que se realizó OCR.
		 			$rootScope.solicitudOSJson.banderaOCR = 1;

		 			// Se desbloquean los campos del formulario.
		 			$scope.bloqueaInput = false;
		 		}	 			
	 		}
	 		
	 		/**
	 		 * Se guarda en una variable la concatenacion de todos los datos que se van a validar
	 		 * en el caso de que hayan sido editados en el simulador, la solicitud se va a ir
	 		 * por el flujo de Call Center. 
	 		 */
	 		$scope.ocrIfeOld = concatenaOCR($rootScope.solicitudJson.cotizacion.clientes[0], true);
	 		/*\Se agrega un evento para la bitacora\*/
			//(coacreditado)
				$rootScope.addEvent( BITACORA.SECCION.coacreditado.id, BITACORA.SUBSECCION.capturaFotoCoacreditado.id, BITACORA.ACCION.finDigitalizacion.id, 1, BITACORA.SECCION.coacreditado.guardarEnBD );
			
				/*\Se agrega un evento para la bitacora\*/
	 		
	 		// Bye, bye Spinner!
	 		$rootScope.waitLoaderStatus = LOADER_HIDE;
	 		try{
	 			$scope.validaApellidos($scope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno,$scope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno, 0, 1);
	 		}catch (e) {}
		};
		
		function concatenaOCR(persona, fechaNac) {
	 		var concatenaCadena = ""; 
	 		
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].nombre;
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno;
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno;
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].genero;
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].idGenero;
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].lugarNacimientoDes;
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].idLugarNacimiento;
	 		concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].folioIdentificacion;
	 		
	 		if(fechaNac) {
	 			concatenaCadena = concatenaCadena + $scope.nDia + "/" + $scope.nMes + "/" + $scope.nAnno;
	 		} else {
	 			concatenaCadena = concatenaCadena + $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento;
	 		}
	 		
	 		return concatenaCadena;
	 	};
		
		/** Valida si se seleccinó INE o PASAPORTE ***/
		$scope.limpiardatosIdentificacion = function(bandera) {
			if (bandera == 1) {
				$scope.folioIdent.obligatorio = true;
				$scope.claveElector.obligatorio = true;
				
				$scope.valueAnioRegistro = true;
				$scope.valueNumEmision = true;
				
				$scope.esINE = 1;
				if ($rootScope.solicitudOSJson.banderaOCR == 1) {
					$scope.bloqueaInput = false;
				} else {
					/*if ($scope.ocrRequired) {
						$scope.bloqueaInput = true;
					} else {
						$scope.bloqueaInput = false;
					}*/
				}
			}else {
				$scope.folioIdent.obligatorio = false;
				$scope.claveElector.obligatorio = false;
				
				$scope.valueAnioRegistro = false;
				$scope.valueNumEmision = false;

				$scope.bloqueaInput = false;
				$rootScope.isOCR = false;
			}
			
			if(bandera == 0 && $rootScope.consultaFuncionalidad.flujoIdComplementariaHabilitado){
	 			modalIdComplementaria();
	 		}
			
			/** Esta validacion funciona para habilitar un mensaje en la vista que indica que se deben verificar el folio y la clave que extrajo el OCR **/
			$rootScope.ocrCapturado = $scope.doctoIdentificacion == 'ine' && $rootScope.solicitudOSJson.cotizacion.clientes[0].folioIdentificacion != '' && $rootScope.solicitudOSJson.cotizacion.clientes[0].claveElector != '' ? true : false;
		};

		/** Limpia los datos antes de asignar la información obtenida del OCR **/
		$scope.limpiarDatosOCR = function() {
			$scope.nAnno = "";
			$scope.nMes = "";
			$scope.nDia = "";
			$rootScope.solicitudOSJson.cotizacion.clientes[0].fechaVigenciaIdentificacion = "";
			$rootScope.solicitudOSJson.cotizacion.clientes[0].nombre = "";
			$rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno = "";
			$rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno = "";
			$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].calle = "";
			$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].cp = "";
			$rootScope.solicitudOSJson.cotizacion.clientes[0].idGenero = "";
			$rootScope.solicitudOSJson.cotizacion.clientes[0].genero = "";
			$rootScope.solicitudOSJson.cotizacion.clientes[0].lugarNacimientoDes = "";
			$rootScope.solicitudOSJson.cotizacion.clientes[0].idLugarNacimiento = "";
			$rootScope.solicitudOSJson.cotizacion.clientes[0].folioIdentificacion = "";
			
			// Se limpian los campos que se muestran al seleccionar algún tipo de credencial.
	 		$rootScope.solicitudOSJson.cotizacion.clientes[0].numeroEmision = "";
		};
		
		/** Despliega la fecha de nacimiento cuando se realizó OCR **/
		function desglosaFechaNacimiento(fn) {
			var cont = 0;
			
			if (fn.length == 6) {
				var annio = "",
				mes = "",
				dia = "";
				try {
					var anioActual = new Date().getFullYear().toString().substring(2);
					var anioFN = fn.substring(0, 2);
					
					if (generalService.isEmpty($scope.nAnno)) {
						if (generalService.isNumeric(anioFN)) {
							if (parseInt(anioActual) < parseInt(anioFN))
								annio = "19" + anioFN;
							else
								annio = "20" + anioFN;
							
							$scope.nAnno = annio;
							cont++;
						}

					} else
						cont++;
					
					mes = fn.substring(2, 4);
					if (generalService.isEmpty($scope.nMes)) {
						if (generalService.isNumeric(mes)) {
							var _mes = parseInt(mes);
							if (_mes > 0 && _mes < 12) {
								$scope.nMes = mes;
								cont++;
							}
						}
					} else
						cont++;

					dia = fn.substring(4, 6);
					if (generalService.isEmpty($scope.nDia)) {
						if (generalService.isNumeric(dia)) {
							var _dia = parseInt(dia);
							if (_dia > 0 && _dia < 32) {
								$scope.nDia = dia;
								cont++;
							}
						}

					} else
						cont++;

				} catch (e) {
					$scope.nAnno = null;
					$scope.nMes = null;
					$scope.nDia = null;
				}

			}
			return (cont == 3) ? true : false;
		};


		/** Obtiene la descrición del genero **/
		$scope.getDescripcionCatalogo = function(id, lista) {
			return generalService.descripcionCatalogo(id, lista);
		};
		
		/**  Limpiar datos del OCR IFE/INE cuando se selecciona la opcion de pasaporte **/
		$scope.iniciarProceso=function(forSimulador){
			if(!$scope.opcionElegidaIdComplementaria && $scope.doctoIdentificacion == "passport" && $rootScope.consultaFuncionalidad.flujoIdComplementariaHabilitado){
				modalIdComplementaria();
			}else if(contadorCel == 0){

			/*\Se agrega un evento para la bitacora\*/
			//(coacreditado)
				$rootScope.addEvent( BITACORA.SECCION.coacreditado.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.continuar.id, 0, BITACORA.SECCION.coacreditado.guardarEnBD );
				
				var num = {
						numTelefono: $scope.celular1.valor.split("(").join("").split(")").join("").split(" ").join(""),
					}

					$rootScope.waitLoaderStatus = LOADER_SHOW;
					solicitudService.validarNumTel(num).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jResponse = JSON.parse(data.data.respuesta);
							
							if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){							
								continuaIniciarProceso(forSimulador);	
							}else{
								$scope.celular1.valor="",
								$rootScope.message("AVISO ", ["Captura nuevamente el número de teléfono del cliente."],"Aceptar",null,"bgSomeGreenTone", "verdeS");
							}
						}else{
							contadorCel++;
							$rootScope.message("AVISO ", ["Verifíca que el número telefónico este capturado correctamente."],"Aceptar",null,"bgSomeGreenTone", "verdeS");
						}							
					}, function(error){
							$rootScope.waitLoaderStatus = LOADER_HIDE; 
							$rootScope.message("AVISO", [ ERROR_SERVICE, "Error "+jResponse.codigo],"Aceptar",null,"bgRojo", "rojoR");	
						}
					);		
			}else{
				continuaIniciarProceso(forSimulador);
			}			
		};
		
		function continuaIniciarProceso(forSimulador){

			if($scope.doctoIdentificacion != 'ine') {
				generalService.setArrayValue('nomsImgIFE', null);
	 			generalService.setArrayValue('imgsIFE', null);
				$rootScope.solicitudOSJson.banderaOCR = 0;
		 		$rootScope.solicitudOSJson.cotizacion.clientes[0].folioIdentificacion = '';
		 		$rootScope.solicitudOSJson.cotizacion.clientes[0].claveElector = '';
			}
			
			/** Aquí va el la función para invocar homonimos o sea aqui inicia el relajo **/
			$scope.consultaHomonimo();
		};
		

		/** Valida la huella **/
		var validaHuella = function(cuArray) {
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			if(configuracion.origen.tienda)
				$rootScope.verificarHuella('simulador', 'responseVerificarHuellaIpad', cuArray);
			else {
				if(generalService.isProduccion()) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					modalService.huellaModal("bgAzul");
				}else {
					var response = {
						codigo : VALIDA_HUELLA_RESPONSE.EXITO,
						matches : cuArray
						//matches: ["1-53-365-3608","1-1-4737-239","1-1-4737-244","1-1-4737-267","1-1-4737-268","1-1-4737-273","1-1-4737-282","1-1-4737-286","1-1-4737-289","1-1-4737-312"]
					}
					
					$scope.responseVerificarHuellaIpad(response);
				}
			}
		};
		
		/** Valida la respuesta del componente**/
		$scope.responseVerificarHuellaIpad = function( response ){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			$rootScope.loggerIpad("responseVerificarHuellaIpad", null, response);
			
			switch(response.codigo){
				case VALIDA_HUELLA_RESPONSE.EXITO:	
					
					if(codigoRespuestaHomonimos == 307){
					
						if(Array.isArray(response.matches)){
							response.matches = $.unique(response.matches);
						}else{
							response.matches = response.matches.replace(/(\[)|(\]| )/g,'').split(",");
						}
					
						consultarSatusLCR(response.matches);
						
					}else{
						if( $rootScope.solicitudOSJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id  && 
							     ($rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente ||
							      $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.certificadoItalikaActivado) && !generalService.isEmpty($rootScope.solicitudOSJson.diaPago) )
							
							if($rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.tazLigada){
								generalService.locationPath("/liberacion");
							}else{
								tarjetaService.checkInvetario($rootScope.solicitudOSJson);
							}
								
						
						else
							$scope.agregarIdentificacionOficial(generalService.getPathSection($rootScope.solicitudOSJson,$rootScope.sucursalSession.idCanal), 0);
					}
										
					break;
										
				case VALIDA_HUELLA_RESPONSE.ERROR:
					$scope.endCotizador = false;
					$rootScope.message("Error "+response.codigo,[ "Error al validar la huella."], "Aceptar");
					break;
					
				case VALIDA_HUELLA_RESPONSE.ERROR_COMPONENTE:
					$scope.endCotizador = false;
					$rootScope.message("Error "+response.codigo,[ "Error en componente de huella."], "Aceptar");
					break;
					
				case VALIDA_HUELLA_RESPONSE.COMPONENTE_CANCELADO_PORUSR:	
					$scope.endCotizador = false;
					break;
					
				case VALIDA_HUELLA_RESPONSE.NO_SE_ENCONTARON_HUELLAS:
					flujoCallCenter();											
					break;
					
				case VALIDA_HUELLA_RESPONSE.NO_HAY_COINCIDENCIAS:
					flujoCallCenter();	
					break;
					
				default:
					$scope.endCotizador = false;
					$rootScope.message( "Componete de huella", ["Código "+response.codigo+" no definido. "], "Aceptar");					
					break;
					
			}
									
						
	};
	
	
	/**
	 * Redirige al flujo callCenter en caso de que no se encuentren huellas del cliente
	 */
	function flujoCallCenter(){
		if($rootScope.promocionCampanas($scope.campanaTDC) || $rootScope.promocionCampanas($rootScope.solicitudOSJson.campana)){
			$rootScope.message( "AVISO", ["Por favor, antes de comenzar tu proceso de crédito debes acudir con un asesor financiero a realizar un mantenimiento de biométricos"], "Aceptar", "/menuWrapper");
			$rootScope.waitLoaderStatus = LOADER_HIDE; 
		}else{
			generalService.setArrayValue("pasoCallCenter", 'init');
			generalService.setArrayValue("encolarImagenes", true);
			generalService.setArrayValue("cusArray", cusArray);
			generalService.setArrayValue("pathOrigen", 'simuladorOS');
			generalService.locationPath("/callCenterOS");
		}
	}
	

		/** Inicia el modal para la huella **/
		$scope.abrirDialogo = function() {
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			modalService.huellaModal("bgAzul");
		};

		
		/** Inicia la validación para la firma de los contratos**/
		$scope.dialogo = function() {
			if ($scope.cTerminos2 == false) {
				document.getElementsByName($scope.terminosCondiciones.campo)[0].checked = true;
				$scope.cTerminos2 = true;
				$scope.muestraAviso(true, 2)
			} else {
				$rootScope.solicitudOSJson.aceptaTerminos = 0;
				$scope.cTerminos2 = false;
			}
		}
		
		/** Inicia la validación para la firma de los contratos**/
		$scope.muestraAviso = function(cheked, opc) {
			/*\Se agrega un evento para la bitacora\*/
//			(Coacreditado)
			$rootScope.addEvent( BITACORA.SECCION.coacreditado.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.chechkAvisoPrivacidad.id, 0, BITACORA.SECCION.coacreditado.guardarEnBD );
			
			/*\Se agrega un evento para la bitacora\*/
			$rootScope.avisosAceptados = false;
			
			if (opc == 1)
				cheked = document.getElementsByName(cheked)[0].checked;		
			if (cheked) {
				
				if ($scope.forSimulador.celular.$valid)
					validateService.limpiaMascaras();
				else
					$rootScope.solicitudOSJson.cotizacion.clientes[0].celular = "";
				
				$rootScope.solicitudOSJson.aceptaTerminos = 1;
				$rootScope.modoPrueba = false;
				$scope.modalAvisosWindows();
				
			} else {
				$rootScope.solicitudOSJson.aceptaTerminos = 0;
				$scope.bloqueaInput = true;
				$scope.obligarAvisos();
				}
			};

		/** Activa el modal para la firma de los contratos **/
		$scope.modalAvisosWindows = function() {
			modalService.avisosWinOS("bgazul") .then(
				function(exito) {
					$scope.init();
				}, 
				function(error) {
					$scope.init();
					$scope.cTerminos2 = $rootScope.solicitudOSJson.aceptaTerminos = 0;
					document.getElementsByName($scope.terminosCondiciones.campo)[0].checked = false;
				}
			);
		};


		/** 
		 * Envía los documentos firmados en linea
		 **/
		$scope.agregarIdentificacionOficial = function(_path, index) {
			var esEncolarFirmas = false, esEncolarOCR = false,  tipoCadenaOS = "", cadena="", imagenDatosOCR = [];
			
			if($rootScope.isFirmaAvisoOS){
				tipoCadenaOS="firmaAvisoAval";
				cadena=$rootScope.imgPrivacidadOS;
				esEncolarFirmas = true;
			}else if($rootScope.isFirmaBuroOS){
				tipoCadenaOS="firmaBuroAval";
				cadena=$rootScope.imgBuroOS;
				esEncolarFirmas = true;
			}else if($rootScope.isOCR){
				imagenDatosOCR = generalService.getArrayValue('imgsIFE');
				esEncolarOCR = true;
			}
			
			if(esEncolarFirmas){
				$scope.guardarFirmasOnline(tipoCadenaOS, cadena.replace("data:image/png;base64,","").trim(), _path, index);
			}else if(esEncolarOCR){
				$scope.envioDocumentosEnLinea(imagenDatosOCR,"1",index, _path)
			}else{
				generalService.locationPath(_path);
			}
		};
		
		/** 
		 * Elige los contratos que se enviarán en linea
		 **/
		$scope.guardarFirmasOnline = function(tipoCadena, cadena, path, index) {
			var request = {
				idSolicitudOS: $rootScope.solicitudOSJson.idSolicitud,
				cadena: cadena,
				tipoCadena: tipoCadena,
				porcentaje: "100",
				rechazoFirma: "0"
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.guardaFirmasBiometricosOS(request).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							
							if($rootScope.isFirmaAvisoOS){
								$rootScope.isFirmaAvisoOS = false;
							}else if($rootScope.isFirmaBuroOS){
								$rootScope.isFirmaBuroOS = false;
							}
							
							$scope.agregarIdentificacionOficial(path, index);
						}else{
							generalService.locationPath(path);
						}
					} else {
						generalService.locationPath(path);
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};
		
		
		/** 
		 * Elige los documentos que se enviarán en linea
		 **/
		$scope.envioDocumentosEnLinea = function(imagenDatosOCR,idDocumento,index,path){
			
			for(var i=0;i<$rootScope.solicitudOSJson.documentos.documento.length;i++){
				if(idDocumento === $rootScope.solicitudOSJson.documentos.documento[i].idDocumento){
					$rootScope.solicitudOSJson.documentos.documento[i].status = 4;
				}
			}
			
			var digitDocRequest = {
					idSolicitud: $rootScope.solicitudOSJson.idSolicitud,
					extensionIMG: "jpg",
					imagenB64: imagenDatosOCR[index],
					idDocumento: idDocumento,										
					consecutivoPersona: "0",
					porcentaje: generalServiceOS.porcentajeDocs( $rootScope ).toString()
			};		    			    	

			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.digitalizarImagenOS(digitDocRequest).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
	
					if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
						var responseJson = JSON.parse(data.data.respuesta);														
						
						if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							if(index < (imagenDatosOCR.length-1)){
								index = index + 1;
								$rootScope.solicitudOSJson = responseJson.data;
							}else{
								$rootScope.isOCR = false
								$rootScope.solicitudOSJson = responseJson.data;
							}
							
							$scope.agregarIdentificacionOficial(path,index);
						}else{
							generalService.locationPath(path);
						}
					}else{
						generalService.locationPath(path);
					}
					
				}, function(error){
		            $rootScope.waitLoaderStatus = LOADER_HIDE;	                
				}
			);
		}


		/** Valida la clave de Elector **/
		$scope.validarClaveElector = function() {
			if ($scope.solicitudOSJson.cotizacion.clientes[0].claveElector != undefined && $scope.solicitudOSJson.cotizacion.clientes[0].claveElector.length >= 18) {
				if ($scope.respCE.length < 18) {
					$scope.respCE = $scope.solicitudOSJson.cotizacion.clientes[0].claveElector;
					$scope.solicitudOSJson.cotizacion.clientes[0].claveElector = "";
					$scope.menCE = "Captura nuevamente la clave de Elector";
					$scope.forSimulador.claveElector.$touched = true;
				} else {
					if ($scope.solicitudOSJson.cotizacion.clientes[0].claveElector.localeCompare($scope.respCE) != 0) {
						$scope.menCE = "La clave de elector no coincide, por favor ingrésalos nuevamente"
						$scope.solicitudOSJson.cotizacion.clientes[0].claveElector = "";
						$scope.respCE = "";
					} else {
						$scope.bandCE = true;
						$scope.menCE = "";
					}
				}
			}
		}
		
	    $scope.regresa = function (){
			generalServiceOS.locationPath("/ochoPasos");
		};	
		
		function modalIdComplementaria(){
 			modalService.modalIDComplementaria("Identificación Complementaria", "bgAzul",$scope).then( 
				function(exito) {
					if(exito != undefined){
						$scope.folioIdent.obligatorio = false;
						$scope.claveElector.obligatorio = false;
						
						$scope.valueAnioRegistro = false;
						$scope.valueNumEmision = false;
						
						$scope.bloqueaInput = false;
						$scope.opcionElegidaIdComplementaria = true;
						// Si ya se había seleccionado algún tipo de IFE y se cambió de tipo de identificación.
				 		if(typeof $rootScope.credencialSeleccionada !== "undefined") {
				 			tipoCredencialSeleccionado = false;
				 		}
				 		
				 		$rootScope.marcaIdComplementaria = exito;
				 		generalService.setArrayValue("solicitarIDComplementaria", true);
					}else{
						//$scope.bloqueaInput = true;
						$scope.opcionElegidaIdComplementaria = false;
					}
				}, function(falla) {
					console.log("falla: "+falla);
				}
			);
 		
		};
		
		/*** Valida el correo electronico * **/
		$scope.validaCorreo = function(email) {
			if (email) {
				var re = /(^[-\w.]+@{1}[-a-z0-9]+[.]{1}[a-z-z0-9-]{2,5})+(?:\.[a-zA-Z0-9-]+)*$/;
				
				if (re.test(email)){
					$scope.correoInvalido = false;
				}else{
					$scope.correoInvalido = true;
				}
			}
		}
		
		/**
	 	 * Función listener para la opción que permite seleccionar un tipo de identificación.
	 	 */
	 	$scope.seleccionarTipoIFE = function() {
	 		// Se despliega el modal con el carrusel de imágenes.
	 		ngDialog.openConfirm({
 				template: 'src/viewsControllers/simulador/tipoIFEsView.html',
 				controller: ['$scope', function($scope) {	 					
 					/**
 					 * Método de inicialización.
 					 * @params images, un arreglo de imágenes.
 					 */
 					$scope.init = function(images) {
 						// Variable para el script de la vista.
 						imagenes = images;
 					}
 					
 					/**
 					 * Método listener para el botón de seleccionar.
 					 */
 					$scope.confirmar = function() {
 						try {
 							// Se obtienen los elementos con la clase.
	 						var elementos = $(".owl-item");
	 						
	 						// Este será el índice de la credencial seleccionada, en el arreglo de credenciales.
	 						var selectedIndex; 
	 						
	 						// Se recorre el arreglo de elementos.
	 						for(var i in elementos) {
	 							// El elemento actual contiene la clase "active", es decir, es la seleccionada.
	 							if(elementos[i].classList.contains("active")) {
	 								// Se obtiene el valor del atributo "id", que es su índice en el arreglo.
	 								selectedIndex = parseInt(elementos[i].firstChild.attributes["id"].value);
	 								
	 								break;
	 							}
	 						}
	 						
	 						$rootScope.credencialSeleccionada = !isNaN(selectedIndex) ? selectedIndex : undefined;
 						} catch(x) {
 							console.log("No se pudo encontrar una clase active.");
 						}
 						
 						// Se cierra el modal, de manera "correcta".
 						$scope.confirm();
 					}
 				}],
 				// className: 'ngDialog-theme-default autoWidthModal',
 				data: {
 					title: "Formato de IFE/INE", 
 					estiloTitulo: "bgAzul",
 					images: CREDENCIALES.ANVERSO
 				}
 			}).then(
 				function(success) {
 					console.log("Index seleccionado: " + $rootScope.credencialSeleccionada);
 					
 					// Se deben configurar las variables para mostrar los campos, acorde con la selección.
 					$scope.mostrarNumeroEmision = false;
 					
 					switch($scope.credencialSeleccionada) {
 						case 0: /* break; */
 						case 1: /* break; */
 						case 2: 
// 							$scope.mostrarNumeroEmision = true;
// 							break;
 						default: /* Nothing to do */	 					
 					}
 					
 					// Se realizan configuraciones.
 					resetAfterKindIdSelection(true);
 				}, function(reject) {
 					// Se realizan configuraciones.
 					resetAfterKindIdSelection(false);
 					
 					// Se desconfigura la selección de la credencial.
 					$rootScope.credencialSeleccionada = undefined;
 					
 					console.log("Se canceló la selección.");
 				}
 			);
	 	}
	 	
	 	function resetAfterKindIdSelection(seleccionado) {
	 		// La variable se configura como verdadera.
	 		tipoCredencialSeleccionado = typeof seleccionado === "boolean" ? seleccionado : false;

	 		// Se llama este método para configurar las variables de bloqueo.
	 		$scope.obligarAvisos();
	 		
	 		// Se vuelve todo a su estado pristino.
			$scope.limpiarDatosOCR();
	 	};
	 	
	 	/**
	 	 * Función listener para la ayuda de la credencial.
	 	 */
	 	

	 	$scope.showIdInfo = function() {

			$scope.valorINE = $rootScope.credencialSeleccionada;
			modalService.modalAyudaINE("Ayuda INE", "bgAzul",$scope).then( 
				function(exito) {
					console.log("exito: "+exito);
				}, function(falla) {
					console.log("falla: "+falla);
				}
			);
	 	};
	 	
	 	function validarDatosErroneos(datosErroneos){
			var mensajeDatosMal = "";
			for(var i=0; i<datosErroneos.length; i++){
				if(i>0){
					mensajeDatosMal += ", ";
				}
				if(datosErroneos[i] == 1){
					mensajeDatosMal += "Nombre";
					$scope.nombreIncorrecto = true;
				}else if(datosErroneos[i] == 2){
					mensajeDatosMal += "Apellido Paterno";
					$scope.apPatIncorrecto = true;
				}else if(datosErroneos[i] == 3){
					mensajeDatosMal +=  "Apellido Materno";
					$scope.apMatIncorrecto = true;
				}else if(datosErroneos[i] == 4){
					mensajeDatosMal += "Clave de Elector";
					$scope.clvEIncorrecto = true;
				}else if(datosErroneos[i] == 5){
					mensajeDatosMal += "Folio de Identificación";
					$scope.folioIncorrecto = true;
				}else if(datosErroneos[i] == 6){
					mensajeDatosMal += "Número de Emisión";
					$scope.numEmisionIncorrecto = true;
				}
			}
			
			$rootScope.message("VALIDACIÓN DATOS INE", ["Confirma que los siguientes datos coincidan con la identificación de tu Coacreditado",
			                              mensajeDatosMal],"Aceptar",null,null,null,null);
		};
	});

});