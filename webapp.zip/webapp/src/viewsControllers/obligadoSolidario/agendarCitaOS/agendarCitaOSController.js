'use strict';

define([ "app" ], function(app) {

	app.controller('agendarCitaOSController', function($timeout, $scope, $rootScope, modalService, generalServiceOS, solicitudService, messageData, bazDigitalService, callCenterService, documentosService, obligadoSolidarioService, generalService) {
		
		
		/*******************************************************************************
		 *                      DECLARACION DE VARIABLES GLOBALES                      *
		 *******************************************************************************/
		$rootScope.waitLoaderStatus = LOADER_SHOW;
		if($rootScope.solicitudOSJson.idSeguimiento == STATUS_SOLICITUD.investigacion.id)
			$scope.citaAgendada = true;
		else
			$scope.citaAgendada = false;
		
		// Imágenes estáticas.
		var uriB64 = "data:image/png;base64,";
		$scope.pestaniaSeleccionada = true;
		$scope.showPage = false;
//		$scope.switchOff = false;
		
		// Catálogo con nombres para meses y días de la semana.
		var catalogos = {
			meses: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 
				'Noviembre', 'Diciembre'],
			dias: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'], 
			periodos: [
				{
					id: 1,
				    descripcion: "09:00 - 13:00",
				    nuevosHorarios: false
				},
				{
				    id: 2,
				    descripcion: "13:01 - 17:00",
				    nuevosHorarios: false
				    
				},
				{
				    id: 3,
				    descripcion: "17:01 - 19:00",
				    nuevosHorarios: false
				},
				{
					id: 4,
				    descripcion: "09:00 - 14:00",
				    nuevosHorarios: true
				},
				{
				    id: 5,
				    descripcion: "14:01 - 19:00",
				    nuevosHorarios: true
				}
			]
		};

		/*******************************************************************************
		 *                     FUNCIONES QUE SE EJECUTAN EN EL INIT                    *
		 *******************************************************************************/
		
		/**
		 * Función Principal
		 **/
		$scope.init = function() {
			
			if(generalService.validardiaDePago())
				generalService.setArrayValue("sourcePath", "/diadePago");
			else
				generalService.setArrayValue("sourcePath", "/ochoPasos");
			// No se tienen CUs.
			if($rootScope.solicitudOSJson.cotizacion.clientes[0].clienteUnico == "" 
				|| $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico == "") {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				// Se muestra un mensaje como feedback.
				$rootScope.message("¡Algo no anda muy bien!", 
					["Las solicitudes no cuentan con clientes únicos aún."], 
					"Aceptar", "/ochoPasos"
				);
				
				return;
			}
			
			$scope.fechaRegistroSolicitud();
						
			$scope.cargaVista();
			
			estilos();
			
			$scope.combos = [];
			$scope.combosAval = [];
			
			$scope.obtenerDisponibilidad(1);
			
			$scope.estado = 0;
			
			$scope.visitDate = null;
			$scope.visitTime = null;
			
			$scope.selectedDate = null;
			$scope.selectedPeriod = null;
			$scope.moreDays = false;
			
		};
		
		/**
		 * Fecha registro de la solicitud
		 **/
		$scope.fechaRegistroSolicitud = function() {
			
			var anio, mes, dia, fecha = '';
			
			fecha = $scope.solicitudJson.idSolicitud.substring(0,8);
			anio = fecha.substring(0,4);
			mes = fecha.substring(4,6);
			dia = fecha.substring(6,8);
			
			fecha = anio+'/'+mes+'/'+dia;
			
			$scope.fechaSolicitud = getPrettyFormatDate(fecha);
			
		};
		
		/**
		 * Carga la vista principal
		 **/
		$scope.cargaVista = function() {
			if (configuracion.origen.tienda){
				$scope.origen = "TIENDA";
			}else{
				$scope.origen = "WEB";
			}
			
			$scope.diaCita = generalServiceOS.getDataInput("VISITA ASESOR", "DIA", $scope.origen);
			$scope.horario = generalServiceOS.getDataInput("VISITA ASESOR", "HORARIO", $scope.origen);
			$scope.btnAceptar = generalServiceOS.getDataInput("VISITA ASESOR", "BOTON ACEPTAR", $scope.origen);
			$scope.textoBoton = "Agendar e imprimir Aviso de Visita";
		};
		
		/*****************************
		 *  ESTILOS DE LAS PESTAÑAS  *
		 *****************************/
				
		/**
		 * Estilos para las pestañas de "Coacreditado" y "Cliente"
		 **/
		$scope.activeTab = function(isObligado) {
			if(!$scope.estado){
				isObligado = typeof isObligado == "undefined" ? false : isObligado;
				
				if(isObligado) {
					
					console.log("OS");
					
					$scope.clientAddress = $rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].calle +  ", COL. " 
					   + $rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].colonia +  ", C.P. "  
					   + $rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].cp +  ". DELEGACIÓN "
					   +  $rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].delegacion + ", " 
					   + $rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].estado;
					
					$scope.uniqueClientNumber = $rootScope.solicitudOSJson.cotizacion.clientes[0].clienteUnico;
					
				} else {
					
					console.log("Cliente");
					
					$scope.clientAddress = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].calle +  ", COL. " 
					   + $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].colonia +  ", C.P. "  
					   + $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].cp +  ". DELEGACIÓN "
					   +  $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].delegacion + ", " 
					   + $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].estado;
					
					$scope.uniqueClientNumber = $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico;
					
				}
	
				$scope.pestaniaSeleccionada = isObligado;
				
				estilos();
			}
		}
		
		/**
		 * Estilos para las pestañas de coumentos pendientes por firmar 
		 **/
		function estilos(){
			if($scope.pestaniaSeleccionada){
				$scope.estiloDocumentosPendientes = {
						'flex-direction': 'row',
						'box-sizing': 'border-box',
						'display': 'flex',
						'align-items': 'center',
						'align-content': 'center',
						'justify-content': 'center',
						'height': '100%',
						'width': '50%',
						'border-bottom': '1px solid #04B4AE',
						'border-left': '1px solid #04B4AE',
						'border-right': '1px solid #04B4AE',
						'color': '#04B4AE',
						'font-weight': 'bold',
						'background-color': 'white'
				}
				
				$scope.estiloDocumentosFirmados = {
						'flex-direction': 'row',
						'box-sizing': 'border-box',
						'display': 'flex',
						'align-items': 'center',
						'align-content': 'center',
						'justify-content': 'center',
						'height': '100%',
						'width': '50%',
						'color': 'white',
						'background-color': '#04B4AE',
						'font-weight': 'bold'
				}
			}else{
				$scope.estiloDocumentosFirmados = {
						'flex-direction': 'row',
						'box-sizing': 'border-box',
						'display': 'flex',
						'align-items': 'center',
						'align-content': 'center',
						'justify-content': 'center',
						'height': '100%',
						'width': '50%',
						'border-bottom': '1px solid #04B4AE',
						'border-left': '1px solid #04B4AE',
						'border-right': '1px solid #04B4AE',
						'color': '#04B4AE',
						'font-weight': 'bold',
						'background-color': 'white'
				}
				
				$scope.estiloDocumentosPendientes = {
						'flex-direction': 'row',
						'box-sizing': 'border-box',
						'display': 'flex',
						'align-items': 'center',
						'align-content': 'center',
						'justify-content': 'center',
						'height': '100%',
						'width': '50%',
						'color': 'white',
						'background-color': '#04B4AE',
						'font-weight': 'bold'
				}
			}
		}
		
		/**
		 * Obtiene la disponibilidad de horarios para aval y cliente
		 * */
		$scope.obtenerDisponibilidad = function(tipo){
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			//Tipo = 1, Aval
			if(tipo == 1){
				var jsonRequest = {
						"latitud": $rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud,
						"longitud": $rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud,
					    "idActividad": 3, //Investigacion de linea de credito
					    "idOrigen": 19, //Nueva originacion de credito
					    "tipoOperacion": "gps",
					    "numDias": 7
				}
			}else{
				var jsonRequest = {
						"latitud": $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud,
						"longitud": $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud,
					    "idActividad": 3, //Investigacion de linea de credito
					    "idOrigen": 19, //Nueva originacion de credito
					    "tipoOperacion": "gps",
					    "numDias": 7
				}
			}
			$scope.flujo = tipo;
			
			// Se realiza el consumo de un servicio.
			solicitudService.obtenerDatosVisita(jsonRequest).then(function(exito){
				
				// Se valida respuesta del servicio
				if (exito.data.codigo == RESPONSE_CODIGO_EXITO) {
					
					// Se obtiene la respuesta del consumo.
					var responseDisponibilidad = JSON.parse(exito.data.respuesta);
					
					// Se obtuvo un código exitoso.
					if((responseDisponibilidad.codRsp == "SRA000") && (responseDisponibilidad.datoRsp != null)) {
						
						if($scope.flujo == 1){
							
							$scope.jvcEmployeeNumberAval = responseDisponibilidad.datoRsp.numeroEmpleado;
							$scope.tipoEmpleadoAval = responseDisponibilidad.datoRsp.tipoEmpleado;
							
							// Se extraen horarios de la respuesta del servicio y se forma el combo a mostrarse en la vista
							$scope.getHorariosAval(responseDisponibilidad.datoRsp.fechasDisponibles);
							
							//Validamos que el arreglo de horarios tenga registros
							if($scope.combosAval.length > 0){
								//Seleccion automatica de los primeros horarios
								$scope.visitDateAval = getPrettyFormatDate($scope.combosAval[0].fecha, false, false);
								$scope.visitTimeAval = $scope.combosAval[0].periodos[0].periodo;
								$scope.visitIdPeriodAval = $scope.combosAval[0].periodos[0].id;
								
								$scope.selectedDateAval = $scope.combosAval[0];
								$scope.selectedPeriodAval = $scope.combosAval[0].periodos[0];
								
								// Se obtienen datos del asesor 
								$scope.obtenerDisponibilidad(2);
								
								//Se detiene el flujo para no llegar al error
								return;
								
							}
							
						}else{
							
							$scope.jvcEmployeeNumber = responseDisponibilidad.datoRsp.numeroEmpleado;
							$scope.tipoEmpleado = responseDisponibilidad.datoRsp.tipoEmpleado;
							
							// Se extraen horarios de la respuesta del servicio y se forma el combo a mostrarse en la vista
							$scope.getHorarios(responseDisponibilidad.datoRsp.fechasDisponibles);
							
							//Validamos que el arreglo de horarios tenga registros
							if($scope.combos.length > 0){
								//Seleccion automatica de los primeros horarios
								$scope.visitDate = getPrettyFormatDate($scope.combos[0].fecha, false, false);
								$scope.visitTime = $scope.combos[0].periodos[0].periodo;
								$scope.visitIdPeriod = $scope.combos[0].periodos[0].id;
								
								$scope.selectedDate = $scope.combos[0];
								$scope.selectedPeriod = $scope.combos[0].periodos[0];
								
								//De nuevo, bandera activa para aval
								$scope.flujo = 1;
								// Se obtienen datos del asesor 
								$scope.obtenerDatosAsesor();
								
								//Se detiene el flujo para no llegar al error
								return;
								
							}
							
						}
						
					}
					
				} 					
				// No se muestra nada de la página actual.
				$scope.showPage = false;
				// Bye, bye Spinner!
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				// Se limpia el $rootScope.
				generalService.cleanRootScope($rootScope);
				// Se reconstruye el JSON de la solicitud.
				generalService.buildSolicitudJson($rootScope, null);
				// Se muestra un mensaje como feedback.
				var mensajeErrorDisponibilidad =  (responseDisponibilidad != undefined) ? responseDisponibilidad.dscRsp : "Reintentar mas tarde";
				$rootScope.message("Visita Asesor", ["Inconveniente en el servicio de Disponibilidad: " + mensajeErrorDisponibilidad, "Latitud: " + jsonRequest.latitud, " Longitud: " + jsonRequest.longitud], "Aceptar", "/");					
			},function(error){
				
				fatalErrorFunction();
				
			});	
			
		};
		
		/**
		 * Función que se ejecuta cuando se obtiene un error que ya no permite continuar con el cargado de los datos.
		 */
		function fatalErrorFunction() {
			// No se muestra nada de la página actual.
			$scope.showPage = false;
			
			// Bye, bye Spinner!
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			
			// Se limpia el $rootScope.
			generalService.cleanRootScope($rootScope);
			// Se reconstruye el JSON de la solicitud.
			generalService.buildSolicitudJson($rootScope, null);
			
			// Se muestra un mensaje como feedback.
			$rootScope.message("Visita asesor", 
				["Ocurrió un problema al recuperar los datos del asesor."], 
				"Aceptar", "/"
			);
		};
		
		/**
		 * Funcion para crear el arreglo de horarios a iterarse
		 */
		$scope.getHorarios = function(fechasDisponibles){
			
			var horaInicio;
			var horaFin;
			var idPeriodo;
			var horarios = [];
			$scope.comboCompleto = [];
			
			//Se extraen horarios de la respuesta del servicio y se crea arreglo legible para iterarse en la vista
			for(var i = 0; i < fechasDisponibles.length; i++){
				//Extraccion de horarios
				for(var x = 0; x < fechasDisponibles[i].horarios.length; x++){
					
					horaInicio = fechasDisponibles[i].horarios[x].horaInicio; 
					horaFin = fechasDisponibles[i].horarios[x].horaFin;
					idPeriodo = fechasDisponibles[i].horarios[x].idPeriodo;
					
					horarios.push({"periodo":horaInicio+" - "+horaFin, "id": idPeriodo});
					
				}
				//Creacion de arreglo
				$scope.comboCompleto.push({
					
					"fecha": fechasDisponibles[i].fecha.split("-").reverse().join("-"),
					"formato": getPrettyFormatDate(fechasDisponibles[i].fecha.split("-").reverse().join("-"), false, false),
					"periodos": horarios
					
				});
				//Se limpia el arreglo de horarios para setear los de la siguiente fecha disponible
				horarios = [];
				
			}
			
			// Activa check box "elegir otro dia" y recorta el combo si revasa de 3 horarios
			if($scope.comboCompleto.length > 3){	
				//Se inserta el combo y se recorta a 3 horarios para mostrarse
				//Se deja intacto el combo completo por si el cliente desea elegir otro dia con el check box
				var corteTresHorarios = [];
				corteTresHorarios = $scope.comboCompleto;
				$scope.combos = corteTresHorarios.slice(0,3);
				$scope.moreDays = true;
			}else{
				// Desactiva check box "elegir otro dia"
				//Se inserta el combo de horarios completo porque no revasa los 3 horarios
				$scope.combos = $scope.comboCompleto;
				$scope.moreDays = false;
			}
			
		};
		
		/**
		 * Funcion para crear el arreglo de horarios a iterarse
		 */
		$scope.getHorariosAval = function(fechasDisponibles){
			
			var horaInicio;
			var horaFin;
			var idPeriodo;
			var horarios = [];
			$scope.comboCompletoAval = [];
			
			//Se extraen horarios de la respuesta del servicio y se crea arreglo legible para iterarse en la vista
			for(var i = 0; i < fechasDisponibles.length; i++){
				//Extraccion de horarios
				for(var x = 0; x < fechasDisponibles[i].horarios.length; x++){
					
					horaInicio = fechasDisponibles[i].horarios[x].horaInicio; 
					horaFin = fechasDisponibles[i].horarios[x].horaFin;
					idPeriodo = fechasDisponibles[i].horarios[x].idPeriodo;
					
					horarios.push({"periodo":horaInicio+" - "+horaFin, "id": idPeriodo});
					
				}
				//Creacion de arreglo
				$scope.comboCompletoAval.push({
					
					"fecha": fechasDisponibles[i].fecha.split("-").reverse().join("-"),
					"formato": getPrettyFormatDate(fechasDisponibles[i].fecha.split("-").reverse().join("-"), false, false),
					"periodos": horarios
					
				});
				//Se limpia el arreglo de horarios para setear los de la siguiente fecha disponible
				horarios = [];
				
			}
			
			// Activa check box "elegir otro dia" y recorta el combo si revasa de 3 horarios
			if($scope.comboCompletoAval.length > 3){	
				//Se inserta el combo y se recorta a 3 horarios para mostrarse
				//Se deja intacto el combo completo por si el cliente desea elegir otro dia con el check box
				var corteTresHorarios = [];
				corteTresHorarios = $scope.comboCompletoAval;
				$scope.combosAval = corteTresHorarios.slice(0,3);
				$scope.moreDays = true;
			}else{
				// Desactiva check box "elegir otro dia"
				//Se inserta el combo de horarios completo porque no revasa los 3 horarios
				$scope.combosAval = $scope.comboCompletoAval;
				$scope.moreDays = false;
			}
			
		};
		
		/**
		 * Funcion para obtener los datos del empleado asesor
		 * **/
		$scope.obtenerDatosAsesor = function(){
			
			var requestNumeroEmp = ($scope.flujo == 1) ? $scope.jvcEmployeeNumberAval : $scope.jvcEmployeeNumber;
			
			solicitudService.obtenerDatosEmpleadoAsesor(requestNumeroEmp).then(function(exito){
				// ¿Todo olrait?
				if(exito.data.codigo == RESPONSE_CODIGO_EXITO) {
					//Se parsea la respuesta
					try {
						var responseAsesor = JSON.parse(exito.data.respuesta);
					} catch (e) {
						// Se muestra un mensaje como feedback.
						$rootScope.message("Visita Asesor", ["Respuesta de Asesor invalida"], "Aceptar");
					}
					
					//Se obtuvo un codigo exitoso?
					if((responseAsesor.codigo == "200.Credito-Creditos.SRA000") && (responseAsesor.respuesta != null)) {
						
						if($scope.flujo == 1){
							
							//Se valida que tenga informacion la respuesta antes de setearla
							if(responseAsesor.respuesta.nombreEmpleado != '' && responseAsesor.respuesta.nombreEmpleado != null){
								if(responseAsesor.respuesta.descPuestoEmpleado != '' && responseAsesor.respuesta.descPuestoEmpleado != null){
									//Se coloca la respuesta en sus respectivas variables
									$scope.jvcNombreAval = responseAsesor.respuesta.nombreEmpleado;	
									$scope.empleadoParaVisitaAval = $scope.formatoLetras(responseAsesor.respuesta.descPuestoEmpleado);
									//Se setea la foto, sino tiene se queda la foto por default
									if(responseAsesor.respuesta.foto != '' && responseAsesor.respuesta.foto != null)
										$scope.jvcPhotoAval = uriB64 + responseAsesor.respuesta.foto;
									//Sigue el Aval
									$scope.flujo = 2;
									$scope.obtenerDatosAsesor();
									return;
									
								}
							}
							
						}else{
							
							//Se valida que tenga informacion la respuesta antes de setearla
							if(responseAsesor.respuesta.nombreEmpleado != '' && responseAsesor.respuesta.nombreEmpleado != null){
								if(responseAsesor.respuesta.descPuestoEmpleado != '' && responseAsesor.respuesta.descPuestoEmpleado != null){
									//Se coloca la respuesta en sus respectivas variables
									$scope.jvcNombre = responseAsesor.respuesta.nombreEmpleado;
									$scope.empleadoParaVisita = $scope.formatoLetras(responseAsesor.respuesta.descPuestoEmpleado);
									//Se setea la foto, sino tiene se queda la foto por default
									if(responseAsesor.respuesta.foto != '' && responseAsesor.respuesta.foto != null)
										$scope.jvcPhoto = uriB64 + responseAsesor.respuesta.foto;
									// Se cargan ya los datos.
									
									// Tab activa por defecto, Coacreditado.
									$scope.activeTab(true);
									$scope.showPage=true;
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									return;
									
								}
							}
							
						}
					}		
				}
				// No se muestra nada de la página actual.
				$scope.showPage = false;
				// Se limpia el $rootScope.
				generalService.cleanRootScope($rootScope);
				// Se reconstruye el JSON de la solicitud.
				generalService.buildSolicitudJson($rootScope, null);
				// Se muestra un mensaje como feedback.
				var mensajeErrorAsesor =  (responseAsesor != undefined) ? responseAsesor.mensaje : "Reintentar mas tarde";
				$rootScope.message("Visita Asesor", ["Inconveniente en el servicio para obtener Asesor: " + mensajeErrorAsesor], "Aceptar", "/");
				// Bye, bye Spinner!
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				
				return;
				
			},function(error){
				// Se muestra un mensaje como feedback.
				$rootScope.message("Visita Asesor", ["Inconveniente en el servicio para obtener Datos del asesor: "+ error], "Aceptar", "/");
				// Bye, bye Spinner!
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
			
		};
		
		/**
		 * Función para dar formato de Mayusculas y Minusculas.
		 * De: AAAA AAAA AAAA a: Aaaa Aaaa Aaaa
		 */
		$scope.formatoLetras = function(enunciado){
			
			var arregloMayusculas = enunciado.split(" ");
			var arregloFormateado = [];
			var letraMayuscula = "";
			
			for(var i = 0; i < arregloMayusculas.length; i ++){
				
				letraMayuscula = arregloMayusculas[i].substring(0,1);
				arregloFormateado.push(letraMayuscula+arregloMayusculas[i].substring(1).toLowerCase());
				
			}
			
			return arregloFormateado.join(' ');
			
		};
		

		/*******************************************************************************
		 *                   FUNCIONES QUE SE EJECUTAN DESDE EL FRONT                  *
		 *******************************************************************************/
		
		/**
		 * Servicio para apartar el lugar en la agenda del JVC
		 **/
		$scope.solicitarVisitaJVC = function(){
			
			$scope.fechaCJV = $rootScope.solicitudOSJson.fechaCita.split("/");
			
			var jsonJVC={
				"pais":$rootScope.solicitudOSJson.idPais,
				"canal":$rootScope.solicitudOSJson.idCanal,
				"sucursal":$rootScope.solicitudOSJson.idSucursal,
				"idSolicitud":$rootScope.solicitudOSJson.idSolicitudTienda,
				"numEmpleado":$scope.respDisp.datoRsp.numeroEmpleado,
				"idCitaJvc": parseInt($rootScope.solicitudOSJson.idCitaJVC),
				"fechaCita": $scope.fechaCJV[2] + "-" + $scope.fechaCJV[1] + "-" + $scope.fechaCJV[0],
				"cveHorario": parseInt($rootScope.solicitudOSJson.periodoCita),
				"tipoCita": 1,
				"statusCita": 1,
				"tipoPersona": 1,
				"folioCaptacion":""
			};
			
			solicitudService.solicitarVisitaAsesor(jsonJVC).then(
				function(data,status) {
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
							$scope.resp = JSON.parse(data.data.respuesta);
					}else{
						$rootScope.message("ERROR", [ generalServiceOS.displayMessage(data.data.descripcion) ], "Aceptar", $scope.pathInicial);
					}
				},function(error) {
					console.log("asdasd");
				}
			);
		};
		
		/**
		 * Función listener para confirmar la visita del JVC.
		 * Se pregunta si está de acuerdo con la visita.
		 */
		$scope.aceptar = function() {
			
			var postGuardarCita  = function() {
				// Mostrar el pop-up para recordar la captura de pantalla e impresión, si todo fue bien 
				$rootScope.message("Atención", 
					["¡No olvides imprimir el aviso de visita y entregárselo a tu cliente!",
						"Sólo realiza los siguientes pasos:",
						"1. Captura la pantalla del aviso de visita",
						"2. Dirígete a la siguiente ruta del menú ADN:",
						"Administración > Office ADN > Impresión de pantallas",
						"3. Busca el aviso de visita de tu cliente, imprímelo y entrégaselo"], 
					"Aceptar", null
				);
				//"$scope.estado" tambien se ocupa para deshabilitar el 'switch' y los 'select' de la vista;
				//Para que el asesor imprima pantalla sin modificar valores
				$scope.estado = 1;
				$scope.textoBoton = "Terminar";
				
			}
			
			if($scope.estado == 1)
				// Redirigir al tracking.
				generalServiceOS.locationPath("/estatusOS");
			else
				// Guardar la cita.
				guardarCita(postGuardarCita);
			
		};
		
		/**
		 * Funcion para determinar si el cliente aceptara o no al asesor 
		 */
		$('#myonoffswitch').click(function(){
			
			modalService.confirmModal("¡Atención!", 
					["¿Tu cliente está seguro de que no autoriza la visita del Gestor de Cartera Relacional?",
						"La solicitud de crédito se rechazará."], "No", "Sí").then(
					function(confirm) {
						var postRechazo = function() {
							// Se limpia el $rootScope.
							generalServiceOS.cleanRootScope($rootScope);
							// Se reconstruye el JSON de la solicitud.
							generalServiceOS.buildSolicitudJson($rootScope, null);
							
							// Se muestra un mensaje como feedback.
							$rootScope.message("Solicitud rechazada", 
								["Sin la visita del Gestor de Cartera Relacional no es posible continuar " +
									"con el proceso de la solicitud."], 
								"Aceptar", "/simulador"
							);
						};
						
						// Realizar el rechazo de la solicitud.
						rechazarSolicitud(postRechazo);								
					}, function(cancel) {
						//Que siempre si quiere el credito el cliente. Se afirma de nuevo el switch.
						$('#myonoffswitch').prop('checked', true);
						
					}
				);
			
		});
		
		/**
		 * Función para reservar el lugar para el agendado de visita de JCV.
		 */
		function solicitarVisitaJVC() {
			var json;
			
			if($scope.pestaniaSeleccionada) {
				json = $rootScope.solicitudOSJson;				
			} else {
				json = $rootScope.solicitudJson;
			}
			
			// Fecha cita.
			var fecha = json.fechaCita;
			
			// Parámetros de entrada.
			var jsonJVC = {
				"pais": json.idPais,
				"canal": json.idCanal,
				"sucursal": json.idSucursal,
				"idSolicitud": json.idSolicitudTienda,
				"numEmpleado": $scope.jvcEmployeeNumber,
				"idCitaJvc": parseInt(json.idCitaJVC),
				"fechaCita": reverseDate(fecha, "/"),
				"cveHorario": parseInt(json.periodoCita),
				"tipoCita": 1,
				"statusCita": 1,
				"tipoPersona": 1,
				"folioCaptacion": ""
			};
			
			// Se procede con el consumo.
			solicitudService.solicitarVisitaAsesor(jsonJVC).then(
				function(data, status) {
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var response = JSON.parse(data.data.respuesta);
						
						console.log("El consumo del servicio solicitarVisitaAsesor fue genial." + response);
					} else {
						// Se envía un mensajito de feedback.
						$rootScope.message("ERROR", [generalService.displayMessage(data.data.descripcion)], 
							"Aceptar", "/"
						);
					}
				}, function(error) {
					console.log("Error al intentar consumir el servicio de SolicitarVisitaAsesor.");
				}
			);
		};
		
		/**
		 * Función para realizar el guardado de la cita.
		 * Recibe una función que se ejecutará en caso de realizarse un consumo exitoso.
		 */
		function guardarCita(successFunction) {
			
			var json, selDate, selPer, visIdPer, visTim, tipEmp;
			
			if($scope.pestaniaSeleccionada) {
				json = $rootScope.solicitudOSJson;	
				selDate = $scope.selectedDateAval;
				selPer = $scope.selectedPeriodAval;
				visIdPer = $scope.visitIdPeriodAval;
				visTim = $scope.visitTimeAval;
				tipEmp = $scope.tipoEmpleadoAval;
			} else {
				json = $rootScope.solicitudJson;
				selDate = $scope.selectedDate;
				selPer = $scope.selectedPeriod;
				visIdPer = $scope.visitIdPeriod;
				visTim = $scope.visitTime;
				tipEmp = $scope.tipoEmpleado;
			}
			
			// Se tienen una fecha y un horario seleccionados.
			if(selDate != null && selPer != null) {
				
				var fechaCita = reverseDate(selDate.fecha, "-");
				
				if(fechaCita != "" && visIdPer != null) {				
					
					// Se prepara un JSON de entrada.
					var x = {
						idSolicitud: json.idSolicitud, // Cliente y Coacreditado
						idUsuario: json.cotizacion.clientes[0].idPersona, // Cliente y Coacreditado
						fecha: fechaCita.replace(/-/g, '\/'), // Cliente y Coacreditado
						periodo: visIdPer, // Cliente y Coacreditado
						empleado: $scope.jvcEmployeeNumber, // Cliente
						empleadoCita : $scope.jvcEmployeeNumberAval, // Coacreditado
						idEmpleado: $rootScope.userSession.noEmpleado, // Cliente y Coacreditado
						ip: json.direccionIp, // Cliente y Coacreditado
						tipoSolicitud: json.tipoSolicitud, // Coacreditado
						horarioCita: (tipEmp == 1) ? "" : visTim
					};
					
					$scope.citaAgendada = true;
					// Oh, hello Spinner!
					$rootScope.waitLoaderStatus = LOADER_SHOW;
										
					var successConsume = function(exito) {
						// Bye, bye Spinner!
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						// ¿Todo olrait (bridges level)?
						if(exito.data.codigo == RESPONSE_CODIGO_EXITO) {
							var response = JSON.parse(exito.data.respuesta);
							
							// ¿Todo olrait (a nivel de respuesta de consumo)?
							if(response.codigo == 2) {
								// Se actualiza el JSON de la solicitud.
								if($scope.pestaniaSeleccionada) {
									$rootScope.solicitudOSJson = response.data;
								} else {
									$rootScope.solicitudJson = response.data;
								}
								
								// ¿Seguro que fue un exitaso?
								if(response.data.flujoSolicitudADN != 99) {
									$rootScope.message("¡No llegamos al 99!", 
										["No se consiguió bajar a Tienda de manera correcta."],
										"Aceptar", null
									);
								} else {
									// Si los nuevos horarios están activos, hay que reservar un lugarcito.
									if($rootScope.consultaFuncionalidad.nuevosHorariosJVC) {
										solicitarVisitaJVC();
									}
									
									// Workoround para créditos inmediatos.
									if(configuracion.estatus.opcion == 0) {
										if($rootScope.solicitudJson.creditoInmediato == 1) {
											$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.preautorizada.id;
										}
									}
									
									// Se ejecutan los pendientes, para después del guardado.
									successFunction();
								}
							} else if(response.codigo == TARJETA_FOLIO_EN_PROCESO) {
								// Ya existe una transacción en proceso, para esta solicitud.
								$rootScope.message("Visita Asesor", 
									["Codigo : " + response.codigo, "Aviso: La solicitud está siendo procesada." 
										+ "Por favor, espere un momento"],
									"Aceptar", null
								);
							} else {
								$rootScope.message("Visita Asesor [" + response.codigo + "]", 
									["Ocurrió un problema con el servicio Agendar Cita."], 
									"Aceptar", "/simulador"
								);
							}
						} else {
							$rootScope.message("ERROR", 
								[generalService.displayMessage(exito.data.descripcion)], 
								"Aceptar", "/simulador"
							);
						}
					};
					
					var unsuccessConsume = function(error) {
						// Bye, bye Spinner!
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						$rootScope.message("Visita Asesor [" + response.codigo + "]", 
							["No se pudo realizar el guardado de la cita."], 
							"Aceptar", "/simulador"
						);
					};
					
					if($scope.pestaniaSeleccionada) {
						obligadoSolidarioService.agendarCitaOS(x).then(successConsume, unsuccessConsume);
					} else {
						// Se procede con el consumo.
						solicitudService.agendaCita(x).then(successConsume, unsuccessConsume);
					}
				}
			}
		};
		
		/**
		 * Función para rechazar una solicitud.
		 * Recibe una función que se ejecuta en caso de tener éxito en el rechazo.
		 */
		function rechazarSolicitud(onSuccessRejection) {
			var jsonRequest;
			
			if($scope.pestaniaSeleccionada) {
				
				jsonRequest = {
					idMotivoRechazo : STATUS_SOLICITUD.rechazada.idMotivoRechazo.rechazaVisitaJVC,
					idSolicitudOS : $rootScope.solicitudOSJson.idSolicitud,
					status : STATUS_SOLICITUD.rechazada.id 
				};
				 
			} else {
				jsonRequest = $rootScope.solicitudJson;
				// Se configura un idMotivo solicitud igual a 164.
				jsonRequest.idMotivoRechazo = STATUS_SOLICITUD.rechazada.idMotivoRechazo.rechazaVisitaJVC;
				// Se configura un idSeguimieno igual a 9, que es RECHAZADO.
				jsonRequest.idSeguimiento = STATUS_SOLICITUD.rechazada.id;
			}
			
			// Oh, hello Spinner!
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			var unsuccess = function(error) {
				// Bye, bye Spinner!
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				
				// Se muestra un mensaje como feedback.
				$rootScope.message("Aviso", 
					["Ocurrió un problema mientras se intentaba rechazar la solicitud."], 
					"Aceptar", null
				);
			};
			
			if($scope.pestaniaSeleccionada){
				
				obligadoSolidarioService.actualizarStatusOS(jsonRequest).then(
						function(exito) {
							var fail = true;
							
							// ¿Todo bien a nivel de puentes?
							if(exito.data.codigo != undefined) {
								var response = JSON.parse(exito.data.respuesta);
								
								// Se consiguió el rechazo.
								if(response.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO) {
									fail = false;
									
									// Bye, bye Spinner!
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									
									onSuccessRejection();
								}
							}
							
							// Se obtuvo algún error en la respuesta del servicio.
							if(fail) {
								unsuccess(exito);
							}
						}, function(error) {
							unsuccess(error);
						}
					);
				
			}else{
				
				solicitudService.actualizarSolicitud(jsonRequest).then(
						function(exito) {
							var fail = true;
							
							// ¿Todo bien a nivel de puentes?
							if(exito.data.codigo != undefined) {
								var response = JSON.parse(exito.data.respuesta);
								
								// Se consiguió el rechazo.
								if(response.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO) {
									fail = false;
									
									// Bye, bye Spinner!
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									
									onSuccessRejection();
								}
							}
							
							// Se obtuvo algún error en la respuesta del servicio.
							if(fail) {
								unsuccess(exito);
							}
						}, function(error) {
							unsuccess(error);
						}
					);
				
			}
			
		};
		
		/**
		 * Función que determina si actualmente, una persona nacida en birthDate tiene al menos limitAge años.
		 * birthDate: cadena que representa una fecha de nacimiento en formato: dd/mm/aaaa.
		 * limitAge: entero que representa la edad mínima requerida.
		 */
		function isOldEnought(birthDate, limitAge) {
			// La edad requerida es un número.
			if(!isNaN(parseInt(limitAge))) {
				// Se obtiene una fecha de nacimiento.
				var date = new Date(reverseDate(birthDate, "/"));

				// Se pudo generar una fecha válida.
				if(!isNaN(date.getDate()) && !isNaN(date.getMonth()) && !isNaN(date.getFullYear())) {
					// Se suman los años mínimos.
					date.setFullYear(date.getFullYear() + limitAge);

					var today = new Date();

					// Sin tiempo, sólo fecha.
					date.setHours(0, 0, 0, 0);

					return today >= date;
				}
			}

			return false;
		};
		
		/**
		 * Utilería para voltear una fecha dada, separando por separador:
		 * "2018-04-26" regresaría "26-04-2018".
		 * y viceversa.
		 */
		function reverseDate(fecha, separador) {
			// La fecha provista no es nula y su longitud es exactamente igual a 10, por los separadores.
			if(fecha != null && fecha.length == 10) {
				var particion = fecha.split(separador);
				
				if(particion.length == 3) {
					return particion[2] + separador + particion[1] + separador + particion[0];
				}
			}
			
			return "";
		};
		
		/**
		 * Utilería que regresa una fecha formateada.
		 * fecha: cadena con la fecha a formatear.
		 * noDay: buleano para agregar o no el nombre del día de la fecha.
		 * noYear: buleano para agregar o no el año.
		 */
		function getPrettyFormatDate(fecha, noDay, noYear) {
			var date = new Date(fecha.replace(/-/g, '\/'));
			
			if(!isNaN(date.getDay()) && !isNaN(date.getDate()) && !isNaN(date.getMonth())) {
				var formato = "";
				
				if(!noDay) {
					formato += catalogos.dias[date.getDay()] + ", "; 
				}
				
				formato += date.getDate() + " de " + catalogos.meses[date.getMonth()]; 
				
				if(!noYear) {
					formato += " de " + date.getFullYear(); 
				}
				
				return formato;				
			}
			
			return fecha;
		};
		
		/**
		 * Función que regresa una cadena para concatener, en la cual se especifica si la visita sería hoy,
		 * mañana o algún otro día.
		 * Recibe un string con la fecha en formato: AAA/mm/dd.
		 */
		function todayOrTomorrow(date) {
			if(date != null) {
				// día de la visita.
				var visit = new Date(date.replace(/-/g, '\/'));
				
				// día actual.
				var today = new Date();
				// Sin tiempo, sólo fecha.
				today.setHours(0, 0, 0, 0);
						
				// La fecha de visita es hoy.
				if(today.getTime() == visit.getTime()) {
					return "día de <span style='font-weight: bold;'>Hoy</span>";
				} else { // No es hoy.
					today.setDate(today.getDate() + 1);
					
					// Es mañana la fecha de visita.
					if(today.getTime() == visit.getTime()) {
						return "día de <span style='font-weight: bold;'>Mañana</span>";
					} else { // Entonces, la fecha será.
						return "día <span style='font-weight: bold;'>" + visit.getDate() + "/" 
							+ catalogos.meses[visit.getMonth()] + "</span>";
					}
				}
			}			
			
			return "";
		};
		
		/**
		 * Función listener para el combo de fechas.
		 */
		$scope.onChangeDate = function() {
			if($scope.pestaniaSeleccionada){
				$scope.selectedPeriodAval = $scope.selectedDateAval.periodos[0];
				
				$scope.visitDateAval = getPrettyFormatDate($scope.selectedDateAval.fecha, false, true);
				$scope.visitTimeAval = $scope.selectedPeriodAval.periodo;
				$scope.visitIdPeriodAval = $scope.selectedPeriodAval.id;
				
			}else{
				$scope.selectedPeriod = $scope.selectedDate.periodos[0];
				
				$scope.visitDate = getPrettyFormatDate($scope.selectedDate.fecha, false, true);
				$scope.visitTime = $scope.selectedPeriod.periodo;
				$scope.visitIdPeriod = $scope.selectedPeriod.id;
				
			}
		};
		
		/**
		 * Function listener para el combo de periodos. 
		 */
		$scope.onChangePeriod = function() {
			if($scope.pestaniaSeleccionada){
				$scope.visitTimeAval = $scope.selectedPeriodAval.periodo;
				$scope.visitIdPeriodAval = $scope.selectedPeriodAval.id;
			}else{
				$scope.visitTime = $scope.selectedPeriod.periodo;
				$scope.visitIdPeriod = $scope.selectedPeriod.id;
			}
		};
		
		/**
		 * Función listener para el check de mostrar más días.
		 */
		$scope.showMoreDays = function() {
			
			if($scope.pestaniaSeleccionada){
				if($scope.comboCompletoAval != undefined){
					
					if($scope.combosAval.length > 3)
						$scope.combosAval = $scope.combosAval.slice(0,3);
					else		
						$scope.combosAval = $scope.comboCompletoAval;
					
					// Se reconfiguran las opciones seleccionadas.
					if($scope.combosAval.length > 0) {
						$scope.visitDateAval = getPrettyFormatDate($scope.combosAval[0].fecha, false, false);
						$scope.visitTimeAval = $scope.combosAval[0].periodos[0].periodo;
						
						$scope.selectedDateAval = $scope.combosAval[0];
						$scope.selectedPeriodAval = $scope.combosAval[0].periodos[0];
					} else {
						$scope.visitDateAval = "";
						$scope.visitTimeAval = "";
						
						$scope.selectedDateAval = null;
						$scope.selectedPeriodAval = null;
					}
					
					// Que surtan efecto los cambios realizados.
					$scope.$apply();
					
				}
			}else{
				if($scope.comboCompleto != undefined){
					
					if($scope.combos.length > 3)
						$scope.combos = $scope.combos.slice(0,3);
					else		
						$scope.combos = $scope.comboCompleto;
					
					// Se reconfiguran las opciones seleccionadas.
					if($scope.combos.length > 0) {
						$scope.visitDate = getPrettyFormatDate($scope.combos[0].fecha, false, false);
						$scope.visitTime = $scope.combos[0].periodos[0].periodo;
						
						$scope.selectedDate = $scope.combos[0];
						$scope.selectedPeriod = $scope.combos[0].periodos[0];
					} else {
						$scope.visitDate = "";
						$scope.visitTime = "";
						
						$scope.selectedDate = null;
						$scope.selectedPeriod = null;
					}
					
					// Que surtan efecto los cambios realizados.
					$scope.$apply();
					
				}				
			}
			
		};
	});
});