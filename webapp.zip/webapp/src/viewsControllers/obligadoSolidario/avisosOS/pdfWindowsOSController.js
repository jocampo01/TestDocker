'use strict';

define(["app"], function (app) {
	
	app.controller("pdfWindowsOSController", function (	$timeout, $scope, $rootScope, ngDialog, generalServiceOS, $location, authService, loginService, modalService, solicitudService, tarjetaService, buroService) {
		
		/** Se inicializan las banderas **/
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		
		$scope.confTipoWindows = configuracion.so.windows;
		$scope.esIpad = configuracion.so.ios;
		$scope.urlDoc = "AvisoPrivacidad.pdf";
		$scope.leyendaFirmar = "Firmar";
		$scope.avisosAceptados = 0;
		$rootScope.firma1 = false;
		$scope.buroCheck = true;
		$scope.status = 1;
		var titleWraper = "";
		var pdfImagenes = true;
		var imagenesArray = null;
		
		if($scope.aceptaPrivacidad)
			titleWraper = "Aviso de Privacidad";
		else
			titleWraper = "Autorización para Consulta de Historial Crediticio";
		
		/** La validación se realiza en base al documento seleccionado con ateriodad **/
		if($rootScope.isAvisoOS){
			$scope.leyendaBoton = "Aviso de Privacidad";
			$scope.aceptaPrivacidad = true;
			$scope.esBuro = false;
		}else if($rootScope.isBuroOS){					
			$scope.leyendaBoton = "Buró de Crédito";
			$scope.aceptaPrivacidad = false;
			$scope.esBuro = true;
		}else if($rootScope.isContratoCaratulaOS){
			$scope.leyendaBoton = "Contrato y Carátula de Crédito";
		}else if($rootScope.isSolicitudOS){
			$scope.leyendaBoton = "Solicitud de Crédito";
		}else if($rootScope.isSeguroClienteOS){
			$scope.leyendaBoton = "Seguro Vidamax";
		}else if($rootScope.isSeguroCartaOS){
			$scope.leyendaBoton = "Seguro Vidamax";
		}
		
		/** Punto de Inicio **/
		$scope.init = function()
	    {		
			if( messageData ){
	    		$scope.setContentPage();
	    		$rootScope.waitLoaderStatus = LOADER_HIDE;
	    		$scope.setHeaderWrapper(1,$scope.ngDialogData.title);		
	    	}
	    
	    };
		
	    /** Se prepara para invocar el executeAxtion **/
		$scope.setHeaderWrapper=function(visible,mensaje){
			var x={nombre:"tituloVisorPDF", mostrar:visible,titulo:mensaje};
			if(configuracion.so.ios){
				$rootScope.executeAction( "avisosDivId", "setHeaderWrapperResponse",x);
			}
		};
		
		/** Reespuesta del componente **/
		$scope.setHeaderWrapperResponse=function(ipadResponse){
			$rootScope.loggerIpad("setHeaderWrapperResponse", null, ipadResponse);
			if( ipadResponse.codigo == RESPONSE_CODIGO_EXITO_IPAD )
				console.log("OK");
			else
				$rootScope.message("Visor Firmas",[ipadResponse.mensaje], "Aceptar");
		};

		$scope.setHeaderWrapper(1,$scope.ngDialogData.title);	

		
		$scope.regresa = function (){	
			$scope.setHeaderWrapper(0,"");	
			$scope.closeThisDialog();

		};
		

		/** Esta fusión muestra el mensaje (por políticas internas y para continuar con la solicitud de crédito se requiere la aceptación del Contrato de Crédito) **/
		$scope.negacion = function (value, element, atributo){
			var foo = function (){
				$scope.acepta1 = false;
				$scope.acepta2 = false;
				$scope.acepta3 = false;
				$scope.buroCheck = true;
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			};
			
			if(value == true && $scope.buroCheck){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$scope.buroCheck = false;
				var aviso =  ["Por políticas internas y para continuar con la solicitud del crédito se requiere la aceptación de" + $scope.ngDialogData.negacionCheck.textoMensaje];
				$rootScope.message("Notificación", aviso, "Aceptar", null, "bgGris", "btnGrisD", foo, null, null, "frenteShow");
			}
		}

		/** Muestra los modales de tratamiento de datos **/
		$scope.negacion2 = function (value, check){
			var foo = function (){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.acepta4 = false;
				$scope.acepta5 = false;
				$scope.buroCheck = true;
			};
			if ($rootScope.isfirmaDomiciliarOS){
			
			}else{
				if(value == true && $scope.buroCheck ){
					switch (check) {
					case 1 :
						$rootScope.solicitudJson.transferenciaDatos = 1;
						break;
					case 2 :
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						var aviso = ["Sin la aceptación del Aviso de Privacidad, no es posible continuar con la solicitud."];
						$scope.buroCheck = false;
						$rootScope.message("Notificación", aviso, "Aceptar", null, "bgGris", "btnGrisD", foo, null, null, "frenteShow");
						break;
					case 3 :
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						var aviso = ["Sin la aceptación de la consulta de Buró de Crédito, no es posible continuar con la solicitud."];
						$scope.buroCheck = false;
						$rootScope.message("Notificación", aviso, "Aceptar",  null, "bgGris", "btnGrisD", foo, null,null, "frenteShow");
						break;	
					}
				}else{
					if(value == false && check == 1){
						$rootScope.solicitudJson.transferenciaDatos = 0;
					}
				}
			}
		}
		
		/** Cuenado se selecciona continuar invoca las siguiente funciones **/
		$scope.aceptar = function(){
			$scope.setHeaderWrapper(0,"");	
			$scope.confirm();
		}
		
		/** Al seleccionar la opción de firmar, invoca el modal de la firma 
		 *  Una vez firmado y al seleccionar la opción de guardar invoca la función firmar 
		 **/
		$scope.firmar = function(){
			if($rootScope.title != ""){
				if ($scope.confTipoWindows){
					$rootScope.capturarFirmaWV("avisosDivId","responseFirmaWV",{titulo:$rootScope.title});
				}else{
					modalService.firmas($rootScope.title)
					.then(
							function(exito){
								$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
							},function(error){
								$scope.responseFirmaWV({codigo: 1});
							});
				}
			}
		}
		
		/** En esta sección se envía la raespuesta del componete **/
		$scope.responseFirmaWV = function(responseWV){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if( responseWV.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
				if($rootScope.isAvisoOS){
					$scope.avisosAceptados++;
					$rootScope.imgPrivacidadOS = responseWV.img64;
					$rootScope.firmaPrivacidadOS = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
					$rootScope.isFirmaAvisoOS = true;
				}else if($rootScope.isBuroOS){					
					$scope.avisosAceptados++;
					$rootScope.imgBuroOS = responseWV.img64;
					$rootScope.firmaBuroOS = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
					$rootScope.isFirmaBuroOS = true;
				}else if($rootScope.isContratoCaratulaOS){
					$scope.avisosAceptados++;
					$rootScope.imgCaratulaOS = responseWV.img64;
					$rootScope.firmaCaratulaOS = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
					$rootScope.isFirmaCaratulaOS = true;
				}else if($rootScope.isSolicitudOS){
					$scope.avisosAceptados++;
					$rootScope.imgSolicitudOS = responseWV.img64;
					$rootScope.firmaSolicitudOS = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
					$rootScope.isFirmaSolicitudOS = true;
				}else if($rootScope.isSeguroClienteOS){
					$scope.avisosAceptados++;
					$rootScope.imgSeguroClienteOS = responseWV.img64;
					$rootScope.firmaSeguroClienteOS = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
					$rootScope.isFirmaSeguroOS = true;
				}else if($rootScope.isSeguroCartaOS){
					$scope.avisosAceptados++;
					$rootScope.imgSeguroCartaOS = responseWV.img64;
					$rootScope.firmaSeguroCartaOS = "data:image/png;base64," + responseWV.img64.replace("data:image/png;base64,","");
					$rootScope.isFirmaCartaOS = true;
				}
				$scope.leyendaFirmar = "Continuar";
			}	
		};	
	});
	
});