'use strict';

define(["app"], function (app) {

	app.factory("validateServiceOS", function($rootScope, $location, sessionService, modalService, generalServiceOS){
		
		/** Inicializamos las variables globales **/
		
		var service = {};
		
		var dMenores=null;
		var dMayores=null;
		var arrayPepAnt=null;
		var arrayPep2Ant=null;
		var coloniaOpc = false;
		var dependientes = false;
		var cambioFlujoEfectivo = false;
		
		var seccionId = "";
		var objColonia = "";
		var seccionDestino = "";
		var pathDestinoFinal = "";
		var respaldoJsonString = "";
		var solicitudJsonString = "";
		var respaldoJsonStringGastos = "";
		var colorDialogo = "verdeOS";
		var botonDialogo = "btn verdeOS";
		
		service.path = function( pathDestino ){
			
			/** Aquí inicia todo el relajo la función path es lo primero que se ejecuta 
			 *  Cargamos las variables globales e inicializamos
			 **/
			
			seccionId = "";
			dMenores = null;
			dMayores = null;
			coloniaOpc = false;
			dependientes = false;
			cambioFlujoEfectivo = false;
			pathDestinoFinal = pathDestino;
			seccionDestino = pathSeccion ["#"+pathDestino];
			seccionId = pathSeccion[  window.location.hash ];
			respaldoJsonString = generalServiceOS.getRespaldo();
			respaldoJsonStringGastos = generalServiceOS.getRespaldo();
			solicitudJsonString = generalServiceOS.delete$$hashKey($rootScope.solicitudOSJson);
			
			service.limpiaMascaras();
			
			/** Antes de redirigir lo que hacemos es saber hacia a donde tenemos que redireccionar **/
			
			switch( seccionId ){
			
				case SECCION_PERSONALES+"1":
					seccionPersonales();
					break;
					
				case SECCION_HOGAR+"1":
					seccionHogar();
					break;
					
				case SECCION_EMPLEO+"1":
					mostrarModal();
					break;
					
				case SECCION_INGRESOS_GASTOS+"1":
					seccionGastos();
					break;
					
				case SECCION_DOCUMENTOS+"1":
					seccionDocumentos();
					break;
					
				case SECCION_CONTRATOS+"1":
					break;
					
				case SECCION_CLIENTES+"1":
					seccionPersonales();
					break;
			}
	
		};
		
		
		/** Función que invoca el modal del aviso **/
		
		var mostrarModal = function(){
			
			if( ( respaldoJsonString != solicitudJsonString || cambioFlujoEfectivo || dependientes) && seccionDestino != seccionId ){
			
			modalService.confirmModal( "Advertencia", [ "Aun no ha guardado los datos ¿Desea continuar?", "Si da click en \"Aceptar\" se perderán los cambios." ], 
													"Cancelar", "Aceptar", colorDialogo, "btnCancel", botonDialogo ).then( 
				function(confirm){
					/** Esto se ejecuta cuando selecciona aceptar y se realizan las últimas validaciones, para redirigir a ocho pasos del cliente **/
					
					if( seccionId != ( SECCION_INGRESOS_GASTOS+"1") )
						$rootScope.solicitudOSJson = JSON.parse(respaldoJsonString);
					
					
					switch(seccionId){
					
					case SECCION_PERSONALES +"1":	
						$rootScope.solicitudOSJson.cotizacion.clientes[0].foto = $rootScope.fotoAnteriorOS;
						$rootScope.fotoOS = $rootScope.fotoanteriorOS1;
						break;
						
					case SECCION_HOGAR+"1": 
						if( $rootScope.objetoColoniaSeleccionadoOS != undefined && $rootScope.objetoColoniaSeleccionadoOS != "" && $rootScope.objetoColoniaSeleccionadoOS.desc )
							$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.objetoColoniaSeleccionadoOS.desc;
						break;
					
					case SECCION_INGRESOS_GASTOS+"1":
						$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo = JSON.parse(respaldoJsonString);
						$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores=dMenores;
						$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores=dMayores; 
						break;
					
					case SECCION_CLIENTES+"1":
						$rootScope.solicitudOSJson.cotizacion.clientes[0].foto = $rootScope.fotoAnteriorOS;
						$rootScope.fotoOS = $rootScope.fotoanteriorOS1;
						if( $rootScope.objetoColoniaSeleccionadoOS != undefined && $rootScope.objetoColoniaSeleccionadoOS != "" && $rootScope.objetoColoniaSeleccionadoOS.desc )
							$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.objetoColoniaSeleccionadoOS.desc;
						break;
					}
					
					$rootScope.coloniaOpcionalOS = "";
					generalServiceOS.locationPath(pathDestinoFinal);
					
					
					
				},function(cancel){
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					if( seccionId == (SECCION_HOGAR+"1") || (SECCION_CLIENTES+"1") == seccionId ){
						
						if(objColonia != "")
							$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].colonia = objColonia;
						
						if(coloniaOpc)
							$rootScope.objetoColoniaSeleccionadoOS.desc = "NO SE ENCUENTRA COLONIA";
					}
					
					
					if ( seccionId == (SECCION_PERSONALES+"1" ) || (SECCION_CLIENTES+"1") == seccionId){
						
						for (var i = 0; i < $rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS.length; i++){
							
							if ($rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS[i].numero == 1){
								$rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS[i] = arrayPepAnt;
								
							}else{
								
								$rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS[i] = arrayPep2Ant;
								
							}
						}
					}
					console.log("no continuar");						
				}
			);
			
			}
			
			else
				generalServiceOS.locationPath(pathDestinoFinal);
		}
		
		
		
		/** Validaciones para la sección de datos del hogar **/
		
		var seccionHogar = function(){
			
			if($rootScope.coloniaOpcionalOS != "" || ($rootScope.objetoColoniaSeleccionadoOS != undefined && $rootScope.objetoColoniaSeleccionadoOS != "" && $rootScope.objetoColoniaSeleccionadoOS.desc == "NO SE ENCUENTRA COLONIA")){
				coloniaOpc=true;
				$rootScope.objetoColoniaSeleccionadoOS.desc=$rootScope.coloniaOpcionalOS;
			}
			
			if( $rootScope.objetoColoniaSeleccionadoOS != undefined && $rootScope.objetoColoniaSeleccionadoOS != "" && $rootScope.objetoColoniaSeleccionadoOS.desc ){
				objColonia = $rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].colonia;
				$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].colonia = $rootScope.objetoColoniaSeleccionadoOS.desc;
				solicitudJsonString = generalServiceOS.delete$$hashKey($rootScope.solicitudOSJson);
			}
			mostrarModal();
		}
		
		/** Validaciones para la sección de datos datos básicos **/
		var seccionPersonales = function(){
			
			var respaldoBasico = JSON.parse(respaldoJsonString);	
			
			for (var i = 0; i < $rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS.length; i++){
					if ($rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS[i].numero == 1){
						arrayPepAnt = $rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS[i];
					}else{
						arrayPep2Ant = $rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS[i];
					}
				}
				
				for (var i = 0; i < $rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS.length; i++){
					if ($rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS[i].numero == 1){
						if($rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS[i].status == 0 &&
						   $rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS[i].status == respaldoBasico.cotizacion.clientes[0].preguntaPEPS[i].status )
							$rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS[i] = respaldoBasico.cotizacion.clientes[0].preguntaPEPS[i];
					}else{
						if($rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS[i].status == 0 &&
						   $rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS[i].status == respaldoBasico.cotizacion.clientes[0].preguntaPEPS[i].status )
							$rootScope.solicitudOSJson.cotizacion.clientes[0].preguntaPEPS[i]=respaldoBasico.cotizacion.clientes[0].preguntaPEPS[i];
					}
				}
				
				
				
				
					angular.forEach( $rootScope.flujoEfectivoOS, function(ig){
						try{	
							var monto = parseInt(generalServiceOS.cleanValue( ig.monto ));
							if(monto == 0)
								ig.monto = "";
						}catch(e){ }																			
					});
				
					var newFlujoEfectivo=JSON.stringify($rootScope.flujoEfectivoOS, function (key, val) { 
						 if (key == '$$hashKey')  
							 return undefined; 
						  
						  return val; 
					});
					

					if (generalServiceOS.flujoEfectivo != newFlujoEfectivo)
						cambioFlujoEfectivo = true;
				
					if( (SECCION_CLIENTES+"1") == seccionId ){
						seccionHogar();
					}else{
						mostrarModal();
					}
						
		}
		
		
		
		var seccionGastos = function(){
			
			
			// RESPALDO: cambiamos formato del monto quitando signo pesos y comas para dejarlo en entero /
			dMenores = respaldoJsonString.split('/')[1];
			
			if(dMenores == "null" || dMenores == "")
				dMenores = null;
			else 
				dMenores = parseInt(dMenores);
			
			dMayores = respaldoJsonString.split('/')[2];
			
			if(dMayores == "null" || dMayores == "")
				dMayores = null;	
			else 
				dMayores = parseInt(dMayores);
			
			
			respaldoJsonString = respaldoJsonString.split('/')[0];
			
			var flujoEfectivoRespJson = JSON.parse(respaldoJsonString);
			
			angular.forEach( flujoEfectivoRespJson, function(ig){
				try{	
					var monto = parseInt(generalServiceOS.cleanValue( ig.monto ));
					if(monto >= 0)
						ig.monto = monto;							
					
				}catch(e){ }																			
			});
			
			
			if( generalServiceOS.isEmpty($rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores +""))
				$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores=null;
			else
				$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores = parseInt($rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores);
				
			if(generalServiceOS.isEmpty($rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores+""))
				$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores=null;
			else
				$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores = parseInt($rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores);
				
			if(dMenores != $rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores)
				dependientes=true;
			if(dMayores != $rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores)
				dependientes=true;
			
			respaldoJsonString = generalServiceOS.delete$$hashKey(flujoEfectivoRespJson);
			
			// ACTUAL: cambiamos formato del monto quitando signo pesos y comas para dejarlo en entero /
			var ff = new Array();
			
			angular.forEach( $rootScope.flujoEfectivoOS, function(ig){
				try{	
					var monto = parseInt(generalServiceOS.cleanValue( ig.monto ));
					if(monto >= 0){
						var gasto = { idTipo:ig.idTipo, tipoDes:ig.tipoDes, idConcepto:ig.idConcepto, conceptoDes:ig.conceptoDes, monto:monto };							
						ff.push(gasto);								
					}
					
				}catch(e){ }																			
			});														
			
			
			solicitudJsonString = generalServiceOS.delete$$hashKey(ff);				
			$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo = JSON.parse(solicitudJsonString);
			
			mostrarModal();
		}
		
		
		var seccionDocumentos = function(){
			if (	!configuracion.origen.tienda  ||  
			   (($rootScope.userSession.idPuesto == PUESTO_GERENTE 
				|| $rootScope.userSession.idPuesto == PUESTO_GERENTE_PRUEBA || 
			   ($rootScope.sucursalSession!=null  && generalServiceOS.isCanalExterno($rootScope.sucursalSession.idCanal) )  )  && 
			    $rootScope.solicitudOSJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.docvalidacionPendienteOS )){
				
					solicitudJsonString = respaldoJsonString;
					$rootScope.solicitudOSJson = JSON.parse(respaldoJsonString);
			}
			mostrarModal();
		} 
		

		
		service.limpiaMascaras = function()
		{
			
			var arrayInputs = document.getElementsByTagName( "input" );
						
			for( var i = 0; i < arrayInputs.length; i++ ){
				
				var currentInput = arrayInputs[i];
				
				if( currentInput.hasAttribute('formato') && currentInput.hasAttribute('valor') ){
									
					var format = currentInput.getAttribute('formato');
					var model = currentInput.getAttribute('ng-model');
					
					if( currentInput.hasAttribute('valor')){
						var etiquetaValor = currentInput.getAttribute('valor');
					}
					
					var newValue = currentInput.value;
					
					var returnObj = generalServiceOS.limpiaFormato( newValue, format );
					
					switch( format ){
						case 'NIP-#':
								if( newValue ){
									$rootScope.$eval( etiquetaValor + "=" + parseInt(returnObj) );
								}else{
									console.warn( 'Be careful, {' + etiquetaValor + '} can\'t exe instanced' );
									$rootScope.$eval( etiquetaValor + "=''" );
								}
							break;
						case 'NIP-$':
								if( newValue ){
									$rootScope.$eval( etiquetaValor + "=" + parseInt(returnObj) );
								}else{
									console.warn( 'Be careful, {' + etiquetaValor + '} can\'t exe instanced' );
									$rootScope.$eval( etiquetaValor + "=''" );
								}
							break;
						case 'LM':
							break
						case 'Lm':
							break
						case 'M':
							break
						case 'm':
							break
						default:
								if( newValue || newValue == ""){
									$rootScope.$eval( etiquetaValor + "='" + returnObj+ "'");
								}
								
					}/* END SWITCH */
					
				}
				
			}/* END FOR */
						
		};
		
		
		return service; 
				
		
	});
});