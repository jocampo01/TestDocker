'use strict';

define(["app"], function (app) {
	
	app.controller("contratosOSController", function ($timeout, $scope, $rootScope, solicitudService, generalServiceOS, modalService, buroService, messageData, validateService, documentosService, obligadoSolidarioService) {
		
		/**********************
		 * Varibales globales *
		 **********************/
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		$scope.pestaniaSeleccionada = true;
		$scope.contratosSinFirma = [];
		$scope.contratosConFirma = [];
		$scope.contratosFirmados = [];
		$scope.aviso = false;
		$scope.buro = false;
		$scope.caratula = false;
		$scope.seguro = false;
		$scope.carta = false;
		$scope.muestraOpcionesDocumentos = false;
		var formaEnvioFirmas = true;
		$rootScope.solicitudOSJson.contratos.contrato[2].descripcion = "Contrato de crédito";
		/**********************************************
		 * Funciones principales para cargar la vista *
		 **********************************************/
		$scope.init = function(){
			/*\Se agrega un evento para la bitacora\*/
//			(Contratos)
			$rootScope.addEvent( BITACORA.SECCION.contratosCoacreditado.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, $rootScope.solicitudOSJson.contratos.porcentaje, BITACORA.SECCION.contratosCoacreditado.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
			if (configuracion.origen.tienda){
				$rootScope.validarTienda = true;
			}else{
				$rootScope.validarTienda = false;
			}
			
			/** Se colocan en arreglos, los contratos y se clasifican por firmados y no firmados **/
			for(var i=0;i<$rootScope.solicitudOSJson.contratos.contrato.length;i++){
				if( i < 3){
					if($rootScope.solicitudOSJson.contratos.contrato[i].statusFirma == 1 || $rootScope.solicitudOSJson.contratos.contrato[i].statusFirma == 2){
						$scope.contratosConFirma.push($rootScope.solicitudOSJson.contratos.contrato[i]);
					}else if($rootScope.solicitudOSJson.contratos.contrato[i].idContrato == "3" || $rootScope.solicitudOSJson.contratos.contrato[i].statusFirma == 0){
						$scope.contratosSinFirma.push($rootScope.solicitudOSJson.contratos.contrato[i]);
						$scope.contratosFirmados.push({firma: false});
					}
				}
			}
			
			var statusConFirma = ($scope.contratosConFirma.length >0)?true:false;
			var statusSinFirma = ($scope.contratosSinFirma.length >0)?true:false;
			
			if(statusSinFirma){
				$scope.pestaniaSeleccionada = false;
			}else{
				$scope.pestaniaSeleccionada = true;
			}
			
			if(statusConFirma && statusSinFirma){
				$scope.muestraOpcionesDocumentos = true;
			}else{
				$scope.muestraOpcionesDocumentos = false;
			}
			
			$scope.cargaPagina();
			$timeout(function(){$scope.showPage = messageData;}, 1);
			$scope.setContentPage();
		};
		
		$scope.cargaPagina = function(){
			if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
		
			generalServiceOS.setMapping( MODEL_VISTAS_JSON );
			generalServiceOS.setRespaldo($rootScope.solicitudOSJson);
			
			$scope.firma1Ant = $rootScope.solicitudOSJson.contratos.contrato[0].statusFirma;
			$scope.idPersona1Ant = $rootScope.solicitudOSJson.contratos.contrato[0].idPersona;
			$scope.firma2Ant = $rootScope.solicitudOSJson.contratos.contrato[1].statusFirma;
			$scope.idPersona2Ant = $rootScope.solicitudOSJson.contratos.contrato[1].idPersona;
			
			$scope.nombreCte = $scope.solicitudOSJson.cotizacion.clientes[0].nombre +" " +$scope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno+" " +$scope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno;
			
			$scope.contratos();
			$scope.marcasSoliciud();
			estilos();
		}
		
		$scope.setContentPage = function(){
	    		if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";

			$scope._txtCheckContratos = generalServiceOS.getDataInput("CONTRATOS","TEXTO CHECK CONTRATOS", $scope.origen);
			$scope._nombreContrato = generalServiceOS.getDataInput("CONTRATOS","TEXTO CONTRATO", $scope.origen);
			$scope._nombreSolicitud = generalServiceOS.getDataInput("CONTRATOS","TEXTO SOLICITUD CREDITO", $scope.origen);
	    };
	    
		$scope.contratos = function(){
		    $('.contratos').each(function(){  
		        var highestBox = 0;
		        $('.texto').css('height', '');
		        $(this).find('.texto').each(function(){
		        	
		        	console.log( $(this).outerHeight() + " <-> " +  highestBox );
		        	
		            if( $(this).outerHeight() > highestBox){  
		                highestBox = $(this).outerHeight();  
		            }
		        })
		        $(this).find('.texto').height(highestBox);
		    });
		}
		
		$scope.marcasSoliciud = function (){
			if((($scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.sinLiberar && $scope.solicitudStatus == STATUS_SOLICITUD.autorizada.id) || ($scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.condicionadoMesa && $scope.solicitudStatus == STATUS_SOLICITUD.autorizada.id)) || ($scope.solicitudStatus == STATUS_SOLICITUD.condicionada.id && $rootScope.solicitudOSJson.idCondicion == STATUS_SOLICITUD.condicionada.idCondicion.expIncompleto)){
				$rootScope.marcas = true;
			} else if(($scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.expCompleto || $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.expValGerente) && $scope.solicitudStatus == STATUS_SOLICITUD.autorizada.id ){
				$rootScope.marcas = true;
			} else {
				$rootScope.marcas = false;
			}
		}
		
		/** Estilos para las pestañas de coumentos pendientes por firmar **/
		function estilos(){
			if($scope.pestaniaSeleccionada){
				$scope.estiloDocumentosPendientes = {
						'flex-direction': 'row',
						'box-sizing': 'border-box',
						'display': 'flex',
						'align-items': 'center',
						'align-content': 'center',
						'justify-content': 'center',
						'height': '100%',
						'width': '50%',
						'border-bottom': '1px solid #ca9963',
						'border-left': '1px solid #ca9963',
						'border-right': '1px solid #ca9963',
						'color': '#ca9963',
						'background-color': '#e3fbfa'
				}
				
				$scope.estiloDocumentosFirmados = {
						'flex-direction': 'row',
						'box-sizing': 'border-box',
						'display': 'flex',
						'align-items': 'center',
						'align-content': 'center',
						'justify-content': 'center',
						'height': '100%',
						'width': '50%',
				}
			}else{
				$scope.estiloDocumentosFirmados = {
						'flex-direction': 'row',
						'box-sizing': 'border-box',
						'display': 'flex',
						'align-items': 'center',
						'align-content': 'center',
						'justify-content': 'center',
						'height': '100%',
						'width': '50%',
						'border-bottom': '1px solid #ca9963',
						'border-left': '1px solid #ca9963',
						'border-right': '1px solid #ca9963',
						'color': '#ca9963',
						'background-color': '#e3fbfa'
				}
				
				$scope.estiloDocumentosPendientes = {
						'flex-direction': 'row',
						'box-sizing': 'border-box',
						'display': 'flex',
						'align-items': 'center',
						'align-content': 'center',
						'justify-content': 'center',
						'height': '100%',
						'width': '50%',
				}
			}
		}
					
		$scope.addOverflow=function(){
			$( "html" ).removeClass( "overflowHiddenHTML");
			$( "body" ).addClass( "overflowInitialHTML");
		}

	    $scope.regresa = function (){
			generalServiceOS.locationPath("/ochoPasosOS");
		};		
		
		/**********************************************************
		 * Funciones que hacen la interaccion con los componentes *
		 **********************************************************/
		
		/** Elige los contratos que se mostraran en el front, 1 es firmados, 2 es pendientes **/
		$scope.tipoContratos = function(tipo){
			if(tipo==1){
				$scope.pestaniaSeleccionada = true;
			}else if(tipo == 2){
				$scope.pestaniaSeleccionada = false;
			}
			
			estilos();
		}
		
		/**Carga la información del contrato seleccionado ya sea como un contrato firmado o pediente por firmar
		 * Declaramos las banderas que se encargaran de indentifica el tipo de contrato seleccionado 
		 **/
		$scope.visualizaDocumento =  function (value,visualizar){
			
			$rootScope.contratoIndex = visualizar;
			$scope.contratoSeleccionado = value;
			$scope.muestraAvisos = false;
			$rootScope.isBuroOS = undefined;
			$rootScope.isAvisoOS = undefined;
			$rootScope.isSolicitudOS = undefined;
			$rootScope.isSeguroCartaOS = undefined;
			$rootScope.isSeguroClienteOS = undefined;
			$rootScope.isContratoCaratulaOS = undefined;
			/** Tomados el ID del contrato para validarlo en un switch **/
			var index3 =  $rootScope.solicitudOSJson.contratos.contrato.map(function(d){
    				return d["idContrato"];
    			}).indexOf (value);
			
			if (index3 >= 0)
				$scope.firma1Ant = $rootScope.solicitudOSJson.contratos.contrato[value-1].statusFirma;
			
			/** El ID seleccionado del contrado debe de ser alguno de los que se encuentran abajo. El switch inicial el proceso para cargar la vista del contrato seleccionado**/
			switch (value){
				case "1": 
					$scope.tituloAviso = generalServiceOS.getDataInput("CONTRATOS","TITULO MODAL CONTRATOS 1", $scope.origen);
					$scope.urlDoc = "AvisoPrivacidadOS.html";
					$rootScope.isAvisoOS = true;
					$rootScope.title = "Firma Aviso de Privacidad";
					$scope.negacionCheck = {texto:"", visible: false, textoMensaje:"", botonAceptar: "Aceptar"};
	                 break;
	            case "2":  
	            	$scope.tituloAviso = generalServiceOS.getDataInput("CONTRATOS","TITULO MODAL CONTRATOS 2", $scope.origen);
					$scope.urlDoc = "BuroCreditoOS.html";
					$rootScope.isBuroOS = true;
					$rootScope.title = "Firma Buro de Crédito";
					$scope.negacionCheck = {texto:"", visible: false, textoMensaje:"", botonAceptar: "Aceptar"};
	                 break;
	            case FIRMA_CARATULA_CLIENTE.id:  
	            	$scope.tituloAviso = $scope._nombreContrato;
	            	$scope.tituloFirma = "Contrato de Crédito";
	            	$scope.urlDoc = "ContratoCaratulaCreditoOS.html";
					$scope.muestraAvisos = true;
					$rootScope.isContratoCaratulaOS = true;
					$rootScope.title = "Firma Contrato de Crédito";
					$scope.negacionCheck ={texto:$scope._txtCheckContratos.texto, visible: true, textoMensaje: "l Contrato de Crédito.", botonAceptar: "Aceptar" };
	                 break;
	            case FIRMA_SOLICITUD_CREDITO.id:  
	            	$scope.tituloAviso = $scope._nombreSolicitud;
	            	$scope.tituloFirma = "Contrato, Carátula y Solicitud de Crédito";
	            	$scope.urlDoc = "SolicitudCreditoOS.html";
					$rootScope.isSolicitudOS = true;
					$rootScope.title = "Firma Solicitud de Crédito";
					$scope.negacionCheck = {texto:$scope._txtCheckContratos.texto, visible: true, textoMensaje: " la Solicitud de crédito.", botonAceptar: "Aceptar"};
	                 break;
	            case FIRMA_SEGURO_CLIENTE.id:  
	            	$scope.tituloAviso = {texto: "Certificado Seguro Vidamax"};
	            	$scope.tituloFirma= "Acepto Seguro VidaMax";
					$scope.urlDoc = "Certificado VidamaxOS.html";
					$rootScope.isSeguroClienteOS = true;
					$rootScope.title = "Firma Seguro Vidamax";
					$scope.negacionCheck ={texto:"No acepto contrato de Seguro VidaMax", visible: true, textoMensaje:"l Seguro VidaMax.", botonAceptar: "Aceptar Seguro" }; 
	                 break;
	            case FIRMA_SEGURO_CARTA.id: 
	            	$scope.tituloFirma="Carta Instrucción";
	            	$scope.tituloAviso = {texto: "Carta Instrucción"};
	            	$scope.urlDoc = "Carta de 14 semanas de atraso VidamaxOS.html";
					$rootScope.isSeguroCartaOS = true;
					$rootScope.title = "Firma Seguro Vidamax";
					$scope.negacionCheck = {texto:"No acepto Carta Instrucción", visible: true, textoMensaje:"l Atraso Vidamax.", botonAceptar: "Aceptar"} 
	                break;
	            default:
	            	$scope.tituloAviso = $scope._nombreSolicitud;
	              	$scope.tituloFirma = "Contrato, Carátula y Solicitud de Crédito";              	              	
	              	$scope.urlDoc = "SolicitudCreditoOS.html";              	              	
	              	$rootScope.title = "Firma Seguro Vidamax";
	              	$scope.negacionCheck = {texto:"", visible: false, textoMensaje:"", botonAceptar: "Aceptar"} 
	            	break;
			}
			
			$timeout( function(){
				construirIframe();
			}, 100 );
			
			$scope._btnNoAceptar = generalServiceOS.getDataInput("CONTRATOS","BOTON NO ACEPTAR", $scope.origen);
			$scope._btnAceptar = generalServiceOS.getDataInput("CONTRATOS","BOTON ACEPTAR", $scope.origen);
			$scope.txtModalContratos = generalServiceOS.getDataInput("CONTRATOS","TEXTO MODAL CONTRATOS", $scope.origen);
			
			/** Carga la ruta del modal para mostrar el contrato **/
			var imagenesArray = "<div ng-include=\"'src/viewsControllers/obligadoSolidario/avisosOS/modalAvisosOS/"+$scope.urlDoc+"'\" ></div>";				
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			
			/** pdfViewModalOS redirige a otro controller para ejecutar el modal del contrato **/
			modalService.pdfViewModalOS($scope.urlDoc, $scope.tituloAviso.texto, $scope._btnAceptar.texto, "Cerrar", null, $scope._btnAceptar.estilo, null, ($scope.creditoInmediato||$rootScope.marcas), $scope.esContratos, $scope.contratosAceptados, $scope.firma1Ant, $scope.txtModalContratos,imagenesArray, $scope.muestraAvisos, $scope.negacionCheck ).then(
					function(aceptar){
						$scope.responseViewPDF({codigo:RESPONSE_CODIGO_EXITO_IPAD});
						$scope.addOverflow();
					},function(noaceptar){
						$scope.responseViewPDF({codigo:1});			
						$scope.addOverflow();
					}
				);				
			};

			$scope.addOverflow=function(){
			$( "html" ).removeClass( "overflowHiddenHTML");
			$( "body" ).addClass( "overflowInitialHTML");
			}
			
			/** En base a la respuesta del modal de la firma activamos la palomita de firmado **/
			$scope.responseViewPDF = function( responseIPAD )
			{
				$rootScope.loggerIpad("responseViewPDF", null, responseIPAD);
				try{
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if( responseIPAD.codigo == 0 )
						$scope.contratosFirmados[$rootScope.contratoIndex].firma = true;
						
					
					/*else{
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						if( $scope.contratosFirmados[$rootScope.contratoIndex].firma != undefined )
						$scope.contratosFirmados[$rootScope.contratoIndex].firma = false;	
					}*/
					
				}catch(e){
					console.log(e.message);
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Error al visualizar el documento."+JSON.stringify(e)], "Aceptar", null);
					console.log( e.message );
					
				}
				
				
			};
			
		
		var construirIframe = function(){
			var divIframe = $( '#contenedor' );
			var iframe = document.createElement('iframe');

			iframe.height= "100%";
			iframe.width = "100%";
			iframe.id = "iframe";
			iframe.src = "pdf/web/viewer.jsp?urlDoc='" + $scope.urlDoc + "'";
			iframe.scrolling = "no";
			iframe.style.marginBottom = "15px";

			divIframe.append( iframe );
		};
		
		var contadorVecesEntro = 0;
				
		/** Se continuan con los contratos en una nueva forma de encolarlos **/
		$scope.continuarContratos = function (){
			var esEncolarFirmas = false;
			var descFirma="", etiqueta="", tipoCadena="", tipoCadenaOS = "", cadena="";
			
			if($rootScope.isFirmaAvisoOS){
				$scope.aviso = true;
				descFirma=DESC_FIRMA_PRIVACIDAD;
				etiqueta=FIRMA_PRIVACIDAD.descripcion; 
				tipoCadena="firmaAviso";
				tipoCadenaOS="firmaAvisoAval";
				cadena=$rootScope.imgPrivacidadOS;
				esEncolarFirmas = true;
				contadorVecesEntro++;
			}else if($rootScope.isFirmaBuroOS){
				$scope.buro = true;
				descFirma=DESC_FIRMA_BURO; 
				etiqueta=FIRMA_BURO.descripcion; 
				tipoCadena="firmaBuro";
				tipoCadenaOS="firmaBuroAval";
				cadena=$rootScope.imgBuroOS;
				esEncolarFirmas = true;
				contadorVecesEntro++;
			}else if($rootScope.isFirmaCaratulaOS || $rootScope.isFirmaSolicitudOS){
				$scope.caratula = true;
				descFirma=DESC_FIRMA_BURO; 
				etiqueta=FIRMAR_CTE_CONTRATOS; 
				tipoCadena=FIRMA_CARATULA_CLIENTE.descripcion; 
				tipoCadenaOS="firmaCaratulaAval";
				cadena=$rootScope.imgCaratulaOS;
				esEncolarFirmas = true;
				contadorVecesEntro++;
			}else if($rootScope.isFirmaSeguroOS){
				$scope.seguro = true;
				descFirma=DESC_FIRMA_BURO;
				etiqueta="Certificado Seguro Vidamax"; 
				tipoCadena="firmaSeguro";
				tipoCadenaOS="firmaSeguroAval";
				cadena=$rootScope.imgSeguroClienteOS;
				esEncolarFirmas = true;
				contadorVecesEntro++;
			}else if($rootScope.isFirmaCartaOS){
				$scope.carta = true;
				descFirma=DESC_FIRMA_BURO;
				etiqueta="Carta instrucción"; 
				tipoCadena="firmaSeguroAtraso"; 
				tipoCadenaOS="firmaSeguroAtrasoAval";
				cadena=$rootScope.imgSeguroCartaOS;
				esEncolarFirmas = true;
				contadorVecesEntro++;
			}
			
			if($scope.origen == "TIENDA"){
				if(esEncolarFirmas){
					if(formaEnvioFirmas){
						$scope.guardarFirmasOnline(tipoCadenaOS, cadena.replace("data:image/png;base64,","").trim());
					}else{
						$scope.guardarFirmasBack(descFirma, etiqueta, tipoCadena, cadena.replace("data:image/png;base64,","").trim());
					}
				}else{
					$scope.guardar();
				}	
			} else{
				$scope.guardar();
			}
		};
		
		/** Elige los contratos que se enviarán en linea **/
		$scope.guardarFirmasOnline = function(tipoCadena, cadena) {
			var request = {
				idSolicitudOS: $rootScope.solicitudOSJson.idSolicitud,
				cadena: cadena,
				tipoCadena: tipoCadena,
				porcentaje: "100",
				rechazoFirma: "0"
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.guardaFirmasBiometricosOS(request).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							
							if($rootScope.isFirmaAvisoOS){
								$rootScope.isFirmaAvisoOS = false;
							}else if($rootScope.isFirmaBuroOS){
								$rootScope.isFirmaBuroOS = false;
							}else if($rootScope.isFirmaCaratulaOS || $rootScope.isFirmaSolicitudOS){
								$rootScope.isFirmaCaratulaOS = false;
								$rootScope.isFirmaSolicitudOS = false;
							}else if($rootScope.isFirmaSeguroOS){
								$rootScope.isFirmaSeguroOS = false;
							}else if($rootScope.isFirmaCartaOS){
								$rootScope.isFirmaCartaOS = false;
							}
							
							$scope.continuarContratos();
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}
					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'guardaFirmasBiometricosOS'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};
		
		/** Elige los contratos que se encolan los documentos **/
		$scope.guardarFirmasBack = function(descFirma, etiqueta, tipoCadena, cadena){
			$rootScope.enviarImagen(
				$rootScope.solicitudOSJson.cotizacion.clientes[0].idPersona,
				"",
				descFirma,
				etiqueta,
				'firmas', {
					ruta: null,
				    idSolicitud: $rootScope.solicitudOSJson.idSolicitud,
				    cadena: cadena,
				    tipoCadena: tipoCadena,
				    nombre: $rootScope.solicitudOSJson.cotizacion.clientes[0].nombre + ' ' + $rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno + ' ' + $rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno,
				    foto: $rootScope.fotoCteOriginalOS
				},
				"responseEnvioFirmas"
			);
		}
		
		/** Elige los contratos en la respuestas de los documentos encolados**/
		$scope.responseEnvioFirmas = function( responseIPAD ){
			$rootScope.loggerIpad("responseEnvioFirmas", null, responseIPAD);
						
			try{
				if( responseIPAD.codigo == 0 ){
					if($rootScope.isFirmaAvisoOS){
						$rootScope.isFirmaAvisoOS = false;
					}else if($rootScope.isFirmaBuroOS){
						$rootScope.isFirmaBuroOS = false;
					}else if($rootScope.isFirmaCaratulaOS || $rootScope.isFirmaSolicitudOS){
						$rootScope.isFirmaCaratulaOS = false;
						$rootScope.isFirmaSolicitudOS = false;
					}else if($rootScope.isFirmaSeguroOS){
						$rootScope.isFirmaSeguroOS = false;
					}else if($rootScope.isFirmaCartaOS){
						$rootScope.isFirmaCartaOS = false;
					}
					
					$scope.continuarContratos();
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("CONTRATOS",[ "Error al encolar archivos." + JSON.stringify(responseIPAD)], "Aceptar", null);
				}
			}catch(e){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("CONTRATOS",[ "Error al encolar archivos."+e.message], "Aceptar", null);
			}
		}
		
		/** Se continuan con los contratos en una nueva forma de guardarlos **/
		$scope.guardar = function(){
			if(contadorVecesEntro){
				var firmadosDocs = 0;
				var porcentajeant = $rootScope.solicitudOSJson.contratos.porcentaje;			
				
				if($scope.aviso){
					$rootScope.solicitudOSJson.contratos.contrato[0].statusFirma = STATUS_CONTRATO.ENVIAD0;
					$rootScope.solicitudOSJson.contratos.contrato[0].idPersona = $rootScope.solicitudOSJson.cotizacion.clientes[0].idPersona;
				}
				
				if($scope.buro){
					$rootScope.solicitudOSJson.contratos.contrato[1].statusFirma = STATUS_CONTRATO.ENVIAD0;
					$rootScope.solicitudOSJson.contratos.contrato[1].idPersona = $rootScope.solicitudOSJson.cotizacion.clientes[0].idPersona;
				}
				
				if($scope.caratula){
					$rootScope.solicitudOSJson.contratos.contrato[2].statusFirma = STATUS_CONTRATO.ENVIAD0;
					$rootScope.solicitudOSJson.contratos.contrato[2].idPersona = $rootScope.solicitudOSJson.cotizacion.clientes[0].idPersona;
					
					//$rootScope.solicitudOSJson.contratos.contrato[3].statusFirma = STATUS_CONTRATO.ENVIAD0;
					//$rootScope.solicitudOSJson.contratos.contrato[3].idPersona = $rootScope.solicitudOSJson.cotizacion.clientes[0].idPersona;
				}
				
				if($scope.seguro){
					$rootScope.solicitudOSJson.contratos.contrato[4].statusFirma = STATUS_CONTRATO.ENVIAD0;
					$rootScope.solicitudOSJson.contratos.contrato[4].idPersona = $rootScope.solicitudOSJson.cotizacion.clientes[0].idPersona;
				}
				
				if($scope.carta){
					$rootScope.solicitudOSJson.contratos.contrato[5].statusFirma = STATUS_CONTRATO.ENVIAD0;
					$rootScope.solicitudOSJson.contratos.contrato[5].idPersona = $rootScope.solicitudOSJson.cotizacion.clientes[0].idPersona;
				}
				    
				for(var i=0;i<$rootScope.solicitudOSJson.contratos.contrato.length;i++){
					if($rootScope.solicitudOSJson.contratos.contrato[i].statusFirma == 1 || $rootScope.solicitudOSJson.contratos.contrato[i].statusFirma == 2){
						firmadosDocs++;
					}
				}
				
	    			$rootScope.solicitudOSJson.contratos.porcentaje = parseInt(((firmadosDocs * 100) / $rootScope.solicitudOSJson.contratos.contrato.length).toFixed(0));
				
	    			$rootScope.waitLoaderStatus = LOADER_SHOW;
	    			obligadoSolidarioService.guardaSeccionOS( { solicitudOSJson: JSON.stringify($rootScope.solicitudOSJson), seccion: 8 } ).then(
	    				function(data){
	    					$rootScope.waitLoaderStatus = LOADER_HIDE;
	
	    					if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
	    						var responseJson = JSON.parse(data.data.respuesta);
	    						
	    						if(responseJson.codigo == 2){
	    							if ($scope.origen == "TIENDA" && (configuracion.so.ios || configuracion.so.windows)){
	    								$scope.enviaContratos();
	    							}
	    							$rootScope.solicitudOSJson = responseJson.data;
	    							
	    							/*\Se agregan eventos para la bitacora\*/
//	    							(coacreditado)																									
	    							$rootScope.addEvent( BITACORA.SECCION.contratosCoacreditado.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.guardar.id, $rootScope.solicitudOSJson.contratos.porcentaje, BITACORA.SECCION.contratosCoacreditado.guardarEnBD );
	    							/*\Se agregan eventos para la bitacora\*/
	    							
	    							$rootScope.porcentajes.secciones[7].porcentaje = $rootScope.solicitudOSJson.contratos.porcentaje;
	    							$rootScope.calculaDocumentos();
	    							generalServiceOS.locationPath("/ochoPasosOS");
	    						}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
	    							var buildJsonDefault=function(){generalServiceOS.buildsolicitudOSJson($rootScope, null);};
	    							$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
	    						}else{
	    							if(responseJson.codigo == ERROR_SOL_RECHAZADA){
	    								var buildJsonDefault=function(){generalServiceOS.buildsolicitudOSJson($rootScope, null);};
	    								$rootScope.message(	"Error en solicitud", [ "La solicitud no puede ser modificada debido a que se encuentra Cancelada o Rechazada." ],
	    										"Aceptar", "/simulador",  "bgRosa" , "btnRosaD",buildJsonDefault);
	    							}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
	    								generalServiceOS.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
	    								generalServiceOS.locationPath("/ficha");
	    							}else{
	    								$scope.DatosAntariores();
	    								$rootScope.message($scope._titulo.texto,["Error al guardar sección. Código " +
	                                     "de error [" + responseJson.codigo + "] no identificado."], 
	                                     "Aceptar", null, "bgRosa", "btnRosaD");
	    							}
	    						}
	    					}else{
	    						$scope.datosAnteriores();
	    						$rootScope.message($scope._titulo.texto,[generalServiceOS.displayMessage(data.data.descripcion)], "Aceptar", null, "bgRosa", "btnRosaD");
	    					}
	    					
	    				}, function(error){
	    					$scope.DatosAntariores();
	    	                $rootScope.waitLoaderStatus = LOADER_HIDE;
	    				}
	    			);
			}else{
				generalServiceOS.locationPath("/ochoPasosOS");
			}
		};
		
		/** Se continuan con los contratos en una nueva forma de enviarlos **/
		$scope.enviaContratos = function(){
			 $rootScope.contratosResponseCita = false;
			$rootScope.executeAction( "firmas", "respuestaContratos",  
					  { nombre:"envioDocumentos", idCliente:$rootScope.solicitudOSJson.cotizacion.clientes[0].idPersona, mostrarSpinner:0, 
                      filtroDocumentos: CONTRATOS_ENVIAR+","+FIRMA_PRIVACIDAD.descripcion+","+FIRMA_BURO.descripcion });
		}
		
		/** Se continuan con los contratos en una nueva forma de respuesta del envio de los documentos **/
		$rootScope.respuestaContratos = function(respuesta){
			$rootScope.contratosResponseCita = true;
			$rootScope.loggerIpad("respuestaContratos", null, respuesta);
			console.log(respuesta);
		}
		
		/** Se continuan con los contratos en una nueva forma de respaldar los datos **/
		$scope.datosAnteriores = function(){
			$rootScope.solicitudOSJson.contratos.contrato[0].statusFirma = $scope.firma1Ant;
            $rootScope.solicitudOSJson.contratos.contrato[0].idPersona = $scope.idPersona1Ant;
            $rootScope.solicitudOSJson.contratos.contrato[1].statusFirma = $scope.firma2Ant;
            $rootScope.solicitudOSJson.contratos.contrato[1].idPersona = $scope.idPersona2Ant;
            $rootScope.solicitudOSJson.contratos.porcentaje = parseInt(porcentajeant);
		}
	});
});