'use strict';

define(["app"], function (app) {

	app.controller("estatusOSController", function ($timeout, $scope, $rootScope, generalService,generalServiceOS) {
		
		$scope.init = function(){	
			if(generalService.existeSolicitud($rootScope.solicitudOSJson)){
				cargaVista();										
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			}else{
				$rootScope.message(SIN_SOLICITUD.titulo, [SIN_SOLICITUD.texto], "Aceptar", "/", null, null);
			}
	    };
	    
		function cargaVista(){	
			$scope.estatus = 1;
			$scope.estatusOS = 1;

			$scope.horas = 24;
			$scope.labelTiempo = "Tiempo aproximado en que será autorizado su crédito";
						
			var respuestaOS = aplicaReglas($rootScope.solicitudOSJson);
			var mensajesOS = respuestaOS.mensajes;
			
			var respuestaCliente = aplicaReglas($rootScope.solicitudJson);
			var mensajesCliente = respuestaCliente.mensajes;
			
			$scope.estatus = respuestaCliente.estatus;
			$scope.estatusOS = respuestaOS.estatus;
			
			$scope.labelVisita = "<span style='font-weight: bold;'>Cliente</span><br /><br /><div style='font-size: 86%;'>" + mensajesCliente + "<br> <span ng-show='estatus == 1' style='font-size: 11px;'>(Si el Coacreditado es rechazado, tu cliente deberá regresar a capturar un nuevo Coacreditado)</span> </div><br /><br />" + "<span style='font-weight: bold;'>Coacreditado</span><br /><br /><div style='font-size: 86%;'>" +mensajesOS + "</div>";
		};

		function aplicaReglas(solicitudJSon, estatus){
			var solicitud = solicitudJSon;
			
			var mensajeOS = [];
			
			
			/**
			 * Valida el estatus de la solicitud de crédito
			 **/
			if(solicitud.idSeguimiento == 3 || solicitud.idSeguimiento == 0){
				estatus = 1;
			}else if(solicitud.idSeguimiento == 5){
				estatus = 2;
			}else if ($rootScope.solicitudOSJson.idSeguimiento == 102 || $rootScope.solicitudOSJson.idSeguimiento == 103 || $rootScope.solicitudOSJson.idSeguimiento == 17){
				estatus = 2;
			}else{
				estatus = 3;
			}
			
			
			/**
			 * Valida que el INE del Coacreditado, esté en estatus 4
			 **/
			var documentosCompletos = true;
			for(var i=0;i<solicitud.documentos.documento.length;i++){
				if(solicitud.documentos.documento[i].status != 4 && solicitud.documentos.documento[i].idDocumento === "1"){
					documentosCompletos = false;
					break;
				}
			}
			
			/**
			 * Valida que esté el contrato de Aviso de Privacidad y Buró de Crédito del Coacreditado
			 **/
			var contratosCompletos = true;
			for(var i=0;i<solicitud.contratos.contrato.length;i++){
				if((solicitud.contratos.contrato[i].idContrato === "1" || solicitud.contratos.contrato[i].idContrato === "2") && solicitud.contratos.contrato[i].statusFirma != 1){
					contratosCompletos = false;
					break;
				}
			}
			
			/**
			 * Valida que esté la foto del Coacreditado
			 **/
			var fotoCompleta = (solicitud.cotizacion.clientes[0].foto === "1")?true:false;
			
			/**
			 * Valida que esté la huella del Coacreditado
			 **/
			var huellaCompleta = (solicitud.cotizacion.clientes[0].huella === "1")?true:false;
			
			/**
			 * Se validan los estatus para bajar a tienda del Coacreditado
			 **/			
			var tieneClienteForaneo = (solicitud.clienteForaneoGuardado > 0)?true:false;
			var tieneSolicitudTienda = (solicitud.idSolicitudTienda > 0)?true:false;
			var tieneFlujoADN = (solicitud.flujoSolicitudADN == 99)?true:false;
			
			
			if(!documentosCompletos && estatus == 2){
				mensajeOS.push("Falta por enviar la Identificación Oficial.");
			}
			
			if(!contratosCompletos && estatus == 2){
				mensajeOS.push("Falta por enviar Contratos.");
			}

			if(!fotoCompleta && estatus == 2){
				mensajeOS.push("Falta por enviar la Foto.");
			}

			if(!huellaCompleta && estatus == 2){
				mensajeOS.push("Falta por enviar la Huela.");
			}

			if((!tieneClienteForaneo || !tieneSolicitudTienda || !tieneFlujoADN) && estatus == 2){
				mensajeOS.push("La solicitud no ha bajado a tienda.");
			}
			
			
			/**
			 * Mensaje en los diferentes estatus de la solicitud
			 **/
			if(estatus == 1){
				mensajeOS.push("La visita del cliente se realizará al concluir la visita del Coacreditado y éste sea autorizado");
			}
			
			if(mensajeOS.length == 0 && estatus == 2){
				mensajeOS.push("En unos dias te visitará uno de nuestros asesores.");
			}
			
			if(estatus == 3){
				mensajeOS.push("La solicitud ya está liberada.");
			}
			
			var mensajesOSCandena = "";
			for(var i=0;i<mensajeOS.length;i++){
				mensajesOSCandena = mensajesOSCandena + mensajeOS[i] + "<br />";
			}
			
			return {estatus: estatus, mensajes: mensajesOSCandena};
		}
		
		$scope.terminar = function() {
			generalService.cleanRootScope($rootScope);
			generalServiceOS.cleanRootScope($rootScope);
			generalService.buildSolicitudJson($rootScope, null);
			generalService.buildSolicitudOSJson($rootScope, null);
			generalService.locationPath("/simulador");
		};
	});
});