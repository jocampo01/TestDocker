'use strict';

define(["app"], function (app) {
	
		app.controller('docsExpedienteOSController', function($q, $timeout, $rootScope, $scope, ngDialog, generalServiceOS, expedienteService, modalService, solicitudService, 
				   											documentosService,clienteUnicoService, validateService, $interval, obligadoSolidarioService) {
			
			var imageAux = "";
		    var adjunta=null;			
			var csstabs = {on:"tab dos cafeLi", off:"tab dos cafeLi active"}; 
			var fotoDocumento = {id:null, imgB64:null};
			var numImagesIpad = 0;									
			var numFotosDocumento = 0;
			var index = 0;
			var size = 0;			
			var subtitulo = {cliente:"Digitaliza los documentos del solicitante", aval:"Digitaliza los documentos del Coacreditado"};
			var subtituloValida = {cliente:"Valida los documentos del solicitante", aval:"Valida los documentos del Coacreditado"};
			var etiquetaFrente  = "";
			var etiquetaReverso = "";		
			var numImgEncoladas = 0;
			var documento = "";
			var subTipoComprobante = null;
			var arrayDocsId = new Array();
			var formatoDocumento = "";
			$rootScope.isExpedienteCte = false;
			$scope.imagenesCargadas = true;
			$scope.cambioIdent=false;		
			$scope.checkDocumentos = {numDocsOK:0, numDocsNotOK:0, docsVisibles:0};
			$scope.listaIdentificacion=[];
			$scope.identificaciones=[];
			$scope.expCompleto = false;
			$scope.expRechazado = false;
			$scope.btnAutorizarDisabled = true;
			$scope.tabCteCSS = csstabs.on;
			$scope.tabAvalCSS = csstabs.off;
			$scope.bloqueaSeccion = false;														
			$scope.accesoValidacion = $scope.$parent.esGerente && $rootScope.userSession.noEmpleado == $rootScope.solicitudJson.idEmpleado;
			$scope.activarValidacion = $rootScope.consultaFuncionalidad.activaBanderaValidaGerente;
			$scope.satatusList = new Array();
			$scope.satatusList[STATUS_PENDIENTE] = {id:STATUS_PENDIENTE, descripcion:"Pendiente", css:'estatus cafeL', img:null};
			$scope.satatusList[STATUS_CAPTURADO] = {id:STATUS_CAPTURADO, descripcion:"Capturado", css:'estatus cafeL', img:null};
			$scope.satatusList[STATUS_NOREQUERIDO] = {id:STATUS_NOREQUERIDO, descripcion:"No requqerido", css:'estatus cafeL', img:null};
			$scope.satatusList[STATUS_VERIFICADO] = {id:STATUS_VERIFICADO, descripcion:"Pendiente de validar", css:'estatus cafeL', img:null};			
			$scope.satatusList[STATUS_RECHAZADO] = {id:STATUS_RECHAZADO, descripcion:"Rechazado", css:'estatus cafeL', img:null};        
			$scope.satatusList[STATUS_VALIDADO] = {id:STATUS_VALIDADO, descripcion:"Validado", css:'estatus ok', img:'images/ok.png'};						

			$scope.listaComDomicilio = ["Recibo de luz, agua, teléfono, predial, gas, televisión de paga","Constancia de propiedad ejidal","Credencial de elector"];
			$scope.listaComPropiedad = ["Recibo de impuesto predial del año en curso, Escritura Pública, Contrato de compra - venta notariado, Constancia de propiedad ejida, con sello del comisariado y consejo de vigilancia","Documento de cesión de derechos notariados o Traslado de dominio","Carta de asignación (Programa de vivienda popular) y con último recibo de caja","Cuando el Coacreditado declare propiedad éste debe habitar dicho inmueble"];
			$scope.listaComIngresos = ["Recibo de nómina","Declaración de pagos de impuesto","Recibos de honorarios","Estados bancarios"];
			$scope.listaArrDomicilio = ["Contrato de Servicios a nombre del cliente o cónyuge","Recibo de agua","Recibo de luz","Recibo de teléfono fijo","Recibo del impuesto predial del año en curso","Recibo de gas natural","Recibo de renta y contrato de arrendamiento"];
			$scope.listaArrEmpl = ["Copia del contrato y el último recibo de nómina a nombre del cliente mes actual","Recibo de nómina mínimo de 6 meses o más de antigüedad y el último recibo a nombre del cliente, mes actual","La hoja rosa del IMSS o el alta/modificación del salario y el último recibo de nómina del cliente."];
			
			$scope.tipofotolicencia = ["Capturar Licencia (frente)", "Capturar Licencia (reverso)"];
			$scope.tipofotoife = ["Capturar IFE (frente)", "Capturar IFE (reverso)"];	
			$scope.tipofotocomdom = ["Recibo"];
			$scope.tipofotoingreso = ["Capturar comprobante de ingresos del ultimo mes"];
			
			/**Objeto tipo matriz con  json's que contienen los datos de un documento  (imagenes, lista tipo doc, parametros para ipad) */			
			$scope.datosDoc = new Array(8);
			$scope.datosDoc[IDENTIFICACION_OFICIAL.id] = {descripcion:IDENTIFICACION_OFICIAL.descripcion, status:null, idPersona:null, consecutivoPersona:null, img1:null, imgs:new Array(), listaDocs:$scope.listaIdentificacion, checked:false, showDoc: true, sent:false, paramsIpad: {tipoPersona:CLIENTE.descripcion, numfotos:2, numMax:2, tiposfoto:$scope.tipofotoife, tipodocumento:5, documentoCargado:false, fotosTomadas: 0, capturarImgnIpadResponse:null},img:'identificacionOficial.jpg',width:'250px',height:'', openModal: true, imgTmp:{img:null, show:false, descripcion:"", imgOriginal: null}, contador:0 };						 
			$scope.datosDoc[COMP_DOMICILIO.id] = {descripcion:COMP_DOMICILIO.descripcion, status:null,idPersona:null,consecutivoPersona:null, img1:null, imgs:new Array(), listaDocs:$scope.listaComDomicilio, checked:false, showDoc: true, sent:false, paramsIpad: {tipoPersona:CLIENTE.descripcion, numfotos:1, numMax:5, tiposfoto:$scope.tipofotocomdom, tipodocumento:6, documentoCargado:false, fotosTomadas: 0, capturarImgnIpadResponse:null},img:'comprobanteDomicilio.jpg',width:'250px',height:'', openModal: true, imgTmp:{img:null, show:false, descripcion:"", imgOriginal: COMP_ARRAIGO_DOMICILIARIO}, contador:0 };						 
			$scope.datosDoc[COMP_INGRESOS.id] = {descripcion:COMP_INGRESOS.descripcion, status:null,idPersona:null, consecutivoPersona:null, img1:null, imgs:new Array(), listaDocs:$scope.listaComIngresos, checked:false, showDoc: false, sent:false, paramsIpad: {tipoPersona:CLIENTE.descripcion, numfotos:1, numMax:5, tiposfoto:$scope.tipofotoingreso, tipodocumento:7, documentoCargado:false, fotosTomadas: 0, capturarImgnIpadResponse:null},img:'comprobanteIngresos.jpg',width:'250px',height:'', openModal: false, imgTmp:{img:null, show:false, descripcion:"", imgOriginal: COMP_ARRAIGO_LABORAL}, contador:0 };						 
			$scope.datosDoc[COMP_PROPIEDAD.id] = {descripcion:COMP_PROPIEDAD.descripcion, status:null,idPersona:null, consecutivoPersona:null, img1:null, imgs:new Array(), listaDocs:$scope.listaComPropiedad, checked:false, showDoc: false, sent:false, paramsIpad: {tipoPersona:CLIENTE.descripcion, numfotos:1, numMax:5, tiposfoto:$scope.tipofotocomdom, tipodocumento:0, documentoCargado:false, fotosTomadas: 0, capturarImgnIpadResponse:null},img:'comprobantePropiedad.jpg',width:'250px',height:'', openModal: false, imgTmp:{img:null, show:false, descripcion:"", imgOriginal: null}, contador:0 };
			$scope.datosDoc[COMP_ARRAIGO_DOMICILIARIO.id] = {descripcion:COMP_ARRAIGO_DOMICILIARIO.descripcion, status:null,idPersona:null, consecutivoPersona:null, img1:null, imgs:new Array(), listaDocs:$scope.listaArrDomicilio, checked:false, showDoc: false, sent:false, paramsIpad: {tipoPersona:CLIENTE.descripcion, numfotos:1, numMax:5, tiposfoto:$scope.tipofotocomdom, tipodocumento:0, documentoCargado:false, fotosTomadas: 0, capturarImgnIpadResponse:null},img:'comprobantePropiedad.jpg',width:'250px',height:'', openModal: false, imgTmp:{img:null, show:false, descripcion:"", imgOriginal: null}, contador:0 };
			$scope.datosDoc[COMP_ARRAIGO_LABORAL.id] = {descripcion:COMP_ARRAIGO_LABORAL.descripcion, status:null,idPersona:null, consecutivoPersona:null, img1:null, imgs:new Array(), listaDocs:$scope.listaArrEmpl, checked:false, showDoc: false, sent:false, paramsIpad: {tipoPersona:CLIENTE.descripcion, numfotos:1, numMax:5, tiposfoto:$scope.tipofotocomdom, tipodocumento:0, documentoCargado:false, fotosTomadas: 0, capturarImgnIpadResponse:null},img:'comprobantePropiedad.jpg',width:'250px',height:'', openModal: false, imgTmp:{img:null, show:false, descripcion:"", imgOriginal: null}, contador:0 };
			$scope.datosDoc[IDENTIFICACION_OFICIAL_AVAL.id] = {descripcion:IDENTIFICACION_OFICIAL_AVAL.descripcion, status:null, idPersona:null, consecutivoPersona:null, img1:null, imgs:new Array(), listaDocs:$scope.listaIdentificacion, checked:false, showDoc: false, sent:false, paramsIpad: {tipoPersona:AVAL.descripcion, numfotos:2, numMax:2, tiposfoto:$scope.tipofotoife, tipodocumento:5, documentoCargado:false, fotosTomadas: 0, capturarImgnIpadResponse:null},img:'identificacionOficial.jpg',width:'250px',height:'', openModal: true, imgTmp:{img:null, show:false, descripcion:"", imgOriginal: null}, contador:0 };						
			$scope.datosDoc[COMP_DOMICILIO_AVAL.id] = {descripcion:COMP_DOMICILIO_AVAL.descripcion, status:null, idPersona:null, consecutivoPersona:null, img1:null, imgs:new Array(), listaDocs:$scope.listaComDomicilio, checked:false, showDoc: false, sent:false, paramsIpad: {tipoPersona:AVAL.descripcion, numfotos:1, numMax:5, tiposfoto:$scope.tipofotocomdom, tipodocumento:6, documentoCargado:false, fotosTomadas: 0, capturarImgnIpadResponse:null},img:'comprobanteDomicilio.jpg',width:'250px',height:'', openModal: true, imgTmp:{img:null, show:false, descripcion:"", imgOriginal: null}, contador:0 };						
			$scope.datosDoc[COMP_INGRESOS_AVAL.id] = {descripcion:COMP_INGRESOS_AVAL.descripcion, status:null, idPersona:null, consecutivoPersona:null, img1:null, imgs:new Array(), listaDocs:$scope.listaComIngresos, checked:false, showDoc: false, sent:false, paramsIpad: {tipoPersona:AVAL.descripcion, numfotos:1, numMax:5, tiposfoto:$scope.tipofotoingreso, tipodocumento:7, documentoCargado:false, fotosTomadas: 0, capturarImgnIpadResponse:null},img:'comprobanteIngresos.jpg',width:'250px',height:'', openModal: false, imgTmp:{img:null, show:false, descripcion:"", imgOriginal: null}, contador:0 };						
			$scope.datosDoc[COMP_PROPIEDAD_AVAL.id] = {descripcion:COMP_PROPIEDAD_AVAL.descripcion, status:null, idPersona:null, consecutivoPersona:null, img1:null, imgs:new Array(), listaDocs:$scope.listaComPropiedad, checked:false, showDoc: false, sent:false, paramsIpad: {tipoPersona:AVAL.descripcion, numfotos:1, numMax:5, tiposfoto:$scope.tipofotocomdom, tipodocumento:0, documentoCargado:false, fotosTomadas: 0, capturarImgnIpadResponse:null},img:'comprobantePropiedad.jpg',width:'250px',height:'', openModal: false, imgTmp:{img:null, show:false, descripcion:"", imgOriginal: null}, contador:0 };						
			
			//variable para la foto adjuntada del cliente
			$scope.foto = {imagen: "images/fotografia.png", sent:false};
			$scope.documento = {imagen: null, sent:false};
			
			
			$scope.loadDocs = function(){
				
				$rootScope.addEvent( BITACORA.SECCION.expedientesCoacreditado.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, $rootScope.solicitudOSJson.documentos.porcentaje, BITACORA.SECCION.expedientesCoacreditado.guardarEnBD );
				
				//valida que el usuario sea un gerente para hacer la validación del gerente
				if($scope.accesoValidacion && $scope.activarValidacion)
					$rootScope.message("Aviso", ["El empleado que realiza la revisión del expediente debe ser distinto al que levantó la solicitud de crédito y debe cumplir con el rol de Gerente o Subgerente"], "Aceptar", "/ochoPasosOS");
				
				//Invoca la funsión para cargar la vista
				loadView();		
				
				// Recorre para obtener el contenido del arreglo documentos ademas de cargar los documentos
				angular.forEach( $rootScope.solicitudOSJson.documentos.documento, function(doc, key){
					
					if(doc.idDocumento === "3" && doc.status == 5 && $rootScope.solicitudOSJson.idSeguimiento == 6 && $rootScope.solicitudOSJson.marca == 1023){
						doc.status = 1;
					}
					
					$scope.datosDoc[doc.idDocumento].consecutivoPersona = doc.consecutivoPersona;
					$scope.datosDoc[doc.idDocumento].idPersona = doc.idPersona;
					$scope.datosDoc[doc.idDocumento].status = doc.status;
					
					if( doc.cantidad != undefined){
						$scope.datosDoc[doc.idDocumento].paramsIpad.fotosTomadas = doc.cantidad;
						if(doc.idDocumento == IDENTIFICACION_OFICIAL.id && doc.cantidad != 2)										
							$scope.datosDoc[doc.idDocumento].paramsIpad.fotosTomadas = 0																												
					}
					
					if($rootScope.solicitudOSJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id  && doc.idDocumento != "3" &&
						($rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.pendienteDigitalizar || 
						$rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.docDigitalizado || 
						$rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.docPendValidar ||
						$rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.DocValidado ||
						$rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.CDPActualizada ||
						$rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.bloqueoIntentos)){
						$scope.datosDoc[doc.idDocumento].showDoc = false;
					}else{
						/**Valida los estuts de los documentos que sean los correctos**/
						if( generalServiceOS.documentoEnviadoValido(doc.status) ){
							$scope.checkDocumentos.docsVisibles++;																		
							$scope.datosDoc[doc.idDocumento].img1 = "images/noencontrado.png";
																	
							if(doc.status == STATUS_VALIDADO)
								$scope.datosDoc[doc.idDocumento].checked = true;
							
							if( doc.idTipoPersona == CLIENTE.id)
								$scope.datosDoc[doc.idDocumento].showDoc = true;																																	
							/**Carga los checks despues de hhaber validado o no un gerente**/
							countStatusDoc(doc.status, $scope.datosDoc[doc.idDocumento].showDoc);
																	
						}else if(doc.status == STATUS_NOREQUERIDO && doc.idTipoPersona == CLIENTE.id){
							$scope.datosDoc[doc.idDocumento].showDoc = false;
						}else if(doc.status == STATUS_PENDIENTE && doc.idTipoPersona == CLIENTE.id)
							$scope.datosDoc[doc.idDocumento].showDoc = true;	
					}
					
					switch(doc.idDocumento){									
						case COMP_ARRAIGO_DOMICILIARIO.id:
							$scope.datosDoc[doc.idDocumento].showDoc = false;
							$scope.datosDoc[COMP_DOMICILIO.id].imgTmp.descripcion = $scope.datosDoc[COMP_DOMICILIO.id].descripcion +"/"+ $scope.datosDoc[COMP_DOMICILIO.id].imgTmp.imgOriginal.descripcion;
							break;
						case COMP_ARRAIGO_LABORAL.id:		
							if($scope.datosDoc[COMP_INGRESOS.id].showDoc){
								$scope.datosDoc[doc.idDocumento].showDoc = false;										
								$scope.datosDoc[COMP_INGRESOS.id].imgTmp.descripcion = $scope.datosDoc[COMP_INGRESOS.id].descripcion +"/"+ $scope.datosDoc[COMP_INGRESOS.id].imgTmp.imgOriginal.descripcion;
							}
							break;
					};																																	
						
				});
				
				
						
				/**
				 * Proceso que valida las imágenes que vienen del iPad
				 **/
				if( $scope.$parent.imagesDocsIpad.length > 0 ){														
						
						angular.forEach($scope.$parent.imagesDocsIpad, function(imgdoc, key){	
							
							if(  $scope.datosDoc[imgdoc.idTipoDoc].status > STATUS_PENDIENTE){
								
								if( !$scope.datosDoc[imgdoc.idTipoDoc].paramsIpad.documentoCargado ){
									$scope.datosDoc[imgdoc.idTipoDoc].paramsIpad.documentoCargado = true;
									paintImage(imgdoc.idTipoDoc, imgdoc);
									
								}else{
									var numfotosTomadas = $scope.datosDoc[imgdoc.idTipoDoc].paramsIpad.fotosTomadas; 
									
									if( numfotosTomadas > 0  ){	
										if( ($scope.datosDoc[imgdoc.idTipoDoc].imgs.length + 1) < numfotosTomadas )
											$scope.datosDoc[imgdoc.idTipoDoc].imgs.push(imgdoc.imgB64);
									}else
										$scope.datosDoc[imgdoc.idTipoDoc].imgs.push(imgdoc.imgB64);
									
										
								}
									
							}
							
						});									
																														
				}
				
				
				/*****************************************************************************
				 * Proceso que valida las imágenes que vienen del Servicio de Digitalización *
				 *****************************************************************************/
				if($scope.$parent.imagesDocsWS != null){		
					$scope.imagenesCargadas = false;
					
					/**
					 * Se eliminan aquellos documentos que esten en los estatus de pendiente, encolado o requerido. 
					 **/ 
					var imagesArrayTmp = new Array();
					for(var i=0;i<$scope.$parent.imagesDocsWS.length;i++){
						if(generalServiceOS.isDefined($scope.datosDoc[$scope.$parent.imagesDocsWS[i].idTipoDoc])  && $scope.datosDoc[$scope.$parent.imagesDocsWS[i].idTipoDoc].status > STATUS_PENDIENTE  && $scope.datosDoc[$scope.$parent.imagesDocsWS[i].idTipoDoc].status != STATUS_ENCOLADO_IPAD  &&  $scope.datosDoc[$scope.$parent.imagesDocsWS[i].idTipoDoc].status != STATUS_NOREQUERIDO){
							imagesArrayTmp.push($scope.$parent.imagesDocsWS[i]);
						}
					}
					
					/**
					 * Si las longitudes de los arreglos, antes y despues de ser procesados son diferentes, se setea en el arreglo originar, el arreglo procesado.
					 **/
					if($scope.$parent.imagesDocsWS.length != imagesArrayTmp.length  )
						$scope.$parent.imagesDocsWS = imagesArrayTmp;
					
					size = $scope.$parent.imagesDocsWS.length;
																																												
					if( size > 0  ){
						
						/**
						 * Se crea una copia termporal de las identificaciones oficiales
						 * Se colocal el tamaño de la imagen y la imagen por defecto, esto por si no se tiene una imagen que incrustar del servicio de digitalizacion
						 **/
						var arrayIdOficialTmp = new Array();
						var count = 0;
						
						var contadorINE = 2;
						contadorINE = ($scope.$parent.isTienda)?2:1;
						
						
						for(var i=0;i<$scope.$parent.imagesDocsWS.length;i++){
							if($scope.$parent.imagesDocsWS[i].idTipoDoc == IDENTIFICACION_OFICIAL.id ){
								if( count < contadorINE){
									arrayIdOficialTmp.push( {datosImg:$scope.$parent.imagesDocsWS[i], index:i } );
									count++;
								}
							}
							
							if(generalServiceOS.documentoEnviadoWS( $scope.datosDoc[ $scope.$parent.imagesDocsWS[i].idTipoDoc ].status )){
								$scope.datosDoc[$scope.$parent.imagesDocsWS[i].idTipoDoc].img1 ="images/loading.gif";
								$scope.datosDoc[$scope.$parent.imagesDocsWS[i].idTipoDoc].width = "80px";
								$scope.datosDoc[$scope.$parent.imagesDocsWS[i].idTipoDoc].height = "80px";
							}
						}
						
						/**
						 * Se invierte el orden de las identificaciones para mostrar la primera foto que se tomo (frente)
						 **/
						if($scope.$parent.isTienda){
							for(var i=0;i<arrayIdOficialTmp.length;i++){
								if(i%2 == 0){
									$scope.$parent.imagesDocsWS[arrayIdOficialTmp[i].index] = arrayIdOficialTmp[i + 1].datosImg;
								}else{
									$scope.$parent.imagesDocsWS[arrayIdOficialTmp[i].index] = arrayIdOficialTmp[i - 1].datosImg;
								}
							}
						}else{
							for(var i=0;i<arrayIdOficialTmp.length;i++){
								$scope.$parent.imagesDocsWS[arrayIdOficialTmp[i].index] = arrayIdOficialTmp[0].datosImg;
							}
						}
						
						loadImage($scope.$parent.imagesDocsWS[index]);
					
					}else{
						$scope.imagenesCargadas = true;
					}
				}
							
				
				
				if(!$scope.$parent.isTienda && $rootScope.solicitudOSJson.cotizacion.clientes[0].foto == 1){
																															
								var biometrico = {
										ruta: null,
										idSolicitud: $rootScope.solicitudOSJson.idSolicitud,
										cadena: null, tipoCadena: null, porcentaje:null
								};
								
								clienteUnicoService.getFoto( biometrico ).then(
									function(data){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										if(data.data.codigo == RESPONSE_CODIGO_EXITO){											
											var responseJson = JSON.parse(data.data.respuesta);
											
											if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
												$scope.foto.imagen = 'data:image/jpg;base64,'+responseJson.data;
												$scope.foto.sent = true;
											}
																					
										}
										
									}, function(error){
						                $rootScope.waitLoaderStatus = LOADER_HIDE; 
						                											
									}
								);
																												
				}																							
					
				
				$rootScope.waitLoaderStatus = LOADER_HIDE;
																																											
			};
			
			/*****************INIT***********
			 * Carga parte de la vista necesario para capturar y/o validar documentos por el gerente
			 * **/
			function loadView(){			
				/**Cuendo la solicitud ya cuenta con alguno de estos estatus se bloquea la sección**/
				if( ( !$scope.$parent.esGerente  && $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.docvalidacionPendienteOS ) ||
					$rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.liberadoOS)
							$scope.bloqueaSeccion = true;
				
				//$scope.condicionadoMesa = ($rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.condicionadoMesa) ? true:false;
				$scope.expCompleto = ($rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.expCompleto || $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente || $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.autorizadoMesa )? true: false;
				$scope.expRechazado = ($rootScope.solicitudOSJson.marca ==  STATUS_SOLICITUD.autorizada.marca.expRechazado) ? true:false;				
				$scope.requiereAval = $rootScope.solicitudOSJson.banderaSolidario == 1 ?  true:false;
																								
				$scope.titulo = generalServiceOS.getDataInput("EXPEDIENTE","TITULO",$scope.$parent.origen );
				$scope.subtitulo = generalServiceOS.getDataInput("EXPEDIENTE","SUBTITULO",$scope.$parent.origen );
				$scope.linkTD = generalServiceOS.getDataInput("EXPEDIENTE","TEXTO LIGA TIPO DOCUMENTOS",$scope.$parent.origen );
				$scope.textoBtn = generalServiceOS.getDataInput("EXPEDIENTE","TEXTO BOTON DIGITALIZAR",$scope.$parent.origen );
				
				if(configuracion.so.ios || configuracion.so.windows)
					$scope.textoBtn.texto="Digitalizar";
				
				$scope.tabCliente = generalServiceOS.getDataInput("EXPEDIENTE","ETIQUETA TAB CTE",$scope.$parent.origen );
				$scope.tabAval = generalServiceOS.getDataInput("EXPEDIENTE","ETIQUETA TAB AVAL",$scope.$parent.origen );
				$scope.btnAutorizo = generalServiceOS.getDataInput("EXPEDIENTE","BOTON AUTORIZO",$scope.$parent.origen );
				$scope.btnNoAutorizo = generalServiceOS.getDataInput("EXPEDIENTE","BOTON NO AUTORIZO",$scope.$parent.origen );
				$scope.btnGuardar = generalServiceOS.getDataInput("EXPEDIENTE","BOTON GUARDAR",$scope.$parent.origen );
				
				$scope.mensajeError = "Error en el servidor, por favor inténtelo mas tarde";					
				$scope.subtitulo.texto = $scope.$parent.esGerente && !$scope.expCompleto? subtituloValida.cliente:subtitulo.cliente;
								
				$scope.seccionFoto = {
						titulo: generalServiceOS.getDataInput("EXPEDIENTE","SUBTITULO FOTO","VALOR" ), 
						labelBtn: generalServiceOS.getDataInput("EXPEDIENTE","TEXTO BOTON FOTO","VALOR" )					
				};
				
				etiquetaFrente  = generalServiceOS.getDatafromCategory("SIMULADOR", "ETIQUETA FRENTE", "VALOR.valor" );
				etiquetaReverso = generalServiceOS.getDatafromCategory("SIMULADOR", "ETIQUETA REVERSO", "VALOR.valor" );
								
				//faltantes de agregar a model
				$scope.checkValidacion = "GERENTE";
				$scope.docRechazado = "Ver documento rechazado";				
				/**
				 * Carga los valores al json  de manera local
				 * **/
				if (offLine)
					$rootScope.cargaDocumentos();
				else
					/** Si la bandera es falso entonces calcula los documentos obtenidos por WS, y calcula el procentaje si aun falta documenttos pendietes de digitalizar**/
					$rootScope.calculaDocumentos();
												
				
				var catalogoIdentificacion = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.CATALOGO DE IDENTIFICACIONES VÁLIDAS"];	
				if(generalServiceOS.isDefined(catalogoIdentificacion)){
					for (var ind = 0; ind < catalogoIdentificacion.length; ind++){
						if ( ind < 2){
							$scope.listaIdentificacion[ind] = catalogoIdentificacion[ind].ETIQUETA.valor;
							$scope.identificaciones[ind]={id:parseInt(catalogoIdentificacion[ind].ID.valor),descripcion:catalogoIdentificacion[ind].ETIQUETA.valor};
						}
					}
				}
			};
			
			//Activa los check para cuendo se loguen un gerente dependiendo si fue rechazado o no
			function countStatusDoc(statusDoc, showDoc){
				if(statusDoc == STATUS_VALIDADO && showDoc)										
					$scope.checkDocumentos.numDocsOK++;
				
				else if(statusDoc == STATUS_RECHAZADO && showDoc)
					$scope.checkDocumentos.numDocsNotOK++;												
				
			};
			
			
			
			function loadImage(dataImage){
				
				/**
				 * Si el documento está en estatus 4, consume el servicio que obtiene la imagen en Base64 de una URL
				 * Si no esta en estatus 4, entonces continua evaluando las siguiente imagenes 
				 **/
				if(generalServiceOS.documentoEnviadoWS( $scope.datosDoc[dataImage.idTipoDoc].status )){
					var numfotosTomadas = $scope.datosDoc[dataImage.idTipoDoc].paramsIpad.fotosTomadas;								
					var primerImagen = ($scope.datosDoc[dataImage.idTipoDoc].img1 == null || $scope.datosDoc[dataImage.idTipoDoc].img1.length < 100) ? 0:1;								
									
					if(numfotosTomadas > 0){
						if(($scope.datosDoc[dataImage.idTipoDoc].imgs.length + primerImagen) < numfotosTomadas || (dataImage.idTipoDoc != IDENTIFICACION_OFICIAL.id  &&  dataImage.idTipoDoc != IDENTIFICACION_OFICIAL_AVAL.id &&  dataImage.origen == 'JVC'))
							getImageB64(dataImage, primerImagen);
						else{
							index++;
							
							if(index < size){									
								loadImage($scope.$parent.imagesDocsWS[index]);		
							}else{
								$scope.imagenesCargadas = true;
							}
						}
					}else{
						getImageB64(dataImage, primerImagen);
					}
				}else{
					console.log("imagen "+dataImage.idTipoDoc+" no ha sido enviada");
					index++;
					
					if(index < size){									
						loadImage($scope.$parent.imagesDocsWS[index]);
					}else{
						$scope.imagenesCargadas = true;
					}
				}
			};
			
			function getImageB64(dataImage, primerImagen){
				/**
				 * Para vista gerente y exp incompleto va por todas las imagenes de los documentos
				 * Para vista NO gerente y exp incompleto va solo por la 1ra imagen de cada documento
				 **/
				if(primerImagen == 0 || $scope.$parent.esGerente && !$scope.expCompleto){ 
					
					getImageB64Promise(dataImage).then(
						function(exito){
							
							/**
							 * Se aumenta el contador de index
							 * Si index menor a la longitud del arreglo, se siguen procesando las imagenes
							 * Si es mayor o igual a la longitud del arreglo, se terminan de procesar las imagenes 
							 **/
							index++;
							
							if(index < size){
								loadImage($scope.$parent.imagesDocsWS[index]);
							}else{
								$scope.imagenesCargadas = true;
							}
							
						},function(error){
							console.log(error);
						}
					);

				}else{
					
					/**
					 * Si no cumple estas condiciones y si index es menor a la longitud del arreglo, se siguen procesando las imagenes
					 * Si no cumple estas condiciones y si index es mayor o igual a la longitud del arreglo, se terminan de procesar las imagenes
					 **/
					
					index++;
					if(index < size){									
						loadImage($scope.$parent.imagesDocsWS[index]);
					}else{
						$scope.imagenesCargadas = true;
					}
				}
																				
			};
			
			function getImageB64Promise(imagedoc){
				var defered = $q.defer();
				var promise = defered.promise;
				
				/**
				 * Se pasa como parametro, la URL de la imagen donde se aloja para consumir un servicio que transforma las URL's en Base64
				 **/
				documentosService.getImageBase64( {url:imagedoc.urlDoc} ).then(
					function(data){												
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){																	
							var imgDoc = data.data.respuesta;
							
							if(imgDoc.imgB64 != null && imgDoc.imgB64.length > 0)
								paintImage(imagedoc.idTipoDoc, imgDoc);
							else{
								if(  $scope.datosDoc[imagedoc.idTipoDoc].img1 == null || $scope.datosDoc[imagedoc.idTipoDoc].img1.length < 100){
									$scope.datosDoc[imagedoc.idTipoDoc].img1 = "images/noencontrado.png";
									$scope.datosDoc[imagedoc.idTipoDoc].width = "";
									$scope.datosDoc[imagedoc.idTipoDoc].height = "";
								}
							}
																															
							defered.resolve(true);
						}else{
							$scope.datosDoc[imagedoc.idTipoDoc].img1 = "images/noencontrado.png";
							defered.reject(false);
						}
							
													
					},function(error){							
						$scope.datosDoc[imagedoc.idTipoDoc].img1 = "images/noencontrado.png";
						defered.reject(false);							
					}
				);
								
				return promise;
			}
														
			
			function paintImage(docId, imgdoc){								
								
				
				if(imgdoc.imgB64 != null && imgdoc.imgB64.length > 0){
					var _width = imgdoc.imgWidth;
					var _height = imgdoc.imgHeight;											
					
					if(  $scope.datosDoc[docId].img1 == null || $scope.datosDoc[docId].img1.length < 100){
						
						$scope.datosDoc[docId].img1 = "data:image/jpg;base64,"+imgdoc.imgB64;
						
						switch(docId){
							case COMP_ARRAIGO_DOMICILIARIO.id:
								$scope.datosDoc[COMP_DOMICILIO.id].imgTmp.img = "data:image/jpg;base64,"+imgdoc.imgB64;
								$scope.datosDoc[COMP_DOMICILIO.id].imgTmp.descripcion = $scope.datosDoc[COMP_DOMICILIO.id].descripcion +"/"+ $scope.datosDoc[COMP_DOMICILIO.id].imgTmp.imgOriginal.descripcion;
								break;
							case COMP_ARRAIGO_LABORAL.id:
								$scope.datosDoc[COMP_INGRESOS.id].imgTmp.img = "data:image/jpg;base64,"+imgdoc.imgB64;
								$scope.datosDoc[COMP_INGRESOS.id].imgTmp.descripcion = $scope.datosDoc[COMP_INGRESOS.id].descripcion +"/"+ $scope.datosDoc[COMP_INGRESOS.id].imgTmp.imgOriginal.descripcion
								break;
						};						
						
					}else
						$scope.datosDoc[docId].imgs.push(imgdoc.imgB64);												
																					
				}
				
			};

			$scope.alertList = function(idDoc){			
				if((idDoc == COMP_DOMICILIO.id  ||  idDoc == COMP_INGRESOS.id) && $scope.datosDoc[idDoc].imgTmp.show)				
					idDoc = $scope.datosDoc[idDoc].imgTmp.imgOriginal.id;
				
				modalService.alerListtModal($scope.datosDoc[idDoc].descripcion,$scope.datosDoc[idDoc].listaDocs, null, "bgCafe", "cafeD", "cafeLi");								
			};
			
			
			//* Función que muestra el modal de los documentos rechazados por Mesa de control *//
			/*$scope.muestraDoc =  function (idDoc){
				var imgs = new Array();
				var texto = "";							
				
				imgs.push($scope.datosDoc[idDoc].img1.split(",")[1]);
				angular.forEach($scope.datosDoc[idDoc].imgs, function(img, key){										
					imgs.push(img);
				});
									
				modalService.muestraDocsModal($scope.datosDoc[idDoc].descripcion, "bgCafe",  idDoc, imgs, texto).then( 
								function(estatus) {
									angular.forEach( $rootScope.solicitudOSJson.documentos.documento, function(doc){																																	
										if( doc.idDocumento == idDoc){					
											doc.status = estatus;											
											$scope.datosDoc[doc.idDocumento].status = estatus;													
										}																																																			
									});	
																											
								}, function(error) {
									$rootScope.waitLoaderStatus = LOADER_HIDE;									
								}
							);								
			};*/			
			
			/**
			 * Carga la vista para la validación del gerente (checkbox)
			 * */
			$scope.showTipoPersona = function(tipoPersona){
				
				if(tipoPersona == CLIENTE.id){					
					$scope.subtitulo.texto = $scope.$parent.esGerente && !$scope.expCompleto? subtituloValida.cliente:subtitulo.cliente; 					
					$scope.tabCteCSS =  csstabs.on;
					$scope.tabAvalCSS =  csstabs.off;
				}else{
					$scope.subtitulo.texto = $scope.$parent.esGerente && !$scope.expCompleto? subtituloValida.aval:subtitulo.aval;					
					$scope.tabCteCSS =  csstabs.off;
					$scope.tabAvalCSS =  csstabs.on;
				}
				
				$scope.checkDocumentos.numDocsOK = 0;
				$scope.checkDocumentos.numDocsNotOK = 0;
				angular.forEach( $rootScope.solicitudOSJson.documentos.documento, function(doc, key){	
					
					if(doc.status == STATUS_VALIDADO)
						$scope.datosDoc[doc.idDocumento].checked = true;						
					
					countStatusDoc(doc.status, $scope.datosDoc[doc.idDocumento].showDoc);
					
					if( generalServiceOS.documentoEnviadoValido(doc.status) && doc.idTipoPersona == tipoPersona ){
						$scope.datosDoc[doc.idDocumento].showDoc = true;						
																
					}else if(doc.status == STATUS_PENDIENTE && doc.idTipoPersona == tipoPersona)
						$scope.datosDoc[doc.idDocumento].showDoc = true;
					
					else
						$scope.datosDoc[doc.idDocumento].showDoc = false;		
					
					switch(doc.idDocumento){									
						case COMP_ARRAIGO_DOMICILIARIO.id:
							$scope.datosDoc[doc.idDocumento].showDoc = false;
							$scope.datosDoc[COMP_DOMICILIO.id].imgTmp.descripcion = $scope.datosDoc[COMP_DOMICILIO.id].descripcion +"/"+ $scope.datosDoc[COMP_DOMICILIO.id].imgTmp.imgOriginal.descripcion;
							break;
						case COMP_ARRAIGO_LABORAL.id:		
							if($scope.datosDoc[COMP_INGRESOS.id].showDoc){
								$scope.datosDoc[doc.idDocumento].showDoc = false;										
								$scope.datosDoc[COMP_INGRESOS.id].imgTmp.descripcion = $scope.datosDoc[COMP_INGRESOS.id].descripcion +"/"+ $scope.datosDoc[COMP_INGRESOS.id].imgTmp.imgOriginal.descripcion;
							}
							break;
					};		
					
				});		
								
			};
			
			
			$scope.showDocumentFilter = function(doc){				
				return $scope.datosDoc[doc.idDocumento].showDoc;
			};
			
			
			/*
			*Inicia la función para la captura de los dicumentos
			*/
			$scope.capturarImagen = function(iddocumento, tipo, subTipo){
				$rootScope.waitLoaderStatus = LOADER_SHOW;																
				var isOCR = false;
				
				if((iddocumento == COMP_DOMICILIO.id  ||  iddocumento == COMP_INGRESOS.id) && $scope.datosDoc[iddocumento].imgTmp.show)				
					iddocumento = $scope.datosDoc[iddocumento].imgTmp.imgOriginal.id;
				
				fotoDocumento.id = iddocumento;
				if (subTipo){
					
					subTipoComprobante = subTipo;								
					//Valida el tipo de documento e inicializa la bandera para hacer OCR				
					switch(tipo) {
				    case RECIBO_TELEFONO:			    	
				    	if (subTipo.id ==  TIPO_RECIBO_TELEFONO.TELMEX)
				    		isOCR = true;
				    					    	
				        break;
				    case RECIBO_LUZ:
				    	if (subTipo.id == TIPO_RECIBO_LUZ.CFE)
				    		isOCR = true;
				    		
				        break;
//					case CREDENCIAL_ELECTOR:
//				    	$scope.datosDoc[iddocumento].paramsIpad.numMax = 2;
//				    		
//				        break;		
					}	
				}else{
					if (tipo == 1)
						if($scope.$parent.isTienda){
							$scope.datosDoc[iddocumento].paramsIpad.numMax = 2;
						}else{
							$scope.datosDoc[iddocumento].paramsIpad.numMax = 1;
						}
				}
				
//				if (configuracion.so.windows){
					isOCR = false;
//				}
					
				var tipoDocumento = iddocumento;
				if(iddocumento === "2")
					tipoDocumento = "3";
				
				//Captura la imagen de los documentos
				if(isOCR)
					$rootScope.aplicarOCR_Domicilio('expDigi', "ocrResponse", {tipo: subTipo.descripcion});
				else{
					if($scope.$parent.isTienda){
						$rootScope.capturarImagenIpad($rootScope.solicitudOSJson.cotizacion.clientes[0].idPersona,$scope.datosDoc[iddocumento].paramsIpad.numfotos, $scope.datosDoc[iddocumento].paramsIpad.tiposfoto,tipoDocumento,'expDigi',"capturarImagenIpadResponse", $scope.datosDoc[iddocumento].paramsIpad.numMax, $scope.datosDoc[iddocumento].descripcion, tipo);
					}else{
						var request = {
						  "codigo": 0,
						  "mensaje": "Se capturaron las fotos",
						  "arrArchBase64": [imageAux],
						  "arrNomArchBase64": ["800DD552-1EF8-40CA-A2BF-73BDC2333909-455-00000067CD32DC43", "807BA8B9-AF6D-4D1F-995D-BB8DB3B7C195-455-00000067CD516342"]
						}
						
						$scope.capturarImagenIpadResponse(request);
					}
				}
															
			};
				
			
			/**
			 * Repuesta del componente
			 * **/
			$scope.ocrResponse = function(responseIpad){
				$rootScope.loggerIpad("ocrResponse", null, responseIpad);
				if(responseIpad.codigo == RESPONSE_CODIGO_EXITO_IPAD){
					angular.forEach( $rootScope.solicitudOSJson.documentos.documento, function(doc){																																	
						if( doc.idDocumento == fotoDocumento.id  &&  (doc.idTipoDocumento==RECIBO_TELEFONO ||  doc.idTipoDocumento==RECIBO_LUZ) ){
							doc.textoDigitalizacion = responseIpad.persona.calle+" # "+responseIpad.persona.numExt+" "+responseIpad.persona.numInt +", Col. "+responseIpad.persona.colonia+
											          ", C.P. "+responseIpad.persona.codigoPostal+" Del. "+responseIpad.persona.municipio+", "+responseIpad.persona.estado;
							doc.idCompania =  subTipoComprobante.id;
							doc.companiaDes =  subTipoComprobante.descripcion;
							
						}
					});
				}
				
				subTipoComprobante = null;
				/***
				 * Carga la información de la respuesta del componente
				 * */
				var jsonResponse = {
					codigo: responseIpad.codigo,
					mensaje: responseIpad.mensaje,
					arrArchBase64:[responseIpad.imagen],
					arrNomArchBase64: [responseIpad.nombre]					
				}
								
				$scope.capturarImagenIpadResponse(jsonResponse);		
								
			};
			
			/**
			 * Se trata la la respuesta del componente
			 * Se carga la información de los documentos y se envían
			 * **/
			$scope.capturarImagenIpadResponse = function(responseIpad){													
				$rootScope.loggerIpad("capturarImagenIpadResponse", null, responseIpad);								
				if(responseIpad.codigo == RESPONSE_CODIGO_EXITO_IPAD){
										
					numFotosDocumento = responseIpad.arrArchBase64.length;
					// El número de fotos debe ser mayor a cero
					if(numFotosDocumento > 0 ){
						$scope.datosDoc[fotoDocumento.id].imgs = new Array();
						numImagesIpad = 0;
						fotoDocumento.imgB64 = responseIpad.arrArchBase64[0];	
						formatoDocumento = (responseIpad.formato != "" && responseIpad.formato != undefined)?responseIpad.formato:"jpg";
											
						$scope.datosDoc[fotoDocumento.id].paramsIpad.capturarImgnIpadResponse = responseIpad;
											
						angular.forEach( responseIpad.arrArchBase64, function(fileB64, key){
							setImageIpad(fotoDocumento.id, fileB64);
						});
						
					}else
						$rootScope.waitLoaderStatus = LOADER_HIDE;
										
					
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Expediente",[responseIpad.mensaje], "Aceptar", null, "bgCafe", "cafeD");
				}
					
																
				
		     };
		     
		     
		    var setImageIpad = function(docId, fileB64){																							
								    	
					numImagesIpad++;																											
					
					if( numImagesIpad == 1)																																													
						actualizasolicitudOSJson(STATUS_ENCOLADO_IPAD);																												
							
								
					else{
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if( !generalServiceOS.isEmpty(docId) )
								$scope.datosDoc[docId].imgs.push(fileB64);																										
					}																			
																					
			};											
		     
		    
			
			var actualizasolicitudOSJson = function(docStatus){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				
				angular.forEach( $rootScope.solicitudOSJson.documentos.documento, function(doc){																																	
					if( doc.idDocumento == fotoDocumento.id){
						doc.status = docStatus;
						doc.cantidad = numFotosDocumento;
						$scope.datosDoc[doc.idDocumento].img1 ="images/loading.gif";
					}
					
					if (doc.idDocumento == COMP_PROPIEDAD_AVAL.id)
						doc.idTipoDocumento = $rootScope.solicitudOSJson.avales[0].idTipoPropiedad;
				});
				
				$rootScope.solicitudOSJson.documentos.porcentaje = generalServiceOS.porcentajeDocs($rootScope);												
				widthImage('data:image/png;base64,'+fotoDocumento.imgB64,fotoDocumento.id);		
				
			};
				
					
			
			/***
			 * Revisa el conportamiento del DIV foto.
			 * */
			$scope.$watch("foto",function(){	
				
				if(!$scope.$parent.isTienda  ){
					var fotoCte =  $scope.foto.imagen.split(",");
					
					if(fotoCte.length == 2  && !$scope.foto.sent){
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						
						var biometrico = {
								ruta: null,
								idSolicitud: $rootScope.solicitudOSJson.idSolicitud,
								cadena: fotoCte[1],
								tipoCadena: "foto",								
								porcentaje: "100"
						};
						
						/**
						 * Invoca el servicio para guardar la foto
						 * **/
						clienteUnicoService.setBiometrico( biometrico ).then(
							function(data){
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								if(data.data.codigo == RESPONSE_CODIGO_EXITO){
									var responseJson = JSON.parse(data.data.respuesta);
									
									if(responseJson.codigo != RESPONSE_ORIGINACION_CODIGO_EXITO){
										$scope.foto.sent = true;										
									}else if(responseJson.codigo == RESPONSE_CODIGO_ERROR_ID){
										$rootScope.message("Expediente",["Error en la respuesta del servicio para guardar la foto. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafe", "cafeD");
									}
								}else
									$rootScope.message("Expediente",["Error en la respuesta del servicio para guardar la foto. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafe", "cafeD");
								
							}, function(error){
				                $rootScope.waitLoaderStatus = LOADER_HIDE; 
				                modalService.alertModal("Error "+error.status, [error.statusText]);
								
							}
						);
						
					}
					
				} 
				
				
			},true);
				

		    $scope.elegidoIdent=function(opc){		    			    			    	
				$scope.datosDoc[opc].sent=true;
				$scope.opcImg1 = opc;
			};
			
			
			$scope.elegido=function(idDoc){				
				
				if((idDoc == COMP_DOMICILIO.id  ||  idDoc == COMP_INGRESOS.id) && $scope.datosDoc[idDoc].imgTmp.show)				
					idDoc = $scope.datosDoc[idDoc].imgTmp.imgOriginal.id;
				
				$scope.opcImg1 = idDoc;				
			};
						
			
			$scope.$watch("documento.imagen",function(){
				if(!$scope.$parent.isTienda && $scope.watch == 0){
					var opc = $scope.opcImg1;
					if (parseInt(opc)){
						if ($scope.documento.imagen != null ){	
							/**
							 * Invoca el servicio de guardado para los documentos
							 * **/							
							imageAux = $scope.documento.imagen.replace("data:image/jpeg;base64,","");
							imageAux = imageAux.replace("data:image/png;base64,","");
							$scope.capturarImagen("3");							
						}	 
							
					}
				}else
					$scope.watch=0;
				
			},true);
		    		    
			/**
			* Este función adjunta la imagen de los expedientes, solo para desarrollo
			**/
			$scope.adjuntaModal = function(docId){
				
				switch(docId){
					case IDENTIFICACION_OFICIAL.id:
					case IDENTIFICACION_OFICIAL_AVAL.id:
						
						modalService.identificacionOficialOSModal(docId);						
						break;
						
					case COMP_DOMICILIO.id:
					case COMP_INGRESOS.id:
						if($scope.datosDoc[docId].imgTmp.show){
							docId = $scope.datosDoc[docId].imgTmp.imgOriginal.id;							
							
							if( $scope.$parent.isTienda )
								$scope.capturarImagen(docId);
							else{
								$scope.elegido(docId);
								document.getElementById("hideUploadBtnFile").click();
							}
									
															
						}else
							modalService.compDomicilioOSModal(docId);
						break;
					
					case COMP_DOMICILIO_AVAL.id:
						modalService.compDomicilioOSModal(docId);
				
				}			     
																

			};
			
			
			$scope.showImgTmp = function(docId, show){																				
				$scope.datosDoc[docId].imgTmp.show = show; 																	
			};
			
			$scope.terminaDialogo=function(){
				$scope.watch=1;
			};
									
			
			//Guarda la sección de de expedientes
			$scope.guardar = function(){				
				/*\Se agregan eventos para la bitacora\*/
//				(Expediente coacreditado)
				$rootScope.addEvent( BITACORA.SECCION.expedientesCoacreditado.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.guardar.id,$rootScope.solicitudOSJson.documentos.porcentaje, BITACORA.SECCION.expedientesCoacreditado.guardarEnBD );
				/*\Se agregan eventos para la bitacora\*/
				$scope.docRechazado = 0;
				if($rootScope.solicitudOSJson.documentos != undefined && $rootScope.solicitudOSJson.documentos.documento != undefined ){
					for(var i=0;i<$rootScope.solicitudOSJson.documentos.documento.length;i++){
						if($rootScope.solicitudOSJson.documentos.documento[i].status == STATUS_RECHAZADO){
							$scope.docRechazado = 1;
							break;
						}
					}
				}
									
//				if( $scope.$parent.isTienda ){																		

//					if($rootScope.solicitudOSJson.banderaIngresos == 1 && $rootScope.solicitudOSJson.cotizacion.clientes[0].flujoEfectivo[0].monto >= 20000.0){
//						solicitudService.enviarIngresosCompMayoresA20k($rootScope.solicitudOSJson.idSolicitud).then(function(data){},function(error){});	
//					}
					
					var documentosObj = JSON.parse(generalServiceOS.getRespaldo()).documentos;										
					documentosObj.porcentaje = $rootScope.solicitudOSJson.documentos.porcentaje;
					documentosObj.documento = new Array();
						
					angular.forEach( $rootScope.solicitudOSJson.documentos.documento, function(doc){						
							var _capturarImgnIpadResponse = $scope.datosDoc[doc.idDocumento].paramsIpad.capturarImgnIpadResponse;																						
							if(_capturarImgnIpadResponse != null)
								documentosObj.documento.push(doc);																																														
					});
										
					/** Si el tamañano del arreglo de los documentos es mayor a cero entonces actualiza los documentos **/	
					if(documentosObj.documento.length > 0 ){
						if($scope.cambioIdent)
							$rootScope.solicitudOSJson.banderaOCR=0;
						
						else if( $scope.docRechazado == 0 && $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.expRechazado)
							actulizarMarca($rootScope.solicitudOSJson.idSolicitud, $rootScope.solicitudOSJson.idSeguimiento, STATUS_SOLICITUD.autorizada.marca.docvalidacionPendienteOS);
						
						validarDocumentosFnc(documentosObj);
		
					}else
						generalServiceOS.locationPath("/ochoPasosOS");
																				
					
//				}else
//					generalServiceOS.locationPath("/ochoPasosOS");
				
			};
			
			/** Actualiza el estuts de la solicitud después de invocar alguna función de actualizaciónde documentos, ya sea digitalizando un documento nuevo**/
			function actualizaSolicitud(solicitud){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				
				solicitudService.actualizarSolicitud(solicitud).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;

							if(data.data.codigo != undefined){
								var responseJson = JSON.parse(data.data.respuesta);														
								
								if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									generalServiceOS.setDataBridge({ origen:FICHA.origen.recuperar, tipoFicha : FICHA.tipoFicha.bloqueada30dias });
									generalServiceOS.locationPath("/ficha");
									//$rootScope.message("Aviso ", ["La solicitud ha sido bloqueada por el número de rechazos del gerente"],"Aceptar","/ficha",null,null,null);
								}else{
								}
							}else{
							}							
							
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 
			                modalService.alertModal("Error "+error.status, [error.statusText]);
							
						}
					);
		    }
			
				/** Esta función se invoca después de hacer clic en el botónde guardado, si algún documento hace falta actalizar.
				 * haya quedado en pendiente de digitalizar, rechazado. Actualiza el documento
				 *  **/
			var validarDocumentosFnc = function(documentosObj){
				var docsString = generalServiceOS.delete$$hashKey(documentosObj);								
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				
				if( STATUS_SOLICITUD.autorizada.marca.pendienteDigitalizar == $rootScope.solicitudOSJson.marca || (STATUS_SOLICITUD.autorizada.marca.docDigitalizado == $rootScope.solicitudOSJson.marca && $rootScope.solicitudOSJson.documentos.documento[2].idMotivoRechazo>0) ){
					var digitDocRequest = {
							jsonSolicitud: $rootScope.solicitudOSJson,
							imagenB64: $scope.datosDoc[COMP_INGRESOS.id].img1.replace("data:image/png;base64,","")
					};	
					
					documentosService.actualizaComprobante(digitDocRequest).then(
							function(data){
								$rootScope.waitLoaderStatus = LOADER_HIDE;

								if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
									var responseJson = JSON.parse(data.data.respuesta);														
									
									if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){								
										$rootScope.solicitudOSJson = responseJson.data;
										$rootScope.solicitudOSJson.marca = STATUS_SOLICITUD.autorizada.marca.docDigitalizado;
										$rootScope.calculaDocumentos();
										generalServiceOS.locationPath("/ochoPasosOS");
										
									}else if(responseJson.codigo != undefined && responseJson.codigo == RESPONSE_BLOQUEO_OFERTA_30_DIAS){
										$rootScope.solicitudOSJson.marca = STATUS_SOLICITUD.autorizada.marca.bloqueoIntentos;
										$rootScope.solicitudOSJson.banderaIngresos = 0;
										actualizaSolicitud($rootScope.solicitudOSJson);
									}else{	
										$rootScope.solicitudOSJson.documentos.porcentaje = porcentajeAnterior;
										$scope.datosDoc[docId].img1 = null;
										$rootScope.message("Expediente",["Ocurrió un error al actualizar el comprobante."], "Aceptar", null, "bgCafe", "cafeD");
									}
								}else{
									$rootScope.solicitudOSJson.documentos.porcentaje = porcentajeAnterior;
									$scope.datosDoc[docId].img1 = null;
									$rootScope.message("Expediente",["Error en la respuesta del servicio para actualizar comprobante. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafe", "cafeD");
								}
								
							}, function(error){
					            $rootScope.waitLoaderStatus = LOADER_HIDE;
					            $rootScope.solicitudOSJson.documentos.porcentaje = porcentajeAnterior;
					            $scope.datosDoc[docId].img1 = null;	                
							}
						);
				}else{
					/** Valida los documentos, si la respuesta es de exito los encola **/
					
					encolarImagenesIpad("responseEnvioImgIpad", 0);
					
//					documentosService.validarDocumentos( { idSolicitud: $rootScope.solicitudOSJson.idSolicitud, jsonDoc: docsString, folioPer: $rootScope.solicitudOSJson.cotizacion.clientes[0].folioIdentificacion,folioAval: $rootScope.solicitudOSJson.avales[0].folioIdentificacion } ).then(
//							function(data){
//								$rootScope.waitLoaderStatus = LOADER_HIDE;
//															
//								if(data.data.codigo == RESPONSE_CODIGO_EXITO){
//									var responseJson = JSON.parse(data.data.respuesta);
//									
//									if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){	
//										
//										$rootScope.solicitudOSJson = responseJson.data;																																
//										$rootScope.calculaDocumentos();																					
//										encolarImagenesIpad("responseEnvioImgIpad");
//										
//										/**************************************/
////										if($rootScope.consultaFuncionalidad.flujoRechazoGerenteCondicionamiento && ($rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.condicionadoMesa && $rootScope.solicitudOSJson.cotizacion.clientes[0].flujoEfectivo[0].monto < 20000) && !bandDocCapturado){
////											envioRechazoGerenteMCO();
////										}else{
////											generalServiceOS.locationPath( "/ochoPasosOS" );
////										}
//										/**************************************/
//										
//									}else{	
//										$rootScope.waitLoaderStatus = LOADER_HIDE;
//										
//										if(responseJson.codigo == ERROR_SOL_RECHAZADA){										
//											var buildJsonDefault=function(){generalServiceOS.buildsolicitudOSJson($rootScope, null);};
//											$rootScope.message(	"Error en solicitud", [ "La solicitud no puede ser modificada debido a que se encuentra Cancelada o Rechazada." ],
//													"Aceptar", "/simulador",  "bgCafe" , "cafeD", buildJsonDefault);
//										}else													
//											$rootScope.message("Expediente",["Ocurrió un error al validar los documentos."], "Aceptar", null, "bgCafe", "cafeD");
//																																						
//									}									
//										
//									
//								}else{
//									$rootScope.waitLoaderStatus = LOADER_HIDE;
//									$rootScope.message("Expediente",["Error en la respuesta del servicio para para validar los documentos. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafe", "cafeD");
//								}											
//																																																									
//															
//							}, function(error){								
//				                $rootScope.waitLoaderStatus = LOADER_HIDE;			                	                					
//							}
//						);
				}
			};
			
			/**
			 * Función para consumir el servicio que va a mesa de control
			 **/
//			function envioRechazoGerenteMCO(){
//				$rootScope.waitLoaderStatus = LOADER_SHOW;
//				
//				$timeout(function(){
//					solicitudService.enviarRechazoGerenteMCO($rootScope.solicitudOSJson.idSolicitud).then(
//    						function(data){
//    							$rootScope.waitLoaderStatus = LOADER_HIDE;
//    							
//							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
//								var response = JSON.parse(data.data.respuesta);
//								$rootScope.solicitudOSJson = response.data;
//								
//								if(response.codigo == 2){
//									generalServiceOS.locationPath( "/estatus" );
//								}else{
//								    $rootScope.message("Código " + response.codigo, ["Ocurrio un error al enviar rechazo de Gerente"], "Aceptar", null, "bgCafe", "cafeD");
//								}
//							}else{
//								$rootScope.message("Aviso", ["Error al enviar los documentos digitalizados."], "Aceptar", null, "bgCafe", "cafeD");
//							}
//						},function(error){
//							$rootScope.waitLoaderStatus = LOADER_HIDE;
//						}
//					);
//				}, 3000);
//			}
			
			/**Encolamos los documentos **/
			
			var encolarImagenesIpad = function(funCallback, index){

				/**
				 * Se usa solo para el comprobante de domicilio
				 * Se crea el esquema de envio de documentos en linea
				 **/
				if(index < $rootScope.solicitudOSJson.documentos.documento.length){
					var _capturarImgnIpadResponse = $scope.datosDoc[ $rootScope.solicitudOSJson.documentos.documento[index].idDocumento].paramsIpad.capturarImgnIpadResponse;
					var formato = "jpg";
					
					try{
						formato = (_capturarImgnIpadResponse.formato != "" && _capturarImgnIpadResponse.formato != undefined)?_capturarImgnIpadResponse.formato:"jpg";
					}catch(e){
					}
					
					if(_capturarImgnIpadResponse != null){
						envioDocumentosEnLinea(_capturarImgnIpadResponse,$rootScope.solicitudOSJson.documentos.documento[index],0, index,formato);
					}else{
						index = index + 1;
						encolarImagenesIpad("responseEnvioImgIpad", index);
					}
				}else{
					generalServiceOS.locationPath("/ochoPasosOS");
				}
			};
			
			/** Envía los documentos de en linea **/
			function envioDocumentosEnLinea(_capturarImgnIpadResponse,doc,index, indexPadre,formato){
				
				for(var i=0;i<$rootScope.solicitudOSJson.documentos.documento.length;i++){
					if(doc.idDocumento === $rootScope.solicitudOSJson.documentos.documento[i].idDocumento){
						$rootScope.solicitudOSJson.documentos.documento[i].status = 4;
						break;
					}
				}
				
				var digitDocRequest = {
						idSolicitud: $rootScope.solicitudOSJson.idSolicitud,
						extensionIMG: formato,
						imagenB64: _capturarImgnIpadResponse.arrArchBase64[index],
						idDocumento: doc.idDocumento,										
						consecutivoPersona: "0",
						porcentaje: generalServiceOS.porcentajeDocs( $rootScope ).toString()
				};		    			    	

				$rootScope.waitLoaderStatus = LOADER_SHOW;
				obligadoSolidarioService.digitalizarImagenOS(digitDocRequest).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
		
						if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
							var responseJson = JSON.parse(data.data.respuesta);														
							
							if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){								
								if(index < (_capturarImgnIpadResponse.arrArchBase64.length-1)){
									index = index + 1;
									$rootScope.solicitudOSJson = responseJson.data;
									envioDocumentosEnLinea(_capturarImgnIpadResponse,doc,index,indexPadre,formato);
								}else{
									indexPadre = indexPadre + 1;
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									$rootScope.solicitudOSJson = responseJson.data;
									encolarImagenesIpad("responseEnvioImgIpad", indexPadre);
								}
							}else{
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message("Expediente",["Ocurrió un error al guardar el documento. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafe", "cafeD");
							}
						}else{
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$rootScope.message("Expediente",["Error en la respuesta del servicio al digitalizar el documento. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafe", "cafeD");
						}
						
					}, function(error){
			            $rootScope.waitLoaderStatus = LOADER_HIDE;	                
					}
				);
			}
			
				/** Inicia el proceso de encolamiento y envío de documentos **/
			var encolarDocumentos = function(_capturarImgnIpadResponse,doc, funCallback){					
				arrayDocsId.push(doc.idDocumento);
																										
				angular.forEach( _capturarImgnIpadResponse.arrArchBase64, function(fileB64, key){
					
					numImgEncoladas++;
					if(documento.length > 0)
						documento += ",";
					
					documento += $scope.datosDoc[doc.idDocumento].descripcion + " "+ $scope.datosDoc[doc.idDocumento].paramsIpad.tipoPersona + " " + ((doc.idDocumento == IDENTIFICACION_OFICIAL.id || doc.idDocumento == IDENTIFICACION_OFICIAL_AVAL.id ) ? (key == 0? etiquetaFrente : etiquetaReverso) : key);
					
					$rootScope.enviarImagen(
							$rootScope.solicitudOSJson.cotizacion.clientes[0].idPersona,
							_capturarImgnIpadResponse.arrNomArchBase64[key],								
							"digitalizacion",
							$scope.datosDoc[doc.idDocumento].descripcion + " "+ $scope.datosDoc[doc.idDocumento].paramsIpad.tipoPersona + " " + ((doc.idDocumento == IDENTIFICACION_OFICIAL.id || doc.idDocumento == IDENTIFICACION_OFICIAL_AVAL.id ) ? (key == 0? etiquetaFrente : etiquetaReverso) : key),
							'expDigi',
							buildDigitDocRequest( doc.idDocumento, $scope.datosDoc[doc.idDocumento].consecutivoPersona, fileB64 ),
							funCallback
						);						
				});
								
			};
			
			/** Si la respuesta del componente es OK, ejecuta la función execute action para enviar los documentos **/
			$scope.responseEnvioImgIpad = function(responseIPAD){														
				numImgEncoladas--;												
				$rootScope.loggerIpad("responseEnvioImgIpad", null, responseIPAD);
				if(numImgEncoladas == 0){
					
					
					generalServiceOS.setArrayValue("IdentificadoresDocs",arrayDocsId);
					$rootScope.documetosResponseCita = false;
					$rootScope.executeAction( "moduloTracker", "executeActionResponseExp",  
								  { nombre:"envioDocumentos", idCliente:$rootScope.solicitudOSJson.cotizacion.clientes[0].idPersona, mostrarSpinner:0, 
			                        filtroDocumentos: documento   } );
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalServiceOS.locationPath("/ochoPasosOS");
				}
					
				
			};
			
								
			/** La función es invocado para iniciar con el proceso de validación **/
			$scope.validar = function(){
						$rootScope.solicitudOSJson.documentos.porcentaje = generalServiceOS.calculaPorcentajeDocs($rootScope);		
						//var docsString = generalServiceOS.delete$$hashKey($rootScope.solicitudOSJson.documentos);
						$scope.documentos = $rootScope.solicitudOSJson.documentos;
						var solicitudOSJsonString = generalServiceOS.delete$$hashKey($rootScope.solicitudOSJson);
						var documentosValidados = 0;
						var documentosRechazados = 0;
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						
						/*var jsonRequest = { 
							idSolicitud: $rootScope.solicitudOSJson.idSolicitud,
							estatus: $rootScope.solicitudOSJson.idSeguimiento,
							marca: $rootScope.solicitudOSJson.marca,
							jsonDoc: JSON.parse(docsString),
						};*/
						
						obligadoSolidarioService.guardaSeccionOS( { solicitudOSJson: solicitudOSJsonString, seccion: 7 } ).then(
								function(data){			
//									if($rootScope.solicitudOSJson.banderaIngresos == 1 && $rootScope.solicitudOSJson.cotizacion.clientes[0].flujoEfectivo[0].monto >= 20000.0){
//										solicitudService.enviarIngresosCompMayoresA20k($rootScope.solicitudOSJson.idSolicitud).then(function(data){},function(error){});	
//									}
									
									
//									var bandDocRechazado = 0;
//									if($rootScope.solicitudOSJson.documentos.documento == null)
//										$rootScope.solicitudOSJson.documentos.documento=[];
//									
//									for(var i=0;i<$rootScope.solicitudOSJson.documentos.documento.length;i++){
//										if($rootScope.solicitudOSJson.documentos.documento[i].status == STATUS_RECHAZADO){
//											bandDocRechazado = 1;
//											break;
//										}
//									}									
									
									if(data.data.codigo == RESPONSE_CODIGO_EXITO){
										if(data.data.respuesta != undefined){
											var jResponse = JSON.parse(data.data.respuesta);
											
											if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){																																		
												//if( $scope.checkDocumentos.numDocsOK == $scope.checkDocumentos.docsVisibles){
													//$rootScope.solicitudOSJson.marca = ($rootScope.solicitudOSJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.docPendValidar)?STATUS_SOLICITUD.autorizada.marca.DocValidado:STATUS_SOLICITUD.autorizada.marca.expValGerente;
														
													
													for(var i = 0; i< $scope.documentos.documento.length; i++){
														if($scope.documentos.documento[i].status == STATUS_VALIDADO)
															documentosValidados++;
														if($scope.documentos.documento[i].status == STATUS_RECHAZADO)
															documentosRechazados++;
													}
													
													if(documentosRechazados > 0)
														actulizarMarca($rootScope.solicitudOSJson.idSolicitud, $rootScope.solicitudOSJson.idSeguimiento, STATUS_SOLICITUD.autorizada.marca.expRechazado);
													
													else if($scope.documentos.documento.length == documentosValidados)
												    	actulizarMarca($rootScope.solicitudOSJson.idSolicitud, $rootScope.solicitudOSJson.idSeguimiento, STATUS_SOLICITUD.autorizada.marca.liberadoOS);
													
													else
														generalServiceOS.locationPath( "/ochoPasosOS" );
													
													
													
													/**
														 * Validación para mostrar la ficha en el producto de tarjetas en cuando los documentos ya esten validados por el gerente
														 
														if ($rootScope.productosTarjetas($rootScope.solicitudOSJson.idProducto))
															generalServiceOS.locationPath( "/credito" );
														else{
															generalServiceOS.locationPath( "/ochoPasosOS" );
														}**/
													
												//}else if(($scope.checkDocumentos.numDocsOK + $scope.checkDocumentos.numDocsNotOK) == $scope.checkDocumentos.docsVisibles){
													//$rootScope.solicitudOSJson.marca = ($rootScope.solicitudOSJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.docPendValidar)?STATUS_SOLICITUD.autorizada.marca.docDigitalizado:STATUS_SOLICITUD.autorizada.marca.expRechazado;														
//													solicitudService.rechazoGerente( {idSolicitud: $rootScope.solicitudOSJson.idSolicitud} );
													
													/**
													 * Se valida el flujo de rechazo gerente por MCO, 
													 * Si el parametro esta prendido y esta en estatus de condicionado
													 * Tiene ingresos menores a 20000
													 * Al menos un documento rechazado
													 * Si no se cumplen las condiciones anteriormente descritas, mada a los 8 pasos
													 **/
//													if($rootScope.consultaFuncionalidad.flujoRechazoGerenteCondicionamiento && $rootScope.solicitudOSJson.cotizacion.clientes[0].flujoEfectivo[0].monto < 20000 && bandDocRechazado){
//														envioRechazoGerenteMCO();
//													}else{
//														generalServiceOS.locationPath( "/ochoPasosOS" );
//													}		
													//generalServiceOS.locationPath( "/ochoPasosOS" );
												
												//}																					
											}else if(jResponse.codigo != 126)	{
												$rootScope.message("Código "+jResponse.codigo, ["Error al obtener la solicitud mediante su ID."], "Aceptar", "/ochoPasosOS", "bgCafe", "cafeD");
											}else if(jResponse.codigo != 189)	{
												$rootScope.message("Código "+jResponse.codigo, ["Error al validar los documentos"], "Aceptar", "/ochoPasosOS", "bgCafe", "cafeD");
											}else if(jResponse.codigo != 188)	{
												/**
												 * Se arma un json que contendrá la información necesaria para recupera una solicitud por ID
												 * idSolicitud -> el id de la solicitud en cuestión
												 * idEstatusSeguimiento -> el estatus en el que se encuentra actualmente la solicitud
												 * fiStatusLcrID -> Estatus de la LCR
												 **/
												var selected = {
													  originalObject: {
														  idSolicitud : $rootScope.solicitudOSJson.idSolicitud,
														  idEstatusSeguimiento: $rootScope.solicitudOSJson.idSeguimiento,
														  fiStatusLcrID: $rootScope.solicitudOSJson.idEstatusLCR,
														  tipoPersona: ""
													  }
												  }

												  generalServiceOS.setArrayValue("selectedBusqueda", selected);
												
												$rootScope.message("Código "+jResponse.codigo, ["No se puede continuar debido a que el Expediente ha sido enviado a Mesa de Control para su Validación."], "Aceptar", "/recuperaSolicitud", "bgCafe", "cafeD");
											}else {
												$rootScope.message("Aviso", ["Error inesperado, al validar los documentos."], "Aceptar", "/ochoPasosOS", "bgCafe", "cafeD");
											}
										}else{
											generalServiceOS.locationPath("/ochoPasosOS");
										}
										
									}else
										$rootScope.message($scope.$parent.titulo, ["Error en la respuesta del servicio para validar los documento(s). Por favor, reintente nuevamente."], "Aceptar", "/ochoPasosOS", "bgCafe", "cafeD");
										
									
								}, function(error){
					                $rootScope.waitLoaderStatus = LOADER_HIDE; 
									
								}
							);																
				
			};
			
			
			function actulizarMarca(idSolicitud, idSeguimiento, marca){
			 	var request = {
	    				idSolicitudOS: idSolicitud,
	    				status: idSeguimiento,
	    				idMarca: marca
	    				}
			 	$scope.actualizarMarca = marca;
	    	obligadoSolidarioService.actualizarStatusOS(request).then( function(data) {
	    		$rootScope.waitLoaderStatus = LOADER_HIDE;
	    				
	    		if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
	    			var jsonResponse = JSON.parse(data.data.respuesta);	
	    			
	    			if(jsonResponse.codigo == 2){
	    				$rootScope.solicitudOSJson.marca = $scope.actualizarMarca
	    				generalServiceOS.locationPath( "/ochoPasosOS" );
	    			}else
	    				$rootScope.message("Error",[jsonResponse.codigo + "Ocurrió un problema al validar los documentos intente nuevamente"], "Aceptar", null, "bgCafe", "cafeD");
	    		}else
	    			$rootScope.message("Error",[data.data.codigo + "Ocurrió un problema al validar los documentos intente nuevamente"], "Aceptar", null, "bgCafe", "cafeD");
	    		
	    	}, function(error) {
	    		$rootScope.waitLoaderStatus = LOADER_HIDE;
	    		$rootScope.message("Error",["Ocurrió un problema al validar los documentos intente nuevamente"], "Aceptar", null, "bgCafe", "cafeD");
	    		});
			}
			
			
			/**
			 * Al activar el botón de validar, muestra los documentos dependiendo del tipo de documentos seleccionado para realizar la validación
			 * **/
			$scope.validaDoc = function (idDoc){									
				var imgs = new Array();
				var texto = "";
				
				if(idDoc == IDENTIFICACION_OFICIAL.id  ||  idDoc == IDENTIFICACION_OFICIAL_AVAL.id)
					texto = "Valida que los datos capturados en la solicitud coincidan con la "+IDENTIFICACION_OFICIAL.descripcion;
					
				else if(idDoc == COMP_INGRESOS.id){
					texto = "Esta Línea de Crédito se esta originando con ingresos comprobables por lo que es necesario que valides que el "+ COMP_INGRESOS.descripcion +
							" esté digitalizado y forma parte del expediente. Los ingresos mensuales declarados son $ "+generalServiceOS.numberWithCommas($rootScope.solicitudOSJson.cotizacion.clientes[0].flujoEfectivo[0].monto) +
							" por favor valida que el comprobante corresponda a ese ingreso.";
				}else
					texto = "Valida que los datos capturados en la solicitud coincidan con el  "+$scope.datosDoc[idDoc].descripcion;
				
				
				
				if((idDoc == COMP_DOMICILIO.id  ||  idDoc == COMP_INGRESOS.id) && $scope.datosDoc[idDoc].imgTmp.show)
					idDoc = $scope.datosDoc[idDoc].imgTmp.imgOriginal.id;				
				
				
				imgs.push($scope.datosDoc[idDoc].img1.split(",")[1]);
				angular.forEach($scope.datosDoc[idDoc].imgs, function(img, key){										
					imgs.push(img);
				});
					
				$scope.checkDocumentos.numDocsOK = 0;
				$scope.checkDocumentos.numDocsNotOK = 0;
				/** Carga el modal para mostrar los documentos pendientes de validar**/
				modalService.validaDocsModal($scope.datosDoc[idDoc].descripcion, "bgCafe",  idDoc, imgs, texto).then( 
								function(estatus) {
									angular.forEach( $rootScope.solicitudOSJson.documentos.documento, function(doc){																																	
										if( doc.idDocumento == idDoc){					
											doc.status = estatus;											
											$scope.datosDoc[doc.idDocumento].status = estatus;
											
											if(estatus == STATUS_RECHAZADO){
												$scope.datosDoc[idDoc].checked = false;
												doc.idMotivoRechazo = $rootScope.rechazo.motivo.id;
												doc.observacion = $rootScope.rechazo.obsRechazo;
												
											}else												
												$scope.datosDoc[idDoc].checked = true;		
										}
										
										countStatusDoc(doc.status, $scope.datosDoc[doc.idDocumento].showDoc);																						
										
									});	
																		
									
								}, function(error) {
									console.log("close dialog");
									angular.forEach( $rootScope.solicitudOSJson.documentos.documento, function(doc){
										countStatusDoc(doc.status, $scope.datosDoc[doc.idDocumento].showDoc);
									});
									
								}
							);								
			};
									
			
			/** No encontré su funcionalidad ya que no se invoca de ningún lado, pero se deja por si acaso **/
			$scope.setCompDomicilio = function(data){				
				
				angular.forEach( $rootScope.solicitudOSJson.documentos.documento, function(doc){																																	
					if( doc.idDocumento == data.id){
						doc.idTipoDocumento = data.tipo.id;
						doc.tipoDocumentoDes =  generalServiceOS.toUpperCaseSinAcentos( data.tipo.descripcion );  
					}
				});
				
//				if( $scope.$parent.isTienda )
				if(!$scope.$parent.isTienda){
					imageAux = data.imagen.replace("data:image/jpeg;base64,","");
					imageAux = imageAux.replace("data:image/png;base64,","");
				}
					$scope.capturarImagen(data.id, data.tipo.id);
					
//				else{				
//					guardarDocumentoSolicitud(data.imagen.split(",")[1], "jpg", data.id, $scope.datosDoc[data.id].consecutivoPersona);																													
//					widthImage(data.imagen, data.id);
//				}
															
			};
			
			/** No encontré su funcionalidad ya que no se invoca de ningún lado, pero se deja por si acaso **/
			$scope.sendIentificacionOficial = function(identificacionObj){										
				if(identificacionObj.dia=="")
					identificacionObj.dia="31";
				if(identificacionObj.mes=="")
					identificacionObj.mes="12";				
				angular.forEach( $rootScope.solicitudOSJson.documentos.documento, function(doc){																																	
					if( doc.idDocumento == identificacionObj.tipo.id){
						
						doc.idTipoDocumento = identificacionObj.tipo.id;
						doc.tipoDocumentoDes =  generalServiceOS.toUpperCaseSinAcentos( identificacionObj.tipo.descripcion );
						
//						if( identificacionObj.id == 1 ){	//cliente
							$rootScope.solicitudOSJson.cotizacion.clientes[0].folioIdentificacion = identificacionObj.folio;
							$rootScope.solicitudOSJson.cotizacion.clientes[0].fechaVigenciaIdentificacion = doc.fechaVigencia = identificacionObj.dia+"/"+identificacionObj.mes+"/"+identificacionObj.anio;
							$scope.cambioIdent=true;
//						}else{ //aval
//							$rootScope.solicitudOSJson.avales[0].folioIdentificacion = identificacionObj.folio;
//							$rootScope.solicitudOSJson.avales[0].fechaVigenciaIdentificacion = doc.fechaVigencia = identificacionObj.dia+"/"+identificacionObj.mes+"/"+identificacionObj.anio;
//						}
						
					}
					
					
				});
				
				
				/** Captura la imagen si es un IPAD o en su caso solo se adjunta pero solo para desarrollo **/
//				if( $scope.$parent.isTienda )
				if(!$scope.$parent.isTienda){
					imageAux = identificacionObj.imagen.replace("data:image/jpeg;base64,","");
					imageAux = imageAux.replace("data:image/png;base64,","");
				}
					$scope.capturarImagen(identificacionObj.id, identificacionObj.tipo.id);
//				else{
//					guardarDocumentoSolicitud(identificacionObj.imagen.split(",")[1], "jpg", identificacionObj.id, $scope.datosDoc[identificacionObj.id].consecutivoPersona);
//					$scope.datosDoc[identificacionObj.id].sent = false;							
//					expedienteService.buildImage(identificacionObj.imagen, identificacionObj.id, $scope, formatoDocumento);
//				}
																
			};		    								
			
			/**Tamaño de la imagen**/
			function widthImage(imgB64, docId){				
				expedienteService.buildImage(imgB64, docId, $scope, formatoDocumento);				
			};
						
			
			
			function buildDigitDocRequest(idDoc, consecPersona, imgB64){												
				var fotoCte = null;
				if( !generalServiceOS.isEmpty( $rootScope.fotoOS ) )
					fotoCte = $rootScope.fotoOS.split(",")[1];
				
				var nombreCte = $rootScope.solicitudOSJson.cotizacion.clientes[0].nombre+' '+$rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno;				
				
				return generalServiceOS.buildDigitDocRequest( $rootScope.solicitudOSJson.idSolicitud, idDoc, consecPersona, imgB64, nombreCte, $rootScope.fotoCteOriginalOS );	
			};
			
			
			
			/**
			 * Actualiza el documento pendiente, además de actulizar el JSON de la solicitud
			 * En caso contrario en caso contrario invoca el servicio de digitalizar con los pametros necesario
			 * **/
			function guardarDocumentoSolicitud(imgB64, extImg, docId, consecutivoPersona){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				
				if(STATUS_SOLICITUD.autorizada.marca.pendienteDigitalizar == $rootScope.solicitudOSJson.marca){
					var digitDocRequest = {
							jsonSolicitud: $rootScope.solicitudOSJson,
							imagenB64: imgB64
					};	
					
					documentosService.actualizaComprobante(digitDocRequest).then(
							function(data){
								$rootScope.waitLoaderStatus = LOADER_HIDE;

								if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
									var responseJson = JSON.parse(data.data.respuesta);														
									
									if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){								
										$rootScope.solicitudOSJson = responseJson.data;
										$rootScope.solicitudOSJson.marca = STATUS_SOLICITUD.autorizada.marca.docDigitalizado;
										$rootScope.calculaDocumentos();
										
									}else{	
										$rootScope.solicitudOSJson.documentos.porcentaje = porcentajeAnterior;
										$scope.datosDoc[docId].img1 = null;
										$rootScope.message("Expediente",[$scope.mensajeError], "Aceptar", null, "bgCafe", "cafeD");
									}
								}else if(responseJson.codigo != undefined && responseJson.codigo == RESPONSE_BLOQUEO_OFERTA_30_DIAS){
									$rootScope.solicitudOSJson.marca = STATUS_SOLICITUD.autorizada.marca.bloqueoIntentos;
									$rootScope.solicitudOSJson.banderaIngresos = 0;
									actualizaSolicitud($rootScope.solicitudOSJson);
								}else{
									$rootScope.solicitudOSJson.documentos.porcentaje = porcentajeAnterior;
									$scope.datosDoc[docId].img1 = null;
									$rootScope.message("Expediente",["Error en la respuesta del servicio para actualizar el comprobante(s). Por favor, reintente nuevamente."], "Aceptar", null, "bgCafe", "cafeD");
								}
								
							}, function(error){
					            $rootScope.waitLoaderStatus = LOADER_HIDE;
					            $rootScope.solicitudOSJson.documentos.porcentaje = porcentajeAnterior;
					            $scope.datosDoc[docId].img1 = null;	                
							}
						);
				}else{
					var porcentajeAnterior = $rootScope.solicitudOSJson.documentos.porcentaje;				
					
					var digitDocRequest = {
											idSolicitud: $rootScope.solicitudOSJson.idSolicitud,
											extensionIMG: extImg,
											imagenB64: imgB64,
											idDocumento: docId.toString(),										
											consecutivoPersona: consecutivoPersona.toString(),
											porcentaje: generalServiceOS.porcentajeDocs( $rootScope ).toString()
									};		    			    	
					
					documentosService.digitalizar( digitDocRequest ).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;

							if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
								var responseJson = JSON.parse(data.data.respuesta);														
								
								if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){								
									$rootScope.solicitudOSJson = responseJson.data;														
									$scope.datosDoc[docId].sent=true;
									
									imgDocumento[docId].imgB64 = null;
									imgDocumento[docId].width = null;
									imgDocumento[docId].height = null;
									
									$rootScope.calculaDocumentos();
									
								}else{	
									$rootScope.solicitudOSJson.documentos.porcentaje = porcentajeAnterior;
									$scope.datosDoc[docId].img1 = null;
									$rootScope.message("Expediente",["Ocurrió un error al digitalizar"], "Aceptar", null, "bgCafe", "cafeD");
								}
							}else{
								$rootScope.solicitudOSJson.documentos.porcentaje = porcentajeAnterior;
								$scope.datosDoc[docId].img1 = null;
								$rootScope.message("Expediente",["Error en la respuesta del servicio al digitalizar el documento. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafe", "cafeD");
							}
							
						}, function(error){
				            $rootScope.waitLoaderStatus = LOADER_HIDE;
				            $rootScope.solicitudOSJson.documentos.porcentaje = porcentajeAnterior;
				            $scope.datosDoc[docId].img1 = null;	                
						}
					);		    	
				}
			};						
			
			
		});
		
		
		
});