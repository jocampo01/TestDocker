'use strict';

define(["app"], function (app) {
	
	app.controller('expedienteOSController', function($http, $compile, $rootScope, $scope, ngDialog, generalServiceOS, expedienteService, modalService, solicitudService, documentosService, messageData, clienteUnicoService, validateService) {
		
		var arrayImagesExpIpad = new Array();
		var documentoEnviado = false;	
		var documentoEncolado = false;
		var index = 0;
		
		$scope.imagesDocsIpad = new Array();;	
		$scope.imagesDocsWS = null;
		$scope.esGerente = false;									
		$rootScope.showDatosHogarOS = true;
		/**
		 * Funcion Principal
		 **/
		$scope.init = function(){
			$scope.isTienda = configuracion.origen.tienda;
			
			$scope.showPage = messageData;
			if( messageData  ){																																							
				
				$scope.origen = configuracion.origen.tienda == true? "TIENDA":"WEB";
				$scope.labelTiempo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO TIEMPO."+$scope.origen+".valor"];
				$scope.labelMin = " " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO MIN."+$scope.origen+".valor"];

				getExpediente();
			}else{
				$rootScope.message(ERROR_CARGA_PAGINA.titulo, [ERROR_CARGA_PAGINA.texto], "Aceptar", "/", "bgCafe", "cafeD");
			}
		};
		
		function getExpediente(){
			if( generalServiceOS.existeSolicitud($rootScope.solicitudOSJson) ){
					generalServiceOS.setRespaldo($rootScope.solicitudOSJson);														
					
					/**
					 * Sección dentro de la funcion getExpediente, para verificar el proceso de la validacion de expedientes por gerente.
					 **/
					var bandRechazado = 0;
					for(var i=0;i<$rootScope.solicitudOSJson.documentos.documento.length;i++){
						if($rootScope.solicitudOSJson.documentos.documento[i].status == STATUS_RECHAZADO){
							bandRechazado = 1;
							break;
						}
					}
					
					$scope.esGerente = (
											( $rootScope.userSession.idPuesto == PUESTO_GERENTE || 
											  $rootScope.userSession.idPuesto == PUESTO_GERENTE_PRUEBA || ($rootScope.sucursalSession!=null  &&  generalServiceOS.isCanalExterno($rootScope.sucursalSession.idCanal) ))  && 
											$rootScope.solicitudOSJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && 
											($rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.docvalidacionPendienteOS ||
											($rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.docPendValidar && !bandRechazado) ||
											($rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.expRechazado && !bandRechazado))
										);
					
					/**
					 * Se verifica, si es canal externo, es gerente, canal externo, y el empleado logueado es el mismo que la originó, se lemuestra un mensaje
					 **/
					if($scope.esGerente  &&  generalServiceOS.isCanalExterno($rootScope.sucursalSession.idCanal)  &&  $rootScope.userSession.noEmpleado == $rootScope.solicitudOSJson.idEmpleado ){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						modalService.alertModal("Aviso", ["La revisión del expediente debe realizarse por otro ejecutivo."]).closePromise.then(
							function(exito){
								generalServiceOS.locationPath("/ochoPasosOS");																
							},function(error){
								generalServiceOS.locationPath("/ochoPasosOS");														
							}
						);
					}else{
						angular.forEach( $rootScope.solicitudOSJson.documentos.documento, function(doc, key){																																													
							if(generalServiceOS.documentoEnviadoWS(doc.status)){
								documentoEnviado = true;	
							}else if(doc.status == STATUS_ENCOLADO_IPAD ){
								documentoEncolado = true;
							}
						});
						
						if($scope.isTienda && documentoEncolado){																				
							/**
							 * Se obtienen imagenes de ipad.
							 **/
							$rootScope.obtenerEnviosXCliente('expDivId', 'getEnviosIpad', $rootScope.solicitudOSJson.cotizacion.clientes[0].idPersona);
						}else{
							/**
							 * Se obtienen imagenes del servicio de digitalización
							 **/
							getImagesService();
						}
					}																																																																					
			}else{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message(SIN_SOLICITUD.titulo, [SIN_SOLICITUD.texto], "Aceptar", "/", "bgCafe", "cafeD");
			}
					
		};
								
		
		$scope.getEnviosIpad = function(response){
			$rootScope.loggerIpad("getEnviosIpad", null, response);
			
			try{
				if(response.codigo==RESPONSE_CODIGO_EXITO_IPAD){
					angular.forEach(response.peticiones, function(data){					
						if(data.service == "digitalizacion"){
							arrayImagesExpIpad.push(data);
						}
					});
					
					if(arrayImagesExpIpad.length > 0){																		
						$rootScope.obtenerRecursoPendiente('expDivId', 'loadImagesIpad', arrayImagesExpIpad[index].identifier.toString());
					}else{
						getImagesService();
					}
				}else{
					getImagesService();
				}
			}catch(e){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("e", [e], "Aceptar", null, "bgCafe", "cafeD");
			}
		};

		$scope.loadImagesIpad = function(response){
			$rootScope.loggerIpad("loadImagesIpad", null, response);								
			
			if(response.codigo==RESPONSE_CODIGO_EXITO_IPAD){
				var jsonImage = {
									identifier: response.peticion.identifier,
									idTipoDoc: response.peticion.parameters.idDocumento, 
									nombreDoc: '',
									urlDoc: null,
									imgB64: response.peticion.parameters.imagenB64,
									imgWidth: 0,
									imgHeight: 0,
									tipo: 'jpg' 
								};
				
				/**
				 * Arreglo que contiene las imagenes que estan encoladas en el iPad
				 **/
				$scope.imagesDocsIpad.push(jsonImage);
			}																
												
    			if($scope.imagesDocsIpad.length > 0  && $scope.imagesDocsIpad.length == arrayImagesExpIpad.length){        			        			        				   
    				getImagesService();
    			}else{
    				index++;
    				$rootScope.obtenerRecursoPendiente('expDivId', 'loadImagesIpad', arrayImagesExpIpad[index].identifier.toString());
    			}
		}
		
		/**
		 * Servicio que trae los documentos del servicio de digitalización.
		 **/
		function getImagesService(){
			
			if(documentoEnviado){
				var imagesRequest = {cuenta: $rootScope.solicitudOSJson.idSolicitud, idTipoDocto: "0", status: 1, opcion: 1};
				
				if(!generalServiceOS.isEmpty( $rootScope.solicitudOSJson.cotizacion.clientes[0].clienteTienda)){
					var cteTda = $rootScope.solicitudOSJson.cotizacion.clientes[0].clienteTienda.split("-");
					var sucursal = generalServiceOS.addZerosLeft(cteTda[1], 4);
					imagesRequest.cuenta = cteTda[0]+sucursal+cteTda[2]+cteTda[3];
				}

				$rootScope.waitLoaderStatus = LOADER_SHOW;
				documentosService.getImages( imagesRequest ).then(
					function(data){
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							/**
							 * Arreglo que contiene las imagenes que estan en central
							 **/
							$scope.imagesDocsWS = data.data.respuesta;	
							loadPage();
						}else{
							$rootScope.message("Expediente", [data.data.descripcion], "Aceptar", "/ochoPasosOS", "bgCafe", "cafeD");
							$rootScope.waitLoaderStatus = LOADER_HIDE;
						}	
						
					},function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;																
					}
				);
				
			}else{
				loadPage();
			}
			
		}
		
		function loadPage(){					
			$scope.htmlDocumentosOSDiv = "<div ng-include=\"'src/viewsControllers/obligadoSolidario/expedienteOS/docsExpedienteOSView.html'\" ></div>";												
		}											
	});
});