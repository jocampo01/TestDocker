'use strict';

define(["app"], function (app) {
	

	app.service('generalServiceOS', function ($rootScope, $location, securityService, generalService) 	                               	                               	                               
	{						
		var mensajeSoporte = "No es posible continuar con el proceso, para mayor información comuníquese con Soporte Técnico al 01 800 050 3358 ó 5515794296 opción 0.";
		var _validaContratos = true;
		var respaldoStringJson = null;
		var respaldoStringJsonDom = null;
		var codigosValidacion = null;
		var solicitudID = null;		
		var valuesArray = new Object();
		var loginOn = false;
		var dataBridge = null;
		var isAval=false;
		var _plazos=null;
		var _diasRechazo = 60;
		
		/** Valida la edad pra no otorgar creditos inmediatos a clientes entre 18 y 21 años, y siempre se mande a la visita de asesor 
		 * @param fecha de nacimiento del cliente en formato dd/mm/aaaa
		 * @return devuelve true si el cliente se encuentra entre 18 y 21 años y falso si es mayor a 21 
		 * */		
		
		var _validaEdad = function (dateString){
			 var dates = dateString.split("/");
			    var d = new Date();

			    var userday = dates[0];
			    var usermonth = dates[1];
			    var useryear = dates[2];

			    var newday = d.getDate();
			    var newmonth = d.getMonth()+1;
			    var newyear = d.getFullYear();

			    var age = newyear - useryear;

			    if((newmonth < usermonth) || ( (newmonth == usermonth) && newday < userday   )){

			        age--;

			    }

			    var result = age >= 18 && age <= 21 ? true : false

			    return result;
		}
												
		/** Obteien la descripcion de un catalogo en base a su ID
		 * @param id Identificador del catalogo
		 * @param catalogo Objeto tipo arregalo json [{id:9,descripcion:''}] con los valores del catalogo
		 * @return desCatalogo la descripcion del catalolgo 
		 * */		
		
		var _getProductosCredito = function (productos, idProductos){
			var descCatalog  = new Object();
			for( var key in idProductos){
				var index2 =  productos.map(function(d){
					return d["ID"].valor;
			    			
				}).indexOf (idProductos[key].toString());
				if (index2 != -1){
					descCatalog[idProductos[key]] = {label:productos[index2].ETIQUETA.valor, idLi: key};
				}
			}
			return descCatalog
		}
		
		/**
		 * Realiza la validacion si es credito inmediato dependiendo el producto y las
		 * vanderas que vengan activadas.
		 */
		var _validaCreditoInmediatoProducto = function(){
			var credInm = false;
			if($rootScope.consultaFuncionalidad.creditoInmediatoHabilitado){
				switch($rootScope.solicitudOSJson.idProducto){
					case ID_PRODUCTO.prestamoPersonal:
						if($rootScope.consultaFuncionalidad.creditoInmediatoHabilitadoPrestamos)
							credInm = true;
					break;
					case ID_PRODUCTO.consumo:
						if($rootScope.consultaFuncionalidad.creditoInmediatoHabilitadoConsumo)
							credInm = true;	
					break;
					case ID_PRODUCTO.italika:
						if($rootScope.consultaFuncionalidad.creditoInmediatoHabilitadoItalika)
							credInm = true;
					break;
					case ID_PRODUCTO.telefonia:
						if($rootScope.consultaFuncionalidad.creditoInmediatoHabilitadoTelefonia)
							credInm = true;
					break;
				}
			}
			return credInm;
		}
		
		
		var _getDataInput = function(seccion,elemento,origen){
			
			var opcional = _getDatafromCategory(seccion, elemento, "OPCIONAL.valor" );
			var textoOpcional = "";
			
			if( opcional )
				textoOpcional = " (Opcional)";
			
			var dataInput = {
					"tipoElemento"  : _getDatafromCategory(seccion, elemento, "tipoElemento"       ),
					"campo"         : _getDatafromCategory(seccion, elemento, "nombreElemento"     ),
					"marcaAgua"     : _getDatafromCategory(seccion, elemento, "MARCAAGUA.valor"    ) + textoOpcional,
					"visible"       : _getDatafromCategory(seccion, elemento, "VISIBLE.valor"      ),
					"deshabilitado" : _getDatafromCategory(seccion, elemento, "DESHABILITADO.valor"),
					"obligatorio"   : _getDatafromCategory(seccion, elemento, "OBLIGATORIO.valor"  ),
					"buro"          : _getDatafromCategory(seccion, elemento, "BURO.valor"         ),
					"cincom"        : _getDatafromCategory(seccion, elemento, "CINCOM.valor"       ),
					"opcional"      : _getDatafromCategory(seccion, elemento, "OPCIONAL.valor"     ),
					"estilo"        : _getDatafromCategory(seccion, elemento, "ESTILO.valor"       ),
					"imagen"        : _getDatafromCategory(seccion, elemento, "IMAGEN.valor"       ),
					"longMin"       : _getDatafromCategory(seccion, elemento, "LONGMIN.valor"      ),
					"longMax"       : _getDatafromCategory(seccion, elemento, "LONGMAX.valor"      ),
					"formato"       : _getDatafromCategory(seccion, elemento, "FORMATO.valor"      ),
					"valor"         : ""                                                            ,
					"pattern"       : _getDatafromCategory(seccion, elemento, "PATTERN.valor"      ),
					"texto"         : _getDatafromCategory(seccion, elemento, origen+".valor"      ),
					"colorModal"    : _getDatafromCategory(seccion, elemento, "COLORMODAL.valor"   ),
					"colorSeccion"  : _getDatafromCategory(seccion, elemento, "COLORSECCION.valor" ),
					"CATALOGO"      : "catalogo",
				};
			return dataInput;
		};
		
		var _descripcionCatalogo = function(id, catalogo){	
			var desCatalogo = '';
			angular.forEach( catalogo, function(value, key){
				if(id == value.id)
					desCatalogo = value.descripcion.trim();
											
			});
			
			desCatalogo = desCatalogo.toUpperCase().replace(/Á/g,"A").replace(/É/g,"E").replace(/Í/g,"I").replace(/Ó/g,"O").replace(/Ú/g,"U");
			
			
			
			return desCatalogo;
		};
		
		
		var _descripcionCatalogoConIdCU = function(id, catalogo){	
			var desCatalogo = {};
			angular.forEach( catalogo, function(value, key){
				if(id == value.id){					
					desCatalogo = value;
					desCatalogo.descripcion = value.descripcion.trim().toUpperCase().replace(/Á/g,"A").replace(/É/g,"E").replace(/Í/g,"I").replace(/Ó/g,"O").replace(/Ú/g,"U");;
				}
															
			});			
			
			return desCatalogo;
		};
		
		
		/** formatea el catalogo del modelo configurador a una lista tipo [{id: descripcion:}]
		 * @param nombreCatalogo Nombee del Catalogo del modelo configurador
		 * @return _catalogo una lista de tipo [{id: descripcion:}] 
		 * */				
		var _construirCatalogo = function(nombreCatalogo){	
			var _catalogo = [];					
			
			var arr = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS."+nombreCatalogo];
			
			if( _isDefined(arr)){
				for(var i=0; i < arr.length; i++)	{
					if(nombreCatalogo != "CATALOGO ANTIGUEDAD"){
						if(nombreCatalogo == "CATALOGO OFICIOS")
							_catalogo.push( {id: parseInt(arr[i].ID_ADN.valor), descripcion:arr[i].OFICIO.valor, tipoEmpleo:arr[i].ID_TIPO_EMPLEO.valor,idClienteUnico:arr[i].ID_CLIENTE_UNICO.valor,idAdnCu:arr[i].ID_ADN_CU.valor} );
						else
							_catalogo.push( {id: parseInt(arr[i].ID.valor), descripcion:arr[i].ETIQUETA.valor, prioridad:arr[i].PRIORIDAD.valor} );
					}else
						_catalogo.push( {id: parseInt(arr[i].ID.valor), descripcion:arr[i].ETIQUETA.valor} );
				}
			}
							
								
			return _catalogo;
		};
		
		
		var _construirCatalogoConIdCU = function(nombreCatalogo){	
			var _catalogo = [];					
			
			var arr = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS."+nombreCatalogo];
			
			if( _isDefined(arr)){
				for(var i=0; i < arr.length; i++){
					var cat = JSONtoMap(arr[i]);				
					_catalogo.push( {id: parseInt(cat["ID ADN.valor"]), idCU:parseInt(cat["ID CLIENTE UNICO.valor"]), descripcion:cat["OFICIO.valor"]} );
				}
			}																						
			return _catalogo;
		};
		
		
		var _construirCatalogoIdString = function(nombreCatalogo){	
			var _catalogo = [];					
			
			var arr = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS."+nombreCatalogo];
			
			for(var i=0; i < arr.length; i++)									
				_catalogo.push( {id: arr[i].ID.valor, descripcion:arr[i].ETIQUETA.valor, prioridad:arr[i].PRIORIDAD.valor} );				
								
			return _catalogo;
		};
		
		
		/** Convierte un objeto json a una cedan jsno eliminando los $$hashKey
		 * @param jsonObject Objeto json
		 * @return cadena em formato json 
		 * */	
		var _delete$$hashKey = function(jsonObject){	
			return JSON.stringify(jsonObject, function (key, val) { 
													 if (key == '$$hashKey')  
														 return undefined; 
													  
													  return val; 
												}); 
		};
		
		
//		var _validaConsultaBuro = function(solicitudJson){			
//			
//			if( solicitudJson.cotizacion.clientes[0].porcentaje == 100  && solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje == 100 && solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado == 0 &&
//				solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje == 100  && solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje == 100 
//				&& solicitudJson.consultaBuro == 0 )									
//				
//				return true;																				
//			else
//				return false
//		};
//		
//		
//var _validaConsultaBuro = function(solicitudJson){			
//			
//			if( solicitudJson.cotizacion.clientes[0].porcentaje == 100  && solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje == 100 && solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado == 0 &&
//				solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje == 100  && solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje == 100 
//				&& solicitudJson.consultaBuro == 0 )									
//				
//				return true;																				
//			else
//				return false
//		};
		
		var _validaConsultaBuro = function(solicitudJson){			
			
			if( solicitudJson.cotizacion.clientes[0].porcentaje == 100  && solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje == 100 /*&& solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado == 0*/ 
				/*&& solicitudJson.consultaBuro == 0*/ )									
				
				return true;																				
			else
				return false
		};
		
		var _bloqueaSecciones = function(ArraySecciones){/*funcion para bloquear secciones de ocho pasos*/
			for (var i = 0; i < ArraySecciones.length; i++){
				switch(ArraySecciones[i]) {
			    case SECCION_PERSONALES: /*SECCION_PERSONALES = 1*/
			    	$rootScope.solicitudOSJson.cotizacion.clientes[0].bloqueado = 1;
			        break;
			    case SECCION_HOGAR: /*SECCION_HOGAR = 2*/
			    	$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].bloqueado = 1;
			        break;
			    case SECCION_EMPLEO: /*SECCION_EMPLEO=3*/
			    	$rootScope.solicitudOSJson.cotizacion.clientes[0].datosEmpleo[0].bloqueado = 1;
			        break;
			    case SECCION_INGRESOS_GASTOS: /*SECCION_INGRESOS_GASTOS=4*/
			    	$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.bloqueado = 1;
			        break;
			    case SECCION_AVAL: /*SECCION_AVAL = 5*/
			    	$rootScope.solicitudOSJson.avales[0].bloqueado = 1;
			        break;
			    case SECCION_REFERENCIAS: /*SECCION_REFERENCIAS = 6*/
			    	$rootScope.solicitudOSJson.referencias.bloqueado = 1;
			        break;
			    case SECCION_DOCUMENTOS: /*SECCION_DOCUMENTOS = 7*/
			    	$rootScope.solicitudOSJson.documentos.bloqueado = 1;
			        break;
			    case SECCION_CONTRATOS: /*SECCION_CONTRATOS = 8*/
			    	$rootScope.solicitudOSJson.contratos.bloqueado = 1;
			        break;
				}
			}
		}/* termina funcion para bloquear secciones de ocho pasos*/
		
		var _noEditableSecciones = function(ArraySecciones){/*funcion para no editar secciones*/
			for (var i = 0; i < ArraySecciones.length; i++){
				switch(ArraySecciones[i]) {
			    case SECCION_PERSONALES: /*SECCION_PERSONALES = 1*/
			    	$rootScope.solicitudOSJson.cotizacion.clientes[0].editable = 1;
			        break;
			    case SECCION_HOGAR: /*SECCION_HOGAR = 2*/
			    	$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].editable = 1;
			        break;
			    case SECCION_EMPLEO: /*SECCION_EMPLEO=3*/
			    	$rootScope.solicitudOSJson.cotizacion.clientes[0].datosEmpleo[0].editable = 1;
			        break;
			    case SECCION_INGRESOS_GASTOS: /*SECCION_INGRESOS_GASTOS=4*/
			    	$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.editable = 1;
			        break;
			    case SECCION_AVAL: /*SECCION_AVAL = 5*/
			    	$rootScope.solicitudOSJson.avales[0].editable = 1;
			        break;
			    case SECCION_REFERENCIAS: /*SECCION_REFERENCIAS = 6*/
			    	$rootScope.solicitudOSJson.referencias.editable = 1;
			        break;
			    case SECCION_DOCUMENTOS: /*SECCION_DOCUMENTOS = 7*/
			    	$rootScope.solicitudOSJson.documentos.editable = 1;
			        break;
			    case SECCION_CONTRATOS: /*SECCION_CONTRATOS = 8*/
			    	$rootScope.solicitudOSJson.contratos.editable = 1;
			        break;
				}
			}
		}/* termina funcion para no editar secciones*/
		
		
		
		var _validaConsultaBuroFinal = function(solicitudJson){						
			if( solicitudJson.cotizacion.clientes[0].porcentaje == 100  &&  
				solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje == 100 &&  
				solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje == 100 &&  
				solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje == 100  &&
				((solicitudJson.avales[0].porcentaje == 100  &&  
				  solicitudJson.avales[0].datosHogar.porcentaje == 100 &&
				  solicitudJson.cotizacion.detallesCotizacion[0].monto > 5000) || solicitudJson.cotizacion.detallesCotizacion[0].monto <= 5000) &&
				solicitudJson.referencias.porcentaje == 100  &&
				solicitudJson.documentos.porcentaje == 100   
			)									
				
				return true;																				
			else
				return false
		};
		
		var _validaTermino=function(solicitudJson){
			var monto=solicitudJson.cotizacion.detallesCotizacion[0].monto;
			var porCliente=solicitudJson.cotizacion.clientes[0].porcentaje;
			var porDomicil=solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje;
			var porEmpleo =solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje;
			var porIngreso=solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje;
			var porAvales =solicitudJson.avales[0].porcentaje;
			var porReferen=solicitudJson.referencias.porcentaje;
			var porExpedie=solicitudJson.documentos.porcentaje;
			var porContrat=solicitudJson.contratos.porcentaje;
			if (solicitudJson.envioCelular == 1)
			    var codigo=true;
			if(porCliente==100 && porDomicil==100 && porEmpleo ==100 && 
			   porIngreso==100 && ((porAvales ==100 && monto > 5000) || monto <= 5000) && porReferen==100 &&
			    porExpedie==100 && (!_validaContratos || _validaContratos && porContrat==100) && codigo)
			    return true;
			else{
				if (porCliente==100 && porDomicil==100 && porEmpleo ==100 && 
					porIngreso==100 && ((porAvales ==100 && monto > 5000) || monto <= 5000) && porReferen==100 &&
					porExpedie==100 && !_validaContratos && codigo)
				    return true;
				else
					return false;
			}
				
		};
		
		
		
		var _validaCita = function( solicitudJson ){
			
			/* ESTO ES DE ARIELvar porCliente=solicitudJson.cotizacion.clientes[0].porcentaje;
			var porDomicil=solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje;
			
			if(porCliente==100 && porDomicil==100 && solicitudJson.consultaBuro == 1 && 
			   solicitudJson.envioCelular != 0 && (solicitudJson.cotizacion.clientes[0].email == "" || solicitudJson.envioCorreo != 0))
			    return true;
			else{
				return false;
			}*/
			
			var status = solicitudJson.idSeguimiento;
			var marca = solicitudJson.marca;
			var cita = solicitudJson.existeCita;
			
			if( ( status == STATUS_SOLICITUD.generada.id
					|| status == STATUS_SOLICITUD.preautorizada.id 
					|| ( status == STATUS_SOLICITUD.autorizada.id && marca == STATUS_SOLICITUD.preautorizada.marca.fico ) ) /* <--CON EL TIEMPO QUITAR*/ 
					&& cita == 0 ) 
				return true;
			else
				return false;
				
		};
		
		
		
		var _isEmpty = function(cadena){
			return cadena==undefined || cadena==null || typeof cadena === 'undefined' || cadena=='null' || cadena.trim().length==0;
		};
		
		
		var _isDefined = function(object){
			return !(object==undefined || object==null);
		};
		
		var _existeSolicitud = function(solicitudJson){
			return  !(solicitudJson == null || solicitudJson.idSolicitud == null || solicitudJson.idSolicitud.length == 0 ) 
		};
		
		
		
		/** @param jsonObject Objeto json  */
		var _setRespaldo = function(jsonObject,ingresos,dMenores,dMayores){	
			if(ingresos){
				respaldoStringJson = JSON.stringify(jsonObject, function (key, val) { 
																	 if (key == '$$hashKey')  
																		 return undefined; 
																	  
																	  return val; 
																}) + "/" + dMenores + "/" + dMayores;
			}else{
				respaldoStringJson = JSON.stringify(jsonObject, function (key, val) { 
					 if (key == '$$hashKey')  
						 return undefined; 
					  
					  return val; 
				});
			}
		};
		
		/** @param jsonObject Objeto json  */
		var _setRespaldoDom = function(jsonObject){
				respaldoStringJsonDom = JSON.stringify(jsonObject, function (key, val) { 
					 if (key == '$$hashKey')  
						 return undefined; 
					  
					  return val; 
				});
		};
		
		
		/** @return String en formato json */
		var _getRespaldo = function(){
			return respaldoStringJson;
		};
		
		/** @return String en formato json */
		var _getRespaldoDom = function(){
			return respaldoStringJsonDom;
		};
		
		var _setCodigos = function(inputCode){
			codigosValidacion = inputCode;
		}
		
		var _getCodigos = function(){
			return codigosValidacion;
		}
		
		
		
		var _setSolicitudId = function(solicitudId){
			solicitudID = solicitudId;
		}
		
		var _getSolicitudId = function(){
			return solicitudID;
		}
		
		/**
		 * FUNCIÓN QUE CONSTRUIYE EL JSON DE LA SOLICITUD DEL COACREDITADO
		 */
		
		var _buildSolicitudOSJson = function(rootScope, solicitudjson){			
			
			
			if(solicitudjson != null){
				rootScope.solicitudOSJson = solicitudjson;

			}else{

				rootScope.solicitudOSJson = {
					      "idSolicitud": "",
					      "idPais": 0,
					      "idCanal": 0,
					      "idSucursal": 0,
					      "idSeguimiento": 0,
					      "tipoLevantamiento": 0,
					      "tipoSolicitud": 0,
    				      "origenSolicitud":0,
					      "idProducto": 0,
					      "idEmpleado": 0,
    				      "terminal": "",
					      "direccionIp": "",
    				      "sistemaOperativo": "",
    				      "pushId": "",
    				      "idEntidadAlnova": "",
					      "idPlataforma":0,
					      "aceptaTerminos": 0,
					      "folioCallCenter": "",
					      "respuestaCallCenter":0,
					      "marca": 0,
					      "envioCorreo": 0,
					      "codigoCorreo": "",
					      "envioCelular": 0,
					      "codigoCelular": "",
					      "cantidadReenviosCelular":0,
					      "cantidadReenviosCorreo":0,
					      "cantidadReenviosLlamada":0,
					      "promocionCelular":0,
					      "promocionCorreo":0,
					      "banderaSeguro":0,
					      "pedido": 0,
					      "pedidoSEG": 0,
					      "pedidoSAC": 0,
    				      "tipoDispersion":0,
					      "idSolicitudTienda":0,
					      "idSolicitudTiendaCredInm":0,
					      "idCondicion":0,
					      "idMotivoRechazo":0,
					      "idMotivoBloqueo":0,
					      "tipoCampania": 0,
					      "idEstatusLCR":0,
					      "consultaBuro": 0,
					      "consultaMatriz": 0,
					      "clienteForaneoGuardado": 0,
					      "banderaPrueba":0,
					      "banderaIngresos": 0,
					      "banderaSolidario": 0,
					      "banderaCUDigitalizacion": 0,
					      "banderaEntregaTAZ": 0,
					      "banderaOCR":0,
					      "banderaOfertaCP":0,
					      "capacidadPagoComprobable":0,
					      "capacidadPagoNoComprobable":0,
					      "creditoInmediato":0,
					      "tratamientoDatos": 0,
					      "transferenciaDatos": 0,
					      "existeCita":0,
					      "diaPago": "",
					      "aceptaConsultaBuro": 0,
					      "diasRechazo": 0,
//I-MODICICACION SIPA (CAMPANA SIPA)					      
					      "campana": "",
//I-MODICICACION SIPA (CAMPANA SIPA)
//I-MODICICACION RECOMIENDA Y GANA
					      "folioRecomendador": "",
					      "banderaFolioRecomendador": 0,
//F-MODICICACION RECOMIENDA Y GANA
					      "cotizacion":       {
					         "idCotizacion": "",
					         "statusCotizacion": 0,
					         "fechaVigencia": "",
					         "montoTotal": 0.0,
					         "idPeriodicidad": 0,
					         "periodicidad": "",
					         "idPlazo": 0,
					         "plazo": 0,
					         "pagoNormal": 0.0,
					         "pagoPuntual": 0.0,
					         "ultimoAbono": 0.0,
					         "idPresupuesto": 0,
					         "detallesCotizacion": [         {
					            "idDetalle": "",
					            "enganche": 0.0,
					            "intereses": 0.0,
					            "monto": 0.0,
					            "cantidad": 0.0,
					            "idProducto": "0"
					         }],
					         "clientes": [         {
					            "idPersona": "",
					            "nombre": "",
					            "apellidoPaterno": "",
					            "apellidoMaterno": "",
					            "apellidoCasada": "",
					            "idGenero": "",
					            "genero": "",
					            "fechaNaciomiento": "",
					            "celular": "",
					            "email": "",
					            "idNacionalidad": 0,
					            "nacionalidadDes": "",
					            "idLugarNacimiento": "",
					            "lugarNacimientoDes": "",
					            "idEstadoCivil": 0,
					            "estadoCivil": "",
					            "idPuesto": 0,
					            "puestoDes": "",
					            "idParentesco": 0,
					            "parentesco": "",
					            "idPuestoCU":0,
					            "puestoCUDes":"",
					            "idPuestoSPCU":0,
					            "idTipoTrabajo":0,
					            "tipoTrabajoDes":"",
					            "curp": "",
					            "rfc": "",
					            "dni": "",
					            "clienteUnico": "",
					            "clienteTienda": "",
					            "clienteAlnova": "",
      				            "bdmid": "",
				                "numCuenta": "",
					            "foto": "0",
					            "huella": "0",
					            "porcentaje": 0,
					            "bloqueado": 0,
					            "editable": 0,
					            "guardado": 0,
					            "consecutivoPersona": 0,
					            "folioIdentificacion": "",
					            "claveElector": "",
					            "fechaVigenciaIdentificacion": "",
					            "flujoEfectivo": [],
					            "preguntaPEPS": [{
								            	  "numero": 1,
								            	  "status": 0,
								            	  "cargo": 0,
								            	  "cargoDes": "",
								            	  "dependencia": 1,
								            	  "dependenciaDes": "",
								            	  "areaAdscrito": 1,
								            	  "areaAdscritoDes": "",
								            	  "parentesco": 0,
								            	  "parentescoDes": "",
								            	  "nombre": "",
								            	  "apellidoPaterno": "",
								            	  "apellidoMaterno": "",
								            	  "fechaNacimiento": "",
								            	  "idPersona": ""              
									              },{
								            	  "numero": 2,
								            	  "status": 0,
								            	  "cargo": 0,
								            	  "cargoDes": "",
								            	  "dependencia": 1,
								            	  "dependenciaDes": "",
								            	  "areaAdscrito": 1,
								            	  "areaAdscritoDes": "",
								            	  "parentesco": 0,
								            	  "parentescoDes": "",
								            	  "nombre": "",
								            	  "apellidoPaterno": "",
								            	  "apellidoMaterno": "",
								            	  "fechaNacimiento": "",
								            	  "idPersona": ""              
									              }
								],
					            "domicilios": [            {
					               "idDomicilio": "",
					               "calle": "",
					               "numeroExterior": "",
					               "numeroInterior": "",
					               "cp": "",
					               "colonia": "",
					               "idDelegacion": 0,
					               "delegacion": "",
					               "idEstado": 0,
					               "estado": "",
					               "telefono": "",
					               "domicilioActual": 1,
					               "idTipoVivienda": 0,
					               "tipoViviendaDes": "",
					               "manzana": "",
					               "superManzana": "",
					               "lote": "",
					               "antiguedad": "",
					               "andador": "",
					               "idAntiguedad": 0,
					               "antiguedadDes": "",
					               "edificio":"",
					               "porcentaje": 0,
					               "bloqueado": 0,
					               "editable": 0,
					               "guardado": 0,
					               "zonificacion":                {
					                  "latitud": "",
					                  "longitud": "",
					                  "referencia": "",
					                  "calleDelante": "",
					                  "calleAtras": "",
					                  "calleIzquierda": "",
					                  "calleDerecha": "",
					                  "heading": "",
					                  "pitch": "",
					                  "zoom": "",
					                  "fov": "",
					                  "idCuadrante":0,
					                  "idPais":0,
					                  "idZonaGeo":0
					               }
					            }],
					            "ingresosEgresos":             {
					               "dependientesMayores": null,
					               "dependientesMenores": null,
					               "porcentaje": 0,
					               "bloqueado": 0,
					               "editable": 0,
					               "guardado": 0,
					               "flujoEfectivo": []
					            },
					            "datosEmpleo": [            {
					               "idEmpleo": "",
					               "idProfesion": 0,
					               "profesion": "",
					               "nombreEmpresa": "",
					               "idGiro": 0,
					               "giro": "",
					               "ext": "",
					               "antiguedad": "",
					               "idPeriodicidad": 0,
					               "periodicidad": "",
					               "idAntiguedad": 0,
					               "antiguedadDes": "",
					               "empleoActual": 0,
					               "porcentaje": 0,
					               "idTipoPago": 0,
					               "tipoPago": "",
					               "bloqueado": 1,
					               "editable": 0,
					               "guardado": 0,
					               "domicilio":{
					                  "idDomicilio": "",
					                  "calle": "",
					                  "numeroExterior": "",
					                  "numeroInterior": "",
					                  "cp": "",
					                  "colonia": "",
					                  "idDelegacion": 0,
					                  "delegacion": "",
					                  "idEstado": 0,
					                  "estado": "",
					                  "telefono": ""
					               }
					            }]
					         }]
					      },
					      "avales": [      {
					         "idPersona": "",
					         "nombre": "",
					         "apellidoPaterno": "",
					         "apellidoMaterno": "",
					         "apellidoCasada": "",
					         "idGenero": "",
					         "genero": "",
					         "fechaNaciomiento": "",
					         "celular": "",
					         "email": "",
					         "idNacionalidad": 0,
					         "nacionalidadDes": "",
					         "idLugarNacimiento": 0,
					         "lugarNacimientoDes": "",
					         "idEstadoCivil": 0,
					         "estadoCivil": "",
					         "curp": "",
					         "rfc": "",
					         "idTipoAval": 0,
					         "tipoAvalDes": "",
					         "idTipoPropiedad": 0,
					         "tipoPropiedadDes": "",
					         "clienteUnico": "",
					         "clienteTienda": "",
					         "clienteAlnova": "",
					         "foto": "",
					         "huella": "",
					         "dni": "",
					         "idParentesco":0,
					         "parentescoDes":"",
					         "idPuesto":0,
					         "puestoDes":"",
					         "presencial":0,
					         "primerInser":0,
					         "clienteForaneoGuardado":0,
					         "porcentaje": 0,
					         "porcentajeBasico": 0,
					         "porcentajeContacto": 0,
					         "bloqueado": 1,
					         "editable": 0,
					         "guardado": 0,
					         "consecutivoPersona": 0,
					         "folioIdentificacion": "",
					         "fechaVigenciaIdentificacion" : "",
					         "idSeguimiento": 0,
					         "marca": 0,
					         "envioCorreo": 0,
					         "codigoCorreo": "",
					         "envioCelular": 0,
					         "codigoCelular": "",
					         "cantidadReenviosCelular":0,
					         "cantidadReenviosCorreo":0,
					         "idCondicion":0,
					         "idMotivoRechazo":0,
					         "idMotivoBloqueo":0,
					         "consultaBuro": 0,
					         "consultaMatriz": 0,
					         "existeCita":0,
					         "aceptaConsultaBuro": 0,
					         "aceptaTerminos": 0,
					         "banderaOCR":0,
					         "datosHogar":          {
					            "idDomicilio": "",
					            "calle": "",
					            "numeroExterior": "",
					            "numeroInterior": "",
					            "cp": "",
					            "colonia": "",
					            "idDelegacion": 0,
					            "delegacion": "",
					            "idEstado": 0,
					            "estado": "",
					            "telefono": "",
					            "domicilioActual": 1,
					            "idTipoVivienda": 0,
					            "tipoViviendaDes": "",
					            "idClaseVivienda": 0,
					            "claseViviendaDes": "",
					            "manzana": "",
					            "superManzana": "",
					            "lote": "",
					            "antiguedad": "",
					            "andador": "",
					            "idAntiguedad": 0,
					            "antiguedadDes": "",
					            "edificio":"",
					            "porcentaje": 0,
					            "bloqueado": 0,
					            "editable": 0,
					            "guardado": 0,
					            "zonificacion":             {
					               "latitud": "",
					               "longitud": "",
					               "referencia": "",
					               "calleDelante": "",
					               "calleAtras": "",
					               "calleIzquierda": "",
					               "calleDerecha": "",
					               "heading": "",
					               "pitch": "",
					               "zoom": "",
					               "fov": "",
					               "idCuadrante":0,
					               "idPais":0,
					               "idZonaGeo":0
					            }
					         },
					         "flujoEfectivo": []
					      }],
					      "referencias":       {
	                            "porcentaje": 0,
	                            "bloqueado": 0,
	                            "editable": 0,
	                            "guardado": 0,
					            "referencia": [
			                         {
						            "idPersona": "",
						            "nombre": "",
						            "apellidoPaterno": "",
						            "apellidoMaterno": "",
						            "apellidoCasada": "",
						            "idGenero": "",
						            "genero": "",
						            "fechaNaciomiento": "",
						            "celular": "",
						            "email": "",
						            "idNacionalidad": 0,
						            "nacionalidadDes": "",
						            "idLugarNacimiento": 0,
						            "lugarNacimientoDes": "",
						            "idEstadoCivil": 0,
						            "estadoCivil": "",
						            "curp": "",
						            "rfc": "",
						            "idParentesco": 0,
						            "parentescoDes": "",
						            "telefonoCasa": "",
						            "dni": ""
			                         },
					                 {
						            "idPersona": "",
						            "nombre": "",
						            "apellidoPaterno": "",
						            "apellidoMaterno": "",
						            "apellidoCasada": "",
						            "idGenero": "",
						            "genero": "",
						            "fechaNaciomiento": "",
						            "celular": "",
						            "email": "",
						            "idNacionalidad": 0,
						            "nacionalidadDes": "",
						            "idLugarNacimiento": 0,
						            "lugarNacimientoDes": "",
						            "idEstadoCivil": 0,
						            "estadoCivil": "",
						            "curp": "",
						            "rfc": "",
						            "idParentesco": 0,
						            "parentescoDes": "",
						            "telefonoCasa": "",
						            "dni": ""
					                }
			                    ]
						},
					      "documentos":       {
					         "porcentaje": 0,
					         "bloqueado": 0,
					         "editable": 0,
					         "guardado": 0,
					         "documento": []
					      },
					      "contratos":       {
					         "porcentaje": 100,
					         "bloqueado": 0,
					         "editable": 0,
					         "guardado": 0,
					         "contrato": [{
					        	 "idContrato": "1",
					        	 "idPersona": "",
					        	 "statusFirma": 1,
					        	 "descripcion": AVISO_PRIVACIDAD,
					        	 "idTipoPersona": 1
		    				},
		    				{	"idContrato": "2",
		    					"idPersona": "",
		    					"statusFirma": 1,
		    					"descripcion": BURO_CREDITO,
		    					"idTipoPersona": 1
		    				},	
		    				{	"idContrato": "3",
		    					"idPersona": "",
		    					"statusFirma": 0,
		    					"descripcion": CARATULA,
		    					"idTipoPersona": 1
		    				},
		    				{	"idContrato": "4",
		    					"idPersona": "",
		    					"statusFirma": 0,
		    					"descripcion": SOLICITUD,
		    					"idTipoPersona": 1
		    				}]
					      },
					      "lineaDeCredito":       {
					         "capacidadDePagoTotal": 0.0,
					         "capacidadDePagoOcupada": 0.0,
					         "capacidadDePagoDisponible": 0.0,
					         "siguientePago": 0,
					         "pagoAntesDe": "",
					         "bonificacion": 0.0,
					         "liquidarAhora": 0.0,
					         "tipoPago": ""
					      },
					      "seguroDeVida":{
					          "nombreSeguro": "",
					          "opcionSeguro": 0,
					          "idSeguro": "",
					          "precioSeguro": 0,
					          "sobrePrecioSeguro": 0,
					          "abonoSeguro": 0,
					          "ultimoAbonoSeguro": 0,
					          "totalSeguro": 0,
					          "clavePromocion": "",
					          "comisionVenta": 0,
					          "montoFinal": 0,
					          "montoInicial": 0,
					          "esDefault": 0
					       },
					       "mesaControl" : {
					   		"folioMCO" : "",
					   		"fechaGeneraFolio" : "",
					   		"contEdicion" : 0,
					   		"existeEdicion" : 0,
					   		"cometario" : "",
					   		"origenEdicion" : ""
					       },
					       "preguntasInvestigacion":[
                             {
                               "idPregunta": "700",
                               "idVecino": 1,
                               "preguntaDes": "¿Cual es el Nombre del Cliente?",
                               "respuestaDes": ""
                             },
                             {
                               "idPregunta": "713",
                               "idVecino": 1,
                               "preguntaDes": "¿Es una persona de confianza?",
                               "respuestaDes": ""
                             }
                           ],
                           "obligadoSolidario": {
                        	    "obligadoSolidarioRequerido": 1,
                        	    "contadorObligadoSolidario": 3,
                        	    "idSolicitudCliente": "",
                        	    "cuCliente": "",
                        	    "idSolicitudObligadoSolidario": "",
                        	    "cuObligadoSolidario": ""
                        	  },
                           "tipoDispositivo":configuracion.so.windows?"Windows":configuracion.so.ios?"iPad":configuracion.origen.portalWeb?"Web":"Dispositivo No Reconocido"
					};
				
//				buildConfiguracion(rootScope);
				buildDatosDefault(rootScope);
			}
		};	
		
		
		var _buildSolicitudJson = function(rootScope, solicitudjson){			
			
			rootScope.fotoCte="data:image/png;base64,"+rootScope.imgUsuario;
			
			if(solicitudjson != null){
				rootScope.solicitudOSJson = solicitudjson;
//				buildConfiguracion(rootScope);
				rootScope.buroHandler = [];
				rootScope.termometroHandler = false;
				rootScope.buroConditional = -1;
			}else{
				rootScope.termometroHandler = false;
				rootScope.buroHandler = [];
				rootScope.buroConditional = -1;
				_buildPorcentajeJson(rootScope, null);
				rootScope.solicitudOSJson = {
					      "idSolicitud": "",
					      "idPais": 0,
					      "idCanal": 0,
					      "idSucursal": 0,
					      "idSeguimiento": 0,
					      "tipoLevantamiento": 0,
					      "tipoSolicitud": 0,
    				      "origenSolicitud":0,
					      "idProducto": 0,
					      "idEmpleado": 0,
    				      "terminal": "",
					      "direccionIp": "",
    				      "sistemaOperativo": "",
    				      "pushId": "",
    				      "idEntidadAlnova": "",
					      "idPlataforma":0,
					      "aceptaTerminos": 0,
					      "folioCallCenter": "",
					      "respuestaCallCenter":0,
					      "marca": 0,
					      "envioCorreo": 0,
					      "codigoCorreo": "",
					      "envioCelular": 0,
					      "codigoCelular": "",
					      "cantidadReenviosCelular":0,
					      "cantidadReenviosCorreo":0,
					      "cantidadReenviosLlamada":0,
					      "promocionCelular":0,
					      "promocionCorreo":0,
					      "banderaSeguro":0,
					      "pedido": 0,
					      "pedidoSEG": 0,
					      "pedidoSAC": 0,
    				      "tipoDispersion":0,
					      "idSolicitudTienda":0,
					      "idSolicitudTiendaCredInm":0,
					      "idCondicion":0,
					      "idMotivoRechazo":0,
					      "idMotivoBloqueo":0,
					      "tipoCampania": 0,
					      "idEstatusLCR":0,
					      "consultaBuro": 0,
					      "consultaMatriz": 0,
					      "clienteForaneoGuardado": 0,
					      "banderaPrueba":0,
					      "banderaIngresos": 0,
					      "banderaSolidario": 0,
					      "banderaCUDigitalizacion": 0,
					      "banderaEntregaTAZ": 0,
					      "banderaOCR":0,
					      "banderaOfertaCP":0,
					      "capacidadPagoComprobable":0,
					      "capacidadPagoNoComprobable":0,
					      "creditoInmediato":0,
					      "tratamientoDatos": 0,
					      "transferenciaDatos": 0,
					      "existeCita":0,
					      "diaPago": "",
					      "aceptaConsultaBuro": 0,
					      "diasRechazo": 0,
//I-MODICICACION SIPA (CAMPANA SIPA)					      
					      "campana": "",
//I-MODICICACION SIPA (CAMPANA SIPA)
//I-MODICICACION RECOMIENDA Y GANA
					      "folioRecomendador": "",
					      "banderaFolioRecomendador": 0,
//F-MODICICACION RECOMIENDA Y GANA
					      "cotizacion":       {
					         "idCotizacion": "",
					         "statusCotizacion": 0,
					         "fechaVigencia": "",
					         "montoTotal": 0.0,
					         "idPeriodicidad": 0,
					         "periodicidad": "",
					         "idPlazo": 0,
					         "plazo": 0,
					         "pagoNormal": 0.0,
					         "pagoPuntual": 0.0,
					         "ultimoAbono": 0.0,
					         "idPresupuesto": 0,
					         "detallesCotizacion": [         {
					            "idDetalle": "",
					            "enganche": 0.0,
					            "intereses": 0.0,
					            "monto": 0.0,
					            "cantidad": 0.0,
					            "idProducto": "0"
					         }],
					         "clientes": [         {
					            "idPersona": "",
					            "nombre": "",
					            "apellidoPaterno": "",
					            "apellidoMaterno": "",
					            "apellidoCasada": "",
					            "idGenero": "",
					            "genero": "",
					            "fechaNaciomiento": "",
					            "celular": "",
					            "email": "",
					            "idNacionalidad": 0,
					            "nacionalidadDes": "",
					            "idLugarNacimiento": "",
					            "lugarNacimientoDes": "",
					            "idEstadoCivil": 0,
					            "estadoCivil": "",
					            "idPuesto": -1,
					            "puestoDes": "",
					            "idParentesco": 0,
					            "parentescoDes": "",
					            "idPuestoCU":0,
					            "puestoCUDes":"",
					            "idPuestoSPCU":0,
					            "idTipoTrabajo":0,
					            "tipoTrabajoDes":"",
					            "curp": "",
					            "rfc": "",
					            "dni": "",
					            "clienteUnico": "",
					            "clienteTienda": "",
					            "clienteAlnova": "",
      				            "bdmid": "",
				                "numCuenta": "",
					            "foto": "0",
					            "huella": "0",
					            "porcentaje": 0,
					            "bloqueado": 0,
					            "editable": 0,
					            "guardado": 0,
					            "consecutivoPersona": 0,
					            "folioIdentificacion": "",
					            "claveElector": "",
					            "fechaVigenciaIdentificacion": "",
					            "flujoEfectivo": [],
					            "preguntaPEPS": [{
								            	  "numero": 1,
								            	  "status": 0,
								            	  "cargo": 0,
								            	  "cargoDes": "",
								            	  "dependencia": 1,
								            	  "dependenciaDes": "",
								            	  "areaAdscrito": 1,
								            	  "areaAdscritoDes": "",
								            	  "parentesco": 0,
								            	  "parentescoDes": "",
								            	  "nombre": "",
								            	  "apellidoPaterno": "",
								            	  "apellidoMaterno": "",
								            	  "fechaNacimiento": "",
								            	  "idPersona": ""              
									              },{
								            	  "numero": 2,
								            	  "status": 0,
								            	  "cargo": 0,
								            	  "cargoDes": "",
								            	  "dependencia": 1,
								            	  "dependenciaDes": "",
								            	  "areaAdscrito": 1,
								            	  "areaAdscritoDes": "",
								            	  "parentesco": 0,
								            	  "parentescoDes": "",
								            	  "nombre": "",
								            	  "apellidoPaterno": "",
								            	  "apellidoMaterno": "",
								            	  "fechaNacimiento": "",
								            	  "idPersona": ""              
									              }
								],
					            "domicilios": [            {
					               "idDomicilio": "",
					               "calle": "",
					               "numeroExterior": "",
					               "numeroInterior": "",
					               "cp": "",
					               "colonia": "",
					               "idDelegacion": 0,
					               "delegacion": "",
					               "idEstado": 0,
					               "estado": "",
					               "telefono": "",
					               "domicilioActual": 1,
					               "idTipoVivienda": 0,
					               "tipoViviendaDes": "",
					               "manzana": "",
					               "superManzana": "",
					               "lote": "",
					               "antiguedad": "",
					               "andador": "",
					               "idAntiguedad": 0,
					               "antiguedadDes": "",
					               "edificio":"",
					               "porcentaje": 0,
					               "bloqueado": 0,
					               "editable": 0,
					               "guardado": 0,
					               "zonificacion":                {
					                  "latitud": "",
					                  "longitud": "",
					                  "referencia": "",
					                  "calleDelante": "",
					                  "calleAtras": "",
					                  "calleIzquierda": "",
					                  "calleDerecha": "",
					                  "heading": "",
					                  "pitch": "",
					                  "zoom": "",
					                  "fov": "",
					                  "idCuadrante":0,
					                  "idPais":0,
					                  "idZonaGeo":0
					               }
					            }],
					            "ingresosEgresos":             {
					               "dependientesMayores": null,
					               "dependientesMenores": null,
					               "porcentaje": 0,
					               "bloqueado": 0,
					               "editable": 0,
					               "guardado": 0,
					               "flujoEfectivo": []
					            },
					            "datosEmpleo": [            {
					               "idEmpleo": "",
					               "idProfesion": 0,
					               "profesion": "",
					               "nombreEmpresa": "",
					               "idGiro": 0,
					               "giro": "",
					               "ext": "",
					               "antiguedad": "",
					               "idPeriodicidad": 0,
					               "periodicidad": "",
					               "idAntiguedad": 0,
					               "antiguedadDes": "",
					               "empleoActual": 0,
					               "porcentaje": 0,
					               "idTipoPago": 0,
					               "tipoPago": "",
					               "bloqueado": 1,
					               "editable": 0,
					               "guardado": 0,
					               "domicilio":{
					                  "idDomicilio": "",
					                  "calle": "",
					                  "numeroExterior": "",
					                  "numeroInterior": "",
					                  "cp": "",
					                  "colonia": "",
					                  "idDelegacion": 0,
					                  "delegacion": "",
					                  "idEstado": 0,
					                  "estado": "",
					                  "telefono": ""
					               }
					            }]
					         }]
					      },
					      "avales": [      {
					         "idPersona": "",
					         "nombre": "",
					         "apellidoPaterno": "",
					         "apellidoMaterno": "",
					         "apellidoCasada": "",
					         "idGenero": "",
					         "genero": "",
					         "fechaNaciomiento": "",
					         "celular": "",
					         "email": "",
					         "idNacionalidad": 0,
					         "nacionalidadDes": "",
					         "idLugarNacimiento": 0,
					         "lugarNacimientoDes": "",
					         "idEstadoCivil": 0,
					         "estadoCivil": "",
					         "curp": "",
					         "rfc": "",
					         "idTipoAval": 0,
					         "tipoAvalDes": "",
					         "idTipoPropiedad": 0,
					         "tipoPropiedadDes": "",
					         "clienteUnico": "",
					         "clienteTienda": "",
					         "clienteAlnova": "",
					         "foto": "",
					         "huella": "",
					         "dni": "",
					         "idParentesco":0,
					         "parentescoDes":"",
					         "idPuesto":0,
					         "puestoDes":"",
					         "presencial":0,
					         "primerInser":0,
					         "clienteForaneoGuardado":0,
					         "porcentaje": 0,
					         "porcentajeBasico": 0,
					         "porcentajeContacto": 0,
					         "bloqueado": 1,
					         "editable": 0,
					         "guardado": 0,
					         "consecutivoPersona": 0,
					         "folioIdentificacion": "",
					         "fechaVigenciaIdentificacion" : "",
					         "idSeguimiento": 0,
					         "marca": 0,
					         "envioCorreo": 0,
					         "codigoCorreo": "",
					         "envioCelular": 0,
					         "codigoCelular": "",
					         "cantidadReenviosCelular":0,
					         "cantidadReenviosCorreo":0,
					         "idCondicion":0,
					         "idMotivoRechazo":0,
					         "idMotivoBloqueo":0,
					         "consultaBuro": 0,
					         "consultaMatriz": 0,
					         "existeCita":0,
					         "aceptaConsultaBuro": 0,
					         "aceptaTerminos": 0,
					         "banderaOCR":0,
					         "datosHogar":          {
					            "idDomicilio": "",
					            "calle": "",
					            "numeroExterior": "",
					            "numeroInterior": "",
					            "cp": "",
					            "colonia": "",
					            "idDelegacion": 0,
					            "delegacion": "",
					            "idEstado": 0,
					            "estado": "",
					            "telefono": "",
					            "domicilioActual": 1,
					            "idTipoVivienda": 0,
					            "tipoViviendaDes": "",
					            "idClaseVivienda": 0,
					            "claseViviendaDes": "",
					            "manzana": "",
					            "superManzana": "",
					            "lote": "",
					            "antiguedad": "",
					            "andador": "",
					            "idAntiguedad": 0,
					            "antiguedadDes": "",
					            "edificio":"",
					            "porcentaje": 0,
					            "bloqueado": 0,
					            "editable": 0,
					            "guardado": 0,
					            "zonificacion":             {
					               "latitud": "",
					               "longitud": "",
					               "referencia": "",
					               "calleDelante": "",
					               "calleAtras": "",
					               "calleIzquierda": "",
					               "calleDerecha": "",
					               "heading": "",
					               "pitch": "",
					               "zoom": "",
					               "fov": "",
					               "idCuadrante":0,
					               "idPais":0,
					               "idZonaGeo":0
					            }
					         },
					         "flujoEfectivo": []
					      }],
					      "referencias":       {
	                            "porcentaje": 0,
	                            "bloqueado": 0,
	                            "editable": 0,
	                            "guardado": 0,
					            "referencia": [
			                         {
						            "idPersona": "",
						            "nombre": "",
						            "apellidoPaterno": "",
						            "apellidoMaterno": "",
						            "apellidoCasada": "",
						            "idGenero": "",
						            "genero": "",
						            "fechaNaciomiento": "",
						            "celular": "",
						            "email": "",
						            "idNacionalidad": 0,
						            "nacionalidadDes": "",
						            "idLugarNacimiento": 0,
						            "lugarNacimientoDes": "",
						            "idEstadoCivil": 0,
						            "estadoCivil": "",
						            "curp": "",
						            "rfc": "",
						            "idParentesco": 0,
						            "parentescoDes": "",
						            "telefonoCasa": "",
						            "dni": ""
			                         },
					                 {
						            "idPersona": "",
						            "nombre": "",
						            "apellidoPaterno": "",
						            "apellidoMaterno": "",
						            "apellidoCasada": "",
						            "idGenero": "",
						            "genero": "",
						            "fechaNaciomiento": "",
						            "celular": "",
						            "email": "",
						            "idNacionalidad": 0,
						            "nacionalidadDes": "",
						            "idLugarNacimiento": 0,
						            "lugarNacimientoDes": "",
						            "idEstadoCivil": 0,
						            "estadoCivil": "",
						            "curp": "",
						            "rfc": "",
						            "idParentesco": 0,
						            "parentescoDes": "",
						            "telefonoCasa": "",
						            "dni": ""
					                }
			                    ]
						},
					      "documentos":       {
					         "porcentaje": 0,
					         "bloqueado": 0,
					         "editable": 0,
					         "guardado": 0,
					         "documento": []
					      },
					      "contratos":       {
					         "porcentaje": 100,
					         "bloqueado": 0,
					         "editable": 0,
					         "guardado": 0,
					         "contrato": [{
					        	 "idContrato": "1",
					        	 "idPersona": "",
					        	 "statusFirma": 1,
					        	 "descripcion": AVISO_PRIVACIDAD,
					        	 "idTipoPersona": 1
		    				},
		    				{	"idContrato": "2",
		    					"idPersona": "",
		    					"statusFirma": 1,
		    					"descripcion": BURO_CREDITO,
		    					"idTipoPersona": 1
		    				},	
		    				{	"idContrato": "3",
		    					"idPersona": "",
		    					"statusFirma": 0,
		    					"descripcion": CARATULA,
		    					"idTipoPersona": 1
		    				},
		    				{	"idContrato": "4",
		    					"idPersona": "",
		    					"statusFirma": 0,
		    					"descripcion": SOLICITUD,
		    					"idTipoPersona": 1
		    				}]
					      },
					      "lineaDeCredito":       {
					         "capacidadDePagoTotal": 0.0,
					         "capacidadDePagoOcupada": 0.0,
					         "capacidadDePagoDisponible": 0.0,
					         "siguientePago": 0,
					         "pagoAntesDe": "",
					         "bonificacion": 0.0,
					         "liquidarAhora": 0.0,
					         "tipoPago": ""
					      },
					      "seguroDeVida":{
					          "nombreSeguro": "",
					          "opcionSeguro": 0,
					          "idSeguro": "",
					          "precioSeguro": 0,
					          "sobrePrecioSeguro": 0,
					          "abonoSeguro": 0,
					          "ultimoAbonoSeguro": 0,
					          "totalSeguro": 0,
					          "clavePromocion": "",
					          "comisionVenta": 0,
					          "montoFinal": 0,
					          "montoInicial": 0,
					          "esDefault": 0
					       },
					       "mesaControl" : {
					   		"folioMCO" : "",
					   		"fechaGeneraFolio" : "",
					   		"contEdicion" : 0,
					   		"existeEdicion" : 0,
					   		"cometario" : "",
					   		"origenEdicion" : ""
					       },
					       "preguntasInvestigacion":[
                             {
                               "idPregunta": "700",
                               "idVecino": 1,
                               "preguntaDes": "¿Cual es el Nombre del Cliente?",
                               "respuestaDes": ""
                             },
                             {
                               "idPregunta": "713",
                               "idVecino": 1,
                               "preguntaDes": "¿Es una persona de confianza?",
                               "respuestaDes": ""
                             }
                           ],
                           "obligadoSolidario": {
                       	    "obligadoSolidarioRequerido": 1,
                       	    "contadorObligadoSolidario": 3,
                       	    "idSolicitudCliente": "",
                       	    "cuCliente": "",
                       	    "idSolicitudObligadoSolidario": "",
                       	    "cuObligadoSolidario": ""
                       	  },
                           "tipoDispositivo":configuracion.so.windows?"Windows":configuracion.so.ios?"iPad":configuracion.origen.portalWeb?"Web":"Dispositivo No Reconocido"
					};
				
//				buildConfiguracion(rootScope);
				buildDatosDefault(rootScope);
			}
		};		
		
		function buildConfiguracion(rootScope){
			if(configuracion.origen.tienda){
				rootScope.solicitudOSJson.idPais=1;
//				rootScope.solicitudOSJson.idCanal=53;
//				rootScope.solicitudOSJson.idSucursal=365;
				rootScope.solicitudOSJson.idCanal=1;
				rootScope.solicitudOSJson.idSucursal=4737;			
				rootScope.solicitudOSJson.idPlataforma=1;
				rootScope.solicitudOSJson.tipoLevantamiento=2;
			}
			if(configuracion.origen.portalWeb){
				rootScope.solicitudOSJson.idPais=1;
//				rootScope.solicitudOSJson.idCanal=53;
//				rootScope.solicitudOSJson.idSucursal=365;
				rootScope.solicitudOSJson.idCanal=1;
				rootScope.solicitudOSJson.idSucursal=4737;			
				rootScope.solicitudOSJson.idPlataforma=3;
				rootScope.solicitudOSJson.tipoLevantamiento=1;
			}	
			
			
		};
		
		function buildDatosDefault(rootScope){
//			rootScope.solicitudOSJson.tipoSolicitud=8;
			rootScope.solicitudOSJson.idProducto=24;
//			rootScope.solicitudOSJson.idSeguimiento=3;
//			rootScope.solicitudOSJson.cotizacion.statusCotizacion=1;
			rootScope.solicitudOSJson.cotizacion.idPeriodicidad=1;
			rootScope.solicitudOSJson.cotizacion.periodicidad="Semanal";
			rootScope.solicitudOSJson.cotizacion.idPlazo=0;
			rootScope.solicitudOSJson.cotizacion.plazo=0;
			rootScope.solicitudOSJson.cotizacion.detallesCotizacion[0].monto=2000;
			rootScope.solicitudOSJson.cotizacion.detallesCotizacion[0].idProducto= "24";
		};
		
		
		var _buildPorcentajeJson = function(rootScope){
			rootScope.porcentajes = {
					"secciones" :[{ 
						"tiempo": 1,
						"porcentaje" : 0
					},
					{ 
						"tiempo": 2,
						"porcentaje" : 0
					},
					{ 
						"tiempo": 2,
						"porcentaje" : 0
					},
					{ 
						"tiempo": 1,
						"porcentaje" : 0
					},
					{
						"tiempo": 3,
						"porcentaje" : 0
					},
					{
						"tiempo": 2,
						"porcentaje" : 0
					},
					{ 
						"tiempo": 4,
						"porcentaje" : 0
					},
					{ 
						"tiempo": 2,
						"porcentaje" : 0
					}
					],
			       "tiempoRestante"  : 17
			}
		};
		
		
		var _calculaPorcentaje = function(rootScope){
			
			if( _isDefined(rootScope.porcentajes) ){
				
				rootScope.porcentajes.secciones[0].porcentaje = rootScope.solicitudOSJson.cotizacion.clientes[0].porcentaje; 
	    		rootScope.porcentajes.secciones[1].porcentaje = rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].porcentaje;
	    		rootScope.porcentajes.secciones[2].porcentaje = rootScope.solicitudOSJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje;
	    		rootScope.porcentajes.secciones[3].porcentaje = rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.porcentaje;
	    		rootScope.porcentajes.secciones[4].porcentaje = rootScope.solicitudOSJson.avales[0].porcentaje;
	    		rootScope.porcentajes.secciones[5].porcentaje = rootScope.solicitudOSJson.referencias.porcentaje;
	    		rootScope.porcentajes.secciones[6].porcentaje = rootScope.solicitudOSJson.documentos.porcentaje;
	    		rootScope.porcentajes.secciones[7].porcentaje = rootScope.solicitudOSJson.contratos.porcentaje;
	    		
	    		rootScope.$watch("porcentajes.secciones",function(){
	    				Tiempo(rootScope);
	    			}, true		                				
	    		);
	    		
			}
			    		
		};
		
		function Tiempo(rootScope){
			var calculaTiempo = 0;
			var tiempoTotal = 0;
			var tiempoTranscurrido = 0;
			var tiempor = 0;
			
			if( rootScope.porcentajes!=undefined && rootScope.porcentajes!=null ){
				for (var i=0; i < rootScope.porcentajes.secciones.length; i++) {
					calculaTiempo = (rootScope.porcentajes.secciones[i].tiempo * rootScope.porcentajes.secciones[i].porcentaje) / 100;
					tiempoTotal = tiempoTotal + rootScope.porcentajes.secciones[i].tiempo;				 
					tiempoTranscurrido = tiempoTranscurrido + calculaTiempo;
				}
				rootScope.porcentajes.tiempoRestante = Math.ceil(tiempoTotal  - tiempoTranscurrido);
			}
		};
		
		
		var _setIP = function(rootScope){
			rootScope.solicitudOSJson.direccionIp = LOCAL_IP;		
		};
		
		
		
		var _setArrayValue = function(index, _value){	
			if(index!=null)
				valuesArray[index] = _value;				
		};
		
		
		var _getArrayValue = function(index){
			return valuesArray[index];				
		};
		
		
		/* FUNCTIONS TO MAP JSON RESPONSE */
		var jsonData = null;
		
		function _setMapping( json )
		{
			jsonData = json;
		}
		
		function _getMapping()
		{
			return jsonData;
		}
		
		function _getFromCategory( category )
		{
			
			var retData = null;
			
			if( jsonData != null ){
				
				retData = jsonData[ 'FRONT PRESTAMOS PERSONALES.' + category ];
				
			}else{
				
				console.error( 'Not json instanced!' );
				
			}
			
			return retData;
			
		}
		
		function _getDatafromCategory( category, data, key )
		{
			
			var retData = null;
			
			
			if( MODEL_VISTAS_JSON != null ){
				
				if( key != null && key !== '' )
					retData = MODEL_VISTAS_JSON[ 'FRONT PRESTAMOS PERSONALES.' + category + '.' + data + '.' + key ];
				else
					retData = JSONtoMap( MODEL_VISTAS_JSON[ 'FRONT PRESTAMOS PERSONALES.' + category + '.' + data ] );
				
			}else{
				
				console.error( 'Not json instanced!' );
				
			}
			
			return retData;
		}
		/* END FOR FUNCTIONS TO MAP JSON RESPONSE */
		
		
		
		var _documentoValido = function(status){
			return  (status == STATUS_CAPTURADO || status == STATUS_VERIFICADO || status == STATUS_VALIDADO || status == STATUS_ENCOLADO_IPAD ); 
		};
		
		var _documentoEnviadoValido = function(status){
			return  (status == STATUS_CAPTURADO || status == STATUS_VERIFICADO || status == STATUS_VALIDADO || status == STATUS_ENCOLADO_IPAD || status == STATUS_RECHAZADO ); 
		};
		
		
		var _documentoEnviadoWS = function(status){
			return  (status == STATUS_CAPTURADO || status == STATUS_VERIFICADO || status == STATUS_VALIDADO || status == STATUS_RECHAZADO); 
		};
		
		var _documentoEncolado = function(solicitudJson){
			var documentoEncolado = false;
			
			if( solicitudJson.cotizacion.clientes[0].foto == FOTO_ENCOLADO_IPAD || solicitudJson.cotizacion.clientes[0].huella == HUELLA_ENCOLADO_IPAD)
				documentoEncolado = true;
			
			else{
				angular.forEach( solicitudJson.documentos.documento, function(doc, key){				
					if(doc.status == STATUS_ENCOLADO_IPAD )
						documentoEncolado = true;
						
				});
			}
			
			return documentoEncolado;
		}
		
		var _contratoEncolado = function(solicitudJson){
			var contratoEncolado = false;
			
				angular.forEach( $rootScope.solicitudOSJson.contratos.contrato, function(firma, key){				
					if(firma.statusFirma == 2 && ((solicitudJson.banderaSolidario == 1 && firma.idTipoPersona == 3) || (solicitudJson.banderaSolidario == 0 && firma.idTipoPersona != 3)))
						contratoEncolado = true;
				});
			
			return contratoEncolado;
		} 
		
		var _verificarCanalEnDispersion = function( canal ){
			
			if( !canal ) canal = CANALES.modatelas;
				
			var tipoTasa = tipoTasas.prestamoPersonal.id;
			var excepcionesCanal = generalService.multitasas("PRESTAMOS PERSONALES.DISPERSION.EXCEPCION DISPERSION",tipoTasa);
			
			if( !excepcionesCanal && excepcionesCanal == null ){
				excepcionesCanal = [{}];				
			}			
			
			var index = excepcionesCanal.map( function( data ){
				return data['valor'];
			}).indexOf( canal.toString() );
				
			if( index != -1 ){
				return true;
			}
			
			return false;
			
		};
		
		
		var _flujoPorDispersion = function(){			
			if($rootScope.solicitudOSJson.idProducto == ID_PRODUCTO.prestamoPersonal)
				return true
			else					
				return false;								
		};
		
		var _verificarCanalValidarCodigoCel = function( canal ){
			
			if( !canal ) return false;
				
			var tipoTasa = tipoTasas.prestamoPersonal.id;
			var excepcionesCanal = generalService.multitasas("PRESTAMOS PERSONALES.SERVICIOS.EXCEPCION VALIDA CODIGOS",tipoTasa);
			
			if( !excepcionesCanal && excepcionesCanal == null ){
				excepcionesCanal = [{}];				
			}			
			
			var index = excepcionesCanal.map( function( data ){
				return data['valor'];
			}).indexOf( canal.toString() );
				
			if( index != -1 ){
				return true;
			}
			
			return false;
			
		};
		
		var _validarMostarTermometro = function(solicitudJson){
			var idProducto=solicitudJson.idProducto;
			var idDetalleProducto=solicitudJson.cotizacion.detallesCotizacion[0].idProducto;
			var canal=solicitudJson.idCanal;
			
			var indexDetalleProducto=EXCEPCIONES_TERMOMETRO.indexOf(parseInt(idDetalleProducto));
			var indexProducto=EXCEPCIONES_TERMOMETRO.indexOf(idProducto);
			
//			if(((indexDetalleProducto==-1 && indexProducto==-1) || canal!=CANALES.modatelas) || (indexProducto==-1 && canal!=CANALES.modatelas))
			if( indexDetalleProducto==-1 && indexProducto==-1 )
				return true;
			else
				return false;
			
		};
		
		var _bloqueoSecciones = function( solicitudJson, excepcionesBloqueo ){
			
			var seccionesJson = {};
			
			seccionesJson[SECCION_PERSONALES] = solicitudJson.cotizacion.clientes[0];
			seccionesJson[SECCION_HOGAR] = solicitudJson.cotizacion.clientes[0].domicilios[0];
			seccionesJson[SECCION_EMPLEO] = solicitudJson.cotizacion.clientes[0].datosEmpleo[0];
			seccionesJson[SECCION_INGRESOS_GASTOS] = solicitudJson.cotizacion.clientes[0].ingresosEgresos;
			seccionesJson[SECCION_AVAL] = solicitudJson.avales[0];
			seccionesJson[SECCION_REFERENCIAS] = solicitudJson.referencias;
			seccionesJson[SECCION_DOCUMENTOS] = solicitudJson.documentos;
			seccionesJson[SECCION_DOCUMENTOS] = solicitudJson.documentos;
			seccionesJson[SECCION_CONTRATOS] = solicitudJson.contratos;
			
			for( var seccion in seccionesJson ){
				
				if( seccionesJson.hasOwnProperty(seccion) ){
					
					var index = excepcionesBloqueo.indexOf( seccion );
					
					if( index == -1 )
						seccionesJson[seccion].bloqueado = 1;
					
				}
				
			}			
			
		};		
		
		
		var _getFechaRecuperacionSolicitudRechazada = function(diasRechazoSolicitud, limiteDiasRechazo){
			var msPorDia = 86400000;		//milisegundo de un dia			
			var timeFechaRechazo = new Date().getTime() - (diasRechazoSolicitud * msPorDia);
			var fechaRecuperacion = new Date( timeFechaRechazo + (limiteDiasRechazo * msPorDia) );
			var fechaTotal=(((fechaRecuperacion.getDate()+"").length>1)?fechaRecuperacion.getDate():"0"+fechaRecuperacion.getDate())+"/"+((((fechaRecuperacion.getMonth()+1)+"").length>1)?(fechaRecuperacion.getMonth()+1):"0"+(fechaRecuperacion.getMonth()+1))+"/"+(((fechaRecuperacion.getFullYear()+"").length>1)?fechaRecuperacion.getFullYear():"0"+fechaRecuperacion.getFullYear());
			
			return fechaTotal;
		}
		
		
		var _recuperarSolicitud = function(objetoSolicitud){
		
			if(objetoSolicitud.tipoPersona==3)//ES AVAL
				var isAval=true;
			else
				var isAval=false;
				
			if( objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.generada.id ||
				objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.mesaControl.id ||
				objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.malZonificada.id ||	
				objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.preautorizada.id ||
				objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.investigacion.id || 
				objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.condicionada.id && !isAval ||
				objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.autorizada.id ||	 
				objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.preRechazada.id ||
				objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.mas120mts.id ||
				objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.menos30min.id ||
				objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.pendienteProceso.id ||
				objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.investigacionGCC.id ||
				objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.investigacionGCCDom.id ||
				objetoSolicitud.fiStatusLcrID == STATUS_SOLICITUD.bloqueado.statusLCR){	
					return {continar: true, path: null};
					
			}else if(objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.condicionada.id && isAval && 
					 objetoSolicitud.condicionID == STATUS_SOLICITUD.condicionada.idCondicion.desaJvc)
					$rootScope.message( "AVISO", ["El Coacreditado se encuentra en validación, es necesario esperar la respuesta de la mesa de crédito."], "Aceptar", null, null, null, null, null, null);
					
			else if(objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.rechazada.id){							
					return {continar: false, path: "huella"};
				
			}else if( objetoSolicitud.idEstatusSeguimiento == STATUS_SOLICITUD.cancelada.id ){	
				_buildSolicitudJson($rootScope, null);
				$rootScope.message( "AVISO", [mensajeSoporte], "Aceptar", null, null, null, null, null, null);
				
			}

			return {continar: false, path: null};			
		};
		
		
		/**
		 * FUNCION PARA DEFINIR EL PATH DEL FLUJO DEL COACREDITADO
		 */
		var _getPathSectionOS = function(solicitusdJson, canal){
			var path = null;
			console.log(solicitudJson.idSolicitud);
			var documentoEncolado = _documentoEncolado(solicitudJson);
			if( solicitudJson.idSeguimiento == STATUS_SOLICITUD.malZonificada.id ){
				var excepciones = [ SECCION_HOGAR.toString() ];
				_bloqueoSecciones( solicitudJson, excepciones );
				path = "/ochoPasosOS";
				
			}else if(isAval){
				var excepciones = [ SECCION_AVAL.toString() ];
				_bloqueoSecciones( solicitudJson, excepciones );
				path = "/ochoPasosOS";
			} else if(solicitudJson.idSeguimiento == STATUS_SOLICITUD.generada.id) {
				var excepciones = [ SECCION_AVAL.toString() ];
				_bloqueoSecciones( solicitudJson, excepciones );
				path = "/ochoPasosOS";
			} //Aqui se metera la validacion cuando se tenga la cita, porque no se a donde redirigirla aún. 
		};
								
		
		var _getPathSection = function(solicitudJson, canal ){
			var path = null;
			console.log(solicitudJson.idSolicitud);
			var documentoEncolado = _documentoEncolado(solicitudJson);
			if( solicitudJson.idSeguimiento == STATUS_SOLICITUD.malZonificada.id ){
				var excepciones = [ SECCION_HOGAR.toString() ];
				_bloqueoSecciones( solicitudJson, excepciones );
				path = "/ochoPasos";
				
			}else if(isAval){
				var excepciones = [ SECCION_AVAL.toString() ];
				_bloqueoSecciones( solicitudJson, excepciones );
				path = "/ochoPasos";
				
				
			}else if(
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.investigacion.id  &&  solicitudJson.creditoInmediato == 1) ||					
					  ( ( solicitudJson.idSeguimiento == STATUS_SOLICITUD.generada.id || 
						solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id ||
						( solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && solicitudJson.marca == STATUS_SOLICITUD.preautorizada.marca.fico ) /* <--CON EL TIEMPO QUITAR*/
					  ) && solicitudJson.existeCita == 0 ) || 
					  ( 
					    solicitudJson.idSeguimiento == STATUS_SOLICITUD.condicionada.id && solicitudJson.idCondicion == STATUS_SOLICITUD.condicionada.idCondicion.expIncompleto ||
					    solicitudJson.idSeguimiento == STATUS_SOLICITUD.condicionada.id && solicitudJson.idCondicion == STATUS_SOLICITUD.condicionada.idCondicion.cambioAval
					  ) ||
					  (	
						 solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && 
						 ( solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.ejecutivo || 
						   solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expCompleto  ||
						   solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente  ||
						   solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expRechazado ||
						   solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.certificadoItalikaActivado  ||
						   solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinLiberar ||
						   solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.condicionadoMesa ||
						   solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.clienteVerdeJVC
						 )  && solicitudJson.idSolicitudTienda != 0 &&   solicitudJson.idEstatusLCR != STATUS_SOLICITUD.bloqueado.statusLCR
					  ) ||
					  (
						 solicitudJson.idEstatusLCR == STATUS_SOLICITUD.inactivo.statusLCR && 
					     (solicitudJson.idMotivoBloqueo == STATUS_SOLICITUD.inactivo.idMotivoBloqueo.sinLiberar120 || solicitudJson.idMotivoBloqueo == STATUS_SOLICITUD.inactivo.idMotivoBloqueo.sinSurtir120) /* PENDIENTE POR REVISAR ESTADO INACTIVO*/
					  )||					  
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id && solicitudJson.existeCita == 1 && solicitudJson.idSolicitudTienda)||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.pendienteProceso.id) ||
					  ( solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.docDigitalizado ) || 
					  ( solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.docPendValidar ) ||
					  ( solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.DocValidado )
				   ){/* CLOSE IF */				 
				path = "/ochoPasos";
				
			}else if(solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.procesoBateriaBuro
					&& $rootScope.userSession.idPerfil == PUESTO_GERENTE ){
				/**
				 * Redirige a la vista de la Bateria de PReguntas cuando tenga un status 6, una marca 4006 (procesoBateriaBuro) y que sea GERENTE
				 **/
				path = "/datosEncuesta";
				
			}else if(solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.procesoBateriaBuro 
					&& ( $rootScope.userSession.idPerfil == PUESTO_EJECUTIVO || $rootScope.userSession.idPerfil == ASESOR_DE_NEGOCIOS || $rootScope.userSession.idPerfil == PUESTO_ASESOR_CREDITO ) ){
				/*
				 * Redirige a la vista de ochoPasos cuando tenga un status 6, una marca 4006 (procesoBateriaBuro) y que sea un EJECUTIVO 
				 */
				path = "/ochoPasos";				
				
			}else if(solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && 
						(solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.errorBateriaBuro ||
						solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.evalucionCorrectaBateria ||
						solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.evalucionCorrectaBateriaMCO)
					){
				/**
				 * Redirige a la vista del Dia de Pago cuando tenga un status 6 y una marca 4007, 4008 o 4009
				 **/
				path = "/credito";
// I-MODIFICACION TDC 
			}else if((solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id &&  solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.ejecutivo && solicitudJson.flujoSolicitudADN != 99) ||
					(solicitudJson.idSeguimiento == STATUS_SOLICITUD.investigacion.id && solicitudJson.flujoSolicitudADN != 99)){
				path = "/visitaAsesor";
// F-MODIFICACION TDC 
				
			}else if( (solicitudJson.idSeguimiento == STATUS_SOLICITUD.investigacion.id  &&  solicitudJson.creditoInmediato == 0) ||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.investigacionGCC.id  &&  solicitudJson.creditoInmediato == 0) ||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.investigacionGCCDom.id &&  solicitudJson.creditoInmediato == 0) ||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.mesaControl.id  && solicitudJson.marca == STATUS_SOLICITUD.mesaControl.marca.revisionMesa) ||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.mesaControl.id) ||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.generada.id  &&  solicitudJson.existeCita == 1) ||					  
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && !solicitudJson.idSolicitudTienda && solicitudJson.existeCita == 1) ||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id && solicitudJson.existeCita == 1 && !solicitudJson.idSolicitudTienda)||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && solicitudJson.marca==STATUS_SOLICITUD.autorizada.marca.jvc) ||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.condicionada.id && solicitudJson.idCondicion == STATUS_SOLICITUD.condicionada.idCondicion.desaJvc) ||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.preRechazada.id)||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.reprogramada.id)||					  
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.mas120mts.id)||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.menos30min.id) || 
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.callCenter) ||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id &&  solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tipoDispersionSeleccionado) ||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id &&  solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinLiberar) ||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id &&  solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.condicionadoMesa) ||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.reprogramada.id) ||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazEntregada) ||
					  
					  /**
					   * Condiciones para mandar al tracking
					   * La primera es si truena al Generar Pedido para Prestamos
					   * La segunda es si truena al Generar Pedido para Consumo
					   **/
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && (solicitudJson.marca == 1016 || solicitudJson.marca == 253 || solicitudJson.marca == 254 || solicitudJson.marca == 5006|| solicitudJson.marca == 1007) && solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal) ||
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && solicitudJson.marca == 5002 && solicitudJson.idProducto != ID_PRODUCTO.prestamoPersonal) ||
					  
					  (solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && solicitudJson.tipoSolicitud == SOLICITUD_REACTIVADO && solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.liberacionAplicada)){				
				path = "/estatus";
				
			}else if(solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && 
					 (
						(solicitudJson.idEstatusLCR == STATUS_SOLICITUD.bloqueado.statusLCR &&
							(solicitudJson.idMotivoBloqueo == STATUS_SOLICITUD.bloqueado.idMotivoBloqueo.entregaInmediata || solicitudJson.idMotivoBloqueo == STATUS_SOLICITUD.bloqueado.idMotivoBloqueo.atraso)								
						)|| solicitudJson.marca==STATUS_SOLICITUD.autorizada.marca.surtida
						 || solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.pendienteDeSurtir
						 || solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.pendienteDigitalizar
						 || solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.CDPActualizada
						 || solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.bloqueoIntentos
					 )){	
				var myObject = {
					origen    : FICHA.origen.recuperar
				};
				if(solicitudJson.idEstatusLCR == STATUS_SOLICITUD.bloqueado.statusLCR)
					myObject.tipoFicha=FICHA.tipoFicha.bloqueada;
							
				_setDataBridge( myObject );
					
				path = "/ficha";
			
			}else if( solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id  &&  $rootScope.sucursalSession.idCanal == CANALES.soriana && solicitudJson.idProducto == ID_PRODUCTO.consumo &&
					( solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.liberadaConTaz || solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazActivada  ||
					  solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinTaz)){
				
				var myObject = {
					origen    : FICHA.origen.recuperar
				};
						
				_setDataBridge( myObject );
// I-MODIFICACION TDC 
				if ($rootScope.productosTarjetas(solicitudJson.idProducto) || $rootScope.sucursalSession.idCanal == CANALES.soriana && solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinTaz){
					path = "/estatus";
				}else{
					if( (_verificarCanalEnDispersion( canal ) && solicitudJson.idProducto != ID_PRODUCTO.prestamoPersonal) ||solicitudJson.idProducto != ID_PRODUCTO.prestamoPersonal)
						path = "/ficha";
					else
						path = "/surtimiento";
				}
// I-MODIFICACION TDC
				
			}else if( solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id  &&  $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.tazLigada){
						path = "/liberacion";
		// I-MODIFICACION TDC
						
			}else if( solicitudJson.idSeguimiento == STATUS_SOLICITUD.rechazada.id ){
				if(isAval)					
					$rootScope.message( "AVISO", ["Infórmale a tu cliente que el Coacreditado que eligó ha sido rechazado, es necesario capturar un nuevo Coacreditado. "], "Aceptar", null, null, null, null, null, null);
					
				else if(solicitudJson.diasRechazo < _diasRechazo){
					_buildSolicitudJson($rootScope, null);
					var fechaTotal = _getFechaRecuperacionSolicitudRechazada(solicitudJson.diasRechazo, _diasRechazo);
					$rootScope.message( "AVISO", ["Lo sentimos, Infórmale a tu cliente que por politicas internas no podra levantar una solicitud hasta el: "+fechaTotal], "Aceptar", null, null, null, null, null, null);
					path = "/simulador";
					
				}else
					path = "recuperarRechazo";

			}else if( solicitudJson.idSeguimiento == STATUS_SOLICITUD.cancelada.id ){
				path =window.location.hash.replace("#", "");
				$rootScope.message( "AVISO", ["Este flujo aún esta en proceso sobre desarrollo."], "Aceptar", null, null, null, null, null, null);
				
			}else if(solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && 
					solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.liberacionAplicada &&
					 (solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal)
					){
				path =window.location.hash.replace("#", "");
				path = "/surtimiento";
				
			}else if((solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.autorizadoMesa) ||
					 (solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.condicionadoMesa)){
				path = "/ochoPasos";				
				
			}else if(solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id){	
				$rootScope.banderaFolio = true;
				path = "/estatus";
				
			}else if( solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && (solicitudJson.marca == STATUS_SOLICITUD.generada.marca.ocrEditaIne || solicitudJson.marca == STATUS_SOLICITUD.generada.marca.noOcrIne || solicitudJson.marca == STATUS_SOLICITUD.generada.marca.noOcrPasaporte)){
				_esValidoFlujoCallCenter(solicitudJson);
				path = "/callcenter";
				
			}else{
				path =window.location.hash.replace("#", "");
				_buildSolicitudJson($rootScope, null);
				path = "/simulador";
				
			}
			return path;
	
		}
		
		var _camelize=function(str) {
		    var pieces = str.toLowerCase().split(" ");
		    for ( var i = 0; i < pieces.length; i++ )
		    {
		    	if(["de", "del", "lo", "los","la","las","el","al"].indexOf(pieces[i])==-1){
			        var j = pieces[i].charAt(0).toUpperCase();
			        pieces[i] = j + pieces[i].substr(1);
		    	}
		    }
		    return pieces.join(" ");
		}
		
		var _calculaVistas=function(actual, anterior,recuperaSolicitud){			
//			var respuesta="";
//				
//			if(configuracion.origen.tienda && !configuracion.modo.offLine){
//				var leavingNgView = document.getElementsByClassName('page')[0];
//				var pasos={"datosPersonales":{},"datosHogar":{},"datosEmpleo":{},"ingresosGastos":{},"aval":{},"expediente":{},"referencias":{},"contratos":{},"ochoPasosSimulador":{},"visitaAsesor":{}};
//				if(recuperaSolicitud)
//					respuesta="";
//				else if(actual==anterior)
//					respuesta=actual+"Out";			
//				else if(actual=="" && anterior=="ochoPasos"){
//					respuesta="simulador";
//					leavingNgView.className ="page ochoPasosSimulador";
//				}else if(actual=="ochoPasos" && anterior=="")
//					respuesta="ochoPasosSimulador";	
//				else if(pasos[actual]!=null && anterior=="ochoPasos"){
//					leavingNgView.className ="page ochoPasos";
//					respuesta=actual;
//				}else if(pasos[actual]!=null && pasos[anterior]!=null){
//					respuesta="pasoArriba";
//					leavingNgView.className ="page pasoArriba";
//				}else if(actual=="ochoPasos" && pasos[anterior]!=null){
//					respuesta=actual;
//					leavingNgView.className ="page "+anterior;
//				}else{
//					respuesta=actual;
//				}
//			}
//			console.log("Respuesta: "+respuesta);
//			return respuesta;
		};
		
		
		var _cleanValue = function(value){
			try{
    			value = value.replace("$ ","").replace(",","");  
    		}catch(e){}
    		
    		return value;
		}
		
		var _limpiaFormato = function( valorEntrada, formato ){
			
            var salidaLimpia = null;
            var cleanVal = "";
            
            if( valorEntrada == null || typeof valorEntrada == "undefined" ){
            	return "";
            }
            
            var re = /^\s+|\s+$|(\s)\s+/g;     
            // elimina espacios
            cleanVal = valorEntrada.replace( re, ' ' );
            var  transformedInput = cleanVal;    

            // busca la etiquetade formato
            var formatoArray = null;
            
            if (formato)
                 formatoArray = formato.split("-");
            else
                 formatoArray =[""];                                                        

            switch (formatoArray[0]) {                                       
                 
                 case "NP": //solo admite numeros positivos
                           
                           var valor = valorEntrada.replace( /\s/g, '',"$1 " );
                           transformedInput = valor ? valor.replace(/[^\d\s.]/g, '') : '';
                           
                           if (isNaN(transformedInput)){                     
                                var valorInt = transformedInput.replace(/--/g, "-");
                                transformedInput = valorInt;
                                var valorInt =    transformedInput.replace("..", ".");
                                transformedInput = valorInt;
                                var valorInt =    transformedInput.replace(/,/g, "");
                                transformedInput = valorInt;
                                
                                if (transformedInput == "-" || transformedInput == "." ){
                                // nothing
                                }else{
                                     if (isNaN(transformedInput)){
                                          transformedInput = "";
                                     }
                                }
                           }
                           
                      break;
                 case "NI":  //solo admite numeros enteros
                           
                           var valor = valorEntrada.replace( /\s/g, '',"$1 " );
                           transformedInput = valor ? valor.replace(/[^\d-]/g,'') : "";
                           
                           if (isNaN(transformedInput)){                     
                                var valorInt = transformedInput.replace(/--/g, "-");
                                if (transformedInput != "-"){
                                     transformedInput =  parseInt(valorInt);
                                     if (isNaN(transformedInput)){
                                          transformedInput = "";
                                     }
                                }
                           }
                           
                      break;
                 case "NIP":  //solo admite numeros enteros positivos
                           
                           var valor = valorEntrada.replace( /\s/g, '',"$1 " );
                           transformedInput = valor ? valor.replace(/[^\d]/g,'') : "";
                           
                           if (isNaN(transformedInput)){                     
                                var valorInt = transformedInput.replace(/--/g, "-");
                                transformedInput = valorInt;
                                if (transformedInput != "-"){
                                     transformedInput =  parseInt(valorInt);
                                     if (isNaN(transformedInput)){
                                          transformedInput = "";
                                     }
                                }
                           }
                           
                      break;
                 case "N":  //solo admite numeros
                           
                           var valor = valorEntrada.replace( /\s/g, '',"$1 " );
                           transformedInput = valor ? valor.replace(/[^\d\s.-]+/i, '') : '';
                           
                           if (isNaN(transformedInput)){                     
                                var valorInt = transformedInput.replace(/--/g, "-");
                                transformedInput = valorInt;
                                var valorInt =    transformedInput.replace("..", ".");
                                transformedInput = valorInt;
                                var valorInt = transformedInput.replace(/,/g, "");
                                transformedInput = valorInt;
                                     if (transformedInput == "-" || transformedInput == "." || transformedInput == "-."){
                                          // nothing
                                     }else{
                                          if (isNaN(transformedInput)){
                                               transformedInput = "";
                                          }
                                     }
                           }
                      
                      break;
                   default:
                	   transformedInput = valorEntrada;
            }/* END SWITCH */

            salidaLimpia = transformedInput;
            
            return salidaLimpia;
			
		}
		
		var _setPlazos = function( rootScope, arrayPlazos, typeAuth ){
			console.log( "NUEVOS PLAZOS" );
			console.log( arrayPlazos )
			_plazos = arrayPlazos;
			rootScope.buroHandler = _plazos;
			rootScope.buroConditional = typeAuth;
		}
		
		var _getPlazos = function( rootScope )
		{
			
			if( rootScope.buroHandler )
				return rootScope.buroHandler;
			else
				return _plazos;
			
		};
		
		
		var _buildDigitDocRequest = function(idSolicitud, idDoc, consecPersona, imgB64, nomCte, fotoCte){
			
			return {
				idSolicitud: idSolicitud,
				extensionIMG: "jpg",
				imagenB64: imgB64,
				idDocumento: idDoc,										
				consecutivoPersona: consecPersona,
				nombre: nomCte,
				foto: fotoCte
			};	
		};				
		
		
		
		var _porcentajeDocs = function(rootScope){				
				
			var porcentajeDoc = 0;
			var cargadosDoc = 0, pendientesDocs = 0;
			
			angular.forEach( rootScope.solicitudOSJson.documentos.documento, function(doc){																																	
				if( doc.status == STATUS_PENDIENTE)
					pendientesDocs++;
				else if( doc.status != STATUS_NOREQUERIDO)
					cargadosDoc++;
			});
			
						
			if(cargadosDoc == 0)
				porcentajeDoc = parseInt( 100 / (pendientesDocs + cargadosDoc)  );		
			else if(pendientesDocs == 0)
				porcentajeDoc = parseInt( (100 / (pendientesDocs + cargadosDoc)) * cargadosDoc );
			else
				porcentajeDoc = parseInt( (100 / (pendientesDocs + cargadosDoc)) * (cargadosDoc+1) );
			
														
			return 	porcentajeDoc;
		};
		
		var _calculaPorcentajeDocs = function(rootScope){				
			var porcentajeDoc = 0;
			var documentosOK = 0;
			var totalDocs=rootScope.solicitudOSJson.documentos.documento.length;
			
			angular.forEach( rootScope.solicitudOSJson.documentos.documento, function(doc){																																	
				if( doc.status != STATUS_PENDIENTE && doc.status != STATUS_RECHAZADO)
					documentosOK++;
			});
			
			porcentajeDoc = parseInt( (documentosOK/totalDocs)*100 );		
														
			return 	porcentajeDoc;
		};
		
		var _isNumeric = function(value){
			return /^([0-9])*$/.test(value);
		}
		
		var _setProduccion = function(isProd){
			isProduccion = isProd;
		}
		
		var _isProduccion = function(){
			return isProduccion;
		}
		
		
		var _textosModal = function(titulo, lista, nombreBotonSI, nombreBotonNO, cssTitulo, cssBotonSI, cssBotonNO, seccion, parametroDialogoModel,nombreCliente,productos){
			
			var tituloMDJ = "-"; 									
			var tituloCssMDJ = "-";
			var cuerpoMDJ = "-";						
			var btnSiMDJ = "-";
			var btnSiCssMDJ = "-";
			var btnNoMDJ = "-";
			var btnNoCssMDJ = "-";
			
			if( !_isEmpty(parametroDialogoModel) ){
				tituloMDJ = MODEL_DIALOGOS_JSON["FRONT ORIGINACION CENTRALIZADA DIALOGOS."+seccion+"."+parametroDialogoModel+".TITULO TXT.valor"]; 									
				tituloCssMDJ = MODEL_DIALOGOS_JSON["FRONT ORIGINACION CENTRALIZADA DIALOGOS."+seccion+"."+parametroDialogoModel+".TITULO CSS.valor"];
				cuerpoMDJ = MODEL_DIALOGOS_JSON["FRONT ORIGINACION CENTRALIZADA DIALOGOS."+seccion+"."+parametroDialogoModel+".CUERPO TXT.valor"];								
				btnSiMDJ = MODEL_DIALOGOS_JSON["FRONT ORIGINACION CENTRALIZADA DIALOGOS."+seccion+"."+parametroDialogoModel+".BTN SI TXT.valor"];
				btnSiCssMDJ = MODEL_DIALOGOS_JSON["FRONT ORIGINACION CENTRALIZADA DIALOGOS."+seccion+"."+parametroDialogoModel+".BTN SI CSS.valor"];
				btnNoMDJ = MODEL_DIALOGOS_JSON["FRONT ORIGINACION CENTRALIZADA DIALOGOS."+seccion+"."+parametroDialogoModel+".BTN NO TXT.valor"];
				btnNoCssMDJ = MODEL_DIALOGOS_JSON["FRONT ORIGINACION CENTRALIZADA DIALOGOS."+seccion+"."+parametroDialogoModel+".BTN NO CSS.valor"];
			}
			
			
			return {
				title: 			(tituloMDJ=="-")? titulo:tituloMDJ,
				estiloTitulo: 	(tituloCssMDJ=="-")? (cssTitulo==null?"bgAzul": cssTitulo) : tituloCssMDJ,						
				message: 		(cuerpoMDJ=="-")? lista: [cuerpoMDJ],																
				nameConfirmButton: 	(btnSiMDJ=="-")? (nombreBotonSI==null?"Aceptar": nombreBotonSI) : btnSiMDJ, 
				estiloBotonConfirm: 	(btnSiCssMDJ=="-")? (cssBotonSI==null?"azul": cssBotonSI) : btnSiCssMDJ,							
				nameCancelButton: 	(btnNoMDJ=="-")? (nombreBotonNO==null?"Cancelar": nombreBotonNO) : btnNoMDJ,
				estiloBotonCancel: 	(btnNoCssMDJ=="-")? (cssBotonNO==null?"gris": cssBotonNO) : btnNoCssMDJ,
				nombreCliente: nombreCliente,
				productos: productos
						
			};
			
		};
		
		
		var _repeatCadena = function(cadena, longitud){
			var out = cadena.toString();    	
	    	
	    	while(out.length < longitud)
	    		out += cadena;
	    	
	    	    	    		    	
	    	return out.substring(0,longitud);
		}
		
		
		
		var _addZerosLeft = function(cadena, longitud){
			var out = cadena.toString();    	
	    	
			if(out.length < longitud)
	    		for(var i=out.length; i<longitud; i++)
	    			out = "0"+out;
	    		    	    	    		    
	    	return out;
		}
		
		var _buildUrlTicket = function(URL, isCrypt, isTarjeta){
			var _url = URL;
// I-MODIFICACION TDC (APUNTAR AL SERVER DE TARJETAS)
			if (isTarjeta){
				if(isCrypt){
					if ( _isEmpty(_getArrayValue('ticket')) )
						_url = IP_WEB_TARJETAS +  securityService.decryptAES_value(URL)+"?ticket="+_getArrayValue('ticketTarjeta');				
					else
						_url = IP_WEB_TARJETAS + securityService.decryptAES_value(URL)+"?ticket="+_getArrayValue('ticket');
					
				}else{						
					if ( !_isEmpty(_getArrayValue('ticket')) ){
						_url = IP_WEB_TARJETAS + URL+"?ticket="+_getArrayValue('ticket');
						if (isTarjeta){
							_url = URL+"?ticket="+_getArrayValue('ticket');
						}
					}
				}
			}else{
				if(isCrypt){
					if ( _isEmpty(_getArrayValue('ticket')) )
						_url = securityService.decryptAES_value(URL);				
					else
						_url = IP + securityService.decryptAES_value(URL)+"?ticket="+_getArrayValue('ticket');
					
				}else{						
					if ( !_isEmpty(_getArrayValue('ticket')) ){
						_url = IP + URL+"?ticket="+_getArrayValue('ticket');
						if (isTarjeta){
							_url = URL+"?ticket="+_getArrayValue('ticket');
						}
// F-MODIFICACION TDC (APUNTAR AL SERVER DE TARJETAS)
					}
				}
			}

			
			return _url;
		}
		
		var _keyEmpBase64 = function(){						            
    		var wordArray = CryptoJS.enc.Utf8.parse( _repeatCadena( $rootScope.userSession.noEmpleado, 16 ) ); 
			return CryptoJS.enc.Base64.stringify(wordArray);
		}
		
		var _recorrerOpcionalesPorSeccion = function( nombreSeccion )
		{
			var arregloBasicos = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES." + nombreSeccion ];
			
			var arregloOpcionales = [];
							
			arregloBasicos.map(function(data){
				var currentData = data;
				data['listAtributos'].map(function( dataAttribute ){
					if( dataAttribute['descripcion'] == 'OPCIONAL' ){
						var object = {
							valor: currentData['descripcion'].toLowerCase(),
							opcional: dataAttribute['valor']
						};
						arregloOpcionales.push( object );
					}
				});
			});
						
			return arregloOpcionales;
			
		};
		
		
		var _setFlagLogin = function(loginFlag){
			loginOn = loginFlag;
		};
		
		var _getFlagLogin = function(){
			return loginOn;
		};
		
		var _setDataBridge = function( object ){
			dataBridge = object;
		};
		
		var _getDataBridge = function(){
			return dataBridge;
		}
		
		var _average = function( array ){
			var sum = array.reduce(function(a, b) { return a + b; });
			var avg = sum / array.length;
			return Math.round(avg);
		};
		
		
		var _toUpperCaseSinAcentos = function(cadena){
			if( _isEmpty(cadena) )
				return cadena;
			else
				return cadena.toUpperCase().replace(/Á/g,"A").replace(/É/g,"E").replace(/Í/g,"I").replace(/Ó/g,"O").replace(/Ú/g,"U");
		};
		
		var _cleanRootScope = function(rootScope){
			for ( var prop in rootScope ) {
			    if ( prop.substring(0,1) !== '$' && typeof rootScope[prop] != 'function' && prop != 'inSession'  && prop !=  'userSession'  && prop !=  'sucursalSession' && prop != 'solicitudesProceso' && 
			    		prop != 'consultaFuncionalidad' && prop != 'consultaAbonos' && prop != 'contadorAbonos' ) {
			        delete rootScope[prop];
			    }
			}
			
			rootScope.imgUsuario = IMG_USR;
			rootScope.waitLoaderStatus = LOADER_HIDE;
			rootScope.rechazoBuro = false;
			rootScope.montoLimiteInicial="10000";
			rootScope.productosAutorizados=[];
			rootScope.productoSeleccionado="";
		};
		
		var _cleanRootScopeOS = function(rootScope){
			for ( var prop in rootScope ) {
			    if ( prop == 'solicitudOSJson') {
			        delete rootScope[prop];
			    }
			}
			
		};
		
		var _noEditaSeccion = function(solicitud,arraySecciones){
			for(var i=0; i < arraySecciones.length; i++){
				switch(arraySecciones[i]){
					case 1:
						solicitud.cotizacion.clientes[0].editable=1;
						break;
					case 2:
						solicitud.cotizacion.clientes[0].domicilios[0].editable=1;
						break;
					case 3:
						solicitud.cotizacion.clientes[0].datosEmpleo[0].editable=1;
						break;
					case 4:
						solicitud.cotizacion.clientes[0].ingresosEgresos.editable=1;
						break;
					case 5:
						solicitud.avales[0].editable=1;
						break;
					case 6:
						solicitud.referencias.editable=1;
						break;
					case 7:
						solicitud.documentos.editable=1;
						break;
					case 8:
						solicitud.contratos.editable=1;
						break;
				}
			}
			return solicitud;
		};
		
		var _siEditaSeccion = function(solicitud,arraySecciones){
			for(var i=0; i < arraySecciones.length; i++){
				switch(arraySecciones[i]){
					case 1:
						solicitud.cotizacion.clientes[0].editable=0;
						break;
					case 2:
						solicitud.cotizacion.clientes[0].domicilios[0].editable=0;
						break;
					case 3:
						solicitud.cotizacion.clientes[0].datosEmpleo[0].editable=0;
						break;
					case 4:
						solicitud.cotizacion.clientes[0].ingresosEgresos.editable=0;
						break;
					case 5:
						solicitud.avales[0].editable=0;
						break;
					case 6:
						solicitud.referencias.editable=0;
						break;
					case 7:
						solicitud.documentos.editable=0;
						break;
					case 8:
						solicitud.contratos.editable=0;
						break;
				}
			}
			return solicitud;
		};
		
		
		
		var _numberWithCommas = function( number ) {                                                
            var parts = number.toString().split(".");
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            return parts.join(".");                                                    
		};
		
		var _mergeSort= function(items){
			if (items.length < 2) {
		        return items;
		    }

		    var middle = Math.floor(items.length / 2),
		    left = items.slice(0, middle),
		    right = items.slice(middle);

		    return _merge(_mergeSort(left), _mergeSort(right));
		}

		var _merge= function(left, right){
			var result  = [],
	        il = 0,
	        ir = 0;

			while( il < left.length && ir < right.length ){
	        	if (left[il] < right[ir])
	            	result.push(left[il++]);
	        	else 
	        		result.push(right[ir++]);
	    	}
			
		    return result.concat(left.slice(il)).concat(right.slice(ir));
		}
				
		var _validaSeccionCompleta=function(seccion,rootScope){
			
			switch(seccion){                                                                                                                                                   
				case SECCION_PERSONALES :                                                                                                                                           
					if (rootScope.solicitudOSJson.cotizacion.clientes[0].porcentaje == "100") 
						return true;
					break;                                                                                                                                                                  
				case SECCION_HOGAR :                                                                                                                                           
					if (rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].porcentaje == "100")
						return true;
					break;                                                                                                                                                  
				case SECCION_EMPLEO :                                                                                                                                           
					if (rootScope.solicitudOSJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje == "100")
						return true;
					break; 
				case SECCION_INGRESOS_GASTOS :                                                                                                                                           
					if (rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.porcentaje == "100")
						return true;
					break; 
				case SECCION_AVAL :                                                                                                                                           
					if (rootScope.solicitudOSJson.avales[0].porcentaje == "100")
						return true;
					break;                                                                                                                                                      
				case SECCION_REFERENCIAS :                                                                                                                                           
					if (rootScope.solicitudOSJson.referencias.porcentaje == "100")
						return true;
					break; 
				case SECCION_DOCUMENTOS :                                                                                                                                           
					if (rootScope.solicitudOSJson.documentos.porcentaje == "100")
						return true;
					break;
				case SECCION_CONTRATOS :                                                                                                                                           
					if (rootScope.solicitudOSJson.contratos.porcentaje == "100")
						return true;
					break; 
				default:
					return false;
					break;
			}
			return false;
		};
		
		var _getSeccionesIncompletas=function(rootScope){
			var seccionesIncompletas=[];
			for(var i=0;i<SECCIONES_OCHO_PASOS.length;i++){
				if(!_validaSeccionCompleta(SECCIONES_OCHO_PASOS[i],rootScope))
					seccionesIncompletas.push(SECCIONES_OCHO_PASOS[i]);
			}
			return seccionesIncompletas;
		};	
		
		var _getSeccionesCompletas=function(rootScope){
			var seccionesCompletas=[];
			for(var i=0;i<SECCIONES_OCHO_PASOS.length;i++){
				if(_validaSeccionCompleta(SECCIONES_OCHO_PASOS[i],rootScope))
					seccionesCompletas.push(SECCIONES_OCHO_PASOS[i]);
			}
			return seccionesCompletas;
		};	
		
		var _isProdModatelas=function(rootScope){
			if(rootScope.solicitudOSJson.cotizacion.detallesCotizacion[0].idProducto == ID_PRODUCTO.modatelas+"")
				return true;
			else if(rootScope.solicitudOSJson.idProducto == ID_PRODUCTO.modatelas)
				return true;
			else
				return false;
		};
		
		var _getDescripcionProducto=function(idProducto){
			var desCatalogo = '';
	 		
	 		if(_isProdModatelas($rootScope))
	 			idProducto=ID_PRODUCTO.modatelas;
	 		
			angular.forEach( MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.CATALOGO PRODUCTOS"], function(value, key){
				if(idProducto == value["ID"].valor)
					desCatalogo=value["ETIQUETA"].valor;
											
			});
			
			if($rootScope.solicitudOSJson.idProducto == ID_PRODUCTO.prestamoPersonal)
				desCatalogo="Préstamo Personal";	
			
	 		return _camelize(desCatalogo);
	 	};
		
		
		var _showProductosCanal = function(canal){
			return  !(canal == CANALES.modatelas || canal == CANALES.waldos );			
		};
		
		
		var _isCanalExterno = function(canal){					
			return CANALES_EXTERNOS.indexOf(canal) > -1? true:false;
		};
		
		var _isCanalInterno = function(canal){					
			return CANALES_INTERNOS.indexOf(canal) > -1? true:false;
		};
			
		var _locationPath = function(path){
			
			if( path == "/ochoPasosOS" && _nuevoFlujoQickFixes(path))
				path = "/datosCoacreditado";
			
			$rootScope.isLocation = true;
			$location.path(path);
		}
		
		var _nuevoFlujoQickFixes = function(path){
			
			var unificacionSecciones = false;
			var porcentajeDBDH = $rootScope.solicitudOSJson.cotizacion.clientes[0].porcentaje != 100 ||  $rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].porcentaje != 100; 
				
			if( porcentajeDBDH ){
					 unificacionSecciones = true;
		     }
			
			
			return unificacionSecciones;
		}

		var _productosQuickFixes = function(){
			
			if( !_isBazDigital() && 
			  ( $rootScope.solicitudOSJson.idProducto == PRODUCTOS.prestamoPersonal.ID.valor ||
				$rootScope.solicitudOSJson.idProducto == PRODUCTOS.telefonia.ID.valor ||
			    	$rootScope.solicitudOSJson.idProducto == PRODUCTOS.consumo.ID.valor ||
			    	$rootScope.solicitudOSJson.idProducto == PRODUCTOS.italika.ID.valor ))
					return true;
			
			return false;
		}
		
		var _isBazDigital = function(){
			return $rootScope.solicitudOSJson.idPlataforma == 6;
		}
		
		var _sobrescribeOfertaBuroConsumo=function(solicitudJson){
			
			var banderaCanalesGS = _isCanalInterno($rootScope.sucursalSession.idCanal);
//			var banderaCanalesGS = false;
//			angular.forEach(CANALESGS, function(value, key) {
//				if(value == $rootScope.sucursalSession.idCanal){
//					banderaCanalesGS = true;
//				}
//			});
			
			if((solicitudJson.idProducto==ID_PRODUCTO.consumo ||
					solicitudJson.idProducto==ID_PRODUCTO.italika  ||
					solicitudJson.idProducto==ID_PRODUCTO.telefonia) && 
					banderaCanalesGS)
				return true;
			else
				return false;
		};
		
		var _forceCloseModal=function(){
			$(".ngdialog").css( "display", "none" );
		};
		
		var _displayMessage = function(texto){
			return (_isEmpty(texto)?ERROR_SERVICE:texto);
		};
		
		/**
		 * Función que regresa una cadena (o subcadena) con el tamaño que se especifica.
		 */
		var _checkLength = function(cadena, size) {
			// cadena es una string.
			if(typeof cadena === 'string') {
				// size es un number
				if(typeof size === 'number') {
					// Se toma la parte entera del número, en caso de que no llegue un entero.
					var entero = Math.floor(size);
					
					// El tamaño de la cadena es mayor al provisto.
					if(cadena.length > entero) {
						// Se regresa una subcadena de la cadena provista
						return cadena.substring(0, entero - 1);
					} else {
						// Se regresa la cadena original.
						return cadena;
					}
				}
				
				// Se regresa la cadena original.
				return cadena;
			}
			
			return "";
		};
		
		/*
		 * Function para validar el CP
		 */
		
		var _validaCP = function(cp, cpanterior){
			
			if(cp != "" && cp != cpanterior && cp != -1 && cp != 0 && cp.length == 5){
				return true;
			}
			return false;
		};
		
		var _calculaPocentajeDocs = function(){
			var docsFirmados = 0;
			for(var i=0;i<$rootScope.solicitudOSJson.contratos.contrato.length;i++){
				if( i < 3 ){
					if($rootScope.solicitudOSJson.contratos.contrato[i].statusFirma == 1 || $rootScope.solicitudOSJson.contratos.contrato[i].statusFirma == 2)
						docsFirmados++;
					}
				}
				return $rootScope.solicitudOSJson.contratos.porcentaje = parseInt(((docsFirmados * 100) / ($rootScope.solicitudOSJson.contratos.contrato.length ) ).toFixed(0));
			}
		
		var _calculaPocentajeOS = function(solicitudOSJson){
			var porcentajes = [];
			var sumaPorcentaje=0;
			var porcentajeTotal = 0;
			porcentajes.push(solicitudOSJson.cotizacion.clientes[0]); 
			porcentajes.push(solicitudOSJson.cotizacion.clientes[0].domicilios[0]);
			porcentajes.push(solicitudOSJson.cotizacion.clientes[0].datosEmpleo[0]);
			porcentajes.push(solicitudOSJson.cotizacion.clientes[0].ingresosEgresos);
			porcentajes.push(solicitudOSJson.documentos);
			porcentajes.push(solicitudOSJson.contratos);
			
			for(var i=0; i < porcentajes.length; i++){
				if(porcentajes[i].porcentaje < 100){
					sumaPorcentaje = sumaPorcentaje + porcentajes[0].porcentaje;
				}
			}
			
			$rootScope.porcentajeTotal = parseInt(((sumaPorcentaje * 100) / porcentajes.length).toFixed(0));
		}
		
		var _calcularPorcentajeDocumentosOS = function(){
			var numDocsCapturados = 0;
    			var numDocsRequeridos = 0;
    			var existeDoc = false;
    			var doc = $rootScope.solicitudOSJson.documentos.documento;
    			
    			if(doc != null){
    				for(var i = 0; i<doc.length; i++){
    					if(doc[i].status == STATUS_CAPTURADO || doc[i].status == STATUS_VERIFICADO || doc[i].status == STATUS_VALIDADO || doc[i].status == STATUS_ENCOLADO_IPAD ){
    						
    						switch(doc[i].idDocumento){
    						case IDENTIFICACION_OFICIAL.id:
    							numDocsCapturados++;
    							break;
    						case COMP_DOMICILIO.id:
    							numDocsCapturados++;
    							break;
    						case COMP_PROPIEDAD.id:
    							numDocsCapturados++;
    							break;
    						case COMP_ARRAIGO_LABORAL.id:
    							numDocsCapturados++;
    							break;
    						case COMP_INGRESOS.id:
    							numDocsCapturados++;
    							break;
    						case IDENTIFICACION_OFICIAL_AVAL.id:
    							numDocsCapturados++;
    							break;
    						case COMP_DOMICILIO_AVAL.id:
    							numDocsCapturados++;
    							break;
    						case COMP_PROPIEDAD_AVAL.id:
    							numDocsCapturados++;
    							break;
    						case COMP_INGRESOS_AVAL.id:
    							numDocsCapturados++;
    							break;
    						}
    					}
    					
    				
    					 /* if (doc[i].status != 3)
							numDocsRequeridos++;
    					
    					if(doc[i].status == 3 && $rootScope.solicitudOSJson.idSeguuimiento == STATUS_SOLICITUD.autorizada.id)
    						numDocsRequeridos++;*/
    				}
    			}
    			
    			if( numDocsCapturados > 0){
	    			var porcentajeExp = (numDocsCapturados * 100) / doc.length;
	    			$rootScope.solicitudOSJson.documentos.porcentaje =  porcentajeExp > 100 ? 100: parseInt( porcentajeExp.toFixed(0) );
	    		}else
	    			$rootScope.solicitudOSJson.documentos.porcentaje = 0;
		}
		
		var _esValidoFlujoCallCenter = function(solicitudJson){
			try{
				$rootScope.esValidoFlujoCallCenter = (solicitudJson.idSolicitud != "")?true:false;
			}catch(e){
				$rootScope.loggerIpad("Error al validar el idSolicitud: "+solicitudJson, e);
			}
		}
		
		var _consultaHistoricoMarcasOS = function(arrayMarcas){
			var idMarca = 0;
			if(typeof $rootScope.historicoMarcasOS !== "undefined" && $rootScope.historicoMarcasOS != null){
				for(var a=0;a<arrayMarcas.length;a++){
					for(var b=0;b<$rootScope.historicoMarcasOS.length;b++){
						if(arrayMarcas[a] == $rootScope.historicoMarcasOS[b]){
							idMarca=arrayMarcas[a];
							break;
						}
					}
					if(idMarca != 0)
						break;
				}
			}
			return idMarca;
		}

		return {
			setProduccion: _setProduccion,
			isProduccion: _isProduccion,
   		    datosPerPorcent: 0,
		    datosHogarPorcent: 0,
		    datosEmpleoPorcent: 0,
		    IngresosGastosPorcent: 0,
		    avalPorcent: 0,
		    referenciasPorcent: 0,
		    expedientesporcent: 0,
		    contratosPorcent: 0,	
		    descripcionCatalogo : _descripcionCatalogo,
		    construirCatalogo : _construirCatalogo,
		    construirCatalogoIdString: _construirCatalogoIdString,
		    delete$$hashKey: _delete$$hashKey,
		    validaConsultaBuro: _validaConsultaBuro,
		    validaConsultaBuroFinal: _validaConsultaBuroFinal,
		    homonimosData: "",
		    visitaAsesorData: "",
		    ocrIFE: false,
			alertaIngresosGastos:false,
		    tituloIngresosGastos:"Actualiza sus Ingresos y Gastos",
		    numAlertaIngresosGastos: 1,
		    alertaExpediente:false,
		    tituloExpediente:"Actualiza su comprobante de ingresos",
		    numAlertaExpediente:1,
		    validaTermino: _validaTermino,
		    validaCita: _validaCita,
		    isEmpty: _isEmpty,
		    getRespaldo: _getRespaldo,
		    getRespaldoDom: _getRespaldoDom,
		    setRespaldo: _setRespaldo,
		    setRespaldoDom: _setRespaldoDom,
		    flujoEfectivo: null,
		    validaContratos: _validaContratos,
		    existeSolicitud: _existeSolicitud,
		    buildSolicitudJson: _buildSolicitudJson,
		    buildSolicitudOSJson: _buildSolicitudOSJson,
		    buildPorcentajeJson: _buildPorcentajeJson,
		    calculaPorcentaje: _calculaPorcentaje,
		    setIP: _setIP,
   		    setMapping: _setMapping,
			getMapping: _getMapping,
			esValidoFlujoCallCenter: _esValidoFlujoCallCenter,
			getDatafromCategory: _getDatafromCategory,
			getFromCategory: _getFromCategory,
			documentoEnviadoValido: _documentoEnviadoValido,
			setCodigos: _setCodigos,
			getCodigos: _getCodigos,
			getPathSection: _getPathSection,
			getPathSectionOS: _getPathSectionOS,
			setSolicitudId: _setSolicitudId,
			getSolicitudId: _getSolicitudId,
			celularAnterior: "",
			correoAnterior: "",
			calculaVistas:_calculaVistas,
			cleanValue: _cleanValue,
			limpiaFormato: _limpiaFormato,			
			getPlazos: _getPlazos,
			setPlazos: _setPlazos,
			documentoEnviadoWS: _documentoEnviadoWS,
			setArrayValue:_setArrayValue,
			getArrayValue: _getArrayValue,
			buildDigitDocRequest: _buildDigitDocRequest,
			porcentajeDocs: _porcentajeDocs,
			isNumeric: _isNumeric,
			getDataInput: _getDataInput,
			documentoEncolado: _documentoEncolado,
			contratoEncolado: _contratoEncolado,
			textosModal: _textosModal,
			repeatCadena: _repeatCadena,
			verificarCanalEnDispersion: _verificarCanalEnDispersion,
			verificarCanalValidarCodigoCel:_verificarCanalValidarCodigoCel,
			buildUrlTicket: _buildUrlTicket,
			keyEmpBase64: _keyEmpBase64,
			addZerosLeft: _addZerosLeft,
			recorrerOpcionalesPorSeccion:  _recorrerOpcionalesPorSeccion,
			bloqueoSecciones: _bloqueoSecciones,
			setFlagLogin: _setFlagLogin,
			getFlagLogin: _getFlagLogin,
			isDefined: _isDefined,
			getDataBridge: _getDataBridge,
			setDataBridge: _setDataBridge,
			recuperarSolicitud:_recuperarSolicitud,
			documentoValido: _documentoValido,
			average: _average,
			camelize:_camelize,
			toUpperCaseSinAcentos: _toUpperCaseSinAcentos,
			cleanRootScope: _cleanRootScope,
			getProductosCredito: _getProductosCredito,
			noEditaSeccion: _noEditaSeccion,
			siEditaSeccion: _siEditaSeccion,
			construirCatalogoConIdCU: _construirCatalogoConIdCU,
			descripcionCatalogoConIdCU: _descripcionCatalogoConIdCU,
			numberWithCommas: _numberWithCommas,
			validarMostarTermometro:_validarMostarTermometro,
			buildDatosDefault:buildDatosDefault,
			bloqueaSecciones: _bloqueaSecciones,
			noEditableSecciones: _noEditableSecciones,
			mergeSort:_mergeSort,
			merge:_merge,
			validaSeccionCompleta:_validaSeccionCompleta,
			getSeccionesIncompletas:_getSeccionesIncompletas,
			getSeccionesCompletas:_getSeccionesCompletas,
			isProdModatelas:_isProdModatelas,
			getDescripcionProducto:_getDescripcionProducto,
			showProductosCanal: _showProductosCanal,
			isCanalExterno: _isCanalExterno,
			isCanalInterno: _isCanalInterno,
			locationPath: _locationPath,
			flujoPorDispersion: _flujoPorDispersion,
			isBazDigital: _isBazDigital,
			sobrescribeOfertaBuroConsumo:_sobrescribeOfertaBuroConsumo,
			forceCloseModal:_forceCloseModal,
			calculaPorcentajeDocs:_calculaPorcentajeDocs,
			displayMessage: _displayMessage,
			validaEdad: _validaEdad,
			getFechaRecuperacionSolicitudRechazada:_getFechaRecuperacionSolicitudRechazada,
			checkLength: _checkLength,
			validaCreditoInmediatoProducto: _validaCreditoInmediatoProducto,
			validaCP: _validaCP,
			calculaPocentajeDocs:_calculaPocentajeDocs,
			cleanRootScopeOS: _cleanRootScopeOS,
			calculaPocentajeOS: _calculaPocentajeOS,
			calcularPorcentajeDocumentosOS :_calcularPorcentajeDocumentosOS,
			consultaHistoricoMarcasOS: _consultaHistoricoMarcasOS,
			nuevoFlujoQickFixes: _nuevoFlujoQickFixes,
			productosQuickFixes: _productosQuickFixes
		};
	});
	
});