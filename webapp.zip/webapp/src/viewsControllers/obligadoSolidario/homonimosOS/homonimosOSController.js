'use strict'; 

define(["app"], function (app) {
	app.controller('homonimosOSController', function( $timeout, $scope, $rootScope, ngDialog, generalService, documentosService, 
													clienteUnicoService, modalService, messageData, tarjetaService, solicitudService, obligadoSolidarioService) {
		
		$scope.sombra="/9j/4AAQSkZJRgABAQEAYABgAAD/4QAWRXhpZgAASUkqAAgAAAAAAAAAAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABgAGEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2SKKEwRkxISVHO2gxQ/8APJP++aIm/cR/7ooLVokSyMxxf3F/KomSP+4v5VITUTGrSJImVf7o/KomA9KdLMkeN7quf7x61nz6vYwvse5TJ9Of5VVkDLLGoWY+tKJY5RlJFceoNMY1SSJuMZ2/vH86haV/77fnT2NQMatJE3EaaX/no/8A31TYp5TcRgyOQWA+9TGNNhP+lRf74puKswTdz1GiiiuA6Dn42/cp/u0FqhRv3a/7tBat0jNilqoanqCafatM/J6Kv941aLVxXiO9NxqJh/gg+X6nvT2Ay7ieW4kMkzl3Jzk1ATSk0wmgB0VxLbyeZC7I3setdFpeti6xDckLN/C3Zq5gmmbyjAg4IOQfSqTsJnesaiY1XsLwXlkkucvjDj0apWNbIhjGNNgP+lRf74pGNJAf9Ki/31/nTfwsXU9UooorzjpOTDfKPpQWqLdxSFq6ktDJvUeWrzid900pLZO48nvXoLHIIrz28ga1upYTn5WwCR1pMERE0wmgmmE0IYE1GTSk0wmmJm94cmO2eLtw1bTGsjQIlWzabHzu2M/StNjW0VoZsaxogP8ApcP++v8AOmMaLc/6XD/10X+dXLZiW56zRRRXmHUcQW5pC1Ru3zH60wtXZFaGDJC1YPiGykuFW5iAPlKdwz/D1/xrYLUxyGUg8gjGKq1wucATTSasX9o9lctGwOzPyH+8Kpk1nYYpNNALsqjkk4xSE1f0e0a4u1mI/dxHOfU1SVxM6CytvsVosO7cRyTUjGlJqJjW6ViGDGi2P+mQf9dF/nUZNSWn/H5B/wBdF/nTl8LBbnrlFFFeWdR57I37xv8Aephamyt++f8A3qj3V3xWhzvckLUwtUE11DAuZZFQe5rFvPEajK2iZP8Afb/CnsIXxM/y24zzljiudJp89xLPIXlcu59agJqGUKTXQaA/+iSjv5mf0rnCadDdTWz74XKn27046MGdoTUZNY9tr6Nhbldh/vDpWnHNHMuY3Vx6g1unczH1Naf8fkH/AF0X+dQ1Naf8fkH/AF0X+dEvhYLc9coooryjrPLr+5W28+Z/uoSa5C41i8nYnzii/wB1OAK6jxDpWqTQSpDp13IWl6JCx4z16VzP/CO65/0B9Q/8Bn/wrs5lZamFmZ5cs2SST700mtH/AIR7XP8AoD6h/wCAz/4Uh8O67/0B7/8A8Bn/AMKOZdx2ZnE00mtI+HNd/wCgNf8A/gM/+FNPhvXf+gNqH/gM/wDhRdBZmYTTSa1P+Eb13/oDah/4DP8A4Un/AAjWu/8AQG1D/wABn/wp8yFZmZQCVbKkg+3WtP8A4RrXf+gNqH/gM/8AhR/wjWu/9AbUP/AZ/wDCnzILMgh1W8hYHzS4/uv3rqtLnW5ktZk4DOvHpzXOf8I1rv8A0BtQ/wDAZ/8ACuj8O6NqsCxifTLyPbNn54GHHr0pqas9RcruexUUUVwHQf/Z";
		$scope.radioSelect={valor:""};
		var etiquetaFrente  = "";
		$scope.limiteCredito = 0;
		var etiquetaReverso = ""
		
		/** Carga la vista **/
		$scope.cargaVista=function(){
			if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
			$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";
			$scope.titulo = "Coincidencias";
			$scope.showEncabezadoCliente = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.HOMONIMOS.ENCABEZADO CLIENTE.VISIBLE.valor"];
			$scope.encabezadoCliente = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.HOMONIMOS.ENCABEZADO CLIENTE."+$scope.origen+".valor"];
			$scope.showEncabezadoCU = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.HOMONIMOS.ENCABEZADO CU.VISIBLE.valor"];
			$scope.encabezadoCU = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.HOMONIMOS.ENCABEZADO CU."+$scope.origen+".valor"];
			$scope.showAceptar = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.HOMONIMOS.BOTON ACEPTAR.VISIBLE.valor"];
			$scope.aceptar = "     " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.HOMONIMOS.BOTON ACEPTAR.ETIQUETA.valor"];
			
			etiquetaFrente  = generalService.getDatafromCategory("SIMULADOR", "ETIQUETA FRENTE", "VALOR.valor" );
			etiquetaReverso = generalService.getDatafromCategory("SIMULADOR", "ETIQUETA REVERSO", "VALOR.valor" );
		};
		
		var cont=0;
		/**
		 * Lo primero es evaluar los códigos de respuesta obtenidos desde el simulador.
		 * Dependiendo del código es lo que se mostrará en la vista.
		 * Si en alguno de los resultados es candidato para la búsqueda por CU invocamos la siguite función getCU esto al seleccionar algún nombre en la vista
		 **/
		$scope.init = function(){
			$scope.showPage = false;
			
			if( messageData ){
				$scope.jsonHomonimos=generalService.homonimosData;
				switch($scope.jsonHomonimos.codigo){
					case 310:
						$scope.textoEstatus = "SIN COINCIDENCIA";
						$scope.imgEstatus = "condicionado";
						break;
				   case 311:
					   $scope.textoEstatus = "BLOQUEADO";
					   $scope.imgEstatus = "bloqueado";
					   break;
				   case 312:
					   $scope.textoEstatus = "AUTORIZADO";
					   $scope.imgEstatus = "autorizado";
					   break;
				   case 313:
					   $scope.textoEstatus = "EN INVESTIGACIÓN";
					   $scope.imgEstatus = "en_investigacion";
					   break;
				   case 314:
					   $scope.textoEstatus = "RECHAZADO";
					   $scope.imgEstatus = "rechazado";
					   break;
				   case 315:
					   $scope.textoEstatus = "AUTORIZADO";
					   $scope.imgEstatus = "autorizado";
					   break;
				   case 316:
					   $scope.textoEstatus = "SIN LINEA DE CRÉDITO";
					   $scope.imgEstatus = "sol_proceso";
					   break;
				   case 900:
					   $scope.textoEstatus = "BLOQUEADO";
					   $scope.imgEstatus = "sol_proceso";
					   break;
				};
				$scope.cargaVista();
				$scope.getFoto();
				
				$timeout(function(){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$scope.showPage = messageData;
				}, 1);
				
			}
			
	    };
	    
		/**
		 * Es el inicio para la búsqueda del CU se evaluan los códigos de respuesta para accióna realizar.
		 * Para inciar el proceso la solicitud debe de estar con el siguiente estatus autorizado sin liberar, investigación , rechazado, sin credito y homonimo reactivado. 
		 **/
		$scope.getCU = function(persona) {
			$scope.persona = persona;
			if(parseInt($scope.persona.fcempgs) == 0) {
				var opcion = $scope.jsonHomonimos.codigo;
				console.log($scope.jsonHomonimos);

				switch($scope.jsonHomonimos.codigo) {
					/*case HOMONIMOS.noCoincide:
						var nuevo_dialog = ngDialog.open(
							{
								template: 'src/viewsControllers/simulador/fotoModalView.html',
								controller: 'fotoModalController', 
								data:{
									estiloTitulo: 'bgAzul'
								}
							}
						);
						
						$scope.closeThisDialog();
						break;
					case HOMONIMOS.bloqueo:
						var foo = function() {
							var homonimo = persona;
							var cu = homonimo.fipais + "-" + homonimo.ficanal + "-" + homonimo.fisucursal + "-" + homonimo.fifolio;
							console.log(cu);
							console.log(homonimo);
							$scope.fichaBloqueada(/*"1-28-973-12"cu, homonimo);
						};
						$rootScope.message("BLOQUEO", ["Línea de crédito bloqueada"], "Aceptar",null, null, null, foo, null, null);
						break;*/
					case 314:
					case 315:
					case 316:
						$scope.realizarBusqueda(persona, opcion);
						break;
					/*case HOMONIMOS.errorConsulta:
						// Ha ocurrido un error al consultar homónimos.
						$rootScope.message("AVISO", [$scope.jsonHomonimos.descripcion], "Aceptar", "/simuladorOS");
						break;
					case HOMONIMOS.empleado:
						// El cliente está registrado como empleado.
						$rootScope.message("AVISO", [$scope.jsonHomonimos.descripcion], "Aceptar", "/simuladorOS");
						break;
					case HOMONIMOS.previoPP:
						/*
						 * Infórmale a tu cliente que no es posible generar su solicitud de crédito 
						 * en esta sucursal debido a que ya tiene un producto de Presta Prenda 
						 * asociado. La tienda que le corresponde es: {sucursal}. 
						 
						$rootScope.message("AVISO", [$scope.jsonHomonimos.descripcion], "Aceptar", "/simuladorOS");
						break;
					case HOMONIMOS.previoLCR:
						/*
						 * Infórmale a tu cliente que no es posible generar su solicitud de crédito 
						 * en esta sucursal debido a que ya tiene una LCR asociada. 
						 * La tienda que le corresponde es: {sucursal}.
						 
						$rootScope.message("AVISO", [$scope.jsonHomonimos.descripcion], "Aceptar", "/simuladorOS");
						break;
					case HOMONIMOS.waitXtime:
						// Favor de esperar {días} días para iniciar una nueva solicitud.
						$rootScope.message("AVISO", [$scope.jsonHomonimos.descripcion],  "Aceptar", "/simuladorOS");
						break;
					case HOMONIMOS.homonimoSucc:
						/*
						 * Se encontró homónimo con alguna solicitud en proceso. Favor de acudir a
						 * la sucursal {sucursal}.
						 
						$rootScope.message("AVISO", [$scope.jsonHomonimos.descripcion], "Aceptar", "/simuladorOS");
						break;
					case HOMONIMOS.homonimoExtr:
						// Se encontró homónimo con cliente extranjero.
						$rootScope.message("AVISO", [$scope.jsonHomonimos.descripcion], "Aceptar", "/simuladorOS");
						break;*/
					default:
						$rootScope.message("ERROR", ["Flujo incorrecto. Código: " + opcion], "Aceptar", "/simuladorOS");;
				};		
			} else {
				$rootScope.message("Advertencia",["Lo sentimos, no es posible otorgar créditos a empleados."], "Aceptar");
			}	
		};
		
		/** Inicia la busqueda por CU **/
		$scope.realizarBusqueda = function(persona, opcion){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$rootScope.solicitudOSJson.cotizacion.clientes[0].clienteUnico = persona.fipais + "-" + persona.ficanal + "-" + persona.fisucursal + "-" + persona.fifolio;
			$scope.mueveDatos(persona);
			$rootScope.solicitudOSJson.marca = STATUS_SOLICITUD.generada.marca.nuevaOriginacion;
			var jsonEnvio = {
					idSolicitudCliente: $rootScope.solicitudJson.idSolicitud,
					solicitud: JSON.stringify($rootScope.solicitudOSJson),
					opcion: opcion
			};
			
			/** Invoca el servicio para la busqueda por medio del CU 
			* Si la respuesta es de exito valida cada uno de los codigos de la respuesta
			**/
			obligadoSolidarioService.buscarCUOS( jsonEnvio ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var jsonRespuesta = JSON.parse(data.data.respuesta);
						/** Valida la respuesta del servicio **/
						$scope.validaRespuesta( jsonRespuesta );
					}else
						$rootScope.message("ERROR",["Error en la respuesta del servicio para generar la solicitud del homónimo. Por favor, reintente nuevamente."], "Aceptar", "/simuladorOS");
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE;
	           	    $rootScope.message("ERROR",["Ocurrió un error al consumir el servicio de enviar Cliente Unico"], "Aceptar", "/simuladorOS");
				} 
			);
			
		};
	    
	    /** Actualiza el JSON **/
		$scope.mueveDatos = function( setJson )
		{
			$rootScope.solicitudOSJson.cotizacion.clientes[0].nombre=setJson.fcnombre;
			$rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno=setJson.fcapellido_PATERNO;
			$rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno=setJson.fcapellido_MATERNO;
			
			// DATOS HOGAR
			var cont = 0;
			var contCampo = 0;
			var arregloOpcionales = generalService.recorrerOpcionalesPorSeccion( "DATOS HOGAR" );
			for (var a=0; a < arregloOpcionales.length; a++){
				if (arregloOpcionales[a].opcional == false)
					cont++;
			}
			var porcentajeCampo = 0;
			if(cont > 0)
				porcentajeCampo = parseInt(100 / cont);
			$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].calle = (setJson.fccalle==null?"":setJson.fccalle).toString();
			$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].numeroExterior = (setJson.fcnumero_EXTERIOR==null?"":setJson.fcnumero_EXTERIOR).toString();
			$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].numeroInterior = (setJson.fcnumero_INTERIOR==null?"":setJson.fcnumero_INTERIOR).toString();
			$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].cp = (setJson.fccodigo_POSTAL==null?"":setJson.fccodigo_POSTAL).toString();
			if($rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].calle != "")
				contCampo++;
			if($rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].numeroExterior != "")
				contCampo++;
			if(parseInt($rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].cp) > 0)
				contCampo++;
			else
				$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].cp = "";
			if($rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].colonia != "")
				contCampo = contCampo + 3;
			var porcentaje = porcentajeCampo * contCampo;
			$rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].porcentaje = parseInt(porcentaje.toFixed(0));
			
			$rootScope.solicitudOSJson.cotizacion.clientes[0].clienteAlnova = (setJson.fccliente_ALNOVA==null?"":setJson.fccliente_ALNOVA).toString();
			$rootScope.solicitudOSJson.cotizacion.clientes[0].clienteTienda = setJson.fiid_NEGOCIO + "-" + setJson.fiid_TIENDA + "-" + setJson.fiid_CLIENTE + "-" + setJson.fidigito_VERIFICADOR;
			
			// DATOS BASICOS
			var cont = 0;
			var contCampo = 0;
			var arregloOpcionales = generalService.recorrerOpcionalesPorSeccion( "DATOS BASICOS" );
			for (var a=0; a < arregloOpcionales.length; a++){
				if (arregloOpcionales[a].opcional == false)
					cont++;
			}
			var porcentajeCampo = 0;
			if(cont > 0)
				porcentajeCampo = parseInt(100 / cont);
			$rootScope.solicitudOSJson.cotizacion.clientes[0].idEstadoCivil = ( setJson.fiedocivil == null || setJson.fiedocivil == "" ? 0 : parseInt(setJson.fiedocivil) );
			$rootScope.solicitudOSJson.cotizacion.clientes[0].idPuesto = ( setJson.fiocupacion == null || setJson.fiocupacion == "" ? 0 : parseInt(setJson.fiocupacion) );
			if ($rootScope.solicitudOSJson.cotizacion.clientes[0].idEstadoCivil != 0){
				var estadoCivil = generalService.construirCatalogo("CATALOGO ESTADO CIVIL");
				var indexEstadoCivil = estadoCivil.map(function(data){
					return data['id'];
				}).indexOf($rootScope.solicitudOSJson.cotizacion.clientes[0].idEstadoCivil);
				
				if(indexEstadoCivil == -1)
					$rootScope.solicitudOSJson.cotizacion.clientes[0].idEstadoCivil = 0;
				else
					contCampo++;
			}
			if ($rootScope.solicitudOSJson.cotizacion.clientes[0].idPuesto != 0){
				var ocupaciones=generalService.construirCatalogo("CATALOGO OCUPACION");
				var indexOcupaciones = ocupaciones.map(function(data){
					return data['id'];
				}).indexOf($rootScope.solicitudOSJson.cotizacion.clientes[0].idPuesto);
				
				if(indexOcupaciones == -1)
					$rootScope.solicitudOSJson.cotizacion.clientes[0].idPuesto = 0;
				else
					contCampo++;
			}
			if ($rootScope.solicitudOSJson.cotizacion.clientes[0].idLugarNacimiento != 0){
				var estados = generalService.construirCatalogo("CATALOGO ESTADOS");
				var indexEstados = estados.map(function(data){
					return data['id'];
				}).indexOf($rootScope.solicitudOSJson.cotizacion.clientes[0].idLugarNacimiento);
				
				if(indexEstados == -1)
					$rootScope.solicitudOSJson.cotizacion.clientes[0].idLugarNacimiento = 0;
				else
					contCampo++;
			}
			var porcentaje = porcentajeCampo * contCampo;
			$rootScope.solicitudOSJson.cotizacion.clientes[0].porcentaje = parseInt(porcentaje.toFixed(0));
			
		};
		
		$scope.datosUsuario=function(index,fecha,sucursal){
			$scope.jsonHomonimos.data[index].dia = fecha.split('-')[2];
			var meses = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
			var mes = fecha.split('-')[1];
			$scope.jsonHomonimos.data[index].mes = meses[mes - 1]; 
			$scope.jsonHomonimos.data[index].anno = fecha.split('-')[0];
			$scope.jsonHomonimos.data[index].descSucursal = "";
		};
		
		$scope.obtieneFoto = function(indArrayCU){
			if($scope.ind > indArrayCU){
				$scope.jsonHomonimos.data[indArrayCU].fcfoto = "R0lGODlhyADIAPYPAP7+/tjY2Pz8/Pr6+vj4+OTk5Pb29vLy8uDg4PT09MjIyOjo6OLi4sbGxubm5tbW1pKSkurq6t7e3ry8vNDQ0MrKytzc3PDw8NTU1MDAwNra2u7u7sLCwuzs7M7Ozr6+vtLS0oaGhpCQkMzMzMTExLKysrCwsKioqJycnJiYmKCgoJSUlKSkpKKiopaWlqysrKqqqra2tpqamp6enqampq6urrS0tLi4uLq6uoqKioyMjHx8fISEhICAgH5+foiIiI6OjnJycnZ2dnBwcHp6eoKCgnR0dGZmZnh4eP///2xsbGpqagAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUEU/eDQ5Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8eHBhY2tldCBlbmQ9InIiPz4AIfkEBQUADwAsAAAAAMgAyAAAB/+ASYKDhIWGh4iJiouMjY6PkJGSk5SVlpeYmZqbnJ2en6ChoqOkpaanqKmqq6ytrq+wsbKztLW2t7i5uru8vb6/wMHCw8TFxsfIycrLzM3Oz9DR0tPU1dbX2Nna29zd3t/g4eLj5OXm5+jp6uvs7e7v8PHy8/T19vf4+fr7/P3+/wADChxIsKDBgwgTKswFoKHDhxAjSpxIsaLFixgxgsvIseNDARciRLggwKPJjBtPqpyYwEKAlwEsJFhJE2LKmjQFuIT50kJJnDRvAj15gSfPC0NXCk3aMYJRmB2YnlwqFaPTpwEiVPVIdaWBDRsINMWateMAsGKHdjU5oABPrRn/rz6Fa5WngwFA15rdeTQuWboWixq1kDboN5wOsPqsixUwxQF87eLUyzHyW8ZzMQ+efLimZZgaClOUa9SxRAIayFrg7A0x2QAFLpK+bNEtWQesu+FE/XpmxdkwTUM88Dp0bm5AF7yW8HMi8JfCHQqQ8Do61841B6Qmu+H334obXlvAe3zb0PBkNTSP+LzsRMivu+fFXlMAgtcLRn+fmJgsgqSUeURceqI91F50CbwWgG/ztZaUbVgx4Nx+EAnAwGu4AUjfbtthdYBEB0okGFYakKfWhji1FwBz7FEoHXUuNqgbU/CRFRVEIeIo3noyIjeRAAds8GFH6JFoYkM5OsQb/1lIcTSAAwhEwONDaxEAY0xNYmQhhjo2BlF/ETrJAAcTlNnAkBGtdSVMDDBo0YBkGWCgiwm+JudFAnRQQZl8TtDAlAB01QGGR1IE5lMSOjSiUVkCcOFtGB0AQp+USiBRV2s+pcGNFS2JFYM6PbVYQ3UaaRFqH1BK6Z9poghAh8uhOSF3DxkQmQV3NlTkU/K95wAJqqqawZRd3acgm7lGFCpWjQIAkkgkQbQoT5b+uMEIwQarALGuTqugBgsACoC3AajXkQCwwiTrQwlgkG22BXDrYESDHsuTBhsACuFLGqwbabqxRTSABBm8G+yoNrnakAGP2vuSBP4KACYDBXJEQP/DDvAocQMGq+pBs1Qq3BBImR5bQMUCGFDoSQMkMOUFHnRMKQnhVhSgsxGk+62UW0k0QAAy9/mBBCu3Ou+ph9qbaM/SYRt0mRi4abPIEiXQsL29Ms3A0xNUkPVFN1e4wWdYZcg0ABQEzUG81x3tZM4mn91Q2gZ/UOJUVCOt4NdbSWAwBf5yFHZFBxg7mLhMEUCmqgpwqtLgFQkw9r1SMx0BpRwwgLjgeb8tgQUFJCs3ABt4wEEDxvVo3uisVwV567CD3XnstFv0eu0nCUBAArz37vvvvhNwZEoGFKCzw/yejLtDEcCQQwjQRy/99NTnAANcGxlwPPL3Vtx6BEBQL/7/+NLrgNtG+3JPVsC1w0D+++OfIMBG26sPGu4CPA///tHnMMBG9rMX7gjAvwJC73+HqV8ANTBA/Rnwff5DXwBfw77YCcB9D3zfCRDYGk9NECbjWR74Mjg+IGQsJW1R4LE0UICiwW4BziNh/05wl0ChSAA4zKEOd6jD5UlEAAMIohCHSMQiCvEnt/Nh7ZKoxNgxsYmte6KyImABDbQpdgyzgAR4pjpt4ERysOpX6w4QxnyVx4s0SUDJYrK5oSzLKAgIXEekSID0GYVvVdnVU5T3uNlNUYUV7JkdjaKBCLjQdn58yOTsZTamDVJUZpxjIgGQAMPZC2R55N4VOee2xyTt/1hLk9vVGOm9S3VOAHBDXiFhh0oV3ouLU+uktMiGoYq17JBOMsCU6qg+C0SLInphmPriqKyJlfIiwnxJIx2iRvUxQHQhkyUAVKSYSEJklGL0yAXStcyRbcCVPHFcNGcEET1+awEuJJe5OIIuZv1oAeB8CSaLhbxnUuSNRlnXs0bCI3KtCHEXq6cpZelKCWByTrRyiK14QhhFVicwayTkQMn5kIjyqwNt1I6dpPMZhJVKU8d0SAcU+B+jUVSktcTIJ9n0EH82apSSuciT4jNRH0WkZJu8yEefkqwkUVJBlZtIMqkFqCpdyZcdsaRRlulTAKz0JZrjyAX4IoFSUiZIB/9oYzmLU6CmajShUhUS4qT4I1oGQJzTjBEA6qUYXOJNmitREYu6lJmbPpQpZI2IBxkFIrUCAE4gxeskL/LIAIQSoXWNCExh0k3DwNUkO70XNJHkVwAYQEFyfOtJVzId/OjHSxNRjn+0ipLBUsScIDxkUz9SPzxq1qY5aa13QDsR1PbEraV9LEdEixUEbG61H7GodSSpW4zslSeZpSxtJwJYQoY0t5s1yVNhI5vKPqSwjW1bdD1Cy9TNNrEUOW5PzpgNnNByuMyzLmI3U5O8OlUxpAWussiWXeJudy9POWiLlgseUeFWdsXFyEwvyhH59pWx/wXwfU1CALAkWLngvUh8g8OioQCfzcBRNK1UMMw699bEpU30cE46StqziTiNt5os7U5Mk7NAq8RyW4iMZ0zjGtv4xjjOsY53zOMe+/jHQA6ykIdM5CIb+chITrKSl8zkJjv5yVCOspSnTOUqW/nKWM6ylrfM5S57+ctgDrOYx0zmMpv5zGhOc0ACAQAh+QQFBQANACw8ADIAXABlAAAH/4ANgoOEhYaHiIYSiYyNjo+QkZKTlJWWl5iZmpucnZ6foKGio6SRBaWEi6iRqqULAbCxAa2rtbaXEgC6u7y9vr/AtLeMwsPGx8jJysvMzc7PnQvQ09TV1tfYtcXZ3JwCBxsHAN2aAhsSsRIE5JYACQyysNuG0tALwL0EDvGyG87zlQRE0MBPVq5jADEJuICuoCwN40w1SkjKHTyH8RhEZHdowCuM/C5s5DjInAWQ8TREGBnq1KUCseoRAnCgIcpYBdaRJEQA5s104naWHPgTloYNLEkCuFh0wQChhTYUDcAgQSabIAvg28rVl0+UFkRCPfTVoUoBn1wmk4rRwdOxif8EYI2FwCrcRgcIxrKAdBjFUAYKWJAQ4e3dw4gTK24wgIDjx5AjQx6AdueGDDBoaN7MubNnGBn8sdvwwrPp05xfdGCXAbXr0x/YZX5NezOMytkG1N6tmdyAE7xpw2Ad/HUG3NlIFz+tmuNl4Ms1g169U8CA69iza99OebH37xwlaFBbS0OKHTxKbEAOvgGIIEPiDyHy4QCyv5su7JDP/wcInd/hwN+AQ8jAgGGJCSADgQMKUcN6m8zlkFZdVYiPggwSuAMHdiHGQYYM6vAAgKZMFQCFFqboCwEQgMjgDAUgCFUCJgjhYoM2rMeVhFkZI0ABC97IXw8KdFgKeZQgWci1ACCEICR/EEjAHidKUvkLARkQ8WR8QdgwZXUbwADflgpMUmUqyAjAwApb6vAlKljh9wgBHvAgJBEyriKhnI8kgIONIOaQZyEyNXLmMQK1MCaBE7THmAQiEBgCiWhyUqgkl1pCgAI9yBfCod4l4MEHFCTwJiV8KnPdqY62ugyokpQVD6yu1mrrrbjmChWtuiaTi4rA6pKqNsEG+1E8w36SaSjJktKsJbz2Ku201FaLyLOHYTtKIAAh+QQFBQAXACw/ADgAWQBZAAAG/8CLcEgsGo/IpPLoWDqf0Kh0SkU2q9isdsvter/gsHhMLpvP6LR6zW67sde3fE6v2+/4vH7P7/v9cXiBf4SFawyGiVyDio1IiFkMAZOMVZCOmJmOlZp2DgCgoaKjpKWmnJ17qKmsra5el6+ys7SEAAIDubq7vLsCAI4JDwoNxcbHyMkVAQmJCRXJ0dLHFQeGD9PZ0g/AfwDE2uHGFYUC4ufFAoQC4OjZFere2O7ZD4bP9NLV3YTC7fkVHhyIZ+iWgIMIEypceJBfrYcQ68RKU6BGihkkrEW8YAGCiI8iUowwAPGADJAoWVgYUKsCypciSiwg2AqACZgvV3DQeOaTqb6fQE2VwAlTBgUCrigQxUkDwYCgohxMmkq16iQGULNCHQBjKc4YEWhiMsBhhdeXLhoccJhlFRkAEYaeRTnjAVIzE6fkJSJAQou5KGG4pbK3C6cRKQCDbMDWEYADEzwqtvek8B0HLxSfeDUgwIy5KcSmIqAg8VIWooUMVp0HwIYYkmGOeCigwAmYLcysZtJlwAMUIFVE2CiEQIARGu4SF3JwuXM5lvVanbr7ufXr2LNrJ1N9u/dO3dWE/w5lfKEgACH5BAUFABEALDcAMgBhAGYAAAb/QIBwSCwaj8iiIcJkWpbNqHRKrVqv2Kx2y+16v+CweEyudsrotLp5XrvfZrg8Tm5/C3Os5W3/7vNcf2J9gIWDYxZJiouLgmuEXo6GcpCTllqVl5p0m5RgHYqZnVGiYaVXF6Nwp6qXoEdQrZassoa0tYC3bLhNkqZGum7BTKllw7xRCMZcylwXvswGjEIJXB0B2NnYx1rNtd7MedxlsVXQh6O651nja3hX61TtVOVY4Mj4+VvD81TVV+/CBEwzUN+VerMMolPIUAoCbRAjXphGMUmxLQjFPIvIsUDFj0UKNmzVL0sBjtlegQRZEs0/VfFG5rk4KqYckTJz6tzJsycW/wACggodSnQoAJ9UCBTQgLKpNg0FCCBlQoCp06vZNEhFehKr1wA4c1r9elXD0Z4AyH49yxPAWLUozXKF69Qj0qp0OVrYendpXmxQCbCdutLI1MOIExuyAFVa4ccdFMTA8UCaYi8OSpjYbCKGhgG4bKIhEIOz6Q8OcKl8PC2A6dcmFNC8TEUB7NclMDhmfWQjVo+8p1W4DfuGhQHBh2RsZYH47QwLBJDp+hV48kUCODi/XWG2NYYDMGjebtpG5Uhqwy7vIqADggNGLtgmbxoHAtBZ7mV5WSVsFgEIoLDDgDAg5MAE9JnGASiF+MeFABT4MOCELSBXxAAalJbgZg8g4f9dKxf0MOGIHggACwjjJcjAGA5GIBopVIww4og5TORhAxtmMNgjTc1mgTaScDDjiDiYiIQABeBAXwy1/AiRIxYMOWEPDiwyQAA2bPfBTWoM4IKUA54g2CIGeJDiaxp0sRuZ1qC0mgRgDpgmJtq9NgF+esxxDUerCQBDnC6sqQiASm42gY1JJLABf1p8aMWeEa0GQAcigqmAkdMMsFQByMHxIhOQQiSpAB/EGcIGYOyYjptGGKBDnDHg2VOo2kgqBAhx+tBiLdYVQWtKRwwgIJgt8MXTr9sgwUCcO2CAFLIB2CqEACbECUEC10FmCqse8hAnB9LlI+0Q0I4LlJBghtCGkivcIkGACHGaEC4v2IbSLhIPMNtrtovsekW52LUQ5wnzygTwIg5IKGUO/FL0qTz3HmkDmDkUXNM+EXsYgpQ1WFzIw1IczEgFQ+awgccNbssnRQPgMCINHaBsiaOPZpyEpiSQwGnDPCch8jQCDIBpz0QTUS5tSH+cdBgGgLx0Exd0sC4aQQAAIfkEBQUADAAsOgAyAFgAZgAAB/+AAIKDhIWGh4iCCQyMjYuNkJGSk5SVlpeYmZqbnJ2en6ChopARo6anpqWoq6yRqq2wDK+hs7G2oLW3nQuxubq/mL7Aw5PCxMeMxsjEysvAzc660NG209SwEYm8172Ij9zY4MjW4qfkyeW4hufpmuztn++tCYmFB5sRAfr7+vKt2+0AwoP0bZg/TgcH9mJVUCErgQ6p+bs3DGJEUw3DXdzIzSLHUBk/ipQ4ciDFkihTqlzJsqXLlzBjypxJs6bNmzhz6tzJs2dJevWCCjV0wAKGAA4G5LwAomlTDBEE2BzwwKnVABekzlxgtSsICfRkSvDqtYBSmGPJdn0QdSihkNz/IqglG+AAgJYANMwli8DA3UoJfwkosNcrhgVnbcHtdGABUEIG0hZ2+qCDVlAnsdmQIQPFhwGGLgSYbFXDYmp5UXBefUPAoQgYSDt1AC+BitW4NSAaQFg2iA7HBFzI8OIFB7uEAuDGfeKxoQQWZAdIlUlAgCBHsh8xYoEQiOW4K1gCIHoyhr+/LmDXnt3I4wLgV6voEFTAgthzAwDgt8+jKA7ssUfCIAKYEB9nnwk1AAJz+eJcPadFUkOA2tVAyAIHclaAWwno1ZV+tixQyAsUZvdCJB9kWAMBbgGwQVVNBeAXAAdskBksJJb4gj0zZIgBJ8JFkBUyOVK4YyEjZMgC3XItCrJMkQEeSQgBJ2SowGURQcmelIRYkOEMgQGjpXYnTrLZgTck5tCYJiISgWoHSrARm0eUOUkGGb5gwEV0cmlPCxmCwGeJddbz3YEtXJAloX4WMsALGXJADZOI9BkUAhmiEGYsfWJyQ4YfoNeOpUF1ACd4NKzJaCYNHHhCk036pwmpQSXAQnwZqKqjW8otR4NdCtFanwKnTgBssIy2KABsILQF67PQCtIpkB/RaWG02GbrVgaEDqjtt+AWcoERFBpBabjoYksVudoZoVu68GIrgAEdfFBcBlnFK1QgACH5BAUFACIALDcAMgBaAGYAAAb/QIBwSCwaj8iiQcRsLpvQqHRKrVqv2Kx2y+16v+CweEwum8/otHrNbrvfcLIjTq/b7/i8fs/v++8baoF9g36Ff2ZziHFPi46PYAeQk5SLh1qXcZKVhFwGSUUJnF2KcJtYpWGZao2jkKtQp32yWLRarbVmtnSprmOwbKJxvWi7fLi+hsllxGgboNDRQ8BTyJjLTcbYk8/S3kjUwdvjWeHk5+jp6uvs7e7v8PHy8/T19vf4+fpun9/+SAYKWJAQQYC9AxoCKAygwRw6ARYWSkRwAACgfxgBbJDIMUABAvAKdOSoIQIZh3REjuRoAaUUa3w2ruyIQJg6BjNHflwXIWFO/4klDb6ByQWAgQ0DjBBQ+XOhhQtlbKYBcMHDhKsYBBhJIKGpRAZE+zi4SnYChSkCNvj0GqCDRkcEPpQl6wCJgAVrm2prc8DDhw8U+g0pMJcsCQJJCOD0ikDL3ivdhDCAEKJyCAgFiCAoTNYCtANdf2qwk4Cy5coQEAvZwPnqh4rQOuSlaaWZGAqnT4OAUqH1hKxZHMwEJhha2CgZclvOQIS1b7fSDCDoKEEom7pEPiiv/KEIBt8Vkno7EFGhBNVCEmyQWo6L9u0TlMhtndnfgQ2P2bxXHr+IBN8cgOTLfrn1R8QAJPg22iOwFUHgaQYSsYBvE+T3x4OWRTiEAFa1RrWBdZVgWJmGQxxAoUmjiBgCiUM84JsC6GXkj0tRqMiiEARk4BsCFsUEio2gbNYaB8f1AWQSAjTgWwA95pEANEcmEQGFFuoRZRIU+IZBiNutGI2JQ3IJnzQBtEaCjN7YpsWViXHA2QNN0tEglF3eaARhcxEpJn9baFAWCEU604WNXBzAAAJQpVjnP1qh6ShGKnb36KSUHuFBlxRUqqmmB5h2GgSBniOBp5cVUA8BF4xwlQfsxREEACH5BAUFAA0ALEYAdgA6ACIAAAf/gA2Cg4SEAhsBCwQAjI2Oj5CMAwYChZaXmAczQ5wrDJGgjwYFAaUOAJiplgMunK5GFKGhBxqltgWoqroKrr1ICbKQArW2tge6qgk9vb0johoUFBYDjwfFxRICwaACJcy9HI4RNTTlNDUdjojXthHbkQtG364WjQTk5uU11IwG7LYaFr1rNEDFPE4i+AGwkC+fBEcM/pka2CjAwSFBNDgC0dAcCEf+JAYANnBAjossBDKi0LFcLEcORCLQ9o7DRSSnHLFs+ZIgsX8b3l3YcfGGwpUtafRs1EHktGACalzkcQHSzo5LG0kQ6U5WAXkHPdDUmTQrI2sSA4YaIOOiCwOR7K42NMuIlERcoEBcDPIwbllQISWSfETgx8UTKh/JzUeX0QKZYxkJ+HBxR1e/PEMNExlUHZGLHyIr/htq3b+nkk9c/HFA1mJzFHRtlXgZQZCLH12TDpVApFoBKC7KSIwZ6za7/04RIDrPCIJtr11uI/DzWj0CPg7ug75bVgSJFgQQYDHPR1XumbcJsJAcwIAF2ZkpEA0qutKBpm2hFrAgOKcgN9BXX3fBfGeLA0e5hwAHHFz2jn2NgULABhsQ54gAAuqWHkUcUgRhhyC+o0FS9YRoImD45FODhSeeKIADKZ7jYIs0utdbNBrAVWMgACH5BAUFABUALDcAMgBgAGYAAAb/wIpwSCwaj8ikUKJsOp/QqHRKrVqv2Kx2y+16v+CweEwum6/MMzStTrLb8HhVAqjb7/i8fn9/y5F+f4KDhIVPCIaGHWCLiUSNjpGSk5SVlpeYmWKBmkqQnaCGnF8HoYihYh15p4OjYqytVp9/DE2uqLi5jIMIpUq1V8BdwrrFjrPGycoVt8vOx3zR0nnIcr6xz8/NYsTZ3t/g4eLj5OXm5+jpw+rsTt3t8PHyZhIa72b38tVkCAH+/wG2mVM1rWC0ffPUCIy0MCGYfA51NUxyAEGHAY4mSjmQJ4ENESBfLAjmBFYiAS9AqlyhId0DlTBdGHgGsQIBFDBhBsAzwAEC/wQRBDgD0CAnTAp3DoxowLTBiGvGNqwwqrKAnQFLmzIdIdSYgI9URZwQYGeBVq0R2iC8giCsCAgM7jA427SmF5NE+vnTyMLtjQF3ENBlireLhH+FiRzYAPUJBbcuCNoRPDhxl7VYEuAMq4Bs4MENLGfi4FYFRzyU6Yq+FGFq2J2rQK+uJMCE2xoE9KQ+i2CPXUIS3EKwqlt2lcZxWridALh4ZVQAPLhNsYHPbq2zJR1I4XaEkutNs0ea4LaFgWjgCTcRf8YBBLd00MuWhnwQWKolmls33mkAd6orLDBNeqFhEZ9BCO4xwGZGceCZfM+hkeCEeQxwA1UonCYNgewVIlJABwyq9IBBHKIhxwb3QaAAgiWiIoADFFBQHYv84UIhABzeqOOOPH5WWY9ABmmQWYNFIOSRSPKUlVZcJekkkhcs6ZSGT1bJowAE+ISAA/pZOU0QACH5BAUFAAsALDUAMgBiAGYAAAf/gAuCg4SFhoeIiYQWio2Oj5CRkpOUlZaXmJmam4YdnJ+gm56hpKWdpqiHo5irqaGMoa2TsK6QtJaytbqVuZIWAMDBwsPExcbEt5+9kcm7pcvO0YrQ0pwSuNXZjtTa2dyJF93P4uSE3+W65+iuHcXh67vqg/K7zbzE9OXvmfT78Jz5Il2wVypBpA4BEipMGNDStX+F/Gl72I0gNkUUx9kyJdFUgUYWFi7suGAZSV0nKaWEyLJaQ4wGFX28NPNTTUcrW6Z6qbOnT00XjgkdSixnqoE/DRlNyo+pU0cxKz6VttSVxVQ3p2rdyrWr169gw4odS7as2bO6sqJdG0ot27dw/7cKmCuAqN27ePPqLVoiB48ZFgREcyuNAAkeOxLv8IFBcNwFAh6IUEz5R1S2Ahy0oMx5Bwm4B2z46My5BdsBCn6Q7sxinYWqjwRoWLGadIW9e2FvEhCBRm3SKMwmuNHjN2cfMQj0zDdghGrjlFsUqCvMQIQDjstdJSQAQQrolEU8IDCMQAUT6EnoLkSYUEZNBGKAV8yDxOVBDdDrL1Egd7UBDcyXmAkdUDcMAvolGMMAm6wHDjECEDAZeDMgMIAxA9yQYIL9CSPABRF00JGDmxBQnHFAgGCAUA9smKAE1YWkkAXKPdKOUCQKMgAQvxXxAXZCJWCDi/rdCIAAMi60nf8uAnxQGwwRZJfICESixwEhF4ikUI6gEMAjZynQaFcEVZpQgpEAIKRlADxN8l4hDny5Qw4jrGhXk2WOYGCaa7LJUZJvGjLAAw2Ml5cEZcZwwDBqatmPXlxCQoCGVQbQSZ9tkgMABmXiQB6jmHp1QQlldgjqmpmKo0CZDVyID6bGtLeOA2WeaUyjIjWUAG68YvhBmRTsKQyuC6WajQaJ7nprqFoZEEOZGghFrELGRgMABWV+8OmyqDYSqDijlunAUNMyNNR9mp5XpQLbMOuUAM8SWUJQ5LpbyZKkUOoiBjbaS8kvveImAJUu3rCttP4mNZyLCNxVLpt3ZSkSvqQAkIA/umYGgNfDaJL7z0ASKOtwwm9xHPDJKONmcsost3yMxFrS6/LMMyOpJcVlGZBkABbYSfPPLg9wQQciCgv0UIEAACH5BAUFABQALDAANQBnAGMAAAf/gACCg4SFhoeIiYIRFI2Oj5CRkpOUlZaXmJmRjJqdnp+UBqCboKKjp5qcqKqora6vkKyws7SesrW4uZK3ur25EYqCpr7En7zFs8O0x8jFCKPMzdKd0dPWltXX2qTb0sqY2d3d4eKa36vl6bu26sTAheTtv4Xn8tLx9pUHqQH9/v34UD3L16yep4EEoVlCWCxgwnQOH0qcSJFCRE0I9lkyECyRwVYfa4XUNfJXRW0lT6pcybJlu4ujUrp8pXGmzZs4c+rcybOWgAEEDAgdSrSoUQMEBgjgKcCABiBLjkidSrWq1SUiGOIcoEGJ1a9gqSphoBMpkLBowUIYUDZq2rdT/5XInGgArl2pcyUScHsXrZKlOQeI6JsWwk4BCLwS/jrEQVlBBSAoXnxECQTHOTkSGmDgwIXPoEOLvnDggAEBHVOrXs26tevXsGPLnk27tu3aAlDf3s1bdYIGNFrYKACgJ6gBIFrIWC4DBYLixjHCYE6dRV6eHW5Q3y4DRDrNvQ8ZaDCD+/Yb0SkJeMDCPHcc6SUVqOHefID4jgBcmFDfvA38jRAwQnn9UTeDAmw9BFMjAdBQ4Hm3DHAAAdDdtEAJD1L3AgIDFIIYCCBacN1BvQxQAQoZLtcCCOARYgGIMIJwgUsCYJBicxzMKEkHMcKIAWAqATDACynagJkk6/UIo/+O3LwyYiUDENgfDBZQmIgDSsLYwUaZLOjJdPWp4EECwRiAQZYgJtASAB64h8IHG1wCAAJogqBBhSsNACZ1JhTQYUcH1AnCAYRE8M8/XmKkSQd7nhCAlakFUOdzhR7qT6KYaJUpBhyyFkGdGLQIgKGWBoBpO0miuYAhpFp6qjoF1BmAbpWW+mo5Bgh6wSGtHuqQqOG9JkGdFtBaq6s7XSAombyWaioohAYLm6RoEodIr4jq9CmaGEDKqrO3ajPAmWi+cy24OcWKZgB/nmvrQnTpGgy2lwZTkyTASosInWgiYGyz79oEALlZ5gsPuB09iUyqSlo7L7oC89vjA+0qQi87QDcBYMADSm6g2sXP4kSAxCCs+jHCHz+kcQQdeNsRyOamZsAGGxisb3gw36yzbDAD6PPPQBsXQbinBAIAIfkEBQUADwAsMAAyAGcAZgAAB/+AAIKDhIWGh4iJgwkPjY6MjpGSk5SVlpeYmZqbnJ2en6ChoqOkpaanqKmqq6cErJuur7Kzjg60t7i5uru8vb6/lbHAw8ShwsXImhLJzI0bq8/NldHF1NLX2A/Ho5DZ3tLbqwff5OXmntab6a2X4+QMu/Cc66MM3eeTDAH7/MvF8pgOEAJo7NIGRYP8ybpXTCE+gwF7EezkblPFTgwvMUAo6OIojw9DYqIHzGElBgQ4IiIwsRRKUCAzhUuVUZtIaQdVcpx5k5U+fkCD7sups2ghkpVqnkIqyYHRp4NsaYrZUyQBB0KBEoValGnVrw+9guXUcqzZs2h1ARAwoK3bt3D/47oVAOAsgAEFTuQIwbev37+Ac5yQCowwKQEFdABezNivjghjCQw40bgy4xN0uWqOmmrAXsug++bg+XBA6NN8B4z1jBq0DrMCKLeuDGPsxgVAZjMG0iGyoAgwPusOoQNG768vJRFIwLy58+fNDZBOS7062M3Ys2tHSCAAiQwexKoqO0wAggwT0qeH/Eu8LAARGqifz0G1dUsADlCYz38Cgu0IeZUSgDsF8EF//FFwHyUMcIBgfyAw494nAHRQwYMIFkBgIhtk5SF53ICAIYIeYGPYKANocOCI/GkgwH0COEACiwkKNEkC9lUFwAYX0qieAhG82BQ/yYECoiMmpSKA/wY+qpcBAgMW8hM/Ggj0FEgn3sJAk+kFYAAiF2SlwSlUfWKlIgLI52N4QlJigYdlglTmJdNJshFCAqw4IgkOZIZIBB4GICCZp6Q54gcSRIlIioEagBEyEmCIQQIqYfXhVLq4p+Z8I2zgpyIJBOrlJ0p9MmU/nBywKZ+fIoRAoFm6RFEkSWIiQAQMBGlUhx5qUGcoW6l0wISmvOnhcQtWAqiHtSbbCAEaBDqnKYpumF0BgW5kyqlBOWWtdqH26qizkwggQaALkEsJr1lZkKO6jSwZKLFoLRAoAm2m0mwy0ErrS7XfcmRpVhrCK4mxQvk6y6+/AIBwUOwZHMnAQFmQry3EDwzw8D7TokKvLgMMrAGyGE9CwAYbvJvLyRswXPLLMDfSccwwl0rzAx/PEggAIfkEBQUADQAsMAAyAGcAZQAAB/+ADYKDhIWGh4iJiRKKjY6PkJGSk5SVlpeYmZqbnJ2en6ChoqOkpaaVBaePjKqrrYkLAbKzAayvt7iaEgC8vb6/wMHCw7y2uYjGx8rLzM3Oz9DR0tPUhgvV2Nna25IX3N+dAgMDlMngjgIHHjgeCdrepgw8Q/Q+CgTniuaPCfP0/0AskMvHCce/g0OCtIggwBQ8R9dMDQiBEKGQG+5G7Vs2QEjFijw84Nu0UdPDTAJ0fPy4gkFDZLRonXQ085iClR+DnNggIFhNVRE9CYgRBGdFIh9GEowkQAIEoxV/gBiIKNWlArOCYrI6KYGCIlARyijwcukjARtseAxLz0iNjGb/Hw0ooILtPwhKoWndRCCASrsc4nbl4IMtip7EEisGwLXRhcWQhaGtYQTqYcGUBjCQYXQCZksEQPz46OPAqZLLDmTYcdAIhs8oN5QI4UMG6lCNYevezbuVuHHAgwsfPqDs7ggfTtBYzry58+cnMmxglhtTBBjPs2tvDmP6ZwEftovXnuFY9UzKx6tnDoOq4PXwl8MWkD6+eBgAYGewPz4w5gIAbIAdf9m98JNZF3AwIIE0wMDBgeBUJw4BFFZo4YUWDhDZhhx26OGHIIYo4ogklmjiiSimqCKIAkQggQYFwKXKecxsoAEtGpjWWyQJSBCTLBIYtyMiBGD14yzeDXlI9Is3HjkLjTsG6KOTtEB5y22ZJIAAlT9CqNtcXP5opTJjMhVBk2HKokEE+Q0JwAVTpilLAXlVgyUiBjAg5ywIHNBmVVstA0AEe8piAU/BlPlITYp2EmChGizgXitedrPYlnIWYMCfhtxZSE2VngIAmlRK8BgncdbSSaiQAJDqjxp0ICQmr6oqTQdULkDAYo0mwuorrv7IQAKcKpkIAXGaWqwle0XSrCVwXgLAARvoyNuvnXhq7LanYMvtIL02YuSR4X5r7rnopqvuuuaxS9AuK0KmbSvwxqtYLD/OC8qzV3apjL6jlOvuwAQX/Iy3OwJsrsKkBAIAIfkEBQUAGgAsMAA4AGcAWQAABv9AjXBILBqPyKRyuXQwn9CodEqtWpHOq3bL7Xq/4LB4TC6bz+i0es1uu9/w+Dorr9vv+Lx+zzcKBH1xCQEjAQSBbREqIowoGAOIaQSLjJUnBYCRZRWVnSIQMRcAeXRmAi2eni4Kh5pgAi6pqTMBkK5eNLKyL6W3Vw+6shATB6OkYgANwbIpI75bDi/LqS0WmUgMWgwB3L1W2VQEDzPTniYRxs9TAAcNseWMKxmt6lMCETHwlTC2et5bAxDk0keh3hUCFGTAKwGgocOHECNKnPgPzoEMK6YxNKhFwIISy5xxBGiBhSwUCUZ2MTBCYaUVElR6YUdChYwSFcuAk8mzp0/MPQD+CB1KtOjQdD4FHHigoIHTp1CjSlXw4ECdnOsOVJDKtSvUCil9PvBKtuuDiWjTqo2IlYqApmXjPq1wTaUAuXid1lUJNy/ZCj4BjPVLNkBPBgASbCXMtYKBnxoG9WVcIcBjmTuHBB3AubPnz53/QB5NurTpMZnVpD7NurXr15rawp5dxAG327hzc1t9Rzbtq7+78I4y3GBxaMExJ1/OXIxvDc+bS38Svfb069izay9yXMo23d22ix9Pvrx5PtXPqzedPk379V7eIwoCACH5BAUFABAALDAAMgBnAGYAAAb/QIBwSCwaj8jk0ABpNi1Mp3RKrVqv2Kx2y+16v+CweEwum5uds3o9FQwE545yTq/b6QMEh1MYmNNsgVoCHS07hzs3fmSAYAWCYIQ/iIgjZY1gFpBeAjCUiCEHjJukUgKTn4cxcGKYmXewsKipPgtjrl8WsbtznamILaxguKWCBb+ID63FxQMmyDsiBGHEzGwdPNAc1ErV1l0CHNA8F8NiF7zpdAki0CbCXN7fag/QPo9eckdR82UEhshQLIrXr1QBH9Aw5CtIakAMaDr4aZFXRZ+6O2E2hID2AR4Wi0MoMgNAoECAPncEKIDWQyQahlouTDBB8wYCAXYMrIAGw6MV/5dNEHi5oAnMgJk0k3IAGgDaDglEOgSYSnUq0C9CxQRIytVEiREJ6BA4AS3FQC5ZN7lE2jWpjQAD5jjoAa3oFbtxztho23ZCAZxIBtyA1mAK3oXWAHzgy5fEhiQXciDzUJGNxCwI6iBgzLcEBQNHBHj4xSMBTDNbObeNoSFukQEqPvnA4HPNVTSwOnBQ3dcBFQOeDqn4KwbfGuNe8uDg3VUBuiIHGFyo/eXyaQMP9jKnWQLD2dNXbmO5MGK7UurgIQmIsNu8rot1ynUBDT+whBvbK9Sngzw9AAMYlMCbAuk5IV4ZFyigmgb7zXGgNQ6wxdUN0zBzWIFODGBBDFyV4P/bac81eBF2E9ygwINk9Ifhiiy26OKLpNQHYxn/FaBBVTjmmKMGBVQInopjGHCjjkQWqYGPM3YBgElFNqljASLGAuQYAAzp5JVTMZikFwBg6eVUAGyppJVfGimmF0yWWeSUZ04BJQFkqlmVBd+1icUANspJFY912ikFkAAIIOighBZKaJh+Jqrooow2qoYFPFpXDJuOCoKihZWWAlKUUWXqaUwWYElpPxbIB4mk6V3wZVpspCnqjKMi9ulLZYT65ZSonnZhF6xuYRoWsQI7KwTBhlHsGqYO28+ou34EU6+aFpksBLZO1WxlykpRLVV45brosRheCgF9dHg7hVQ6gmSgLq9rXPsHkVdBm4W7WiSwwa9dTJsFujnepu9EpOYDb7Zf8IujuJ4aXBXCdkJ5hMJUbTqEqziCKybEVoWBb6YYB8BwuK0MTLAUEkcl8shbdPxxkmF1A+8cG8No8bkno7xvza9wGgu9N6dLBs8wAQ2Byp4KXdHL8eVo9KQhp3vHyqT8+xHONv+EtM5Y60x01VyTsnTXThjwNdhNXNAB1GUEAQAh+QQFBQAKACw2ADEAWgBnAAAH/4AAgoOEhYaHiIYCFx8vLx8dBgKJlJWWl5iWAUFHnUdGAQOZo6SlmBecnp1CF6aur64ZqqocsLa3lS+znjUKvr/AwcLDxMXGwwLHwjC7nTW40IgCCxQgEZOYJ81Hvcre3+C+ABc3MuYoFdiW2s3d4e/wv+M05vUyAdnb7vH84B/29VgkuMRu175+CIsBoAfQXANvBWcdTEgxGMOGMzqs01exYzAA/xqau6EsoqqJHilGQCHSHIJKJnmlnCmAQ0sZMEQliuls5swDLW6CoMSTm8+ZFG62GIioKMqj/Qy8uMmhmNNEC6DCk3ATRYSm+hAl0ApvQLmWJYg5JesxwoybFv8OrWVbUUCDmycIGJoL7mu0UQdY3PSwN2yhCGwXRdiQDByGmypaEeJL15eBACAyP9CIiUCNmx+CMWtX+ZcAzJlTa2BqCUHXBYR0NTNR2leE1LgzI9BJacCEmyXUcdj20FvWhABQ506NYYE6RB1U3CwwKEEqVULGdkRsDACG5csDSJZW4SYGQhauHxFioXFp5eBxW2BtKMGJlhoKJSBR4wWHC+71o903G8QXXwG8FRKASC0YwNZx4SxgIHgY+FWIAGfVM4MEANSmjIUJaDBheOMNQsAHLMlwA3cJQUjTBg+MmJsEBtQXwYAI4QjVAA58J2NqBQToYUcAGIDAj6p1OKT6Mi4qA8ABIiLJ4pLE0JeJAB3EKKMEVO5YwJZdBjMlQkVKMOGYYaa0CHypPSBkmjRF4GNqF8BJF48BPCCBjnb26eefgAYq6KCEFmrooYgmquiijDbq6KOQRirppJRWOiSflmaq6aacdnoopp6GSgyakpLqE6iipqrqqkeZqqirbXWKamVNpmplIrOKGcCuvO5qIQC5GgobIRH02uuvANQKabHG+uops83CWmqzznYKrbHSRnrtsc9SG0C2y3oL7qPb8jquo+VWy2m633ZL7bmNsgsvo/K6G22hyvYlLkL59lmvteJmMi+c/64b8F8Iw1IwqwyvGuyzA1cUCAAh+QQFBQAjACw3ADEAWgBnAAAG/8CRcEgsGo9I48Ez+XgOhKR0Sq1aqwhRaBuCIK7gsPhq0HK3kARgzW673/C4fE6vrynnM8jO7/v/bh95XBmAhoduAn8Tg1sZY5CRFxIIB2CMjY+Rm1YGFBOgExpXmIOanKhIBhyhoQV8pXmnqbRCABitoRkEdrFns7W0rLmgGr2NIcDBqMPEH2p0voTLwbjEoBR10o7UtQfXoRHRyMrdkQ/gEw2KctvJ5rQGGekIc+6FchvwVgAS6bvtyEHagOgPAQXpHgTMJMfBPjAR0k24EOdeHAMPwQj4BM4DOzf3Mqb6lk7cG4tvLIkEEyBdgwEnBa7kJC+dhJiZZhI5sOHAH/8G6T4YACnTispNBCQEWGqBIp8BCMFhIJqzmz4j/ZZqDYBgqJ0OEgmyEVR1ZYetaB1SEWDtWgUieBqBsKJ20walaLdq6FDnwId0YgEQMHMGAsaZGvLmlXAUiQV6bQoQ7vKqytUkjaUgUKy4gFc4BJrlcuDG018KCYpk7gTmAGfFGhZ8dFPgWoYBD+teOfs6r4YNAo5wbLVg32UxBhj0XgytzYC2Hiii0r3sAN7lWgvwcjPgAi9Uh/cJiJAY+1INEXSKCTyHgAPzWhmopxsmwWb47AvOOU4lfJgNFphXwHyYoULecgMSCA8BBfSWn35x8JcRAPYpZoGCKwGoV2oKSminTgQSWOAZhiSWaOKJKKao4oostujiizDGKOOMNNZo44045qjjjjz2uKJ/PsroYZAsPgjhG0MSiWGSLzIpBZAmOqnklEpCSeWV6q22jJQnajmGlyutBmaWkXA5Uo5WzkQdPGNumcRndKQZiZwyrknfmW6qZ+QcPGHp54tt/inooIQWYWahhxaq6KKMNkqlnSVCuk+gtCTqqFWXZqopJJRuaiOdf1q6TBAAIfkEBQUADQAsSAAxADoAIgAAB/+AAIKDhIWGhAYaFBQaCQOHkJGSk4URNTSYNDURApSen5EEl5mYNQSgqKkWpKQWqa+eFKyZFLC2kR6zmLWoAp2QBhsbp6C5uryfDh8fEo+EAwUB0gERxbo0yJMCJUFD3igLvwMW09MXn8az2ZECJN7vQz4Ojw7l0xa/k+ms65AbO/DesSAggJw9adUo7SPVz9AAGAHf9Thl8KAGYpIW0qIkwUhEbz5O1TsorYDCaw0RpfjoTUUnAhpISkugD6U+lkOMmBS0QGYACQ2CCh3aQOMuSQd44KyRb0BMmRsy2oQ04AbOHecIbfCpIZ8ho9giOUCCk4MhAQh8LsA11RABGjjuc2AkdIDrXEJgU2roxjJApGgyGUDKe8gABJwznB2C6fPAIcKFBCjAKWStpAg+JXgVBFlrEZwlNjuseLDD17aCBtjA6YMmpa0yNSjmjBpAASE4FXxC69NBoc4ACKjACeSupAQ+AxggJOsYoQA4g7hCNZIkAkKrdEkYNAAIThazPTGWaWDoKFKmBkFnKSRhKsxQCVlC7x7AB5w3BBDdz79BQZmOEUKABYtYsBwhk31URHn9NShUXRaJdhxZEXng4IUN2GaPBgGiQgFu8MgwAIYXClBdAcZ9goAL3gTBQgIkkiiAAeG9QkAEFmygH4mBAAAh+QQFBQASACw3ADEAWgBaAAAG/0CAcEgsGo9I42CBQDgIgqR0Sq1aq4dRY9sYXa7gsPg60HK3o8F4zV4vzudIe06fIuBcRn3PF97xDXpiEoSFhoeIiYqLjIh/eIJWHR4jDgKNmJmai49wDJskECKjJRubp6iMnWeRUyCjsCIoHZeptqmreVgpsbA3arfBmrlbrUgCH72wMwPCzo3EgVQOK8qjKM3P2o6A0lIEJtajMdvlhtHGRgHiIisR5qgI0N3pRAkq7BnwqR1S6EkCKrCTcaBPkg63/iHpwEsciH3wFCrBwY5FNojbJBYpwE6EPIzlNA4hAIOdjVogtYkU8oDdCoQpM9IzcmAGuwYAYsoEZEwACfJ2KAxsgwlSZIRq4jDoDDlzyAAb7E5cXJrowKZoCIgwYAehgLCPVCVE6CZHiIAT7G6gvNUBrE4BZs6kGYKAXYoLz9wuzSK34BAP7BTkDFtOQIQmC9QQaWltBgHCYQ007BUAMmENSGGZWFuIqE4EVjEuqOFLqGXIAzYUCH269TPPrmPLnk27tu3b/Qwagb33tu/fwIMLH068uPHjyJMrX868ufPn0KNLn069uvXr2LPv4x1RO6rcuolw906+vPnz6KWzbq03vfv38OPLbzQ+O9j21/Ue2LCeev35AAYooGX9xYSfdv+5l+CAmBw4W4HbQBhMEAAh+QQFBQAOACw3ADEAXABnAAAH/4AAgoOEhYaHiIYCFxERFwKJkZKTlJWWAAYWAZsBFgaXoKGilAKanJsWkKOrrKEXp6cXrbO0kR2wnB21u7wAEbibHQ7DxMXGx8jJysvMzcW/wLqWBxoaws7Y2cTSlNC43JMYJSbkFQkA2unqyd6w4JES5PImNwfr6Qv3w+2n74gGMebJ8yBAn8Fs/HI5AyFQHo6DEJslDDZpw7iGJnAUjMjx2MQA/goNUICR3Ah0HVPuAwZSUoGSJkpcUKlOArOPIQcRmAATA0qaHXEuCwAzhgGgKnEmOhCwpAWkSVnmFOABZoaNUDkqPdQBpokIWVNuFckBZoWwYqUeYgCzhD20Wv/VFjKAoyfcoFKPYYB5g8BdZTMRyh10wQZMBJcMgOCAwe/fZ4MBCBgBk4OqSQYq/NjBGUg+jgmy3YpGKELbnIUIaHDBufUOEY6Xfe74CljgYWVLjmgmYAEN18AtA7D519SpVINMl7RxLtEiHD2AAxcxoOO1ZpmOfxqkAWaASAZG5JAunUfsrLeJXejg6LIgBCVxDEBEwIIM8uRdEFjEMb2+AU0JVMAhAkTwAn74jVDdY9gUcJE8ChwjwAEZ8ICgdD7IZ5AEoSF1QQPyjEBAaiCIcKF0KBSAVTH+MWiMAAl0sN0gAjCgwonA6QDCgspc5yJ2JfiAY2s9fHDUjxwJkML/kK3B0MGKNMnSiyENMLmDCxJAqU2LSDrQwpA/KNglTV9e2AMOHY6pUgYX0rCAe7uk+eMBIZAHgQZaqtmRABgI2VoICpynJ1ACSKBCCCLEIOWUjM4iwKODRirppJRWaumlmGaq6aacdurpp6CGKuqopJZq6qmopqrqhqu26updXGoa66izvnqXj6fiaitacv5IXKq10sZpsNkQG1YHLRr716KIjGYbR6gJouyuB80W1rSiOuvOXb8O021HCxSibT+FWGtQet8Ok8AGvTaD7bgKFQsKtkDBGwy19oIELFd57Zqvrqv+u067aKXrjMD+9msrwgsrnIzBkjaXyL+SEOwpMcOvYuyqxpWamw7H2ngMayUUU0JvpCVTAjCD9IKsasqNxkyyw9Qac3LNOOO83sp3BQIAOw==";
				clienteUnicoService.getFotoCU($scope.arrayCU[indArrayCU]).then(
					function(data){
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							$scope.resp=JSON.parse(data.data.respuesta);
							if( !generalService.isEmpty($scope.resp.data) )
								$scope.jsonHomonimos.data[indArrayCU].fcfoto=$scope.resp.data;						   						   
							else
								$scope.jsonHomonimos.data[indArrayCU].fcfoto=$scope.sombra;
						}else
							$scope.jsonHomonimos.data[indArrayCU].fcfoto=$scope.sombra;
						
						$scope.obtieneFoto( indArrayCU + 1);
					},function(error){
						$scope.jsonHomonimos.data[indArrayCU].fcfoto=$scope.sombra;
						$scope.obtieneFoto( indArrayCU + 1);
					}
				);
			}
		};	
		
		/** Obtiene la foto **/
		$scope.getFoto = function(){
			$scope.arrayCU = [];
			$scope.ind = 0;
			angular.forEach( $scope.jsonHomonimos.data, function(value, key){
				$scope.arrayCU[$scope.ind] = {	    			
		    			pais: parseInt(value.fipais),
		    			canal: parseInt(value.ficanal),
		    			sucursal: parseInt(value.fisucursal),
		    			folio: parseInt(value.fifolio),
		    			width: 60 
		    	}
				value.fcfoto = "iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AABPFElEQVR42u2dCZgkR3Xnp1TVXdXVRaFBB2CMLaEBm7bU3ZXdWV09M60eJIG4jI3NcKxhuawFPptdzG0bzGkDNodsWAQs9yFOc5nbeLG5bWRsA+IQiMscRl4hcelAB/sSItrhcU9WZkZmVkTkr78vv56j+teVkS/i/6/MeO/t2cMXX3zxxRdffPGV9+ussw615DjGOFrw4MGDBw8ePL94eX95+8gDHjx48ODBg+cXL6/r6MgxZxydou4DHjx48ODBg1c/r8gvT37hvHHMWZ4MPHjw4MGDB69GXpFf3pWjZxxdy5OBBw8ePHjw4NXIK/LLk1+4YBw9y5OBBw8ePHjw4NXI08ysL0x2F/blWDSO5O/HFPzF8ODBgwcPHrz6eS21afCYrL88+YUD41i0PBl4xXjHxPF6tL6+9ntra2vnra+vvy+Koovk+I78/YdyXC/HT/IewvkvRxEOPHjwSuP9HusfvAp4egPhdANg/PKhcQwsT2YALztvaWlpMBqN7i0i/zZZFC5nsYQHrzG8h7OewiuR1zKyBtINgHpx33gDN1TfbU5Gc24IL/1rdXV1RUT/lSL+V7BYwoPXTJ6sAY9gPYVXAk9vIJw3DEBr2oaDxSMcCINdMU8WhVhE/70slvDgwVMm4FGsp/AseTprYMcATHMKC0c8e2CwK+TFcXwTmewv3+05PoslPHiN5z2a9RSexQbCBcMAdKY9I+gZBmCRwa6WJ5P7sBzfZbGEBw9eyvFY1lN4BTYQLhoGYC7t1n9HOQRtAPoMdnW87e3tXhRFL2FxgwcPXkbek1hP4eXYQDgwDEA3TfzbRolB/byAwa6IF8fxcSL+H2FxgwcPXk7ek1lP4WXgDQ0D0Ju26c80ADblCrl4U3gygW8uk/oiFjd48OAV5D2O9RTeFJ42AP1UPVc/1DZyBBH/ingbGxs3RvzhwYNny4ui6PGsz/BSeMNMe/gMA9BB/Kvjjcfj4Wg0+hSLGzx48MrgiQn4I9ZneEfhDfKU+20j/pXyWiL+b2FxgwcPXpk8MQFPYH2GV5hn2VGIwc6W6vcYFjd48OBVxHsi6zM8Wx6DUwFPJvCp8un/xyxu8ODBq5D3JNZneIi/W7yWTMyPsrjBgwevap580Hgy6zM8xN8RnkzI+1cx2YX7j1EUPUX+fEf5fqvJZHzTQ4cOHsv1gAfPD56qAHp12WZC1oM/5nrAQ/xnzNve3u7IZPxyieJ/tQj/8+X7L3M94MHzn7e2Ft1B1ogryr6TEMfrz+R6wEP8Z8iTiX2/EsX/PfLaW3A94MELi7exMT5b5vb3yn6MICbgWVwPeIj/jHjyaf2TJYj/dbv1BOd6wIMXDm8y2diS9eCSsvcQyNrxDK4HvKMwWwxORbzV1dUVW/EXA3FN8pyQ6wEPXvi88Xj8yxVVDHwG1wOeKfyq7k/mIkEDBjsfTybds2xv+yePEAhWePCaw6swe+DPuB7wlPh3MhkAo5/wkMHO9yWf3j9vKf4vIFjhwWsWr8rUQVmTnsn1aLz4634/6QZAvbivPv0PGezsXysrKzez3PD3zaWlpQHBDw9es3hV1w1I7kxyPRor/l3V7XcutfS/enFPffofGL2FGexst//vbZPXKz//EIIfHrzm8WoqGvQcrkfjeD117BiAaU5hwTAAAwY7O299fe3ZFpPzcjn6BD88eM3j1ViB8Dlcj8bw+krPtQHoTHtG0DMMwCKDnY+3tha9w2Jyvozghwevmbw6yw+PRqO/4HoEz9Marg3AXNqt/45yCNoA9Bns/Lwoij5bdHLKz/4WwQ8PXjN59fceWHsh1yNYnr57rw1AN03828odzBvPCxjsAjyZWN8qOjmTzoEEPzx4zeTNpvHQT00A1yM83tAwAL1pm/5MA9DNXCWIwf4vPPkU//2iE3My2TiW4IcHr5m8GXYdfL78+hbXIyieNgD9VD1XP9Q2cgQRfwteUr636OQ8eHByLMEPD14zebNsOZw0GstjAri+zvOGmfbwGQagg/jb82wmJ+MHD15zebMSf2MP0nlZTADX1wtetuw9wwAg/iXwbCYn4wcPXnN5sxT/I6qQtrgeDeEVFX4Gu/xynowfPHjN5c1a/I3jRbuZAK4vLYIZ7ArLeTJ+8OA1l+eI+O9qAri+iD+DXXE5T8YPHrzm8hwSf/044MWJCeD6Iv4Mdg3lPBk/ePCay3NJ/A0T8FKykxB/BruGcp6MHzx4jS4iVlisRagfVtUegjhef/XW1uZeri/iz2BXWM6T8YMHr7k8G7FWewgeXdVjBDEB56s7AVxfxJ/BzmsAsjhzxg8evEYXEbMxAD/lxXH8qKoeI0RR9Ep5+8dwff0X/8zZfwx2feU8GT948CgiZltETP7+cPn366vYQ5DXBHB9nePp0v+ZiwQNGOx6ynkyfvDgUUSsjCJiItQPKWICMq5Xr8piAri+Top/J5MBMPoJDxns7F82u3EZP3jwKCJWVhExec2D8piAnOvVqw8fPtzm+nol/rrfT7oBUC/uq0//QwY7vwEoshuX8YMHr7m8KoqIRVF0ThYTUGS9Go1Gr9nNBHB9nRT/rur2O5da+l+9uKc+/Q+M3sIMdkYDUDQVh/GDB6+5vKqKiMnPPDDNBNikDorBON80AVxfJ3k9dewYgGlOYcEwAAMGOzvPZjIxfvDgNZdXZRExed0DdjMBJVUMfG1iAri+TvL6Ss+1AehMe0bQMwzAIoOdj2czmRg/ePCay6u6iNhoNLq/vPa6iroOvuHMMw/t5fo6xdMarg3AXNqt/45yCNoA9Bns/DybycT4wYPXXF4dRcTk0/p9ExNQUeOht4gJOI7r6wRP373XBqCbJv5t5Q7mjecFDHYBns1kYvzgwWsur64iYuPx+H8I47pqeg+svVXdCeD6zpY3NAxAb9qmP9MAdDNXCWKwSy/nSfDDg9dMXp1FxOJ4/Zwoiq6tqGLgX25vb3e4vjPlaQPQT9Vz9UNtI0cQ8bfglVHOk+CHB695vLqLiAnvgaPR6NqKug7+pRxzXN+Z8YaZ9vAZBqCD+NvzyirnSfDDg9cs3iyKiAn3nkVMQMb39+YsJoB4qYSXLXvPMACIfwm8Mst5cj3gwaOIWNVFxMQA3COPCcjz/oT7ljQTQLzMmFdU+Bnsesp5cj3gwaOIWNVFxKIouruI9TVVVAwU9lt3MwHECy2Cg+NVUc6T6wEPHkXEqi4iJpy7pZkAy4qBb1taWponXhD/oHlVlfPkesCDRxGxqouIiQH4DTl+XEXFQDnenpgA4gXxD5ZXZTlPrgc8eOHyXCkiJp/W72qagJKLBr3j4MH9xxEviD/lPAuU8+R6wIMXJs+lImLC/LXEBFRRMXBtLXrP/v2TE4kXxJ9yngWqeXE94MELj+daEbGNjfE95D1dXUXFQPn7+/bv3zieeEH8KedZoJwn1wMevLB4LhYRi+P1HRNQQcXAd+/bt69LvNQv/pmz/xhsd8t5cj3gwQuH52oRMTEBh+X3XFVRxcD3bG9v94iX2ni69H/mIkEDBtvdcp5cD3jwwuC5XERMftcdi5iALOvfaDR6bxYTQLyUIv6dTAbA6Cc8ZLCzf82inCfXAx48iohV/f5EqG+fxwTkrBiYagKIl1LEX/f7STcA6sV99el/yGDnNwB1l/PkesCDRxGxqs83iqKzRayvrKJioHDfN5lMFoiXSsS/q7r9zqWW/lcv7qlP/wOjtzCDndEAzKqcJ9cDHjyKiFV9vvIebitifUUVFQPleL9pAoiXUng9dewYgGlOYcEwAAMGOztv1uU8uR7w4FFErOrzld971m4moKS6AT81AcRLKby+0nNtADrTnhH0DAOwyGDn47lQzpPrAQ+efzzfiohFUXSGmIAfVVQx8P9ubR24MfFixdMarg3AXNqt/45yCNoA9Bns/DxXynlyPeDB84vnYxExMQG3SUxAFRUDhf3B008/cFPipRBP373XBqCbJv5t5Q7mjecFDHYBnkvlPOHBg+cPz9ciYuNxfEcR6yuqqBgo3A+pOwHESz7e0DAAvWmb/kwD0M1cJYjBdr6cJzx48Pzg+VxEbGNjfCd5bz+qqGLg3y0vLy8SL7l42gD0U/Vc/VDbyBFE/C14LpbzhAcPnvs834uIxXF8tryXH1RUMTCXCSD+fvrn6Xv4DAPQQfztea6W84QHD57bvBCKiMl7OVjEBGQ83w8uLS0NiJdMvGzZe4YBQPxL4LlczhMePHgUEauhouGB0Wj0/YoqBn4ozQQQfzl5RYWfwfaznCc8ePAoIlb1+YpQb8rxvYoqBn54//79NyD+aBHsHM+Hcp7w4MGjiFjV5xtF0STNBNicr7A/YpoA4g/xd4LnSzlPePDgUUSs6vMVod6Q93d5RRUDPzoej4fEH+LvDM+ncp7w4MFzhxdqETF5f2PTBJRcNOhjW1sHbkb8If6U8+R6wIPnLS/kImJyXrG8z8sqqhj4iYMH99+c+EP8KefJ9YAHjyJiDp7veByfLud4WUUVAy84cGDz54k/xJ9ynlwPePAoIubg+ZomoOyKgaPR6O/l/25I/GVithicCng+l/OEBw/e7HhNKSI2mWwcFLG+tIqKgVEU/cPKysqxxN/RhV/V/clcJGjA5GxOOU948ODNhtekImJxHK+KCfh/FVUM/EQWE9BQ8e9kMgBGP+EhkzP7VwjlPOHBgzeTImLXFRXDQ4cOHuvb+a6urq7kMQE519MLTjvttL3E338Sf93vJ90AqBf31af/IZMzvwHwvZwnPHjw6uWJGF5ZVAw3Nzdu7uP4yTkvy/HvFVUM/MfJZHIj4u+net5V3X7nUkv/qxf31Kf/gdFbmMme0QCEUs4THjx4tYrht4t+Eh6P48jX8Yui6DQ5r0uqqBgoY/pJ0wQ0NP566tgxANOcwoJhAAZMzuy80Mp5woMHrx6eCOE/WXwSfqDP4xfH8a/IOXynioqB2gQ0NP76Ss+1AehMe0bQMwzAIpMzHy/Ecp7w4MGrnidrwJstboO/zvfxW11dXRKx/rcqKgYm5urAgf0nNSz+tIZrAzCXduu/oxyCNgB9Jmd+XqjlPOHBg1ctT0TqqRa3wX+Y1MX3ffzEANw6eRRSRcVAOT598OD+kxsSf/ruvTYA3TTxbyt3MG88L2ByFuCFXM4THjx41fHEANzV5hm4/PwjQhi/yWS8Lufyb1VUDJTjM/v3T05uQPwNDQPQm7bpzzQA3cxVgpjsjSvnCQ8evGp4y8vLJ8o6cH3RZ+DJbvpQUt82NyeJCfh2RRUDP7W6unpC4PGnDUA/Vc/VD7WNHEHE34LXhHKe8ODBq4ZnbgQseBv85aGMn5iASM7nm1VUDBQT8Ok8JsDD8Rtm2sNnGIAO4m/Pa0o5T3jw4JXPk7XgibYb4MREnBPK+IlI31LO6RtVVAyUcfpMctcl0PjLlr1nGADEvwRek8p5woMHr1xeHMe3tt0AJ59ur5Hvdwtl/OR89olY/2sVFQOnmYDg46+o8DPZj1rOs7BTZfzgwYMna8FHbDfAiWheK+L2sFDGT87lFDmnr1dRMVCOCzc2Nm7c9PhjcpbAs7lNxfjBgwcvjtd/q7zd72vvOnBg/1II4yfncwsxAV+romKgHJ+N4/gmiD+T04pnc5uK8YMHD97W1ubeRJDK2v0un56vEFPx5/Lnk3wfv/F4fLKc31crqhj4ucQEIP5MzsI8m2dUjB88ePBUNtFdK9j9fp2Ygb+V74+V77cRMf35ffv2dX0bv5WVlZNME1Bm0aDEBBw4sLkP8WdyFi3nWfgZFeMHDx48Y0Px+6vY/Q4vnSfm6KLNzckvIf5Mztw8m2Bl/ODBg6dfoza+/Qixrp8nf//iZDK+FeLP5MzFswlWxg8ePHhHrCcPRqxnwxMD9gUxYD8Xovhnzv5jcubj2QQr4wcPHrwjv0SIzkesZ8a7aGVl5WYBxZ8u/Z+5SNCAyZmdZxOsjB88ePCO/JpMJgvySfTjiPXMeF9MNkwGIv6dTAbA6Cc8ZHJm/7IJVsYPHjx4R1lXjj8yNRCxro8nBuxLaSbAE/HX/X7SDYB6cV99+h8yOfMbgCLByvjBgwfvaF9JjnpSuhaxng0vMQHyupt7Kv5d1e13LrX0v3pxT336Hxi9hZmcGQ1A0WBl/ODBg5f2tbm5ebyYgI8i1rPhiQm4WL7/gmfx11PHjgGY5hQWDAMwYHJm59kEF+MHDx68abytrf0nxPH6yxDr2fDEgH05MQGexEtf6bk2AJ1pzwh6hgFYZHLm49kEF+MHDx68rLz19bX7ybrxXcS6fl5iAjY2xr/ieLxoDdcGYC7t1n9HOQRtAPpMzvw8m+Bi/ODBg5eHp/YFnI9Yz4T3tfE4Ps3ReNF377UB6KaJf1u5g3njeQGTswDPJrgYP3jw4BXhyZqzfzQafQCxrp339fF4/VQH42VoGIDetE1/pgHoZq4SxOTc5bZc8eBi/ODBg2fDExOwKWvJ6+W4GrGujffVpEuhY/GiDUA/Vc/VD7WNHEHE34JnE1yMHzx48MrgqboBD5LjPWIKrkSsq+XJGH/NsXgZZtrDZxiADuJvz7MJLsYPHjx4ZfMOHdrux3F8thx/EMfrr5a15iNqJ/tlR7tTgPh738slW/aeYQAQ/xJ4NsHF+MGDBw9eLbyWelRSmpnwcvyKCj/BtTvPxlkyfvDgwYNXD297e7sna/BHy7qT4Pv4EVwl8GxuKzF+8ODBg1cfb3V19QT1OMT6MQLiT3DtsXmmxPjBgwcPXr280Wh0a7Uf4idN7OVCMJTIs3mmxPjBgwcPXv08MQFn2m4gRPzh7bHZUML4wYMHD95seLbZA4g/vD02G0oYP3jw4MGbDc82dRDxh7cnoDxSePDgwaORW2C9XBSzRTBUwGtcHik8ePDgBcCzLRrkyfnq0v+ZiwQNCK7svCbnkcKDBw+erzzbioGeiH8nkwEw+gkPCa7sX03NI4UHDx48n3m25YI9EH/d7yfdAKgX99Wn/yHBld8ANCmPFB48ePB859n2CnBc/Luq2+9caul/9eKe+vQ/MHoLE1wZDUCT8kjhwYMHLwSebaMgh8+3p44dAzDNKSwYBmBAcGXnNSmPFB48ePBC4dl2CXT0fPtKz7UB6Ex7RtAzDMAiwZWP15Q8Unjw4MELiWfbItjB89Uarg3AXNqt/45yCNoA9Amu/Lwm5JHCgwcPXmg8G/F3sJeLvnuvDUA3Tfzbyh3MG88LCK4CvAbkkcKDBw9ecDwb8Xewl8vQMAC9aZv+TAPQzVwliOAqNZWE8YMHDx48/xq5OdjLRRuAfqqeqx9qGzmCiL8FL+A8Unjw4MELlmcj/g72chlm2sNnGIAO4m/PCzSPFB48ePCC5tmIv4O9XLJl7xkGAPEvgRdoHik8ePDg0cgttF4uRYWf4Co/lYTxgwcPHjz/GrmF0MuFYCiBF1geKTx48ODRyC3wXi4EQ0m8gPJI4cGDB49GboH3ciEYSuQFlEcKDx48eDRyC7iXC8FQMi+gPFJ48ODBo5FboL1cCIYKeAHlkcKDBw8ejdwC7OVCMFTECyiPFB48ePBo5BZYLxfFbBEMFfAal0cKDx48eAHwbMTfo14uuvR/5iJBA4KrnlQSxg8ePHjwZsOzEX9Perm0VMXf6QbA6Cc8JLiyfzU1jxQePHjwfObZiL8HvVxaRr+fdAOgXtxXn/6HBFd+A9CkPFJ48ODB851nI/6O93JpqS6/84YBSG0P3FOf/gdGb2GCK6MBaFIeKTx48OCFwLMRf8d7ufTUsWMApjmFBcMADAiu7Lwm5ZHCgwcPXig8G/F3uJdLX+m5NgCdac8IeoYBWCS48vGakkcKDx48eCHxbMTf0V4uWsO1AZhLu/XfUQ5BG4A+wZWf14Q8Unjw4MELjWcj/g72ctF377UB6KaJf1u5g3njeQHBVYDXgDxSePDgwQuOZyP+DvZyGRoGoDdt059pALqZqwQRXKWmkjB+8ODBg+dfIzcHe7loA9BP1XP1Q20jRxDxt+AFnEcKDx48eMHybMTfwV4uw0x7+AwD0EH87XmB5pHCgwcPXtA8G/F3sJdLtuw9wwAg/iXwAs0jhQcPHjwauYXWy6Wo8BNc5aeSMH7w4MGD518jtxB6uRAMJfACyyOFBw8ePBq5Bd7LhWAoiRdQHik8ePDg0cgt8F4uBEOJvIDySOHBgwePRm4B93IhGErmBZRHCg8ePHg0cgu0lwvBUAEvoDxSePDgwaORW4C9XAiGingB5ZHCgwcPHo3cAuvlopgtgqECXuPySOHBgwcvAJ6N+HvUy0WX/s9cJGhAcNWTSsL4wYMHD95seDbi70kvl5aq+DvdABj9hIcEV/avpuaRwoMHD57PPBvx96CXS8vo95NuANSL++rT/5Dgym8AmpRHCg8ePHi+82zE3/FeLi3V5XfeMACp7YF76tP/wOgtTHBlNABNyiOFBw8evBB4NuLveC+Xnjp2DMA0p7BgGIABwZWd16Q8Unjw4MELhWcj/g73cukrPdcGoDPtGUHPMACLBFc+XlPySOHBgwcvJJ6N+Dvay0VruDYAc2m3/jvKIWgD0Ce48vOakEcKDx48eKHxbMTfwV4u+u69NgDdNPFvK3cwbzwvILgK8BqQRwoPHjx4wfFsxN/BXi5DwwD0pm36Mw1AN3OVIIKr1FQSxg8ePHjw/Gvk5mAvF20A+ql6rn6obeQIIv4WvIDzSOHBgwcvWJ6N+DvYy2WYaQ+fYQA6iL89L9A8Unjw4MELmmcj/g72csmWvWcYAMS/BF6geaTw4MGDRyO30Hq5FBV+gqv8VBLGDx48ePD8a+QWQi8XgqEEXmB5pPDgwYNHI7fAe7kQDCXxAsojhQcPHjwauQXey4VgKJEXUB4pPHjw4NHILeBeLgRDybyA8kjhwYMHj0ZugfZyIRgq4AWURwoPHjx4NHILsJcLwVARL6A8Unjw4MGjkVtgvVwUs0UwVMBrXB4pPHjw4AXAsxF/j3q56NL/mYsEDQiuelJJGD948ODBmw3PRvw96eXSUhV/pxsAo5/wkODK/tXUPFJ48ODB85lnI/4e9HJpGf1+0g2AenFfffofElz5DUCT8kjhwYMHz3eejfg73sulpbr8zhsGILU9cE99+h8YvYUJrowGoEl5pPDgwYMXAs9G/B3v5dJTx44BmOYUFgwDMCC4svOalEcKDx48eKHwbMTf4V4ufaXn2gB0pj0j6BkGYJHgysdrSh4pPHjw4IXEsxF/R3u5aA3XBmAu7dZ/RzkEbQD6BFd+3mQyPnVra3MvkxMePHjw/OHZiL+DvVz03XttALpp4t9W7mDeeF5AcMGDBw8evEbwbMTfwV4uQ8MA9KZt+jMNQDdzlSCCCx48ePDgNbyRm4O9XLQB6KfqufqhtpEjiPjDgwcPHrxG8WzE38FeLsNMe/gMA9BB/OHBgwcPXhN5NuLvYC+XbNl7hgFA/OHBgwcPXiN5NuLvbS+XosJPcMGDBw8ePBq5hdHLhWCABw8ePHiN5NmIv++9XAgGePDgwYPXWJ6N+Pvcy4VggAcPHjx4jebZiL+vvVwIBnjw4MGD13iejfj72MuFYIAHDx48ePAsG7n51suFYIAHDx48ePBKaORmGgAfxD9z9h/BBQ8ePHjwQufZiL82AB6cry79n7lI0IDgggcPHjx4IfNsxD85PBH/TiYDYPQTHjYgGFpxHK/JxX/E+vraC+VifkD+fLEcl4xGox8VDQjbZ0rw4MGDl5cna9Y18v1y+f4lOT4gf36RHL8r/x9vb293EP/debbXwwPx1/1+0g2AenFfffofhhgM+/bt68pFu1sURW+USXIpiwc8ePBC58la9z1Z894kf76XHH3E/z94ttfDcfHvqm6/c6ml/9WLe+rT/8DoLRxEMMgE+EWZAM+Vi/ZdFg948OA1mHd5shZubIxXeIxw6Bjb6+Hw+fbUsWMApjmFBcMADEIIhpWVlZPkYr1c3R5j8YAHDx48+XkxAdeur6+9djIZn9rkPQS218PR8+0rPdcGoDPtGUHPMACLvgfD0tLSvFyox4nwX8FkhwcPHrzdeWIErpR/f1KyZjZxA6Ht+Dl4vlrDtQGYS7v131EOQRuAvu/iLwF9mlyozzLZ4cGDBy8z78I4jleblj1gO36Ona++e68NQDdN/NvKHcwbzwt8F//f3u1TP5MdHjx48KbyrpI19JwmpQ7ajp9j5zs0DEBv2qY/0wB0M1cJcjMYWhK4z2ayw4MHD54171xZU49pQuqg7fg5dr7aAPRT9Vz9UNvIEfRW/JMcV7kQr2Kyw4MHD15pqYOvObJ+QIipg7bj59j5DjPt4TMMQMf3T/6IPzx48OCVz4ui6Hx9JyDUugG24+fY+Q7ylPttey7+e7jtDw8ePHiV8s4NuWiQ7fh5uWGyqPC7tuGPyQkPHjx4lfMeGmrRINvx833DpLepfuz2hwcPHrxaeFfF8fqBECsG2o4f4j+bIj/k+cODBw9efbzPHzy4/7jQKgbajh/iX/8zm8cxOeHBgwevdt6TQhJ/0wAUHT/Ev0ZeUtuf8r7w4MGDN5OWw1cmjdVCEX9tAGzGD/Gvd8PGy5mc8ODBgzcz3stDEf/k52zHD/Gviac+/dPVDx48ePBmxJM1+Fr591uEIP7Jz9uOn0/inzn7z8WTSXpYMznhwYMHb7Y8WYv/IgTxTzi24+fJ+erS/5mLBA1cOpl9+/Z1ZbC/y+SEBw8evJnzLptMJgu+i79pAIqOnSfi38lkAIx+wkPHUjXuxuSEBw8ePGd4h30Xf20AbMbPA/HX/X7SDYB6cV99+h+6dDJRFL2RyQkPHjx4zvBe77v4J3+3HT/Hxb+ruv3OpZb+Vy/uqU//A6O3sAsn0xqNRpcyOeHBgwfPGd5lhw8fbvss/sm/246fw+fbU8eOAZjmFBYMAzBw5WTiOF5jcsKDBw+eW7woitZ8bxRkO36Onm9f6bk2AJ1pzwh6hgFYdCxP8xFMTnjw4MFziycG4Hd97xJoO34Onq/WcG0A5tJu/XeUQ9AGoO9enubaC5mc8ODBg+cab+2lvncJtB0/x85X373XBqCbJv5t5Q7mjecFzl08GfgPMDnhwYMHzzne3/reIth2/Bw736FhAHrTNv2ZBqCbuUpQ/XmaFzM54cGDB8853pd8bxFsO36Ona82AP1UPVc/1DZyBFuuXjwZ7EuYnPDgwYPnHO8yn8U/iwGYNn6One8w0x4+wwB0XBb/5O+j0ehHTE548ODBc453tc/iP80AZBk/x853kKfcb9t18S8jT5PJDg8ePHjV8HwW/zQDkHX8fDvfnT0Aewp++ZanyWSHBw8evGp4Pov/0fQlz/h5J/42Xz7maTLZ4cGDB68ans/iv5u+5B0/xN/xPE0mOzx48OBVw/NZ/I/UlyLjh/g7nqfJZIcHDx68ang+i7+pL0XHD/F3PE+TyQ4PHjx41fB8fwZuO36Iv+N5mkx2ePDgwauG57P4q14zVuOH+Duep8lkhwcPHrxqeD6L/896zdiNn0/inzn7L6Q8TSY7PHjw4FXD81n8VaVZq/Hz5Hx16f/MRYIGoeRpMtnhwYMHrxqez+JvGoCiY+eJ+HcyGQCjn/AwlDxNJjs8ePDgVcPzWfy1AbAZPw/EX/f7STcA6sV99el/GEqeJpMdHjx48Krh+Sz+yd9tx89x8e+qbr9zqaX/1Yt76tP/wOgt7H2eJpMdHjx48Krh+Sz+ZfSacfh8e+rYMQDTnMKCYQAGoeRpMtnhwYMHrxqez+JfpNT8kePn6Pn2lZ5rA9CZ9oygZxiAxZDyNJns8ODBg1cNz2fxL2IAjhw7B89Xa7g2AHNpt/47yiFoA9APLU+TyQ4PHjx41fB8Fv+8BmC38XPsfPXde20Aumni31buYN54XhBcniaTHR48d3ij0egaOb4ux8fl72+X4+VynBtF0VPl++PkeLT8+ZHJkfxZjj+UP/9xHK8/f3197VVra9E75O8fE97FwvgR12O2PJ/FP48BONr4OXa+Q8MA9KZt+jMNQDdzlSDP8jSZ7PDg1c8Tkb5Gjn8R0X6l/F2EPLr9ysrKSYcPH26Xub7EcXycGIF1+b33kuOJ8jvfJN8vkuN6rkf1PJ/FP6sBSBs/x85XG4B+qp6rH2obOYItVy8ek9O9DTlVnK8r8Xf22WftPXRo6yYHD+4/eTyOT5tMNg4m4iXCcl85Hi/v9aUiOB+W75cRf//puE6Oj8kn9afLuN359NMP3HSW4jAej4dyvc5I7iDI8W65Zt9H/Mvn+Sz+WQzAtPFz7HyHmfbwGQag47L4VyU2bMiZbeqMB046Ey/5RCvCcg95/8+T759vWvzJOV8rx/vk5x4gwn+iyxvC7nKXO8+JMTkjjuPkUcPH5T1fh/jb83wW/2kGIMv4OXa+gzzlftuui39VYsOGnNmmznjgpAvx5FPnyXIuD5fjgsDj76vy6fr35bipr3ngk8nGLeScH6juDlzD+hLEM/Dae814uV4VFX4f8zTZkONe6owHTtqat7k5Oaief18VUPxdIMfd5DSP8e16pPFWV1dPEDPzP8UIfIr1Jfw7d9MMQJ7x8329Cj5Pkw057qXOBOOkM33SHN9KhOW8Ip8yXYk/ee+fFoG8cwjXI8Mz4YNyvleyvjTjzp3t+CH+HooNG3JmmzoTopOexhNRubWc5wd9ij95z5fK9webn/hDFn91nU5nfWnOnTvb8UP8PRQbNuTYXd8qzjdk8Te+WskeARGZH3sQf69Lbo0Hfj12MwCvYX1pzp072/FD/D0UGzbkWN8mLf18GyD+O18yHvvlnL/jaPxdnmQ2NOl6GHF9vBxXsb40586d7fgh/h6KDRty7K5vFefbNLGJougUOb7sWPz9s/z/LZoo/uqaPJL1pVl37mzHD/H3UGzYkDPb1JkQnHQZPBmfm8u5f8WR+HuzHP2mir96PHMR60uz7tzZjp9P4p85+y+kPE025JR/fas436aJv/5aXV29ZbLZbsbx97zdNvo16XrINTiT9aV5d+5sx8+T89Wl/zMXCRqEkqfJhpzyg6uK822i+Bu3IX9VV6arO/6iKHp6QzZgTovpN7C+NO/OnS/l1y3Fv5PJABj9hIeh5GmyIaeSxbL0822q+GuejMEzZhB/f4r479mzsbFxY52ZwfrSrDt3vpRftxB/3e8n3QCoF/fVp/9hKHmabMgpP7h8bmTkKu/Qoa3j5dP4hTV+8n8J4r+z+e/3WV+aeefOl/LrBcW/q7r9zqWW/lcv7qlP/wOjt7D3eZpsyHEvdcZDJ10Lb3197Yya4uX929vbHcT/Z5v/kmwM1pdm3rnzpfx6AV5PHTsGYJpTWDAMwCCUPE025LiXOuOZk66798W7K/7k/+XJZHIjxF+vL9EdWF+ae+fOl/LrOXl9pefaAHSmPSPoGQZgMaQ8TTbkuJc645mTrrv3xcGq4iV5zi3HOuL/HzwxRH/F+tLcO3e+lF/PwdMarg3AXNqt/45yCNoA9EPL02RDjnupMx456ZnwRKQ/WUW8JM+6Ef//4CWNmmRMrmF9ae6dO1/Kr2fk6bv32gB008S/rdzBvPG8ILg8TTbkuJc644mTnhkvaU1bQbxccPjw4Tbi/58+XPwx60uz79z5Un49I29oGIDetE1/pgHoZq4SVPPFY3K6tyHH50ZGPvDEANxUxun6EuPlOmFGLo9fYk7iOL6JvNdfXl1dXUkOOa9T5W3f6uDB/adsbe0/ocz3d/bZZ95I2N9gfWn2nTtfyq9n5GkD0E/Vc/VDbSNHsOXqxWNyurchx+dGRr7wRJz+ocR4eaFL55uIvbynA3KOj5fvb082Jo5Go2sznO/lSaqkvPZd8n/nyp/PkWNje3u7l/f9xfH6PRB/7tz5Un49I2+YaQ+fYQA6Lot/VWLDhhy76xtwI6Or5PiWHB+Rvz93PI7vuLJyansW80NE7mklxcsPk0I3Liy+8n5/KRFuOS4pc36ozY1/nxQ2kuO2+/bt62a4s/gexJ87d76UX8/Iy5a9ZxiAlusXj8np3oacJjUyEmH5nHy/Y93zQ37vr5YRL7uV+q178Y3jONls96a0xxolz48fyPF6GcPfSMzAke9vc3NyalJ6GfHnzp0v5ddL5RUV/lmcDJPTvQ05TWxkJGLy5Drnh/y+n7ONF2Fcuby8fOKs5m9yq1/d5r96hvPju+vray+YTDZi/f6SssuIv1937lxbD+ouv14Vz/mLx+R0b0NOgxsZPbjO+SEC/j3LeHnRDO/cHS/v/wOOzbe/juP4zvLv30T8/bpz5+h68BPE30OxYUOO3fVtcCOj5Nby8XXND/ldn7KJl2Qn/Szmrwj/L8rv/yLiSgty18XQl/LrjRT/qsSGDTl217fhjYweU9f80BvVCsbLJ2Yxf5NUPjEAFyOutCD3QQx9Kb/eSPGvSmzYkDPb1BmfGxmJuH24rvkRx+vnW8TLQ+uev0k63tHSF5m/tCB3sxeEH+XXGyn+VYkNG3JmmzrjcyMjMQA/ElSrjvkhv+8FBePlumTzX93zV8T/BYgrLch9EcMy1gPE30OxYUPObFNnfG9klHTTq6cI1tqzC8bKB2eQrXNbxJUW5D6JfxnrgU/inzn7L6Q8TTbkuJc643sjI/nZk2oqgvUnBd/jY2oW/zn59P8FxJUW5D6JfxnrgSfnq0v/Zy4SNAglT5MNOe6lzvjeyGhzc+OWdcyPpIhPsTsUGwfrnL/yPh+CGNKC3DfxL2M98ET8O5kMgNFPeBhKniYbctxLnfG8kdH1ZTemSflkfW6B93fZ1tbm3rrm7/b2dmc0Gn0NMaQFuY+9OXwpv24h/rrfT7oBUC/uq0//w1DyNNmQ42QqnbeNjOTT7r/W+Mn6xXnfn3x/X52LUVJuFzGkBbmvjbl8Kb9eUPy7qtvvXGrpf/Xinvr0PzB6C3ufp8mGHPdSZzxvZPSWGotgvTnv+4vj9afXuRiJAXgHYkgLcl+7cvpSfr0Ar6eOHQMwzSksGAZgEEqeJhty3Eud8bmR0Xg8flCNRbA+mvf9bWyM71XX+1tZWTk26cSHGNKC3NeW3L6UX8/J6ys91wagM+0ZQc8wAIsh5WmyIcfNVDpPGxn9+/b21ol1zY/kcUPeeBEDsFLX+5Pfd0/EkBbkvop/CevBTxw8X63h2gDMpd367yiHoA1AP7Q8TTbkuJlK52kjo0fUNT8mk8nCtPa5R74/MQxXnnLKyZ265q/8vpcghrQg91X8S1gPfuLY+eq799oAdNPEv63cwbzxvCC4PE025LiZSudhI6P31ymu8vtGeeNlNBp9rs75m5b7j7jSgtx18bdcD2otv56RNzQMQG/apj/TAHQzVwmq+eIxOYNMpfOqkZEI3QWTycaxdc4PeR8PLBAv767x/d3waHcoEFdakPsg/kXXg1mUX8/I0wagn6rn6ofaRo5gy9WLx+QML5XOp0ZG8m9vjKLRDeqeH/Jp/v/kjZfkZ+p6f/L7DhSNZ3mf17ouDkl9A9YXL5+B19prxrHzHWbaw2cYgI7L4l+V2LAhZ7apMz40MpJP/f8Sx+t3n2EFzC/mjRd5z0+t6/3J735A0XjOYgBmLQ5ZDAB3Epx7Bl57rxnHzneQp9xv23Xxr0ps2JAz29QZxxoZJbexfyji+ZXkOb8cTxuP4+1ZfrJZXV29ZZF4kXN4WF3zV37XU4rG8zQD4II4TDMAiL+Tz8Br7zXj2/nu7AHYU/DLtzxNNuSUf319bmTkA0/G49FF4kVE+X51na/8vpcWjec0A+DK9UgzAIi/s8/Aa+814/t65fzFQ/yDS6ULx0lXJ67/XDBe7lbX+crvenvReD6aAXDpehzNACD+Tj8Dr73XDOLvodiwIcfu+vrcyMh1noxRXDReoii6U13nK7/vg0XjeTcD4Nr12M0AIP7h3bnzpfx6I8W/KrFhQ47d9fW5kZHrPBHx84vGi/zs7eo6X3k//1Q0no80AC5ejyMNAOtLmHfufCm/3kjxr0ps2JBjd319bmTkMi/Z/JeIY9F4kdedVdf5itm4sGg8mwbA1ethGgDWl3Dv3PlSfr2R4l+V2LAhx+76+tzIyGWeiOqbLOPltnWdr/yuzxWNZ20AXL4e2gCwvoR9586X8uuNFP+qxIYNObNNnQnBSZf/SSQ6yzZeRFhvX9f56jsAReI4MQCuX4/b3GZ7nvUl/Dt3vpRfL0P8M2f/hZSnyYac8q+vz42M3PzkP7qBjNfFtvEiP3OXus432QNQNJaVAXD6+p555qG9rC/h37nzpfy6JU+X/s9cJGgQSp4mG3LKDy6fGxm5eRty7RVlxEvSnreu842i6O+KxrP87LWuX18xAMexvoR/586X8uuW4t/JZACMfsLDUPI02ZBTfnD53MjIwWeQDy0xXn67rvMVEX9b0Xg+wgA4eX1NA8D6Eu6dO1/Kr1uIv+73k24A1Iv76tP/MJQ8TTbklB9cPjcycokXx+t3FTH8cYnx8od1na+87xcXjWfDADh7fbUBYH0J+86dL+XXC4p/V3X7nUst/a9e3FOf/gdGb2Hv8zTZkONe6oyHTrp03sbG+A4ihFeUGS9iKJ5ZY4XOJxWNZ2UAnL6+yR4A1pfw79z5Un69AK+njh0DMM0pLBgGYBBKniYbctxLnfHMSZfOG4/ju5Ut/j9jRK+o63x36waYNZ6VAXD6+iZZAKwv4d+586X8ek5eX+m5NgCdac8IeoYBWAwpT5MNOe6lznjmpMuO58cmAlhFvIgBeE9d5yvnsFU0nrO0A5719c3SDpgNyv7fufOl/HoOntZwbQDm0m79d5RD0AagH1qeJhty3Eud8chJl8bb3Nw8Xs75rRXHy6frOt/TTjttb9F4LmIA6r6+RQwALcj9m7++lF/PyNN377UB6KaJf1u5g3njeUFweZpsyHEvdcYTJ13mY6y7yyfmb1cdLyKs36vzfOX3XVwknvMagFlc37wGgBbkfs5fX8qvZ+QNDQPQm7bpzzQA3cxVgmq+eIi/extyfG5kVCdPRH9DxO5v64yX5eXlE+s6Xzm/VxSJ5zwGYFbXN48BoAW5v+bdl/LrGXnaAPRT9Vz9UNvIEWy5evEQf/c25PjcyKgGXkvOKdnh/9eziBf5+3Zd5yu/6z6zmh9VP0bIagBoQe73nTtfyq9n5A0z7eEzDEDHZfGvSmzYkGN3fX1uZFQVL47jX0lS40T4vzzLeJHf/zt1jd/q6uoJiRDP4nyrfoyQxQCwQdn/O3e+lF/PyMuWvWcYgJbrFw/xd29Djs+NjMriyfu/uYjt3UWInr/bs/BZxUtSoKfmxxwzudNR9WOEaQYA8Q/jzp0v5ddL5RUV/lmcDOLv3oYcnxsZpfG2tjb3bm3tP2Fr68DNRNh+XkTm1ird7bB8f4R8/99y/I0cl7gaL/KeP1XzBsf/NovzzWoAip5vmgFA/MO5c+dL+fWqeM5fPMTfvQ05NDJyOl6uk+OGdc3fgwf3JyVzv133+WYxADbnezQDgPj7feeu7PUA8fdQbNiQY3d9aWTkdrxEUXSnOuevvK/fn8GdjmurjJfdDADi7/wz8NrXA8TfQ7FhQ47d9aWRkfPxcm6d83f//smJYjq+Uuf5phmAMs73SAPA+hLQM/AS1wPE30OxYUOO3fWlkZHb8SJi/IX6s3WiO9R5vkczAGWdr2kAWF/CfQbuS/n1Rop/VWLDhpzZps6E1sjIRV6ygXEGG3afV9f57mYAyjxfbQBYX8J9Bl7GeoD4eyg2bMiZbepMaI2MXORFUfRHdc/fpaWlpIPeB+s43yMNQNnxknQDZH0J9xl4WeuBT+KfOfsvpDxNNuS4lzoTWiMjF3liAC6axfxdWVk5Vn7/BVWfr2kAqoiXM888tJf1Jcxn4GWuB56cry79n7lI0CCUPE025LiXOhNaIyNXeXG8fttZzN/xeDwUgX5vleerDUBV8SIG4DjWl/CegZe9Hngi/p1MBsDoJzwMJU+TDTnupc6E1sjIXd7aa2c1fw8fPtyOougJItTXVLTH4doq48U0AKwvYTwDr2I98ED8db+fdAOgXtxXn/6HoeRpsiHHvdSZ0BoZOcy7Sj6N/9ws56+8h1Plvb277PNVBqCyeNEGgPUljGfgVa0Hjot/V3X7nUst/a9e3FOf/gdGb2Hv8zTZkONHKh29JSrrmvc0FxbfOF7fluPVURR9v6Q9DtdUGS/JHgDWl2CegVe2Hjh8vj117BiAaU5hwTAAg1DyNNmQ40cqHb0lKuua9/04jo9zZfFNei3I+/tVeW9Plvf2Dvl+kXy/8iif8pPHB9+R41/k+Cs5niPHQ8RI3P700w+eVGW8JFkArC9BPAOvdD1w9Hz7Ss+1AehMe0bQMwzAYkh5mmzI8SOVjt4SlbYIfpbr2T/yPvtyHL+8vHziZDK5UfL3Wb6/LO2A2aDs/DPwytcDB89Xa7g2AHNpt/47yiFoA9APLU+TDTl+pNLRW6JS3tXyaXqfq+LvIq+IAaAFuX/x4kv59Yw8ffdeG4Bumvi3lTuYN54XBJenyYYcP1Lp6C1ROe/diH92Xl4DQAtyP+PFl/LrGXlDwwD0pm36Mw1AN3OVoJovHuLfjFQ6ekvUUj733oh/Nl4eA0ALcn/jxZfy6xl52gD0U/Vc/VDbyBFsuXrxEP9mpNLVFX8Nj5fvyutvjvhP52U1ALQg9ztefCm/npE3zLSHzzAAHZfFv4F5241Npasr/poeL6PR6MOJuCH+6bwsBoANys49A699PXDsfAd5yv22XRf/JuZtNzWVrq74I15+evw54p/Om2YAEH8nn4HXvh54OT+KCv8sTgbxb0YqXV3xR7ysqT4B8e8h/kf/SjMAiL+zz8BrXw98nx/OXzzEvxmpdHXFH/HyM0YURdeur6/dG/HPZwAQf6efgde+HiD+5G03bkMOjYyCib+ro2j0a4h/NgNAvDj/DLz29QDx91Bs2JBjd31pZBRUr4Afy5/vifinGwDiJaBn4CWuB4i/h2LDhhyr63tMFedbV/wRL7vyro+i6FGI/+4GgHgJ9xm4L+XXGyn+WQwAk7PeDTlLS0vzNDIKNv5etVsN/qaJv2kAiJdwn4GXsR4g/hXzEP/MvOvruB5iAAY0Mgo6/i5cXV1dabL4J19JN0DWl3CfgZe1Hvgk/pmz/0LK02zQ5LyqjuuxsbFxYxoZBR9/V0dR9ITkbk8TxT/5uTPPPLSX9SXMZ+BlrgeenK8u/Z+5SNAglDzNpkzO0Wh0aR3XI+kqRyOjxsTfRWtr0V2aWDRoPI5PY30J7xl42euBJ+LfyWQAjH7Cw1DyNJsyOUWYv1TT9RjTyKhx8fcREcQ7hy7+cr63jOP1P5Dz/Xs5rmd9CesZeBXrgQfir/v9pBsA9eK++vQ/DCVPsymTM4qij9RxPeT33IlGRs2MP7n2F8jxW/rRgO/in2x4lPM5W45nyZ8/y/oS7jPwqtYDx8W/q7r9zqWW/lcv7qlP/wOjt7D3eZpNmZyyiJ1fx/WQ33MOjYwaH3+XyHGuxMKGT+Ifx/FxysD+yWg0+lCy14Hr24hn4JWtBw6fb08dOwZgmlNYMAzAIJQ8zQZNzifWdD2eTCMj4s8wnv8qx3ly3HUymdzIFfFP2h7LcQd5j4+V43Ui+Bdzff29c+fqeuDo+faVnmsD0Jn2jKBnGIDFkPI0GzQ5f72m6/E6rge8oxzXJ7fSxQy8Qo6Hyc/ebnNzY2lra3NvmYt5whPuKeNxfGBjY/yb8jsfLL/v6fL99SL0n5TvP+B6hNWCvCqeL+XXc/C0hmsDMJd267+jHII2AP3Q8jQbMjmvX15ePrGO6yEL7Se4HvByNh5Kyg1/LdlcJ39+m/zfy0So/1yOpyV3ruTfHq+OJ8jxFDmekfy/fH+xHK+VP79Djg8rc/GdnzUy4no0qQV5VTxfyq/nyN4bGAagmyb+beUO5o3nBcHlaTZhcsri+I91XI9Dhw4eK4vvD7ge8ODBc/wZeC29Zhw736FhAHrTNv2ZBqCbuUqQZ3maTZicZh33Kq/H5uZkhesBDx48x5+B19ZrxrHz1Qagn6rn6ofaRo5gy9WLx+Sc+un/itXV1RPqMWNr9+d6wIMHz+Fn4LX2mnHsfIeZ9vAZBqDjsviTt53p0//T67oea2vReVwPePDgOfoMvPZeM46d7yBPud+26+JP3vZU8f9MUsykRjP2z1wPePDgOfoMvPZeM14WwSoq/D7maYY6OUej0eeTXOe6rsfq6upNVJoX1wMePHguPgOvvdeMd+Jv8+VjnqaLk8ncSV/gmf+18vMvGI/Hwzqvh/ze+7NYwoMHz+Fn4LX3mkH8Hc/TdHEyJYVMxuP1DfnzA+XfnynH36jyqkf72avk+FiSJ72ysnLSLK6HGIB3sljCgwfP4WfgtfeaQfwdz9P0KXVmaWlpICJ/irxmlHTdi+N4NbnNf/jw4fYsr0eSZSAG4BoWS3jw4Hn/DHwXfSk6foi/43mapM6U8hjm4SyW8ODBC+0ZuO34If6O52mSOmPNa8l5fJHFEh48eCE9Ay+j1wzi73ieJqkz1nswfp3FEh48eCE9Ay+r14xP4p85+8+lkznas2dSZ2rbg3EBiyU8ePB2Oa72WfzL6DXjyfnq0v+ZiwQNHMrTvJzUmdkEVxRFd2exhAcP3lFSki/1WfzL6DXjifh3MhkAo5/w0JWTkSD7EqkzM/nk35fjqyyW8ODBO0ol0i/4LP5l9JrxQPx1v590A6Be3Fef/oeunIwYgA+QOjOT7Is/Y7GEBw9eyvF+n8W/jF4zjot/V3X7nUst/a9e3FOf/gdGb2EX8jRfROpMvcElput0eZ/XsVjCgwcv5Q7AeT6Lfxm9Zhw+3546dgzANKewYBiAgUN5mg8ldaa+4FpeXj5R3uM3WCzhwYM3xQA8xGfxz1pnpkhRtxmfb1/puTYAnWnPCHqGAVh06WQ2NjYOkTpTz/XY3t7uyaf/D7G4wYMHb9oRx/Gaz+JfxAB4UNRNa7g2AHNpt/47yiFoA9B37eKdeeah48Rpfj+kyeToM/85Gee3srjBgwcvw/Hds88+a6/P4p/XAHhQ1E3fvdcGoJsm/m3lDuaN5wWOpmqsvS2kyeSa+O/bt6+L+MODBy/H8SbfxT+PAfCkqNvQMAC9aZv+TAPQzVwlaAYXL47jB4Q0mVx75j8ajT7M4gYPHrysvI2N8X18F/+sBsCjom7aAPRT9Vz9UNvIEWy5fPHG43iwW0EgXyeTY7v92fAHDx68PLzLzjjj0I19F/8sBsCzom7DTHv4DAPQcV38NS+KoueGMplmHfz79++/gbyPc0n1gwcPXl5eHK+fF4L4TzMAHhZ1G+Qp99v2RfyVAThFPrFeG8JkmuGGlzk5HiTj+G0WN3jw4OXlyTp8zXgcnxaC+KcZgJCKuu26B2BPwa8Z16Z/ZQiTqe7xm0wmN5Kxe6QI/9dZ3ODBg1ect/aqUMT/aAYgpKJupX458Mz6F+W40vfJVMf4raysHCu/715y/KUcV7G4wYMHz4YnHyKu2Nyc3DoU8d/NAIRU1C0o8Tcu2JMCmEyfESf9yjiOHyV/vp2I9Unb29udouO3f//kxPF4fSPJlpBJ+hw5/iHP4xIWN3jw4E3jxfH6U0IS/yMNQEhF3YIU/+RraWlpXgb+wtAmpxLsb8j3T8rxXvnzG+R4qRzPE0F/tvzbM+XPz5Hvz5e/v0p+/l3y/RPyb9+UP1/H4gYPHryqeLLWfGYy2eiGJP6mAQipqFuw4q+/5JPuqnlbm8kODx48eJWJ/5Wy5i6HJv7aAIRU1C148Tc2BJ7D5IQHDx68anmy1t4/RPFPfi6kom6NEX/Ni+P15zPZ4cGDB68a3mg0elao+pH8fChF3UrN/vPl4m1tbe5dW4vewGSHBw8evNJ5r5blthWq+P+sz4zfRd2yCr+q+5O5SNDAl0YPSbdAuRBvZLLDgwcPXnnif/jw4XbI4m8aAN+KuuUU/04mA2D0Ex761OjhlFNO7qjStkx2ePDgwbPjPTP0T/6mAfCpqFsB8df9ftINgHpxX336H/pY61ltDKToDTx48OAV2O0f8oa/3Xg+FHWzEP+u6vY7l1r6X724pz79D4zewt4VfVhdXV3ZrU4Akx0ePHjwjp7nH2qqXxrPdvwcPt+eOnYMwDSnsGAYgIHPFZ9UsaAnHq1sMIsHPHjw4P2svG9S4S/EIj9ZeLbj5+j59pWeawPQmfaMoGcYgMVQyj0mvQPkgr3cLIvL4gEPHjy6+kXXJI19Qqvtn5dnez0cPF+t4doAzKXd+u8oh6ANQD/EYJALdQsJ+OfK98tZPODBg9dg3mVJ/ZSQWvra8Gyvh2Pnq+/eawPQTRP/tnIH88bzgqCD4dChrZtI4N9XLtybEzPA4gEPHrwG8L4rx5s2Nsb3OeOMQzf2Vayr4NleD8fOd2gYgN60TX+mAehmrhIUSDDc5S53nouiaE2O35HjBXIx3y/HRWqyXM3iAQ8ePI94V49Go0tlLftCspbJ9/PkeEgcx2tnn33W3hDEugqe7fVw7Hy1Aein6rn6obaRI9giGODBgwcPXpN4tmbMsfMdZtrDZxiADuIPDx48ePCayLO9E+PY+Q7ylPttI/7w4MGDB6+pPNvHMF6OX1HhJ7jgwYMHD14oPNs9GL6PH8EADx48ePAaybPdgIn4E1zw4MGDB89Dnm32BeIPDx48ePDgecizTeVE/OHBgwcPHjwPebZ1HBB/ePDgwYMHz0OebREnxB8ePHjw4MHzkGdbwdEn8c+c/UdwwYMHDx680Hm25Zs9OV9d+j9zkaABwQUPHjx48ELm2fZu8ET8O5kMgNFPeEhwwYMHDx68kHm2jZs8EH/d7yfdAKgX99Wn/yHBBQ8ePHjwQubZdm10XPy7qtvvXGrpf/Xinvr0PzB6CxNc8ODBgwcvSJ5ty2aHz7enjh0DMM0pLBgGYEBwwYMHDx68kHk24m8YANfOt6/0XBuAzrRnBD3DACwSXPl4EgjXNyGPFB48ePBC4tmIvzIArp2v1nBtAObSbv13lEPQBqBPcOXnNSGPFB48ePBC49mIvzIALp2vvnuvDUA3Tfzbyh3MG88LCK4CvAbkkcKDBw9ecDwb8c/SDrjm8x0aBqA3bdOfaQC6masEEVylppIwfvDgwYM3G56N+BcxABWfrzYA/VQ9Vz/UNnIEEX8LXsB5pPDgwYMXLM9G/PMagBrOd5hpD59hADqIvz0v0DxSePDgwQuaZyP+eQxATeebLXvPMACIfwm8QPNI4cGDBy9ono34ZzUAzo1fUeEnuMpPJWH84MGDB282PBvxz2IAaBHcAF5geaTw4MGD1wiejfhPMwCIf0N4AeWRwoMHD15jeDbin2YAEP8G8QLKI4UHDx68xvBsxP9o6zfi3zBeQHmk8ODBg9cYno3477Z+I/4N5AWURwoPHjx4jeHZiL9vvVwIhop4AeWRwoMHD16TGrn9pAm9XBSzRTBUwGtcHik8ePDgBcCzEX+Perno0v+ZiwQNCK56UkkYP3jw4MGbDc9G/D3p5dJSFX+nGwCjn/CQ4Mr+1dQ8Unjw4MHzmWcj/h70cmkZ/X7SDYB6cV99+h8SXPkNQJPySOHBgwfPd56N+Dvey6WluvzOGwYgtT1wT336Hxi9hQmujAagSXmk8ODBgxcCz0b8He/l0lPHjgGY5hQWDAMwILiy85qURwoPHjx4ofBsxN/hXi59pefaAHSmPSPoGQZgkeDKx2tKHik8ePDghcSzEX9He7loDdcGYC7t1n9HOQRtAPoEV35eE/JI4cGDBy80no34O9jLRd+91wagmyb+beUO5o3nBQRXAV4D8kjhwYMHLziejfg72MtlaBiA3rRNf6YB6GauEkRwlZpKwvjBgwcPnn+N3Bzs5aINQD9Vz9UPtY0cQcTfghdwHik8ePDgBcuzEX8He7kMM+3hMwxAB/G35wWaRwoPHjx4QfNsxN/BXi7ZsvcMA4D4l8ALNI8UHjx48GjkFlovl6LCT3CVn0rC+MGDBw+ef43cQujlQjCUwAssjxQePHjwaOQWeC8XgqEkXkB5pPDgwYNHI7fAe7kQDCXyAsojhQcPHjwauQXcy4VgKJkXUB4pPHjw4NHILdBeLgRDBbyA8kjhwYMHj0ZuAfZyIRgq4gWURwoPHjx4NHILrJeLYrYIhgp4jcsjhQcPHrwAeDbi71EvF136P3ORoAHBVU8qCeMHDx48eLPh2Yi/J71cWqri73QDYPQTHhJc2b+amkcKDx48eD7zbMTfg14uLaPfT7oBUC/uq0//Q4IrvwFoUh4pPHjw4PnOsxF/x3u5tFSX33nDAKS2B+6pT/8Do7cwwZXRADQpjxQePHjwQuDZiL/jvVx66tgxANOcwoJhAAYEV3Zek/JI4cGDBy8Uno34O9zLpa/0XBuAzrRnBD3DACwSXPl4TckjhQcPHryQeDbi72gvF63h2gDMpd367yiHoA1An+DKz2tCHik8ePDghcazEX8He7nou/faAHTTxL+t3MG88byA4CrAa0AeKTx48OAFx7MRfwd7uQwNA9CbtunPNADdzFWCCK5SU0kYP3jw4MHzr5Gbg71ctAHop+q5+qG2kSOI+FvwAs4jhQcPHrxgeTbi72Avl2GmPXyGAegg/va8QPNI4cGDBy9ono34O9jLJVv2nmEAEP8SeIHmkcKDBw8ejdxC6+VSVPgJrvJTSRg/ePDgwfOvkVsIvVwIhhJ4geWRwoMHDx6N3ALv5UIwlMQLKI8UHjx48GjkFngvF4KhRF5AeaTw4MGDRyO3gHu5EAwl8wLKI4UHDx48GrkF2suFYKiAF1AeKTx48ODRyC3AXi4EQ0W8gPJI4cGDB49GboH1clHMFsFQAa9xeaTw4MGDFwDPRvw96uWiS/9nLhI0ILjqSSVh/ODBgwdvNjwb8fekl0tLVfydbgCMfsJDgiv7V1PzSOHBgwfPZ56N+HvQy6Vl9PtJNwDqxX316X9IcOU3AE3KI4UHDx4833k24u94L5eW6vI7bxiA1PbAPfXpf2D0Fia4MhqAJuWRwoMHD14IPBvxd7yXS08dOwZgmlNYMAzAgODKzmtSHik8ePDghcKzEX+He7n0lZ5rA9CZ9oygZxiARYIrH88yj7TF5IQHDx682nktG/GX43oHz1druDYAc2m3/jvKIWgD0Ce48vMkEK4uupt0aWlpwOSEBw8evHp5y8vLizaN3KIoutKx89V377UB6KaJf1u5g3njeQHBVYAngXBp0d2ko9Ho1kxOePDgwauXJ2vvPptGbvLv33HsfIeGAehN2/RnGoBu5ipBBNduqSSfs9hMci8mJzx48ODV3sX1jjaN3MRAfNqx89UGoJ+q5+qH2kaOIOJvwZNAeJeFAXgpkxMePHjwau/i+iSbRm6y7r/TsfMdZtrDZxiADuJvz4ui6NkWu0kvOfPMQ8cxOeHBgwevPp4I+MdtGrkl675j55ste88wAIh/CTwJhv9us5s0jtfvx+SEBw8evHp4KysrJ8k6fL1NIzcxAPf1cvyKCj/BtTsvz2aSowTXp0855eQO1wMePHjwqufJOvynNuKvXvdLvo8fwVAST0zA1202lMjxYK4HPHjw4FXLW15ePlHW2x/YiL8c30D8CS7TADzfckPJ91dXV2/J9YAHDx686niy3r7MUvyT40WIP8G18yXBsm2zoUQdF8pxQ64HPHjw4JXPi6LoriWIf/L8/3aIPzzzqyWf4i8uIbg+trKycizXAx48ePBKFf8oudNqK/7J7f/Dhw+3EX94RwbYI0sIrsRdfkaOU7ge8ODBg2fPE+HflOPSMtbnpH4A4g/vv3yNx+Okv/TllsGl9wR8T0zAOXtUsyCuBzx48ODlvzMr6+jvyJp6VRniL+vyFckmQh/FP3P2H8FVnCfB9ke24n9EwH1Sjt88++yz9nI94MGDBy8bT9biM2QN/WgZz/zTiv94MH669H/mIkEDgqsYL4pGN5Bg+lYZ4m8GqwTev62vr71EjvuPx/H68vJpwz1GK2GuBzx48JrK27dvX1fWyl9INufJ8VT50PQ52zz/XY7k7u7xHop/J5MBMPoJDwmu4rzxePyAMsW/bDMBDx48ePDy8cRY/C8PxV/3+0k3AOrFffXpf4j42/Hkk/o7mUzw4MGD5z8v6Rsgy/wxnol/V3X7nUst/a9e3FOf/gdGb2HEvyBvMtm4hQTNt5hM8ODBg+c17wdmkTZP9Kinjh0DMM0pLBgGYID42/MkcA6ICfgxkwkePHjw/OTJ6+/pmR71lZ5rA9CZ9oygZxiARcS/PF7eToFMTnjw4MFzgxdF0VM80yOt4doAzKXd+u8oh6ANQB/xL5+3W4EgJic8ePDgOS3+L/FMj/Tde20Aumni31buYN54XoD4V8SbZgKYnPDgwYPnDO9letOfR3o0NAxAb9qmP9MAdDNXCUL8bWpR33e3PQFMTnjw4MFzhvdne/yswKoNQD9Vz9UPtY0cQcS/Jp4E10EzO4DJCQ8ePHhO8K6Stfn+HuvRMNMePsMAdBD/+nmrq6snSLD9FZMTHjx48JzgXSjiv+y5Hg3ylPttI/6z5cXx+m9HUfRtJic8ePDg1c8T0b8y6e63tLQ03xg9Kir8iH/5vM3NjZuJEXha0v2PyQkPHjx4tfCukzX3NePx+OQm6xFi7QhvZWXlWAnKx8jxFSYnPHjw4FXC+0EURS+I4/hWTdcjxNpN3jESoLeR4zxxqF9nssODBw+eFe+Hsp6+Tf7/PktLSwP0qHiRgeER+YbHwKuWl9SgTtIHkz7UYgjemWxWkeMS+fuVEtDXM9nhwYPXdJ6shz9OHqPKcbH8/98lRXzkeJj8fdN8vo8eFS8vODii0tAx8ODBgwcPHjw/eEV+ed+oL7xYQrlgePDgwYMHD16NvLy/vGX0CFgwmgu04MGDBw8ePHh+8DQzzy/vGj0CepblguHBgwcPHjx4s+G1sxYJahk9AvQxZ/nL4cGDBw8ePHj18zqZDIDx4jnj6JTwy+HBgwcPHjx4s+FlMgDtI489Fl/w4MGDBw8ePCd4rWlu4RjjaFn+cnjw4MGDBw+eI7z/DzlJ71Dghd77AAAAAElFTkSuQmCC";
				$scope.ind++;
			});
			$scope.obtieneFoto(0);
		};
		
		/** Valida la respuesta de la busuqeda por CU **/
		$scope.validaRespuesta = function( jsonRespuesta ){
			if( jsonRespuesta && jsonRespuesta != null ){
				try{	    
					switch ( parseInt(jsonRespuesta.codigo) ) {
						case RESPONSE_ORIGINACION_CODIGO_EXITO:
								$scope.seteaDatos( jsonRespuesta, generalService.getPathSection( jsonRespuesta.data, null )  );
							break;
						case 299:
							var nombreCte = $rootScope.solicitudOSJson.cotizacion.clientes[0].nombre+' '+ $rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno+' '+$rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno;
							$rootScope.message("AVISO",["No es posible continuar con la solicitud ya que el cliente  "+nombreCte+"  es un cliente Activo en Micronegocio"], "Aceptar", "/simuladorOS");
							break;
						case 351:
							$rootScope.message("AVISO",["No puede ser Coacreditado, ya que tiene solicitudNOC de cliente en proceso" + $rootScope.solicitudOSJson.idSolicitud], "Aceptar", "/simuladorOS");
						break;
						case 352:
							$rootScope.message("AVISO",["Ya tiene una solicitud de Coacreditado con otro Cliente."], "Aceptar", "/simuladorOS");
						break;
						case 353:
							$rootScope.message("AVISO",["No puede ser Coacreditado porque ya tiene una solicitud de Coacreditado autorizada."], "Aceptar", "/simuladorOS");
						break;
						default:
								$rootScope.message("Homonimos",["Error en la respuesta de código de éxito de originación. Código: " + jsonRespuesta.codigo], "Aceptar", "/simuladorOS");
							break;
					}
			    }catch( e ){
			    	$rootScope.message("ERROR",[ e.message, e, e.type ], "Aceptar", "/simuladorOS");
			    }
		    }else
				$rootScope.message("Homónimos",["Ocurrio un error al validar la respuesta de la solicitud"], "Aceptar", "/simuladorOS");
		};
		
		/** Obtiene la foto del cliente **/
		$scope.seteaDatos = function( jsonRespuesta, path ){			
			/** Validación para el envío de los documentos **/
			var setsolicitudOSJson = function(){	
				if(path !== '/simuladorOS')
					$rootScope.solicitudOSJson = jsonRespuesta.data;
				$scope.agregarIdentificacionOficial("/ochoPasosOS", 0);
				};
			
			var cu = {
					pais: parseInt($scope.persona.fipais),
					canal: parseInt($scope.persona.ficanal),
					sucursal: parseInt($scope.persona.fisucursal),
					folio: parseInt($scope.persona.fifolio)					
				};
			
			clienteUnicoService.getFotoCU(cu).then(
					function(data){
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jRespopnse = JSON.parse(data.data.respuesta);
							
							if( !generalService.isEmpty(jRespopnse.data) ){
								$rootScope.fotoOS = "data:image/png;base64,"+jRespopnse.data;
								$rootScope.fotoCteOriginalOS = jRespopnse.data;
							}																													   						   							
						}
						setsolicitudOSJson();
					},function(error){
						setsolicitudOSJson();
					}
				);
						
		};/* END SETEA DATOS FUNCTION */
		
		
		$scope.fichaRecompra = function( cu, homonimo ){
			var myObject = {
				cu        : cu,
				homonimo  : homonimo,
				origen    : FICHA.origen.homonimos,
				tipoFicha : FICHA.tipoFicha.recompra
			};
			generalService.setDataBridge( myObject );
			generalService.locationPath( "/ficha" );
			
		};/* END FICHA RECOMPRA FUNCTION */
		
		/** La ficha esta bloqueada **/
		$scope.fichaBloqueada = function( cu, homonimo ){
			var myObject = {
				cu        : cu,
				homonimo  : homonimo,
				origen    : FICHA.origen.homonimos,
				tipoFicha : FICHA.tipoFicha.bloqueada
			};
			
			generalService.setDataBridge( myObject );
			generalService.locationPath( "/ficha" );
		};
		
		$scope.agregarIdentificacionOficial = function(_path, index) {
			var esEncolarFirmas = false, esEncolarOCR = false,  tipoCadenaOS = "", cadena="", imagenDatosOCR = [];
			
			if($rootScope.isFirmaAvisoOS){
				tipoCadenaOS="firmaAvisoAval";
				cadena=$rootScope.imgPrivacidadOS;
				esEncolarFirmas = true;
			}else if($rootScope.isFirmaBuroOS){
				tipoCadenaOS="firmaBuroAval";
				cadena=$rootScope.imgBuroOS;
				esEncolarFirmas = true;
			}else if($rootScope.isOCR){
				imagenDatosOCR = generalService.getArrayValue('imgsIFE');
				esEncolarOCR = true;
			}
			
			if(esEncolarFirmas){
				$scope.guardarFirmasOnline(tipoCadenaOS, cadena.replace("data:image/png;base64,","").trim(), _path, index);
			}else if(esEncolarOCR){
				$scope.envioDocumentosEnLinea(imagenDatosOCR,"1",index, _path)
			}else{
				generalService.locationPath(_path);
			}
		};
		
		/** 
		 * Elige los contratos que se enviarán en linea
		 **/
		$scope.guardarFirmasOnline = function(tipoCadena, cadena, path, index) {
			var request = {
				idSolicitudOS: $rootScope.solicitudOSJson.idSolicitud,
				cadena: cadena,
				tipoCadena: tipoCadena,
				porcentaje: "100",
				rechazoFirma: "0"
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.guardaFirmasBiometricosOS(request).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							
							if($rootScope.isFirmaAvisoOS){
								$rootScope.isFirmaAvisoOS = false;
							}else if($rootScope.isFirmaBuroOS){
								$rootScope.isFirmaBuroOS = false;
							}
							
							$scope.agregarIdentificacionOficial(path, index);
						}else{
							generalService.locationPath(path);
						}
					} else {
						generalService.locationPath(path);
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};
		
		
		/** 
		 * Elige los documentos que se enviarán en linea
		 **/
		$scope.envioDocumentosEnLinea = function(imagenDatosOCR,idDocumento,index,path){
			
			for(var i=0;i<$rootScope.solicitudOSJson.documentos.documento.length;i++){
				if(idDocumento === $rootScope.solicitudOSJson.documentos.documento[i].idDocumento){
					$rootScope.solicitudOSJson.documentos.documento[i].status = 4;
				}
			}
			
			var digitDocRequest = {
					idSolicitud: $rootScope.solicitudOSJson.idSolicitud,
					extensionIMG: "jpg",
					imagenB64: imagenDatosOCR[index],
					idDocumento: idDocumento,										
					consecutivoPersona: "0",
					porcentaje: generalServiceOS.porcentajeDocs( $rootScope ).toString()
			};		    			    	

			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.digitalizarImagenOS(digitDocRequest).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
	
					if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
						var responseJson = JSON.parse(data.data.respuesta);														
						
						if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							if(index < (imagenDatosOCR.length-1)){
								index = index + 1;
								$rootScope.solicitudOSJson = responseJson.data;
							}else{
								$rootScope.isOCR = false
								$rootScope.solicitudOSJson = responseJson.data;
							}
							
							$scope.agregarIdentificacionOficial(path,index);
						}else{
							generalService.locationPath(path);
						}
					}else{
						generalService.locationPath(path);
					}
					
				}, function(error){
		            $rootScope.waitLoaderStatus = LOADER_HIDE;	                
				}
			);
		}
		/******  FIN de envío de documentos  ******/
		
		function pad (n, length) {
		    var  n = n.toString();
		    while(n.length < length)
		         n = "0" + n;
		    return n;
		}
	});
});