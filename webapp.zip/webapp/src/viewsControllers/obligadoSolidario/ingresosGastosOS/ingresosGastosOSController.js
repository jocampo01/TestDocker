'use strict';

define(["app"], function (app) {
	
	app.controller("ingresosGastosOSController", function ($timeout, $scope, $rootScope, modalService, generalServiceOS, solicitudService, buroService, messageData, validateService, $filter, $locale,obligadoSolidarioService) {
    	
		var CONCEPTO = [];
		$scope.vistaDatosUsuario = configuracion.datosUsuario.opcion=0;
		$scope.pageClass = generalServiceOS.calculaVistas($rootScope.paginaActual,$rootScope.paginaAnterior,$rootScope.recuperaSolicitud);    
		$scope.dependientes={};
		$scope.dependientes={menores:$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores,mayores:$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores};
		$scope.bloqueaSeccion = $rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.editable;
		$rootScope.flujoEfectivoOS = [];
		$rootScope.showDatosHogarOS = true;	
		$scope.init = function(){
	     	loadView();
					
	     	if(parseInt($rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores) < 0 )
	     		$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores=null;
			
			if(parseInt($rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores) < 0 )
				$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores=null;
			
			generalServiceOS.setRespaldo($rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo,true,
					                   $rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores,
					                   $rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores);
	     	
	     	
			for(var i=0;i<CONCEPTO.length;i++){
				var activaBanderaFE = true;
				
				for(var j=0;j<$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo.length;j++){
					if(CONCEPTO[i].id == $rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo[j].idConcepto){
						var flujoEfectivoAux = $rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo[j];
						flujoEfectivoAux.orderId = CONCEPTO[i].orderId;
						activaBanderaFE = false;
						
						$rootScope.flujoEfectivoOS.push(flujoEfectivoAux);
					}
				}
				
				if(activaBanderaFE){
					$rootScope.flujoEfectivoOS.push({"idTipo": parseInt(CONCEPTO[i].tipo), "tipoDes":CONCEPTO[i].tipoDesc, "idConcepto": CONCEPTO[i].id, "conceptoDes":CONCEPTO[i].descripcion, "monto": "", orderId:CONCEPTO[i].orderId })
				}
			}
											
			if($rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.porcentaje > 0)
				$scope.porcMayor=true;
			
			$rootScope.waitLoaderStatus = LOADER_HIDE;
		};
		
		function loadView(){
			/**
			 * Configuración de las propiedades de la primera sección de Gastos.
			 **/
			$scope.datosFE = [null, {
				  "placeholder": "Luz",
				  "img": "images/icon-form/luz.png",
				  "opcional": false,
				  "visible": true,
				  "longmax": "8",
				  "formato": "NIP-$",
				  "buro": false
				}, {
				  "placeholder": "Agua",
				  "img": "images/icon-form/agua.png",
				  "opcional": false,
				  "visible": true,
				  "longmax": "8",
				  "formato": "NIP-$",
				  "buro": false
				}, null, null, {
				  "placeholder": "Renta",
				  "img": "images/icon-form/renta.png",
				  "opcional": false,
				  "visible": true,
				  "longmax": "8",
				  "formato": "NIP-$",
				  "buro": false
				}, {
				  "placeholder": "Transporte",
				  "img": "images/icon-form/transporte.png",
				  "opcional": false,
				  "visible": true,
				  "longmax": "8",
				  "formato": "NIP-$",
				  "buro": false
				}, {
				  "placeholder": "Teléfono",
				  "img": "images/icon-form/telefono.png",
				  "opcional": false,
				  "visible": true,
				  "longmax": "8",
				  "formato": "NIP-$",
				  "buro": false
				}, {
				  "placeholder": "Gas",
				  "img": "images/icon-form/gas.png",
				  "opcional": false,
				  "visible": true,
				  "longmax": "8",
				  "formato": "NIP-$",
				  "buro": false
				}, {
				  "placeholder": "Comida",
				  "img": "images/icon-form/comida.png",
				  "opcional": false,
				  "visible": true,
				  "longmax": "8",
				  "formato": "NIP-$",
				  "buro": false
				}
			];	
			
			CONCEPTO = [{
				  "id": 1,
				  "descripcion": "LUZ",
				  "tipo": "2",
				  "tipoDesc": "EGRESO",
				  "orderId": 7
				}, {
				  "id": 2,
				  "descripcion": "AGUA",
				  "tipo": "2",
				  "tipoDesc": "EGRESO",
				  "orderId": 6
				}, {
				  "id": 5,
				  "descripcion": "RENTA",
				  "tipo": "2",
				  "tipoDesc": "EGRESO",
				  "orderId": 3
				}, {
				  "id": 6,
				  "descripcion": "TRANSPORTE",
				  "tipo": "2",
				  "tipoDesc": "EGRESO",
				  "orderId": 5
				}, {
				  "id": 7,
				  "descripcion": "TELEFONO",
				  "tipo": "2",
				  "tipoDesc": "EGRESO",
				  "orderId": 8
				}, {
				  "id": 8,
				  "descripcion": "GAS",
				  "tipo": "2",
				  "tipoDesc": "EGRESO",
				  "orderId": 9
				}, {
				  "id": 9,
				  "descripcion": "COMIDA",
				  "tipo": "2",
				  "tipoDesc": "EGRESO",
				  "orderId": 4
				}
			];
		};

		$scope.guardar=function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			save();
		};
		
		function save(){
			var porcentajeAnt = $rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.porcentaje;
			$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.porcentaje = cuentatext('ingresosGastosForm');
			
			/**
			 * Gurda la sección "¿Cuáles son tus gastos fijos mensuales?" dentro del JSON de la solicitud
			 **/
			$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo  = new Array();		
			for(var i=0;i<$rootScope.flujoEfectivoOS.length;i++){
				var monto = parseInt(generalServiceOS.cleanValue( $rootScope.flujoEfectivoOS[i].monto ));
				
				if(monto > 0){
					$rootScope.flujoEfectivoOS[i].monto = monto;
					$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.flujoEfectivo.push($rootScope.flujoEfectivoOS[i]);
				}
			}

			/**
			 * Gurda la sección "¿Tienes dependientes económicos?" dentro del JSON de la solicitud
			 **/
			if (parseInt($rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores) >= 0 && $rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores != ""){
				$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores = parseInt($rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores);
			}else{
				$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores = null;
			}
			
			if (parseInt($rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores) >= 0 && $rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores != ""){
				$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores = parseInt($rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores);
			}else{
				$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores = null;
			}
			
			var solicitudOSJsonString = generalServiceOS.delete$$hashKey($rootScope.solicitudOSJson);			

			obligadoSolidarioService.guardaSeccionOS( { solicitudOSJson: solicitudOSJsonString, seccion: SECCION_INGRESOS_GASTOS } ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;

					if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
						var responseJson = JSON.parse(data.data.respuesta);
						if(responseJson.codigo == 2){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							$rootScope.solicitudOSJson = responseJson.data;
							$rootScope.calculaDocumentos();
							$scope.datosActuales = JSON.stringify(DatosAnterioresArreglo('ingresosGastosForm'));

							$rootScope.porcentajes.secciones[3].porcentaje = $rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.porcentaje;										
							
							solicitudService.validaFolioCallCenterOS(solicitudOSJsonString, responseJson.data).then(
									function(data){
										if(data == null){
											buroObligadoSolidarioService.consultaBuro( $scope.titulo.colorModal, "btn gris","btn naranja", null, null, consultarBuro, null );
										}else
											generalServiceOS.locationPath(data);
									},function(error){
										console.log("Error: " + error);
										generalServiceOS.locationPath("/ochoPasosOS");
									}
							);
						}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
							var buildJsonDefault=function(){generalServiceOS.buildsolicitudOSJson($rootScope, null);};
							$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
						}else if(responseJson.codigo == ERROR_SOL_RECHAZADA){
							var buildJsonDefault=function(){generalServiceOS.buildsolicitudOSJson($rootScope, null);};
							$rootScope.message(	"Error en solicitud", [ "La solicitud no puede ser modificada debido a que se encuentra Cancelada o Rechazada." ], "Aceptar", "/simulador",  "bgVerde" , "verde",buildJsonDefault);
						}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
							generalServiceOS.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
							generalServiceOS.locationPath("/ficha");
						}else{
							$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.porcentaje = porcentajeAnt;
							$rootScope.message("Gastos",["Error al guardar sección. Código de error [" + responseJson.codigo + "] no identificado."], "Aceptar", null, "bgVerde", "verde");
						}
					}else{
						$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.porcentaje = porcentajeAnt;
						$rootScope.message("Gastos",["Error en la respuesta del servicio para guardar los datos de la sección de Gastos. Por favor, reintente nuevamente."], "Aceptar", null, "bgVerde", "verde");							
					}
				}, function(error){
					$rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.porcentaje = porcentajeAnt;					
	                $rootScope.waitLoaderStatus = LOADER_HIDE;
				}
			);
		};				
	});
});