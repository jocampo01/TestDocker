'use strict';

define(["app"], function (app) {

    app.controller("compDomicilioOSModalController", function ( $scope, $rootScope, $location, $timeout, generalService, modalService) {
    	
    	$scope.compDomicilioObj = {id:null, tipo:null,anio:null, mes:null,dia:null, imagen:null, subTipo: null}
    	$scope.listaComDomicilio = new Array();
    	$scope.msj = "";
    	
    	
		$scope.init = function(documentoId){
    		$scope.compDomicilioObj.id = documentoId;
			loadView();						
		};
		
		
		$scope.$watch("compDomicilioObj.imagen",function(){
			if( $scope.compDomicilioObj.imagen!=null )
				loadData();							
		},true);
		
		
		$scope.fotoImagenIpad = function(){
			loadData();
		};
		
		function loadData(){						
			if($scope.compDomicilioObj.tipo.id == 8)
				$scope.compDomicilioObj.oficial = true;
			
			angular.element("[ng-controller='docsExpedienteOSController']").scope().setCompDomicilio( $scope.compDomicilioObj );
			$scope.closeThisDialog();				
		};
		
		
		$scope.validadias = function(dia){
	 	   if (!dia){
		 	   $scope.vDia=$scope.compDomicilioObj.dia;
		 	   
		 	   var year = new Date().getFullYear();
		 	   		 	   
		 	   if( $scope.compDomicilioObj.anio && $scope.compDomicilioObj.anio != null )
		 		   year =  $scope.compDomicilioObj.anio;
		 	   		 			   
		 	   if (parseInt($scope.compDomicilioObj.mes) && parseInt(year)){
		          $scope.aniobisiesto(year,$scope.compDomicilioObj.mes);
		          $scope.compDomicilioObj.dia=$scope.vDia;
		 	   }
	 	   }		 	  
		};
		
		
		$scope.aniobisiesto = function(vAnno,vMes){
		 		$scope.days=[];
		 		if ((vAnno % 4 == 0) && ((vAnno % 100 != 0) || (vAnno % 400 == 0))) {
		 			if (vMes == "02"){
		 				$scope.days = dias.slice(0,29);
		 				if ($scope.vDia>"29")
		 					$scope.vDia="29";
		 			}
		 		}else{
		 			if (vMes == "02"){
		 				$scope.days = dias.slice(0,28);
		 				if ($scope.vDia>"28")
		 					$scope.vDia="28";
		 			}
		 		}
		 		if (vMes=="04"||vMes=="06"||vMes=="09"||vMes=="11"){
		 			$scope.days = dias.slice(0,30);
		 			if ($scope.vDia>"30")
		 				$scope.vDia="30";
		 		}
		 		if (vMes=="01"||vMes=="03"||vMes=="05"||vMes=="07"||vMes=="08"||vMes=="10"||vMes=="12")			    		
		 			$scope.days = dias;
		 		if(parseInt($scope.mesActual) == parseInt(vMes)){
		 			$scope.days=dias.slice(0,parseInt($scope.diaActual));
		 			if(parseInt($scope.vDia) > $scope.diaActual)
		 				$scope.vDia=$scope.diaActual;
		 		}
		 };
		
		function loadView(){				
			var origen = configuracion.origen.tienda ? "TIENDA":"WEB";
			$scope.isTienda = configuracion.origen.tienda;
			
			$scope.btnGuardar = generalService.getDataInput("EXPEDIENTE","BOTON GUARDAR", origen );
			$scope.titulo             = generalService.getDataInput("MODAL COMP DOM","TITULO",origen);
			$scope.etiquetaTipoComprobante = generalService.getDataInput("MODAL COMP DOM","ETIQUETA TIPO COMPROBANTE",origen);
			$scope.etiquetaSelectDefault = generalService.getDataInput("MODAL COMP DOM","ETIQUETA SELECT DEFAULT VALUE",origen);
			$scope.botonContinuar = generalService.getDataInput("MODAL COMP DOM","BOTON CONTINUAR",origen);
			$scope.etiquetaFechaEmision = generalService.getDataInput("MODAL COMP DOM","ETIQUETA FECHA EMISION",origen);
			$scope.etiquetaFechaAnti = generalService.getDataInput("MODAL COMP DOM","ETIQUETA FECHA ANTIGÜEDAD",origen);
			$scope.etiquetaFechaActual = generalService.getDataInput("MODAL COMP DOM","ETIQUETA FECHA ACTUAL",origen);
						
			var catalogoTiposCompDomicilio = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.COMPROBANTES DE DOMICILIO VALIDOS"];			
			for (var i = 0; i < catalogoTiposCompDomicilio.length; i++)					
					$scope.listaComDomicilio.push({id:parseInt(catalogoTiposCompDomicilio[i].ID.valor), descripcion:catalogoTiposCompDomicilio[i].DESCRIPCION.valor});												
			
			var listaComDomicilioCfe = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.COMPAÑIAS DE LUZ"];
			var listaComDomicilioTelmex =	MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.COMPAÑIAS DE TELEFONO"];
			$scope.listaComDomicilioCfe = [];
			$scope.listaComDomicilioTelmex = [];
			
			for (var i = 0; i < listaComDomicilioCfe.length; i++)					
				$scope.listaComDomicilioCfe.push({id:parseInt(listaComDomicilioCfe[i].ID.valor), descripcion:listaComDomicilioCfe[i].ETIQUETA.valor});
			
			for (var i = 0; i < listaComDomicilioTelmex.length; i++)					
				$scope.listaComDomicilioTelmex.push({id:parseInt(listaComDomicilioTelmex[i].ID.valor), descripcion:listaComDomicilioTelmex[i].ETIQUETA.valor});
					
						
			var hoy = new Date();
			$scope.diaActual = hoy.getDate();
			$scope.mesActual = hoy.getMonth() + 1;
			var anioActual = hoy.getFullYear();
			var fechaVigente = new Date();
			fechaVigente.setMonth(hoy.getMonth() - 3);
			var anioVigente = fechaVigente.getFullYear();
			var mesVigente = fechaVigente.getMonth();
			
			$scope.days = dias;
//			$scope.meses = meses;
			$scope.meses = [];
			for(var i=parseInt(mesVigente);$scope.meses.length < 4;i++){
				if(i > 11)
					i = 0;
				$scope.meses.push(meses[i]);
			}
			$scope.annos = new Array();
			
			if(anioActual != anioVigente){
				$scope.annos.push(anioVigente);
				$scope.annos.push(anioActual);
			}else
				$scope.annos.push(anioActual);
												
						
		};	
		
		
		$scope.validaTipoComporbante = function (){ 
			$scope.compDomicilioObj.subTipo = null;
			switch($scope.compDomicilioObj.tipo.id) {
		    case RECIBO_TELEFONO:
		    	$scope.telmex = false;
		    	$scope.cfe = false;
		        break;
		    case RECIBO_LUZ:
		    	$scope.cfe = true;
		    	$scope.telmex = false;
		        break;
		    default:
		    	$scope.cfe = false;
	    		$scope.telmex = false;
		    	break;		       
			}
		}

	});
	
	
});