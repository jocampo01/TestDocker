'use strict';

define(["app"], function (app) {

    app.controller("identificacionOficialOSModalController", function ( $scope, $rootScope, $timeout, documentosService, expedienteService, generalService) {
    		
			var fechaDia = new Date();
			var dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
			var mm = ((fechaDia.getMonth() + 1) < 10 ? '0' : '') + (fechaDia.getMonth() + 1);
			var aa = fechaDia.getFullYear();
			
			$scope.identificacionObj = {id:null, tipo:null,anio:null, mes:"12",dia:"31", imagen:null, folio:null};
			
			$scope.disabledFolio=true;
			$scope.identificaciones = [];					
			
			
			$scope.init=function(documentoId){
				$scope.identificacionObj.id = documentoId;
				
				var origen = configuracion.origen.tienda ? "TIENDA":"WEB";
				$scope.ori=origen;
				$scope.isTienda = configuracion.origen.tienda ? true:false;
				
				$scope.tituloAdjunta              = generalService.getDataInput("ADJUNTAR DOCUMENTO","TITULO"                      ,origen);
				$scope.etiquetaTipoIdentificacion = generalService.getDataInput("ADJUNTAR DOCUMENTO","ETIQUETA TIPO IDENTIFICACION",origen);
				$scope.tipoIdentificacion         = generalService.getDataInput("ADJUNTAR DOCUMENTO","TIPO IDENTIFICACION"         ,null);
				$scope.idExpiracion         = generalService.getDataInput("ADJUNTAR DOCUMENTO","ETIQUETA ID EXPIRACION"         ,origen);

				$scope.folioIdentificacion = {
						"tipoElemento"  : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.TIPOELEMENTO[1].valor"],
						"campo"         : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.CAMPO[1].valor"],
						"marcaAgua"     : "Folio Identificación",
						"visible"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.VISIBLE[1].valor"],
						"deshabilitado" : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.DESHABILITADO[1].valor"],
						"obligatorio"   : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.OBLIGATORIO[1].valor"],
						"estilo"        : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.ESTILO[1].valor"],
						"imagen"        : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.IMAGEN[1].valor"],
						"longMin"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.LONGMIN[1].valor"],
						"longMax"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.LONGMAX[1].valor"],
						"formato"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.FORMATO[1].valor"]
				
				};
				
				$scope.fecha={
						nDia:"",
						nMes:"",
						nAnno:""
				};
				
				$scope.vigenciaIdent = {
						marcaAgua : "Vigencia de Identificación",
						visible : true,
						deshabilitado: true,
						obligatorio: true,
						estilo: "inpuSelect",
						imagen: "images/icon-form/calendario.png"	
				};
				
				$scope.vigenciaPerm = {
						marcaAgua : "Vigencia de Licencia",
						visible : true,
						deshabilitado: false,
						obligatorio: true,
						estilo: "inpuSelect",
						imagen: "images/icon-form/calendario.png"	
				};
				
				$scope.mDia = {
						campo: "nDia",
						marcaAgua : "Día",
						visible : true,
						deshabilitado: false,
						obligatorio: true,
						estilo: "inpuSelect active",
						imagen: "images/icon-form/calendario.png"
							
				};
				
				$scope.mMes = {
						campo: "nMes",
						marcaAgua : "Mes",
						visible : true,
						deshabilitado: false,
						obligatorio: true,
						estilo: "inpuSelect active"
				};
				
				$scope.mAnio = {
						campo: "nAnno",
						marcaAgua : "Año",
						visible : true,
						deshabilitado: false,
						obligatorio: true,
						estilo: "inpuSelect active"
				};
				
				$scope.btnContinuar              = generalService.getDataInput("ADJUNTAR DOCUMENTO","BOTON CONTINUAR"              ,origen);
				
				
				if($rootScope.solicitudOSJson.cotizacion.clientes[0].idNacionalidad > NAC_MEXICANA)
					$scope.identificaciones[0] = {id:IDENT_FME, descripcion:"FME"}					
				else{
					var catalogoIdentificacion = MODEL_CATALOGOS_JSON["PRESTAMOS - CATALOGOS.PRESTAMOS - CATALOGOS.CATALOGO DE IDENTIFICACIONES VÁLIDAS"];	
					if(generalService.isDefined(catalogoIdentificacion)){
						for (var ind = 0; ind < catalogoIdentificacion.length; ind++){
							if (ind < 2){
								$scope.identificaciones[ind]={id:parseInt(catalogoIdentificacion[ind].ID.valor),descripcion:catalogoIdentificacion[ind].ETIQUETA.valor};
							}
						}
					}
				}
				
								
				var tiempoVigencia = 20; // MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.CONSTANTES.VIGENCIA IDENTIFICACION.VALOR.valor"];
				var annosVigencia  = [];
				var i = 0;
				for(var a = aa/* - tiempoVigencia*/; a < aa + tiempoVigencia; a++){
					annosVigencia[i]=a;
					i++;
				}
				$scope.days = dias;
				$scope.months = meses;			 				
				var arrayVigenciaLicencia=[];
				arrayVigenciaLicencia=[
				    {
					id:1,
					descPermanente:"Permanente"
					},
					{
					id:2,
					descPermanente:"Con expedición"
					}
				]
				
				$scope.combos = {"annosVigencia":annosVigencia,"arrayVigenciaLicencia":arrayVigenciaLicencia};
			};
						
			
			$scope.$watch("identificacionObj.imagen",function(){
				console.log('imagen ');
				
				if ($scope.identificacionObj.imagen !=  null){						
					console.log('IMAGEN ');									
					angular.element("[ng-controller='docsExpedienteOSController']").scope().sendIentificacionOficial( $scope.identificacionObj);						
					$scope.closeThisDialog();							
				}
								
			},true);
						
			
			
			$scope.cargaIFE=function(){							
					angular.element("[ng-controller='docsExpedienteOSController']").scope().sendIentificacionOficial( $scope.identificacionObj );					
					$scope.closeThisDialog();				
			};
			
			$scope.fechaVigencia = function(){
				if (parseInt($scope.identificacionObj.anio)){
					if($scope.identificacionObj.anio >= aa)										
						$scope.vigenciaError = false;
					else
						$scope.vigenciaError = true;
					$scope.colorLetraInputVigencia = false;
				}
			};
			
			$scope.vigenciaLicencia=function(vigenciaPermanente){
				if(parseInt(vigenciaPermanente)){
					$scope.vigenciaError=false;
					$scope.colorLetraInputVigLicencia=false;
					$scope.formIdentificacion.nAnno.$touched=false;
					$scope.formIdentificacion.nMes.$touched=false;
					$scope.formIdentificacion.nDia.$touched=false;
					if(vigenciaPermanente == 1){
						$scope.mostrarFecha=false;
						$scope.vigPermanente=true;
						  $scope.identificacionObj.anio="2100";
			 	      	  $scope.identificacionObj.mes="12";
			 	      	  $scope.identificacionObj.dia="31";
					}else{
						$scope.mostrarFecha=true;
						$scope.vigPermanente=false;
					}
					$timeout(function(){
						$scope.fecha.nAnno="";
						$scope.fecha.nMes="";
						$scope.fecha.nDia="";
					},1);
				}
			};
			
			$scope.validadias = function(dia){
		 	   if (!dia){
			  	   var vAnno="";
			 	   var vMes="";
			 	   $scope.vDia=$scope.fecha.nDia;
			 	   if (parseInt($scope.fecha.nMes) && parseInt($scope.fecha.nAnno)){
			 		  vAnno=$scope.fecha.nAnno;
			 		  vMes=$scope.fecha.nMes;
			           $scope.aniobisiesto(vAnno,vMes);
			           $scope.fecha.nDia=$scope.vDia;
			 	   }
		 	   }
		 	   if (parseInt($scope.fecha.nDia) && parseInt($scope.fecha.nMes) && parseInt($scope.fecha.nAnno)){
		 		  if($scope.validaFecha()){
		 			  $scope.vigenciaError = false;
		 			  $scope.identificacionObj.anio=$scope.fecha.nAnno;
		 	      	  $scope.identificacionObj.mes=$scope.fecha.nMes;
		 	      	  $scope.identificacionObj.dia=$scope.fecha.nDia;
		 		  }else{
		 			 $scope.vigenciaError = true;
		 		  }
		 	   }
		  	};
		  	
		  	$scope.validaFecha=function(){
		  		var fechaFinal = new Date();
		  		var fechaInicial = aa+"/"+mm+"/"+dd;
		  		if($scope.validaExpedicion)
		  			fechaFinal.setFullYear(fechaDia.getFullYear() - $scope.tiempoDocumento);
		  		else
		  			fechaFinal.setFullYear(fechaDia.getFullYear() + $scope.tiempoDocumento);
		  		var ddFin = (fechaFinal.getDate() < 10 ? '0' : '') + fechaFinal.getDate();
				var mmFin = ((fechaFinal.getMonth() + 1) < 10 ? '0' : '') + (fechaFinal.getMonth() + 1); 
				var aaFin = fechaFinal.getFullYear();
				var fechaVigente = aaFin+"/"+mmFin+"/"+ddFin;
				var fechaSelec = $scope.fecha.nAnno+"/"+$scope.fecha.nMes+"/"+$scope.fecha.nDia;
				if($scope.validaExpedicion){
					if(fechaSelec >= fechaVigente && fechaSelec <= fechaInicial)
						return true;
					else{
						if(fechaSelec > fechaInicial)
							$scope.idExpiracion.texto = "Ingrese la fecha de expedición de su identificación";
						if(fechaSelec < fechaVigente)
							$scope.idExpiracion.texto = "La identificación debe estar expedida no más de " + $scope.tiempoDocumento + " años";
						return false;
					}
				}else{
					if(fechaSelec >= fechaInicial && fechaSelec <= fechaVigente)
						return true;
					else
						return false;
				}
		  	}
		 		 	
		 	$scope.aniobisiesto = function(vAnno,vMes){
		 		$scope.days=[];
		 		if ((vAnno % 4 == 0) && ((vAnno % 100 != 0) || (vAnno % 400 == 0))) {
		 			if (vMes == "02"){
		 				$scope.days = dias.slice(0,29);
		 				if ($scope.vDia>"29")
		 					$scope.vDia="29";
		 			}
		 		}else{
		 			if (vMes == "02"){
		 				$scope.days = dias.slice(0,28);
		 				if ($scope.vDia>"28")
		 					$scope.vDia="28";
		 			}
		 		}
		 		if (vMes=="04"||vMes=="06"||vMes=="09"||vMes=="11"){
		 			$scope.days = dias.slice(0,30);
		 			if ($scope.vDia>"30")
		 				$scope.vDia="30";
		 		}
		 		if (vMes=="01"||vMes=="03"||vMes=="05"||vMes=="07"||vMes=="08"||vMes=="10"||vMes=="12")			    		
		 			$scope.days = dias;
		 	};
									
			
			$scope.cambioIdent=function(){
				
				
				$scope.idExpiracion = generalService.getDataInput("ADJUNTAR DOCUMENTO","ETIQUETA ID EXPIRACION"         ,$scope.ori);
				$scope.validaExpedicion=false;
				$scope.vigPermanente=false;
				$scope.vigenciaPermanente="";
				$scope.identificacionObj.folio="";
				$scope.identificacionObj.dia="";
				$scope.identificacionObj.mes="";
				$scope.identificacionObj.anio = "";
				$scope.colorLetraInputVigencia = true;
				$scope.colorLetraInputVigLicencia=true;
				$scope.formIdentificacion.folioIdentificacion.$touched=false;
				$scope.formIdentificacion.vigenciaIdentificacion.$touched=false;
				$scope.formIdentificacion.nVigenciaPerm.$touched=false;
				$scope.formIdentificacion.nAnno.$touched=false;
				$scope.formIdentificacion.nMes.$touched=false;
				$scope.formIdentificacion.nDia.$touched=false;
				$scope.mostrarFecha=false;
				$scope.vigenciaError = false;
				if($scope.identificacionObj.tipo != null){
					$scope.disabledFolio=false;
					if($scope.identificacionObj.tipo.id == 1){
						$scope.folioIdentificacion = {
							"tipoElemento"  : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.TIPOELEMENTO[1].valor"],
							"campo"         : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.CAMPO[1].valor"],
							"marcaAgua"     : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.MARCAAGUA[1].valor"],
							"visible"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.VISIBLE[1].valor"],
							"deshabilitado" : false,
							"obligatorio"   : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.OBLIGATORIO[1].valor"],
							"estilo"        : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.ESTILO[1].valor"],
							"imagen"        : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.IMAGEN[1].valor"],
							"longMin"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.LONGMIN[1].valor"],
							"longMax"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.LONGMAX[1].valor"],
							"formato"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.FORMATO[1].valor"]
						};
						$scope.vigenciaIdent.marcaAgua="Vigencia de ID"
					}else{
						$scope.folioIdentificacion = {
							"tipoElemento"  : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.TIPOELEMENTO[2].valor"],
							"campo"         : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.CAMPO[2].valor"],
							"marcaAgua"     : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.MARCAAGUA[2].valor"],
							"visible"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.VISIBLE[2].valor"],
							"deshabilitado" : false,
							"obligatorio"   : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.OBLIGATORIO[2].valor"],
							"estilo"        : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.ESTILO[2].valor"],
							"imagen"        : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.IMAGEN[2].valor"],
							"longMin"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.LONGMIN[2].valor"],
							"longMax"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.LONGMAX[2].valor"],
	//						"formato"       : MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.ADJUNTAR DOCUMENTO.FOLIO IDENTIFICACION.FORMATO[2].valor"]
							"formato"       : "LMN"
						};
						$scope.years = [];
						var i=0;
						$scope.tiempoDocumento=20;
						switch($scope.identificacionObj.tipo.id){
							case 2:
								$scope.folioIdentificacion.marcaAgua="No. de Pasaporte";
								$scope.vigenciaIdent.marcaAgua="Vigencia";
								$scope.tiempoDocumento=5;
								$scope.mostrarFecha=true;
								for(var a = aa/* - tiempoVigencia*/; a < aa + $scope.tiempoDocumento; a++){
									$scope.years[i]=a;
									i++;
								}
								break;
							case 3:
								$scope.folioIdentificacion.marcaAgua="No. de Cédula";
								$scope.vigenciaIdent.marcaAgua="Fecha de expedición (máxima 10 años)";
								$scope.tiempoDocumento=10;
								$scope.mostrarFecha=true;
								for(var a = aa - $scope.tiempoDocumento; a <= aa; a++){
									$scope.years[i]=a;
									i++;
								}
								$scope.validaExpedicion=true;
								break;
							case 4:
								$scope.folioIdentificacion.marcaAgua="No. de Licencia";
								$scope.vigenciaIdent.marcaAgua="Vigencia";
								$scope.tiempoDocumento=3;
								for(var a = aa/* - tiempoVigencia*/; a < aa + $scope.tiempoDocumento; a++){
									$scope.years[i]=a;
									i++;
								}
								break;
							case 5:
								$scope.folioIdentificacion.marcaAgua="Matrícula";
								$scope.vigenciaIdent.marcaAgua="Fecha de expedición (menor a 3 años)";
								$scope.tiempoDocumento=3;
								$scope.mostrarFecha=true;
								for(var a = aa - $scope.tiempoDocumento; a <= aa; a++){
									$scope.years[i]=a;
									i++;
								}
								$scope.validaExpedicion=true;
								break;
							case 6:
								$scope.folioIdentificacion.marcaAgua="Nacionalidad";
								$scope.vigenciaIdent.marcaAgua="Vigencia";
								$scope.tiempoDocumento=3;
								$scope.mostrarFecha=true;
								for(var a = aa/* - tiempoVigencia*/; a < aa + $scope.tiempoDocumento; a++){
									$scope.years[i]=a;
									i++;
								}
								break;
							case 7:
								$scope.folioIdentificacion.marcaAgua="NSS";
								$scope.vigenciaIdent.marcaAgua="Vigencia";
								$scope.tiempoDocumento=10;
								$scope.mostrarFecha=true;
								for(var a = aa - $scope.tiempoDocumento; a <= aa; a++){
									$scope.years[i]=a;
									i++;
								}
								$scope.validaExpedicion=true;
								break;
						}
						
					}
					$scope.vigenciaIdent.deshabilitado=false;
					$timeout(function(){
						$scope.fecha.nAnno="";
						$scope.fecha.nMes="";
						$scope.fecha.nDia="";
					},1);
				}
			};						
											

	});
	
	
});