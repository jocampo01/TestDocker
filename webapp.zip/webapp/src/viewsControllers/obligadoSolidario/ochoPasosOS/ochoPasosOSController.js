'use strict';

define(['app'], function(app){
	app.controller("ochoPasosOSController", function($scope, $rootScope, generalService, $timeout, clienteUnicoService, buroObligadoSolidarioService, generalServiceOS, solicitudService, modalService, obligadoSolidarioService){
		
		/****************************************
		 * FUNCIONES QUE SE EJECUTAN EN EL INIT *
		 ****************************************/
		$rootScope.showDatosHogarOS = false;
		
		$scope.cotizar = ( $rootScope.solicitudOSJson.consultaBuro == 1 && $rootScope.solicitudOSJson.consultaMatriz == 0 ) || 
						 ( $rootScope.solicitudOSJson.consultaBuro == 0 && $rootScope.solicitudOSJson.consultaMatriz == 1 ) || 
						 ( $rootScope.termometroHandlerOS == false && $rootScope.solicitudOSJson.consultaBuro == 0 && $rootScope.solicitudOSJson.consultaMatriz == 0 ) || 
						 ( ( $rootScope.solicitudOSJson.consultaBuro == 0 || $rootScope.solicitudOSJson.consultaMatriz == 0 ) &&
						 ( $rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].porcentaje == 100 && $rootScope.solicitudOSJson.cotizacion.clientes[0].porcentaje == 100 ) );
		
		$rootScope.ipad=configuracion.origen.tienda;
		$scope.esIpad = configuracion.so.ios;
		var porcentajeOS = generalService.evaluaAgendaCita($rootScope.solicitudOSJson, $scope.menuListOS);
		$rootScope.solicitudJson.obligadoSolidario.idSolicitudObligadoSolidario = $rootScope.solicitudOSJson.idSolicitud;
		
		$scope.init = function(){
			/*\Se agrega un evento para la bitacora\*/
			//(coacreditado)
				$rootScope.addEvent( BITACORA.SECCION.coacreditado.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, 0, BITACORA.SECCION.coacreditado.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/	
			
			
			$rootScope.solicitudOSJson.contratos.porcentaje = validaPorcentajeContratos();
			
			if(!validaFlujoCallCenter()){
				if( $rootScope.solicitudOSJson.cotizacion.clientes[0].clienteUnico != "" && pathSeccion[  window.location.hash ] === "#/ochoPasos"){
					validaHuella($rootScope.solicitudOSJson.cotizacion.clientes[0].clienteUnico);
				}else{
					$rootScope.isFotoCliente = false;
					inicializaVista();
				}
			}else{
				flujoCallCenter();
			}
		}
		
		function validaFlujoCallCenter(){
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) == -1 && $rootScope.consultaFuncionalidad.flujoMesaAltaUnica && $rootScope.solicitudOSJson.idSeguimiento == STATUS_SOLICITUD.generada.id && $rootScope.solicitudOSJson.folioCallCenter == "" && $rootScope.solicitudOSJson.tipoIdentificacion == 2){
				return true;
			}
			
			return false;
		}
		
		function flujoCallCenter(){
			generalService.setArrayValue("solicitarIDComplementaria", true);
			generalService.setArrayValue("pasoCallCenter", 'init');
			generalService.setArrayValue("encolarImagenes", true);
			generalService.setArrayValue("cusArray", null);
			generalService.setArrayValue("pathOrigen", 'simuladorOS');
			generalService.locationPath("/callCenterOS");
		}
				
		var validaHuella=function(cu){
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) > -1){
				$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
			}else if(configuracion.origen.tienda){
				$rootScope.waitLoaderStatus = LOADER_SHOW;							
				$rootScope.verificarHuella( 'fondoDivId', 'responseVerificarHuellaIpad', [cu]);
			}else if(generalService.isProduccion()){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				modalService.huellaModal("bgAzul");
			}else{
				$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
			}
		};
		
		$scope.responseVerificarHuellaIpad = function( response ){
			$rootScope.loggerIpad("responseVerificarHuellaIpad", null, response);
			switch(response.codigo){
				case VALIDA_HUELLA_RESPONSE.EXITO:
					$rootScope.isFotoCliente = false;
					inicializaVista();
					break;
					
				case VALIDA_HUELLA_RESPONSE.ERROR:
					goSimulador();
					break;
					
				case VALIDA_HUELLA_RESPONSE.ERROR_COMPONENTE:
					goSimulador();
					break;
					
				case VALIDA_HUELLA_RESPONSE.COMPONENTE_CANCELADO_PORUSR:
					goSimulador();
					break;
					
				case VALIDA_HUELLA_RESPONSE.NO_SE_ENCONTARON_HUELLAS:
					goSimulador();
					break;
					
				case VALIDA_HUELLA_RESPONSE.NO_HAY_COINCIDENCIAS:
					goSimulador();
					break;
					
				default:
					goSimulador();
					break;
			}
		};
		var goSimulador = function(){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			generalService.buildSolicitudOSJson($rootScope, null);
			generalService.buildSolicitudJson($rootScope, null );			
			generalService.locationPath("/simulador");
		};
		
		function inicializaVista(){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if( configuracion.origen.tienda )
				$scope.origen = "TIENDA";
			else
				$scope.origen = "WEB";
			
			$scope.obtenerProcentaje();
			$scope.buildMenuListOS();
			$scope.nombrePersonaMinusculas();
			$timeout( loadProgressbar, 0 );
			
			if( !generalService.isEmpty($rootScope.solicitudOSJson.folioCallCenter) && $rootScope.solicitudOSJson.respuestaCallCenter==STATUS_CALL_CENTER_RESPONSE.IDENTIFICACION_NO_VALIDA){
				modalService.confirmModal("Call Center", ["No es posible continuar. La identificación presentada por el Coacreditado no es válida.", "¿Desea generar un nuevo folio de Call Center?"], 
		                  "Cancelar", "Aceptar").then(
		                		  
								  function(exito){
									  $rootScope.waitLoaderStatus = LOADER_HIDE;
									  	if($rootScope.fotoCteOriginal)
									  		generalService.setArrayValue("pasoCallCenter", 'IFE');
										else
											generalService.setArrayValue("pasoCallCenter", 'foto');
									  	generalService.locationPath("/callCenterOS");
								  },function(error){
									  $rootScope.waitLoaderStatus = LOADER_HIDE;
									  generalService.locationPath("/ochoPasos");	  														
								  }
				);
			}
			
			
			
		}
		
		
		/**
		 * Se ejecuta el servicio para validar el estatus del folio de callcenter del Coacreditado
		 **/
		function validaEstatusCallCenter(solicitudOSJsonString){
			solicitudService.validaFolioCallCenterOS(JSON.parse(solicitudOSJsonString), JSON.parse(solicitudOSJsonString), $scope.$parent.origenCallCenter).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.locationPath(data);
					$scope.$parent.origenCallCenter = 0;
				},function(error){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.locationPath(data);
					$scope.$parent.origenCallCenter = 0;
				}
			);
		}
		
		$scope.buildMenuListOS = function(){

			$scope.menuListOS = [
				{
					texto: "Datos del Coacreditado",
					labelAvance: $scope.labelAvance,
					porcentaje: ($rootScope.solicitudOSJson.cotizacion.clientes[0].porcentaje + $rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].porcentaje)/2,
					path: '/datosCoacreditado',
					image: 'images/menu/opDatosPersonales.jpg',
					alt: "Datos del Coacreditado",
					progressbar: 'progressbar_opDatosPersonalesOS',
					estilo: 'opc opDatosPersonales',
					showAlerta: false,
					showAuth: $rootScope.solicitudOSJson.consultasRealizadasEvaluacion == 1,
					numAlerta: '1',
					tituloAlert: '',
					messageAlert: '',
					showMessageAlert: false,
				    vistaPorcentaje:  true,
				    messageAuth: '',
					showMessageAuth: $rootScope.solicitudOSJson.consultasRealizadasEvaluacion == 1,
					show: true,
				    bloqueo: $rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].bloqueado == 1 && $rootScope.solicitudOSJson.cotizacion.clientes[0].bloqueado == 1,
				    prioridad: 1
				}/*,
				{
					texto: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS BASICOS."+$scope.origen+".valor"],
					labelAvance: $scope.labelAvance,
					porcentaje: $rootScope.solicitudOSJson.cotizacion.clientes[0].porcentaje,
					path: '/datosBasicosOS',
					image: 'images/menu/opDatosPersonales.jpg',
					alt: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS BASICOS."+$scope.origen+".valor"],
					progressbar: 'progressbar_opDatosPersonalesOS',
					estilo: 'opc colIzq opDatosPersonales',
					showAlerta: false,
					showAuth: false,
					numAlerta: '1',
					tituloAlert: '',
					messageAlert: '',
					showMessageAlert: false,
				    vistaPorcentaje:  true,
				    messageAuth: '',
					showMessageAuth: false,
					show: false,
				    bloqueo: "",
				    prioridad: 1	
				 }*/,{
					texto: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS HOGAR."+$scope.origen+".valor"],
					labelAvance: $scope.labelAvance,
					porcentaje: $rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].porcentaje,
					path: '/datosHogarOS',
					image: 'images/menu/opDatosHogar.jpg',
					alt: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS HOGAR."+$scope.origen+".valor"],
					progressbar: 'progressbar_opDatosHogarOS',
					estilo: 'opc opDatosHogar',
					showAlerta: false,
					showAuth: false,
					numAlerta: '1',
					tituloAlert: '',
					messageAlert: '',
					showMessageAlert: false,
					messageAuth: '',
					showMessageAuth: false,
				    vistaPorcentaje:  true,
				    show: false,
				    bloqueo: "",
				    prioridad: 2
				 },
				 {
					texto: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS EMPLEO."+$scope.origen+".valor"],
					labelAvance: $scope.labelAvance,
					porcentaje: $rootScope.solicitudOSJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje,
					path: '/datosEmpleoOS',
					image: $rootScope.solicitudOSJson.cotizacion.clientes[0].datosEmpleo[0].bloqueado!=0? 'images/menu/opDatosEmpleo_disabled.jpg':'images/menu/opDatosEmpleo.jpg',
					alt: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS EMPLEO."+$scope.origen+".valor"],
					progressbar: $rootScope.solicitudOSJson.cotizacion.clientes[0].datosEmpleo[0].bloqueado!=0?'':'progressbar_opDatosEmpleoOS',
					estilo: $rootScope.solicitudOSJson.cotizacion.clientes[0].datosEmpleo[0].bloqueado!=0?'opc  opMenuDisabled':'opc  opDatosEmpleo',
					showAlerta: false,
					showAuth: false,
					numAlerta: '1',
					tituloAlert: '',
					messageAlert: '',
					showMessageAlert: false,
					messageAuth: '',
					showMessageAuth: false,
				    vistaPorcentaje:  true,
				    show: false,
				    bloqueo: 1,
				    prioridad:3
				},
				{
					texto: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO INGRESOS GASTOS."+$scope.origen+".valor"],
					labelAvance: $scope.labelAvance,
					porcentaje: $rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.porcentaje,
					path: '/ingresosGastosOS',
					image: 'images/menu/opIngresosGastos.jpg',
					alt: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO INGRESOS GASTOS."+$scope.origen+".valor"],
					progressbar: 'progressbar_opIngresosGastosOS',
					estilo: 'opc opIngresosGastos',
					showAlerta: false,
					showAuth: false,
					numAlerta: '1',
					tituloAlert: '',
					messageAlert: '',
					showMessageAlert: false,
					messageAuth: '',
					showMessageAuth: false,
				    vistaPorcentaje:  true,
				    show: false,
				    bloqueo: 1,
				    prioridad:4
				 },
				 {
					texto: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO EXPEDIENTE."+$scope.origen+".valor"],
					labelAvance: $scope.labelAvance,
					porcentaje: $rootScope.solicitudOSJson.documentos.porcentaje,
					path: '/expedienteOS',
					image: 'images/menu/opExpediente.jpg',
					alt: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO EXPEDIENTE."+$scope.origen+".valor"],
					progressbar: 'progressbar_opExpedienteOS',
					estilo: 'opc opExpediente',
					showAlerta: false,
					showAuth: false,
					numAlerta: '1',
					tituloAlert: '',
					messageAlert: '',
					showMessageAlert: false,
					messageAuth: '',
					showMessageAuth: false,
				    vistaPorcentaje:  true,
				    show: true,
				    bloqueo: "",
				    prioridad: 5
				},
				{
					texto: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO CONTRATOS."+$scope.origen+".valor"],
					labelAvance: $scope.labelAvance,
					porcentaje: $rootScope.solicitudOSJson.contratos.porcentaje,
					path: '/contratosOS',
					image: 'images/menu/opContratos.jpg',
					alt: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO CONTRATOS."+$scope.origen+".valor"],
					progressbar: 'progressbar_opContratosOS',	
					estilo: 'opc opContratos',
					showAlerta: false,
					showAuth: false,
					numAlerta: '1',
					tituloAlert: '',
					messageAlert: '',
					showMessageAlert: false,
					messageAuth: '',
					showMessageAuth: false,
				    vistaPorcentaje:  true,
				    show: true,
				    bloqueo: "",
				    prioridad: 6
				}
			];
			
			/** Activa el mensaje de alerta para que validen los expedientes **/
			if( $rootScope.solicitudOSJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && ($rootScope.solicitudOSJson.marca == 1055 )){
				$scope.menuListOS[4].showMessageAuth = true
				$scope.menuListOS[4].showAuth = true
				$scope.menuListOS[4].messageAuth = "Falta la autorización del gerente";
			}else if( $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.expRechazado ){
				$scope.menuListOS[4].showMessageAuth = true
				$scope.menuListOS[4].showAuth = true
				$scope.menuListOS[4].messageAuth = "Expediente rechazado";
			}
			
			ajustarMenuList();
		}
		
		function ajustarMenuList(){
			var contador = 0;
			
			for(var i=0; i < $scope.menuListOS.length; i++){
				if($scope.menuListOS[i].show == true){
					
					contador++;
					$scope.menuListOS[i].prioridad = contador;
					
					if(((contador)%2) > 0)
						$scope.menuListOS[i].estilo = $scope.menuListOS[i].estilo + " colIzq";//los imapres van hacia la izquierda
					else
						$scope.menuListOS[i].estilo = $scope.menuListOS[i].estilo + " colDer";// los pares van hacia la derecha
				}	
			}
			
			for(var i=0; i < $scope.menuListOS.length; i++){
				if($scope.menuListOS[i].show == false){
					contador++;
					$scope.menuListOS[i].prioridad = contador;
				}	
			}
			
		}
		
		function validaPorcentajeContratos(){
			var contador = 0;
			for(var i=0;i<$rootScope.solicitudOSJson.contratos.contrato.length;i++){
				if($rootScope.solicitudOSJson.contratos.contrato[i].statusFirma == 1){
					contador++;
				}
			}
			
			return Math.round(contador/$rootScope.solicitudOSJson.contratos.contrato.length*100);
		}
		
		$scope.nombrePersonaMinusculas=function(){
			$rootScope.nombreCamelOS=generalService.camelize($rootScope.solicitudOSJson.cotizacion.clientes[0].nombre);
			$rootScope.apellidoPaternoCamelOS=generalService.camelize($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoPaterno);
			$rootScope.apellidoMaternoCamelOS=generalService.camelize($rootScope.solicitudOSJson.cotizacion.clientes[0].apellidoMaterno);
		};
		
		/**
		 * Funcion que se invoca para llenar las barras de progreso de cada seccion
		 **/
		function loadProgressbar(){
			  prog( "#progressbar_opDatosPersonalesOS",	parseInt($rootScope.solicitudOSJson.cotizacion.clientes[0].porcentaje) );
			  prog( "#progressbar_opDatosHogarOS", 		parseInt($rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].porcentaje) );
			  prog( "#progressbar_opDatosEmpleoOS", 		parseInt($rootScope.solicitudOSJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje) );
			  prog( "#progressbar_opIngresosGastosOS",	parseInt($rootScope.solicitudOSJson.cotizacion.clientes[0].ingresosEgresos.porcentaje) );
			  prog( "#progressbar_opExpedienteOS", 		parseInt($rootScope.solicitudOSJson.documentos.porcentaje) );
			  prog( "#progressbar_opContratosOS", 		parseInt($rootScope.solicitudOSJson.contratos.porcentaje) );
		};
		
		/**
		 * Funcion que setea el valor de la barra de progreso de la seccion establecida en los parametros.
		 **/
		function prog(progress, value){
			$( progress ).progressbar({ value: value });
			$( progress ).prev().find('.porcentaje').text(value + "%");
		}
		
		/********************************************
		 * FUNCIONES QUE SE EJECUTAN DESDE EL FRONT *
		 ********************************************/
		
		/**
		 * Funcion que se usa cuando se le da clic en alguna de las secciones para redirigir a su controlador correspondiente
		 **/
		$scope.itemSelected = function(opcion){
			if(opcion != null && opcion) {
				generalService.locationPath(opcion);
				agregaEventoDesdeOchoPasosOs(opcion);
			}
		}
		
		var agregaEventoDesdeOchoPasosOs = function (opcion){
		
				switch(opcion){
					case "/expedienteOS": //Expedientes coacreditados
						/*\Se agrega un evento para la bitacora\*/
						//(expedientes coacreditado)
							$rootScope.addEvent( BITACORA.SECCION.expedientesCoacreditado.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, $rootScope.solicitudOSJson.documentos.porcentaje, BITACORA.SECCION.expedientesCoacreditado.guardarEnBD );
						
						/*\Se agrega un evento para la bitacora\*/
						break;
					case "/contratosOS": //Contratos
						/*\Se agrega un evento para la bitacora\*/
						//(contratos coacreditado)
							$rootScope.addEvent( BITACORA.SECCION.contratosCoacreditado.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, $rootScope.solicitudOSJson.contratos.porcentaje, BITACORA.SECCION.contratosCoacreditado.guardarEnBD );
						/*\Se agrega un evento para la bitacora\*/	
						break;
							
				case "/datosCoacreditado": //Datos Coacreditado
						$rootScope.addEvent( BITACORA.SECCION.datosCoacreditado.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, porcentajeUnificada($rootScope.solicitudOSJson), BITACORA.SECCION.datosCoacreditado.guardarEnBD );
						break;
				
					default:
						break;
				
			}
		}
		
		
		
		
		/**
		 * Funcion que se usa cuando se le da clic al boton de 'Generar Cita'
		 **/
		
		$scope.enviaVisitaAsesor = function(){
			/** Probablemente quitar como estaba antes  **/
			var respuestaAgendacita = generalService.evaluaAgendaCita($rootScope.solicitudOSJson, $scope.menuListOS);
			var continuaFlujo = respuestaAgendacita.continua;

			if( !generalService.isEmpty($rootScope.solicitudOSJson.folioCallCenter)  &&  $rootScope.solicitudOSJson.respuestaCallCenter != STATUS_CALL_CENTER_RESPONSE.CLIENTE_CORRECTO && $rootScope.solicitudOSJson.respuestaCallCenter != STATUS_CALL_CENTER_RESPONSE.SIN_RESPUESTA && $scope.$parent.origenCallCenter){
				var solicitudOSJsonString = generalServiceOS.delete$$hashKey($rootScope.solicitudOSJson);
				$scope.enviaOchoPasos = true;
				validaEstatusCallCenter(solicitudOSJsonString);
			}else{
			
					if( $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.docvalidacionPendienteOS || 
					    $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.liberadoOS )
						generalService.locationPath("/ochoPasos");
					
					else if( continuaFlujo ){
						var agendarCitaOSDisponible = true;
						validarContratosDigitalizadosOS(agendarCitaOSDisponible);
					}
			
			}
		}
		
		$scope.obtenerProcentaje = function(){
			$rootScope.solicitudOSJson.documentos.porcentaje = generalServiceOS.porcentajeDocs($rootScope);
		}
		$scope.volverAcotizar = function(){
				buroObligadoSolidarioService.consultaBuro( "bgVerde", "btn gris","btn verde", null, null, 0, null );
		}
		$scope.regresaOchoPasos = function(){
			
			
			var respuestaAgendacita = generalService.evaluaAgendaCita($rootScope.solicitudOSJson, $scope.menuListOS);
			var continuaFlujo = respuestaAgendacita.continua;
			
			if(continuaFlujo){
				var agendarCitaOSDisponible = false;
				validarContratosDigitalizadosOS(agendarCitaOSDisponible);
			}else{
				generalService.locationPath("/ochoPasos");
			}
		}
		
		function validarContratosDigitalizadosOS (agendarCitaOSDisponible){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			obligadoSolidarioService.validarContratosDigitalizadosOS({jsonSolicitudOS:$rootScope.solicitudOSJson}).then(
		 			function(data){
		 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
		 					$rootScope.waitLoaderStatus = LOADER_HIDE;
		 					var responseJson = JSON.parse(data.data.respuesta);
		 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
		 						$rootScope.solicitudOSJson = responseJson.data;
		 						if(agendarCitaOSDisponible){
		 							$rootScope.agendarCitaOSDisponible = true;
		 						}
		 						generalService.locationPath("/ochoPasos");
		 					}else{
		 						generalService.locationPath("/ochoPasos");
		 					}
		 				}else{
		 					$rootScope.waitLoaderStatus = LOADER_HIDE;
		 					generalService.locationPath("/ochoPasos");
		 				}
		 			}, function(error){
		 				generalService.locationPath("/ochoPasos");
		 			}	
				);// END SOLICITUD SERVICE - SAVE SOLICITUD	
		};
		
	});
});