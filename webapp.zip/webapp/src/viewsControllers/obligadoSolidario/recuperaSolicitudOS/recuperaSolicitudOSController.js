'use strict';

define(["app"], function (app) {
	
	app.controller('recuperaSolicitudOSController',function($rootScope, $scope,  messageData, modalService, generalService, solicitudService, clienteUnicoService, 
														  recuperaSolicitudService, obligadoSolidarioService, tarjetaService, documentosService) {





$scope.init = function(){	
			
			if(messageData){
				
				var selected = generalService.getArrayValue("selectedBusqueda");
												
				
				if(selected){
										
					generalService.setArrayValue("selectedBusqueda", null);					
					$rootScope.waitLoaderStatus = LOADER_SHOW; 																																														
					
					
					try{
						var json = {"Funcion": 'cargaDato.IdSolicitudRecuperar', "Response": selected.originalObject };		    		
				    		solicitudService.loggerFront( json );
					}catch (e) {
					}					
		    	
					var recuperasolicitud = generalService.recuperarSolicitud( selected.originalObject );	
										
					
					if(recuperasolicitud.continar){
						
						obligadoSolidarioService.buscarSolicitudOS(selected.originalObject.idSolicitud, recuperasolicitud, $rootScope, selected.originalObject ).then(
								function(exito){
									
									if(exito){
										if(exito == RESPONSE_CODIGO_ERROR_ID){
											generalService.cleanRootScope($rootScope);
											generalService.buildSolicitudOSJson($rootScope, null);
											
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$rootScope.message( "Error "+RESPONSE_CODIGO_ERROR_ID, ["Problemas con la solicitud, Reintente mas tarde"], "Aceptar","/simulador");
										}else if(exito == RESPONSE_CODIGO_ERROR_BAZ_DIGITAL){
											generalService.cleanRootScope($rootScope);
											generalService.buildSolicitudOSJson($rootScope, null);
											
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$rootScope.message( "Error "+RESPONSE_CODIGO_ERROR_BAZ_DIGITAL, ["El cliente tiene una solicitud de BAZ Digital en proceso. Favor de recuperarla desde la aplicación."], "Aceptar","/simulador");
										}else if(exito == RESPONSE_CODIGO_ERROR_GENERAL){
											generalService.cleanRootScope($rootScope);
											generalService.buildSolicitudOSJson($rootScope, null);
											
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$rootScope.message( "Error "+RESPONSE_CODIGO_ERROR_GENERAL, ["Problemas con la solicitud, Reintente mas tarde"], "Aceptar","/simulador");
										}else if(exito == 5) {
											generalService.cleanRootScope($rootScope);
											generalService.buildSolicitudOSJson($rootScope, null);
											
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$rootScope.message( "Error ", ["Error inesperado"], "Aceptar","/simulador");
										}else if(exito == 15) {
											generalService.cleanRootScope($rootScope);
											generalService.buildSolicitudOSJson($rootScope, null);
											
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$rootScope.message( "Error ", ["Identificador de la solicitud no válido"], "Aceptar","/simulador");
										}else if(exito == 126) {
											generalService.cleanRootScope($rootScope);
											generalService.buildSolicitudOSJson($rootScope, null);
											
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											$rootScope.message( "Error ", ["No se obtuvo la solicitud del Coacreditado, Error al obtener la solicitud mendiante su id"], "Aceptar","/simulador");
										}
										else{
											$scope.recuperaFirmas(exito,recuperasolicitud);
										}
										
										
										
									}else
										goPath(null)
																											
									
								},function(error){
									console.log("");
								}
							);
						
					}else{							
						if(recuperasolicitud.path == "huella"){
							solicitudRechazadaMas30dias = selected.originalObject.idSolicitud;
							validaHuella(selected.originalObject.cu);
						}else
							goPath(null);
					}
										
					
				}else
					generalService.locationPath("/simuladorOS");
				
				
			}		
			
		};
		
		
		var goPath=function(path){
			$rootScope.waitLoaderStatus = LOADER_HIDE;				
			$rootScope.solicitudOSJson.tipoDispositivo = configuracion.so.windows?"Windows":configuracion.so.ios?"iPad":configuracion.origen.portalWeb?"Web":"Dispositivo No Reconocido";
									
			if( generalService.isEmpty(path) ){				
				
																									
				if( generalService.existeSolicitud($rootScope.solicitudOSJson) ){					
					
					if( $rootScope.solicitudOSJson.idCanal != $rootScope.sucursalSession.idCanal  &&  generalService.isProduccion() ){
						modalService.alertModal("AVISO",["Lo sentimos la solicitud fue originada en otro canal."], "Aceptar")
						generalService.buildsolicitudOSJson($rootScope, null);
						generalService.locationPath("/simulador");
						
					}else if($rootScope.solicitudOSJson.idPlataforma == PLATAFORMA.BAZDIGITAL){
						modalService.alertModal("AVISO",["Lo sentimos la solicitud fue originada en otra plataforma."], "Aceptar")
						generalService.buildsolicitudOSJson($rootScope, null);
						generalService.locationPath("/simulador");
						
						/**
						 * Esta validacion regresa a callcenter. Esto sólo sucede cuando el cliente debe irse a Callcenter y no se generó un folio ya que se salio de la vista
						 * Al recuperar la solicitud debe regresar a la vista de callcenter para generar el folio. La solicitud debería venir marcada y no debería tener un folio de callcenter
						 */
						
					}else if( $rootScope.solicitudOSJson.idSeguimiento == STATUS_SOLICITUD.generada.id && $rootScope.solicitudOSJson.folioCallCenter == "" && ($rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.generada.marca.ocrEditaIne || $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.generada.marca.noOcrIne || $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.generada.marca.noOcrPasaporte)) {
						generalService.esValidoFlujoCallCenter($rootScope.solicitudOSJson);
						generalService.setArrayValue("pasoCallCenter", 'init')
						generalService.setArrayValue("encolarImagenes", true);
						generalService.setArrayValue("pathOrigen", 'visorAsesor');
						generalService.locationPath("/callCenter");
						
					}else if(  $rootScope.solicitudOSJson.cotizacion.clientes[0].clienteUnico == "")		
						generalService.locationPath(generalService.getPathSectionOS($rootScope.solicitudOSJson,$rootScope.sucursalSession.idCanal));																												
						
					else
						validaHuella($rootScope.solicitudOSJson.cotizacion.clientes[0].clienteUnico);
						
						
				}else if($rootScope.urlAnterior != "#/avisos"){
					generalService.buildsolicitudOSJson($rootScope, null);
					generalService.locationPath("/simulador");
				
				}else
					generalService.locationPath("/simulador");
																																											
			}else				
				generalService.locationPath(path);																		
			
		};
		
	var validaHuella=function(cu){
			
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) > -1){
				$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
			}else if(configuracion.origen.tienda){
				$rootScope.waitLoaderStatus = LOADER_SHOW;							
				$rootScope.verificarHuella( 'fondoDivId', 'responseVerificarHuellaIpad', [cu]);
			}else if(generalService.isProduccion()){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				modalService.huellaModal("bgAzul");
			}else{
				$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
			}
		};
		
		$scope.responseVerificarHuellaIpad = function( response ){												
			$rootScope.loggerIpad("responseVerificarHuellaIpad", null, response);
			switch(response.codigo){
				case VALIDA_HUELLA_RESPONSE.EXITO:
					
					
					var continuar = function(){
					
					if($rootScope.solicitudOSJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id &&
							     ($rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente ||
							      $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.certificadoItalikaActivado) && !generalService.isEmpty($rootScope.solicitudOSJson.diaPago)){
							if($rootScope.solicitudOSJson.tipoSolicitud == SOLICITUD_REACTIVADO){
								var request = {
										idSolicitud: $rootScope.solicitudOSJson.idSolicitud,
										tarjeta: "1"
									};
									solicitudService.liberarLCR(request).then(
										function(data){
											$rootScope.waitLoaderStatus = LOADER_HIDE;
											if(data.data.codigo == RESPONSE_CODIGO_EXITO){
												var jResponse = JSON.parse(data.data.respuesta);
												if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
													$rootScope.solicitudOSJson.marca = STATUS_SOLICITUD.autorizada.marca.liberacionAplicada;
												}
												generalService.locationPath("/estatus");
											}else{
												$rootScope.message("Error", ["Error en la respuesta del servicio liberar la LCR (Reactivado). Por favor, reintente nuevamente."],"Aceptar","/simulador","bgCafeZ", "cafeZ");
											}
										}
									);
							}else{
								tarjetaService.checkInvetario($rootScope.solicitudOSJson);
							}
						}else{
							generalService.locationPath( generalService.getPathSectionOS($rootScope.solicitudOSJson,$rootScope.sucursalSession.idCanal) );
						}
													
					};
								
					continuar();
							
					break;
					
				case VALIDA_HUELLA_RESPONSE.ERROR:
					goSimulador();
					break;
					
				case VALIDA_HUELLA_RESPONSE.ERROR_COMPONENTE:
					goSimulador();
					break;
					
				case VALIDA_HUELLA_RESPONSE.COMPONENTE_CANCELADO_PORUSR:
					goSimulador();
					break;
					
				case VALIDA_HUELLA_RESPONSE.NO_SE_ENCONTARON_HUELLAS:
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					modalService.confirmModal("Sin huellas", ["No se encontraron huellas. Infórmale a tu cliente que para continuar con su proceso de crédito es necesario que realice un mantenimiento de biométricos. "], 
			                  "Cancelar", "Aceptar").then(
									  function(exito){	
										  generalService.esValidoFlujoCallCenter($rootScope.solicitudOSJson);
										  generalService.setArrayValue("pasoCallCenter", 'foto')
										  generalService.setArrayValue("encolarImagenes", false);
										  generalService.locationPath("/callCenter");
										  
									  },function(error){
										  goSimulador();														  														
									  }
								);
											
					break;
					
				case VALIDA_HUELLA_RESPONSE.NO_HAY_COINCIDENCIAS:
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					if( !generalService.isEmpty($rootScope.solicitudOSJson.folioCallCenter) && $rootScope.solicitudOSJson.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.SIN_RESPUESTA)
						generalService.setArrayValue("pasoCallCenter", 'consultaCte')
					else
						generalService.setArrayValue("pasoCallCenter", 'init')
																							
					generalService.esValidoFlujoCallCenter($rootScope.solicitudOSJson);
					generalService.setArrayValue("encolarImagenes", false);
					generalService.locationPath("/callCenter");	
					break;
					
				default:
					$rootScope.message( "Componete de huella", ["Código "+response.codigo+" no definido. "], "Aceptar");
					goSimulador();
					break;
					
			}				
										
	};
	
	var goSimulador = function(){
		$rootScope.waitLoaderStatus = LOADER_HIDE;				
		generalService.buildSolicitudOSJson($rootScope, null );			
		generalService.locationPath("/simuladorOS");
	};
		
	});
	
}); 