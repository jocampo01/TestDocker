'use strict';

define(["app"], function (app) { 
	app.controller('codigoDialogController', function( $timeout, $scope, $rootScope, ngDialog, generalService, authService, loginService, modalService, solicitudService){
		
		$scope.correoInvalido=true;
		$scope.validaCorreo=function(email){
			if(email){
				var re = /(^[-\w.]+@{1}[-a-z0-9]+[.]{1}[a-z-z0-9-]{2,5})+(?:\.[a-zA-Z0-9-]+)*$/;
				if(re.test(email))
					$scope.correoInvalido=false;
				else
					$scope.correoInvalido=true;
			}
		}
		
		// Se respaldan los datos originales.
		if($scope.ngDialogData.tipoPersona == CLIENTE.id) { // Es Cliente.
			generalService.celularAnterior = 
				$rootScope.solicitudJson.cotizacion.clientes[0].celular;
			generalService.correoAnterior = 
				$rootScope.solicitudJson.cotizacion.clientes[0].email;
		} else { // Es Aval. 
			generalService.celularAnterior = $rootScope.solicitudJson.avales[0].celular;
			generalService.correoAnterior = $rootScope.solicitudJson.avales[0].email;
		}
		
		$scope.validando=false;
		$scope.validandoCelular = false;
		$scope.validandoCorreo = false;
		$scope.reenviando = false;
		$scope.reenviandoCelular = false;
		$scope.reenviandoCorreo = false;
		$scope.celularValidado = false;
		$scope.correoValidado = false;
		$scope.muestraMensajeNumNoValido = false;
		$scope.mensaje = {
				msj: "",
				color: "",
				origen: null
		};
		$scope.envioCodigo = {
				codeCelular:{
					code: null,
					success:null
				},									
				codeMail:{
					code: null,
					success:null
				},
				solicitudJson: null
		};
		
		var TEXTO_ACLARATIVO = '¿No has recibido tu código?<br />Continúa con la captura de la solicitud. ' +
			'Puedes validar más tarde.';
		
		var contadorCel = 0;
		
		$scope.init=function(){
			contadorCel = 0;
			
			if( $scope.ngDialogData.tipoPersona == CLIENTE.id ){
				$scope.modelCelular = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
				$scope.modelCorreo = $rootScope.solicitudJson.cotizacion.clientes[0].email;
			}else{
				$scope.modelCelular = $rootScope.solicitudJson.avales[0].celular;
				$scope.modelCorreo = $rootScope.solicitudJson.avales[0].email;
			}
			
			if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
			
			$scope.titulo                  = generalService.getDataInput("CODIGO SEGURIDAD","TITULO"                   ,$scope.origen);
			$scope.codigoCelular           = generalService.getDataInput("CODIGO SEGURIDAD","CODIGO CELULAR"           ,null         );
			$scope.codigoCorreo            = generalService.getDataInput("CODIGO SEGURIDAD","CODIGO CORREO"            ,null         );
			$scope.celular                 = generalService.getDataInput("CODIGO SEGURIDAD","CELULAR"                  ,null         ); 
			$scope.correo                  = generalService.getDataInput("CODIGO SEGURIDAD","CORREO"                   ,null         );
			$scope.etiquetaCodigoSeguridad = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA CODIGO SEGURIDAD",$scope.origen);
			$scope.etiquetaCodigoCelular   = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA CODIGO CELULAR"  ,$scope.origen);
			$scope.etiquetaCodigoCorreo    = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA CODIGO CORREO"   ,$scope.origen);
			$scope.etiquetaRecepcionCodigo = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA RECEPCION CODIGO",$scope.origen);
			$scope.etiquetaRecepcionCodigo.texto="Reenviar código";
			$scope.etiquetaRegresar        = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA REGRESAR"        ,$scope.origen);
			$scope.etiquetaCorrecto        = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA CORRECTO"        ,$scope.origen);
			$scope.etiquetaReenviando      = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA REENVIANDO"      ,$scope.origen);
			$scope.etiquetaIncorrecto      = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA INCORRECTO"      ,$scope.origen);
			$scope.etiquetaEnviado         = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA ENVIADO"         ,$scope.origen);
			$scope.etiquetaNoEnviado       = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA NO ENVIADO"      ,$scope.origen);
			$scope.etiquetaCelularInvalido = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA CELULAR INVALIDO",$scope.origen);
			$scope.etiquetaCorreoInvalido  = generalService.getDataInput("CODIGO SEGURIDAD","ETIQUETA CORREO INVALIDO" ,$scope.origen);
			$scope.btnValidarTarde         = generalService.getDataInput("CODIGO SEGURIDAD","BOTON VALIDAR TARDE"      ,$scope.origen);
			$scope.btnValidarCelular       = generalService.getDataInput("CODIGO SEGURIDAD","BOTON VALIDAR CELULAR"    ,$scope.origen);
			$scope.btnReenviarCelular      = generalService.getDataInput("CODIGO SEGURIDAD","BOTON REENVIAR CELULAR"   ,$scope.origen);
			$scope.btnValidarCorreo        = generalService.getDataInput("CODIGO SEGURIDAD","BOTON VALIDAR CORREO"     ,$scope.origen);
			$scope.btnReenviarCorreo       = generalService.getDataInput("CODIGO SEGURIDAD","BOTON REENVIAR CORREO"    ,$scope.origen);
			
			$scope.CLIENTE = CLIENTE;
			$scope.AVAL = AVAL;
			
			$scope.textoAval = "Ingresa el código de seguridad que le hemos enviado a tu <span style='font-weight:700;' class='fVerde'>COACREDITADO</span>.";
			
			$scope.textoInicio = $scope.etiquetaCodigoCelular.texto;
			
			// Texto aclarativo.
			$scope.textoAclarativo = TEXTO_ACLARATIVO;
			
			if( $scope.modelCelular != "" && $scope.modelCorreo != ""){
				
				$scope.codigoCelular.visible = true;
				$scope.codigoCorreo.visible = true;
				
				if( $scope.ngDialogData.tipoPersona == CLIENTE.id ){
					if($rootScope.solicitudJson.envioCelular != 0)
						$scope.celularValidado = true;
					if($rootScope.solicitudJson.envioCorreo != 0)
						$scope.correoValidado = true;
				}else{
					if($rootScope.solicitudJson.avales[0].envioCelular != 0)
						$scope.celularValidado = true;
					if($rootScope.solicitudJson.avales[0].envioCorreo != 0)
						$scope.correoValidado = true;
				}
				
				
			}else{
				if ($scope.modelCelular != ""){
					$scope.codigoCelular.visible = true;
				}else{
					$scope.codigoCorreo.visible = true;
				}
			}
			
			$scope.textoCodigo = $scope.etiquetaRecepcionCodigo.texto;
			
			// Se invoca el método para validar tope de reenvíos.
			cellMailCodeForwardingCheck();
			
			$scope.bandera = true;
			
			if($rootScope.consultaFuncionalidad.liberacionSinCodigo) {
				// Validar.
				if($scope.ngDialogData.validacion == 777) {
					$scope.showReenvio = false;
				}
				
				// Reenvío.
				if($scope.ngDialogData.validacion == 666) {
					$scope.showReenvio = true;
				}
				
				// Se configura la Etiqueta Inicio, según corresponda.
				$scope.textoInicio = getLabelTextoInicio();
				
				$scope.bandera = false;
			}
		};
		
		/**
		 * Configura banderas de reenvíos, para saber si se han agotado los intentos.
		 */
		function cellMailCodeForwardingCheck() {
			var maxSMS = $rootScope.consultaFuncionalidad.intentosMaximoReenvioSMS;
			var maxMail = $rootScope.consultaFuncionalidad.intentosMaximoReenvioMail;
			var maxCall = $rootScope.consultaFuncionalidad.intentosMaximoReenvioCall;
		
			$scope.reenvioCorreoAgotado = $rootScope.solicitudJson.cantidadReenviosCorreo >= maxMail;
			
			// Ya se alcanzó (o superó) el máximo de reenvíos celular.
			if($rootScope.solicitudJson.cantidadReenviosCelular >= maxSMS) {
				// Ya se alcanzó (o superó) el máximo de llamadas.
				if($rootScope.solicitudJson.cantidadReenviosLlamada >= maxCall) {
					$scope.reenvioCelularAgotado = true;
				} else {
					// Se cambia el texto para mostrar en el botón.
					$scope.btnReenviarCelular.texto = "Llamar";
					
					$scope.reenvioCelularAgotado = false;
				}
			} else { // Aún hay algunos por quemar.
				$scope.reenvioCelularAgotado = false;
			}			
		};
						
		/**
		 * Utilería que verifica si debe enviarse llamada o mensaje.
		 * @returns 1, si debe ser SMS. 3, si debe ser llamada. -1 en caso de que no deba enviarse
		 * ni mensaje ni llamada.Esto se usa como parámetro para el consumo del servicio de 
		 * reenvío.
		 */
		function smsOrCall() {
			var maxSMS = $rootScope.consultaFuncionalidad.intentosMaximoReenvioSMS;
			var maxCall = $rootScope.consultaFuncionalidad.intentosMaximoReenvioCall;

			// Ya se alcanzó (o supeó) el máximo de reenvíos celular.
			if($rootScope.solicitudJson.cantidadReenviosCelular >= maxSMS) {
				// Aún quedan intentos de llamada.
				if($rootScope.solicitudJson.cantidadReenviosLlamada < maxCall) {
					return 3;
				}				
			} else { // Aún hay algunas por quemar.
				return 1;
			}

			return -1;
		}
		
		/**
		 * Listener para el botón de reenvío.
		 */
		$scope.reenviaCodigo = function(reenvio, validar){
			if(contadorCel == 0){
				var num = {
						numTelefono: $scope.modelCelular.split("(").join("").split(")").join("").split(" ").join(""),
					}

					$rootScope.waitLoaderStatus = LOADER_SHOW;
					solicitudService.validarNumTel(num).then(
						function(data) {
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var jResponse = JSON.parse(data.data.respuesta);
								
								if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){	
									$scope.muestraMensajeNumNoValido = false;
									continuaReenviaCodigo(reenvio, validar);	
								}else{
									$scope.modelCelular="";
									$scope.muestraMensajeNumNoValido = true;
									/*$rootScope.message("AVISO ", ["Infórmale a tu cliente que su número de celular no es válido, " +
									                                   "deberá ingresar un número válido para " +
									                                   "continuar su solicitud de Crédito Azteca."],"Aceptar",null,"bgRojo", "rojoR");*/
								}	
							}else{
								contadorCel++;
								$scope.muestraMensajeNumNoValido = true;
								/*$rootScope.message("AVISO ", ["Error al consultar el servicio de validación telefónica."],"Aceptar",null,"bgRojo", "rojoR");*/
							}							
						}, function(error){
							$rootScope.waitLoaderStatus = LOADER_HIDE; 
							$rootScope.message("AVISO", [ ERROR_SERVICE, "Error "+jResponse.codigo],"Aceptar",null,"bgRojo", "rojoR");	
						}
					);	
			}else{
				$scope.muestraMensajeNumNoValido = false;
				continuaReenviaCodigo(reenvio, validar);
			}
		};
		
		function continuaReenviaCodigo(reenvio, validar){
			$scope.cambio = false;
			
			// No se está reenviando ya un código.
			if (!$scope.reenviando) {
				$scope.mensaje = {
						msj: "",
						color: "",
						origen: null
				};

				// Se está pidiendo reenvío a celular (1) o a correo electrónico (2).
				$scope.mensaje.origen = reenvio;

				// Se obtuvo una validación exitosa del target del reenvío: celular/email.
				if(validar) {
					var destino = 0;
					var celular = null, nombreCte = null;
					var celularAnterior = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
					var correoAnterior = $rootScope.solicitudJson.cotizacion.clientes[0].email;
					
					// ¿A dónde se va a enviar el código? 
					switch(reenvio) {
						case 1: // Celular mediante SMS.
							// Es cliente.
							if($scope.ngDialogData.tipoPersona == CLIENTE.id) {
								$rootScope.solicitudJson.cotizacion.clientes[0].celular = 
									generalService.limpiaFormato($scope.modelCelular,"NIP-@");
								generalService.celularAnterior = 
									$rootScope.solicitudJson.cotizacion.clientes[0].celular;
								destino = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
								celular = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
								nombreCte = $rootScope.solicitudJson.cotizacion.clientes[0].nombre;
							} else { // Es aval.
								$rootScope.solicitudJson.avales[0].celular = 
									generalService.limpiaFormato($scope.modelCelular,"NIP-@");
								generalService.celularAnterior = 
									$rootScope.solicitudJson.avales[0].celular;
								destino = $rootScope.solicitudJson.avales[0].celular;
								celular = $rootScope.solicitudJson.avales[0].celular;
								nombreCte = $rootScope.solicitudJson.avales[0].nombre;
							}
							
							// Configuración de variables útiles en la vista.
							$scope.reenviandoCelular = true;
							$scope.codigocel = "";
							break;
						case 2: // Correo electrónico.
							// Es cliente.
							if($scope.ngDialogData.tipoPersona == CLIENTE.id) {
								generalService.correoAnterior = 
									$rootScope.solicitudJson.cotizacion.clientes[0].email;
								$rootScope.solicitudJson.cotizacion.clientes[0].email = 
									$scope.modelCorreo;
								destino = $rootScope.solicitudJson.cotizacion.clientes[0].email;
								nombreCte = $rootScope.solicitudJson.cotizacion.clientes[0].nombre;
								celular = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
							} else { // Es aval.
								generalService.correoAnterior = 
									$rootScope.solicitudJson.avales[0].email;
								destino = $rootScope.solicitudJson.avales[0].email;
								celular = $rootScope.solicitudJson.avales[0].celular;
								nombreCte = $rootScope.solicitudJson.avales[0].nombre;
							}
							
							// Configuración de variables útiles en la vista.
							$scope.reenviandoCorreo = true;
							$scope.codigoEmail = "";
							break;
					}

					// Verificar si se debe realizar un nuevo reenvío de celular o una llamada.
					if(reenvio == 1) {
						reenvio = smsOrCall();
					}
					
					// Se prepara el JSON para el reenvío.
					var tipoCodigo = { 
						idDestino: reenvio, 
						destino: destino, 
						celular: celular,
						celularAnterior: celularAnterior,
						nombreCte: nombreCte,
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						idPersona: $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
						tipoPersona: $scope.ngDialogData.tipoPersona,
						codigoAnterior: $rootScope.solicitudJson.codigoCelular,
						idPais: $rootScope.solicitudJson.idPais,
						idSucursal: $rootScope.solicitudJson.idSucursal,
						idCanal: $rootScope.solicitudJson.idCanal,
						generaCodigo: (celularAnterior != celular 
							|| $rootScope.solicitudJson.codigoCelular == "") ? 1 : 0
					};

					// Configuración de variables útiles en la vista.
					$scope.reenviando = true;
					$scope.errorServicio=false;

					// Invocación al servicio que realizará el reenvío del código.
					loginService.getCode(tipoCodigo).then(
							function(data) {
								// Configuración de variables útiles en la vista.
								$scope.reenviando = false;
								$scope.reenviandoCelular = false;
								$scope.reenviandoCorreo = false;
								
								// Todo bien.
								if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
									var validaService = JSON.parse(data.data.respuesta);

									if(validaService.error == false) {									
										switch (tipoCodigo.idDestino) {										
											case 1:												
												$rootScope.solicitudJson.cantidadReenviosCelular++;											
												break;
											case 2:
												generalService.correoAnterior = 
													$rootScope.solicitudJson.cotizacion.clientes[0].email;
												$rootScope.solicitudJson.cantidadReenviosCorreo++;
												break;
											case 3:
												$rootScope.solicitudJson.cantidadReenviosLlamada++;
												break;
											default: // Nothing yet.
										}
										
										// Se guarda el nuevo código celular
										$rootScope.solicitudJson.codigoCelular = data.data.descripcion;

										// Configurar las banderas de intentos agotados.
										cellMailCodeForwardingCheck();

										$scope.mensaje.color = $scope.etiquetaEnviado.estilo;
										$scope.mensaje.msj = $scope.etiquetaEnviado.texto;

										generalService.setRespaldo($rootScope.solicitudJson);
										
										if($rootScope.consultaFuncionalidad.liberacionSinCodigo) {
											$scope.closeThisDialog();
										} else {
											$scope.changeClass();
										}
									} else {
										$scope.errorServicio = true;
										$scope.mensaje.color = $scope.etiquetaNoEnviado.estilo;
										
										var MSG_ERROR = {
											CELL_EXIST: "El número celular proporcionado se " +
													"encuentra asociado a otro cliente, por " +
													"favor, captura un nuevo número."	
										};
										
										switch(validaService.codigo) {
											case 241:
												// El celular ya fue validado.
												$scope.mensaje.msj = MSG_ERROR.CELL_EXIST;
												break;
											default:												
												$scope.mensaje.msj = $scope.etiquetaNoEnviado.texto;
										}
										
										// Realizar el rollback de lo que corresponda.
										phoneMailRestore(reenvio, celularAnterior, correoAnterior);
									}
								} else {									
									$scope.errorServicio = true;
									$scope.mensaje.color = $scope.etiquetaNoEnviado.estilo;
									$scope.mensaje.msj = $scope.etiquetaNoEnviado.texto;
									
									// Realizar el rollback de lo que corresponda.
									phoneMailRestore(reenvio, celularAnterior, correoAnterior);
								}
							}, function(error) {
								$scope.errorServicio = true;
								$scope.reenviando = false; 
								$scope.reenviandoCelular = false;
								$scope.reenviandoCorreo = false;
								$scope.mensaje.color = $scope.etiquetaNoEnviado.estilo;
								$scope.mensaje.msj = $scope.etiquetaNoEnviado.texto;
								
								// Realizar el rollback de lo que corresponda.
								phoneMailRestore(reenvio, celularAnterior, correoAnterior);
							}
					);
				} else {
					if(reenvio == 1) {
						$scope.mensaje.color = $scope.etiquetaCelularInvalido.estilo;
						$scope.mensaje.msj = $scope.etiquetaCelularInvalido.texto;
					} else {
						if(reenvio == 2) {
							$scope.mensaje.color = $scope.etiquetaCorreoInvalido.estilo;
							$scope.mensaje.msj = $scope.etiquetaCorreoInvalido.texto;
						}
					}
				}
			}
		};
		
		/**
		 * Se realiza la restauración del correo o el celular, según corresponda.
		 */
		function phoneMailRestore(opcion, cell, mail) {
			switch(opcion) {
				case 1: // Celular.
				case 3: // Llamada
					$rootScope.solicitudJson.cotizacion.clientes[0].celular = cell;
					generalService.celularAnterior = cell;
					break;
				case 2: // Correo
					$rootScope.solicitudJson.cotizacion.clientes[0].correo = mail;
					generalService.correoAnterior = mail;
					break;
				default: // Nothing.
			}
		};
		
		/**
		 * Utilería para configurar la leyenda del texto de inicio del pop-up de validación de 
		 * código celular.
		 */
		function getLabelTextoInicio() {			
			var LABEL_REENVIO = {
				SMS: // "Recibirás un SMS con tu código de validación.",
					"Indícale a tu cliente que recibirá un mensaje en su celular para indicarle su código de validación",
				CALL: // "Recibirás una llamada a tu celular para indicarte tu código de validación.",
					"Indícale a tu cliente que recibirá una llamada a su celular para indicarle su código de validación",
				OUT: "Lo sentimos, se han agotado los intentos de reenvío."
			};
			
			// Se está mostrando la opción de reenvío.
			if($scope.showReenvio) {
				var intento = smsOrCall();
				
				if($rootScope.consultaFuncionalidad.liberacionSinCodigo) {
					if(intento != -1) {
						return "Verifica el teléfono capturado."
					}
				} else {
					// Por qué medio se está haciendo llegar el código.
					switch(intento) {
						case -1: return LABEL_REENVIO.OUT;
						case 1:  return LABEL_REENVIO.SMS; 
						case 3:	 return LABEL_REENVIO.CALL;
						default: return $scope.etiquetaCodigoCelular.texto;
					}
				}
			} else {
				return $scope.etiquetaCodigoCelular.texto;
			}
		}
		
		$scope.changeClass = function() {
			if (!$scope.validando && !$scope.reenviando) {
				if($scope.showReenvio) {
					$scope.cambio = false;
					$scope.showReenvio = false;
					if($scope.errorServicio) {
						$scope.mensaje = {
								msj: "",
								color: "",
								origen: null
						}
					}
				} else {
					$scope.showReenvio = true;
					$scope.cambio = true;
					$scope.mensaje = {
							msj: "",
							color: "",
							origen: null
					}
				}			
				
				// Cambiar la leyenda del textoInicio.
				$scope.textoInicio = getLabelTextoInicio();		
				
				if($scope.showReenvio) {
					$scope.claseTest = true;
					$scope.correoInvalido = false;
					$scope.textoCodigo = $scope.etiquetaRegresar.texto;
					$scope.modelCelular = generalService.celularAnterior;
					
					if($scope.ngDialogData.tipoPersona == CLIENTE.id) {
						$rootScope.solicitudJson.cotizacion.clientes[0].email = 
							generalService.correoAnterior;
					} else {
						$rootScope.solicitudJson.avales[0].email = generalService.correoAnterior;
					}
					
					$scope.modelCorreo = generalService.correoAnterior;
					
					if($scope.reenvioCelularAgotado || $scope.reenvioCorreoAgotado) {
						$scope.mensaje.color = "red";
						$scope.mensaje.msj = "Se han agotado sus intentos de reenvío";						
					}
					
					// Texto aclarativo.
					$scope.textoAclarativo = "";
				} else {					
					$scope.claseTest = false;
					$scope.textoCodigo = $scope.etiquetaRecepcionCodigo.texto;
					$scope.forCodigoCelular.codigoCel.$touched = false;
					$scope.forCodigoCorreo.codigoCorreo.$touched = false;
					
					// Texto aclarativo.
					$scope.textoAclarativo = TEXTO_ACLARATIVO;					
				}
			}
		};
		
		$scope.cierraDialog = function(){
			if( $scope.ngDialogData.tipoPersona == CLIENTE.id ){
				$rootScope.solicitudJson.cotizacion.clientes[0].celular = generalService.celularAnterior;
				$rootScope.solicitudJson.cotizacion.clientes[0].email = generalService.correoAnterior;
			}else{
				$rootScope.solicitudJson.avales[0].celular = generalService.celularAnterior;
				$rootScope.solicitudJson.avales[0].email = generalService.correoAnterior;
			}
			$('#' + $scope.ngDialogId).remove();
			$scope.closeThisDialog();
		};

		function codeValidationError(opcion) {
			if(opcion == 1) { // Celular
				$scope.validandoCelular = false;
				$scope.codigocel = "";
			} else if(opcion == 2) { // Correo
				$scope.validandoCorreo = false;
				$scope.codigoEmail = "";
			} else { // No es una opción considerada.
				// TODO ¿Qué rayos?
				$scope.validandoCelular = false;
				$scope.codigocel = "";
				$scope.validandoCorreo = false;
				$scope.codigoEmail = "";
			}
				
			$scope.mensaje.color = $scope.etiquetaIncorrecto.estilo;
			$scope.mensaje.msj = $scope.etiquetaIncorrecto.texto;
		}
		
		$scope.guarda = function(codigo, form) {
			if(!$scope.validando) {
				$scope.mensaje = {
					msj: "",
					color: "",
					origen: null
				};
				
				$scope.envioCodigo = {
					codeCelular: {
						code: null,
						success: null
					},									
					codeMail: {
						code: null,
						success:null
					},
					makePhoneBan: 
						$rootScope.consultaFuncionalidad.celularUnicoHabilitado && BANEO_CELULAR_VALIDADO,
					solicitudJson: null
				};
				
				if(form) {
					if(codigo == 1) { // Celular
						$scope.validandoCelular = true;
						$scope.mensaje.origen = 1;
					} else if(codigo == 2) { // Correo
						$scope.validandoCorreo = true;
						$scope.mensaje.origen = 2;
					} else { // No es una opción considerada.
						// TODO ¿Qué rayos?
						$scope.validandoCelular = false;
						$scope.validandoCorreo = true;
						$scope.mensaje.origen = -1;
					}

					var celular = null, correo = null, envioCelular = null;

					// Se inicializan directamente del cliente. ¿Hay que considerar AVAL?
					celular = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
					correo = $rootScope.solicitudJson.cotizacion.clientes[0].email;
					envioCelular = $rootScope.solicitudJson.envioCelular;

					// Validación celular, celulares iguales.
					if((codigo == 1 && generalService.celularAnterior == celular) 
							|| (codigo == 2 && generalService.correoAnterior == correo)) {
						if(codigo == 1) {
							$scope.envioCodigo.codeCelular.code = parseInt($scope.codigocel);		
						} else if(codigo == 2) {
							$scope.envioCodigo.codeMail.code = parseInt($scope.codigoEmail);
						} else {
							// TODO ¿Qué rayos?
						}

						$scope.envioCodigo.tipoPersona = $scope.ngDialogData.tipoPersona;
						$scope.envioCodigo.solicitudJson = $rootScope.solicitudJson;
						$scope.validando = true;
						
						// Se realiza la validación del código.
						loginService.validateCode($scope.envioCodigo).then(
							function(data) {
								$scope.validando = false;

								if(codigo == 1) { // Celular
									$scope.validandoCelular = false;
								} else if(codigo == 2) { // Correo
									$scope.validandoCorreo = false;
								} else {
									// TODO ¿Qué rayos?
								}

								// Éxito.
								if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
									var r = JSON.parse(data.data.respuesta);
									
									$rootScope.solicitudJson = r.solicitudJson;
									
									// No se terminó el proceso.
									var completo = false;

									// Correctamente.
									var exito = false;

									if(codigo == 1) { // Celular
										// Existe y es verdadero.
										exito = r.codeCelular.success != null 
											&& r.codeCelular.success;										
									} else if(codigo == 2) { // Correo
										// Existe, es verdadero. 
										exito = r.codeMail.success != null 
											&& r.codeMail.success && envioCelular != 0;										
									} else {
										// TODO ¿Qué rayos?
									}

									if(exito) {
										// Se completó el proceso correctamente.
										completo = true;
										
										if(codigo == 1) { // Celular
											$scope.celularValidado = true;
										} else if(codigo == 2) { // Correo.
											$scope.correoValidado = true;
										} else {
											// TODO ¿Qué rayos?
										}
									} else {
										$scope.mensaje.color = $scope.etiquetaIncorrecto.estilo;
										$scope.mensaje.msj = $scope.etiquetaIncorrecto.texto;
									}
									
									generalService.setRespaldo($rootScope.solicitudJson);
									
									if(completo) {
										// Ya no hay que pedir el código en ninguna ruta.
										for(var i in window.routes) {
											window.routes[i].requireLogin = false;
										}
																				
										localStorage['paths'] = JSON.stringify(window.routes);
										
										$scope.closeThisDialog();
										
										if($scope.ngDialogData.validacion != null 
												&& $scope.ngDialogData.validacion) {
											generalService.locationPath($scope.opcion);
										}
											
									}
								} else {											
									$scope.mensaje.color = $scope.etiquetaIncorrecto.estilo;
									$scope.mensaje.msj = data.data.descripcion;
								}
							}, function(error) {
								codeValidationError(codigo);
							}
						);
					} else {
						codeValidationError(codigo);
					}
				} else {
					switch(codigo) {
						case 1:
							$scope.forCodigoCelular.codigoCel.$touched = true;
							break;
						case 2:
							$scope.forCodigoCorreo.codigoCorreo.$touched = true;
							break;
						default:
							$scope.forCodigoCelular.codigoCel.$touched = true;
							$scope.forCodigoCorreo.codigoCorreo.$touched = true;
					}
				}
			}
		};
	});
});