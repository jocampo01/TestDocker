'use strict';

var imagenes = new Array();

define(["app"], function (app) {
	
		app.controller('modalCotizadorControllerML', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService,modalService) {
			
			$scope.MUESTRA_OFERTA=1;
			$scope.MUESTRA_OFERTA_COTIZADOR=2;
			$scope.MUESTRA_COTIZADOR=3;
			$scope.MUESTRA_ERROR=4;
						
			$scope.OFERTA_EXITO=1;
			$scope.OFERTA_RECALCULAR=2;
			$scope.esMenor=false;
			$scope.fechaNac = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento;
			$scope.creditoInmediatoHabilitado = $rootScope.consultaFuncionalidad.creditoInmediatoHabilitado;
			
			$scope.mostrarBeneficiosTaz=false;
			if(($rootScope.solicitudJson.idProducto == PRODUCTOS.consumo.ID.valor || $rootScope.solicitudJson.idProducto == PRODUCTOS.italika.ID.valor || $rootScope.solicitudJson.idProducto == PRODUCTOS.prestamoPersonal.ID.valor
					||$rootScope.solicitudJson.idProducto == PRODUCTOS.tarjetaAzteca.ID.valor || $rootScope.solicitudJson.idProducto == PRODUCTOS.telefonia.ID.valor) && !$rootScope.esSolicitudRescate)
				$scope.mostrarBeneficiosTaz = true;
			
			$scope.modalRescate = $rootScope.esSolicitudRescate && $rootScope.solicitudJson.flujoSolicitudADN != 99 ;
			
			var sinInmediatoPorComprobables;
			var tipoTasa = tipoTasas.prestamoPersonal.id;
			
			$scope.init=function(){
				/*\Se agrega un evento para la bitacora\*/
				//(Guardar dia de pago)
					$rootScope.addEvent( BITACORA.SECCION.oferta.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, 0, BITACORA.SECCION.oferta.guardarEnBD );
					
				/*\Se agrega un evento para la bitacora\*/

				if($rootScope.solicitudJson.idProducto==PRODUCTOS.tarjetaAzteca.ID.valor){
					$rootScope.mostrarSeccionTAZ = true;
				}
				
				$scope.objMonto=null;
				$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
				$scope.tituloHeader="Cotizador";
				$scope.opcion=$scope.MUESTRA_COTIZADOR;
				$scope.tipoOferta=$scope.OFERTA_EXITO;
				$scope.mostrarDocumentos=false;
				$scope.alcanzaMoto=false;
				$scope.listaDocumentos=[];
				$scope.muestraOfertaItalika=false;
				$scope.muestraOfertaConsumo=false;
				
				sinInmediatoPorComprobables = false;
				
				try {
					sinInmediatoPorComprobables = $rootScope.consultaFuncionalidad.sinInmediatoPorIngresosComprobables;
				} catch(e) {}
				$scope.condicionesMostrarPantallas();
				
				$scope.isCreditoInmediato = $rootScope.solicitudJson.creditoInmediato==1?true:false;
				$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";
				$scope.respaldoJsonSolicitud=null;
				$scope.isComprobable=false;
				$scope.periodicidad="semanas";
				$scope.inicializaSlider();
				$scope.labelAntesModal =  '<p>Si paga puntual</p><h3>{{respaldoJsonSolicitud.cotizacion.pagoPuntual | currency:$:0}}</h3>';
				$scope.labelAhorroModal = '<p class="fVerde" style="margin-bottom:2px !important;">Se ahorra</p><h4 class="fVerde" style="font-size:14px;">{{respaldoJsonSolicitud.cotizacion.pagoNormal - respaldoJsonSolicitud.cotizacion.pagoPuntual | currency:$:0}} {{respaldoJsonSolicitud.cotizacion.periodicidad | lowercase}}</h4><h5 class="fVerde" style="margin-top:5px;font-size:13px;">{{(respaldoJsonSolicitud.cotizacion.pagoNormal - respaldoJsonSolicitud.cotizacion.pagoPuntual)*respaldoJsonSolicitud.cotizacion.plazo | currency:$:0}} total</h5>';
				//			$scope.labelAhorro = '<p class="fVerde">Su ahorro</p><h3 class="fVerde">{{solicitudJson.cotizacion.pagoNormal - solicitudJson.cotizacion.pagoPuntual | currency:$:0}}</h3><p class="fVerde">{{solicitudJson.cotizacion.periodicidad | lowercase}}es</p>';
//				$scope.labelAhorro = '<h4 class="fVerde">{{solicitudJson.cotizacion.pagoNormal - solicitudJson.cotizacion.pagoPuntual | currency:$:0}} {{solicitudJson.cotizacion.periodicidad | lowercase}}</h4>';
//				$scope.labelAhorroTotal = '<h4 class="fVerde">{{(solicitudJson.cotizacion.pagoNormal - solicitudJson.cotizacion.pagoPuntual)*solicitudJson.cotizacion.plazo | currency:$:0}} total</h4>';
				$scope.labelPlazoModal = '<p>Plazo</p><h3>{{respaldoJsonSolicitud.cotizacion.plazo}} semanas</h3>';/*<p>semanas</p>';*/
				$scope.labelPagoModal = '<p>Pagará</p><h3>{{respaldoJsonSolicitud.cotizacion.pagoNormal | currency:$:0}}</h3>';/*<p>{{solicitudJson.cotizacion.periodicidad | lowercase}}mente</p>'*/;
				$scope.respaldoJsonSolicitud=JSON.parse(JSON.stringify($rootScope.solicitudJson));
				
				$scope.estiloDocNoCom = ($scope.mostrarDocumentosNoCOm)?"height: 24%;padding-top: 4%;":"height: 1%;padding-top: 4%;";
				$scope.estiloDocCom = ($scope.mostrarDocumentosCom)?"height: 24%;padding-top: 4%;":"height: 1%;padding-top: 4%;";
				$scope.estiloCapNoCom = ($scope.mostrarDocumentosNoCOm)?"height: 60%;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: center;border: 1px solid;border-color: #F5AD7C;background-color: white;margin: 0% 4%;":"height: 78%;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: center;border: 1px solid;border-color: #F5AD7C;background-color: white;margin: 0% 4%;";
				$scope.estiloCapCom = ($scope.mostrarDocumentosNoCOm)?"height: 60%;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: center;border: 1px solid;border-color: #F5AD7C;background-color: white;margin: 0% 4%;":"height: 78%;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: center;border: 1px solid;border-color: #F5AD7C;background-color: white;margin: 0% 4%;";
				$scope.estiloBotonesDoc = ($scope.mostrarDocumentosNoCOm && $scope.mostrarDocumentosCom)?"height: 7%;width:100%;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: center;padding-top: 9%;font-family: 'Roboto-Regular', Sans-Serif, Arial;":"height: 7%;width:100%;flex-direction: row;display: flex;align-items: center;align-content: center;justify-content: center;font-family: 'Roboto-Regular', Sans-Serif, Arial;";
			};
			
			$scope.inicializaSlider=function(){
				if($rootScope.buroHandler){
					$scope.buildSlider();
				}					
			};
			
			$scope.condicionesMostrarPantallas=function(){
				$scope.muestraOfertaItalika=false;
				$scope.muestraOfertaConsumo=false;
				if($rootScope.solicitudJson.idCanal==CANALES.sams){
					$scope.muestraOfertaItalika=true;
					if($rootScope.buroHandler)
						$scope.alcanzaMoto=true;
					else
						$scope.alcanzaMoto=false;
				}else if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.consumo ||
						 $rootScope.solicitudJson.idProducto == ID_PRODUCTO.italika ||
						 $rootScope.solicitudJson.idProducto == ID_PRODUCTO.telefonia||
						 $rootScope.solicitudJson.idProducto == ID_PRODUCTO.tarjetaAztecaProducto){
					$scope.muestraOfertaConsumo=true;
					$scope.evaluarCPenConsumo();
					$scope.docuemntosConsumo();
				}
					
				var muestraOferta=false;
				var muestraCotizador=false;
				var error=false;
				$rootScope.onceOfert=false;
				$rootScope.mostrarOfertaCotizador=false;
//				if($rootScope.solicitudJson.banderaOfertaCP == 0 && $rootScope.onceOfert)
						muestraOferta=true;						
				
				switch($rootScope.buroConditional){
					case BURO_RECALCULAR_PLAZO:
					case BURO_AUTORIZADO_PORCOMPROBAR:
						$scope.tituloHeader="¡Lo sentimos!";
						muestraCotizador=true;
						$scope.tipoOferta=$scope.OFERTA_RECALCULAR;
						$scope.generaVariablesMejorOferta();
						break;
					case BURO_AUTORIZADO_SCORE:
					case RESPONSE_ORIGINACION_CODIGO_EXITO:
						if(muestraOferta)
							$scope.tituloHeader="¡Felicidades!";
						muestraCotizador=true;
						break;
					case BURO_CALIFICA_PARA_MINICONSUMO:
					case BURO_CALIFICA_PARA_MINICONSUMO_ROJO_KO:
					case BURO_CALIFICA_PARA_MINICONSUMO_VALIDO_KO:
						if(muestraOferta)
							$scope.tituloHeader="¡Felicidades!";
						muestraCotizador=true;
						break;
					default:
						error=true;
				}
				
				if(error)
					$scope.opcion=$scope.MUESTRA_ERROR;
				else if(muestraOferta && muestraCotizador)
					$scope.opcion=$scope.MUESTRA_OFERTA_COTIZADOR;
				else if(muestraOferta)
					$scope.opcion=$scope.MUESTRA_OFERTA;
				else if(muestraCotizador)
					$scope.opcion=$scope.MUESTRA_COTIZADOR;
				
				$scope.capacidadesPagoProductoCotizador={
					prestamoPersonal:{
						capacidadPagoComprobable:0,
						capacidadPagoNoComprobable:0
					},
					consumo:{
						capacidadPagoComprobable:0,
						capacidadPagoNoComprobable:0
					},
					consumo_elektra:{
						capacidadPagoComprobable:0,
						capacidadPagoNoComprobable:0
					}
				}
				
				$scope.capacidadesPagoProductoVisible=false;
				$scope.italikaSobregiro = false;
				
				if($rootScope.capacidadesPagoProducto){
					for(var i=0; i< $rootScope.capacidadesPagoProducto.length;i++){
						if($rootScope.capacidadesPagoProducto[i].producto == PRODUCTOS.prestamoPersonal.ID.valor){
							$scope.capacidadesPagoProductoCotizador.prestamoPersonal.capacidadPagoComprobable   = $rootScope.capacidadesPagoProducto[i].capacidadPagoComprobable;
							$scope.capacidadesPagoProductoCotizador.prestamoPersonal.capacidadPagoNoComprobable = $rootScope.capacidadesPagoProducto[i].capacidadPagoNoComprobable;
							$scope.capacidadesPagoProductoVisible=true;
						}
						
						if($rootScope.solicitudJson.idProducto == $rootScope.capacidadesPagoProducto[i].producto){
							$scope.capacidadesPagoProductoCotizador.consumo.capacidadPagoComprobable   = $rootScope.capacidadesPagoProducto[i].capacidadPagoComprobable;
							$scope.capacidadesPagoProductoCotizador.consumo.capacidadPagoNoComprobable = $rootScope.capacidadesPagoProducto[i].capacidadPagoNoComprobable;
							$scope.capacidadesPagoProductoVisible=true;
						}

						if($rootScope.capacidadesPagoProducto[i].producto == PRODUCTOS.consumo.ID.valor){
							$scope.capacidadesPagoProductoCotizador.consumo_elektra.capacidadPagoComprobable   = $rootScope.capacidadesPagoProducto[i].capacidadPagoComprobable;
							$scope.capacidadesPagoProductoCotizador.consumo_elektra.capacidadPagoNoComprobable = $rootScope.capacidadesPagoProducto[i].capacidadPagoNoComprobable;
							$scope.capacidadesPagoProductoVisible=true;
						}
					}
					
					$scope.italikaSobregiro = $scope.capacidadesPagoProductoVisible && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.italika;
				}
			};
			
			$scope.evaluarCPenConsumo=function(){
				$scope.muestraCPNoComprobable=false;
				$scope.muestraCPComprobable=false;
				$scope.muestraCPNoComprobableInmediato=false;
				$scope.muestraCPComprobableInmediato=false;
				var arrayPlazos = generalService.getPlazos( $rootScope );
				var ingresoComp=$scope.getTipoIngreso(3);
				var ingresoNoComp=$scope.getTipoIngreso(4);
				
				var mostrarCDPComprobable = false;
				var mostrarCDPNoComprobable = false;
				for(var i=0;i<$rootScope.capacidadesPagoProducto.length;i++){
					if($rootScope.capacidadesPagoProducto[i].producto == $rootScope.solicitudJson.idProducto){
						mostrarCDPComprobable = ($rootScope.capacidadesPagoProducto[i].mostrarCDPComprobable == 1);
						mostrarCDPNoComprobable = ($rootScope.capacidadesPagoProducto[i].mostrarCDPNoComprobable == 1);
						break;
					}
				}
				
				if(mostrarCDPComprobable || ($rootScope.consultaFuncionalidad.validarPorCDP && $rootScope.solicitudJson.banderaIngresos == 1)) {
					$scope.muestraCPComprobable=true;
				}else if(mostrarCDPNoComprobable) {
					$scope.muestraCPNoComprobable=true;
				}
				
				if(arrayPlazos){
					if(arrayPlazos.length>0){
						if(arrayPlazos[0].comprobableInm == 1 && $scope.muestraCPComprobable)
							$scope.muestraCPComprobableInmediato=true;
						if(arrayPlazos[0].noComprobableInm == 1 && $scope.muestraCPNoComprobable)
							$scope.muestraCPNoComprobableInmediato=true;
					}
				}
				
				/**
				 * Si se eligiera comprobar ingresos, ¿sería crédito inmediato?
				 * Si se eligiera no comprobar ingresos, ¿sería crédito inmediato?
				 * Si ambas opciones convergen en crédito inmediato, entonces, la Caracola Mágica hablará con verdad.
				 * Se aplica el trucazo para "clonar" el JSON y no sólo copiar la referencia al nuevo control remoto.
				 */
				var solicitud = JSON.parse(JSON.stringify($rootScope.solicitudJson));
				
//				solicitud.banderaIngresos = 1;
//				
//				$scope.creditoInmediatoComprobando = sinInmediatoPorComprobables ? 
//						false : generalService.masterFunction(solicitud);
//				
//				solicitud.banderaIngresos = 0;
//				
//				$scope.creditoInmediatoSinComprobar = generalService.masterFunction(solicitud);
//				
//				$scope.magicConchShell = $scope.creditoInmediatoComprobando && $scope.creditoInmediatoSinComprobar;
				
				if(solicitud.banderaIngresos == 1){
					$scope.creditoInmediatoComprobando = sinInmediatoPorComprobables ? 
						false : generalService.masterFunction(solicitud);
					$scope.magicConchShell = $scope.creditoInmediatoComprobando
				}else{
					$scope.creditoInmediatoSinComprobar = generalService.masterFunction(solicitud);
					$scope.magicConchShell = $scope.creditoInmediatoSinComprobar;
				}
				
			};
			
			$scope.getTipoIngreso=function(tipoIngreso){
				var arrayFlujo = $rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo;
				for(var efectivo in arrayFlujo){
					if(arrayFlujo[efectivo].idConcepto==tipoIngreso && arrayFlujo[efectivo].monto != 0)
						return true;
				}
				return false;

			};
			
			$scope.generaVariablesMejorOferta=function(){
				var arrayPlazos = generalService.getPlazos( $rootScope );
				if(arrayPlazos){
					var monto = parseInt($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto);
					
					var index = arrayPlazos.map(function(d){
						return d["monto"];
						
					}).indexOf (monto);
					if (index != -1){
						$scope.montoOferta = parseInt($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto);
					}else{
						var montoMayor = $scope.regresaMayor(arrayPlazos, "monto");
						$scope.montoOferta=montoMayor.valor; 
						index = montoMayor.posicion;
					}
					
					var plazo = $rootScope.solicitudJson.cotizacion.plazo;
					var arrelgoPlazos =arrayPlazos[index];
					if (arrayPlazos[index].cpNoComprobable){
						var index1 = arrelgoPlazos.cpNoComprobable.indexOf( plazo );		
						if( index1 != -1 ){
							$scope.plazoOferta=plazo;
							$scope.Montocomprobables = false;
						}else{
								if (arrayPlazos[index].cpComprobable)
									index1 = arrelgoPlazos.cpComprobable.indexOf( plazo );	
								else
									index1 = -1;
							
								if( index1 != -1 ){
									$scope.plazoOferta=plazo;
									$scope.Montocomprobables = true;
								}else{
									var plazoMayor = $scope.regresaMayor(arrayPlazos[index].cpNoComprobable);
									$scope.Montocomprobables = false;
									if (!plazoMayor.encontro){
										plazoMayor = $scope.regresaMayor(arrayPlazos[index].cpComprobable);
										$scope.Montocomprobables = true;
									}
									index1 = plazoMayor.posicion;
									$scope.plazoOferta=plazoMayor.valor
								}
						}
					}else{
						if (arrayPlazos[index].cpComprobable)
							var index1 = arrelgoPlazos.cpComprobable.indexOf( plazo );
						else
							var index1 = -1;
						$scope.Montocomprobables = true;
						if( index1 != -1 ){
							$scope.plazoOferta=plazo;
						}else{
							plazoMayor = $scope.regresaMayor(arrayPlazos[index].cpComprobable);
							index1 = plazoMayor.posicion;
							$scope.plazoOferta=plazoMayor.valor
						}
					}
					console.log("comprobables " + $scope.Montocomprobables)
					if ($scope.Montocomprobables){
						if(arrayPlazos[index].comprobableInm == 1)
							$scope.creditoInmediatoOferta=true;
						else
							$scope.creditoInmediatoOferta=false;
					}else{
						if(arrayPlazos[index].noComprobableInm == 1)
							$scope.creditoInmediatoOferta=true;
						else
							$scope.creditoInmediatoOferta=false;
					}
	//				$scope.montoOferta=montoMayor.valor; 
	//				$scope.plazoOferta=plazoMayor.valor
					$scope.periodicidadOferta="semanas";
	//				$scope.actualizaPlazo($scope.plazoOferta);
					$scope.respaldoNuevoPlazo=$scope.plazoOferta;
	//				$scope.creditoInmediatoOferta=false;
				}
			};
			
			
			$scope.buildSlider = function(){
				
				var cambiaMontoCallback = function( valorSlider ){
			 		$timeout( function(){ 
		 				angular.element( document.getElementById( "volverCotizar" ) ).scope().reBuildSlider( valorSlider );
		 			}, 0);
				};
				
				if( $scope.$parent.muestraTermometro){
					
					var plazos = generalService.getPlazos($rootScope );
					  
					var arrayMontos = plazos.map( function(d){
						return d['monto'];
					});
					
					arrayMontos = generalService.mergeSort(arrayMontos);
					
					var monto = parseInt($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto);
					var index = arrayMontos.indexOf( monto );

					var _min = Math.min.apply( 0, arrayMontos );
					var _max = Math.max.apply( 0, arrayMontos );
									
					if( index == -1 )
						monto = _max;
					  
					$scope.minMonto = _min;
					$scope.maxMonto = _max;
					
					var step=500;
					var len = arrayMontos.length;
					
					if( arrayMontos[0] )
						if( arrayMontos[1] )
							step = arrayMontos[1]-arrayMontos[0];
					
					var fnCrearSliderCallBack = function(){
						slider( _min , _max, step, monto, '.amountVolCotizar div', arrayMontos, cambiaMontoCallback, "#sliderVolCotizar");
					};
					
					$scope.createSliderThread( 'sliderVolCotizar', fnCrearSliderCallBack, true );
					
				}
				
			};
			
			$scope.reBuildSlider = function ( valorSlider )
			{		

				var cambiaMontoCallback = function(){								
	
					
					
					$scope.plazosCotizador = $scope.calculaPlazosTermometro( valorSlider);				
					
					var plazo = $scope.respaldoNuevoPlazo?$scope.respaldoNuevoPlazo:$rootScope.solicitudJson.cotizacion.plazo;
					var index = $scope.plazosCotizador.indexOf( plazo );
					
					$scope.deshabilitarRecalcular = true;
			 		$scope.actualizaMonto();
					if(index != -1 ){
						if(plazo = plazo)
						$scope.validaPlazoComprobableInmediato( plazo, valorSlider ); 
						$scope.calculaNuevosMontos();
						$timeout( function(){
							$('.requisitosCot ul li > a').each(function(){
								if( parseInt($(this).text()) == parseInt(plazo) ){
									if(!$(this).hasClass( "active" )){
										limpiarClasePlazos();
										$( this ).addClass('active'); 
									}
									return;
								};
							});
							$scope.actualizaPlazo();
						}, 10 );
					}else{
						$scope.mostrarDocumentos=false;
						limpiarClasePlazos();
						$scope.nuevoPlazo=0;
					}
									
				};
				
				$scope.createSliderThread( 'sliderVolCotizar', cambiaMontoCallback, false );
					 		
		 	};/* END UISLIDER FUNCTION */
		 	
			$scope.createSliderThread = function( idSlider, fnCrearSliderCallBack, isFirstTime ){											
				
				var stopInterval = null, intervalCont = 1;
				
				var verifySlider = function(){
					var sliderVal = $( "#" + idSlider ).slider( "value" );
					return !(isNaN( sliderVal ));
				};
								
				var trySlider = function(){					
					if( verifySlider() ){
						$interval.cancel( stopInterval )
						if( fnCrearSliderCallBack && fnCrearSliderCallBack != null )
							fnCrearSliderCallBack();
					}else if( intervalCont == 100 )
						$interval.cancel( stopInterval )
					else{
						intervalCont++;
						if( isFirstTime )
							if( fnCrearSliderCallBack && fnCrearSliderCallBack != null )
								fnCrearSliderCallBack();
					}
				};
				stopInterval = $interval( trySlider, 100 );
										
				
			};/* END THREAD SLIDER FUNCTION */
			
			
			$scope.calculaPlazosTermometro = function( valor){
				var arrayPlazos = generalService.getPlazos( $rootScope ); 
				
				var index = arrayPlazos.map( function(d){
					return d['monto'];
				}).indexOf( parseInt(valor) );
				
				if( arrayPlazos.length == 0 ){
					$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
					$scope.opcion=$scope.MUESTRA_ERROR;
					return [];
				}			
				
				if( index != -1 ){
					
					var plazos = [];
					var _comprobables = arrayPlazos[index].cpComprobable;
					var _noComprobables = arrayPlazos[index].cpNoComprobable;
					
					_comprobables = _comprobables ? _comprobables : [];
					_noComprobables = _noComprobables ? _noComprobables : [];
					
					if( _comprobables.length > _noComprobables.length ){
						var comprobables = _comprobables;
						var noComprobables = _noComprobables;
					}else{
						var comprobables = _noComprobables;
						var noComprobables = _comprobables;
					}	
					
					for( var i = 0; i < comprobables.length; i++ ){
							
						if( noComprobables[i] ){
							
							if( plazos.indexOf( comprobables[i] ) == -1 ){
								plazos.push( comprobables[i] );
							}
							
							if( plazos.indexOf( noComprobables[i] ) == -1 ){
								plazos.push( noComprobables[i] );
							}
							
						}else{
							if( plazos.indexOf( comprobables[i] ) == -1 ){
								plazos.push( comprobables[i] );
							}
						}
							
					}/* END FOR */
					
					return plazos.sort( function( a, b ){
						return a-b;/* Invert to asc */
					});
					
				}/* END IF INDEX */
				return [];
				
			};
			
			
			$scope.validaPlazoComprobableInmediato = function( plazo, monto ){
				var arrayPlazos = generalService.getPlazos( $rootScope ); 
				var tiposComprobantes=null;
				var indexPlazo = arrayPlazos.map( function(d){
					return d[ 'monto' ];
				}).indexOf( parseInt(monto) );
				
				var index = -1;
				var comprobante = false;
				var tiposComprobantes = null;
				
				if( indexPlazo != -1 ){
					
					var condicionRequeridaC = arrayPlazos[indexPlazo].requeridoComprobable;
					var condicionRequeridaNC = arrayPlazos[indexPlazo].requeridoNoComprobable;
					
					if( condicionRequeridaC != '' && condicionRequeridaC != null )
						condicionRequeridaC = condicionRequeridaC.split(",");
					if( condicionRequeridaNC != '' && condicionRequeridaNC != null )
						condicionRequeridaNC = condicionRequeridaNC.split(",");
					
					if( arrayPlazos[indexPlazo].cpNoComprobable ){
						
						index = arrayPlazos[indexPlazo].cpNoComprobable.indexOf( parseInt(plazo) );
						
						if( typeof condicionRequeridaNC == "object" && index != -1 && condicionRequeridaNC != null ){
							comprobante = true;
							tiposComprobantes = arrayPlazos[indexPlazo].requeridoNoComprobable;
						}
				
						if( index == -1 ){
							
							index = arrayPlazos[indexPlazo].cpComprobable.indexOf( parseInt(plazo) );
							
							if( typeof condicionRequeridaC == "object" && condicionRequeridaC != null){
								comprobante = true;
								tiposComprobantes = arrayPlazos[indexPlazo].requeridoComprobable;
							}
							
							if( index != -1 )
								comprobante = true;
													
						}
						
					}else{
						
						if( arrayPlazos[indexPlazo].cpComprobable ){
							
							index = arrayPlazos[indexPlazo].cpComprobable.indexOf( parseInt(plazo) );
							
							if( typeof condicionRequeridaC == "object" && condicionRequeridaC != null ){
								comprobante = true;
								tiposComprobantes = arrayPlazos[indexPlazo].requeridoComprobable; 
							}
							
							if( index != -1 )
								comprobante = true;
							
						}
						
					}
					$scope.objMonto=arrayPlazos[indexPlazo];	
				}					
				$scope.isCreditoInmediato=false;
				//validar si ese plazo tiene credito inmediato
				if( comprobante ){
					$scope.isComprobable=true;
					if(arrayPlazos[indexPlazo].comprobableInm)
						$scope.isCreditoInmediato = generalService.masterFunction();
						// $scope.isCreditoInmediato = (generalService.validaEdad($scope.fechaNac)) ? false : true;				
					$scope.listaDocumentos=[{desc:IDENTIFICACION_OFICIAL_INE.descripcion, id:IDENTIFICACION_OFICIAL_INE.id },{desc:COMP_DOMICILIO.descripcion, id: COMP_DOMICILIO.id}];
					if(tiposComprobantes.split(",").indexOf("CI")!=-1){
						$scope.listaDocumentos.push({desc:COMP_INGRESOS.descripcion, id:COMP_INGRESOS.id });
					}
					
					
					for (var i = 0; i < $scope.listaDocumentos.length;){
						var borrarRegistro = $scope.searchID($scope.listaDocumentos[i].id)
						if (borrarRegistro){
							 $scope.listaDocumentos.splice(i,1);
						}else{
							i++	
						}
						
					}
					if ($scope.listaDocumentos.length > 0)
						$scope.mostrarDocumentos=true;
					else
						$scope.mostrarDocumentos=false;
				}else{
					$scope.listaDocumentos=[{desc:IDENTIFICACION_OFICIAL_INE.descripcion, id:IDENTIFICACION_OFICIAL_INE.id },{desc:COMP_DOMICILIO.descripcion, id: COMP_DOMICILIO.id}];
					for (var i = 0; i < $scope.listaDocumentos.length;){
						var borrarRegistro = $scope.searchID($scope.listaDocumentos[i].id)
						if (borrarRegistro){
							 $scope.listaDocumentos.splice(i,1);
						}else{
							i++	
						}
						
					}
					if ($scope.listaDocumentos.length > 0)
						$scope.mostrarDocumentos=true;
					else
						$scope.mostrarDocumentos=false;
					
					
					if(arrayPlazos[indexPlazo].noComprobableInm)
						$scope.isCreditoInmediato = generalService.masterFunction();
						// $scope.isCreditoInmediato = (generalService.validaEdad($scope.fechaNac)) ? false : true;
	//					$scope.mostrarDocumentos=false;
	//					$scope.listaDocumentos=[];
					$scope.isComprobable=false;
				}
				
				return comprobante;
				
			};
			
			
			function limpiarClasePlazos(){
				$('.requisitosCot ul li > a').each(function(){
		 			$( this ).removeClass('active');
		 	    });
				
			};/* END LIMPIAR CLASE PLAZO FUNCTION */
			
		 	$scope.onSeleccionaPlazo = function(valor,ui){	 		 		 	
		 		$scope.actualizaMonto();
		 		$scope.actualizaPlazo(ui.target.parentNode);		 		
		 		$scope.validaPlazoComprobableInmediato($scope.nuevoPlazo,$scope.nuevoMonto);
		 		$scope.calculaNuevosMontos();
		 			 		
		 	};/* END CONDICIONES TERMOMETRO FUNCTION */
		 	
		 	$scope.actualizaMonto=function(){
		 		$scope.nuevoMonto= $( "#sliderVolCotizar" ).slider( "value" );
		 	};
		 	
		 	$scope.actualizaPlazo=function(nuevoPlazo){
		 		var plazo;
	 			if(nuevoPlazo){
	 				limpiarClasePlazos();
	 				$(nuevoPlazo).addClass('active');
	 			}
		 		$('.requisitosCot ul li > a').each(function(){
			 		if( $( this ).hasClass('active') ){
			 			plazo = parseInt( $(this).text() ); 
			 			return;
			 		};
			 	});
		 		$scope.nuevoPlazo= plazo;
		 		$scope.respaldoNuevoPlazo= plazo;
		 	};
		 	
		 	
		 	$scope.volverACotizar = function(){
				$scope.respaldoJsonSolicitud=JSON.parse(JSON.stringify($rootScope.solicitudJson));
				$scope.respaldoJsonSolicitud.banderaOfertaCP= 1;
		 		if($scope.opcion==$scope.MUESTRA_OFERTA){
		 			$rootScope.waitLoaderStatus = LOADER_SHOW;
		 			$scope.guardarSeccion();
		 		}else{
					if( $scope.nuevoPlazo &&  $scope.nuevoMonto){
			 			$rootScope.waitLoaderStatus = LOADER_SHOW;
	 		 			if($scope.calculaNuevosMontos()){
		 		 			$scope.validaCreditoInmediatoIngresos();
		 		 			$scope.guardarSeccion();
	 		 			}
	
					}
		 		}
		 	};
		 	
		 	/**
			   *Codigo que valida la edad para pinta si es credito inmediato o no en la vista
			   *Si el cliente es menor de edad aunque sea verde, NO es credito inmediato a menos que cotice una italiza
			   *Si el cliente es menor, es verde y cotiza una italika entonces SI es credito inmediato
			   *Si el cliente es menor, es azul y cotiza una italiza entonces NO es credito inmediato 
			   *Esta validacion solo aplica para el mensaje de credito inmediato o no en la vista
			 **/
//		 	if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.italika) {
//		 		$scope.esMenor = (generalService.validaEdad($scope.fechaNac) && ($rootScope.solicitudJson.idColorNC == 7 || $rootScope.solicitudJson.idColor == 7) || !generalService.validaCreditoInmediatoProducto()) ? true : false;
//		 	} else {
//		 		$scope.esMenor = (generalService.validaEdad($scope.fechaNac) || !generalService.validaCreditoInmediatoProducto()) ? true : false;
//		 	}
		 	
		 	//TOMANDO EN CUENTA SOLO LAS VALIDACIONES DE LA MASTER FUNCTION, SI REGRESA TRUE ES CREDITO INMEDIATO POR LO QUE LA BANDERA DE esMenor SE VUELVE TRUE
		 	if(generalService.masterFunction()) {
		 		$scope.esMenor = false;
		 		$scope.isCreditoInmediato = true;
		 	} else {
		 		$scope.esMenor = true;
		 		$scope.isCreditoInmediato = false;
		 	}
		 	
//		 	if(generalService.validaCreditoInmediatoProducto()) 
//		 		$scope.esMenor = false;
		 	
		 	
		 	$scope.cotizarConsumo = function(ingresos){
		 		if(ingresos != 1){
			 		/*\Se agrega un evento para la bitacora\*/
					//(Guardar dia de pago)
						$rootScope.addEvent( BITACORA.SECCION.oferta.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.aceptar.id, 0, BITACORA.SECCION.oferta.guardarEnBD );
			 		}	
					/*\Se agrega un evento para la bitacora\*/
		 		
		 		$rootScope.waitLoaderStatus = LOADER_SHOW;
		 		$scope.respaldoJsonSolicitud.banderaOfertaCP= 1;
		 		$scope.respaldoJsonSolicitud.banderaIngresos = ingresos;
		 		$scope.validaCreditoInmediatoPorColor();
		 		/**
				 *antes de guardar se debe vallidar la edad, si es cliente azul y si cotiza una italiza para mandar el credito inmediato en 0
				 *Si es cliente verde, es menor de 22 años y cotiza una italiza entonces SI es credito inmediato
				 *Si es menor a 22 años, la bandera de credito inmediato es 0 
				**/
//		 		if((generalService.validaEdad($scope.fechaNac) && $rootScope.solicitudJson.idProducto != ID_PRODUCTO.italika) || $rootScope.solicitudJson.creditoInmediatoInhabilitado>0) {
//		 			$scope.respaldoJsonSolicitud.creditoInmediato = 0;
//		 		}
//		 		
//		 		if(($rootScope.solicitudJson.idProducto == ID_PRODUCTO.italika && generalService.validaEdad($scope.fechaNac) && ($rootScope.solicitudJson.idColorNC == 7 || $rootScope.solicitudJson.idColor == 7)) || $rootScope.solicitudJson.creditoInmediatoInhabilitado>0) {
//		 			 $scope.respaldoJsonSolicitud.creditoInmediato = 0;
//		 		}
//		 		
//		 		if(!generalService.validaCreditoInmediatoProducto())
//		 			$scope.respaldoJsonSolicitud.creditoInmediato = 0;
		 		
		 		// Está comprobando ingresos.
		 		if(ingresos == 1 && sinInmediatoPorComprobables) {
		 			$scope.respaldoJsonSolicitud.creditoInmediato = 0;
		 		} else {
		 			$scope.respaldoJsonSolicitud.creditoInmediato = 
		 				generalService.masterFunction($scope.respaldoJsonSolicitud) ? 1 : 0;
		 		}
		 		
		 		$scope.guardarSeccion();
		 	};
		 	
		 	$scope.seleccionarOtraMoto=function(){		 		
		 		$scope.closeThisDialog(true);		 				 		
		 		generalService.setArrayValue("cotizacionOfertaItalika", JSON.stringify($rootScope.solicitudJson.cotizacion));
		 		generalService.locationPath("/catalogoItalika");		 		
		 	};
		 	
		 	/**
			 * Función que valida las banderas de imgreso 
			 * Si la bandera de ingresos esta en 0 pero es un cliente verde con ingresos no comprobables la bandera de credito inmediato sera 1
			 * Si el cliente tiene la bandera de ingresos en 1, es verde, con ingresos comprobables, el credito inmediato es 1
			 * en cualquier otro caso, el credito inmediato es 0 
			 * Esta funcion se manda a llamar al seleccionar ingresos comprobables o no comprobables en el cotizador
			 **/
		 	
			$scope.validaCreditoInmediatoPorColor = function(){
					 		
		 		if($rootScope.solicitudJson.banderaIngresos == 0 && ($rootScope.solicitudJson.idColorNC == 1 || $rootScope.solicitudJson.idColorNC == 2 || $rootScope.solicitudJson.idColorNC == 3 || $rootScope.solicitudJson.idColorNC == 7)){
		 			$scope.respaldoJsonSolicitud.creditoInmediato = 1;
		 	
		 		}else{
		 			if($rootScope.solicitudJson.banderaIngresos == 1 && ($rootScope.solicitudJson.idColor == 1 || $rootScope.solicitudJson.idColor == 2 || $rootScope.solicitudJson.idColor == 3 || $rootScope.solicitudJson.idColor == 7)){
		 				$scope.respaldoJsonSolicitud.creditoInmediato = 1;
			 	
			 		} else {
			 			$scope.respaldoJsonSolicitud.creditoInmediato = 0;
			 		}
		 		}
		 	};
					 	
		 	$scope.validaCreditoInmediatoIngresos=function(){
				if($scope.isCreditoInmediato)
					$scope.respaldoJsonSolicitud.creditoInmediato = 1;
				else
					$scope.respaldoJsonSolicitud.creditoInmediato = 0;
				
				if($scope.banderaComprobables)
					$scope.respaldoJsonSolicitud.banderaIngresos = 1;
				else
					$scope.respaldoJsonSolicitud.banderaIngresos = 0;
		 	};
		 	
			$scope.calculaNuevosMontos = function(){	 
				
		 			var monto =  $scope.nuevoMonto;
			 		var periodicidad = $scope.respaldoJsonSolicitud.cotizacion.idPeriodicidad;
			 		var plazo = $scope.nuevoPlazo;			 	
			 		
			 		if($scope.muestraOfertaItalika){
			 			var pagoNormal;
			 			var pagoPuntual;
			 			for(var abonoItalika in $scope.objMonto.abonoSemanal){
			 				if($scope.objMonto.abonoSemanal[abonoItalika].plazo==plazo){
			 					pagoNormal=$scope.objMonto.abonoSemanal[abonoItalika].pagoNormal;
			 					pagoPuntual=$scope.objMonto.abonoSemanal[abonoItalika].pagoPuntual;
			 					break;	
			 				}			 						 					
			 			}
			 			if(pagoNormal && pagoPuntual){				
			 				var montoConIntereses = pagoNormal * plazo;
			 				
			 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = monto;
			 				$scope.respaldoJsonSolicitud.cotizacion.montoTotal = montoConIntereses;
			 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = montoConIntereses - monto;
			 				$scope.respaldoJsonSolicitud.cotizacion.pagoNormal = pagoNormal;
			 				
			 				$scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = pagoPuntual;
			 				$scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = pagoNormal;				
			 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = 1;
		 					$scope.respaldoJsonSolicitud.cotizacion.plazo = plazo;
		 					$scope.respaldoJsonSolicitud.cotizacion.idPlazo = plazo; 
			 							 				
			 			}else
			 				return null;
			 		}else{
			 			
			 			

			 			if($rootScope.consultaAbonos.prestamosPersonales != undefined){
					 		
					 		for (var i = 0; i < $rootScope.consultaAbonos.prestamosPersonales.length;i++){
					 			if(monto == $rootScope.consultaAbonos.prestamosPersonales[i].precio && periodicidad == $rootScope.consultaAbonos.prestamosPersonales[i].periodo && plazo == $rootScope.consultaAbonos.prestamosPersonales[i].plazo  ){
					 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = monto;
					 				$scope.respaldoJsonSolicitud.cotizacion.montoTotal = parseInt($rootScope.consultaAbonos.prestamosPersonales[i].precio) + parseInt($rootScope.consultaAbonos.prestamosPersonales[i].sobre);
									$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = parseInt($rootScope.consultaAbonos.prestamosPersonales[i].sobre);
									$scope.respaldoJsonSolicitud.cotizacion.pagoNormal =parseFloat( $rootScope.consultaAbonos.prestamosPersonales[i].normal );
									$scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = parseFloat($rootScope.consultaAbonos.prestamosPersonales[i].puntual);
									$scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = parseInt($rootScope.consultaAbonos.prestamosPersonales[i].ultimo);
									$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto = $rootScope.consultaAbonos.prestamosPersonales[i].sku;
									$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = 1;
									$scope.respaldoJsonSolicitud.cotizacion.plazo = plazo;
  			 					    $scope.respaldoJsonSolicitud.cotizacion.idPlazo = plazo;
									$scope.existePlazo= true;
									break;
					 			}
					 		}
			 			}
			 			
//				 		var arrayPlazoMonto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA",tipoTasa);
//				 		for ( var i = 1; i <= arrayPlazoMonto.length; i++ ){
//		 					
//				 			if (monto        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.MONTO["+i+"].valor",tipoTasa) &&
//		 						periodicidad == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PERIODICIDADID["+i+"].valor",tipoTasa) &&
//		 						plazo        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PLAZO["+i+"].valor",tipoTasa) ){ 						
//		 					   var tasaNormal = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA NORMAL["+i+"].valor",tipoTasa));
//		 					   var tasaPuntual = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA PUNTUAL["+i+"].valor",tipoTasa));
//		 					   var idProducto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PRODUCTOID["+i+"].valor",tipoTasa);
//		 					   var montoNormal = monto * tasaNormal;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = monto;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.montoTotal = monto + montoNormal;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = parseInt($scope.respaldoJsonSolicitud.cotizacion.montoTotal - monto);
//		 					   $scope.respaldoJsonSolicitud.cotizacion.pagoNormal = Math.round(parseFloat($scope.respaldoJsonSolicitud.cotizacion.montoTotal / plazo));
//		 					   var montoPuntual = monto * tasaPuntual;
//		 					   var montoTotalPuntual = monto + montoPuntual;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = Math.round(parseFloat(montoTotalPuntual / plazo));
//		 					   $scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = parseInt($scope.respaldoJsonSolicitud.cotizacion.montoTotal - $scope.respaldoJsonSolicitud.cotizacion.pagoNormal * (plazo - 1));
//		 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto = idProducto;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = 1;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.plazo = plazo;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.idPlazo = plazo; 
//		 					   break;
//		 					}
//		 					
//				 		}
			 		}
			 		return true;
			 		
		 	};
		 	
		 	$scope.guardarSeccion = function(){	
		 		
		 		/* Cuando MCO autoriza una solicitud con una CDP específica, entonces al seleccionar la nueva alternativa
		         *  se setea el valor de ofertaSeleccionadaMCO  a 2 para que ya no se se muestre la notificación de volver a cotizar 
		         *  */
		        if($scope.respaldoJsonSolicitud.ofertaSeleccionadaMCO == 1)
		          $scope.respaldoJsonSolicitud.ofertaSeleccionadaMCO = COTIZADOR_MCO;
		 		
		 		solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($scope.respaldoJsonSolicitud), seccion: SECCION_SOLICITUD } ).then(
			 			function(data){
			 				$rootScope.waitLoaderStatus = LOADER_HIDE;
			 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
			 					var responseJson = JSON.parse(data.data.respuesta);
			 					
			 					var fnStatusOK = function( esMalZonificada ){
									$scope.$parent.muestraAlertaNuevoBuro=false;
									$scope.$parent.muestraMensajeNuevoBuro=false;
									$scope.$parent.mensajeNuevoBuro=""
									$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO; //FIX COMMENT 01/04/2016
			 						$rootScope.solicitudJson = responseJson.data;
			 						
			 						try{
			 							$rootScope.solicitudJson.contratos.porcentaje = porcentajeSeccionDocumentos();
			 						}catch(e){}
			 						
									if( esMalZonificada && typeof esMalZonificada !== 'undefined' ){
										var excepciones = [ SECCION_HOGAR.toString() ];
										generalService.bloqueoSecciones( $rootScope.solicitudJson, excepciones );
									}
									$rootScope.calculaDocumentos();
									if(!$scope.$parent.quickFixes)
										$scope.$parent.buildMenuList();
									$scope.closeThisDialog(true);		
								
			 					};
			 					
			 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
									fnStatusOK();							
								}else if( responseJson.codigo == STATUS_SOLICITUD.malZonificada.guardarSeccion ){
									generalService.setDataBridge( {esMalZonificada:true} );
									fnStatusOK( true );
								}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
								}else{
									if(responseJson.codigo == ERROR_SOL_RECHAZADA){
										var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
										var marca = $rootScope.solicitudJson.marca;
										var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
										var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
										$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],"Aceptar", "/simulador",null,null,buildJsonDefault);
									}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
										generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
										$scope.closeThisDialog(true);
										generalService.locationPath("/ficha");
									}else{
										$rootScope.message("Error al volver a cotizar",[ "Error al guardar sección. Código " +
										    "de error [" + responseJson.codigo + "] no identificado."],"Aceptar", null);
									}
			 					}
			 					
			 					//Se actualiza el status de la solicitud cuando el cliente decide cambiarse por la opción de No comprobables.
			 					if($rootScope.solicitudJson.idSeguimiento == 34 && $rootScope.solicitudJson.marca == 4001 && $rootScope.solicitudJson.banderaIngresos == 0){
			 						$scope.actualizaStatusTiendaMCO();
			 					}
			 					
			 				}else{
			 					$rootScope.message("Error",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
			 				}
			 			}, function(error){                     
			 				$rootScope.waitLoaderStatus = LOADER_HIDE;
			 				$rootScope.message("Error al volver a cotizar",[ "Error en el servicio guardar solicitud sección 9"], "Aceptar", null);								
			 			}	
					);
			}
		 	
		 	function porcentajeSeccionDocumentos(){
				var porcentaje = 0;
				
				if($rootScope.solicitudJson.idSeguimiento == 185 || $rootScope.solicitudJson.idSeguimiento == 6){
					for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
						if($rootScope.solicitudJson.contratos.contrato[i].statusFirma == 1 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 2 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 4){
							porcentaje = porcentaje + 100; 
						}
					}
					
					return porcentaje / $rootScope.solicitudJson.contratos.contrato.length;
				}else{
					for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
						if(($rootScope.solicitudJson.contratos.contrato[i].statusFirma == 1 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 2 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 4)){
							if(!generalService.validardiaDePago()){
								if(i==0 || i==1)
									porcentaje = porcentaje + 100;
							}else{
								if(i==0 || i==1 || i==2 || i==3)
									porcentaje = porcentaje + 100;
							}
						}
					}
					var numDocs  = generalService.validardiaDePago()?4:2;
					return porcentaje / numDocs;
				}
			}
		 	
		 	$scope.regresaMayor = function(arreglo, campo){
				var auxiliar = 0;
				var posicion = 0;
				var encontro = false;
				if (arreglo){
					for(var i = 0; i< arreglo.length; i++){
						if (campo){
							if (auxiliar < arreglo[i][campo]){
								auxiliar =arreglo[i][campo];
								posicion = i;	
								encontro = true
							}	
						}else{
							if (auxiliar < arreglo[i]){
								auxiliar =arreglo[i];
								posicion = i;
								encontro = true
							}	
						}
					}
				}
				return {"posicion": posicion, "valor": auxiliar, "encontro": encontro};
			}
		 	
		 	
		 	$scope.searchID = function(documentoId){
		 		var returnStatus = false;
		 		
				if($rootScope.solicitudJson.documentos.documento != null){
					var lenDoc = $rootScope.solicitudJson.documentos.documento.length;
					var index = -1;
					
					
					if( lenDoc > 0 ){
						
						var data = $rootScope.solicitudJson.documentos.documento;
						
						index = data.map( function(d){
							return d['idDocumento'];
						}).indexOf( documentoId ); /* IDENTIFICACION */
						
						if( index >= 0 ){
							returnStatus = data[index].status == STATUS_CAPTURADO ? 
									true : data[index].status == STATUS_VERIFICADO ?
									true : data[index].status == STATUS_ENCOLADO_IPAD ?
									true : data[index].status == STATUS_VALIDADO ? true : false;  
						}
										
					}
				}				
				
				return returnStatus;
				
			};/* END SEARCH ID FUNCTION */
			
			
			$scope.docuemntosConsumo = function(){		
					var arrayPlazos = generalService.getPlazos( $rootScope );
					$scope.DocumentosComprobanbles=[{desc:IDENTIFICACION_OFICIAL_INE.descripcion, id:IDENTIFICACION_OFICIAL_INE.id},{desc:COMP_DOMICILIO.descripcion, id: COMP_DOMICILIO.id},{desc:COMP_INGRESOS.descripcion, id:COMP_INGRESOS.id}];
					for (var i = 0; i < $scope.DocumentosComprobanbles.length;){
						var borrarRegistro = $scope.searchID($scope.DocumentosComprobanbles[i].id)
						if (borrarRegistro){
							 $scope.DocumentosComprobanbles.splice(i,1);
						}else{
							i++	
						}
						
					}
					$scope.DocumentosNoComprobables=[{desc:IDENTIFICACION_OFICIAL_INE.descripcion, id:IDENTIFICACION_OFICIAL_INE.id },{desc:COMP_DOMICILIO.descripcion, id: COMP_DOMICILIO.id}];
					for (var i = 0; i < $scope.DocumentosNoComprobables.length;){
						var borrarRegistro = $scope.searchID($scope.DocumentosNoComprobables[i].id)
						if (borrarRegistro){
							 $scope.DocumentosNoComprobables.splice(i,1);
						}else{
							i++	
						}
						
					}
					if ($scope.DocumentosComprobanbles.length > 0)
						$scope.mostrarDocumentosCom=true;
					else
						$scope.mostrarDocumentosCom=false;
					
					if ($scope.DocumentosNoComprobables.length > 0)
						$scope.mostrarDocumentosNoCOm=true;
					else
						$scope.mostrarDocumentosNoCOm=false;			
			}
			
		 	
		 	$scope.rechazarOferta = function(){	
		 		
		 		
		 		modalService.confirmModal("Aviso",["¿Estás seguro que tu cliente no desea esta oferta?","Recuerda que la solicitud quedará rechazada."], "Si", "No", "bgAzul", "btn azul", "btn gris" ).then(
						function(exito){
							console.log("Continua con la oferta")
						},function(error){	
							
							var jsonSolicitud = {
									idSolicitud: $rootScope.solicitudJson.idSolicitud,
									idSeguimiento: STATUS_SOLICITUD.rechazada.id,
									marca: $rootScope.solicitudJson.marca,
									idMotivoRechazo: STATUS_SOLICITUD.rechazada.idMotivoRechazo.noAceptaOferta
									
							};
							$rootScope.waitLoaderStatus = LOADER_SHOW;
				 	
							solicitudService.actualizarSolicitud( jsonSolicitud ).then(
									function(data){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
								
										if(data.data.codigo == RESPONSE_CODIGO_EXITO){
											$rootScope.message("Aviso", ["La solicitud ha sido rechazada"],"Aceptar","/simulador");
											/*\Se agrega un evento para la bitacora\*/
											$rootScope.addEvent( BITACORA.SECCION.oferta.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.noAceptar.id, 0, BITACORA.SECCION.oferta.guardarEnBD );
											/*\Se agrega un evento para la bitacora\*/
											generalService.cleanRootScope($rootScope);
											generalService.buildSolicitudJson($rootScope, null);
											$scope.closeThisDialog(true);
								}else 
									$rootScope.message( "Error", ["Ocurrio un invonveniente, por favor, intentelo más tarde."], "Aceptar","/simulador");
					            
							}, function(error){ modalService.alertModal("Error "+error.status, [error.statusText]);}
						);}
				 );
		 		
		 	}
		   
		});
	
});