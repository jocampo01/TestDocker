'use strict';

var imagenes = new Array();

define(["app"], function (app) {
	
		app.controller('modalCotizadorNOController', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService) {
			
			var tipoTasa = tipoTasas.prestamoPersonal.id;
			$scope.MUESTRA_OFERTA=1;
			$scope.documentosDescCom = "";
			$scope.MUESTRA_OFERTA_COTIZADOR=2;
			$scope.MUESTRA_COTIZADOR=3;
			$scope.MUESTRA_ERROR=4;
			$scope.muestraRadios = false;
			$scope.OFERTA_EXITO=1;
			$scope.OFERTA_RECALCULAR=2;
			$scope.banderaComprobables = true;
			$scope.mostrarSugerido = true;
			$scope.banderaSugerido = false;
			$scope.esMenor = false;
			$scope.fechaNac = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento;
			$scope.creditoInmediatoHabilitado = $rootScope.consultaFuncionalidad.creditoInmediatoHabilitado;
			$scope.init=function(){
				$scope.objMonto=null;
				$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
				$scope.tituloHeader="Cotizador";
				$scope.opcion=$scope.MUESTRA_COTIZADOR;
				$scope.tipoOferta=$scope.OFERTA_EXITO;
				$scope.mostrarDocumentos=false;
				$scope.alcanzaMoto=false;
				$scope.listaDocumentos=[];
				$scope.muestraOfertaItalika=false;
				$scope.muestraOfertaConsumo=false;
				$scope.condicionesMostrarPantallas();
				$scope.isCreditoInmediato = $rootScope.solicitudJson.creditoInmediato==1?true:false;
				$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";
				$scope.respaldoJsonSolicitud=null;
				$scope.isComprobable=false;
				$scope.periodicidad="semanas";
				$scope.inicializaSlider();
				$scope.labelAntesModal =  '<p>Si paga puntual</p><h3>{{respaldoJsonSolicitud.cotizacion.pagoPuntual | currency:$:0}}</h3>';
				$scope.labelAhorroModal = '<p class="fVerde" style="margin-bottom:2px !important;">Se ahorra</p><h4 class="fVerde" style="font-size:14px;">{{respaldoJsonSolicitud.cotizacion.pagoNormal - respaldoJsonSolicitud.cotizacion.pagoPuntual | currency:$:0}} {{respaldoJsonSolicitud.cotizacion.periodicidad | lowercase}}</h4><h5 class="fVerde" style="margin-top:5px;font-size:13px;">{{(respaldoJsonSolicitud.cotizacion.pagoNormal - respaldoJsonSolicitud.cotizacion.pagoPuntual)*respaldoJsonSolicitud.cotizacion.plazo | currency:$:0}} total</h5>';
				//			$scope.labelAhorro = '<p class="fVerde">Su ahorro</p><h3 class="fVerde">{{solicitudJson.cotizacion.pagoNormal - solicitudJson.cotizacion.pagoPuntual | currency:$:0}}</h3><p class="fVerde">{{solicitudJson.cotizacion.periodicidad | lowercase}}es</p>';
//				$scope.labelAhorro = '<h4 class="fVerde">{{solicitudJson.cotizacion.pagoNormal - solicitudJson.cotizacion.pagoPuntual | currency:$:0}} {{solicitudJson.cotizacion.periodicidad | lowercase}}</h4>';
//				$scope.labelAhorroTotal = '<h4 class="fVerde">{{(solicitudJson.cotizacion.pagoNormal - solicitudJson.cotizacion.pagoPuntual)*solicitudJson.cotizacion.plazo | currency:$:0}} total</h4>';
				$scope.labelPlazoModal = '<p>Plazo</p><h3>{{respaldoJsonSolicitud.cotizacion.plazo}} semanas</h3>';/*<p>semanas</p>';*/
				$scope.labelPagoModal = '<p>Pagará</p><h3>{{respaldoJsonSolicitud.cotizacion.pagoNormal | currency:$:0}}</h3>';/*<p>{{solicitudJson.cotizacion.periodicidad | lowercase}}mente</p>'*/;
				$scope.respaldoJsonSolicitud=JSON.parse(JSON.stringify($rootScope.solicitudJson));
				$scope.montoCampo = $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto;
				
				$scope.segundaEdicionDatosDB = $rootScope.solicitudJson.cotizacion.clientes[0].contadorBloqueo;
				$scope.segundaEdicionDatosDH = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].contadorBloqueo;
				
				if (!$scope.muestraCPComprobable && $scope.muestraCPNoComprobable ){
					$scope.banderaComprobables = false;
				}
				$scope.calculaMaximos();
				$timeout(function(){
					$scope.banderaSugerido = true;
				}, 800)
				
				$scope.banderaComprobables = ($scope.banderaComprobableAux)?true:false
			};
			
			$scope.inicializaSlider=function(){
				if($rootScope.buroHandler){
					$scope.buildSlider();
				}					
			};
			
			$scope.condicionesMostrarPantallas=function(){
				$scope.muestraOfertaItalika=false;
				$scope.muestraOfertaConsumo=false;
				if($rootScope.solicitudJson.idCanal==CANALES.soriana){
					$scope.muestraOfertaItalika=true;
					if($rootScope.buroHandler)
						$scope.alcanzaMoto=true;
					else
						$scope.alcanzaMoto=false;
				}else if($rootScope.solicitudJson.idProducto == ID_PRODUCTO.consumo ||
						 $rootScope.solicitudJson.idProducto == ID_PRODUCTO.italika ||
						 $rootScope.solicitudJson.idProducto == ID_PRODUCTO.telefonia){
					$scope.muestraOfertaConsumo=true;
					$scope.evaluarCPenConsumo();
					$scope.docuemntosConsumo();
				}
				$scope.evaluarCPenConsumo();	
				var muestraOferta=false;
				var muestraCotizador=false;
				var error=false;
				$rootScope.onceOfert=false;
				$rootScope.mostrarOfertaCotizador=false;
//				if($rootScope.solicitudJson.banderaOfertaCP == 0 && $rootScope.onceOfert)
						muestraOferta=true;						
				
				switch($rootScope.buroConditional){
					case BURO_RECALCULAR_PLAZO:
					case BURO_AUTORIZADO_PORCOMPROBAR:
						$scope.tituloHeader="¡Lo sentimos!";
						muestraCotizador=true;
						$scope.tipoOferta=$scope.OFERTA_RECALCULAR;
						$scope.generaVariablesMejorOferta();
						break;
					case BURO_AUTORIZADO_SCORE:
					case RESPONSE_ORIGINACION_CODIGO_EXITO:
						if(muestraOferta)
							$scope.tituloHeader="¡FELICIDADES!";
						muestraCotizador=true;
						break;
					default:
						error=true;
				}
				
				if(error)
					$scope.opcion=$scope.MUESTRA_ERROR;
				else if(muestraOferta && muestraCotizador)
					$scope.opcion=$scope.MUESTRA_OFERTA_COTIZADOR;
				else if(muestraOferta)
					$scope.opcion=$scope.MUESTRA_OFERTA;
				else if(muestraCotizador)
					$scope.opcion=$scope.MUESTRA_COTIZADOR;
			};
			
			function validaPlazosVista(arrayPlazos){
				var plazos = arrayPlazos;
				$scope.banderaComprobableAux = 0;
				$scope.banderaNoComprobableAux = 0;
				
				for(var i=0;i<plazos.length;i++){
					if(plazos[i].cpNoComprobable != null){
						$scope.banderaNoComprobableAux = 1;
					}
					
					if(plazos[i].cpComprobable != null){
						$scope.banderaComprobableAux = 1;
					}
				}
			}
			
			$scope.evaluarCPenConsumo=function(){
				$scope.muestraCPNoComprobable=false;
				$scope.muestraCPComprobable=false;
				$scope.muestraCPNoComprobableInmediato=false;
				$scope.muestraCPComprobableInmediato=false;
				
				var arrayPlazos = generalService.getPlazos( $rootScope );
				validaPlazosVista(arrayPlazos);
				
				var ingresoComp=$scope.getTipoIngreso(3);
				var ingresoNoComp=$scope.getTipoIngreso(4);
				
				if($rootScope.solicitudJson.capacidadPagoNoComprobable >= 50 && 
						(ingresoNoComp || ingresoComp)) {
					$scope.muestraCPNoComprobable=true;
				}
				
				if($rootScope.solicitudJson.capacidadPagoComprobable >= 50 && ingresoComp) {
					$scope.muestraCPComprobable=true;
				}
				
				if ($scope.muestraCPNoComprobable && $scope.muestraCPComprobable ){
					$scope.muestraRadios = true;
				}
				if(arrayPlazos){
					if(arrayPlazos.length>0){
						if(arrayPlazos[0].comprobableInm == 1 && $scope.muestraCPComprobable)
							$scope.muestraCPComprobableInmediato=true;
						if(arrayPlazos[0].noComprobableInm == 1 && $scope.muestraCPNoComprobable)
							$scope.muestraCPNoComprobableInmediato=true;
					}
				}
			};
			
			$scope.getTipoIngreso=function(tipoIngreso){
				var arrayFlujo = $rootScope.solicitudJson.cotizacion.clientes[0].flujoEfectivo;
				for(var efectivo in arrayFlujo){
					if(arrayFlujo[efectivo].idConcepto==tipoIngreso)
						return true;
				}
				return false;

			};
			
			$scope.generaVariablesMejorOferta=function(){
				var arrayPlazos = generalService.getPlazos( $rootScope );
				if(arrayPlazos){
					var monto = parseInt($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto);
					
					var index = arrayPlazos.map(function(d){
						return d["monto"];
						
					}).indexOf (monto);
					if (index != -1){
						$scope.montoOferta = parseInt($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto);
					}else{
						var montoMayor = $scope.regresaMayor(arrayPlazos, "monto");
						$scope.montoOferta=montoMayor.valor; 
						index = montoMayor.posicion;
					}
					
					var plazo = $rootScope.solicitudJson.cotizacion.plazo;
					var arrelgoPlazos =arrayPlazos[index];
					if (arrayPlazos[index].cpNoComprobable){
						var index1 = arrelgoPlazos.cpNoComprobable.indexOf( plazo );		
						if( index1 != -1 ){
							$scope.plazoOferta=plazo;
							$scope.Montocomprobables = false;
						}else{
								if (arrayPlazos[index].cpComprobable)
									index1 = arrelgoPlazos.cpComprobable.indexOf( plazo );	
								else
									index1 = -1;
							
								if( index1 != -1 ){
									$scope.plazoOferta=plazo;
									$scope.Montocomprobables = true;
								}else{
									var plazoMayor = $scope.regresaMayor(arrayPlazos[index].cpNoComprobable);
									$scope.Montocomprobables = false;
									if (!plazoMayor.encontro){
										plazoMayor = $scope.regresaMayor(arrayPlazos[index].cpComprobable);
										$scope.Montocomprobables = true;
									}
									index1 = plazoMayor.posicion;
									$scope.plazoOferta=plazoMayor.valor
								}
						}
					}else{
						if (arrayPlazos[index].cpComprobable)
							var index1 = arrelgoPlazos.cpComprobable.indexOf( plazo );
						else
							var index1 = -1;
						$scope.Montocomprobables = true;
						if( index1 != -1 ){
							$scope.plazoOferta=plazo;
						}else{
							plazoMayor = $scope.regresaMayor(arrayPlazos[index].cpComprobable);
							index1 = plazoMayor.posicion;
							$scope.plazoOferta=plazoMayor.valor
						}
					}
					console.log("comprobables " + $scope.Montocomprobables)
					if ($scope.Montocomprobables){
						if(arrayPlazos[index].comprobableInm == 1)
							$scope.creditoInmediatoOferta=true;
						else
							$scope.creditoInmediatoOferta=false;
					}else{
						if(arrayPlazos[index].noComprobableInm == 1)
							$scope.creditoInmediatoOferta=true;
						else
							$scope.creditoInmediatoOferta=false;
					}
	//				$scope.montoOferta=montoMayor.valor; 
	//				$scope.plazoOferta=plazoMayor.valor
					$scope.periodicidadOferta="semanas";
	//				$scope.actualizaPlazo($scope.plazoOferta);
					$scope.respaldoNuevoPlazo=$scope.plazoOferta;
	//				$scope.creditoInmediatoOferta=false;
				}
			};
			
			
			$scope.buildSlider = function(){
				
				var cambiaMontoCallback = function( valorSlider ){
			 		$timeout( function(){ 
		 				angular.element( document.getElementById( "volverCotizar" ) ).scope().reBuildSlider( valorSlider );
		 			}, 0);
				};
				
				if( $scope.$parent.muestraTermometro){
					
					var plazos = generalService.getPlazos($rootScope );
					  
					var arrayMontos = plazos.map( function(d){
						return d['monto'];
					});
					
					arrayMontos = generalService.mergeSort(arrayMontos);
					
					var monto = parseInt($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto);
					var index = arrayMontos.indexOf( monto );

					var _min = Math.min.apply( 0, arrayMontos );
					var _max = Math.max.apply( 0, arrayMontos );
									
					if( index == -1 )
						monto = _max;
					  
					$scope.minMonto = _min;
					$scope.maxMonto = _max;
					
					var step=500;
					var len = arrayMontos.length;
					
					if( arrayMontos[0] )
						if( arrayMontos[1] )
							step = arrayMontos[1]-arrayMontos[0];
					
					var fnCrearSliderCallBack = function(){
						slider( _min , _max, step, monto, '.amountVolCotizar div', arrayMontos, cambiaMontoCallback, "#sliderVolCotizar");
					};
					
					$scope.createSliderThread( 'sliderVolCotizar', fnCrearSliderCallBack, true );
					
				}
				
			};
			
			
			
			$scope.reBuildSlider = function ( valorSlider )
			{		

				var cambiaMontoCallback = function(){								
	
					
					
					$scope.plazosCotizador = $scope.calculaPlazosTermometroNuevo( valorSlider);				
					var plazo = $scope.respaldoNuevoPlazo?$scope.respaldoNuevoPlazo:$rootScope.solicitudJson.cotizacion.plazo;
					$scope.respaldoNuevoPlazo = plazo;
					var encontro = false;
					for (var i = 0; i < $scope.plazosCotizador.length; i++){
						if ($scope.plazosCotizador[i] >= $scope.respaldoNuevoPlazo){
							plazo = $scope.plazosCotizador[i];
							encontro = true
							break;
						}
					 }
					 if (!encontro){
					 	plazo = $scope.plazosCotizador[$scope.plazosCotizador.length - 1]
					 }
					 console.log(plazo);
					
//					var plazo = $scope.respaldoNuevoPlazo?$scope.respaldoNuevoPlazo:$rootScope.solicitudJson.cotizacion.plazo;
					
					$timeout(function(){
						$scope.actualizaMonto();	 		
						$scope.validaPlazoComprobableInmediato(plazo,valorSlider);
						$scope.calculaNuevosMontos();						
					}, 50)
			 		
					var index = $scope.plazosCotizador.indexOf( plazo );
					$scope.deshabilitarRecalcular = true;
			 		$scope.actualizaMonto();
			 		$scope.calculaMaximos();
					if(index != -1 ){
						if(plazo = plazo)
						$scope.validaPlazoComprobableInmediato( plazo, valorSlider ); 
						$scope.calculaNuevosMontos();
						$timeout( function(){
							$('.requisitosCot ul li > a').each(function(){
								if( parseInt($(this).text()) == parseInt(plazo) ){
									if(!$(this).hasClass( "active" )){
										limpiarClasePlazos();
										$( this ).addClass('active'); 
									}
									return;
								};
							});
							$scope.actualizaPlazo();
						}, 10 );
					}else{
						$scope.mostrarDocumentos=false;
						limpiarClasePlazos();
						$scope.nuevoPlazo=0;
						$scope.actualizaPlazo($scope.plazosCotizador[$scope.plazosCotizador.length - 1]);
					}
									
				};
				
				$scope.createSliderThread( 'sliderVolCotizar', cambiaMontoCallback, false );
				$timeout(function(){$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
				if($scope.nuevoMonto != $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto)
					$scope.buildSliderNoCom($scope.banderaComprobables);
				}, 100);
					 		
		 	};/* END UISLIDER FUNCTION */
		 	
			$scope.createSliderThread = function( idSlider, fnCrearSliderCallBack, isFirstTime ){											
				
				var stopInterval = null, intervalCont = 1;
				
				var verifySlider = function(){
					var sliderVal = $( "#" + idSlider ).slider( "value" );
					return !(isNaN( sliderVal ));
				};
								
				var trySlider = function(){					
					if( verifySlider() ){
						$interval.cancel( stopInterval )
						if( fnCrearSliderCallBack && fnCrearSliderCallBack != null )
							fnCrearSliderCallBack();
					}else if( intervalCont == 100 )
						$interval.cancel( stopInterval )
					else{
						intervalCont++;
						if( isFirstTime )
							if( fnCrearSliderCallBack && fnCrearSliderCallBack != null )
								fnCrearSliderCallBack();
					}
				};
				stopInterval = $interval( trySlider, 100 );
										
				
			};/* END THREAD SLIDER FUNCTION */
			
			
			$scope.calculaPlazosTermometroNuevo = function( valor){
				var arrayPlazos = generalService.getPlazos( $rootScope ); 
				
				var index = arrayPlazos.map( function(d){
					return d['monto'];
				}).indexOf( parseInt(valor) );
				
				if( arrayPlazos.length == 0 ){
					$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
					$scope.opcion=$scope.MUESTRA_ERROR;
					return [];
				}			
				
				if( index != -1 ){
					
					var plazos = [];
					var _comprobables = arrayPlazos[index].cpComprobable;
					var _noComprobables = arrayPlazos[index].cpNoComprobable;
					
					_comprobables = _comprobables ? _comprobables : [];
					_noComprobables = _noComprobables ? _noComprobables : [];
					
					var comprobables = _comprobables;
					var noComprobables = _noComprobables;
					
					if (!$scope.banderaComprobables){
						comprobables = noComprobables
					}
					
					for( var i = 0; i < comprobables.length; i++ ){	
						if( plazos.indexOf( comprobables[i] ) == -1 ){
							plazos.push( comprobables[i] );
						}	
					}/* END FOR */
					
					return plazos.sort( function( a, b ){
						return a-b;/* Invert to asc */
					});
					
				}/* END IF INDEX */
				return [];
				
			};
			
			
			
			
			$scope.calculaPlazosTermometro = function( valor){
				var arrayPlazos = generalService.getPlazos( $rootScope ); 
				
				var index = arrayPlazos.map( function(d){
					return d['monto'];
				}).indexOf( parseInt(valor) );
				
				if( arrayPlazos.length == 0 ){
					$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
					$scope.opcion=$scope.MUESTRA_ERROR;
					return [];
				}			
				
				if( index != -1 ){
					
					var plazos = [];
					var _comprobables = arrayPlazos[index].cpComprobable;
					var _noComprobables = arrayPlazos[index].cpNoComprobable;
					
					_comprobables = _comprobables ? _comprobables : [];
					_noComprobables = _noComprobables ? _noComprobables : [];
					
					if( _comprobables.length > _noComprobables.length ){
						var comprobables = _comprobables;
						var noComprobables = _noComprobables;
					}else{
						var comprobables = _noComprobables;
						var noComprobables = _comprobables;
					}	
					
					for( var i = 0; i < comprobables.length; i++ ){
							
						if( noComprobables[i] ){
							
							if( plazos.indexOf( comprobables[i] ) == -1 ){
								plazos.push( comprobables[i] );
							}
							
							if( plazos.indexOf( noComprobables[i] ) == -1 ){
								plazos.push( noComprobables[i] );
							}
							
						}else{
							if( plazos.indexOf( comprobables[i] ) == -1 ){
								plazos.push( comprobables[i] );
							}
						}
							
					}/* END FOR */
					
					return plazos.sort( function( a, b ){
						return a-b;/* Invert to asc */
					});
					
				}/* END IF INDEX */
				return [];
				
			};
			
			
			$scope.validaPlazoComprobableInmediato = function( plazo, monto ){
				var arrayPlazos = generalService.getPlazos( $rootScope ); 
				var tiposComprobantes=null;
				var indexPlazo = arrayPlazos.map( function(d){
					return d[ 'monto' ];
				}).indexOf( parseInt(monto) );
				
				var index = -1;
				var comprobante = false;
				var tiposComprobantes = null;
				
				if( indexPlazo != -1 && !$scope.banderaComprobables){
					
					var condicionRequeridaC = arrayPlazos[indexPlazo].requeridoComprobable;
					var condicionRequeridaNC = arrayPlazos[indexPlazo].requeridoNoComprobable;
					
					if( condicionRequeridaC != '' && condicionRequeridaC != null )
						condicionRequeridaC = condicionRequeridaC.split(",");
					if( condicionRequeridaNC != '' && condicionRequeridaNC != null )
						condicionRequeridaNC = condicionRequeridaNC.split(",");
					
					if( arrayPlazos[indexPlazo].cpNoComprobable ){
						
						index = arrayPlazos[indexPlazo].cpNoComprobable.indexOf( parseInt(plazo) );
						
						if( typeof condicionRequeridaNC == "object" && index != -1 && condicionRequeridaNC != null ){
							comprobante = true;
							tiposComprobantes = arrayPlazos[indexPlazo].requeridoNoComprobable;
						}
				
						if( index == -1 ){
							
							index = arrayPlazos[indexPlazo].cpComprobable.indexOf( parseInt(plazo) );
							
							if( typeof condicionRequeridaC == "object" && condicionRequeridaC != null){
								comprobante = true;
								tiposComprobantes = arrayPlazos[indexPlazo].requeridoComprobable;
							}
							
							if( index != -1 )
								comprobante = true;
													
						}
						
					}else{
						
						if( arrayPlazos[indexPlazo].cpComprobable && $scope.banderaComprobables){
							
							index = arrayPlazos[indexPlazo].cpComprobable.indexOf( parseInt(plazo) );
							
							if( typeof condicionRequeridaC == "object" && condicionRequeridaC != null ){
								comprobante = true;
								tiposComprobantes = arrayPlazos[indexPlazo].requeridoComprobable; 
							}
							
							if( index != -1 )
								comprobante = true;
							
						}
						
					}
					$scope.objMonto=arrayPlazos[indexPlazo];	
				}					
				$scope.isCreditoInmediato=false;
				//validar si ese plazo tiene credito inmediato
				if( comprobante ){
					$scope.isComprobable=true;
					if(arrayPlazos[indexPlazo].comprobableInm)
						$scope.isCreditoInmediato = (generalService.validaEdad($scope.fechaNac) || $scope.creditoInmediatoHabilitado==false) ? false : true;
					$scope.listaDocumentos=[{desc:IDENTIFICACION_OFICIAL.descripcion, id:IDENTIFICACION_OFICIAL.id },{desc:COMP_DOMICILIO.descripcion, id: COMP_DOMICILIO.id}];
//					if(tiposComprobantes.split(",").indexOf("CI")!=-1){
					if ($scope.banderaComprobables){
					$scope.listaDocumentos.push({desc:COMP_INGRESOS.descripcion, id:COMP_INGRESOS.id });
					}
					
					
//					for (var i = 0; i < $scope.listaDocumentos.length;){
//						var borrarRegistro = $scope.searchID($scope.listaDocumentos[i].id)
//						if (borrarRegistro){
//							 $scope.listaDocumentos.splice(i,1);
//						}else{
//							i++	
//						}
//						
//					}
					if ($scope.listaDocumentos.length > 0){
						$scope.mostrarDocumentos=true;
						$scope.documentosDescCom = $scope.crearLista($scope.listaDocumentos);
					}else
						$scope.mostrarDocumentos=false;
				}else{
					$scope.listaDocumentos=[{desc:IDENTIFICACION_OFICIAL.descripcion, id:IDENTIFICACION_OFICIAL.id },{desc:COMP_DOMICILIO.descripcion, id: COMP_DOMICILIO.id}];
					if ($scope.banderaComprobables){
						tiposComprobantes = arrayPlazos[indexPlazo].requeridoComprobable;
//						if(tiposComprobantes.split(",").indexOf("CI")!=-1){
						$scope.listaDocumentos.push({desc:COMP_INGRESOS.descripcion, id:COMP_INGRESOS.id });
//						}
					}
//					for (var i = 0; i < $scope.listaDocumentos.length;){
//						var borrarRegistro = $scope.searchID($scope.listaDocumentos[i].id)
//						if (borrarRegistro){
//							 $scope.listaDocumentos.splice(i,1);
//						}else{
//							i++	
//						}
						
//					}
					if ($scope.listaDocumentos.length > 0){
						$scope.mostrarDocumentos=true;
						$scope.documentosDescCom = $scope.crearLista($scope.listaDocumentos);
					}else{
						$scope.mostrarDocumentos=false;
					}
					
					
					if(arrayPlazos[indexPlazo].noComprobableInm)
						$scope.isCreditoInmediato = (generalService.validaEdad($scope.fechaNac) || $scope.creditoInmediatoHabilitado==false) ? false : true;
//					$scope.mostrarDocumentos=false;
//					$scope.listaDocumentos=[];
					$scope.isComprobable=false;
				}				
				//Activamos la bandera en cero si existe una segunda edición de datos dentro de las secciones de DH o DB.
				if(($scope.segundaEdicionDatosDB == SEGUNDA_EDICION_DATOS || $scope.segundaEdicionDatosDH == SEGUNDA_EDICION_DATOS) && $rootScope.solicitudJson.creditoInmediato==0)
					$scope.isCreditoInmediato = false;
				
				return comprobante;
				
			};
			
			
			function limpiarClasePlazos(){
				$('.requisitosCot ul li > a').each(function(){
		 			$( this ).removeClass('active');
		 	    });
				
			};/* END LIMPIAR CLASE PLAZO FUNCTION */
			
		 	$scope.onSeleccionaPlazo = function(valor,ui){	 		 		 	
		 		$scope.actualizaMonto();
		 		$scope.actualizaPlazo(ui.target.parentNode);		 		
		 		$scope.validaPlazoComprobableInmediato($scope.nuevoPlazo,$scope.nuevoMonto);
		 		$scope.calculaNuevosMontos();
		 		if ($scope.banderaSugerido){
					$scope.mostrarSugerido = false;
				}
		 			 		
		 	};/* END CONDICIONES TERMOMETRO FUNCTION */
		 	
		 	$scope.actualizaMonto=function(){
		 		$scope.nuevoMonto= $( "#sliderVolCotizar" ).slider( "value" );
		 	};
		 	
		 	$scope.actualizaPlazo=function(nuevoPlazo){
		 		var plazo;
	 			if(nuevoPlazo){
	 				limpiarClasePlazos();
	 				$(nuevoPlazo).addClass('active');
	 			}
		 		$('.requisitosCot ul li > a').each(function(){
			 		if( $( this ).hasClass('active') ){
			 			plazo = parseInt( $(this).text() ); 
			 			return;
			 		};
			 	});
		 		$scope.nuevoPlazo= plazo;
		 		$scope.respaldoNuevoPlazo= plazo;
		 	};
		 
		 	$scope.esMenor = (generalService.validaEdad($scope.fechaNac) || $scope.creditoInmediatoHabilitado==false) ? true : false;
		 	
		 	$scope.volverACotizar = function(detalle){
		 		
		 		if (!detalle){
		 			console.log("normal");
		 		}else{
		 			$scope.nuevoPlazo = detalle.plazo;
		 			$scope.nuevoMonto =  detalle.monto;
		 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = detalle.monto;
		 			$scope.respaldoJsonSolicitud.cotizacion.montoTotal = detalle.montoTotal;
		 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = detalle.intereses;
		 			$scope.respaldoJsonSolicitud.cotizacion.pagoNormal = detalle.pagoNormal;
		 			$scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = detalle.pagoPuntual;
		 			$scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = detalle.ultimoAbono;
		 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto = detalle.idProducto;
		 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = detalle.cantidad;
		 			$scope.respaldoJsonSolicitud.cotizacion.plazo = detalle.plazo;
		 			$scope.respaldoJsonSolicitud.cotizacion.idPlazo = detalle.idPlazo; 
		 			console.log(detalle);
		 		}
				$scope.respaldoJsonSolicitud=JSON.parse(JSON.stringify($rootScope.solicitudJson));
				$scope.respaldoJsonSolicitud.banderaOfertaCP= 1;
		 		if($scope.opcion==$scope.MUESTRA_OFERTA){
		 			$rootScope.waitLoaderStatus = LOADER_SHOW;
		 			$scope.guardarSeccion();
		 		}else{
					if( $scope.nuevoPlazo &&  $scope.nuevoMonto){
			 			$rootScope.waitLoaderStatus = LOADER_SHOW;
	 		 			if($scope.calculaNuevosMontos()){
		 		 			$scope.validaCreditoInmediatoIngresos();
		 		 			$scope.guardarSeccion();
	 		 			}
	
					}
		 		}
		 	};
		 	
		 	$scope.validaCreditoInmediatoPorColor = function(){
		 		
		 		if($rootScope.solicitudJson.banderaIngresos == 0 && ($rootScope.solicitudJson.idColorNC == 1 || $rootScope.solicitudJson.idColorNC == 2 || $rootScope.solicitudJson.idColorNC == 3 || $rootScope.solicitudJson.idColorNC == 7)){
		 			$scope.respaldoJsonSolicitud.creditoInmediato = 1;
		 	
		 		}else{
		 			if($rootScope.solicitudJson.banderaIngresos == 1 && ($rootScope.solicitudJson.idColor == 1 || $rootScope.solicitudJson.idColor == 2 || $rootScope.solicitudJson.idColor == 3 || $rootScope.solicitudJson.idColor == 7)){
		 				$scope.respaldoJsonSolicitud.creditoInmediato = 1;
			 	
			 		} else {
			 			$scope.respaldoJsonSolicitud.creditoInmediato = 0;
			 		}
		 		}
		 	};
		 	
		 	//Modifica la bandera de ingresos si existen ediciones dentro de las secciones de datos del Hogar o datos Básicos.
		 	$scope.validaExiteEdicionesSecciones=function(){
		 		if($scope.segundaEdicionDatosDB == SEGUNDA_EDICION_DATOS || $scope.segundaEdicionDatosDH == SEGUNDA_EDICION_DATOS)
		 			$scope.respaldoJsonSolicitud.creditoInmediato = 0;
		 	};
		 	
		 	$scope.cotizarConsumo = function(ingresos){
		 		$rootScope.waitLoaderStatus = LOADER_SHOW;
		 		$scope.respaldoJsonSolicitud.banderaOfertaCP= 1;
		 		$scope.respaldoJsonSolicitud.banderaIngresos = ingresos;
		 		$scope.guardarSeccion();
		 	};
		 	
		 	$scope.seleccionarOtraMoto=function(){		 		
		 		$scope.closeThisDialog(true);		 				 		
		 		generalService.setArrayValue("cotizacionOfertaItalika", JSON.stringify($rootScope.solicitudJson.cotizacion));
		 		generalService.locationPath("/catalogoItalika");		 		
		 	};
			
		 	$scope.validaCreditoInmediatoIngresos=function(){
		 		$scope.validaCreditoInmediatoPorColor();
		 		//Validamos las secciones 1 o 2 (Existe Edición)
		 		$scope.validaExiteEdicionesSecciones();
		 		if(generalService.validaEdad($scope.fechaNac) || !generalService.validaCreditoInmediatoProducto() || $rootScope.solicitudJson.creditoInmediatoInhabilitado>0)
		 			$scope.respaldoJsonSolicitud.creditoInmediato = 0;		 		 
					
				if($scope.banderaComprobables)
					$scope.respaldoJsonSolicitud.banderaIngresos = 1;
				else
					$scope.respaldoJsonSolicitud.banderaIngresos = 0;
		 		
		 	};
		 	
			$scope.calculaNuevosMontos = function(){	 
				
		 			var monto =  $scope.nuevoMonto;
			 		var periodicidad = $scope.respaldoJsonSolicitud.cotizacion.idPeriodicidad;
			 		var plazo = $scope.nuevoPlazo;			 	
			 		
			 		if($scope.muestraOfertaItalika){
			 			var pagoNormal;
			 			var pagoPuntual;
			 			for(var abonoItalika in $scope.objMonto.abonoSemanal){
			 				if($scope.objMonto.abonoSemanal[abonoItalika].plazo==plazo){
			 					pagoNormal=$scope.objMonto.abonoSemanal[abonoItalika].pagoNormal;
			 					pagoPuntual=$scope.objMonto.abonoSemanal[abonoItalika].pagoPuntual;
			 					break;	
			 				}			 						 					
			 			}
			 			if(pagoNormal && pagoPuntual){				
			 				var montoConIntereses = pagoNormal * plazo;
			 				
			 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = monto;
			 				$scope.respaldoJsonSolicitud.cotizacion.montoTotal = montoConIntereses;
			 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = montoConIntereses - monto;
			 				$scope.respaldoJsonSolicitud.cotizacion.pagoNormal = pagoNormal;
			 				
			 				$scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = pagoPuntual;
			 				$scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = pagoNormal;				
			 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = 1;
		 					$scope.respaldoJsonSolicitud.cotizacion.plazo = plazo;
		 					$scope.respaldoJsonSolicitud.cotizacion.idPlazo = plazo; 
			 							 				
			 			}else
			 				return null;
			 		}else{
			 			
			 			var arrayTempAbonos = $rootScope.consultaAbonos.prestamosPersonales;
			 			for (var i = 0; i < arrayTempAbonos.length;i++){
				 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){
				 				   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = monto;
				 				   $scope.respaldoJsonSolicitud.cotizacion.montoTotal = parseInt(arrayTempAbonos[i].precio) + parseInt(arrayTempAbonos[i].sobre);
			 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = parseInt(arrayTempAbonos[i].sobre);
			 					   $scope.respaldoJsonSolicitud.cotizacion.pagoNormal = parseFloat(arrayTempAbonos[i].normal);
			 					   $scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = parseFloat(arrayTempAbonos[i].puntual);
			 					   $scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = parseInt(arrayTempAbonos[i].ultimo);
			 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto = arrayTempAbonos[i].sku;
			 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = 1;
			 					   $scope.respaldoJsonSolicitud.cotizacion.plazo = plazo;
			 					   $scope.respaldoJsonSolicitud.cotizacion.idPlazo = plazo; 
			 					   break; 
				 			}
				 		}
			 			
			 			
//				 		var arrayPlazoMonto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA",tipoTasa);
//				 		for ( var i = 1; i <= arrayPlazoMonto.length; i++ ){
//		 					
//				 			if (monto        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.MONTO["+i+"].valor",tipoTasa) &&
//		 						periodicidad == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PERIODICIDADID["+i+"].valor",tipoTasa) &&
//		 						plazo        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PLAZO["+i+"].valor",tipoTasa) ){ 						
//		 					   var tasaNormal = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA NORMAL["+i+"].valor",tipoTasa));
//		 					   var tasaPuntual = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA PUNTUAL["+i+"].valor",tipoTasa));
//		 					   var idProducto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PRODUCTOID["+i+"].valor",tipoTasa);
//		 					   var montoNormal = monto * tasaNormal;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = monto;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.montoTotal = monto + montoNormal;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].intereses = parseInt($scope.respaldoJsonSolicitud.cotizacion.montoTotal - monto);
//		 					   $scope.respaldoJsonSolicitud.cotizacion.pagoNormal = Math.round(parseFloat($scope.respaldoJsonSolicitud.cotizacion.montoTotal / plazo));
//		 					   var montoPuntual = monto * tasaPuntual;
//		 					   var montoTotalPuntual = monto + montoPuntual;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.pagoPuntual = Math.round(parseFloat(montoTotalPuntual / plazo));
//		 					   $scope.respaldoJsonSolicitud.cotizacion.ultimoAbono = parseInt($scope.respaldoJsonSolicitud.cotizacion.montoTotal - $scope.respaldoJsonSolicitud.cotizacion.pagoNormal * (plazo - 1));
//		 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].idProducto = idProducto;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].cantidad = 1;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.plazo = plazo;
//		 					   $scope.respaldoJsonSolicitud.cotizacion.idPlazo = plazo; 
//		 					   break;
//		 					}
//		 					
//				 		}
			 			
			 		}
			 		return true;
			 		
		 	};
		 	
		 	$scope.guardarSeccion = function(){	
		 		
		 		solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($scope.respaldoJsonSolicitud), seccion: SECCION_SOLICITUD } ).then(
			 			function(data){
			 				$rootScope.waitLoaderStatus = LOADER_HIDE;
			 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
			 					var responseJson = JSON.parse(data.data.respuesta);
			 					
			 					var fnStatusOK = function( esMalZonificada ){
									$scope.$parent.muestraAlertaNuevoBuro=false;
									$scope.$parent.muestraMensajeNuevoBuro=false;
									$scope.$parent.mensajeNuevoBuro=""
									$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO; //FIX COMMENT 01/04/2016
			 						$rootScope.solicitudJson = responseJson.data;
									if( esMalZonificada && typeof esMalZonificada !== 'undefined' ){
										var excepciones = [ SECCION_HOGAR.toString() ];
										generalService.bloqueoSecciones( $rootScope.solicitudJson, excepciones );
									}
									$rootScope.calculaDocumentos();
									$scope.$parent.buildMenuList();
									$scope.closeThisDialog(true);		
								
			 					};
			 					
			 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
									fnStatusOK();							
								}else if( responseJson.codigo == STATUS_SOLICITUD.malZonificada.guardarSeccion ){
									generalService.setDataBridge( {esMalZonificada:true} );
									fnStatusOK( true );
								}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
								}else{
									if(responseJson.codigo == ERROR_SOL_RECHAZADA){
										var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
										var marca = $rootScope.solicitudJson.marca;
										var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
										var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
										$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],"Aceptar", "/simulador",null,null,buildJsonDefault);
									}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
										generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
										$scope.closeThisDialog(true);
										generalService.locationPath("/ficha");
									}else{
										$rootScope.message("Error "+responseJson.codigo,[ $scope.mensajeError],"Aceptar", null);
									}
			 					}
			 				}else{
			 					$rootScope.message("Error",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
			 				}
			 			}, function(error){                     
			 				$rootScope.waitLoaderStatus = LOADER_HIDE;
			 				$rootScope.message("Error al volver a cotizar",[ $scope.mensajeError], "Aceptar", null);								
			 			}	
					);
			}
		 	
		 	$scope.regresaMayor = function(arreglo, campo){
				var auxiliar = 0;
				var posicion = 0;
				var encontro = false;
				if (arreglo){
					for(var i = 0; i< arreglo.length; i++){
						if (campo){
							if (auxiliar < arreglo[i][campo]){
								auxiliar =arreglo[i][campo];
								posicion = i;	
								encontro = true
							}	
						}else{
							if (auxiliar < arreglo[i]){
								auxiliar =arreglo[i];
								posicion = i;
								encontro = true
							}	
						}
					}
				}
				return {"posicion": posicion, "valor": auxiliar, "encontro": encontro};
			}
		 	
		 	
		 	$scope.searchID = function(documentoId){
		 		var returnStatus = false;
		 		
				if($rootScope.solicitudJson.documentos.documento != null){
					var lenDoc = $rootScope.solicitudJson.documentos.documento.length;
					var index = -1;
					
					
					if( lenDoc > 0 ){
						
						var data = $rootScope.solicitudJson.documentos.documento;
						
						index = data.map( function(d){
							return d['idDocumento'];
						}).indexOf( documentoId ); /* IDENTIFICACION */
						
						if( index >= 0 ){
							returnStatus = data[index].status == STATUS_CAPTURADO ? 
									true : data[index].status == STATUS_VERIFICADO ?
									true : data[index].status == STATUS_ENCOLADO_IPAD ?
									true : data[index].status == STATUS_VALIDADO ? true : false;  
						}
										
					}
				}				
				
				return returnStatus;
				
			};/* END SEARCH ID FUNCTION */
			
			
			$scope.docuemntosConsumo = function(){		
					var arrayPlazos = generalService.getPlazos( $rootScope );
					$scope.DocumentosComprobanbles=[{desc:IDENTIFICACION_OFICIAL.descripcion, id:IDENTIFICACION_OFICIAL.id},{desc:COMP_INGRESOS.descripcion, id:COMP_INGRESOS.id},{desc:COMP_DOMICILIO.descripcion, id: COMP_DOMICILIO.id}];
					for (var i = 0; i < $scope.DocumentosComprobanbles.length;){
						var borrarRegistro = $scope.searchID($scope.DocumentosComprobanbles[i].id)
						if (borrarRegistro){
							 $scope.DocumentosComprobanbles.splice(i,1);
						}else{
							i++	
						}
						
					}
					$scope.DocumentosNoComprobables=[{desc:IDENTIFICACION_OFICIAL.descripcion, id:IDENTIFICACION_OFICIAL.id },{desc:COMP_DOMICILIO.descripcion, id: COMP_DOMICILIO.id}];
					for (var i = 0; i < $scope.DocumentosNoComprobables.length;){
						var borrarRegistro = $scope.searchID($scope.DocumentosNoComprobables[i].id)
						if (borrarRegistro){
							 $scope.DocumentosNoComprobables.splice(i,1);
						}else{
							i++	
						}
						
					}
					if ($scope.DocumentosComprobanbles.length > 0){
						$scope.mostrarDocumentosCom=true;
						$scope.documentosDescCom = $scope.crearLista($scope.DocumentosComprobanbles);
					}else
						$scope.mostrarDocumentosCom=false;
					
					if ($scope.DocumentosNoComprobables.length > 0){
						$scope.mostrarDocumentosNoCOm=true;
						$scope.documentosDescnoCom = $scope.crearLista($scope.DocumentosComprobanbles);
					}else
						$scope.mostrarDocumentosNoCOm=false;	
					
					
			}
			
			$scope.crearLista = function(array){
				var aux = ""
				if (array.length == 1){
					aux = array[0].desc
				}else{
					for(var i = 0; i < array.length; i++){
						if (i == (array.length - 1) ){
							aux = aux + " y " + array[i].desc;
						}else if (i == 0)  {
							aux =  array[i].desc;
						}else{
							aux = aux + ", " + array[i].desc;
						}
							
					}
				}
				return aux;
			}
			
			$scope.radiosingresos = function(valor){
				$scope.banderaComprobables = valor;
				if($scope.banderaComprobables){
					$scope.buildSliderNoCom(true);
					$timeout(function(){$scope.buildSliderNoCom(true);
					if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxCom.monto)
						$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = $scope.maxCom.monto;
					$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto, 0);
					}, 1)
				}else{
					$scope.buildSliderNoCom(false);
					$timeout(function(){$scope.buildSliderNoCom(false);
					if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxNoCom.monto)
						$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = $scope.maxNoCom.monto;
					$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto, 0);
					}, 1)
				}
			}
			
			$scope.buildSliderNoCom = function(comprobables){
				
				var cambiaMontoCallback = function( valorSlider ){
			 		$timeout( function(){ 
		 				angular.element( document.getElementById( "volverCotizar" ) ).scope().reBuildSlider( valorSlider );
		 			}, 0);
				};
				
				if( $scope.$parent.muestraTermometro){
					
					var plazosArray = generalService.getPlazos($rootScope );
					var plazos=[]; 
					if (comprobables){
						for (var i = 0; i < plazosArray.length; i++){
							if (!plazosArray[i].cpComprobable){
								continue;
							}else{
								plazos.push(plazosArray[i]);							
							}
						}
					}else{
						for (var i = 0; i < plazosArray.length; i++){
							if (!plazosArray[i].cpNoComprobable){
								continue;
							}else{
								plazos.push(plazosArray[i]);							
							}
						}
					}
						
					
					var arrayMontos = plazos.map( function(d){
						return d['monto'];
					});
					
					arrayMontos = generalService.mergeSort(arrayMontos);
					
					var monto = parseInt( $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
					var index = arrayMontos.indexOf( monto );

					var _min = Math.min.apply( 0, arrayMontos );
					var _max = Math.max.apply( 0, arrayMontos );
									
					if( index == -1 ){
						var aprox = $scope.buscaMontoAproximado(monto, $scope.banderaComprobables, 100, false);
						monto = aprox.monto;
					}
					  
					$scope.minMonto = _min;
					$scope.maxMonto = _max;
					
					var step=500;
					var len = arrayMontos.length;
					
					if( arrayMontos[0] )
						if( arrayMontos[1] )
							step = arrayMontos[1]-arrayMontos[0];
					
					var fnCrearSliderCallBack = function(){
						slider( _min , _max, step, monto, '.amountVolCotizar div', arrayMontos, cambiaMontoCallback, "#sliderVolCotizar");
					};
					
					$scope.createSliderThread( 'sliderVolCotizar', fnCrearSliderCallBack, true );
					
				}
				
			};
			
			
			$scope.buscaMonto = function(){								
				$scope.plazosCotizador = $scope.calculaPlazosTermometroNuevo( valorSlider);				
				
				var plazo = 100;
				var index = $scope.plazosCotizador.indexOf( plazo );
				$scope.deshabilitarRecalcular = true;
				if(index != -1 ){
//					if(plazo = plazo)
					$scope.validaPlazoComprobableInmediato( plazo, valorSlider ); 
					$scope.calculaNuevosMontos();
					$timeout( function(){
						$('.requisitosCot ul li > a').each(function(){
							if( parseInt($(this).text()) == parseInt(plazo) ){
								if(!$(this).hasClass( "active" )){
									limpiarClasePlazos();
									$( this ).addClass('active'); 
								}
								return;
							};
						});
						$scope.actualizaPlazo();
					}, 10 );
				}else{
					$scope.mostrarDocumentos=false;
					limpiarClasePlazos();
					$scope.nuevoPlazo=0;
				}
								
			};
			
			$scope.calculaMaximos = function(){
				var arrayPlazos = generalService.getPlazos( $rootScope );
				arrayPlazos.sort(function (a, b) {
					  if (a.monto > b.monto) {
					    return 1;
					  }
					  if (a.monto < b.monto) {
					    return -1;
					  }
					  // a must be equal to b
					  return 0;
					});
				for(var i = 0; i < arrayPlazos.length; i++){
					if (!arrayPlazos[i].cpComprobable){
//						continue
					}else{
						$scope.maxComproblable = arrayPlazos[i];
					}
					if (!arrayPlazos[i].cpNoComprobable){
//						continue
					}else{
						$scope.maxNoComproblable = arrayPlazos[i];
					}
				}
				
				if (!$scope.maxComproblable){
					
				}else{
					$scope.montoProComprobable = ($scope.maxComproblable.monto + $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto)/2;
					$scope.montoProComprobable = redondearValor($scope.montoProComprobable, 100);
					$scope.plazoMaxComprobables = $scope.maxComproblable.cpComprobable[ $scope.maxComproblable.cpComprobable.length - 1]
					$scope.maxCom  = $scope.calculaNuevosMontosMax($scope.maxComproblable.monto, $scope.plazoMaxComprobables);
					if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxCom.monto && $scope.banderaComprobables){
						$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto =  $scope.maxCom.monto;
					}
					var detalleCom = $scope.buscaMontoAproximado($scope.montoProComprobable, true,100, true);
					$scope.detalleCom = $scope.calculaNuevosMontosMax(detalleCom.monto, detalleCom.plazo);					
				}
				
				if (!$scope.maxNoComproblable){
					
				}else{
					$scope.montoProNoComprobable = ($scope.maxNoComproblable.monto + $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto)/2;
					$scope.montoProNoComprobable = redondearValor($scope.montoProNoComprobable, 100);
					$scope.plazoMaxNoComprobables = $scope.maxNoComproblable.cpNoComprobable[ $scope.maxNoComproblable.cpNoComprobable.length - 1]
					$scope.maxNoCom = $scope.calculaNuevosMontosMax($scope.maxNoComproblable.monto, $scope.plazoMaxNoComprobables);
					if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxNoCom.monto && !$scope.banderaComprobables){
						$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = $scope.maxNoCom.monto;
					}
					var detalleNoCom = $scope.buscaMontoAproximado($scope.montoProNoComprobable, false,100, true);
					$scope.detalleNoCom = $scope.calculaNuevosMontosMax(detalleNoCom.monto, detalleNoCom.plazo);
				}
				if ($scope.banderaSugerido && $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto != $scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto ){
					$scope.mostrarSugerido = false;
				}
			}
			$scope.buscaMontoAproximado = function(monto, comprobable, unidad, menor){
				var arrayPlazos = generalService.getPlazos( $rootScope );
				arrayPlazos.sort(function (a, b) {
					  if (a.monto > b.monto) {
					    return 1;
					  }
					  if (a.monto < b.monto) {
					    return -1;
					  }
					  // a must be equal to b
					  return 0;
					});
				var encontro = false;
				var detalle = {};
				if (comprobable){
					
					while (!encontro) {
						var index = arrayPlazos.map(function(d){
							return d["monto"];
							
						}).indexOf (monto);
						if (index != -1){
							if(!arrayPlazos[index].cpComprobable){
								if (menor){									
									monto = monto - unidad;
								}else{
									monto = monto + unidad;
								}
							}else{
								detalle.plazo = arrayPlazos[index].cpComprobable[ arrayPlazos[index].cpComprobable.length - 1];
								detalle.monto = monto;
								encontro = true;
								$scope.hayPromedio= true;
								break;
							}
						}else{
							if (menor){									
								monto = monto - unidad;
							}else{
								monto = monto + unidad;
							}
						}
						if (monto < 2000 || monto > arrayPlazos[arrayPlazos.length - 1].monto){
							encontro = true;
							$scope.hayPromedio= false;
						}
					}
				}else{
					while (!encontro) {
						var index = arrayPlazos.map(function(d){
							return d["monto"];
							
						}).indexOf (monto);
						if (index != -1){
							if(!arrayPlazos[index].cpNoComprobable){
								if (menor){									
									monto = monto - unidad;
								}else{
									monto = monto + unidad;
								}
							}else{
								detalle.plazo = arrayPlazos[index].cpNoComprobable[arrayPlazos[index].cpNoComprobable.length - 1]
								detalle.monto = monto; 
								encontro = true;
								$scope.hayPromedio= true;
								break;
							}
						}else{
							if (menor){									
								monto = monto - unidad;
							}else{
								monto = monto + unidad;
							}
						}
						if (monto < 2000 || monto > arrayPlazos[arrayPlazos.length - 1].monto){
							encontro = true;
							$scope.hayPromedio= false;
						}
					}
				}
				return detalle;
			}
			$scope.calculaNuevosMontosMax = function(nuevoMonto, nuevoPLazo){	 
				
	 			var monto =  nuevoMonto;
		 		var periodicidad = $rootScope.solicitudJson.cotizacion.idPeriodicidad;
		 		var plazo = nuevoPLazo;
		 		
		 		var arrayTempAbonos = $rootScope.consultaAbonos.prestamosPersonales;
		 		for ( var i = 0; i < arrayTempAbonos.length; i++ ){
		 			if(monto == arrayTempAbonos[i].precio && periodicidad == arrayTempAbonos[i].periodo && plazo == arrayTempAbonos[i].plazo  ){
		 				var calculo = {};
	 					   calculo.monto = monto;
	 					   calculo.montoTotal = parseInt(arrayTempAbonos[i].precio) + parseInt(arrayTempAbonos[i].sobre);
						   calculo.intereses = parseInt(arrayTempAbonos[i].sobre);
	 					   calculo.pagoNormal =parseFloat( arrayTempAbonos[i].normal );
//	 					   var montoPuntual = monto * tasaPuntual;
//	 					   var montoTotalPuntual = monto + montoPuntual;
	 					   calculo.pagoPuntual = parseFloat(arrayTempAbonos[i].puntual);
	 					   calculo.ultimoAbono = parseInt(arrayTempAbonos[i].ultimo);
	 					   calculo.idProducto = arrayTempAbonos[i].sku;
	 					   calculo.cantidad = 1;
	 					   calculo.plazo = plazo;
	 					   calculo.idPlazo = plazo; 
	 					   break;
	 					}
		 			}
//		 		var arrayPlazoMonto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA",tipoTasa);
//			 		for ( var i = 1; i <= arrayPlazoMonto.length; i++ ){
//	 					
//			 			if (monto        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.MONTO["+i+"].valor",tipoTasa) &&
//	 						periodicidad == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PERIODICIDADID["+i+"].valor",tipoTasa) &&
//	 						plazo        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PLAZO["+i+"].valor",tipoTasa) ){ 						
//	 					   var tasaNormal = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA NORMAL["+i+"].valor",tipoTasa));
//	 					   var tasaPuntual = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA PUNTUAL["+i+"].valor",tipoTasa));
//	 					   var idProducto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PRODUCTOID["+i+"].valor",tipoTasa);
//	 					   var montoNormal = monto * tasaNormal;
//	 					   var calculo = {};
//	 					   calculo.monto = monto;
//	 					   calculo.montoTotal = monto + montoNormal;
//	 					   calculo.intereses = parseInt(calculo.montoTotal - monto);
//	 					   calculo.pagoNormal = Math.round(parseFloat(calculo.montoTotal / plazo));
//	 					   var montoPuntual = monto * tasaPuntual;
//	 					   var montoTotalPuntual = monto + montoPuntual;
//	 					   calculo.pagoPuntual = Math.round(parseFloat(montoTotalPuntual / plazo));
//	 					   calculo.ultimoAbono = parseInt(calculo.montoTotal -calculo.pagoNormal * (plazo - 1));
//	 					   calculo.idProducto = idProducto;
//	 					   calculo.cantidad = 1;
//	 					   calculo.plazo = plazo;
//	 					   calculo.idPlazo = plazo; 
//	 					   break;
//	 					}
//	 					
//			 		}
			 		
			 		
		 		return calculo;
		 		
	 	};
	 	function redondearValor(valor, unidad){
			var valorDes = Math.ceil(valor / unidad) * unidad
			var valorAnt = valorDes - unidad;
			
			var valorR1 = valorDes - valor;
			var valorR2 = valor - valorAnt;
			
			if(valorR1 <= valorR2){
				return valorDes; 
			}else{
				return valorAnt; 
			}
			
		}
			
	 	
	 	$scope.promediaMonto=function(){
	 		if ($scope.montoCampo.length > 5){
		 		var valor = generalService.limpiaFormato( $scope.montoCampo, "NIP-$" );
		 		
		 		if (valor < MONTO_MAX_SALTOS){
		 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = redondearValor(valor, 100);
		 		}else{		 			
		 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = redondearValor(valor, 500);
		 		}
		 		if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto < 2000)
		 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = 2000;
		 		if ($scope.banderaComprobables){
		 			if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxCom.monto){
		 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = $scope.maxCom.monto;
		 			}
		 		}else{
		 			if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxNoCom.monto){
		 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto =$scope.maxNoCom.monto;
		 			}
		 		}
		 		$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto, 0);
		 		console.log($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
		 		if($scope.banderaComprobables){
					$scope.buildSliderNoCom(true);
					$timeout(function(){$scope.buildSliderNoCom(true);}, 1)
				}else{
					$scope.buildSliderNoCom(false);
					$timeout(function(){$scope.buildSliderNoCom(false);}, 1)
				}
	 		}else{
	 			if ($scope.montoCampo.length > 4 && $scope.montoCampo.length < 6){
	 				$timeout(function(){
	 					if ($scope.montoCampo.length > 4){
			 				var valor = generalService.limpiaFormato( $scope.montoCampo, "NIP-$" );
			 				
			 				if (valor < MONTO_MAX_SALTOS){
					 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = redondearValor(valor, 100);
					 		}else{		 			
					 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = redondearValor(valor, 500);
					 		}
			 				
					 		if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto < 2000)
					 			$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = 2000;
					 		if($scope.banderaComprobables){
					 			if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxCom.monto){
					 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto = $scope.maxCom.monto;
					 			}
					 		}else{
					 			if ($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto > $scope.maxNoCom.monto){
					 				$scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto =$scope.maxNoCom.monto;
					 			}
					 		}
					 		$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto, 0);
					 		console.log($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto);
					 		if($scope.banderaComprobables){
								$scope.buildSliderNoCom(true);
								$timeout(function(){$scope.buildSliderNoCom(true);}, 1)
							}else{
								$scope.buildSliderNoCom(false);
								$timeout(function(){$scope.buildSliderNoCom(false);}, 1)
							}
	 					}
	 				}, 500);
	 			}
	 		}
	 	}
		   
	 	function number_format(amount, decimals) {

	 	    amount += ''; // por si pasan un numero en vez de un string
	 	    amount = parseFloat(amount.replace(/[^0-9\.]/g, '')); // elimino cualquier cosa que no sea numero o punto

	 	    decimals = decimals || 0; // por si la variable no fue fue pasada

	 	    // si no es un numero o es igual a cero retorno el mismo cero
	 	    if (isNaN(amount) || amount === 0) 
	 	        return parseFloat(0).toFixed(decimals);

	 	    // si es mayor o menor que cero retorno el valor formateado como numero
	 	    amount = '' + amount.toFixed(decimals);

	 	    var amount_parts = amount.split('.'),
	 	        regexp = /(\d+)(\d{3})/;

	 	    while (regexp.test(amount_parts[0]))
	 	        amount_parts[0] = amount_parts[0].replace(regexp, '$1' + ',' + '$2');

	 	    return amount_parts.join('.');
	 	}
	 	$scope.cambio=function(){
	 		$scope.montoCampo = number_format($scope.respaldoJsonSolicitud.cotizacion.detallesCotizacion[0].monto, 0);
	 	}
		});
	
});