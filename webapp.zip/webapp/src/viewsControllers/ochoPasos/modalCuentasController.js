'use strict';

var imagenes = new Array();

define(["app"], function (app) {
	
		app.controller('modalCuentasController', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService) {
			
			
			
			$scope.selecciona = function (value, check){
				$scope.ngDialogData.cuentas[check].selec = false;
				for (var i =0; i < $scope.ngDialogData.cuentas.length; i++){
					if (check == i){
						$scope.ngDialogData.cuentas[i].selec = true;	
					}else{
						$scope.ngDialogData.cuentas[i].selec = false;						
					}
				}
			}
			
			$scope.init=function(){
				for (var i =0; i < $scope.ngDialogData.cuentas.length; i++){
					$scope.ngDialogData.cuentas[i].selec = false;
				}
				$scope.objMonto=null;
				$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
				$scope.tituloHeader="Cuentas del cliente";
			};
			
			$scope.seleccionaMinimo = function(valor, check){
				if(check == 0){
					$scope.minimo = true;
					$scope.maximo = false;
				}else{
					$scope.minimo = false;
					$scope.maximo = true;
				}
			}
			$scope.continuar = function(){
				var encontro = false;
				for (var i = 0; i < $scope.ngDialogData.cuentas.length; i++){
					if ($scope.ngDialogData.cuentas[i].selec){
						encontro = true;
						$scope.cuentaSel = $scope.ngDialogData.cuentas[i];
						$scope.cuentaSel.minimo = $scope.minimo;
						$scope.cuentaSel.maximo = $scope.maximo;
					}
				}
				if (($scope.maximo || $scope.minimo) && encontro){
					$scope.confirm($scope.cuentaSel);	
				}
			}
		});
	
});