'use strict';

var imagenes = new Array();

define(["app"], function (app) {
	
	app.controller('modalVisorContratosController', function($rootScope, $scope, $location, $interval, generalService,$timeout,solicitudService, modalService, clienteUnicoService) {
		$scope.firmaAutografa;
		$scope.tituloHeader = "Contratos";
		$scope.textCheckCaratulaContrato = "Carátula y Contrato de Crédito";
		$scope.textSolicitudCredito = "Solicitud de Crédito";
		$scope.textPagare = "Pagaré";
		$scope.textEnviarPorEmail = "Enviar documentos vía email";
		$scope.textEnviarPorSms = "Enviar liga de descarga por SMS";
		$scope.placeHolder = "";
		var flujoFirmaUnica = (generalService.consultaHistoricoMarcas([STATUS_SOLICITUD.generada.marca.firmaUnica]) || $rootScope.isFirmaUnica)?true:false;
		var hayFirmaPendienteAviso = ($rootScope.solicitudJson.contratos.contrato[0].statusFirma == 0)?true:false;
		var hayFirmaPendienteBuro = ($rootScope.solicitudJson.contratos.contrato[1].statusFirma == 0)?true:false;
		$scope.mostrarContratos = false;
		$scope.muestraTipoModalUnicaAutografa = flujoFirmaUnica;
		var contadorVeces = 0;
		
		$scope.init = function(){
			
			$scope.checks={
					caratulaContrato: false,
					solicitud: false,
					pagare: false,
					enviarPorCorreo: false,
					enviarPorSms: false
			}
			$scope.editaCorreo = ($rootScope.solicitudJson.cotizacion.clientes[0].email != '') ? true : false;
			
			if(flujoFirmaUnica){
				$scope.bloquearBtnAceptar = true;
				$scope.bloquearCheck1 = false;
				$scope.bloquearCheck2 = false;
				$scope.bloquearCheck3 = false;
				$scope.esfirmaUnica = true;
			}else{
				$scope.bloquearBtnAceptar = false;
				$scope.esfirmaUnica = false;
				$scope.bloquearCheck1 = true;
				$scope.bloquearCheck2 = true;
				$scope.bloquearCheck3 = true;
			}
			
			if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.prodResPrestamoConGarantias){
				var addBienes =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
								return d["idContrato"];
							}).indexOf (FIRMA_BIENES.id);
							if (addBienes == -1){
								var jsonBienes = {
										idContrato: FIRMA_BIENES.id,
										idPersona: $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
										statusFirma: STATUS_CONTRATO.ENVIAD0,
										descripcion: FIRMA_BIENES.etiqueta,
										idTipoPersona: 1
									};
								$rootScope.solicitudJson.contratos.contrato.push(jsonBienes);
							}
			}
		}
		
		$scope.enviar = function(){
			if($scope.checks.enviarPorCorreo){
				if($rootScope.solicitudJson.cotizacion.clientes[0].email == ""){
					
				}else{
					$scope.validaCorreo($rootScope.solicitudJson.cotizacion.clientes[0].email);
				}
			}
			if($scope.checks.enviarPorSms){
				
			}
		};
		
		$scope.validaCheck = function(correo, sms){
			
			$scope.enviarCorreo = false;
			$scope.enviaSmS = false;
			if(correo == true){
				$scope.enviarCorreo = true;
				$scope.checks.enviarPorCorreo = true;
				$scope.checks.enviarPorSms = false;
			}
			if(sms == true){
				$scope.enviaSmS = true;
				$scope.checks.enviarPorSms = true;
				$scope.checks.enviarPorCorreo = false;
			}
		}
		
		$scope.validaCorreo= function(email){
			if(email){
				var re = /(^[-\w.]+@{1}[-a-z0-9]+[.]{1}[a-z-z0-9-]{2,5})+(?:\.[a-zA-Z0-9-]+)*$/;
				if(re.test(email))
					$scope.correoInvalido=false;
				else
					$scope.correoInvalido=true;
			}
		}
		
		$scope.visualizaDoc =  function (value){
			$rootScope.esVisorContratos = true;
			$rootScope.isAviso = undefined;
			$rootScope.isBuro = undefined;
			$rootScope.isContratoCaratula = undefined;
			$rootScope.isSolicitud = undefined;
			$rootScope.isSeguroCliente = undefined;
			$rootScope.isSeguroCarta = undefined;
			$rootScope.isAcuseTaz = undefined;
			$rootScope.isBienes = undefined;
			var tmp = Date.now();
			$scope.visualizaContrato = true;	
			$scope.muestraAvisos = false;
			switch (value){
			case "1": 
            	$scope.tituloAviso = {texto: "Aviso de Privacidad"};
				$scope.urlDoc = "AvisoPrivacidad.html";
				$rootScope.isAviso = true;
				$rootScope.title = "Firma Aviso de Privacidad";
				$scope.negacionCheck = {texto:"", visible: false, textoMensaje:"", botonAceptar: "Aceptar"};
                 break;
            case "2":  
            	$scope.tituloAviso = {texto: "Buró de crédito"};
				$scope.urlDoc = "BuroCredito.html";
				$rootScope.isBuro = true;
				$rootScope.title = "Firma Buro de Crédito";
				$scope.negacionCheck = {texto:"", visible: false, textoMensaje:"", botonAceptar: "Aceptar"};
                 break;
            case FIRMA_CARATULA_CLIENTE.id:            	
            	$scope.tituloAviso = {texto: "Carátula de crédito"};
            	$scope.tituloFirma = "Contrato, Carátula y Anexo de Comisiones";
            	$scope.urlDoc = "ContratoCaratulaCredito.html";
				$scope.muestraAvisos = true;
				$rootScope.isContratoCaratula = true;
				$rootScope.title = "Firma Contrato, Carátula y Anexo de Comisiones";
				$scope.negacionCheck ={texto:"No acepto Contrato, Carátula y Anexo de Comisiones", visible: true, textoMensaje: "l Contrato de Crédito.", botonAceptar: "Aceptar" };
				break;
            case FIRMA_SOLICITUD_CREDITO.id:  
             	$scope.tituloAviso = {texto: "Aviso de Privacidad"};
            	$scope.tituloFirma = "Solicitud de Crédito";
            	$scope.urlDoc = "SolicitudCredito.html";
				$rootScope.isSolicitud = true;
				$rootScope.title = "Firma Mercadotecnia y Solicitud de Crédito";
				$scope.negacionCheck = {texto:"No acepto Solicitud de Crédito", visible: true, textoMensaje: " la Solicitud de crédito.", botonAceptar: "Aceptar"};
                 break;
            case "5":  
            	$scope.tituloAviso = {texto: "Anexo de Bienes"};
            	$scope.tituloFirma= "Acepto Anexo de Bienes";
				$scope.urlDoc = "AnexoBienes.html";
				$rootScope.isBienes = true;
				$rootScope.title = "Firma Anexo de Bienes";
				$scope.negacionCheck ={texto:"No acepto el contrato de Anexo de Bienes", visible: true, textoMensaje:"l Anexo de Bienes.", botonAceptar: "Aceptar" }; 
				break;    
            case FIRMA_CONTRATO_CREDITO.id:				
             	$scope.tituloAviso = {texto: "Contrato de Crédito"};
            	$scope.tituloFirma = "Contrato de Crédito";
            	$scope.urlDoc = "CaratulaCredito.html";
            	$rootScope.isContratoCaratula = true;
            	$rootScope.title = "Firma Mercadotecnia y Solicitud de Crédito";
				$scope.negacionCheck = {texto:"No acepto Solicitud de Crédito", visible: true, textoMensaje: " la Solicitud de crédito.", botonAceptar: "Aceptar"};
                 break;
            default:
            	$scope.tituloAviso = {texto: "Aviso de Privacidad"};
              	$scope.tituloFirma = "Contrato, Carátula y Solicitud de Crédito";              	              	
              	$scope.urlDoc = "SolicitudCredito.html";              	              	
              	$rootScope.title = "Firma Seguro Vidamax";
              	$scope.negacionCheck = {texto:"", visible: false, textoMensaje:"", botonAceptar: "Aceptar"} 
            	break;
       }/* END SWITCH */
			
			
			$timeout( function(){
				construirIframe();
			}, 100 );
			
			$scope.contratoView = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
			
			if(!$scope.muestraTipoModalUnicaAutografa && contadorVeces > 0){
				$scope.visualizaContrato = true;
			}else{
				contadorVeces++;
			}
			
			$scope.mostrarContratos = true;
		};
		
		var construirIframe = function()
		{
			
			var divIframe = $( '#contenedor' );
			var iframe = document.createElement('iframe');

			iframe.height= "100%";
			iframe.width = "100%";
			iframe.id = "iframe";
			iframe.src = "pdf/web/viewer.jsp?urlDoc='" + $scope.urlDoc + "'";//"pdf/webvi?" + ngDialogData.estiloTitulo;
			iframe.scrolling = "no";
			iframe.style.marginBottom = "15px";

			divIframe.append( iframe );
			
		};
		
		$scope.cancelar = function(){
			
			/*\Se agrega un evento para la bitacora\*/
//			(Contratos)
			$rootScope.addEvent( BITACORA.SECCION.contratos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.cancelar.id, $rootScope.solicitudJson.contratos.porcentaje, BITACORA.SECCION.contratos.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
			
			$rootScope.firmaCaratula = undefined;
			$rootScope.firmaSolicitud = undefined;
			$rootScope.firmaSolicitudDos = undefined;
			$scope.closeThisDialog();
			$rootScope.message( "Nueva Originación Centralizada", ["Es necesario autorizar los términos y condiciones para continuar con la solicitud."], "Aceptar","/ochoPasos");
		};
		
		$scope.continuarFirma = function(){
			if($scope.enviarCorreo && $rootScope.solicitudJson.cotizacion.clientes[0].email == ""){
				$rootScope.message("Aviso ", ["Favor de ingresar un email"],"Aceptar",null,null,null,null);
				return;
			}else if($scope.enviarCorreo && $rootScope.solicitudJson.cotizacion.clientes[0].email != "" && $scope.correoInvalido){
				$rootScope.message("Aviso ", ["Favor de ingresar un email correcto"],"Aceptar",null,null,null,null);
				return;
			}else{

				if(flujoFirmaUnica){
					/*\Se agrega un evento para la bitacora\*/
//					(Contratos)
					$rootScope.addEvent( BITACORA.SECCION.contratos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.continuar.id, $rootScope.solicitudJson.contratos.porcentaje, BITACORA.SECCION.contratos.guardarEnBD );
					/*\Se agrega un evento para la bitacora\*/
					enviarContratosChecks();
				}else{
					/*\Se agrega un evento para la bitacora\*/
//					(Contratos)
					$rootScope.addEvent( BITACORA.SECCION.contratos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.continuar.id, $rootScope.solicitudJson.contratos.porcentaje, BITACORA.SECCION.contratos.guardarEnBD );
					/*\Se agrega un evento para la bitacora\*/						
					marcarSolEnvio();
				}
			
			}
			
		};
		
		$scope.tipoEnvio = function(tipoEnvio){
			$scope.mtdEnvio = tipoEnvio;
			if($scope.mtdEnvio == 1){
				$rootScope.message("Aviso", ["Una vez que se autorice el crédito los documentos serán enviados" +
						" al número " + $rootScope.solicitudJson.cotizacion.clientes[0].celular],"Aceptar",null,null,null,null);
			}else{
				$rootScope.message("Aviso", ["Una vez que se autorice el crédito los documentos serán enviados" +
				     						" al correo " + $rootScope.solicitudJson.cotizacion.clientes[0].email],"Aceptar",null,null,null,null);
			}
		};
		
		function marcarSolEnvio(){
			 var x = {
					  idSolicitud : $rootScope.solicitudJson.idSolicitud,
					  idSeguimiento: $rootScope.solicitudJson.idSeguimiento,
					  marca: ""
			  }
			 
			if($scope.mtdEnvio == 1){
				x.marca = MARCAS_SOLICITUD.envioContratosSmS;
			}else{
				x.marca = MARCAS_SOLICITUD.envioContratosEmail;
			}
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.actualizarSolicitud(x).then(
				function(data){
					 $rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var responseJson = JSON.parse(data.data.respuesta);	
						if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							if(flujoFirmaUnica){
								$scope.closeThisDialog();
								$rootScope.tipoEnvioSeleccionado = true;
								generalService.locationPath("/ochoPasos");
							}else{
								prepararFirmasAutografas();
							}
						}else{
							$rootScope.message("Aviso ", ["Error al actualizar el tipo de envío de contratos" +
									", Favor de intentar nuevamente"],"Aceptar","/ochoPasos",null,null,null);
						}
						
					}else{
						$rootScope.message("Aviso ", ["Error en el servicio para actualizar el tipo de envío de contratos " +
								"flujo de firma única."],"Aceptar","/ochoPasos",null,null,null);
					}
				}, function(error){
					 $rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Aviso ", ["Error del servidor para actualizar la solicitud"],"Aceptar","/ochoPasos",null,null,null);				
				}
			);
		
			
		};
		
		$scope.obtenerTimeStampFirma = function(contrato){
			
			var timeStamp = Date.now();
			var hayCheckPendiente = false;
			if(contrato == "aviso"){
				$scope.timeStampAviso = timeStamp;
				$scope.bloquearAviso = true;
				$scope.enviarAviso = true;
				$rootScope.avisoActivo = false;
			}else if(contrato == "buro"){
				$scope.timeStampBuro = timeStamp;
				$scope.bloquearBuro = true;
				$scope.enviarBuro = true;
				$rootScope.buroActivo = false;
			}else if(contrato == "contratoCaratula"){
				$scope.timeStampcontratoCaratula = timeStamp;
				$scope.bloquearContratoCaratula = true;
				$scope.enviarContratoCaratula = true;
				$rootScope.contratoCaratulaActivo = false;
			}else if(contrato == "solicitud"){
				$scope.timeStampSolicitud = timeStamp;
				$scope.bloquearSolicitud = true;
				$scope.enviarSolicitud = true;
				$rootScope.solicitudActivo = false;
			}else if(contrato == "bienes"){
				$scope.timeStampBienes = timeStamp;
				$scope.bloquearBienes = true;
				$scope.enviarBienes = true;
				$rootScope.bienesActivo = false;
			}
			
			if(!$rootScope.avisoActivo && !$rootScope.buroActivo &&
				!$rootScope.contratoCaratulaActivo && !$rootScope.solicitudActivo &&
				!$rootScope.bienesActivo){
				$scope.bloquearBtnAceptar = false;
			}
			
		};
		
		function enviarContratosChecks(){
			var x = [];
			var hayAlgoPendiente = false;
			if($scope.enviarAviso){
				x = [
	                   {
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							numFirmas: 1,
							timeStampFirma: $scope.timeStampAviso,
							tipoCadena: "firmaAviso"
							
						},
						{
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							numFirmas: 2,
							timeStampFirma: $scope.timeStampAviso,
							tipoCadena: "firmaAviso"
							
						},
						{
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							numFirmas: 3,
							timeStampFirma: $scope.timeStampAviso,
							tipoCadena: "firmaAviso"
							
						}
					];
				hayAlgoPendiente = true;
				
			}else if($scope.enviarBuro){
				x = [
			            {
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							numFirmas: 1,
							timeStampFirma: $scope.timeStampBuro,
							tipoCadena: "firmaBuro"
			            }
		              ];
				hayAlgoPendiente = true;
				
			}else if($scope.enviarContratoCaratula){
				x = [
					 {
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						numFirmas: 1,
						timeStampFirma: $scope.timeStampcontratoCaratula,
						tipoCadena: "firmaContratoCredito"
					 },
					 {
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						numFirmas: 0,
						timeStampFirma: $scope.timeStampcontratoCaratula,
						tipoCadena: "firmaCaratulaCliente"
					 }
				];
				hayAlgoPendiente = true;
				
			}else if($scope.enviarSolicitud){
				x = [
				      {
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						numFirmas: 1,
						timeStampFirma: $scope.timeStampSolicitud,
						tipoCadena: "firmaSolicitudCreditoDos"
		               },
		               {
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						numFirmas: 2,
						timeStampFirma: $scope.timeStampSolicitud,
						tipoCadena: "firmaSolicitudCreditoDos"
		               }
	               ];
				hayAlgoPendiente = true;
				
			}else if($scope.enviarBienes){
				x = [
				      {
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						numFirmas: 1,
						timeStampFirma: $scope.timeStampBienes,
						tipoCadena: "firmaBienes"
		               }
	               ];
				hayAlgoPendiente = true;
			}
			
			(hayAlgoPendiente)?guardarFirmaUnicaB(x):validarBienes();
			
		};
		
		function validarBienes (){
			($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.prodResPrestamoConGarantias)?addContratoBienes(16):guardarSeccionContratos();
		};
		
		function addContratoBienes(tipoContrato){
	    	if(tipoContrato == 16){
	    		var addBienes =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
					return d["idContrato"];
				}).indexOf (FIRMA_BIENES.id);
				if (addBienes == -1){
					var jsonBienes = {
							idContrato: FIRMA_BIENES.id,
							idPersona: $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
							statusFirma: STATUS_CONTRATO.ENVIAD0,
							descripcion: FIRMA_BIENES.etiqueta,
							idTipoPersona: 1
						};
					$rootScope.solicitudJson.contratos.contrato.push(jsonBienes);
				}
	    	}
	    	guardarSeccionContratos();
	    };
		
		function guardarFirmaUnicaB(x){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 						
			clienteUnicoService.guardarFirmaUnica( x ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							if($scope.enviarAviso){
								$rootScope.solicitudJson.contratos.contrato[0].statusFirma = STATUS_CONTRATO.ENVIAD0;
								$scope.enviarAviso = false;
							}else if($scope.enviarBuro){
								$rootScope.solicitudJson.contratos.contrato[1].statusFirma = STATUS_CONTRATO.ENVIAD0;
								$scope.enviarBuro = false;
							}else if($scope.enviarContratoCaratula){
								$rootScope.solicitudJson.contratos.contrato[2].statusFirma = STATUS_CONTRATO.ENVIAD0;
								$scope.enviarContratoCaratula = false;
							}else if($scope.enviarSolicitud){
								$rootScope.solicitudJson.contratos.contrato[3].statusFirma = STATUS_CONTRATO.ENVIAD0;
								$scope.enviarSolicitud = false;
							}else if($scope.enviarBienes){
								var contratos = $rootScope.solicitudJson.contratos.contrato;
								for(var i in contratos){
									if(contratos[i].idContrato == FIRMA_BIENES.id){
										$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.ENVIAD0;
										break;
									}
								}
								$scope.enviarBienes = false;
							}
							enviarContratosChecks();
						}else{
							$rootScope.message("Siete Pasos",[ "Error en el servicio para guardar la firma única" ], "Aceptar", null);
						}
					}else
						$rootScope.message("Siete Pasos",["Error en el servidor para guardar la firma única"], "Aceptar");
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 	                					
				}
			);
		};
		

		function prepararFirmasAutografas(){
			var esEncolarFirmas = false;
			var tipoCadena="", cadena="", hayFirmaPendiente=false;
			
			if($rootScope.isAvisoWSD){
				tipoCadena="firmaAviso";
				cadena=$rootScope.imgPrivacidad;
				hayFirmaPendiente = true;
			}else if($rootScope.isBuroWSD){
				tipoCadena="firmaBuro";
				cadena=$rootScope.imgBuro;
				hayFirmaPendiente = true;
			}else if($rootScope.isContratoCaratulaWSD){
				tipoCadena="firmaCaratulaCliente"; 
				cadena=$rootScope.imgCaratula;
				hayFirmaPendiente = true;
			}else if($rootScope.firmaSolUnoWSD){
				tipoCadena="firmaSolicitudCreditoUno"; 
				cadena=$rootScope.imgSolicitud;
				hayFirmaPendiente = true;
			}else if($rootScope.firmaSolDosWSD){
				tipoCadena="firmaSolicitudCreditoDos"; 
				cadena=$rootScope.imgSolicitudDos;
				hayFirmaPendiente = true;
			}else if($rootScope.isBienesWSD){
				tipoCadena="firmaBienes";
				cadena=$rootScope.imgFirmaBienes;
				hayFirmaPendiente = true;
				$scope.firmaBieneEnviada = true;
			}

			(hayFirmaPendiente)?enviarFirmasAutografas(tipoCadena, cadena.replace("data:image/png;base64,","").trim()):validarBienes();

		};
		
		
		function enviarFirmasAutografas(tipoCadena, cadena) {
			var request = {
				idSolicitud: $rootScope.solicitudJson.idSolicitud,
				cadena: cadena,
				tipoCadena: tipoCadena,
				porcentaje: "100"
			}
			
			if(request.tipoCadena == "firmaAviso"){
				request.tratamiento = $rootScope.solicitudJson.tratamientoDatos;
				request.transferencia = $rootScope.solicitudJson.transferenciaDatos;
			}
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			clienteUnicoService.setBiometrico(request).then(
				function(data) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if(jsonResponse.codigo == 2){
							if($rootScope.isAvisoWSD || hayFirmaPendienteAviso){
								hayFirmaPendienteAviso = false;
								$rootScope.isAvisoWSD = false;
								$scope.aviso = true;
								$rootScope.solicitudJson.contratos.contrato[0].statusFirma = 1;
							}else if($rootScope.isBuroWSD || hayFirmaPendienteBuro){
								hayFirmaPendienteBuro = false;
								$rootScope.isBuroWSD = false;
								$scope.buro = true; 
								$rootScope.solicitudJson.contratos.contrato[1].statusFirma = 1;
							}else if($rootScope.isContratoCaratulaWSD){
								$rootScope.isContratoCaratulaWSD = false;
								$rootScope.solicitudJson.contratos.contrato[2].statusFirma = 1;
								$scope.caratula = true;
							}else if($scope.firmaSolUnoWSD){
								$rootScope.solicitudJson.contratos.contrato[3].statusFirma = 1;
								$rootScope.firmaSolUnoWSD = false;
								$scope.solicitudUno = true;
							}else if($scope.firmaSolDosWSD){
								$rootScope.solicitudJson.contratos.contrato[3].statusFirma = 1;
								$rootScope.firmaSolDosWSD = false;
								$scope.solicitudDos = true;
							}else if($rootScope.isBienesWSD){
								$rootScope.solicitudJson.contratos.contrato[4].statusFirma = 1;
								$rootScope.isBienesWSD = false;
							}
							prepararFirmasAutografas();
						}else{
							$rootScope.message("Error: "+jsonResponse.codigo, [jsonResponse.descripcion], "Aceptar");
						}
					} else {
						$rootScope.message("Error", ["Ocurrio un error al consultar el servicio 'guardar firmas autografas'.","Por favor, contacte al administrador del sistema."], "Aceptar");
					}
			}, function(error) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
			});
		};
		
		
		function guardarSeccionContratos(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			var celCliente = $rootScope.solicitudJson.cotizacion.clientes[0].celular;
			celCliente = celCliente.split("(").join("").split(")").join("").split(" ").join("");
			$rootScope.solicitudJson.cotizacion.clientes[0].celular = celCliente;
			
			var firmadosDocs = 0;
			for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
				if($rootScope.solicitudJson.contratos.contrato[i].statusFirma == 1 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 2){
					firmadosDocs++;
				}
			}
			$rootScope.solicitudJson.contratos.porcentaje = parseInt(((firmadosDocs * 100) / $rootScope.solicitudJson.contratos.contrato.length).toFixed(0));
			
			solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($rootScope.solicitudJson), seccion: 8 } ).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
							var responseJson = JSON.parse(data.data.respuesta);
							if(responseJson.codigo == 2){
								$rootScope.hayContratoBienes = false;
								$rootScope.solicitudJson.contratos = responseJson.data.contratos;
								if(flujoFirmaUnica){
									/*\Se agrega un evento para la bitacora\*/
//									(Contratos)
									$rootScope.addEvent( BITACORA.SECCION.contratos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.guardar.id, $rootScope.solicitudJson.contratos.porcentaje, BITACORA.SECCION.contratos.guardarEnBD );
									/*\Se agrega un evento para la bitacora\*/
									
									marcarSolEnvio();
								}else{
									
									/*\Se agrega un evento para la bitacora\*/
//									(Contratos)
									$rootScope.addEvent( BITACORA.SECCION.contratos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.guardar.id, $rootScope.solicitudJson.contratos.porcentaje, BITACORA.SECCION.contratos.guardarEnBD );
									/*\Se agrega un evento para la bitacora\*/
									
									$scope.closeThisDialog();
									$rootScope.tipoEnvioSeleccionado = true;
									generalService.locationPath("/ochoPasos");
								}
							}
						}else{
							$scope.firmarAcuse = false;
							$rootScope.message("Error",["Ocurrio un error al guardar la sección de contratos. Favor de volver a intentar"], "Aceptar", "/ochoPasos", "bgRosa", "btnRosaD");
						}
						
					}, function(error){
						$scope.firmarAcuse = false;
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Error",["Ocurrio un error al guardar la sección de contratos. Favor de volver a intentar"], "Aceptar", null, "bgRosa", "btnRosaD");
					}
				);
		};
		
		/**
		 * Esta función solo la utiliza la firma única
		 **/
		$scope.regresaVistaPrincipalFirmaUnica = function(){
			
			$scope.visualizaContrato = false;
			$scope.mostrarContratos = false;
		}
		
		$scope.firmarContratos = function(numeroFirma){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			/**
			 * 'tipoFirma' contiene el número de firma, en caso de 
			 * 1 Firma normal
			 * 2 Segunda firma en el contrato de Solicitud de Crédito
			 * 3 Firma Única
			 **/
			tipoFirma = numeroFirma;
			
			/**
			 * Levanta el modal para firmar desde el iPad
			 **/
			modalService.firmas($scope.title).then(
				function(exito){
					$scope.responseFirmaWV({codigo: RESPONSE_CODIGO_EXITO_IPAD, img64:exito});
				},function(error){
					$scope.responseFirmaWV({codigo: 1, img64:null});
				}
			);
		}
		
	});
});