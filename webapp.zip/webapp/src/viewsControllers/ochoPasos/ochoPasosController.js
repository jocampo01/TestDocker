'use strict';

define(["app"], function (app) {

	app.controller("ochoPasosController", function ( $timeout, $scope, $rootScope, loginService, modalService, 
													 sessionService, ngDialog, generalService, authService, 
												     solicitudService, messageData, clienteUnicoService, TermometroController,
												     $interval, tarjetaService, buroService, documentosService, callCenterService, obligadoSolidarioService, generalServiceOS,constantesTDC) {		
		// Por defecto, es más sano mostrar que no hacerlo.
		var mostrarSeccionEmpleo = true;
		var mostrarSeccionGastos = true;
		$scope.mostrarGeneraCita = true;
		$scope.$parent.origenCallCenter = 1;
		$scope.esRescate=false;
		$scope.respuestaBuro = $rootScope.codigoBuro;
		$rootScope.codigoBuro = null;
		//BANDERA PARA MOSTRAR CABECERO DE TAZ 
		$scope.esTarjetaTAZProducto = false;
		if($rootScope.solicitudJson.idProducto == PRODUCTOS.tarjetaAzteca.ID.valor)
			$scope.esTarjetaTAZProducto = true;	
		// Bandera para volver a 8 pasos si se llega desde ocho pasos a entrega de TAZ
		$rootScope.flujoEsOchoPasos = false;
		var tipoTasa = tipoTasas.prestamoPersonal.id;
		try {
			// Se leen los valores de BD.
			mostrarSeccionEmpleo = $rootScope.consultaFuncionalidad.muestraSeccionDatosEmpleo;
			mostrarSeccionGastos = $rootScope.consultaFuncionalidad.muestraSeccionGastos;

			// Se ya bajó a tienda correctamente y fue rendida correctamente, se muestra sí o sí.
			if($rootScope.solicitudJson.existeCita == 1 && $rootScope.solicitudJson.flujoSolicitudADN == 99 
				&& ($rootScope.solicitudJson.idSeguimiento == 6 || $rootScope.solicitudJson.idSeguimiento == 185)) {
				mostrarSeccionEmpleo = $rootScope.solicitudJson.cotizacion.clientes[0].idTipoTrabajo == 1;
				mostrarSeccionGastos = true;
			}
		} catch (x) {}
		
		$rootScope.ofertaMCO = $rootScope.solicitudJson.tipoOferta;
		$scope.envioBack=true;
		$scope.SOLICITUD_REACTIVADO = SOLICITUD_REACTIVADO; 
		$rootScope.rechazoBuro = false;
		$rootScope.productosAutorizados=[];		
		$scope.mostrarMenu = true;
		$scope.ID_PRODUCTO = ID_PRODUCTO;
		if($rootScope.solicitudJson.cotizacion.clientes[0].porcentaje != 100)
			 $rootScope.solicitudJson.cotizacion.clientes[0].bloqueado=0;
		if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje != 100 || $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.malZonificada.id)
			$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado=0;
		if(isNaN(parseInt($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores)))
			$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores=null;
		else
			$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMenores);
		if(isNaN(parseInt($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores)))
			$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores=null;
		else
			$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores = parseInt($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.dependientesMayores);
		$scope.deshabilitarRecalcular = true;
		$scope.pageClass = generalService.calculaVistas($rootScope.paginaActual,$rootScope.paginaAnterior,$rootScope.recuperaSolicitud);
		var porcentajeQF =  (($rootScope.solicitudJson.cotizacion.clientes[0].porcentaje + $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje)/2).toFixed(0);
/** INICIA_OS-FLUJO COACREDITADO **/
		// Obliga a que se firmen los contratos antes de validar los documentos
		$scope.firmarContratosOS = false;
		var respuestaSeccionOS = {};
		
		/** Variable global para confirma que exista Coacreditado para el cliente **/
		$scope.existeObligadoSolidario = $rootScope.solicitudOSJson && $rootScope.solicitudOSJson.idSolicitud != "" && !generalService.solicitudOSRechazado();
		
		if( $scope.existeObligadoSolidario ){
			generalServiceOS.calcularPorcentajeDocumentosOS();
			respuestaSeccionOS = generalService.evaluaAgendaCita( $rootScope.solicitudOSJson, $scope.menuListOS );
		}
		
		if( $scope.existeObligadoSolidario && $rootScope.solicitudOSJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id)
			$rootScope.muestraOpcionOS = true;
		
		if( $scope.existeObligadoSolidario && ( $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico == "" || 
			$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico == null ))

			$rootScope.muestraOpcionOS = true;
		
		if( $rootScope.solicitudJson.obligadoSolidario &&  $rootScope.solicitudJson.obligadoSolidario.idSolicitudObligadoSolidario == ""  && 
		    $rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.clienteAceptoProductoCosumo )
					$rootScope.muestraOpcionOS = true;
		
		
		if( $rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescate  ||
			$rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescateFDos	|| 
			$rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescateFCuatro )
				$rootScope.muestraMiniConsumo = true;
		
/** TERMINA_OS-FLUJO COACREDITADO **/
		

		generalService.setArrayValue("seCotizoItalika", false);
		generalService.setArrayValue("montoPlazoPP", null);
		generalService.setArrayValue("presupuesto", null);
		$scope.errorCelular =  false;
		$scope.errorCorreo =  false;
		$scope.siempreMostrarAval = true;
		$scope.creditoInmediato = ($rootScope.solicitudJson.creditoInmediato == 0) ? true : false;
		var arrayPlazoMonto;
	    if (esIpad && configuracion.origen.tienda )
	    	$scope.validaContratos = true;
		else
			$scope.validaContratos = false;				
		$scope.vistaDatosUsuario=configuracion.datosUsuario.opcion=0;
		$scope.menuList = new Array();		
				
		if($rootScope.solicitudJson.seguroDeVida == null){
			$rootScope.solicitudJson.seguroDeVida = {
		          "nombreSeguro": "",
		          "opcionSeguro": 0,
		          "idSeguro": "",
		          "precioSeguro": 0,
		          "sobrePrecioSeguro": 0,
		          "abonoSeguro": 0,
		          "ultimoAbonoSeguro": 0,
		          "totalSeguro": 0,
		          "clavePromocion": "",
		          "comisionVenta": 0,
		          "montoFinal": 0,
		          "montoInicial": 0,
		          "esDefault": 0
		       };
		}
										
		$scope.getFotoIpad = function( response )
		{
			$rootScope.loggerIpad("getFotoIpad", null, response);			
			if(response.codigo==0){													
				angular.forEach(response.peticiones, function(envio){
					if(envio.parameters.tipoCadena == 'foto')
						$rootScope.obtenerRecursoPendiente('ochoPasosDivId', 'loadFotoIpad', envio.identifier.toString());
				});																												
			}					
			
		};
		
		
		$scope.loadFotoIpad = function( response )
		{		
			$rootScope.loggerIpad("loadFotoIpad", null, response);
			$rootScope.fotoCte = "data:image/png;base64,"+response.peticion.parameters.cadena;
			$rootScope.fotoCteOriginal=response.peticion.parameters.cadena;
		};
		
		$scope.getSucursalInfo=function(){
			console.log("ME EJECUTE SUCRSAL")
			$rootScope.sucursalInfo = {"idSucursal":null,"sucursal":null};
	 		solicitudService.getSucursal(PROCESOS.PIZ).then(
		 			function(data){
		 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){		 						 						 					
		 					var responseJson = JSON.parse(data.data.respuesta);
		 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
		 						if(responseJson.data){
		 							if(responseJson.data.xpUbicacion){
		 								$rootScope.sucursalInfo.sucursal=responseJson.data;
		 								$rootScope.sucursalInfo.idSucursal=$rootScope.sucursalSession.idSucursal;
		 							}
		 						}
							}
		 				}
		 			}, function(error){                     	 												
		 			}	
				);// END SOLICITUD SERVICE - SAVE SOLICITUD	
		};
		
		$scope.ejecutaSucursalInfo=function(){
			if(!$rootScope.sucursalInfo){
				if(!$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud)
					$scope.getSucursalInfo();
			}else if(!$rootScope.sucursalInfo.idSucursal && !$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud)
				$scope.getSucursalInfo();
			else if($rootScope.sucursalInfo.idSucursal!=$rootScope.sucursalSession.idSucursal && !$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud)
				$scope.getSucursalInfo();
		}
		
		$scope.ejecutaSucursalInfo();
		
		$scope.validaHuella = function()
		{
			if( esIpad && configuracion.origen.tienda ){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$rootScope.verificarHuella( 'ochoPasos', 'responseVerificarHuellaIpad', 
											$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico );
			}else
				$scope.abrirDialogo();
			
		};/* END VALIDA HUELLA FUNCTION */
		
		$scope.responseVerificarHuellaIpad = function( response )
		{
			$rootScope.loggerIpad("responseVerificarHuellaIpad", null, response);
			try{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(response.codigo == 0 && response.matches.length > 0)						
					$scope.calculaMonto();
				else
					$rootScope.message("Siete Pasos", [response.mensaje], "Aceptar", null, null, null);
		
			}catch(e){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message( "Error al verificar la huella", [e], "Aceptar", null, null, null);
			}									
			
		};/* END RESPONSE VERIFICAR HUELLA IPAD FUNCTION */
		
	 	$scope.abrirDialogo = function()
	 	{			  		
	 		modalService.huellaModal("bgazul");
	 	};/* END ABRIR DIALOGO FUNCTION */
		
		$scope.calculaMonto = function(credioInm,isOferta)
		{	 
			if( $rootScope.consultaAbonos.prestamosPersonales != undefined ){
	 			
	 			var monto = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;
		 		var periodicidad = $rootScope.solicitudJson.cotizacion.idPeriodicidad;
		 		var plazo = $rootScope.solicitudJson.cotizacion.plazo;		 				 				 	
		 		for (var i = 0; i < $rootScope.consultaAbonos.prestamosPersonales.length;i++){
		 			if(monto == $rootScope.consultaAbonos.prestamosPersonales[i].precio && periodicidad == $rootScope.consultaAbonos.prestamosPersonales[i].periodo && plazo == $rootScope.consultaAbonos.prestamosPersonales[i].plazo  ){
		 				
//		 				$rootScope.solicitudJson.cotizacion.montoTotal = parseFloat($rootScope.consultaAbonos.prestamosPersonales[i].sobre);
//						$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses = parseInt($rootScope.solicitudJson.cotizacion.montoTotal - monto);
		 				$rootScope.solicitudJson.cotizacion.montoTotal = parseInt(arrayTempAbonos[i].precio) + parseInt(arrayTempAbonos[i].sobre);
		 				$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses = parseInt(arrayTempAbonos[i].sobre);
						$rootScope.solicitudJson.cotizacion.pagoNormal =parseFloat( $rootScope.consultaAbonos.prestamosPersonales[i].normal );
						
						$rootScope.solicitudJson.cotizacion.pagoPuntual = parseFloat($rootScope.consultaAbonos.prestamosPersonales[i].puntual);
						$rootScope.solicitudJson.cotizacion.ultimoAbono = parseInt($rootScope.consultaAbonos.prestamosPersonales[i].ultimo);
						$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto = $rootScope.consultaAbonos.prestamosPersonales[i].sku;
						$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].cantidad = 1;
						$scope.existePlazo= true;	 					 
						break;	   
		 			}
		 		}
		 		
		 		if(credioInm)
		 			validaCreditoInmediato($( "#sliderVertical" ).slider( "value" ), true);
		 		$scope.nuevaCotizacion(isOferta);
		 		
	 		}// END IF ARRAY PLAZO MONTO
			
			
//	 		if( arrayPlazoMonto != undefined ){
//	 			
//	 			var monto = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;
//		 		var periodicidad = $rootScope.solicitudJson.cotizacion.idPeriodicidad;
//		 		var plazo = $rootScope.solicitudJson.cotizacion.plazo;		 				 				 	
//		 				 		
//		 		for ( var i = 1; i <= arrayPlazoMonto.length; i++ ){
// 					
//		 			if (monto        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.MONTO["+i+"].valor",tipoTasa) &&
// 						periodicidad == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PERIODICIDADID["+i+"].valor",tipoTasa) &&
// 						plazo        == generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PLAZO["+i+"].valor",tipoTasa) ){ 						
// 					   var tasaNormal = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA NORMAL["+i+"].valor",tipoTasa));
// 					   var tasaPuntual = parseFloat(generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.TASA PUNTUAL["+i+"].valor",tipoTasa));
// 					   var idProducto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA.PRODUCTOID["+i+"].valor",tipoTasa);
// 					   var montoNormal = monto * tasaNormal;
// 					   $rootScope.solicitudJson.cotizacion.montoTotal = monto + montoNormal;
// 					   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].intereses = parseInt($rootScope.solicitudJson.cotizacion.montoTotal - monto);
// 					   $rootScope.solicitudJson.cotizacion.pagoNormal = parseInt(parseFloat($rootScope.solicitudJson.cotizacion.montoTotal / plazo));
// 					   var montoPuntual = monto * tasaPuntual;
// 					   var montoTotalPuntual = monto + montoPuntual;
// 					   $rootScope.solicitudJson.cotizacion.pagoPuntual = Math.round(parseFloat(montoTotalPuntual / plazo));
// 					   $rootScope.solicitudJson.cotizacion.ultimoAbono = parseInt($rootScope.solicitudJson.cotizacion.montoTotal - $rootScope.solicitudJson.cotizacion.pagoNormal * (plazo - 1));
// 					   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].idProducto = idProducto;
// 					   $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].cantidad = 1;
// 					   i=9999;
// 					}// END IF MONTOS 
// 					
//		 		}// END FOR ARRAY PLAZO MONTO
//		 		
//		 		if(credioInm)
//		 			validaCreditoInmediato($( "#sliderVertical" ).slider( "value" ), true);
//		 		$scope.nuevaCotizacion(isOferta);
//		 		
//	 		}// END IF ARRAY PLAZO MONTO
	 	};/* END CALCULA MONTO FUNCTION */
	 	
	 	$scope.nuevaCotizacion = function(isOferta)
	 	{
	 		
	 		$rootScope.waitLoaderStatus = LOADER_SHOW;
	 		$scope.endCotizador = false;
	 		if(!isOferta)
	 			$rootScope.buroConditional = -1; //FIX COMMENT 01/04/2016
	 		$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = $("#sliderVertical").slider( "value");

	 		if( offLine ){				
				$rootScope.cargaDocumentos();
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.menuList= [];
				$scope.showPage= false;
				$scope.init();
			}else{
				
				var guardarSeccionNueve = true;
				
		 		solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($rootScope.solicitudJson), seccion: 9 } ).then(
		 			function(data){
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
		 					var responseJson = JSON.parse(data.data.respuesta);
		 					
		 					var fnStatusOK = function( esMalZonificada ){
								
		 						$rootScope.solicitudJson = responseJson.data;
		 						$scope.validaEdicionSecciones();
								if( esMalZonificada && typeof esMalZonificada !== 'undefined' ){
									var excepciones = [ SECCION_HOGAR.toString() ];
									generalService.bloqueoSecciones( $rootScope.solicitudJson, excepciones );
								}
								
								configuracion.datosUsuario.opcion = 1;
								$rootScope.calculaDocumentos();
								$scope.menuList= []; //FIXIN 03/02/2016
								$scope.showPage= false; //FIXIN 03/02/2016
								$scope.init( guardarSeccionNueve ); //FIXIN 03/02/2016								

		 					};
		 					
		 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
								fnStatusOK();							
							}else if( responseJson.codigo == STATUS_SOLICITUD.malZonificada.guardarSeccion ){
								generalService.setDataBridge( {esMalZonificada:true} );
								fnStatusOK( true );
							}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
								var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
								$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
							}else{
								if(responseJson.codigo == ERROR_SOL_RECHAZADA){
									var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
									var marca = $rootScope.solicitudJson.marca;
									var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],"Aceptar", "/simulador",null,null,buildJsonDefault);
								}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
									generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
									generalService.locationPath("/ficha");
								}else{
									$rootScope.message("Volver a cotizar",[ "Error al guardar la cotización (sección 9). Código " +
											"de error [" + responseJson.codigo + "] no identificado."],"Aceptar", null);
								}
		 					}
		 				}else{
		 					$rootScope.message("Volver a cotizar",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
		 				}
		 			}, function(error){                     
		 				$rootScope.waitLoaderStatus = LOADER_HIDE;
		 				$rootScope.message("Error al volver a cotizar",[ "Error en el servicio al guardar la sección 9."], "Aceptar", null);								
		 			}	
				);// END SOLICITUD SERVICE - SAVE SOLICITUD	
			
			}// END IF - ELSE OFFLINE
	   
	 	};/* END NUEVA COTIZACION FUNCTION */
	 	
	 	$scope.recordarRadio = function( currentPlazo, currentMonto )
	 	{
	 		
	 		var montoOriginal = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;
	 		var plazoOriginal = $rootScope.solicitudJson.cotizacion.plazo;
	 		
			if( $rootScope.solicitudJson.banderaIngresos == 1 
				&& $rootScope.solicitudJson.banderaSolidario == 0 )
				$scope.condiciones.tipoComprobante = "ingresos";
			if( $rootScope.solicitudJson.banderaIngresos == 0 
				&& $rootScope.solicitudJson.banderaSolidario == 1 )
				$scope.condiciones.tipoComprobante = "aval";
			
			if( currentPlazo != plazoOriginal || currentMonto != montoOriginal )
				$scope.condiciones.tipoComprobante = "";
	 		
	 		$scope.deshabilitarRecalcular = true;
	 		
	 	};/* END RECORDAR RADIO FUNCTION */
		
	 	$scope.obtieneFoto = function()
	 	{
	 		
			var x = {
				ruta: 0,
				idSolicitud: $rootScope.solicitudJson.idSolicitud
			};

			clienteUnicoService.getFoto(x).then(
				function(data){
					if ( data.data.codigo == RESPONSE_CODIGO_EXITO ) {
						$scope.resp = JSON.parse( data.data.respuesta );
						if( $scope.resp.codigo == 2 ){
							var cadenaFoto = $scope.resp.data;
							$rootScope.fotoCte = 'data:image/png;base64,' + cadenaFoto;
						} 
					}else{
						console.error("Error al obtener la foto");
					}
				},function(error) {
					console.error( error );
				});
			
		};/* END OBTIENE FOTO FUNCTION */
		
		$scope.validacionBoton = function()
		{
			
			if( generalService.validaCita( $rootScope.solicitudJson ) ){
				
				var estadoZonificacion = generalService.getDataBridge();
				
				if( !generalService.isEmpty( JSON.stringify(estadoZonificacion) ) ){
					if( estadoZonificacion.esMalZonificada )
						$scope.terminoSolicitud = true;
					else if(estadoZonificacion.origen){
						$scope.terminoSolicitud = true;
						generalService.setDataBridge(null);
					}
				}else
					$scope.terminoSolicitud = true;
				
			}
			
		};/* END VALIDACION BOTON */
		
		$scope.nombrePersonaMinusculas=function(){
			$rootScope.nombreCamel=generalService.camelize($rootScope.solicitudJson.cotizacion.clientes[0].nombre);
			$rootScope.apellidoPaternoCamel=generalService.camelize($rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno);
			$rootScope.apellidoMaternoCamel=generalService.camelize($rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno);
		};
		
		$scope.init = function( banderaGuardarSeccion )
		{
			$scope.btnOchoPasos= !$rootScope.productosTarjetas($rootScope.solicitudJson.idProducto) && generalService.validardiaDePago() && 
							     !$rootScope.marcaTipoDispersionSeleccionado && !($rootScope.marcaDiaDePagoSeleccionado && $rootScope.solicitudJson.idProducto != ID_PRODUCTO.prestamoPersonal)?"Guardar día de pago":"Generar Cita";
			//Se verifica que el usuario que genero no sea el que libere
			$scope.estadoSolicitud = $rootScope.solicitudJson.idSeguimiento;
			$scope.marcaSolicitud = $rootScope.solicitudJson.marca;
			
			if( messageData ){

				/*\Se agrega un evento para la bitacora\*/
//				(Búsqueda Cliente)
				$rootScope.addEvent( BITACORA.SECCION.busquedaCliente.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, 0, BITACORA.SECCION.busquedaCliente.guardarEnBD );
				/*\Se agrega un evento para la bitacora\*/
				
// I-MODIFICACION CAMBACEO (QUITAR BOTON GENERAR CITA)
				if ( $rootScope.esSolicitudCambaceo( $rootScope.solicitudJson.marca) ){
					$scope.mostrarGeneraCita = false;
				}else{
					$scope.mostrarGeneraCita = !$rootScope.campanasConvivencia($rootScope.solicitudJson.campana) &&  !$scope.validareactivado() && !($rootScope.productosSIPA($rootScope.solicitudJson.idProducto)  && $rootScope.promocionCampanas($rootScope.solicitudJson.campana)) && !$rootScope.productosTarjetas($rootScope.solicitudJson.idProducto);
				}
				
				if($rootScope.campanasConvivencia($rootScope.solicitudJson.campana))
						$scope.titulo_TDC = "Liberar Límite de Crédito";
					else 
						$scope.titulo_TDC = "Entregar TDC";
				
				if($rootScope.campanasEsc_Ctes($rootScope.solicitudJson.campana) && $rootScope.solicitudJson.idSeguimiento==6 && $rootScope.solicitudJson.marca==270 ){
					$scope.titulo_TDC = "Entregar TDC";
				}
				
// F-MODIFICACION CAMBACEO (QUITAR BOTON GENERAR CITA)				
/** INICIA_OS-FLUJO COACREDITADO **/
				/** Bloquear el botón de expediente si se va por el flujo de los 20K **/
					if( $scope.existeObligadoSolidario && $rootScope.solicitudJson.marca == 216 && $rootScope.condicionamientoIngMay20 ){
						$rootScope.solicitudJson.documentos.bloqueado = 1;
					}
/** INICIA_OS-FLUJO COACREDITADO **/
				
				$scope.showResumenMonto = ($rootScope.solicitudJson.idProducto==ID_PRODUCTO.prestamoPersonal || $rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)/*MOSTRAR MONTO CUANDO SEA PRODUCTO TARJETAS*/ ); 
				$scope.showResumenOferta30Dias = false;
				$scope.showResumenConsumo = false;
				
				if(($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.pendienteDigitalizar ||//1020
					$rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.docDigitalizado ||//1023
					$rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.docPendValidar ||//1024
					$rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.DocValidado /*1024*/) && $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id){
					
					var capacidadesCliente = obtenerCapacidadesPrestamoyProducto($rootScope.capacidadesPagoProducto);
					
					//Sobregiro solo para Italika
					$scope.italikaSobregiro = false;
					$scope.italikaSobregiro = $scope.capacidadesPagoProductoVisible && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.italika;
					
					if($rootScope.solicitudJson.idProducto != PRODUCTOS.prestamoPersonal.ID.valor){
						$scope.showInfoCapacidadConsumo = true;

						$scope.montoOferta30DiasCP = capacidadesCliente.prestamoPersonal.capacidadPagoNoComprobable;
						$scope.montoOferta30DiasCC = capacidadesCliente.consumo.capacidadPagoNoComprobable;
						
						if($scope.montoOferta30DiasCP == $scope.montoOferta30DiasCC){
							$scope.showInfoCapacidadConsumo = false;
						}
						
						//Sobregiro solo para Italika
						$scope.italikaSobregiro = false;
						$scope.italikaSobregiro = $scope.showInfoCapacidadConsumo && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.italika;
						
					}else{
						$scope.showInfoCapacidadConsumo = false;
						$scope.montoOferta30DiasCP = capacidadesCliente.prestamoPersonal.capacidadPagoNoComprobable;
					}

					$scope.showResumenOferta30Dias = true;
					$scope.showResumenMonto = false;
				}
				
				$scope.calculaCPConsumo();
				if( generalService.existeSolicitud($rootScope.solicitudJson) && $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.pendienteProceso.id && !generalService.cambaceoRechazadoConAlternativas($rootScope.solicitudJson.marca)){
					$rootScope.onceOfert = false;
					$scope.consultaProductos(banderaGuardarSeccion);
				
				}else{
					$scope.realizaini(banderaGuardarSeccion);
				}
				
				switch($rootScope.ofertaMCO){
				case 0:
				if($rootScope.consultaFuncionalidad.liberacionSinCodigo && !$rootScope.pedirCodigoSoloUnaVez) {
					$rootScope.pedirCodigoSoloUnaVez = true;
					
					if(($rootScope.solicitudJson.idSeguimiento == 6 || $rootScope.solicitudJson.idSeguimiento == 185) 
							&& $rootScope.solicitudJson.marca == 215 && $rootScope.solicitudJson.envioCelular != 1) {
						/*
						 * Se debe preguntar si no ha recibido el código celular.
						 */
						modalService.confirmModal("Código de Seguridad", 
								["¿Tu cliente recibió su código de seguridad?"], "No", "Sí").then(
								function(exito) {
									console.log("Sí recibió el código.");
									
									// Se muestra el modal para validación del código.
									modalService.codigoModal(null, 777, CLIENTE.id).then(
					  					function(exito) {
					  						console.log("Validar");
					  					}, function(error) {
					  						console.log("Validar más tarde.");
					  					}
						  			);
								}, function(error) {
									console.log("No recibió el código.");
									
									if(smsOrCall() == -1) {
										console.log("Ya no quedan intentos.");
									} else {
										// Se muestra el modal para reenvío de código.
										modalService.codigoModal(null, 666, CLIENTE.id).then(
						  					function(exito) {
						  						/*
						  						 * El caso de éxito de este modal es el de validar, pero con esta
						  						 * configuración no es visible, por lo que no se puede ejecutar.
						  						 */
						  					}, function(error) {
						  						console.log("Reenvío de código.");
						  					}
							  			);
									}
								}
						);
					}
				}
				break;
				case 1:
					if($rootScope.solicitudJson.ofertaSeleccionadaMCO == 1)
						modalService.alertModal("AVISO",["El comprobante de ingresos ha sido validado. La capacidad de pago del cliente es de: [ " + $rootScope.solicitudJson.capacidadPagoComprobable + " ]"],"Aceptar",null,null,null,null);
						break;
				case 2:
					if($rootScope.solicitudJson.ofertaSeleccionadaMCO == 1)
						modalService.alertModal("AVISO",["El comprobante de ingresos no es válido, por lo que la capacidad de pago a asignar al cliente es: [ " + $rootScope.solicitudJson.capacidadPagoNoComprobable + " ]"],"Aceptar",null,null,null,null);	
						break;
				}
				
			}// END IF MESSAGEDATA
			$rootScope.waitLoaderStatus = LOADER_HIDE;
	    };/* END INIT FUNCTION*/
	    
	    function obtenerCapacidadesPrestamoyProducto(capacidadesPagoProducto){
	    		var capacidadesOferta30Dias={
	    			prestamoPersonal:{
					capacidadPagoComprobable:0,
					capacidadPagoNoComprobable:0
				},
				consumo:{
					capacidadPagoComprobable:0,
					capacidadPagoNoComprobable:0
				},
				consumo_elektra:{
					capacidadPagoComprobable:0,
					capacidadPagoNoComprobable:0
				}
			}
	    	
	    		for(var i=0; i< capacidadesPagoProducto.length;i++){
					if(capacidadesPagoProducto[i].producto == PRODUCTOS.prestamoPersonal.ID.valor){
						capacidadesOferta30Dias.prestamoPersonal.capacidadPagoComprobable   = capacidadesPagoProducto[i].capacidadPagoComprobable;
						capacidadesOferta30Dias.prestamoPersonal.capacidadPagoNoComprobable = capacidadesPagoProducto[i].capacidadPagoNoComprobable;
					}
					
					if($rootScope.solicitudJson.idProducto == $rootScope.capacidadesPagoProducto[i].producto){
						capacidadesOferta30Dias.consumo.capacidadPagoComprobable   = capacidadesPagoProducto[i].capacidadPagoComprobable;
						capacidadesOferta30Dias.consumo.capacidadPagoNoComprobable = capacidadesPagoProducto[i].capacidadPagoNoComprobable;
					}
					if(capacidadesPagoProducto[i].producto == PRODUCTOS.consumo.ID.valor){
						capacidadesOferta30Dias.consumo_elektra.capacidadPagoComprobable   = capacidadesPagoProducto[i].capacidadPagoComprobable;
						capacidadesOferta30Dias.consumo_elektra.capacidadPagoNoComprobable = capacidadesPagoProducto[i].capacidadPagoNoComprobable;
					}
			}
	    		
	    		return capacidadesOferta30Dias;
	    }
	    
	    $scope.calculaCPConsumo=function(){
	    	if(($rootScope.solicitudJson.idProducto==ID_PRODUCTO.consumo || $rootScope.solicitudJson.idProducto==ID_PRODUCTO.italika  || 
					$rootScope.solicitudJson.idProducto==ID_PRODUCTO.telefonia || $rootScope.solicitudJson.idProducto==ID_PRODUCTO.tarjetaAztecaProducto) && 
				generalService.isCanalInterno($rootScope.sucursalSession.idCanal) && 
				($rootScope.solicitudJson.capacidadPagoComprobable || $rootScope.solicitudJson.capacidadPagoNoComprobable) &&
				!$scope.showResumenOferta30Dias){					
				
				$scope.showResumenConsumo = true;
				$scope.showInfoCPonsumo = false;
				
				if($rootScope.capacidadesPagoProducto != undefined && $rootScope.capacidadesPagoProducto != null && $rootScope.capacidadesPagoProducto != ""){
					var capacidadesCliente = obtenerCapacidadesPrestamoyProducto($rootScope.capacidadesPagoProducto);
					
					if( $rootScope.solicitudJson.banderaIngresos == 1){
						if(capacidadesCliente.prestamoPersonal.capacidadPagoComprobable >= 50){
							$scope.montoConsumoCP = capacidadesCliente.prestamoPersonal.capacidadPagoComprobable;
							$scope.showInfoCPonsumo = true;
						}
						$scope.montoConsumoCC = capacidadesCliente.consumo.capacidadPagoComprobable;
					}else if($rootScope.solicitudJson.banderaIngresos == 0){
						if(capacidadesCliente.prestamoPersonal.capacidadPagoNoComprobable >= 50){
							$scope.montoConsumoCP = capacidadesCliente.prestamoPersonal.capacidadPagoNoComprobable;
							$scope.showInfoCPonsumo = true;
						}
						//$scope.montoConsumoCC = capacidadesCliente.consumo.capacidadPagoNoComprobable;
						if($rootScope.solicitudJson.idProducto == PRODUCTOS.tarjetaAzteca.ID.valor)
							$scope.montoConsumoCC = capacidadesCliente.consumo_elektra.capacidadPagoNoComprobable;
						else
							$scope.montoConsumoCC = capacidadesCliente.consumo.capacidadPagoNoComprobable;
					}
					//Sobregiro solo para Italika
					$scope.italikaSobregiro = false;
					$scope.italikaSobregiro = $scope.showInfoCPonsumo && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.italika;
				}else{
					if( $rootScope.solicitudJson.banderaIngresos == 1){
						$scope.montoConsumoCC = $rootScope.solicitudJson.capacidadPagoComprobable
						//if($rootScope.solicitudJson.idProducto == PRODUCTOS.tarjetaAzteca.ID.valor)
						//	$scope.montoConsumoCC = capacidadesCliente.consumo_elektra.capacidadPagoComprobable;
						//else	
						//	$scope.montoConsumoCC = $rootScope.solicitudJson.capacidadPagoComprobable
					}else if($rootScope.solicitudJson.banderaIngresos == 0){
						$scope.montoConsumoCC = $rootScope.solicitudJson.capacidadPagoNoComprobable
					}
				}
			}
	    };
	    
	    $scope.consultaProductos=function(banderaGuardarSeccion){
		    $rootScope.waitLoaderStatus = LOADER_SHOW;
			buroService.resultadoConsultaProductos($rootScope.solicitudJson.idSolicitud,$rootScope).then(
					function(objRes){								
						buroService.productosAutorizados(objRes);							
						$scope.realizaini(banderaGuardarSeccion);								
																
					}, function(error){
						$scope.realizaini(banderaGuardarSeccion);
						$rootScope.message("ERROR", [error], "Aceptar");
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 								
					}
			);
	    };
	    
	    $scope.realizaini=function(banderaGuardarSeccion){
	    	$scope.validacionBoton();
			var idPro=$rootScope.solicitudJson.idProducto;
			
			$scope.srcImagenProducto=idPro==ID_PRODUCTO.prestamoPersonal?"":idPro==ID_PRODUCTO.consumo?"consum.png":idPro==ID_PRODUCTO.italika?"ital.png":idPro==ID_PRODUCTO.telefonia?"icon_telefonia_monto.png":"";
			$rootScope.srcImagenProductoT=idPro==ID_PRODUCTO.prestamoPersonal?"":idPro==ID_PRODUCTO.consumo?"consumo.png":idPro==ID_PRODUCTO.italika?"italika.png":idPro==ID_PRODUCTO.telefonia?"telefoniaa.png":"";
			$rootScope.srcImagenProductoTDes=idPro==ID_PRODUCTO.prestamoPersonal?"":idPro==ID_PRODUCTO.consumo?"Consumo":idPro==ID_PRODUCTO.italika?"Italika":idPro==ID_PRODUCTO.telefonia?"Telefonía":"";
			$scope.nombrePersonaMinusculas();									
				 
			if( configuracion.origen.tienda && $rootScope.solicitudJson.cotizacion.clientes[0].foto == FOTO_ENCOLADO_IPAD)
				$rootScope.obtenerEnviosXCliente('ochoPasosDivId', 'getFotoIpad', $rootScope.solicitudJson.cotizacion.clientes[0].idPersona);
			
			if(generalService.getArrayValue("seCotizoItalika") && $scope.muestraTermometro){
				$scope.muestraAlertaNuevoBuro=false;
				$scope.muestraMensajeNuevoBuro=false;
				$scope.mensajeNuevoBuro=""
			}
								
			cargaVista( banderaGuardarSeccion );
			
			$timeout(function(){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.shoobtiwPage = messageData;
			}, 0);
	    };
	    
	    $scope.geolocalizacion = function(){
			if( configuracion.origen.tienda ){				
				try{
					$rootScope.obtenerGeolocalizacion( 'ochoPasosDivId', 'responseGPS' );
				}catch(e){
					modalService.alertModal("Error al obtener geolocalización catch",[e],null,null,null,null,null);
				}				
			}			
		};
		
		$scope.responseGPS = function( responseArgsBack ){
			$rootScope.loggerIpad("responseGPS", null, responseArgsBack);
			if( responseArgsBack.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
				localStorage['latitude'] = responseArgsBack.latitud;
				localStorage['longitude'] = responseArgsBack.longitud;
				localStorage['currentPosition'] = responseArgsBack.mensaje;
			}else{
				console.warn( 'GeoLocation default' );
				localStorage['currentPosition'] = null;
				localStorage['latitude'] = "19.2972509"; // Grupo Salinas
				localStorage['longitude'] = "-99.1853969"; // Grupo Salinas
			}
			
		}

	    $scope.validaCodigo = function( opcion, bloqueo, jsonObject, terminado )
	    {
//	    	Esta función controla que evento se debe agregar a la lista de eventos (de la bitacora)
	    	agregaEventoDesdeOchoPasos(opcion, bloqueo);
	    	
	    	$scope.muestraAlertaCodigo = false;
			$scope.muestraMensajeCodigo = false;
	    	var tipoPersona = CLIENTE.id;
	    	
	    	if( opcion == validacionPath[SECCION_HOGAR].nombrePath )
	    		$scope.geolocalizacion();
	    		
	    	var callModal = function(persona) {
	    		if($rootScope.consultaFuncionalidad.liberacionSinCodigo) {
		  			if(opcion != null && opcion) {
    					generalService.locationPath(opcion);
    				}
		  		} else {
		  			modalService.codigoModal(null, opcion, persona).then(
	  					function(exito) {
	  						$scope.guarda(exito);
	  					}, function(error) {
	  						if(opcion != null && opcion) {
	  							generalService.locationPath(opcion);
	  						} else {
	  							var faltaCelular=false;
	  							
	  							if($rootScope.solicitudJson.envioCelular != 1  && terminado) {
	  								faltaCelular = true;				
	  								$scope.muestraAlertaCodigo = true;
	  								$scope.muestraMensajeCodigo = true;
	  								$scope.mensajeCodigo = "Es necesario validar el código celular";
	  							}
	  							
	  							if(!faltaCelular && terminado) {
	  								if($rootScope.solicitudJson.avales[0].envioCelular != 1 
	  										&& $rootScope.solicitudJson.envioCelular == 1 
	  										&& $rootScope.solicitudJson.banderaSolidario == 1 
	  										&& $rootScope.solicitudJson.avales[0].presencial == 1) {
	  									$scope.llenaSeccion = false;				
	  									$scope.muestraAlertaCodigo = true;
	  									$scope.muestraMensajeCodigo = true;
	  									$scope.mensajeCodigo = "Es necesario validar el código celular del " +
	  											"Coacreditado";
	  								}
	  							}
	  						}

	  					}
		  			);
		  		}
	    	};
	    	
	    	if( typeof jsonObject !== undefined && jsonObject != null ){
	    		
	    		if( jsonObject.tipoPersona == AVAL.id && $rootScope.solicitudJson.avales[0].presencial == 1 
	    				&& ( $rootScope.solicitudJson.avales[0].envioCelular == 0 ) )
	    			callModal( jsonObject.tipoPersona );
	    		else
	    			callModal( jsonObject.tipoPersona );
	    		
	    	}else if( bloqueo == 0 ){
		  		
		  		if( opcion == validacionPath[SECCION_AVAL].nombrePath )
		  			tipoPersona = AVAL.id;
		  				  		
		  		if( ( $rootScope.solicitudJson.envioCelular == 0  ) && tipoPersona == CLIENTE.id ){
		  				callModal( tipoPersona );
		  		}else if( ( $rootScope.solicitudJson.avales[0].envioCelular == 0 ) && tipoPersona == AVAL.id && $rootScope.solicitudJson.avales[0].presencial == 1 ){
		  				callModal( tipoPersona );
		  		}else{
		  			if( opcion != null && opcion )									
						generalService.locationPath(opcion);
		  		}
		  		
		  	}//END IF BLOQUEO
		  	
	    };/* END VALIDA CODIGO FUNCTION */
	
		
		$scope.simulador = function() 
		{
			configuracion.simulador.opcion = 2;
			generalService.locationPath("/");
		};/* END SIMULADOR FUNCTION */

		function cargaVista( banderaGuardarSeccion )
		{
			$scope.validaEdicionSecciones();
			if( configuracion.origen.tienda )
				$scope.origen = "TIENDA";
			else
				$scope.origen = "WEB";
			
			$rootScope.calculaDocumentos();
			
			var total = 0;
		    var convalor = 0;
		    
		    if ( esIpad && configuracion.origen.tienda ){
				$rootScope.Ipad = true;
			}
		    
		    
		    var contratos = $rootScope.solicitudJson.contratos.contrato;
			for(var i in contratos){
				if(contratos[i].idContrato == FIRMA_BIENES.id || contratos[i].idContrato == FIRMA_ACUSE_TAZ.id){
					if(!generalService.isEmpty($rootScope.firmaBienes) || 
							($rootScope.solicitudJson.contratos.contrato[i] == STATUS_CONTRATO.ENVIAD0 && $rootScope.isFirmaUnica)){
						$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.ENVIAD0;
					}else if(!generalService.isEmpty($rootScope.firmaAcuseTaz)){
						$rootScope.solicitudJson.contratos.contrato[i].statusFirma = STATUS_CONTRATO.ENVIAD0;
					}	
				}
			}
			
		    var cdpAlcanza;
		    if ($rootScope.solicitudJson.banderaIngresos == 1)
		    	cdpAlcanza = $scope.calcupaRestante($rootScope.solicitudJson.capacidadPagoComprobable, $rootScope.solicitudJson.cotizacion.pagoPuntual);
			else
				cdpAlcanza = $scope.calcupaRestante($rootScope.solicitudJson.capacidadPagoNoComprobable, $rootScope.solicitudJson.cotizacion.pagoPuntual);
		    
		    if( (cdpAlcanza < 10 && $rootScope.solicitudJson.banderaSeguro != 1) || generalService.consultaHistoricoMarcas([150,151])!=0 ){
		    	$scope.alcanzaCDPSeguro = false;
		    }else{
		    	$scope.alcanzaCDPSeguro = true;
		    }

		  //Bandera que valida las condiciones para mostrar los contratos de la solicitud y proceder a la firma de ellos
		    $rootScope.mostrarContratos=(($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.autorizadoMesa) && 
		    							 ($rootScope.solicitudJson.banderaSeguro == 1 || $rootScope.solicitudJson.idProducto != ID_PRODUCTO.prestamoPersonal || !$scope.alcanzaCDPSeguro) && ($rootScope.solicitudJson.ofertaSeleccionadaMCO != 1)) ? true:false;

		    
		    if ( $rootScope.solicitudJson.creditoInmediato == 0 
		    		&& ( $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.generada.id || 
		    				$rootScope.solicitudJson.idSeguimiento== STATUS_SOLICITUD.malZonificada.id
		    			 || $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.investigacion.id ) ){
		    		/**
		    		 * Se obtiene el porcentaje con base a el estatus y marca de la solicitud y al estatus del documento
		    		 * Se divide entre dos, al inicio, con estas condiciones, solo pueden exisitir dos solicitudes
		    		 **/
		    		var firmadosDocs = 0;
		    		for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
		    			if($rootScope.solicitudJson.contratos.contrato[i].idContrato === "1" || $rootScope.solicitudJson.contratos.contrato[i].idContrato === "2"
		    					|| $rootScope.solicitudJson.contratos.contrato[i].idContrato === "13"
		    					|| (generalService.validardiaDePago() && ($rootScope.solicitudJson.contratos.contrato[i].idContrato === "3" 
		    					|| $rootScope.solicitudJson.contratos.contrato[i].idContrato === "4"))){
		    				if($rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.ENVIAD0 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.FIRMADO_SIN_ENVIAR)
		    					firmadosDocs++;
		    			}
		    		}
		    		if($rootScope.campanasConvivencia($rootScope.solicitudJson.campana) || $rootScope.promocionCampanas($rootScope.solicitudJson.campana)){
		    			numDocs = 2;
		    		}else{
		    			var numDocs = generalService.validardiaDePago()?4:2;
		    		}
		    		if($rootScope.prestamoGarantias || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.prodResPrestamoConGarantias)
		    			numDocs = numDocs + 1;
		    		$rootScope.solicitudJson.contratos.porcentaje = firmadosDocs==0?0:parseInt(((firmadosDocs * 100) / numDocs).toFixed(0));
		    		
		    		if(generalService.validardiaDePago()){
			    	    if(!generalService.isEmpty($rootScope.firmaPrivacidad) && !generalService.isEmpty($rootScope.firmaBuro) &&
			    	       !generalService.isEmpty($rootScope.firmaCaratula) && !generalService.isEmpty($rootScope.firmaSolicitud)){
			    	        $rootScope.solicitudJson.contratos.porcentaje = 100;
			    	        $rootScope.solicitudJson.contratos.contrato[0].statusFirma = STATUS_CONTRATO.ENVIAD0;
			    	        $rootScope.solicitudJson.contratos.contrato[1].statusFirma = STATUS_CONTRATO.ENVIAD0;
			    	        $rootScope.solicitudJson.contratos.contrato[2].statusFirma = STATUS_CONTRATO.ENVIAD0;
			    	        $rootScope.solicitudJson.contratos.contrato[3].statusFirma = STATUS_CONTRATO.ENVIAD0;
			    	    }
		    		}else if(!generalService.isEmpty($rootScope.firmaPrivacidad) && !generalService.isEmpty($rootScope.firmaBuro) 
		    				&& $rootScope.solicitudJson.marca != STATUS_SOLICITUD.generada.marca.prodResPrestamoConGarantias){
		    					$rootScope.solicitudJson.contratos.porcentaje = 100;
		    					$rootScope.solicitudJson.contratos.contrato[0].statusFirma = STATUS_CONTRATO.ENVIAD0;
				    	        $rootScope.solicitudJson.contratos.contrato[1].statusFirma = STATUS_CONTRATO.ENVIAD0;
		    			}
		    }
		    
		    if (($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id || $rootScope.solicitudJson.idSeguimiento== STATUS_SOLICITUD.malZonificada.id || $rootScope.solicitudJson.idSeguimiento ==  STATUS_SOLICITUD.preautorizada.id || $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.mesaControl.id) &&
		    		(!$rootScope.mostrarContratos ||
		    		 $rootScope.solicitudJson.marca == STATUS_SOLICITUD.preautorizada.marca.fico ||		
		    		 $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinLiberar ||
					 $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.clienteVerdeJVC ||
					 $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.ejecutivo  ||					 
					 $rootScope.solicitudJson.marca == STATUS_SOLICITUD.mesaControl.marca.condicionadoMesa)){		    
		    		/**
		    		 * Se obtiene el porcentaje con base a el estatus y marca de la solicitud y al estatus del documento
		    		 * Se divide entre 2 para que no pida la firma de contratos hasta que se haya validado el expediente.
		    		 **/
		    		var firmadosDocs = 0;
		    		for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
		    			if($rootScope.solicitudJson.contratos.contrato[i].idContrato === "1" || $rootScope.solicitudJson.contratos.contrato[i].idContrato === "2"){
		    				if($rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.ENVIAD0 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.FIRMADO_SIN_ENVIAR)
		    					firmadosDocs++;
		    			}
		    		}
		    	
		    		$rootScope.solicitudJson.contratos.porcentaje = parseInt(((firmadosDocs * 100) / 2).toFixed(0));
		    }
		    
		    if( ($rootScope.solicitudJson.idSeguimiento ==  STATUS_SOLICITUD.autorizada.id || $rootScope.solicitudJson.idSeguimiento== STATUS_SOLICITUD.malZonificada.id) && 
					  ($rootScope.mostrarContratos) ||
					  ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.condicionada.id && $rootScope.solicitudJson.idCondicion == STATUS_SOLICITUD.condicionada.idCondicion.expIncompleto)){
		    		var contador = 0;
		    		var firmadosDocs = 0;
		    		if ($rootScope.solicitudJson.contratos.contrato.length < 3){
		    			contador = 2;
		    			firmadosDocs = 2;
		    		}
		    		for(var i = 0; i < $rootScope.solicitudJson.contratos.contrato.length; i ++){
		    			if ($rootScope.solicitudJson.banderaSolidario == 1){
		    				contador++;
// I-MODIFICACION TDC ( VALIDACION DE PORCENTAJES PARA CONTRATOS INFORMATIVOS)										    				
		    				if (!($rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.SIN_FIRMA || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.INFORMATIVO)){
// F-MODIFICACION TDC ( VALIDACION DE PORCENTAJES PARA CONTRATOS INFORMATIVOS)										    				
		    					firmadosDocs++;
		    				}		    				
		    			}else{
		    				if ($rootScope.solicitudJson.contratos.contrato[i].idTipoPersona != 3){
			    				contador++;
// I-MODIFICACION TDC ( VALIDACION DE PORCENTAJES PARA CONTRATOS INFORMATIVOS)										    							    			
			    				if (!($rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.SIN_FIRMA || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == STATUS_CONTRATO.INFORMATIVO)){
// F-MODIFICACION TDC ( VALIDACION DE PORCENTAJES PARA CONTRATOS INFORMATIVOS)										    							    				
			    					firmadosDocs++;
			    				}	
		    				}
		    			}
		    		}
		    	
		    		$rootScope.solicitudJson.contratos.porcentaje = contador==0?0:parseInt(((firmadosDocs * 100) / contador).toFixed(0));
		    		$rootScope.seccionCompleta = ($rootScope.solicitudJson.contratos.porcentaje == 100) ? true:false;
		    		
/** INICIA_OS-FLUJO COACREDITADO **/
		    		
		    		/** Caculamos el porcenta depues de que el porcentaje de los contratos del cliente esté en 100, esto con la finalidad de firmar los contratos faltantes del Coacreditado depués de la vista **/
		    		/** **/

		    		if( $scope.existeObligadoSolidario && $rootScope.solicitudJson.contratos.porcentaje == 100 ){
		    			
		    			// calcula el porcentaje de los contratos
		    			generalServiceOS.calculaPocentajeDocs();
		    			
		    			// actualiza el porcentaje de la sección del Coacreditado
		    			respuestaSeccionOS = generalService.evaluaAgendaCita( $rootScope.solicitudOSJson, $scope.menuListOS );
		    			
		    			//Permitimos continuar con la actulización de la marca
		    			$scope.firmarContratosOS = true;
		    		}
		    		
/** TERMINA_OS-FLUJO COACREDITADO **/

		    }
		    
			$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";
			arrayPlazoMonto = generalService.multitasas("PRESTAMOS PERSONALES.TASA POR PRODUCTO/PLAZO.PRODUCTO - PLAZO - TASA",tipoTasa);
			$scope.labelTiempo=MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO TIEMPO."+$scope.origen+".valor"];
			$scope.labelMin=" " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO MIN."+$scope.origen+".valor"];
			$scope.labelPrestamo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO PRESTAMO."+$scope.origen+".valor"];
			$scope.labelAntes =  '<p>Si paga puntual</p><h3>{{solicitudJson.cotizacion.pagoPuntual | currency:$:0}}</h3>';
			$scope.labelAhorro = '<p class="fVerde">Se ahorra</p><h4 class="fVerde" style="font-size:14px;">{{solicitudJson.cotizacion.pagoNormal - solicitudJson.cotizacion.pagoPuntual | currency:$:0}} {{solicitudJson.cotizacion.periodicidad | lowercase}}</h4><h5 class="fVerde" style="margin-top:5px;font-size:13px;">{{(solicitudJson.cotizacion.pagoNormal - solicitudJson.cotizacion.pagoPuntual)*solicitudJson.cotizacion.plazo | currency:$:0}} total</h5>';
			//			$scope.labelAhorro = '<p class="fVerde">Su ahorro</p><h3 class="fVerde">{{solicitudJson.cotizacion.pagoNormal - solicitudJson.cotizacion.pagoPuntual | currency:$:0}}</h3><p class="fVerde">{{solicitudJson.cotizacion.periodicidad | lowercase}}es</p>';
//			$scope.labelAhorro = '<h4 class="fVerde">{{solicitudJson.cotizacion.pagoNormal - solicitudJson.cotizacion.pagoPuntual | currency:$:0}} {{solicitudJson.cotizacion.periodicidad | lowercase}}</h4>';
//			$scope.labelAhorroTotal = '<h4 class="fVerde">{{(solicitudJson.cotizacion.pagoNormal - solicitudJson.cotizacion.pagoPuntual)*solicitudJson.cotizacion.plazo | currency:$:0}} total</h4>';
			$scope.labelPlazo = '<p>Plazo</p><h3>{{solicitudJson.cotizacion.plazo}} semanas</h3>';/*<p>semanas</p>';*/
			$scope.labelPago = '<p>Pagará</p><h3>{{solicitudJson.cotizacion.pagoNormal | currency:$:0}}</h3>';/*<p>{{solicitudJson.cotizacion.periodicidad | lowercase}}mente</p>'*/;
			$scope.labelAvance = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO AVANCE."+$scope.origen+".valor"];
			
			/** Cambaceo: mostrar la modal de cambaceo para cliente presente **/
			if( generalService.actualizaCambaceoPorcentaje() )
				$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = 80;
			
			$scope.esCambaceo();
			
			
			$scope.buildMenuList();
			
			$scope.condiciones = {
					tipoComprobante: ''
			}
			

			//PASAR PARAMETRO PARA DESACTIVAR 			
			$scope.condicionesLiberacion();

/** INICIA_OS-FLUJO COACREDITADO **/
			/** Se agregó la condición solo para cuando no es Coacreditado **/
			if( !generalService.consultaSinObligado($scope.existeObligadoSolidario) && 
				!generalService.cambaceoPrecalificado($rootScope.solicitudJson.marca ) && 
				!generalService.esCandidatoRescateItalika($rootScope.solicitudJson.marca ) &&
				$rootScope.solicitudJson.marca != STATUS_SOLICITUD.generada.marca.generadaCambaceo){
				$scope.condicionesMostrarTermometro(banderaGuardarSeccion);
			}
/** TERMINA_OS-FLUJO COACREDITADO **/						
		$scope.quitarBotonVolverACotizar = function(){
			$scope.muestraBoton = false;
			$scope.muestraAlertaNuevoBuro=false;
			$scope.muestraMensajeNuevoBuro=false;
		}
		
		if( $rootScope.solicitudJson.banderaOfertaCP != 0 && $scope.existeObligadoSolidario ){
			$scope.quitarBotonVolverACotizar();
			$rootScope.onceOfert = true;
			$rootScope.mostrarOfertaCotizador = false;
			$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
			
		}

		/** Se valida si el cliente califica para un producto de rescate de Telefonia**/
		$scope.rescateTelefonia();
		/** Se valida si el cliente califica para un producto de rescate de Consumo**/
		$scope.rescateConsumo();
		/** Se valida si el cliente califica para un producto de rescate de Italika**/
		$scope.rescateItalika();
/** INICIA_OS-FLUJO COACREDITADO **/
			/** Muestra el mensaje para seleccionar si registra el Coacreditado, no desea registrar Coacreditado, registrar despues Coacreditado
			**/
			$scope.muestraMensajeObligadoSolidario=function() {
				
				var cuerpoDlg = ["Infórmale a tu cliente que para poder llevarse su producto, es necesario que presente a un Coacreditado."];
				var info = ['Infórmale a tu cliente que tiene hasta "60" días para registrar a su Coacreditado, de lo contrario su solicitud de crédito sera CANCELADA'];
				
				modalService.obligadoSolidarioModal("Aviso Importante", cuerpoDlg, "No tengo Coacreditado", "Registrar Coacreditado", "<span style='vertical-align:0	;margin-left:0;'>Registrar<br>después</span>", "bgAzul", "btn azul", "btn azul" ).then(
						function(exito){
							
							switch(exito){
							
							case 1:
								modalService.confirmModal("Autorización",["Sin el registro de un Coacreditado no es posible continuar con el proceso de solicitud de crédito, podrá generar una segunda solicitud el día:"], "Aceptar", "Registrar después", "bgAzul", "btn azul", "btn gris" ).then(
										function(exito){
											
											var buildJsonDefault=function(){
												generalService.buildSolicitudOSJson($rootScope, null);
												generalService.buildSolicitudJson($rootScope, null);
											};
											
											$rootScope.message("Atención", info,"Aceptar", "/simulador", null, null, buildJsonDefault);
											
										},function(error){
											
											/* EL CLIENTE NO ACEPTA PRESENTAR UN COACREDITADO POR LO TANTO SE RECHAZA LA SOLICITUD */
											
											$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.rechazada.id;
											$rootScope.solicitudJson.idMotivoRechazo = 163;
											$rootScope.waitLoaderStatus = LOADER_SHOW;
										      
											solicitudService.actualizarSolicitud( $rootScope.solicitudJson ).then(
												function(data){
													
													$rootScope.waitLoaderStatus = LOADER_HIDE;
													generalService.cleanRootScope($rootScope);
													generalServiceOS.cleanRootScope($rootScope);
													generalService.buildSolicitudJson($rootScope, null);
													generalService.buildSolicitudOSJson($rootScope, null);
										            generalService.locationPath("/simulador");	
										            
												}, function(error){
													
													$rootScope.waitLoaderStatus = LOADER_HIDE; 
										        	  	modalService.alertModal("Error "+error.status, [error.statusText]);
										        	  	
												}
											);
										}
								 );
								break;
							case 2:
								
								/** Si no ha aceptado la oferta, consulta montos y plazos
								 * Si ya cepto la oferta, se construye el menu para que aparezca la opcion del Coacreditado
								 **/
								
								if( !$rootScope.solicitudJson.banderaOfertaCP ){
									
					    				$rootScope.waitLoaderStatus = LOADER_SHOW;
					    				$scope.muestraOferta = true;
					    				consutaMontosPlazos();
					    				
								}else{
									
									$rootScope.muestraOpcionOS = true;
									$scope.buildMenuList();
									
								}
								break;
							case 3:
								/* SE REGISTRARÁ DESPUÉS EL COACREDITADO. EL CLIENTE PERMANECE EN OCHO PASOS PARA CONTINUAR LLENANDO LAS SECCIONES*/
								
								var buildJsonDefault=function(){
								
									generalService.buildSolicitudOSJson($rootScope, null);
									generalService.buildSolicitudJson($rootScope, null);
									
								};
								
								$rootScope.message("Atención", info,"Aceptar", "/simulador", null, null, buildJsonDefault);
								break;
							}								
						},function(error){
							console.log("No hacer nada");																			
						}
				 );
			}
	
			try{
				if($rootScope.muestraObligadoSolidario && !$rootScope.muestraOpcionOS && ($rootScope.solicitudJson.obligadoSolidario.idSolicitudObligadoSolidario == "" || generalService.solicitudOSRechazado())){
					
					/** Si no ha aceptado la oferta, invoca el modal para que acepte una
					 *  Coacreditado NF	1
					 **/
					
					$scope.muestraMensajeObligadoSolidario();
					
					//NO MOSTRAR EL BOTON DE VOLVER A COTIZAR 
					$scope.muestraBoton = false;
					$scope.muestraAlertaNuevoBuro=false;
					$scope.muestraMensajeNuevoBuro=false;
					
				} else {
					
					/*Se ejecuta esta parte del codigo cuando se rechaza la solicitud del Coacreditado y el cliente tiene la 
					 *opción de registrar uno nuevo. El path manda al simuladorOS
					 */
					
					if( $rootScope.tieneIntentos && $rootScope.solicitudJson.obligadoSolidario.contadorObligadoSolidario > 0) {
	
						$scope.muestraMensajeObligadoSolidario();
						
						//NO MOSTRAR EL BOTON DE VOLVER A COTIZAR 
						$scope.muestraBoton = false;
						$scope.muestraAlertaNuevoBuro=false;
						$scope.muestraMensajeNuevoBuro=false;
						
					}
				}
			}catch(e){}
/** TERMINA_OS-FLUJO COACREDITADO **/

			var montoOriginal = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;
	 		var plazoOriginal = $rootScope.solicitudJson.cotizacion.plazo;
			
			$scope.recordarRadio( plazoOriginal, montoOriginal );

			$timeout( loadProgressbar, 0 );										
			 if (($rootScope.solicitudJson.banderaFolioRecomendador == 0 && ($rootScope.consultaFuncionalidad.solicitudesSIPA || $rootScope.canalesPRG($rootScope.sucursalSession.idCanal)) && !$rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)) && PROMOCION_RECOMIENDA){
				modalService.codigoRecomiendaModal(null,null,null);
			}
			
		};/* END CARGA VISTA FUNCTION */
		

/** INICIA_OS-FLUJO COACREDITADO **/
		
		/**Funcion para mostrar la opcion de Coacreditado
		 * si acepto la oferta, y aun no tiene Coacreditado, se construye de nuevo el menu
		 * Coacreditado NF 4	
		 **/
		function validaOfertaOS(){
			if( generalService.tieneObligadoSolidario($rootScope.solicitudJson )){
				
				$rootScope.muestraOpcionOS = true;
				$scope.buildMenuList();
				
			}
		}
		
/** TERMINA_OS-FLUJO COACREDITADO **/
		
		$scope.validaEdicionSecciones=function(){
			if ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.condicionada.id || 
					$rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id ||
					$rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id && $rootScope.solicitudJson.existeCita == 1){
						generalService.noEditableSecciones(generalService.getSeccionesCompletas($rootScope));
				}
		};
		
		$scope.buildMenuList=function(){
			$scope.btnOchoPasos= !$rootScope.productosTarjetas($rootScope.solicitudJson.idProducto) && generalService.validardiaDePago() && 
							     !$rootScope.marcaTipoDispersionSeleccionado && !($rootScope.marcaDiaDePagoSeleccionado && $rootScope.solicitudJson.idProducto != ID_PRODUCTO.prestamoPersonal)?"Guardar día de pago":"Generar Cita";
			if($rootScope.requiereObligado)
				$rootScope.muestraOpcionOS = true;
			if(generalService.esCandidatoRescatePrestamo($rootScope.solicitudJson.marca) || generalService.esCandidatoRescatePrestamoFaseII($rootScope.solicitudJson.marca) || generalService.esCandidatoRescateConsumoFaseIII($rootScope.solicitudJson.marca) ||
			   $rootScope.rescatePPGarantias || $rootScope.requiereObligado || $rootScope.rescateFaseIII )
				$scope.esRescate=true;
			$scope.menuList=[];
			if(generalService.productosQuickFixes()){
			$scope.menuList.push( 
					{
						texto: "Datos del Cliente",
						labelAvance: $scope.labelAvance,
						porcentaje :porcentajeQF,
						path: '/informacionGeneral',
						image: 'images/menu/opDatosPersonales.jpg',
						alt: "Datos del Cliente",
						progressbar: 'progressbar_opDatosPersonales',
						estilo: 'opc opDatosPersonales',
						showAlerta: false,
						showAuth: $rootScope.solicitudJson.consultasRealizadasEvaluacion == 1,
						numAlerta: '1',
						tituloAlert: '',
						messageAlert: $rootScope.solicitudJson.consultasRealizadasEvaluacion == 1?'Ubica el domicilio de tu cliente en el mapa':'',
						showMessageAlert: false,
					    vistaPorcentaje:  true,
					    messageAuth: '',
						showMessageAuth: $rootScope.solicitudJson.consultasRealizadasEvaluacion == 1,
						show: generalService.productosQuickFixes(),
					    bloqueo: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado == 1 && $rootScope.solicitudJson.cotizacion.clientes[0].bloqueado == 1,
					    prioridad: 1
					 }
				);
			}else{
			$scope.menuList.push( 
					{
						texto: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS BASICOS."+$scope.origen+".valor"],
						labelAvance: $scope.labelAvance,
						porcentaje: $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje,
						path: '/datosPersonales',
						image: 'images/menu/opDatosPersonales.jpg',
						alt: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS BASICOS."+$scope.origen+".valor"],
						progressbar: 'progressbar_opDatosPersonales',
						estilo: 'opc colIzq opDatosPersonales',
						showAlerta: false,
						showAuth: false,
						numAlerta: '1',
						tituloAlert: '',
						messageAlert: '',
						showMessageAlert: false,
					    vistaPorcentaje:  true,
					    messageAuth: '',
						showMessageAuth: false,
						show: !generalService.productosQuickFixes(),
					    bloqueo: $rootScope.solicitudJson.cotizacion.clientes[0].bloqueado,
					    prioridad: parseInt(MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS BASICOS.PRIORIDAD.valor"])
					 }
				);
			}
				$scope.menuList.push( 
					{
						texto: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS HOGAR."+$scope.origen+".valor"],
						labelAvance: $scope.labelAvance,
						porcentaje: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje,
						path: '/datosHogar',
						image: 'images/menu/opDatosHogar.jpg',
						alt: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS HOGAR."+$scope.origen+".valor"],
						progressbar: 'progressbar_opDatosHogar',
						estilo: 'opc colDer opDatosHogar',
						showAlerta: false,
						showAuth: false,
						numAlerta: '1',
						tituloAlert: '',
						messageAlert: '',
						showMessageAlert: false,
						messageAuth: '',
						showMessageAuth: false,
					    vistaPorcentaje:  true,
					    show: !generalService.productosQuickFixes(),
					    bloqueo: $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado,
					    prioridad: parseInt(MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS HOGAR.PRIORIDAD.valor"])
					 }
				);
// I-MODIFICACION TDC (VALIDA PREAPROBADOS PARA BLOQUEAR SECCIONES)						
				if ($rootScope.productosTarjetas( $rootScope.solicitudJson.idProducto ) && 
					$rootScope.promocionCampanas($rootScope.solicitudJson.tarjetasCredito.tarjetaOro.campana) ||
					$rootScope.campanasConvivencia($rootScope.solicitudJson.campana) ){
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].bloqueado = 1;
					$rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje = 100;
					$scope.mostrarMenu = false;
				}
// F-ODIFICACION TDC (VALIDA PREAPROBADOS PARA BLOQUEAR SECCIONES)	
				
// I-MODIFICACION CAMBACEO (VALIDA SOLICITUDES CAMBACEO PARA BLOQUEAR SECCIONES)
				if ( $rootScope.esSolicitudCambaceo( $rootScope.solicitudJson.marca) ){
					$scope.mostrarMenu = false;
				}
// F-MODIFICACION CAMBACEO (VALIDA SOLICITUDES CAMBACEO PARA BLOQUEAR SECCIONES)
				$scope.menuList.push( 
					{
						texto: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS EMPLEO."+$scope.origen+".valor"],
						labelAvance: $scope.labelAvance,
						porcentaje: $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje,
						path: '/datosEmpleo',
						image: $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].bloqueado!=0? 'images/menu/opDatosEmpleo_disabled.jpg':'images/menu/opDatosEmpleo.jpg',
						alt: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS EMPLEO."+$scope.origen+".valor"],
						progressbar: $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].bloqueado!=0?'':'progressbar_opDatosEmpleo',
						estilo: $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].bloqueado!=0?'opc colIzq opMenuDisabled':'opc colIzq opDatosEmpleo',
						showAlerta: false,
						showAuth: false,
						numAlerta: '1',
						tituloAlert: '',
						messageAlert: '',
						showMessageAlert: false,
						messageAuth: '',
						showMessageAuth: false,
					    vistaPorcentaje:  true,
					    /* I-MODIFICACION TDC (NO MOSTRAR SECCIONES EN PREAPROBADOS)*/
						show: $scope.mostrarMenu && 
							/**
							 * Si BD pide mostrar, se muestra sin problemas.
							 * Si BD pide ocultar, sólo se muestra si termina siendo crédito inmediato
							 * y la sección de Datos del Empleo no estaría bloqueada.
							 */
							(mostrarSeccionEmpleo || (!mostrarSeccionEmpleo && doNotLubricate()
								&& $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].bloqueado == 0)),
					    bloqueo: $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].bloqueado,
					    prioridad: parseInt(MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS EMPLEO.PRIORIDAD.valor"])
					 }
				);
				
// I-MODIFICACION TDC (VALIDA PREAPROBADOS PARA BLOQUEAR SECCIONES)				
				if ($rootScope.productosTarjetas( $rootScope.solicitudJson.idProducto ) && 
					$rootScope.promocionCampanas($rootScope.solicitudJson.tarjetasCredito.tarjetaOro.campana) ||
					$rootScope.campanasConvivencia($rootScope.solicitudJson.campana)){
					$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.bloqueado = 1;
					$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje = 100;
					$scope.mostrarMenu = false;
				}
// F-ODIFICACION TDC (VALIDA PREAPROBADOS PARA BLOQUEAR SECCIONES)						
				$scope.menuList.push( 
					{
						texto: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO INGRESOS GASTOS."+$scope.origen+".valor"],
						labelAvance: $scope.labelAvance,
						porcentaje: $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje,
						path: '/ingresosGastos',
						image: 'images/menu/opIngresosGastos.jpg',
						alt: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO INGRESOS GASTOS."+$scope.origen+".valor"],
						progressbar: 'progressbar_opIngresosGastos',
						estilo: 'opc colDer opIngresosGastos',
						showAlerta: generalService.alertaIngresosGastos,
						numAlerta: generalService.numAlertaIngresosGastos,
						tituloAlert: generalService.tituloIngresosGastos,
						showAuth: false,
					    vistaPorcentaje:  true,
					    messageAlert: '',
						showMessageAlert: false,
						messageAuth: '',
						showMessageAuth: false,
						/* I-MODIFICACION TDC (NO MOSTRAR SECCIONES EN PREAPROBADOS)*/
						show: false,//$scope.mostrarMenu && 
							/**
							 * Si BD pide mostrar, se muestra sin problemas.
							 * Si BD pide ocultar, sólo se muestra si termina siendo crédito inmediato.
							 */
							//(mostrarSeccionGastos || (!mostrarSeccionGastos && doNotLubricate())),
					    bloqueo: $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.bloqueado,
					    prioridad: parseInt(MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO INGRESOS GASTOS.PRIORIDAD.valor"])
					 }
				);
								
				
				var menuAval = {
					texto: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS AVAL."+$scope.origen+".valor"],
					labelAvance: $scope.labelAvance,
					porcentaje: $rootScope.solicitudJson.avales[0].porcentaje,
					path: '/aval',
					image: 'images/menu/opObligado.jpg',
					alt: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS AVAL."+$scope.origen+".valor"],
					progressbar: 'progressbar_opObligado',
					estilo: 'opc colDer opObligado',
					showAlerta: false,
					showAuth: false,
					numAlerta: '1',
					tituloAlert: '',
				    vistaPorcentaje:  true,
				    messageAlert: '',
					showMessageAlert: false,
					messageAuth: '',
					showMessageAuth: false,
					show: !$rootScope.esSolicitudCambaceo( $rootScope.solicitudJson.marca),
				    bloqueo: $rootScope.solicitudJson.avales[0].bloqueado,
				    prioridad: parseInt(MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO DATOS AVAL.PRIORIDAD.valor"])
				 };
				

				$rootScope.porcentajes.secciones[5].porcentaje = 100;
				
// I-MODIFICACION TDC (VALIDA PREAPROBADOS PARA BLOQUEAR SECCIONES)										
				if ($rootScope.productosTarjetas( $rootScope.solicitudJson.idProducto ) && 
					$rootScope.promocionCampanas($rootScope.solicitudJson.tarjetasCredito.tarjetaOro.campana) && 
					$rootScope.campanasConvivencia($rootScope.solicitudJson.campana)){
					$rootScope.solicitudJson.referencias.bloqueado = 1;
					$rootScope.solicitudJson.referencias.porcentaje = 100;
					$scope.mostrarMenu = false;
				}
// F-ODIFICACION TDC (VALIDA PREAPROBADOS PARA BLOQUEAR SECCIONES)
				
				$scope.mostrarReferencias = false;
				if($rootScope.consultaFuncionalidad.mostrarReferencias){
					if(generalService.masterFunction())
						$scope.mostrarReferencias = true;
				}else
					$scope.mostrarReferencias = true;
				
				$scope.menuList.push( 
					{
						texto: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO REFERENCIAS."+$scope.origen+".valor"],
						labelAvance: $scope.labelAvance,
						porcentaje: $rootScope.solicitudJson.referencias.porcentaje,
						path: '/referencias',
						image: 'images/menu/opReferencias.jpg',
						alt: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO REFERENCIAS."+$scope.origen+".valor"],
						progressbar: 'progressbar_opReferencias',
						estilo: 'opc colIzq opReferencias',
						showAlerta: false,
						showAuth: false,
						numAlerta: '1',
						tituloAlert: '',
					    vistaPorcentaje:  true,
					    messageAlert: '',
						showMessageAlert: false,
						messageAuth: '',
						showMessageAuth: false,
						show: $scope.mostrarMenu && !$rootScope.esSolicitudCambaceo( $rootScope.solicitudJson.marca) && $scope.mostrarReferencias, /* I-MODIFICACION TDC (NO MOSTRAR SECCIONES EN PREAPROBADOS)*/
					    bloqueo: $rootScope.solicitudJson.referencias.bloqueado,
					    prioridad: parseInt(MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO REFERENCIAS.PRIORIDAD.valor"])
					 }
				);
				
								
				$scope.menuList.push( 
					{
						texto: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO EXPEDIENTE."+$scope.origen+".valor"],
						labelAvance: $scope.labelAvance,
						porcentaje: $rootScope.solicitudJson.documentos.porcentaje,
						path: '/expediente',
						image: 'images/menu/opExpediente.jpg',
						alt: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO EXPEDIENTE."+$scope.origen+".valor"],
						progressbar: 'progressbar_opExpediente',
						estilo: 'opc colDer opExpediente',
						showAlerta: generalService.alertaExpediente,
						numAlerta: generalService.numAlertaExpediente,
						tituloAlert: generalService.tituloExpediente,
					    vistaPorcentaje:  true,
					    showAuth: false,
					    messageAlert: 'Es necesario digitalizar la Identificación Oficial',
						showMessageAlert: true,
						messageAuth: 'Falta la autorización del gerente',
						showMessageAuth: true,
						show:!$rootScope.esSolicitudCambaceo( $rootScope.solicitudJson.marca),
					    bloqueo: $rootScope.solicitudJson.documentos.bloqueado,
					    prioridad: parseInt(MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO EXPEDIENTE.PRIORIDAD.valor"])
					 }
				);
				
				var bandStatusDocInit = 0;
				if($rootScope.solicitudJson.documentos.documento == null)
					$rootScope.solicitudJson.documentos.documento=[];
				for(var i=0;i<$rootScope.solicitudJson.documentos.documento.length;i++){
					if($rootScope.solicitudJson.documentos.documento[i].status == STATUS_RECHAZADO){
						bandStatusDocInit = 1;
						break;
					}
				}
				
				if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expRechazado && bandStatusDocInit){
					$scope.menuList[$scope.menuList.length - 1].showAlerta = true;
					$scope.menuList[$scope.menuList.length - 1].showMessageAlert = true;
					$scope.menuList[$scope.menuList.length - 1].messageAlert = "Expediente rechazado";
				}else{
					$scope.menuList[$scope.menuList.length - 1].showAlerta = false;
					$scope.menuList[$scope.menuList.length - 1].showMessageAlert = false;
					$scope.menuList[$scope.menuList.length - 1].messageAlert = "";
				}
// I-MODIFICACION TDC (LLAMAR A LA VISTA DE CONTRATOS TARJETAS)
				if ($rootScope.productosTarjetas( $rootScope.solicitudJson.idProducto )){
					var pathContratos = '/contratosTarjetas'
				}else{
					var pathContratos = '/contratos'
				}
// F-MODIFICACION TDC (LLAMAR A LA VISTA DE CONTRATOS TARJETAS)
				
				$scope.menuList.push( 
					{
						texto: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO CONTRATOS."+$scope.origen+".valor"],
						labelAvance: $scope.labelAvance,
						porcentaje: $rootScope.solicitudJson.contratos.porcentaje,
						path: pathContratos, /* I-MODIFICACION TDC (LLAMAR CONTRATOS DE TARJETAS)*/
						image: 'images/menu/opContratos.jpg',
						alt: MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO CONTRATOS."+$scope.origen+".valor"],
						progressbar: 'progressbar_opContratos',
						estilo: 'opc colIzq opContratos',
						showAlerta: false,
						showAuth: false,
						numAlerta: '1',
						tituloAlert: '',
						messageAlert: '',
						showMessageAlert: false,
						messageAuth: '',
						showMessageAuth: false,
					    vistaPorcentaje:  true,//generalService.validaContratos,
					    show: !$rootScope.esSolicitudCambaceo( $rootScope.solicitudJson.marca),
					    bloqueo: $rootScope.solicitudJson.contratos.bloqueado,
					    prioridad: parseInt(MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO CONTRATOS.PRIORIDAD.valor"])
					}
				);
				
				/**
				 * CBS Muestra notificación cuando se realizó el cambio de sucursal
				 * **/
				if($rootScope.solicitudJson.solicitudMigrada == SOLICITUD_MIGRADA &&  $rootScope.solicitudJson.consultaBuro == 0){
					$scope.activar = true;
					if ($rootScope.solicitudJson.cotizacion.clientes[0].bloqueado == 0){
			    		$scope.menuList[0].showAlerta = true;
			    		$scope.menuList[0].showMessageAlert = true;
			    		$scope.menuList[0].messageAlert = "Ingrese a la sección y verifica los datos de tu cliente";
			    		$scope.menuList[0].numAlerta = "?";
			    		}
			    	
			    	if($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].bloqueado == 0){
			    		$scope.menuList[1].showAlerta = true;
			    		$scope.menuList[1].showMessageAlert = true;
			    		$scope.menuList[1].messageAlert = "Ingrese a la sección y verifica los datos de tu cliente";
			    		$scope.menuList[1].numAlerta = "?";
			    	}
				}
				
				
				try{
					for(var i=0;i<$scope.menuList.length;i++){
						if($scope.menuList[i].texto === "Contratos"){
							$scope.menuList[i].porcentaje = porcentajeSeccionDocumentos();
							break;
						}
					}
				}catch(e){
					
				}
				
/** INICIA_OS-FLUJO COACREDITADO **/	
				/** Opcion para registrar el Coacreditado **/
				if($rootScope.muestraOpcionOS){
					$scope.menuList.push(
						{
							texto: $rootScope.banderaCoacreditado ? "Coacreditado" : "Obligado Solidario",
							labelAvance:"Avance",
							porcentaje: $scope.existeObligadoSolidario !=false ? respuestaSeccionOS.porcentajeTotal : 0,
							path:"/simuladorOS",
							image:"images/menu/opObligado.jpg",
							alt: $rootScope.banderaCoacreditado ? "Coacreditado" : "Obligado Solidario",
							progressbar:'progressbar_opContratos',
							estilo:"opc colDer opObligado",
							showAlerta:false,
							numAlerta:1,
							tituloAlert:$rootScope.banderaCoacreditado ? "Actuliza los datos del Coacreditado" : "Actuliza los datos del Obligado Solidario",
							vistaPorcentaje:true,
							showAuth:false,
							messageAlert:"",
							showMessageAlert:false,
							messageAuth:$rootScope.banderaCoacreditado ? "Falta llenar datos del Coacreditado" : "Falta llenar datos del Obligado Solidario", 
							showMessageAuth:false,
							show:true,
							bloqueo:0,
							prioridad:8
						}
					);
					
					if($rootScope.solicitudOSJson && $rootScope.solicitudOSJson.idSolicitud != ""){
						if(generalService.solicitudOSRechazado()) {
							/*
							 * Cuando la solicitud del Coacreditado es rechazada, se puede volver a registrar un nuevo Coacreditado
							 * Es por eso que el path lo pongo en simuladorOS para registrar uno nuevo. 
							 */
							$scope.menuList[$scope.menuList.length-1].path = "/simuladorOS"
								
						} else {
							if(generalServiceOS.nuevoFlujoQickFixes())
								$scope.menuList[$scope.menuList.length-1].path = "/datosCoacreditado";
							else 
								$scope.menuList[$scope.menuList.length-1].path = "/ochoPasosOS";
						}
					} 
					
				}
				
				
				//Muestra notificación para zonificar.
				if( $rootScope.solicitudJson.consultasRealizadasEvaluacion == 1 ){
					$scope.registrarDomicilio = true;
					//$scope.menuList[1].showAuth = true;
					//$scope.menuList[1].showMessageAuth = true;
				}
				/**if($rootScope.muestraOpcionGarantias){
					$scope.menuList.push( 
							{
								texto: "Garantias Prendarias",
								labelAvance: $scope.labelAvance,
								porcentaje: $rootScope.solicitudJson.garantias.porcentaje,
								path: '/garantias',
								image: 'images/menu/opGarantias.png',
								alt: "Garantias Prendarias",
								progressbar: 'progressbar_opContratos',
								estilo: "opc colDer opGarantias",
								showAlerta: false,
								showAuth: false,
								numAlerta: '1',
								tituloAlert: '',
								messageAlert: '',
								showMessageAlert: false,
							    vistaPorcentaje:  true,
							    messageAuth: "Falta agregar mas garantias",
								showMessageAuth: false,
								show: true,
							    bloqueo: $rootScope.solicitudJson.garantias.bloqueado,
							    prioridad: 9
							 }
						);
				}**/
/** TERMINA_OS-FLUJO COACREDITADO **/
				if(validaSeccionesTAZ() && generalService.mostrarSeccionTAZ()){		
					$scope.menuList.push( 
							{
								texto: "Entrega de TAZ",
								labelAvance: $scope.labelAvance,
								porcentaje: $rootScope.solicitudJson.folioFlujoUnico != ""?100:0,
								path: '/liberacion',
								image: 'images/menu/opEntregaTAZ.png',
								alt: "Entrega de TAZ",
								progressbar: 'progressbar_opDatosPersonales',
								estilo: 'opc colDer opEntregaTAZ',
								showAlerta: false,
								showAuth: false,
								numAlerta: '1',
								tituloAlert: '',
								messageAlert: '',
								showMessageAlert: false,
							    vistaPorcentaje:  true,
							    messageAuth: '',
								showMessageAuth: false,
								show: true,
							    bloqueo: 0,
							    prioridad: 9
							 }
						);
			}
		botonTAZ();
		 ajustarMenuList();
		};
		
		function ajustarMenuList(){
			var contador = 0;
			
			for(var i=0; i < $scope.menuList.length; i++){
				if($scope.menuList[i].show == true){
					
					contador++;
					$scope.menuList[i].prioridad = contador;
					
					if(((contador)%2) > 0)
						$scope.menuList[i].estilo = $scope.menuList[i].estilo + " colIzq";//los imapres van hacia la izquierda
					else
						$scope.menuList[i].estilo = $scope.menuList[i].estilo + " colDer";// los pares van hacia la derecha
				}	
			}
			
			for(var i=0; i < $scope.menuList.length; i++){
				if($scope.menuList[i].show == false){
					contador++;
					$scope.menuList[i].prioridad = contador;
				}	
			}
			
		}
		
		function botonTAZ(){
			if(generalService.mostrarSeccionTAZ()){
				
				if($rootScope.solicitudJson.folioFlujoUnico == ""){
					
					for(var i=0; i < $scope.menuList.length; i++){
						if($scope.menuList[i].texto === "Entrega de TAZ" && $rootScope.solicitudJson.idSeguimiento != 6)
							$scope.menuList[i].bloqueo = 1;
						else{
							$scope.menuList[i].bloqueo = 0;
							$rootScope.flujoEsOchoPasos =true;
						}	
					}
				}else{
					for(var i=0; i < $scope.menuList.length; i++){
						if ($scope.menuList[i].texto === "Entrega de TAZ" )
							$scope.menuList[i].bloqueo = 1;
					}
				}
				
				
			}
		}
		
		function validaSeccionesTAZ(){
			var mostrar = true;
			
				for(var i=0; i < $scope.menuList.length; i++){
					if ($scope.menuList[i].porcentaje != 100 && $scope.menuList[i].show == true){
						mostrar = false;
						break;
					}
				}
			
			return mostrar;
		}
		
		
		function porcentajeSeccionDocumentos(){
			var porcentaje = 0;
			
			if($rootScope.solicitudJson.idSeguimiento == 185 || $rootScope.solicitudJson.idSeguimiento == 6){
				for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
					if($rootScope.solicitudJson.contratos.contrato[i].statusFirma == 1 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 2 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 4){
						porcentaje = porcentaje + 100; 
					}
				}
				
				$rootScope.solicitudJson.contratos.porcentaje = parseInt( (porcentaje / $rootScope.solicitudJson.contratos.contrato.length).toFixed(0) );
				return $rootScope.solicitudJson.contratos.porcentaje;
			}else{
				for(var i=0;i<$rootScope.solicitudJson.contratos.contrato.length;i++){
					if(($rootScope.solicitudJson.contratos.contrato[i].statusFirma == 1 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 2 || $rootScope.solicitudJson.contratos.contrato[i].statusFirma == 4)){
						if(!generalService.validardiaDePago() || $rootScope.campanasConvivencia($rootScope.solicitudJson.campana) || $rootScope.promocionCampanas($rootScope.solicitudJson.campana)){
							if(i==0 || i==1)
								porcentaje = porcentaje + 100;
						}else{
							if(i==0 || i==1 || i==2 || i==3 || i==4)
								porcentaje = porcentaje + 100;
						}
					}
				}
				if($rootScope.campanasConvivencia($rootScope.solicitudJson.campana) || $rootScope.promocionCampanas($rootScope.solicitudJson.campana)){
					var numDocs  = 2;
				}else{
					var numDocs  = generalService.validardiaDePago()?4:2;
				}
				if($rootScope.prestamoGarantias || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.prodResPrestamoConGarantias)
					numDocs = numDocs + 1;
				$rootScope.solicitudJson.contratos.porcentaje = parseInt( (porcentaje / numDocs).toFixed(0) );
				return $rootScope.solicitudJson.contratos.porcentaje;
			}
		}
		
		$scope.validarRespuestaBuroCanalExterno=function(){
			if(generalService.isProdModatelas($rootScope))
				$scope.validarCIModatelas();
			else if($rootScope.solicitudJson.idProducto===ID_PRODUCTO.tarjetaWaldos)
				$scope.validarCIModatelas();
		};
		
		$scope.validarCIModatelas=function(){
			
			if($rootScope.seConsultoBuro){
				
				if($rootScope.solicitudJson.creditoInmediato == 1){
					
						modalService.notificacionModatelasModal().then(
								function(exito){								
									console.log("cancelar sol");
									solicitudService.cancelarSolicitud({idSolicitud:$rootScope.solicitudJson.idSolicitud});
									$scope.reiniciaCotizacion();																
								},function(error){								
									console.log("No hacer nada");								
								}
						 );
						
					
				}else{
						var cuerpoDlg=["Infórmale a tu cliente que para autorizar su tarjeta será necesario una visita a su domicilio.",
							           "De ser autorizado su crédito, obtendrá una tarjeta con un límite de crédito de $2,000."];
						
						modalService.confirmModal("Notificación",cuerpoDlg, "Continuar", "No está interesado", "bgAzul", "btn gris", "btn azul" ).then(
								function(exito){
									console.log("cancelar sol");
									solicitudService.cancelarSolicitud({idSolicitud:$rootScope.solicitudJson.idSolicitud});
									$scope.reiniciaCotizacion();																			
								},function(error){
									console.log("No hacer nada");								
								}
						 );
				}
					
				$rootScope.seConsultoBuro=null;
				
			}
		};


		
		function loadProgressbar()
		{
			if(!generalService.productosQuickFixes())
				porcentajeQF = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje;
					                                                    
			  prog( "#progressbar_opDatosPersonales",	parseInt(porcentajeQF) );
			  prog( "#progressbar_opDatosHogar", 		parseInt($rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje) );
			  prog( "#progressbar_opDatosEmpleo", 		parseInt($rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje) );
			  prog( "#progressbar_opIngresosGastos",	parseInt($rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje) );
			  prog( "#progressbar_opObligado", 			parseInt($rootScope.solicitudJson.avales[0].porcentaje) );
			  prog( "#progressbar_opReferencias",		parseInt($rootScope.solicitudJson.referencias.porcentaje) );
			  prog( "#progressbar_opExpediente", 		parseInt($rootScope.solicitudJson.documentos.porcentaje) );
			  prog( "#progressbar_opContratos", 		parseInt($rootScope.solicitudJson.contratos.porcentaje) );
			
			  if(MUESTRA_TERMOMETRO)
				  $scope.termometroManager();
			  		  
			  var json = $rootScope.solicitudJson.cotizacion;
			  
			  $scope.avanceDatosPersonales = json.clientes[0].porcentaje;  
			  $scope.prestamo = 2000; 
			  $scope.prestamo = 1000;
			  $scope.pagosreq = 13;
			  $scope.abonos = 204;
			  $scope.avance = "0 %";
			  $scope.avanceDatosPersonales = (generalService.datosPerPorcent).toFixed(0) + " %";
			  $scope.avanceaval = (generalService.avalPorcent).toFixed(0) + " %";
			  $scope.avancehogar = (generalService.datosHogarPorcent).toFixed(0) + " %";
			  $scope.avenceEmpleo = (generalService.datosEmpleoPorcent).toFixed(0) + " %";
			  $scope.avancingresos = (generalService.IngresosGastosPorcent).toFixed(0) + " %";
			  $scope.avancreferencias = (generalService.referenciasPorcent).toFixed(0) + " %";
			  $scope.avancexpedientes = (generalService.expedientesporcent).toFixed(0) + " %";
			  $scope.pagopuntual = 184;
			  $scope.ahorro  = 20;
			  
			  if( generalService.isDefined($rootScope.porcentajes) ){
				  
				  $rootScope.porcentajes.secciones[0].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje; 
				  $rootScope.porcentajes.secciones[1].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje;
				  $rootScope.porcentajes.secciones[2].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje;
				  $rootScope.porcentajes.secciones[3].porcentaje = $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje;
				  $rootScope.porcentajes.secciones[4].porcentaje = $rootScope.solicitudJson.avales[0].porcentaje;
				  $rootScope.porcentajes.secciones[5].porcentaje = $rootScope.solicitudJson.referencias.porcentaje;
				  $rootScope.porcentajes.secciones[6].porcentaje = $rootScope.solicitudJson.documentos.porcentaje;
				  $rootScope.porcentajes.secciones[7].porcentaje = $rootScope.solicitudJson.contratos.porcentaje;
				  
				  if( $rootScope.solicitudJson.avales[0].bloqueado != 0 ){/* SE VALIDA BLOQUEO DE AVAL */
					  $rootScope.porcentajes.secciones[4].porcentaje = "100";
				  }
				  
				  if( $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].bloqueado != 0 ){/* SE VALIDA BLOQUEO DE EMPLEO */
					  $rootScope.porcentajes.secciones[2].porcentaje = "100";
				  }
				  
				  $scope.menuList[6].porcentaje = $rootScope.porcentajes.secciones[7].porcentaje;
			  }			  
			  			  
			  
			  
			  generalService.setRespaldo($rootScope.solicitudJson);
			  			  
		};/* END LOAD PROGRESSBAR FUNCTION */
		
		$scope.threadSlider = function( idSlider, doFunction, isFirstTime )
		{											
			
			var stopInterval = null, intervalCont = 1;
			
			var verifySlider = function(){
				var sliderVal = $( "#" + idSlider ).slider( "value" );
				return !(isNaN( sliderVal ));
			};
							
			var trySlider = function(){
									
				if( verifySlider() ){
					
					$interval.cancel( stopInterval )
					
					if( doFunction && doFunction != null )
						doFunction();
					
				}else if( intervalCont == 100 )
					$interval.cancel( stopInterval )
				else{
					
					intervalCont++;
					
					if( isFirstTime )
						if( doFunction && doFunction != null )
							doFunction();
					
				}
			};
			
			stopInterval = $interval( trySlider, 100 );
									
			
		};/* END THREAD SLIDER FUNCTION */
		
		$scope.termometroManager = function()
		{
			
			var fooCallback = function( uiValue ){
		 			
				/* BUG JQUERY TIMEOUT */
		 		$timeout( function(){ 
		 				angular.element( document.getElementById( "ochoPasos" ) ).scope().uiSlider( uiValue );
		 			}, 0
		 		);
		 			
			};
			
			if( $scope.muestraTermometro && !$scope.muestraRefresh ){
				
				var plazos = generalService.getPlazos( $rootScope );
				  
				var arrayMontos = plazos.map( function(d){
					return d['monto'];
				});
				
				arrayMontos = mergeSort(arrayMontos);
				
				var monto = parseInt($rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto);
				var index = arrayMontos.indexOf( monto );

				var _min = Math.min.apply( 0, arrayMontos );
				var _max = Math.max.apply( 0, arrayMontos );
								
				if( index == -1 )
					monto = _max;
				  
				$scope.minMonto = _min;
				$scope.maxMonto = _max;
				
				var step=500;
				var len = arrayMontos.length;
				
				if( arrayMontos[0] )
					if( arrayMontos[1] )
						step = arrayMontos[1]-arrayMontos[0];
				
				var fnCallBack = function(){
					sliderVertical( _min , _max, step, monto, 
							'.amountVertical div', '.listaDocumentos', arrayMontos, fooCallback );
				};
				
				$scope.threadSlider( 'sliderVertical', fnCallBack, true );
				
			}//END IF MUESTRA TERMOMETRO && MUESTRA REFRESH
			
		};/* END TERMOMETRO MANAGER FUNCTION */
		
		function mergeSort(items)
		{
			if (items.length < 2) {
		        return items;
		    }

		    var middle = Math.floor(items.length / 2),
		    left = items.slice(0, middle),
		    right = items.slice(middle);

		    return merge(mergeSort(left), mergeSort(right));
		}

		function merge(left, right)
		{
			var result  = [],
	        il = 0,
	        ir = 0;

			while( il < left.length && ir < right.length ){
	        	if (left[il] < right[ir])
	            	result.push(left[il++]);
	        	else 
	        		result.push(right[ir++]);
	    	}

		    return result.concat(left.slice(il)).concat(right.slice(ir));
		    
		}
				
		function limpiar_clasePlazo()
		{
			
			$('.requisitos ul li > a').each(function(){
	 			$( this ).removeClass('active');
	 	    });
			
		};/* END LIMPIAR CLASE PLAZO FUNCTION */
		
		//FUNCION DEL ANTIGUO TERMOMETRO
		$scope.uiSlider = function ( valorSlider )
		{		

			var fnCallBack = function(){								

				limpiar_clasePlazo();
				
				$scope.listaPlazos = TermometroController.calculaPlazos( valorSlider, $scope );				
				
				var plazo = $rootScope.solicitudJson.cotizacion.plazo;
				var index = $scope.listaPlazos.indexOf( plazo );
				
				$scope.deshabilitarRecalcular = true;
				
				if( index != -1 ){
					
					TermometroController.muestraCondicion( plazo, valorSlider, $scope ); 
					
					$timeout( function(){
						$('.requisitos ul li > a').each(function(){
							if( parseInt($(this).text()) == parseInt(plazo) ){
								$( this ).addClass('active'); 
								return;
							};
						});
					}, 10 );
					
				}
				
				validaCreditoInmediato( valorSlider, false);
								
			};
			
			$scope.threadSlider( 'sliderVertical', fnCallBack, false );
				 		
	 	};/* END UISLIDER FUNCTION */
	 	
	 	//FUNCION DEL ANTIGUO TERMOMETRO
	 	$scope.condicionesTermometro = function( valor, ui ){	 		 		 	
	 		
	 		var fnCallBack = function(){
	 			
	 			var sliderVal = $( "#sliderVertical" ).slider( "value" );
	 			limpiar_clasePlazo();
	 			
	 			$( ui.target.parentNode ).addClass('active');
	 			TermometroController.muestraCondicion( valor, sliderVal, $scope );

	 		};
	 		
	 		$scope.threadSlider( 'sliderVertical', fnCallBack, false );
	 			 		
	 	};/* END CONDICIONES TERMOMETRO FUNCTION */
	 	
	 	//FUNCION DEL ANTIGUO TERMOMETRO
	 	$scope.recalcularMonto = function()	 		 	
	 	{	 			 		
			
	 		
	 		$scope.comprobanteHandler();
	 		
	 		var sliderVal = $( "#sliderVertical" ).slider( "value" );
	 		var plazo;
	 		var continuarValidacion = true;

	 		$scope.muestraAlertaBuro = false;
	 		
	 		$('.requisitos ul li > a').each(function(){
		 		if( $( this ).hasClass('active') ){
		 			plazo = parseInt( $(this).text() ); 
		 			return;
		 		};
		 	});
	 		
	 		var internalFn = function(){
	 			if( plazo == $rootScope.solicitudJson.cotizacion.plazo ){
						if( sliderVal == $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto ){
 						continuarValidacion = false;
 						$scope.muestraAlertaBuro = true;
 					}else{
 						continuarValidacion = true;
 						$scope.muestraAlertaBuro = false;
 						$rootScope.solicitudJson.banderaOfertaCP = 0;
 					}
 		 		}
	 		};
	 		
	 		switch( $rootScope.buroConditional ){
	 			case BURO_RECALCULAR_PLAZO:
	 					internalFn()
					break;
				case BURO_AUTORIZADO_PORCOMPROBAR:
						continuarValidacion = true;
					break;
				case BURO_AUTORIZADO_SCORE:
				case RESPONSE_ORIGINACION_CODIGO_EXITO:
						internalFn()
					break;
	 		}// END SWITCH BUROCONDITIONAL
	 			 			 		
	 		if( $scope.muestraCondicion && continuarValidacion ){
	 			if( angular.equals($scope.condiciones.tipoComprobante, "") ){
	 				$scope.deshabilitarRecalcular = true;
	 			}else{
	 				if( angular.equals($scope.condiciones.tipoComprobante, "ingresos") ){
	 					$rootScope.solicitudJson.banderaIngresos = 1;
	 					$rootScope.solicitudJson.banderaSolidario = 0;
	 				}else{
	 					if($rootScope.solicitudJson.banderaOfertaCP==1 && $rootScope.solicitudJson.banderaIngresos==1)
	 						//$rootScope.solicitudJson.banderaSolidario = 1;
	 						$rootScope.solicitudJson.banderaSolidario = 0;  //ya no se pide Coacreditado
	 					else{
		 					$rootScope.solicitudJson.banderaIngresos = 0;
		 					//$rootScope.solicitudJson.banderaSolidario = 1;
		 					$rootScope.solicitudJson.banderaSolidario = 0;  //ya no se pide Coacreditado
	 					}
	 				}
	 			}
	 		}else{
	 			if( $rootScope.solicitudJson.banderaOfertaCP == 0 ){
	 				$rootScope.solicitudJson.banderaSolidario = 0;
	 				$rootScope.solicitudJson.banderaIngresos = 0;
	 			}
	 			TermometroController.filtrosOferta($scope);
	 		}
	 		
	 		if( continuarValidacion ){	 			
	 			validaCreditoInmediato(sliderVal, true);
	 			
	 			$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = sliderVal;
 				$rootScope.solicitudJson.cotizacion.plazo = plazo;
 				$scope.calculaMonto(); 				 				 				 				
 				
 			}
	 		
	 	};/* END RECALCULAR MONTO FUNCTION */
	 	
	 	
	 	
	 	
		
		function prog( progress, value )
		{
			$( progress ).progressbar({ value: value });
			$( progress ).prev().find('.porcentaje').text(value + "%");
		}/* END PROG FUNCTION */
		
		$scope.validarBuroModatelas=function(tercerosModatelasCita, tercerosModatelasLiberar){
			if(generalService.validaConsultaBuro( $rootScope.solicitudJson)){
				var si = function() {
					$scope.intentarBuro(tercerosModatelasCita, tercerosModatelasLiberar);
				};
	
				var no = function() {
					console.log("no hacer nada");
				};
				var cuerpoDlg=["No se ha podido consultar a buró. ¿Desea intentarlo nuevamente?"];
				
				$rootScope.seConsultoBuro=null;
				$rootScope.messageConfirm(
					"Notificación",
					cuerpoDlg,
					"Si", "No", "bgAzul",
					"btn azul", "btn gris",
					null, no,
					si);
				return true;
			}else
				return false;
		};
// I-MODIFICACION TDC (SERVICIO DE VISITA ASESOR TDC)		
		$scope.enviaVisitaAsesorTarjeta = function(){
			/*Cambio Ninja para el Buen Fin 2019, quitar después\*/
			if($rootScope.solicitudJson.campana.toUpperCase() != 'NVOPREAP'){
			/*Cambio Ninja para el Buen Fin 2019, quitar después\*/
				var x = { idSolicitud: $rootScope.solicitudJson.idSolicitud};
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				tarjetaService.evaluacionCita(x).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var responseJson = JSON.parse(data.data.respuesta);		
								if(responseJson.codigo == 2){
									$rootScope.solicitudJson = responseJson.data;
									$scope.enviaVisitaAsesor();
								}else
									$scope.enviaVisitaAsesor();
							}else{
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								$rootScope.message("Siete Pasos",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
							}
						}, function(error){
							$rootScope.waitLoaderStatus = LOADER_HIDE; 
							validateService.error(error);
						}
				);
				
			} else {
				$scope.obtenerVerificacion();
			}
		}
		
		$scope.liberarTDC = function(){
			$scope.buildMenuList();
			$scope.seccionesNoInmediatas();
			
			if($scope.llenaSeccion){
				
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				
				var jsonSolicitud = {
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						idSeguimiento: STATUS_SOLICITUD.autorizada.id,
						marca: STATUS_SOLICITUD.autorizada.marca.sinLiberar
				};
				
				solicitudService.actualizarSolicitud(jsonSolicitud).then(
						function(data) {
							
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var j = JSON.parse(data.data.respuesta);	
								
								if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){	
									
										$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.autorizada.id;
										$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.sinLiberar;
										$scope.menuList= [];
										$scope.showPage= false;
										$scope.init();
								}else{
									$rootScope.message("Aviso", ["Ocurrió un problema al actualizar la solicitud, favor de volver a reintentar"], "Aceptar");
								}
								
							}else{
								$rootScope.message("Aviso", ["Ocurrió un problema al actualizar la solicitud, favor de volver a reintentar"], "Aceptar");
							}
							
						}, function(error) {
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$rootScope.message("Aviso", ["Ocurrió un problema al actualizar la solicitud, favor de volver a reintentar"], "Aceptar");
						}
				);
			}
		}
// F-MODIFICACION TDC (SERVICIO DE VISITA ASESOR TDC)				
		$scope.enviaVisitaAsesor = function(paso){
			$scope.buildMenuList();
			$scope.seccionesNoInmediatas();	
			
			if($rootScope.requiereObligado && respuestaSeccionOS.porcentajeTotal != 100){
				$scope.menuList[7].showAlerta = true;
				$scope.menuList[7].showMessageAlert = true;
				$scope.menuList[7].messageAlert="Es necesario tener al 100% la sección.";
			} else{
				if($scope.existeObligadoSolidario){
					
					if( !generalService.isEmpty($rootScope.solicitudOSJson.folioCallCenter)  &&  $rootScope.solicitudOSJson.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.SIN_RESPUESTA ){
						$scope.consultaFolioCUOS(paso);
						
					}else{
						/** INICIA_OS-FLUJO COACREDITADO **/			
						$scope.porcentajeObligado();
						/** Si existe Coacreditado activar la bandera para redirigir a las vista de visita del Coacreditado **/
						if($rootScope.solicitudOSJson && $rootScope.solicitudOSJson.existeCita != 1 && ($rootScope.solicitudOSJson.idSeguimiento == 5 || $rootScope.solicitudOSJson.idSeguimiento == 3 || $rootScope.solicitudOSJson.idSeguimiento == 185) && $rootScope.solicitudOSJson.idSolicitud){
							$rootScope.termometroHandlerOS = true;
							$scope.muestraAlertaBuro = false;
							$rootScope.buroConditional = 2;
							$rootScope.agendarCitaOSDisponible = true;
						}
						/** TERMINA_OS-FLUJO COACREDITADO **/
						
						if( !generalService.isEmpty($rootScope.solicitudJson.folioCallCenter)  &&  $rootScope.solicitudJson.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.SIN_RESPUESTA ){
							$scope.consultaFolioCU();
						}else{
							solicitudService.validaFolioCallCenter("", $rootScope.solicitudJson, 1)
							.then(
									function(data){
										if(data == null)
											$scope.enviaVisitaAsesorContinua(paso);
										else
											generalService.locationPath(data);							
									},function(error){																	
									}
							);	
						}
					}
				} else{
					if( !generalService.isEmpty($rootScope.solicitudJson.folioCallCenter)  &&  $rootScope.solicitudJson.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.SIN_RESPUESTA ){
						$scope.consultaFolioCU();
					}else{
						solicitudService.validaFolioCallCenter("", $rootScope.solicitudJson, 1)
						.then(
								function(data){
									if(data == null)
										$scope.enviaVisitaAsesorContinua(paso);
									else
										generalService.locationPath(data);							
								},function(error){																	
								}
						);	
					}
				}				
			}
			
			
		};/* END VISITA ASESOR FUNCTIOn */
		
		
		
		$scope.validaCita = function(){
			
			if( !generalService.isEmpty($rootScope.solicitudJson.folioCallCenter)  &&  $rootScope.solicitudJson.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.SIN_RESPUESTA ){
				modalService.alertModal("Call Center", ["Aún no es posible generar la cita del cliente debido a que el Call Center no ha dado respuesta, favor de espera unos minutos y vuelve a intentarlo."]);
				return false;
			}else{
				solicitudService.validaFolioCallCenter("", $rootScope.solicitudJson, 1)
				.then(
						function(data){
							if(data == null)
								$scope.enviaVisitaAsesorContinua(3);
							else
								generalService.locationPath(data);							
						},function(error){																	
						}
				);	
			}				
			
		};
		
		
		$scope.validaCitaOS = function(paso){
			if( !generalService.isEmpty($rootScope.solicitudOSJson.folioCallCenter)  &&  $rootScope.solicitudOSJson.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.SIN_RESPUESTA ){
				modalService.alertModal("Call Center", ["Aún no es posible generar la cita del cliente debido a que el Call Center no ha dado respuesta, favor de espera unos minutos y vuelve a intentarlo."]);
			}else{
				solicitudService.validaFolioCallCenterOS("", $rootScope.solicitudOSJson, 1)
				.then(
						function(data){
							if(data == null)
								$scope.enviaVisitaAsesor(paso);
							else
								generalService.locationPath(data);
						},function(error){
							modalService.alertModal("Call Center", ["Aún no es posible generar la cita del cliente debido a que el Call Center no ha dado respuesta, favor de espera unos minutos y vuelve a intentarlo."]);
						}
				);	
			}				
			
		};
		
		$scope.enviaVisitaAsesorContinua = function(paso){
			if($rootScope.solicitudJson.campana == "NVOPREAP" && $rootScope.solicitudJson.folioCallCenter != "" && $rootScope.solicitudJson.respuestaCallCenter > 0 && $rootScope.solicitudJson.banderaOfertaCP == 0){
				buroService.consultaBuro("bgNaranja", "btn gris","btn naranja", null, null,1, null);
			}else{
				if( $rootScope.termometroHandler == BURO_RESPUESTAWS_ERROR ){
					
					if(generalService.validarMostarTermometro($rootScope.solicitudJson)){
						$scope.muestraAlertaNuevoBuro=true;
						$scope.muestraMensajeNuevoBuro=true;
					    $scope.mensajeNuevoBuro="Es necesario reintentar para poder continuar"
						$scope.llenaSeccion = false;
					}else if(generalService.isProdModatelas($rootScope)){
						if($scope.validarBuroModatelas(true,null));
							return false;
					}
				}else if( $scope.muestraAlertaBuro && MUESTRA_TERMOMETRO){
					$scope.llenaSeccion = false;
					TermometroController.showMessageBuro( $scope );
				}else if(!$scope.validaContinuarNuevoCotizador() && MUESTRA_NUEVO_COTIZADOR)
					$scope.llenaSeccion = false;
				
				/*
				 * Se agrega un OR para lograr el efecto de que es generidad. El código celular sólo era obligatorio para 
				 * canales externos. Si la bandera de liberacionSinCodigo está en true para todas las sucursales, entonces
				 * va a entrar a este caso.
				 */
				if($rootScope.consultaFuncionalidad.liberacionSinCodigo) {
					// No se ha certificado con el código celular.
					if($rootScope.solicitudJson.envioCelular != 1) {
						// La sucursal permite liberación sin código.
						if($rootScope.consultaFuncionalidad.liberacionSinCodigo) {
							// ¿Ya están llenas todas las secciones?
							if($scope.llenaSeccion && paso == undefined) {
								// Se debe preguntar si recibió el código.
								modalService.confirmModal("Código de Seguridad", 
										["¿Tu cliente recibió su código de seguridad?"], "No", "Sí").then(
									function(exito) {
										console.log("Sí recibió el código.");
										
										// Se le muestra el modal para validar el código.
										modalService.codigoModal(null, 777, CLIENTE.id).then(
						  					function(exito) {
						  						console.log("Validar");
						  											  						
						  						// Después de esto se debe continuar con las validaciones pendientes.
						  						validacionesExtra(paso);
						  					}, function(error) {
						  						console.log("Validar más tarde.");
						  						
						  						// Se realizan las validaciones posteriores.
						  						validacionesExtra(paso);
						  					}
							  			);
									}, function(error) {
										console.log("No recibió el código.");
										
										var hayReenvio = smsOrCall();
										
										if(hayReenvio != -1) {
											// Se intenta reenviar el código celular.
											var tipoCodigo = { 
												idDestino: hayReenvio, 
												destino: $rootScope.solicitudJson.cotizacion.clientes[0].celular, 
												celular: $rootScope.solicitudJson.cotizacion.clientes[0].celular,
												celularAnterior: $rootScope.solicitudJson.cotizacion.clientes[0].celular,
												nombreCte: $rootScope.solicitudJson.cotizacion.clientes[0].nombre,
												idSolicitud: $rootScope.solicitudJson.idSolicitud,
												idPersona: $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
												tipoPersona: CLIENTE.id,
												codigoAnterior: $rootScope.solicitudJson.codigoCelular,
												idPais: $rootScope.solicitudJson.idPais,
												idSucursal: $rootScope.solicitudJson.idSucursal,
												idCanal: $rootScope.solicitudJson.idCanal,
												generaCodigo: 0
											};
											
											// Se consume el reeenvío.
											loginService.getCode(tipoCodigo).then(
												function(exito) {
													if(exito.data.codigo == RESPONSE_CODIGO_EXITO) {
														var validaService = JSON.parse(exito.data.respuesta);
	
														if(validaService.error == false) {									
															switch (tipoCodigo.idDestino) {										
																case 1:												
																	$rootScope.solicitudJson.cantidadReenviosCelular++;											
																	break;
																case 3:
																	$rootScope.solicitudJson.cantidadReenviosLlamada++;
																	break;
																default: // Nothing yet.
															}
															
															// Se guarda el nuevo código celular
															$rootScope.solicitudJson.codigoCelular = exito.data.descripcion;
															
															generalService.setRespaldo($rootScope.solicitudJson);
														}
													}
												}, function(error) {} // Nada que hacer.
											);
										}
										
										// Se realizan las validaciones posteriores.
										validacionesExtra(paso);
									}
								);
								
								return;
							}
						} else {
							$scope.llenaSeccion = false;				
							$scope.muestraAlertaCodigo = true;
							$scope.muestraMensajeCodigo = true;
							$scope.mensajeCodigo = "Es necesario validar el código celular";
							
							var jsonCodigo = {
								tipoPersona: CLIENTE.id,
							};
							
							if( esTerminado() )
								$scope.validaCodigo( null, 0, jsonCodigo, true );
							
							if( $rootScope.solicitudJson.avales[0].envioCelular != 1 && $rootScope.solicitudJson.envioCelular == 1 
									&& $rootScope.solicitudJson.banderaSolidario == 1 && $rootScope.solicitudJson.avales[0].presencial == 1 ) {
								$scope.llenaSeccion = false;				
								$scope.muestraAlertaCodigo = true;
								$scope.muestraMensajeCodigo = true;
								$scope.mensajeCodigo = "Es necesario validar el código celular del Coacreditado";
								
								var jsonCodigo = {
									tipoPersona: AVAL.id,
								};
								
								if( esTerminado() )
									$scope.validaCodigo( null, 0, jsonCodigo, true );
							}
						}
					}
				}
				
				validacionesExtra(paso);
			}
		};/* END VISITA ASESOR CONTINUA FUNCTION */
		
		function validacionesExtra(paso) {
			
			if(MUESTRA_TERMOMETRO) {
				if(generalService.validarMostarTermometro($rootScope.solicitudJson)) {
					$scope.validaCambioBuro();
				}
			}
			
			if($scope.llenaSeccion) {
				if(paso == 2 || paso == 3) {
					
/** INICIA_OS-FLUJO COACREDITADO **/
					
					/** Enviamos la agenda de la cita para el Coacreditado solo si exites Coacreditado de lo contraio continuamos con el flijo normal **/
//					if($rootScope.agendarCitaOSDisponible && $rootScope.solicitudOSJson && $rootScope.solicitudOSJson.idSolicitud != ""){
//						generalService.locationPath(generalService.whichOneVisit());
						
/** TERMINA_OS-FLUJO COACREDITADO **/
						
//					}else{
//						generalService.locationPath(generalService.whichOneVisit());
//					}
					validaAltaCU(0);
				}else{
					$scope.validaEncoladosEnGenerarCita();
				}
			}
		}
				
		/**
		 * Utilería que verifica si debe enviarse llamada o mensaje.
		 * @returns 1, si debe ser SMS. 3, si debe ser llamada. -1 en caso de que no deba enviarse
		 * ni mensaje ni llamada.Esto se usa como parámetro para el consumo del servicio de 
		 * reenvío.
		 */
		function smsOrCall() {
			var maxSMS = $rootScope.consultaFuncionalidad.intentosMaximoReenvioSMS;
			var maxCall = $rootScope.consultaFuncionalidad.intentosMaximoReenvioCall;

			// Ya se alcanzó (o supeó) el máximo de reenvíos celular.
			if($rootScope.solicitudJson.cantidadReenviosCelular >= maxSMS) {
				// Aún quedan intentos de llamada.
				if($rootScope.solicitudJson.cantidadReenviosLlamada < maxCall) {
					return 3;
				}				
			} else { // Aún hay algunas por quemar.
				return 1;
			}

			return -1;
		}
		
		$scope.executeActionResponse = function(ipadResoponse){
			console.log("executeActionResponse "+JSON.stringify(ipadResponse));
		};
		
		
		$scope.seccionesNoInmediatas = function()
		{
			$scope.llenaSeccion = true;
			var sectionAlert = false;
			var canal = $rootScope.sucursalSession.idCanal;						
			var avalBloqueado = $rootScope.solicitudJson.avales[0].bloqueado==0?false:true;
			var avalPresente = $rootScope.solicitudJson.avales[0].presencial == AVAL.presencial.NO_PRESENTE ? false:true;						
			
			for( var i = 0; i < $scope.menuList.length; i++ ){
													
								
				var path = $scope.menuList[i].path;
				
				if( /*$scope.validarCanal(canal)*/ generalService.isCanalInterno(canal) &&  path != '/datosPersonales'  &&  path != '/datosHogar'  &&  path != '/expediente' &&  path != '/referencias' &&  path != '/ingresosGastos' &&  path != '/datosEmpleo'){
					if(generalService.validardiaDePago())
						$scope.validaContratosEncolados();
					continue;
				}
					
				
				if ( $scope.menuList[i].porcentaje != 100  &&  $scope.menuList[i].bloqueo == 0 
						&& $scope.menuList[i].show) {										
					
					
						switch( path ){
							case '/datosHogar':
									sectionAlert = true;
								break;
							case '/datosPersonales':
									sectionAlert = true;
								break;
							case '/referencias':
									sectionAlert = true;
							break;
							case '/datosEmpleo':
									sectionAlert = true;
									break;
							case '/ingresosGastos':
									sectionAlert = true;
							break;
							case '/expediente':
									sectionAlert = $scope.searchID( IDENTIFICACION_OFICIAL.id );
									if( generalService.isCanalExterno(canal)  &&  !sectionAlert  &&  !avalBloqueado  &&  avalPresente){
										sectionAlert = $scope.searchID( IDENTIFICACION_OFICIAL_AVAL.id );
										if(sectionAlert)
											$scope.menuList[i].messageAlert =  'Es necesario digitalizar la Identificación Oficial del Coacreditado';
									}
								break;
							case '/aval':							
								if(avalPresente)
									sectionAlert = true;																																														
								break;
							default:
								sectionAlert = true;							
						}
						
						if( sectionAlert ){
							$scope.menuList[i].showAlerta = true;
							$scope.llenaSeccion = false;
						}
					
					
				}							
				
				sectionAlert = false;
			}// END FOR MENULIST			
			
			
		};/* END SECCIONES NO INMEDIATAS FUNCTION */
		
		var esTerminado = function()
		{
			
			var terminado = true;
			
			var porcentajeNoCompletado = $scope.menuList.map( function( arrayData ){
				if( arrayData['porcentaje'] != 100 && arrayData['bloqueo'] == 0 )
					return true;
				else
					return false;
			}).indexOf( true );
			
			if( porcentajeNoCompletado != -1 )
				terminado = false;
			
			if( !$scope.searchID( IDENTIFICACION_OFICIAL.id ) )
				terminado = true;
						
			return terminado; 
			
		};/* END ES TERMIADO FUNCTION */
		
		$scope.validaInmediato = function()
		{
			$scope.llenaSeccion = true;
			for(var l = 0; l < $scope.menuList.length; l++){
				if ($scope.menuList[l].porcentaje != 100 && $scope.menuList[l].bloqueo == 0){
					$scope.menuList[l].showAlerta = true;
					$scope.menuList[l].showMessageAlert = false;
					$scope.llenaSeccion = false;
				}
			}	
		};/* END VALIDA INMEDIATO FUNCTION */
		
		$scope.searchID = function(documentoId)
		{
			
			var lenDoc = $rootScope.solicitudJson.documentos.documento.length;
			var index = -1;
			var returnStatus = false;
			
			if( lenDoc > 0 ){
				
				var data = $rootScope.solicitudJson.documentos.documento;
				
				index = data.map( function(d){
					return d['idDocumento'];
				}).indexOf( documentoId ); /* IDENTIFICACION */
				
				if( index >= 0 ){
					returnStatus = data[index].status == STATUS_CAPTURADO ? 
							false : data[index].status == STATUS_VERIFICADO ?
							false : data[index].status == STATUS_ENCOLADO_IPAD ?
							false : data[index].status == STATUS_VALIDADO ? false : true;  
				}
								
			}
			
			return returnStatus;
			
		};/* END SEARCH ID FUNCTION */
		
		$scope.reiniciaCotizacion = function()
		{									
			generalService.cleanRootScope($rootScope);
			generalService.buildSolicitudJson($rootScope, null);
			
			generalService.locationPath("/simulador");
			
		};/* END REINICIA COTIZACION FUNCTION */
		
		$scope.condicionesLiberacion = function()
		{
			//Bandera que permitirá continuar con el proceso de Liberación una vez que estén completas todas las secciones
			$rootScope.pasoLiberacion = (($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.autorizadoMesa) && $rootScope.seccionCompleta) ? true:false;
			$scope.estadoSolicitud = $rootScope.solicitudJson.idSeguimiento;
			$scope.marcaSolicitud = $rootScope.solicitudJson.marca;
			$scope.liberacion = "default";
			
			if( $scope.estadoSolicitud == STATUS_SOLICITUD.generada.id || 
				($scope.estadoSolicitud == STATUS_SOLICITUD.autorizada.id /* <--CON EL TIEMPO QUITAR*/
				 	&& $scope.marcaSolicitud == STATUS_SOLICITUD.preautorizada.marca.fico) || /* <--CON EL TIEMPO QUITAR*/
				$scope.estadoSolicitud == STATUS_SOLICITUD.malZonificada.id ||
				($scope.estadoSolicitud == STATUS_SOLICITUD.preautorizada.id
					&& $rootScope.solicitudJson.existeCita == 0) ){
			
				var estadoZonificacion = generalService.getDataBridge();
				
				if( !generalService.isEmpty( JSON.stringify(estadoZonificacion) ) )
					if( estadoZonificacion.esMalZonificada )
						$scope.terminoSolicitud = true;
				if(generalService.validarMostarTermometro($rootScope.solicitudJson)){
					if( generalService.validaConsultaBuro( $rootScope.solicitudJson ) && $rootScope.solicitudJson.banderaSeguro==0){
						$scope.muestraTermometro = true;
					}else
						$scope.muestraTermometro = false;
				}
				$scope.liberacion = "default";
			}
			
			if( ($scope.estadoSolicitud == STATUS_SOLICITUD.autorizada.id || $scope.estadoSolicitud == STATUS_SOLICITUD.mesaControl.id 
					&& ($scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.expValGerente ||
							$scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.autorizadoMesa ||
							$scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.sinLiberar ||
							$scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.ejecutivo ||
							$scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.expRechazado ||
							$scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.clienteVerdeJVC ||
							$scope.marcaSolicitud == STATUS_SOLICITUD.mesaControl.marca.condicionadoMesa
						)) ||
				($scope.estadoSolicitud == STATUS_SOLICITUD.condicionada.id 
				   	&& $rootScope.solicitudJson.idCondicion == STATUS_SOLICITUD.condicionada.idCondicion.expIncompleto) ||	
				($scope.estadoSolicitud == STATUS_SOLICITUD.preautorizada.id
				   	&&	$rootScope.solicitudJson.existeCita == 1) ){/* PENDIENTE POR REVISAR ESTADO INACTIVO*/
				$scope.liberacion = "liberar";
				$scope.terminoSolicitud = true;
				if(generalService.validarMostarTermometro($rootScope.solicitudJson) && $rootScope.solicitudJson.banderaSeguro==0 &&
						($scope.marcaSolicitud != STATUS_SOLICITUD.autorizada.marca.autorizadoMesa || $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.autorizadoMesa && $rootScope.solicitudJson.ofertaSeleccionadaMCO == 1))
					$scope.muestraTermometro = true;
				else
					$scope.muestraTermometro = false;
			}
			
			if( $scope.estadoSolicitud == STATUS_SOLICITUD.autorizada.id 
					&& ($rootScope.pasoLiberacion ||
							$scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.expCompleto) ||
							$scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.procesoBateriaBuro){
				$scope.liberacion = "surtir";
				$scope.terminoSolicitud = true;
				$scope.muestraTermometro = false;
			}
						
			if( $scope.estadoSolicitud == STATUS_SOLICITUD.autorizada.id 
					&& $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.sinTaz ){
				$scope.liberacion = "surtirSinTaz";
				$scope.terminoSolicitud = true;
				$scope.muestraTermometro = false;
			}
			
			/* OFERTA 30 Dias*/
			if($scope.estadoSolicitud == STATUS_SOLICITUD.autorizada.id && $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.pendienteDigitalizar){
				$scope.terminoSolicitud = true;
				$scope.liberacion = "oferta30DiasAplicarOfertaIn";
				$scope.muestraTermometro = false;
			}
			
			if($scope.estadoSolicitud == STATUS_SOLICITUD.autorizada.id && $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.docDigitalizado){
				$scope.terminoSolicitud = true;
				$scope.liberacion = "oferta30DiasAplicarOfertaHa";
				$scope.muestraTermometro = false;
			}
			
			if($scope.estadoSolicitud == STATUS_SOLICITUD.autorizada.id && $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.docPendValidar){
				$scope.terminoSolicitud = true;
				$scope.liberacion = "oferta30DiasFinalizarOfertaIn";
				$scope.muestraTermometro = false;
			}			
		
			if($scope.estadoSolicitud == STATUS_SOLICITUD.autorizada.id && $scope.marcaSolicitud == STATUS_SOLICITUD.autorizada.marca.DocValidado){
				$scope.terminoSolicitud = true;
				$scope.liberacion = "oferta30DiasFinalizarOfertaHa";
				$scope.muestraTermometro = false;
			}
//I MODIFICACION SIPA (NO MOSTRAR BOTON DE VOLVER A COTIZAR)
			if (($rootScope.productosSIPA($rootScope.solicitudJson.idProducto)	&& $rootScope.promocionCampanas($rootScope.solicitudJson.campana)) || $rootScope.campanaNvoPreaprob($rootScope.solicitudJson.campana || ($rootScope.consultaFuncionalidad.habilitarPDRCreditoEnEfectivo && $scope.esRescate && $rootScope.solicitudJson.idSeguimiento != STATUS_SOLICITUD.autorizada.id))){
				$scope.muestraBoton = false;
			}else{
				$scope.muestraBoton = true;
			}
//F MODIFICACION SIPA (NO MOSTRAR BOTON DE VOLVER A COTIZAR)
			
		};/* END CONDICIONES LIBERACION FUNCTION */
		
		$scope.liberarGerencia = function(){
			$scope.continuaLiberarGerencia( true );
		};		
		
		$scope.recuperaSolicitud = function(ipadResponse){	
			$rootScope.loggerIpad("recuperaSolicitud", null, ipadResponse);
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.getSolicitud( $rootScope.solicitudJson.idSolicitud ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;

					if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
						if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
	    					var responseJson = JSON.parse(data.data.respuesta);		
		    				$rootScope.solicitudJson = responseJson.data;
		    				$scope.validaEdicionSecciones();
		    				$scope.envioBack=false;
		    				$scope.continuaLiberarGerencia( true );
						
						}else if(j.codigo == RESPONSE_CODIGO_ERROR_ID){
							$rootScope.message("Aviso", [j.descripcion], "Aceptar", $scope.backPath.root, "bgCafe", "cafeD");
						}						
					}else
						$rootScope.message("Siete Pasos",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
					
				}, function(error){
					$rootScope.waitLoaderStatus = LOADER_HIDE;																							
				}
			);
			
		}
		
		$scope.validaDocumentosGerencia=function(searchFlag,validaEncolados){
			
			for( var i = 0; i < $scope.menuList.length; i++ ){
				
				if( $scope.menuList[i].bloqueo == 0 && searchFlag ){
					
					var path = $scope.menuList[i].path; 
					
					if( path == '/expediente' )
						$scope.searchDocuments( $scope.menuList[i] ,validaEncolados);
				
				}
						
				if ( $scope.menuList[i].porcentaje != 100 && $scope.menuList[i].bloqueo == 0 
						&& $scope.menuList[i].show) {
				
					var path = $scope.menuList[i].path; 
										
					if( path == '/expediente' ){
						$scope.searchDocuments( $scope.menuList[i] );
					}
					
					$scope.menuList[i].showAlerta = true;
					$scope.llenaSeccion = false;
					
				}
				
			}
		}
		
		/*Servicio que autoriza la solicitud cuando se cambia la CDP a NO Comprobables y al mismo tiempo se actualiza en Tienda dicha CDP
	 	 * Éste proceso entra sólo cuando se está validando el expediente por parte de MCO y el cliente decide cambiar su CDP a NO comprobables
	 	 * */
		$scope.actualizaStatusTiendaMCO = function()
		{			
			$rootScope.waitLoaderStatus = LOADER_SHOW;							
			var docRechazo = 0;
			for(var i=0;i<$rootScope.solicitudJson.documentos.documento.length;i++){
				if($rootScope.solicitudJson.documentos.documento[i].status == STATUS_RECHAZADO){
					docRechazo = 1;
					break;
				}
			}
	        if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.mesaControl.id && $rootScope.solicitudJson.marca == STATUS_SOLICITUD.mesaControl.marca.condicionadoMesa && !docRechazo){
	        	$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.autorizada.id;
				$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.expValGerente;
				
	        }else if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.mesaControl.id && $rootScope.solicitudJson.marca == STATUS_SOLICITUD.mesaControl.marca.condicionadoMesa && docRechazo){
        	$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.autorizada.id;
			$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.expRechazado;
	        }
	        
			solicitudService.actualizaStatusTiendaPorCambioCDP( $rootScope.solicitudJson ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					console.log( data );
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						if(response.codigo == 2){
							generalService.locationPath( "/ochoPasos" );
						}else{
						    $rootScope.message("Código " + response.codigo, ["Ocurrió un error al actualizar status en Tienda, favor de intentarlo más tarde."], "Aceptar", null, "bgCafe", "cafeD");
						
				        }
					}else
						$rootScope.message("Aviso",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
					
				}, function(error){
		            $rootScope.waitLoaderStatus = LOADER_HIDE; 
		            modalService.alertModal("Error "+error.status, [error.statusText]);
				}
			);
			
		};
		
		$scope.continuaLiberarGerencia = function( searchFlag, paso ){
						
				$scope.llenaSeccion = true;
				var sectionAlert = false;
				
/** INICIA_OS-FLUJO COACREDITADO **/
				/** Actualiza la marca para mostrar, muestra el  mensaje de falta validar los documentos **/
				condicionesLiberacionOS();
/** TERMINA_OS-FLUJO COACREDITADO **/
				
				cargaVista();
				$scope.buildMenuList();
				$scope.seccionesNoInmediatas();
				if($rootScope.solicitudJson.ofertaSeleccionadaMCO == 1){
					$scope.llenaSeccion = false;					
				}else if( $scope.muestraAlertaBuro && MUESTRA_TERMOMETRO){
					$scope.llenaSeccion = false;
					TermometroController.showMessageBuro( $scope );
				}else if(!$scope.validaContinuarNuevoCotizador() && MUESTRA_NUEVO_COTIZADOR)
					$scope.llenaSeccion = false;
				
				if( $rootScope.termometroHandler ){
					if( ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id || $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.preautorizada.id) 
					     && ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinLiberar || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.clienteVerdeJVC || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.mesaControl.marca.condicionadoMesa) )
						$rootScope.onceOfert = true;	
					$scope.validaDocumentosGerencia(searchFlag);
				
					
					$scope.avisoAval = false;																											/** INICIA_OS-FLUJO COACREDITADO -- No entrar si se tiene tiene Coacreditado**/

					if ($rootScope.solicitudJson.banderaSolidario == 1 && $rootScope.solicitudJson.avales[0].idSeguimiento != 6 && $scope.llenaSeccion && !$scope.existeObligadoSolidario){
						if($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id &&
							$rootScope.solicitudJson.marca == (STATUS_SOLICITUD.autorizada.marca.sinLiberar || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.clienteVerdeJVC || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.mesaControl.marca.condicionadoMesa)){
							$scope.avisoAval = true;
							modalService.confirmModal("Aviso", ["Avísale a " + $rootScope.solicitudJson.cotizacion.clientes[0].nombre + " " + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno + " " + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno + " que su Coacreditado aún no ha sido visitado en su domicilio, puede esperar a tener un resultado de la visita o puede continuar con el proceso sin Coacreditado pero las condiciones del crédito serán diferentes (monto menor de LCR)."], 
									"Continuar sin Aval","Esperar verificación del Aval", "bgazul", "btn gris btn AvisoAvalGris", "btnAvalAzul" , null, null)
									.then(
											function(exito){
												$scope.menuList[4].showAlerta = true;	
												if (esIpad && $scope.validaContratos && configuracion.origen.tienda ){
													var firmaRest = 0;
													for (var x = 0; x < $rootScope.solicitudJson.contratos.contrato.length; x++){
														if($rootScope.solicitudJson.contratos.contrato[x].statusFirma == 0)
															firmaRest++;
													}
													
													if (firmaRest > 0){
														$scope.llenaSeccion = false;
														$scope.menuList[7].numAlerta = firmaRest;
														$scope.menuList[7].showAlerta = true;
														$scope.menuList[7].vistaPorcentaje = true;
													}
											    }
												
											},function(error){
												$rootScope.waitLoaderStatus = LOADER_SHOW;
												$rootScope.solicitudJson.banderaSolidario = 0;
												var solicitudJsonString = generalService.delete$$hashKey($rootScope.solicitudJson);
												
												solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: SECCION_SOLICITUD } ).then(
														function(data){
															$rootScope.waitLoaderStatus = LOADER_HIDE;
															
															if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
																var responseJson = JSON.parse(data.data.respuesta);							
																if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO)
																	console.log("OK");
																else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
																	var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
																	$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
																}else{
																	if(responseJson.codigo == ERROR_SOL_RECHAZADA){
																		var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
																		$rootScope.message(	"Error en solicitud", [ "La solicitud no puede ser modificada debido a que se encuentra Cancelada o Rechazada." ],
																				"Aceptar", "/simulador",  null,null,buildJsonDefault);
																	}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
																		generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
																		generalService.locationPath("/ficha");
																	}else{
																		$rootScope.message("Aviso",["Error al guardar cotización (sección 9). Código [" + responseJson.codigo +"] no identificado"], "Aceptar", null, null, null);
																	}
																}
															}else{
																var mensaje = "";
																if(data.data.descripcion == null || data.data.descripcion == undefined || data.data.descripcion == "")
																	mensaje = "No se obtuvo una respuesta éxitosa al guardar la sección 9.";
																else
																	mensaje = data.data.descripcion;
																
																$rootScope.message("Aviso",[generalService.displayMessage(mensaje)], "Aceptar");
																
															}
																
															
														}, function(error){
															$rootScope.waitLoaderStatus = LOADER_HIDE;
															$rootScope.message("Aviso",["Error en el servicio al guardar solicitud sección 9."], "Aceptar", null, null, null);
														}
												);
											}
									);
						}
					}
					
				    if (!$scope.avisoAval){
				    	//$rootScope.consultaFuncionalidad.flujoIngresosMayoresA20KCondicionamiento
				    	/*Se valida que el objeto de mesaControl sea diferente de Null para validar la regla del flujo Ingresos Comprobables MCO 
				    	 * Si es Null debe continuar por el flujo normal del liberación */
				    	if($rootScope.solicitudJson.mesaControl == null){
				    		$rootScope.condicionamientoIngMay20 = false;
				    	}else if(($rootScope.consultaFuncionalidad.flujoIngresosMayoresA20KCondicionamiento) && ($rootScope.solicitudJson.banderaIngresos == 1) &&
				    			($rootScope.solicitudJson.mesaControl.tipoCondicionamiento == CONDICIONAMIENTO_MCO_IC) && ($rootScope.solicitudJson.idSolicitudTiendaCredInm == 0)){
				    		$rootScope.condicionamientoIngMay20 = true;
				    	}else{
				    		$rootScope.condicionamientoIngMay20 = false;
				    	}
										    
				    	/* Si mostrarContratos = true entonces se debe pedir la firma de contratos */
				    	if($rootScope.mostrarContratos){				    		
            				$scope.validaContratosEncolados(paso);
            			}
						
						if(MUESTRA_TERMOMETRO){ 
							if(generalService.validarMostarTermometro($rootScope.solicitudJson) && $scope.llenaSeccion)
								$scope.validaCambioBuro();
						}
						
						if ( $scope.llenaSeccion ){
                				if(($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.sinLiberar || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.clienteVerdeJVC) ||
                						(($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expRechazado || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.mesaControl.marca.condicionadoMesa))){
                					if($rootScope.condicionamientoIngMay20 && ($rootScope.solicitudJson.mesaControl.numeroDeCondicionamiento <= LIMITE_INTENTOS_MCO)){
                						envioIngresosMayores20kMCO();
                					}else{
                						$scope.servicioLiberacionEjecutivo();
                					}
                				}else if(($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.autorizadoMesa) && ($scope.alcanzaCDPSeguro)){
                					$scope.seguroVidamax();	                					
			              
                				} else if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.ejecutivo){
                					$scope.validacionGerente();				                
                			}
                		}						 						 
                	}
				}else{
					if(generalService.validarMostarTermometro($rootScope.solicitudJson)){
						if(MUESTRA_TERMOMETRO)
							TermometroController.errorBuroGlobo( $scope );
						if(MUESTRA_NUEVO_COTIZADOR)
							$scope.muestraAlertasNuevoCotizador();
					}else
						$scope.validarBuroModatelas(null,true);					
				}
							
		};/* END CONTINUA LIBERAR GERENCIA FUNCTION */
		
		$scope.validaContratosEncolados=function(paso){
			$scope.menuList[6].messageAlert="";
			$scope.menuList[6].showMessageAlert= false;
			$scope.menuList[6].showAlerta = false;
			var firmaNo = 0;
			var firmaPen = 0;
			var firmadosDocs = 0;
			for (var x = 0; x < $rootScope.solicitudJson.contratos.contrato.length; x++){
				if($rootScope.solicitudJson.contratos.contrato[x].statusFirma == STATUS_CONTRATO.SIN_FIRMA)
					firmaNo++;
				else{
					if($rootScope.solicitudJson.contratos.contrato[x].statusFirma == STATUS_CONTRATO.FIRMADO_SIN_ENVIAR)
						firmaPen++;
					firmadosDocs++;
				}
			}
			
			if (firmaNo > 0 || firmaPen > 0){
				if(firmaNo > 0)
					$scope.menuList[6].messageAlert="Aún tienes un contrato(s) por firmar";
				else
					if(firmaPen > 0)
						$scope.menuList[6].messageAlert="Aún tienes un contrato(s) por enviar";
				if($rootScope.campanasConvivencia($rootScope.solicitudJson.campana) || $rootScope.promocionCampanas($rootScope.solicitudJson.campana)){
					var numDocs = 2;
	    		}else{
	    			var numDocs = generalService.validardiaDePago()?4:2;
	    		}
				if($rootScope.prestamoGarantias || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.prodResPrestamoConGarantias)
					numDocs = numDocs + 1;
	    		$rootScope.solicitudJson.contratos.porcentaje = firmadosDocs==0?0:parseInt(((firmadosDocs * 100) / numDocs).toFixed(0));
	    		$scope.menuList[6].porcentaje = $rootScope.solicitudJson.contratos.porcentaje;
				$scope.menuList[6].showMessageAlert=true;
				$scope.menuList[6].showAlerta = true;
				if (paso == 2){
					$scope.llenaSeccion=false;
				}
			}
		};
		
		$scope.servicioLiberacionEjecutivo = function()
		{
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			solicitudService.liberarSolicitud( $rootScope.solicitudJson ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
//					console.log( data );
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.autorizada.id;
						$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.ejecutivo;
						$rootScope.solicitudJson = generalService.noEditaSeccion($rootScope.solicitudJson,[1,2,3,4,5,6,7,8]);
						$scope.condicionesLiberacion();
						$scope.validacionGerente();
						/** INICIA_OS-FLUJO COACREDITADO **/
												/* Activa la notificación de documento pendientes de validar por el gerente para el Coacreditado */
													$scope.activarNotificacion();
						/** TERMINA_OS-FLUJO COACREDITADO **/
						
					}else
						$rootScope.message("Aviso",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
					
				}, function(error){
		            $rootScope.waitLoaderStatus = LOADER_HIDE; 
		            modalService.alertModal("Error "+error.status, [error.statusText]);
				}
			);
			
		};/* END SERVICIO LIBERACION EJECUTIVO FUNCTION */
		
		$scope.searchDocuments = function( scopeMenuItem,validaEncolado )
		{
			
			var lenDoc = $rootScope.solicitudJson.documentos.documento.length;
			var index = -1;
			var status = false;
			
			if( lenDoc > 0 ){
				
				var docs = $rootScope.solicitudJson.documentos.documento;
				
				var docRulePending = function( doc ){
					if( doc.status == STATUS_PENDIENTE )
						return doc;
				};
				
				var docRuleHeaping = function( doc ){
					if( doc.status == STATUS_ENCOLADO_IPAD )
						return doc;
				};
				
				var docRuleRechazados = function( doc ){
					if( doc.status == STATUS_RECHAZADO )
						return doc;
				};
				
				var missingDocs = docs.filter( docRulePending );
				var heapDocs = validaEncolado?docs.filter( docRuleHeaping ):[];
				var rechazadosDocs = docs.filter( docRuleRechazados );
				
				docs.map(function( dataDocs ){
										
					if( ( dataDocs['status'] == STATUS_ENCOLADO_IPAD || dataDocs['status'] == STATUS_PENDIENTE ) &&
							dataDocs['idDocumento'] == COMP_INGRESOS.id ){
						if(MUESTRA_TERMOMETRO)
							TermometroController.filtrosOferta( $scope );
					}
					
				});
				
				if( missingDocs.length != 0 )
					if( missingDocs.length == 1 ){
						scopeMenuItem.messageAlert = 'Es necesario digitalizar: ' +  missingDocs[0].documentoDes;
						scopeMenuItem.showMessageAlert = true;
					}else{
						scopeMenuItem.messageAlert = 'Aún tienes documentos pendientes por digitalizar';
						scopeMenuItem.showMessageAlert = true;
					}
				
				if( heapDocs.length != 0 )
					if( heapDocs.length == 1 ){
						scopeMenuItem.messageAlert = 'Es necesario enviar: ' +  heapDocs[0].documentoDes;
						scopeMenuItem.showMessageAlert = true;
					}else{
						scopeMenuItem.messageAlert = 'Aún tienes documentos por enviar';
						scopeMenuItem.showMessageAlert = true;
					}
				
				if( rechazadosDocs.length != 0 )
					if( rechazadosDocs.length == 1 ){
						scopeMenuItem.messageAlert = 'El documento ' +  rechazadosDocs[0].documentoDes + ' está RECHAZADO'; 
						scopeMenuItem.showMessageAlert = true;
					}else{
						scopeMenuItem.messageAlert = 'Tienes documentos RECHAZADOS';
						scopeMenuItem.showMessageAlert = true;
					}

				if( missingDocs.length != 0 || heapDocs.length != 0 || rechazadosDocs.length != 0){
					$scope.llenaSeccion = false;
					scopeMenuItem.showAlerta = true;
					scopeMenuItem.showAuth = false;			
				}
								
			}
			
		};/* END SEARCH DOCUMENTS FUNCTION */
				
		$scope.validacionGerente = function()
		{
			
			var index = -1;
			var data = $scope.menuList;
			
			index = data.map( function(d){
				return d['path'];
			}).indexOf( '/expediente' ); /* IDENTIFICACION */
			
			if( index >= 0 ){
				$scope.menuList[index].showAuth = true;
				$scope.menuList[index].showMessageAlert = false;
			}
			
		};/* END VALIDACION GERENTE FNCTION */
		
		
		/**
		 * Función para consumir el servicio que va por flujo ingresos Comprobables de MCO
		 **/
		function envioIngresosMayores20kMCO(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			$timeout(function(){
				solicitudService.enviarIngresosCompMayoresA20k($rootScope.solicitudJson.idSolicitud).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var response = JSON.parse(data.data.respuesta);
							$rootScope.solicitudJson = response.data;
							
							if(response.codigo == 2){
								generalService.locationPath( "/estatus" );
							}else{
							    $rootScope.message("Código " + response.codigo, ["Ocurrió un error al ejecutar el servicio de Mesa de Crédito, favor de intentarlo más tarde."], "Aceptar", null, "bgCafe", "cafeD");
							}
						}
					},function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
					}
				);
			}, 3000);
		}
		
		
		$scope.surtirPorEjecutivo = function()
		{
			
			$scope.estadoSolicitud = $rootScope.solicitudJson.idSeguimiento;
			$scope.marcaSolicitud = $rootScope.solicitudJson.marca;
			
			/**
			 * Se toma el color idColor y idColorNC dependiendo de la bandera ingresos
			 **/
			var color = ($rootScope.solicitudJson.banderaIngresos == 0)?$rootScope.solicitudJson.idColorNC:$rootScope.solicitudJson.idColor;
			
			if( $scope.estadoSolicitud == STATUS_SOLICITUD.autorizada.id && $rootScope.pasoLiberacion || $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.procesoBateriaBuro){					
/** INICIA_OS-FLUJO COACREDITADO **/
				if($scope.activarNotificacion())
					return;
/** TERMINA_OS-FLUJO COACREDITADO **/
					
					// Se agrega una validación para que sólo sea una vez.
					if( $rootScope.solicitudJson.envioCelular != 1 && !$scope.soloUnaVezLiberacion) {
						if($rootScope.consultaFuncionalidad.liberacionSinCodigo) {
							$scope.soloUnaVezLiberacion = true;
							
							modalService.confirmModal("Código de Seguridad", 
									["¿Tu cliente recibió su código de seguridad?"], "No", "Sí").then(
								function(exito) {
									console.log("Sí recibió el código.");
									
									modalService.codigoModal(null, 777, CLIENTE.id).then(
					  					function(exito) {
					  						console.log("Validar");
					  						
					  						$scope.surtirPorEjecutivo();
					  					}, function(error) {
					  						console.log("Validar más tarde.");
					  						
					  						$scope.surtirPorEjecutivo();
					  					}
						  			);
								}, function(error) {
									console.log("No recibió el código.");
									
									$scope.surtirPorEjecutivo();
								}
							);
						} else {
							$scope.llenaSeccion = false;				
							$scope.muestraAlertaCodigo = true;
							$scope.muestraMensajeCodigo = true;
							$scope.mensajeCodigo = "Es necesario validar el código celular";
							
							var jsonCodigo = {
								tipoPersona: CLIENTE.id,
							};
							
							if( esTerminado() )
								$scope.validaCodigo( null, 0, jsonCodigo, true );
						}							
					}else if(($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.procesoBateriaBuro) 
							&& ( $rootScope.userSession.idPerfil == PUESTO_EJECUTIVO || $rootScope.userSession.idPerfil == ASESOR_DE_NEGOCIOS || $rootScope.userSession.idPerfil == PUESTO_ASESOR_CREDITO ) 
							&& generalService.isCanalInterno($rootScope.sucursalSession.idCanal)
							){
						
						$scope.llenaSeccion = false;				
						$scope.muestraAlertaEncuesta = true;
						$scope.muestraMensajeEncuesta = true;
						$scope.mensajeEncuesta = "Falta validar el cuestionario por el gerente";
						/*Si el perfil es ejecutivo, al recuperar una solicitud con proceso de bateria le mostrará el mensaje definido arriba*/
						
					}else if((color == COLORES_EVALUACION_CTE.VERDE_OBSCURO || color == COLORES_EVALUACION_CTE.VERDE || color == COLORES_EVALUACION_CTE.VERDE_CLARO) && $rootScope.consultaFuncionalidad.flujoBateriaBuroHabilitada){
						/**
						 * Entra a esta validación si es un canal interno
						 * La bandera "flujoClienteVerdeStatusMesa" es una bandera que se parametriza por sucursal
						 * Si es colo 1,2 o 3, y la bandera de "flujoClienteVerdeStatusMesa" es igual a true, envía a la Bateria de Preguntas
						 **/
// I-MODIFICACION TDC (LLAMAR A CONSULTAR CUENTAS DOMICILIACION)							
						if(  $rootScope.campanasConvivencia($rootScope.solicitudJson.campana) ){
							
							$scope.validarCapacidades("/datosEncuesta");
						
						}else if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto))
							$scope.validaHuellaLiberacionTDC("/datosEncuesta");
						else
// F-MODIFICACION TDC (LLAMAR A CONSULTAR CUENTAS DOMICILIACION)
							generalService.locationPath( "/datosEncuesta" );
					}else{
						/**
						 * Entra a esta validación si es un canal interno
						 * La bandera "flujoClienteVerdeStatusMesa" es una bandera que se parametriza por sucursal
						 * Si es colo 1,2 o 3, y la bandera de "flujoClienteVerdeStatusMesa" es igual a false, envía a la Bateria de Preguntas
						 **/
// I-MODIFICACION TDC (LLAMAR A CONSULTAR CUENTAS DOMICILIACION)

						if( $rootScope.campanasConvivencia($rootScope.solicitudJson.campana)){
							
							$scope.validarCapacidades("/liberacion");
						
						}else if ($rootScope.productosTarjetas($rootScope.solicitudJson.idProducto))
							$scope.validaHuellaLiberacionTDC("/liberacion");
						else{
// F-MODIFICACION TDC (LLAMAR A CONSULTAR CUENTAS DOMICILIACION)
							$scope.abreModalLimitesDeCredito();
						}
					}
			}else{
				$scope.validacionGerente();
/** INICIA_OS-FLUJO COACREDITADO **/
				$scope.activarNotificacion();
/** TERMINA_OS-FLUJO COACREDITADO **/
			}
							
		};/* END SURTIR POR EJECUTIVO FUNCTION */
		
		$scope.validarCapacidades = function(path){
		
			$rootScope.waitLoaderStatus = LOADER_SHOW; 
				var jsonRequest =  {
						"clienteUnico": $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
						 "tipoConsulta": 1,
						 "idSolicitud": $rootScope.solicitudJson.idSolicitud
				 };
				 
	tarjetaService.consultaStatusLCR(jsonRequest).then(
		function(data){
		
		if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
		
			var responseJson = JSON.parse(data.data.respuesta);
			
			if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
					
				var jsonStatusLCR = JSON.parse(responseJson.data);
				$rootScope.resultadoConsultaLCR  = JSON.parse(responseJson.data);
				validaCapacidades(jsonStatusLCR,path);
			}else{
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("AVISO", [responseJson.descripcion],"Aceptar",null,null, null);
			}
				
		}else{
			$rootScope.waitLoaderStatus = LOADER_HIDE; 
			$rootScope.message("AVISO", [data.data.descripcion],"Aceptar",null,null, null);
		}
			
			
		}, function(error){
			$rootScope.waitLoaderStatus = LOADER_HIDE; 
			$rootScope.message("AVISO", ["Se presentó un error favor de reintentar"],"Aceptar",null,null, null);
			});


		}
				
		
		function validaCapacidades(jsonStatusLCR,path){
			
			var x = JSON.parse(jsonStatusLCR.data);
			$scope.capacidadPagoTDC = x.capacidadDePagoDisponible;
			 switch (jsonStatusLCR.codigo) {
				 
			 case CONVIVENCIA_LCR_LIBERADA:
					
					 if($scope.capacidadPagoTDC !== $rootScope.solicitudJson.tarjetasCredito.tarjetaOro.capacidadPagoDisponible){
						 $rootScope.waitLoaderStatus = LOADER_HIDE; 
						 modalService.modalCotizadorTDC();
					 }else{
						 $scope.bajarTiendaConvivencia(path);
					 } 
				 
				 break;
			 case CONVIVENCIA_LCR_AUTORIZADA_SIN_LIBERAR:
			 case CONVIVENCIA_LCR_CANCELADA:
			 case CONVIVENCIA_LCR_RECHAZADA:
			 case CONVIVENCIA_LCR_BLOQUEADA:
			 case CONVIVENCIA_LCR_AUTORIZADA:
			 case CONVIVENCIA_LCR_DEMANDA_MERCANTIL:
			 case CONVIVENCIA_CLIENTE_SIN_LCR:
				 generalService.buildSolicitudJson($rootScope, null);
				 $rootScope.waitLoaderStatus = LOADER_HIDE; 
				 $rootScope.message("AVISO", [jsonStatusLCR.descripcion],"Aceptar","/simulador");
				 break;
			 default:
				 $rootScope.waitLoaderStatus = LOADER_HIDE; 
				 $rootScope.message("AVISO", ["Error inesperado"],"Aceptar",null,null, null);
			 break;
			 }

		}	
		
		$scope.bajarTiendaConvivencia = function(path){
			
			if( $rootScope.solicitudJson.flujoSolicitudADN != 99){
				var jsonRequest =  {
						 idSolicitud: $rootScope.solicitudJson.idSolicitud
					};
				 
				tarjetaService.bajarTiendaLCR(jsonRequest).then(
					function(data){
					
					$rootScope.waitLoaderStatus = LOADER_HIDE; 
					
					if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
					
						var responseJson = JSON.parse(data.data.respuesta);
						
						if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
								
							var jsonStatusLCR = responseJson.data;
							$rootScope.solicitudJson = jsonStatusLCR;
							$scope.validaHuellaLiberacionTDC(path);
							
						}else
							$rootScope.message("AVISO", [responseJson.descripcion],"Aceptar",null,null, null);
					}else
						$rootScope.message("AVISO", [data.data.descripcion],"Aceptar",null,null, null);
						
				}, function(error){
					$rootScope.waitLoaderStatus = LOADER_HIDE; 
					$rootScope.message("AVISO", ["Se presentó un error al bajar a tienda, favor de reintentar"],"Aceptar",null,null, null);
					});
			}else{
				$scope.validaHuellaLiberacionTDC(path);
			}
		}
		
		$scope.surtirSinTaz = function(){
			generalService.locationPath( "/credito" );
			$rootScope.informeRecomendado();
		};/* EN SURTIR SIN TAZ FUNCTION */
		
		
		$scope.intentarBuro = function(tercerosModatelasCita, tercerosModatelasLiberar){ TermometroController.intentarBuro( $scope,tercerosModatelasCita, tercerosModatelasLiberar); };
		
		$scope.comprobanteHandler = function()
		{
			
			var existe = false;
			
			$('.requisitos ul li > a').each(function(){
		 		if( $( this ).hasClass('active') ){
		 			existe = true; 
		 			return;
		 		};
		 	});
			
			if( existe )
				$scope.deshabilitarRecalcular = false;
			else
				$scope.deshabilitarRecalcular = true;
			
			validaCreditoInmediato($( "#sliderVertical" ).slider( "value" ), false);
			
		};/* END COMPROBANTE HANDLER FUNCTION */
		
		$scope.test = function( algo ){
			console.warn( algo );
		}
		

		$scope.validaCambioBuro = function(){
			var ingresos = "";
			var aval = "";
			$scope.cambio = false;
			var plazo = "";
			if ($scope.condiciones.tipoComprobante != ""){
				if ($scope.condiciones.tipoComprobante == "ingresos"){
					ingresos = 1;
					aval = 0;
				}else{
				    ingresos = 0;
				    aval = 1;
				}
				if ($rootScope.solicitudJson.banderaIngresos != ingresos && $rootScope.solicitudJson.banderaSolidario != aval){
				   alert("cambio");
				   $scope.cambio = true;
				}
			}

			$('.requisitos ul li > a').each(function(){
				if( $( this ).hasClass('active') ){
					plazo = parseInt( $(this).text() ); 
				 	return;
				};
			});

			if ($rootScope.solicitudJson.cotizacion.plazo != plazo ) 
				$scope.cambio = true;
			
			var sliderValor = $( "#sliderVertical" ).slider( "value" );
			if ( $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto != sliderValor ) 
				$scope.cambio = true;
		
			if ($scope.cambio && $scope.llenaSeccion){
				if ($scope.liberacion == "default"){
					var accion = "generar cita"
				}else{
					var accion = "liberación"
				}
				modalService.confirmModal("Aviso", ["Detectamos que tiene cambios en el termómetro sin aplicar, ¿Desea continuar?"], 
						"Cancelar","Aceptar", "bgazul", "btn gris btn AvisoAvalGris", "btn Azul" , null, null)
					.then(
						function(exito){
//									$scope.llenaSeccion = false;									
						},function(error){
							$scope.llenaSeccion = false;
						}
				);
			}
			
		};
		
		function validaCreditoInmediato(monto, setCI){
	 		
	 			var plazos = generalService.getPlazos( $rootScope );
			  
				var arrayMontos = plazos.map( function(d){
					return d['monto'];
				});
												
				var index = arrayMontos.indexOf( monto );
								 				
				//plazo seleccionado
				var _plazo = plazos[index]; 
				
				
				if(typeof _plazo != "undefined"){
										
					
					if(setCI){
						if( ($rootScope.solicitudJson.banderaIngresos == 1  &&  _plazo.comprobableInm == 1 ) || _plazo.noComprobableInm == 1 )
							$rootScope.solicitudJson.creditoInmediato = (generalService.validaCreditoInmediatoProducto()) ? 1 : 0;
						else
							$rootScope.solicitudJson.creditoInmediato = 0;
						 				 				 								
						console.log("creditoInmediato "+$rootScope.solicitudJson.creditoInmediato);
					}
					
					
					if( ($scope.muestraCondicion  &&  $scope.condiciones.tipoComprobante == 'ingresos' && _plazo.comprobableInm == 1 ) || _plazo.noComprobableInm == 1   )
						$scope.leyendaCreditoInmediato = true;
					else
						$scope.leyendaCreditoInmediato = false;
					 				 				 								
					console.log("leyendaCreditoInmediato "+$scope.leyendaCreditoInmediato);
				}
				
	 	}
		
		$scope.validaEncoladosEnLiberacion = function()
		{
			if ( $scope.llenaSeccion ){
				if( configuracion.origen.tienda ){
					var documentoEncolado = generalService.documentoEncolado($rootScope.solicitudJson);
					var contratoEncolado  = generalService.contratoEncolado($rootScope.solicitudJson);
					
					if(documentoEncolado || contratoEncolado){
						if ($rootScope.contratosResponseCita && $rootScope.documetosResponseCita){
							if (configuracion.so.windows)
								envioDocsWindows("liberacion");
							else						
								$rootScope.executeAction( "ochoPasosDivId", "DocumentosResponseEnvioLiberacion",  {nombre:"envioDocumentos", idCliente:$rootScope.solicitudJson.cotizacion.clientes[0].idPersona, mostrarSpinner:1} );
						}else{
							$rootScope.message("Siete Pasos",["Se están enviando documentos, favor de esperar"], "Aceptar", null, null, null);
							$timeout(function(){
								$rootScope.contratosResponseCita = true;
								$rootScope.documetosResponseCita = true;
							}, 30000);
						}
					}else{																															
						validaContratosDigitalizados();
					}								
				}else{
					$scope.seguroVidamax();
				}
			}		
			
		};/* END VALIDA ENCOLADOS EN LIBERACION */
		
		
		$scope.validaEncoladosEnGenerarCita = function()
		{
		
			if ( $scope.llenaSeccion ){
				if( configuracion.origen.tienda ){
					var documentoEncolado = generalService.documentoEncolado($rootScope.solicitudJson);
					var contratoEncolado  = generalService.contratoEncolado($rootScope.solicitudJson);
					
					if(documentoEncolado || contratoEncolado){
						if ($rootScope.contratosResponseCita && $rootScope.documetosResponseCita){
							if (configuracion.so.windows)
								envioDocsWindows("cita");
							else						
								$rootScope.executeAction( "ochoPasosDivId", "DocumentosResponseEnvio",  {nombre:"envioDocumentos", idCliente:$rootScope.solicitudJson.cotizacion.clientes[0].idPersona, mostrarSpinner:1} );
						}else{
							$rootScope.message("Siete Pasos",["Se están enviando documentos, favor de esperar"], "Aceptar", null, null, null);
							$timeout(function(){
								$rootScope.contratosResponseCita = true;
								$rootScope.documetosResponseCita = true;
							}, 30000);
						}
					}else{	
						
/** INICIA_OS-FLUJO COACREDITADO **/
						/** Si existe Coacreditado enviamos a la visita del Coacreditado **/
						if($rootScope.agendarCitaOSDisponible && $rootScope.solicitudOSJson && $rootScope.solicitudOSJson.idSolicitud != ""){
							validaContratosDigitalizados(generalService.whichOneVisit());
/** TERMINA_OS-FLUJO COACREDITADO **/
							
						}else{
							validaContratosDigitalizados(generalService.whichOneVisit());
						}


					}								
				}else{
					
/** INICIA_OS-FLUJO COACREDITADO **/
					/** Si existe Coacreditado enviamos a la visita del Coacreditado **/
					if($rootScope.agendarCitaOSDisponible && $rootScope.solicitudOSJson && $rootScope.solicitudOSJson.idSolicitud != ""){
						validaContratosDigitalizados(generalService.whichOneVisit());
/** TERMINA_OS-FLUJO COACREDITADO **/
						
					}else{
						validaAltaCU(0);
					}
				}
			}
			
		};/* END VALIDA ENCOLADOS EN GENERAR CITA */
		
		
		$scope.DocumentosResponseEnvioLiberacion = function(ipadResponse){
			$rootScope.contratosResponseCita = true;
			$rootScope.loggerIpad("DocumentosResponseEnvioLiberacion", null, ipadResponse);
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			validaContratosDigitalizados();
		}
		
		$scope.DocumentosResponseEnvio = function(ipadResponse){
			$rootScope.contratosResponseCita = true;
			$rootScope.loggerIpad("DocumentosResponseEnvio", null, ipadResponse);
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			
/** INICIA_OS-FLUJO COACREDITADO **/
			
			/** Si existe Coacreditado enviamos a la visita del Coacreditado **/
			if($rootScope.agendarCitaOSDisponible && $rootScope.solicitudOSJson && $rootScope.solicitudOSJson.idSolicitud != ""){
				validaContratosDigitalizados(generalService.whichOneVisit());
				
/** TERMINA_OS-FLUJO COACREDITADO **/
			}else{
				validaContratosDigitalizados(generalService.whichOneVisit());
			}
			
		}
		var validaContratosDigitalizados = function(path){
			$rootScope.waitLoaderStatus = LOADER_SHOW; 						
															
			documentosService.validaContratosDigitalizados( { jsonSolicitud: $rootScope.solicitudJson } ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						
						if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							$rootScope.solicitudJson = j.data;
/** INICIA_OS-FLUJO COACREDITADO **/
							if (path == generalService.whichOneVisit() || (path == "/agendarCitaOS" && $rootScope.solicitudOSJson && $rootScope.solicitudOSJson.idSolicitud != "") )
/** TERMINA_OS-FLUJO COACREDITADO **/


								$scope.enviaVisitaAsesor(2);
							else{
								$scope.continuaLiberarGerencia(true, 2)
							}				
						}else if(j.codigo == 603){
							$rootScope.solicitudJson = j.data;
							$rootScope.message("Siete Pasos",[ "Por favor, revise que no cuente con documentos encolados y/o secciones incompletas" ], "Aceptar", null);
						}else{
							$rootScope.message("Siete Pasos",[ "Por favor, revise que no cuente con documentos encolados y/o secciones incompletas" ], "Aceptar", null);
						}
					}else
						$rootScope.message("Siete Pasos",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
					
				}, function(error){
	                $rootScope.waitLoaderStatus = LOADER_HIDE; 	                					
				}
			);
						
		};
		
		var envioDocsWindows = function(cita){
			var etiquetaFrente=generalService.getDatafromCategory("SIMULADOR", "ETIQUETA FRENTE", "VALOR.valor" );
			var etiquetaReverso=generalService.getDatafromCategory("SIMULADOR", "ETIQUETA REVERSO", "VALOR.valor" );
			var documento = "";
			angular.forEach( $rootScope.solicitudJson.documentos.documento, function(doc, key){
				if(doc.status == STATUS_ENCOLADO_IPAD){
					switch(doc.idDocumento){
						case IDENTIFICACION_OFICIAL.id:
							if(documento.length > 0)
								documento += ",";
							documento += IDENTIFICACION_OFICIAL.descripcion + " "+ CLIENTE.descripcion + " " + etiquetaFrente +",";
							documento += IDENTIFICACION_OFICIAL.descripcion + " "+ CLIENTE.descripcion + " " + etiquetaReverso;
							break;
						case COMP_DOMICILIO.id:
							for(var i=0; i<doc.cantidad; i++){
								if(documento.length > 0)
									documento += ",";
								documento += COMP_DOMICILIO.descripcion + " "+ CLIENTE.descripcion + " " + i;
							}
							break;
						case COMP_INGRESOS.id:
							for(var i=0; i<doc.cantidad; i++){
								if(documento.length > 0)
									documento += ",";
								documento += COMP_INGRESOS.descripcion + " "+ CLIENTE.descripcion + " " + i;
							}
							break;
						case COMP_PROPIEDAD.id:
							for(var i=0; i<doc.cantidad; i++){
								if(documento.length > 0)
									documento += ",";
								documento += COMP_PROPIEDAD.descripcion + " "+ CLIENTE.descripcion + " " + i;
							}
							break;									
					}																
				}													
			});
			if(documento.length > 0)
				documento = ","+documento;
			var callbackDocs = "recuperaSolicitud";
			if (cita =="cita")
				var callbackDocs = "DocumentosResponseEnvio";
			if (cita =="liberacion")
				var callbackDocs = "DocumentosResponseEnvioLiberacion";
			$rootScope.contratosResponseCita = false;
			$rootScope.executeAction( "ochoPasosDivId", callbackDocs,  {nombre:"envioDocumentos", idCliente:$rootScope.solicitudJson.cotizacion.clientes[0].idPersona, mostrarSpinner:1,filtroDocumentos:CONTRATOS_ENVIAR+","+FIRMA_PRIVACIDAD.descripcion+","+FIRMA_BURO.descripcion + documento} );
		}
		
		$scope.seguroVidamax = function(paso){
			if(!$rootScope.consultaFuncionalidad.habilitarFlujoSeguroVidamaxUnificado && !$rootScope.consultaFuncionalidad.habilitarFlujoSeguroVidamax && $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente){
				$rootScope.pasoLiberacion = true;
				$scope.surtirPorEjecutivo();
			}else{
			//EJECUTA_SEGURO = $rootScope.consultaFuncionalidad.habilitarFlujoSeguroVidamax || $rootScope.consultaFuncionalidad.habilitarFlujoSeguroVidamaxUnificado;
// I-MODIFICACION SIPA (VALIDA QUITAR OFERTA DE SEGURO PARA CLIENTES SIPA)
			if (EJECUTA_SEGURO && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal 
			&& (!($rootScope.productosSIPA($rootScope.solicitudJson.idProducto) && $rootScope.promocionCampanas($rootScope.solicitudJson.campana)) || $rootScope.campanaNvoPreaprob($rootScope.solicitudJson.campana))
// F-MODIFICACION SIPA (VALIDA QUITAR OFERTA DE SEGURO PARA CLIENTES SIPA)
			/*\ Se valida que la solicitud no sea un rescate de préstamo personal\*/
			&& generalService.consultaHistoricoMarcas([150,151])==0){
			/*\ Se valida que la solicitud no sea un rescate de préstamo personal\*/
				if ($rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico == "" || $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico == null ){
					$rootScope.message("Siete Pasos",["La solicitud no cuenta con Cliente Unico"], "Aceptar", null, null, null);
					$rootScope.waitLoaderStatus = LOADER_HIDE;
				}else{
					if ($rootScope.solicitudJson.banderaIngresos == 1)
						var capacidadPago = $scope.calcupaRestante($rootScope.solicitudJson.capacidadPagoComprobable, $rootScope.solicitudJson.cotizacion.pagoPuntual);
					else
						var capacidadPago = $scope.calcupaRestante($rootScope.solicitudJson.capacidadPagoNoComprobable, $rootScope.solicitudJson.cotizacion.pagoPuntual);
					if (!$rootScope.solicitudJson.banderaSeguro){
						$rootScope.solicitudJson.banderaSeguro = 0;
					}
					if ( capacidadPago >= 10 && $rootScope.solicitudJson.banderaSeguro != 1 ){
				    	$rootScope.waitLoaderStatus = LOADER_SHOW;
				    	
				    	
				    	if($rootScope.consultaFuncionalidad.habilitarFlujoSeguroVidamaxUnificado){
				    		var fechaNac =  $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento;
				    		var dma = fechaNac.split('/');
				    		var segFechaNacimiento = dma[2]+'-'+dma[1]+'-'+dma[0];
				    		var req = {
				    			tipoOferta : 1,
				    			origen : 4,
				    			cliente:{
				    				pais : $rootScope.solicitudJson.idPais,
				    				canal : $rootScope.solicitudJson.idCanal,
				    				sucursal : $rootScope.solicitudJson.idSucursal,
				    				folio :  $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico.split("-")[3],
				    				capacidadPagoDisponible: capacidadPago,
				    				fechaNacimiento: segFechaNacimiento
				    			},
				    			productoCredito : {
				    				montoVenta : $rootScope.solicitudJson.cotizacion.montoTotal,
				    				productoId : $rootScope.solicitudJson.idProducto,
				    				periodo : $rootScope.solicitudJson.cotizacion.idPeriodicidad,
				    				plazo : $rootScope.solicitudJson.cotizacion.plazo
				    			},
				    			seguro : {
				    				esPromocion : false,
				    				iva : $rootScope.consultaFuncionalidad.esFronteriza?0.8:0.16,
				    			},
				    			informacionBase : {
				    				ws : "",
				    				usuario : $rootScope.solicitudJson.idEmpleado,
				    				sucursal : $rootScope.solicitudJson.idSucursal,				    				
				    			}
				    		};
				    		
				    		$rootScope.loggerIpad("Invocar Servicio Seguros Vidamax Unificado", req);
				    		
				    		solicitudService.segurovidamaxUnificado( req ).then(
									function(data){										
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										if(data.data.codigo ==  RESPONSE_CODIGO_EXITO){
											if(!data.data.respuesta ||  JSON.parse(data.data.respuesta).tipoOfertaRespuesta != 1){
												$rootScope.pasoLiberacion = true;
												$scope.validaContratosEncolados(paso);
												$scope.surtirPorEjecutivo();
											}else{
											  var jsonResponse = JSON.parse(data.data.respuesta);
											
											
											var listaSeguros = {
													listaBeneficios : jsonResponse.seguros.listaBeneficios,
													listaPlanes : jsonResponse.seguros.lista,
													tasaSeguro : jsonResponse.seguros.tasaSeguro
											};
											
											if(listaSeguros){
												$rootScope.seguros = listaSeguros;	
												
												if($rootScope.seguros.listaPlanes){
													$scope.llamarDialogoSeg();
												}else{
													$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
													$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax Unificado", "Error Lista Planes: "+$rootScope.seguros.listaPlanes);
													$scope.validaContratosEncolados(paso);
													$rootScope.pasoLiberacion = true;
													$scope.surtirPorEjecutivo();
												}	
											}else{
												$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
												$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax Unificado", "Error Lista Seguros: "+ listaSeguros);
												$scope.validaContratosEncolados(paso);
												$rootScope.pasoLiberacion = true;
												$scope.surtirPorEjecutivo();
											}
										}
										}else{
											$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
											$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax", "Error Código Seguros: "+data.data.codigo);
											$scope.validaContratosEncolados(paso);
											$rootScope.pasoLiberacion = true;
											$scope.surtirPorEjecutivo();
										}
										
									}, function(error){
										$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax", "Error Servicio Seguros: "+error);
										$scope.validaContratosEncolados(paso);	
										$rootScope.pasoLiberacion = true;
										$scope.surtirPorEjecutivo();
									}
								);
				    		
				    	
				    	}else{			
				    	var req = {
				    			cu: $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
				    			aplicacion: 1,
				    			capacidadPago: capacidadPago,
				    			fechaNacimiento: $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento,
				    			iva: 16,
				    			plazo: $rootScope.solicitudJson.cotizacion.plazo,
				    			subArea: 1	    			
				    	};
				    	
				    	$rootScope.loggerIpad("Invocar Servicio Seguros Vidamax", req);
				    	
				    	tarjetaService.seguroVidamax( req ).then(
								function(data){
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									if(data.data.codigo == RESPONSE_CODIGO_EXITO){
										if(data.data.respuesta.listaSeguros){
											$rootScope.seguros = data.data.respuesta.listaSeguros[0];	
											
											if($rootScope.seguros.listaPlanes){
												$scope.llamarDialogoSeg();
											}else{
												$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
												$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax", "Error Lista Planes: "+$rootScope.seguros.listaPlanes);
												$scope.validaContratosEncolados(paso);
											}	
										}else{
											$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
											$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax", "Error Lista Seguros: "+data.data.respuesta.listaSeguros);
											$scope.validaContratosEncolados(paso);
										}
									}else{
										$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
										$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax", "Error Código Seguros: "+data.data.codigo);
										$scope.validaContratosEncolados(paso);
									}
									
								}, function(error){
									$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax", "Error Servicio Seguros: "+error);
									$scope.validaContratosEncolados(paso);	
								}
							);
				    	}
					}else{
						$scope.validaContratosEncolados(paso);
					}
				
				}
			}else{	
				$scope.validaContratosEncolados(paso);	
			}
		}
	    };
		
	    $scope.guardarContratos = function(consultaCu,contratos){
	    	$rootScope.solicitudJson.contratos.contrato=contratos;
	    	var contador = 0;
    		var firmadosDocs = 0;
			for(var i = 0; i < $rootScope.solicitudJson.contratos.contrato.length; i ++){
    			if ($rootScope.solicitudJson.banderaSolidario == 1){
    				contador++;
    				if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma != STATUS_CONTRATO.SIN_FIRMA){
    					firmadosDocs++;
    				}		    				
    			}else{
    				if ($rootScope.solicitudJson.contratos.contrato[i].idTipoPersona != 3){
	    				contador++;
	    				if ($rootScope.solicitudJson.contratos.contrato[i].statusFirma != STATUS_CONTRATO.SIN_FIRMA){
	    					firmadosDocs++;
	    				}	
    				}
    			}
    		}
    		$rootScope.solicitudJson.contratos.porcentaje = contador==0?0:parseInt(((firmadosDocs * 100) / contador).toFixed(0));
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	var solicitudJsonString = generalService.delete$$hashKey($rootScope.solicitudJson);							
	    	solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: SECCION_CONTRATOS } ).then(
	    		function(data){
//	    			if (!consultaCu)
	    				$rootScope.waitLoaderStatus = LOADER_HIDE;

	    			if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
	    				var responseJson = JSON.parse(data.data.respuesta);		
	    				if(responseJson.codigo == 2){
	    					$rootScope.solicitudJson = responseJson.data;
	    					$scope.validaEdicionSecciones();
	    					cargaVista();
	    					if (consultaCu){
	    						$scope.seguroVidamax();
	    					}else{	    						
	    						$scope.buildMenuList();
	    					}
	    				}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
							var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
							$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
						}else{
	    					$rootScope.waitLoaderStatus = LOADER_HIDE;
	    					if(responseJson.codigo == 137){
	    						var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
								var marca = $rootScope.solicitudJson.marca;
								var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
	    						generalService.buildSolicitudJson($rootScope, null);
	    						$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],
	    								"Aceptar", "/simulador");
	    					}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
								generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
								generalService.locationPath("/ficha");
							}else{
	    						$rootScope.message("Siete Pasos",["Error al guardar sección 8. Código " +
										    "de error [" + responseJson.codigo + "] no identificado."], "Aceptar", null, null, null);
							}
	    				}
	    			}else{
	    				$rootScope.waitLoaderStatus = LOADER_HIDE;
	    				$rootScope.message("Siete Pasos",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
	    			}
	    			
	    				
	    		}, function(error){
	    			$rootScope.waitLoaderStatus = LOADER_HIDE;
	    		}
	    	);	
	    }
	     
	    
	    $scope.consultaFolioCU = function() { 	    		    	
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	clienteUnicoService.consultaFolioCU({idSolicitud:$rootScope.solicitudJson.idSolicitud}).then(
	    			function(data) {
	    				$rootScope.waitLoaderStatus = LOADER_HIDE;
	    				
	    				if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
	    					var respuesta = JSON.parse(data.data.respuesta);
	    					
	    					if(respuesta.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO) {
	    						$rootScope.solicitudJson = respuesta.data;
	    						$scope.validaEdicionSecciones();
	    					} else if(respuesta.codigo == LCR_CLIENTE_CUENTA_CON_LCR) {
	    						generalService.setDataBridge({tipoFicha : FICHA.tipoFicha.bloqueada});
	    						generalService.locationPath("/ficha");
	    						return null;
	    					} else {
	    						switch(respuesta.codigo) {
	    							case FOLIO_CU_CODES.dbSaveError:
	    								// Error al guardar la solicitud en BD.
	    								$rootScope.message("ERROR", [respuesta.descripcion], 
	    									"Aceptar", "/simulador");
	    								break;
	    							case FOLIO_CU_CODES.UnexpectedError:
	    								// Error inesperado.
	    								$rootScope.message("ERROR", [respuesta.descripcion], 
		    								"Aceptar", "/simulador");
	    								break;
	    							case FOLIO_CU_CODES.ipAddressError:
	    								/*
	    								 * La dirección IP del servidor que realizó la petición
	    								 * no es válida.
	    								 */ 
	    								$rootScope.message("ERROR", [respuesta.descripcion], 
		    									"Aceptar", "/simulador");
	    								break;
	    							case FOLIO_CU_CODES.HomonimoQueryErr:
	    								// Ha ocurrido un error al consultar los homónimos.
	    								$rootScope.message("ERROR", [respuesta.descripcion], 
		    									"Aceptar", "/simulador");
	    								break;
	    							case FOLIO_CU_CODES.previoPrestaPren:
	    								/**
	    								 * Infórmale a tu cliente que no es posible generar su 
	    								 * solicitud de crédito en esta sucursal debido a que 
	    								 * ya tiene un producto de Presta Prenda asociado.
	    								 * La tienda que le corresponde es {sucursal}.
	    								 */
	    								$rootScope.message("AVISO", [respuesta.descripcion], 
		    									"Aceptar", "/simulador");
	    								break;
	    							case FOLIO_CU_CODES.getFolioCUError:
	    								// Error al consultar el servicio de Consulta Folio CU.
	    								$rootScope.message("ERROR", [respuesta.descripcion], 
		    									"Aceptar", "/simulador");
	    								break;
	    							case FOLIO_CU_CODES.previoLCRotrSuc:
	    								/**
	    								 * Infórmale a tu cliente que no es posible generar su 
	    								 * solicitud de crédito en esta sucursal debido a que 
	    								 * ya tiene una LCR asociada.
	    								 * La tienda que le corresponde es {sucursal}.
	    								 */
	    								$rootScope.message("AVISO", [respuesta.descripcion], 
		    									"Aceptar", "/simulador");
	    								break;
	    							case FOLIO_CU_CODES.waitXtime:
	    								/*
	    								 * Favor de esperar {días} días para generar una solicitud
	    								 * nueva.
	    								 */ 
	    								$rootScope.message("AVISO", [respuesta.descripcion], 
		    									"Aceptar", "/simulador");
	    								break;
	    							case FOLIO_CU_CODES.homonimoOtraSucc:
	    								/*
	    								 * Se encontró homónimo con una solicitud en proceso. Favor
	    								 * de acudir a la sucursal {sucursal}.
	    								 */
	    								$rootScope.message("AVISO", [respuesta.descripcion], 
		    									"Aceptar", "/simulador");
	    								break;
	    							case FOLIO_CU_CODES.homonimoExtranj:
	    								// Se encontró homónimo con cliente extranjero.
	    								$rootScope.message("AVISO", [respuesta.descripcion], 
		    									"Aceptar", "/simulador");
	    								break;
	    							default:
	    								$rootScope.message(
	    									"Folio CallCenter Error " + respuesta.codigo, 
    	    								[respuesta.descripcion], 
    	    								"Aceptar", null, null, null
	    	    						);
	    						}
	    							    						
	    						return null;
	    					}
	    				}
	    				
	    				$scope.validaCita();
	    			}, function(error) {
	    				$rootScope.waitLoaderStatus = LOADER_HIDE; 		                						
	    			}
	    	);
	    };
	    
	    
	    $scope.consultaFolioCUOS = function(paso) {
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	obligadoSolidarioService.consultaFolioCUOS({idSolicitud:$rootScope.solicitudOSJson.idSolicitud}).then(
	    			function(data) {
	    				$rootScope.waitLoaderStatus = LOADER_HIDE;
	    				
	    				if(data.data.codigo == RESPONSE_CODIGO_EXITO) {
	    					var respuesta = JSON.parse(data.data.respuesta);
	    					
	    					if(respuesta.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO) {
	    						$rootScope.solicitudOSJson = respuesta.data;
//	    						$scope.validaEdicionSecciones();
	    					} else {
	    						switch(respuesta.codigo) {
	    							case FOLIO_CU_CODES.dbSaveError:
	    								// Error al guardar la solicitud en BD.
	    							case FOLIO_CU_CODES.UnexpectedError:
	    								// Error inesperado.
	    							case FOLIO_CU_CODES.ipAddressError:
	    								/*
	    								 * La dirección IP del servidor que realizó la petición
	    								 * no es válida.
	    								 */ 
	    							case FOLIO_CU_CODES.HomonimoQueryErr:
	    								// Ha ocurrido un error al consultar los homónimos.
	    							case FOLIO_CU_CODES.getFolioCUError:
	    								// Error al consultar el servicio de Consulta Folio CU.
	    								$rootScope.message("ERROR", [respuesta.descripcion], 
	    									"Aceptar");
	    								break;
	    							case FOLIO_CU_CODES.previoPrestaPren:
	    								/**
	    								 * Infórmale a tu cliente que no es posible generar su 
	    								 * solicitud de crédito en esta sucursal debido a que 
	    								 * ya tiene un producto de Presta Prenda asociado.
	    								 * La tienda que le corresponde es {sucursal}.
	    								 */
	    							case FOLIO_CU_CODES.previoLCRotrSuc:
	    								/**
	    								 * Infórmale a tu cliente que no es posible generar su 
	    								 * solicitud de crédito en esta sucursal debido a que 
	    								 * ya tiene una LCR asociada.
	    								 * La tienda que le corresponde es {sucursal}.
	    								 */
	    							case FOLIO_CU_CODES.waitXtime:
	    								/*
	    								 * Favor de esperar {días} días para generar una solicitud
	    								 * nueva.
	    								 */ 
	    							case FOLIO_CU_CODES.homonimoOtraSucc:
	    								/*
	    								 * Se encontró homónimo con una solicitud en proceso. Favor
	    								 * de acudir a la sucursal {sucursal}.
	    								 */
	    							case FOLIO_CU_CODES.homonimoExtranj:
	    								// Se encontró homónimo con cliente extranjero.
	    							case FOLIO_CU_CODES.esObligado:
	    								// El cliente ya es un Coacreditado
	    								$scope.existeObligadoSolidario = false; 
	    								generalServiceOS.cleanRootScopeOS($rootScope);
	    								generalServiceOS.buildSolicitudOSJson($rootScope, null );
	    								$rootScope.message("AVISO COACREDITADO", [respuesta.descripcion], 
		    									"Aceptar","/ochoPasos");
	    								break;
	    							default:
	    								$rootScope.message(
	    									"Folio CallCenter Error " + respuesta.codigo, 
		    								[respuesta.descripcion], 
		    								"Aceptar");
	    						}
	    						return null;
	    					}
	    				}
	    				
	    				$scope.validaCitaOS(paso);
	    			}, function(error) {
	    				$rootScope.waitLoaderStatus = LOADER_HIDE; 		                						
	    			}
	    	);
	    };
	    
	    /*OFERTA 30 Dias*/
	    $scope.cambiarMarcaOferta30Dias = function(){
	    	
	    	var bandDoc = 0;
	    	for(var i=0;i<$rootScope.solicitudJson.documentos.documento.length;i++){
	    		if($rootScope.solicitudJson.documentos.documento[i].idDocumento == "3" && $rootScope.solicitudJson.documentos.documento[i].status == 5){
	    			bandDoc = 1;
	    			break;
	    		}
	    	}	    	
	    	
	    	if(bandDoc == 1){
	    		$scope.menuList[5].showMessageAuth = false;
				$scope.menuList[5].showAuth = false;
				$scope.menuList[5].messageAlert = "El documento esta rechazado, ingrese uno nuevo."
				$scope.menuList[5].showAlerta = true
	    	}else{	
		    	$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.autorizada.id;
				$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.docPendValidar;
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				
				solicitudService.actualizarSolicitud( $rootScope.solicitudJson ).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
	
							if(data.data.codigo != undefined){
								var responseJson = JSON.parse(data.data.respuesta);														
								
								if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									$scope.menuList[5].showMessageAuth = true;
									$scope.menuList[5].showAuth = true;
									
									$scope.terminoSolicitud = true;
									$scope.liberacion = "oferta30DiasAplicarOfertaHa";
									$scope.muestraTermometro = false;
								}else{
								}
							}else{
							}							
							
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 
			                modalService.alertModal("Error "+error.status, [error.statusText]);
							
						}
					);
	    	}
	    }
	    
	    $scope.actualizarCapacidadPago = function(){
	    	var bandDocumento = 0
	    	for(var i=0;i<$rootScope.solicitudJson.documentos.documento.length;i++){
	    		if($rootScope.solicitudJson.documentos.documento[i].idDocumento == COMP_INGRESOS.id && $rootScope.solicitudJson.documentos.documento[i].status == STATUS_VALIDADO){
	    			bandDocumento = 1;
	    			break;
	    		}
	    	}
	    	
	    	if(bandDocumento == 0){
	    		$scope.menuList[5].showMessageAuth = true;
				$scope.menuList[5].showAuth = true;
	    	}else{
		    	var solicitudJson = {
		    			jsonSolicitud: $rootScope.solicitudJson
		    	}
		    	$rootScope.waitLoaderStatus = LOADER_SHOW;
		    	
		    	solicitudService.capacidadPago( solicitudJson ).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
	
							if(data.data.codigo != undefined){
								var responseJson = JSON.parse(data.data.respuesta);														
								
								if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
									$rootScope.solicitudJson = responseJson.data;
									generalService.setDataBridge({ origen:FICHA.origen.recuperar, tipoFicha : FICHA.tipoFicha.predeterminada });
									
									generalService.locationPath("/ficha");
								}else{
									$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar");
								}
							}else{
								$rootScope.message("Aviso",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
							}							
							
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 
			                modalService.alertModal("Error "+error.status, [error.statusText]);
							
						}
					);
	    	}
	    }
	    
	    $scope.validarDocumentos = function(){
	    	var bandDoc = 0;
	    	for(var i=0;i<$rootScope.solicitudJson.documentos.documento.length;i++){
	    		if($rootScope.solicitudJson.documentos.documento[i].idDocumento == "3" && $rootScope.solicitudJson.documentos.documento[i].status == 5){
	    			bandDoc = 1;
	    			break;
	    		}
	    	}	    	
	    	
	    	if(bandDoc == 1){
	    		$scope.menuList[5].showMessageAuth = false;
				$scope.menuList[5].showAuth = false;
				$scope.menuList[5].messageAlert = "El documento Esta rechazado, escanee uno nuevo."
				$scope.menuList[5].showAlerta = true
	    	}else{
	    		$scope.menuList[5].showMessageAuth = true;
				$scope.menuList[5].showAuth = true;
				$scope.menuList[5].messageAlert = "Es necesario digitalizar la Identificación Oficial.";
				$scope.menuList[5].showAlerta = false;
	    	}
	    	
	    }
	    
	    /************/
	    
	    /* LOGICA NUEVO TERMOMETRO/COTIZADOR */
	    
	    $scope.condicionesMostrarTermometro=function(botonVolverCotizar){
	    	if(generalService.validarMostarTermometro($rootScope.solicitudJson)){
				if( generalService.validaConsultaBuro( $rootScope.solicitudJson )){
					if(MUESTRA_NUEVO_COTIZADOR && $scope.muestraTermometro){
//						$scope.muestraTermometro = true;
						$scope.muestraAlertasNuevoCotizador();
						if($rootScope.termometroHandler == BURO_RESPUESTAWS_OK){
							if(( ($rootScope.solicitudJson.marca != 93 && $rootScope.solicitudJson.marca != 104 && $rootScope.solicitudJson.marca != 103)  && $rootScope.solicitudJson.banderaOfertaCP == 0 && $rootScope.onceOfert)||botonVolverCotizar){						
								$scope.muestraModalCotizador();			
							}else if($rootScope.mostrarOfertaCotizador)
								$scope.muestraModalCotizador();		
						}else{
							if(botonVolverCotizar)
								$scope.reintentarConsultaBuro();
						}
					}
					if(MUESTRA_TERMOMETRO){
						if( $rootScope.termometroHandler == BURO_RESPUESTAWS_OK )
							TermometroController.inheritProperties( $scope );
						else
							TermometroController.errorLoad( $scope );
					}
				}
				if(MUESTRA_TERMOMETRO)
					TermometroController.filtrosOferta( $scope );
			}else if($rootScope.termometroHandler == BURO_RESPUESTAWS_OK &&  generalService.isCanalExterno($rootScope.sucursalSession.idCanal)  /*&& generalService.isProdModatelas($rootScope)*/ )
				$scope.validarRespuestaBuroCanalExterno();	
	    }
				
	    var ofertaTarjetasSIPAyPREAPROB = function () {
	     	modalService.tarjetaModal("Cotizador", "bgAzul",$scope).then(
	    		function(estatus) {
	    			console.log("ok");
	    			$scope.calculaCPConsumo();
	    			$scope.validaEdicionSecciones();
	    		}, function(exito) {
	    			if(exito){
	    				$scope.muestraAlertasNuevoCotizador();
	    				$timeout( loadProgressbar, 0 );
	    				$scope.calculaCPConsumo();
	    				$scope.validaEdicionSecciones();
	    			}else{
	    				$scope.rechazarOferta();
	    			}
	    		}
	    	);
	     };
	     
		var rescateCreditoEnEfectivo = function(){			
			$scope.muestraBoton = false;
			$scope.muestraAlertaNuevoBuro=false;
			$scope.muestraMensajeNuevoBuro=false;
			
			modalService.rescateCreditoEnEfectivo("En Banco Azteca le decimos CÓMO SÍ a nuestros clientes", $rootScope.solicitudJson.marca ).then(			
				function(estatus) {																												
					console.log("ok");
					if($rootScope.solicitudJson.idProducto!=ID_PRODUCTO.prestamoPersonal)
						$scope.showResumenMonto = false;
					$scope.calculaCPConsumo();
					$scope.validaEdicionSecciones();
					$scope.buildMenuList();
				}, function(exito) {
					if(exito){
						if($rootScope.solicitudJson.idProducto!=ID_PRODUCTO.prestamoPersonal)
							$scope.showResumenMonto = false;
						$scope.muestraAlertasNuevoCotizador();
						$timeout( loadProgressbar, 0 );
						$scope.calculaCPConsumo();
						$scope.validaEdicionSecciones();
						$scope.buildMenuList();
					}
				}
			);
	    };

	     
	     var ofertaFlujoClienteNuevo = function () {
	    	 if ($rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal){
	     		if($rootScope.buroHandler != null && $rootScope.buroHandler.length > 0){
	    			modalService.cotizadorModalML("Cotizador", "bgAzul",$scope).then( 
	    				function(estatus) {																												
	    					console.log("ok");
	    					$scope.calculaCPConsumo();
	    					$scope.validaEdicionSecciones();							
	    					/** INICIA_OS-FLUJO COACREDITADO **/
	    					/**Validación para construir el menu con la opcion del Coacreditado
	    					 * Coacreditado NF	
	    					 **/
	    					validaOfertaOS();
	    					/** TERMINA_OS-FLUJO COACREDITADO **/
	    				}, function(exito) {
	    					if(exito){
	    						$scope.muestraAlertasNuevoCotizador();
	    						$timeout( loadProgressbar, 0 );
	    						$scope.calculaCPConsumo();
	    						$scope.validaEdicionSecciones();							
	    						/** INICIA_OS-FLUJO COACREDITADO **/
	    						/**
	    						 * Validación para construir el menu con la opcion del Coacreditado
	    						 * Coacreditado NF	
	    						 **/										
	    						validaOfertaOS();
	    						/** TERMINA_OS-FLUJO COACREDITADO **/
	    					}
	    				}
	    			);
	    		}else
	    			$scope.reintentarConsultaBuro();
	     	} else {
	     		modalService.cotizadorModalMLC("Cotizador", "bgAzul",$scope).then( 
	    			function(estatus) {																												
	    				console.log("ok");
	    				$scope.calculaCPConsumo();
	    				$scope.validaEdicionSecciones();
	    				/** INICIA_OS-FLUJO COACREDITADO **/
	    				/**Validación para construir el menu con la opcion del Coacreditado
	    				 * Coacreditado NF	
	    				 **/
	    				validaOfertaOS();
	    				/** TERMINA_OS-FLUJO COACREDITADO **/
	    			}, function(exito) {
	    				if(exito){
	    					$scope.muestraAlertasNuevoCotizador();
	    					$timeout( loadProgressbar, 0 );
	    					$scope.calculaCPConsumo();
	    					$scope.validaEdicionSecciones();
	    					/** INICIA_OS-FLUJO COACREDITADO **/
	    					/**Validación para construir el menu con la opcion del Coacreditado
	    					 * Coacreditado NF	
	    					 **/
	    					validaOfertaOS();
	    					/** TERMINA_OS-FLUJO COACREDITADO **/
	    				}
	    			}
	    		);
     		}
	     }

	     $scope.muestraModalCotizador=function(){
	     	/*Inicia bloque que evalua si tiene algún tag de camapana\*/
	     	if( !generalService.isEmpty($rootScope.solicitudJson.campana) ){
	     		if($rootScope.campanasConvivencia($rootScope.solicitudJson.campana)){
	    			if($rootScope.solicitudJson.banderaOfertaCP == 0 || $rootScope.solicitudJson.banderaOfertaCP == 1 || $rootScope.modalConvivenviaDesdeBuro == true){
	    				$rootScope.waitLoaderStatus = LOADER_SHOW;
	    				$rootScope.modalConvivenviaDesdeBuro = false;
	    				$rootScope.consultarStatusLCR($rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico, constantesTDC.TIPO_CONSULTA.consultarStatusSolicitudYLCR, $rootScope.solicitudJson.idSolicitud);
//	    				setTimeout(function(){$rootScope.consultarStatusLCR($rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico, constantesTDC.TIPO_CONSULTA.consultarStatusSolicitudYLCR, $rootScope.solicitudJson.idSolicitud)},1000);
	    			}
	    		} else if ( $rootScope.productosTarjetas($rootScope.solicitudJson.idProducto) ){
	     			ofertaTarjetasSIPAyPREAPROB();
	     		} else if($rootScope.campanaNvoPreaprob($rootScope.solicitudJson.campana)){
		  			$scope.nvoPreaprobados();
	     		}else if( $rootScope.productosSIPA($rootScope.solicitudJson.idProducto) && $rootScope.campanasSipa($rootScope.solicitudJson.campana) ){
	     			if( $rootScope.consultaFuncionalidad.habilitarPromocionesBuenFin ){
	     				/*Si es SIPA y esta habilitada la promoción con tasas especiales y se debe ver un comparativo en el modal\*/
	     				$scope.ofertaPreaprob();
	     			}
	     		} else if( $rootScope.campanasPreaprobadosCaptacion($rootScope.solicitudJson.campana) ){
	     			if( $rootScope.consultaFuncionalidad.habilitarPromocionesBuenFin ){
	     				/*Si es PREAPROB y esta habilitada la promoción con tasas especiales y se debe ver un comparativo en el modal\*/
	     				$scope.ofertaPreaprob();
	     			}else{
	     				ofertaTarjetasSIPAyPREAPROB();
	     			}
	     		} else if( $rootScope.solicitudJson.campana == CAMPANAS_REACTIVADOS.winback ){
	     			ofertaFlujoClienteNuevo();//El modal de winback esta en el modal de cliente nuevo, dentro de este se evalua si tiene la campaña y si la bandera funcionalidad sucursal esta prendida para mostrarla
	     		}/*else if( $rootScope.campanaDUAL($rootScope.solicitudJson.campana) ){
	    				ofertaPreaprobDualyCONSUMO();
	    		} else if( $rootScope.campanaCONSUMO($rootScope.solicitudJson.campana) ){
	    				ofertaPreaprobDualyCONSUMO();
	    		}*/
	     	/*Finaliza bloque que evalua si tiene algún tag de camapana\*/
	     	}
	     	/*Inicia bloque que evalua si es Rescate\*/
	     	else if(generalService.esCandidatoRescateItalika($rootScope.solicitudJson.marca)){
	    		$scope.rescateItalika();
	    	}else if(generalService.esCandidatoRescateTelefonia($rootScope.solicitudJson.marca)){
	    		$scope.rescateTelefonia();
	    	}else if(generalService.esCandidatoRescateConsumo($rootScope.solicitudJson.marca)){
	    		$scope.rescateConsumo();
	     	}else if(generalService.esCandidatoRescatePrestamoFaseII($rootScope.solicitudJson.marca)){
	     			if($rootScope.solicitudJson.banderaOfertaCP == 0)
	     				$scope.rescatePrestamoFaseII();
			}else if(generalService.esCandidatoRescatePrestamo($rootScope.solicitudJson.marca)){
				if($rootScope.solicitudJson.banderaOfertaCP == 0)
					$scope.rescatePrestamo();
			}else if(generalService.esCandidatoRescateConsumoFaseIII($rootScope.solicitudJson.marca)){
					if($rootScope.solicitudJson.banderaOfertaCP == 0){
						switch($rootScope.solicitudJson.idProducto){
							case PRODUCTOS.consumo.ID.valor:
								$scope.rescateConsumoFaseIII();
								break;
							case PRODUCTOS.italika.ID.valor:
								$scope.rescateItalikaFaseIII();
								break;
							case PRODUCTOS.telefonia.ID.valor:
								$scope.rescateTelefoniaFaseIII();
								break;
							default:
								generalService.buildSolicitudJson($rootScope, null);
								$rootScope.message("Error ",["No es posible otorgar Rescate"], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
						}
					}
			}else if( generalService.esCandidatoRescateCreditoEnEfectivo($rootScope.solicitudJson.marca, $scope.esRescate) )
						rescateCreditoEnEfectivo();
		     	/*Finaliza bloque que evalua si es Rescate\*/
	     	else {
	     		/*Inicia bloque que evalua las condiciones del flujo Normal\*/
	     		if(!$rootScope.rescatePPGarantias && !$rootScope.rescatePPObligado)
	     			ofertaFlujoClienteNuevo();
	     		/*Finaliza bloque que evalua las condiciones del flujo Normal\*/
	     	}
	    };
	    
	    $scope.muestraAlertasNuevoCotizador=function(botonVolverCotizar){
	    	/* Si MCO autoriza una solicitud con (Ingresos comprobables o No comprobables) entonces se le pide al usuario que seleccione
	    	 *  nuevamente la alternativa de acuuerdo a la CDP que MCO le asignó 
	    	 *  */
	    	if($rootScope.solicitudJson.ofertaSeleccionadaMCO == 1){
	    		$scope.muestraAlertaNuevoBuro=true;
				$scope.muestraMensajeNuevoBuro=true;
				$scope.mensajeNuevoBuro="Favor de volver a cotizar"
				if(botonVolverCotizar)
					$scope.reintentarConsultaBuro();
	    	}else if($rootScope.termometroHandler == BURO_RESPUESTAWS_OK){
				switch( $rootScope.buroConditional ){
				case BURO_RECALCULAR_PLAZO:
				case BURO_AUTORIZADO_PORCOMPROBAR:
					$scope.muestraAlertaNuevoBuro=true;
					$scope.muestraMensajeNuevoBuro=true;
					$scope.mensajeNuevoBuro="Favor de volver a cotizar"
					break;
				default:
					$scope.muestraAlertaNuevoBuro=false;
					$scope.muestraMensajeNuevoBuro=false;
					$scope.mensajeNuevoBuro=""
				break;
				}
			} else if($rootScope.solicitudJson.marca == 1059 || $rootScope.solicitudJson.marca == 1057 || $rootScope.muestraObligadoSolidario) { /** INICIA_OS-FLUJO COACREDITADO **/ /** TERMINA_OS-FLUJO COACREDITADO **/
				$scope.muestraAlertaNuevoBuro=false;
				$scope.muestraMensajeNuevoBuro=false;
				$scope.mensajeNuevoBuro="";
			}else{
				$scope.muestraAlertaNuevoBuro=true;
				$scope.muestraMensajeNuevoBuro=true;
				$scope.mensajeNuevoBuro="Favor de volver a cotizar"
				if(botonVolverCotizar)
					$scope.reintentarConsultaBuro();
			}
	    };
	    
	    $scope.validaContinuarNuevoCotizador=function(){
			if($rootScope.termometroHandler == BURO_RESPUESTAWS_OK){
				switch( $rootScope.buroConditional ){
					case BURO_RECALCULAR_PLAZO:
					case BURO_AUTORIZADO_PORCOMPROBAR:
						return false;
					break;
					case BURO_AUTORIZADO_SCORE:
					case RESPONSE_ORIGINACION_CODIGO_EXITO:
						return true;
					break;
				}
			}else
				return false;
	    };
	    
	    $scope.reintentarConsultaBuro=function(){
			var cuerpoDlg=["No fue posible evaluar al cliente. ¿Desea volver a intentarlo?"];
			
			modalService.confirmModal("Notificación",cuerpoDlg, "Intentarlo más tarde", "Si", "bgAzul", "btn gris", "btn azul" ).then(
					function(exito){
						var consultaBuro=null;
						var foo =  function( typeAuth ){
							$scope.muestraAlertaNuevoBuro=false;
							$scope.muestraMensajeNuevoBuro=false;
							$rootScope.buroConditional= typeAuth ? typeAuth : $rootScope.buroConditional;
							if(!generalService.cambaceoPrecalificado($rootScope.solicitudJson.marca)){
								$scope.muestraModalCotizador();
							}					
						};
						if( $rootScope.solicitudJson.consultaBuro == 0 )
							consultaBuro = 1; // Consulta Buro
						else if( $rootScope.solicitudJson.consultaBuro == 1 && $rootScope.solicitudJson.consultaMatriz == 0 )
							consultaBuro = 0; //Consulta matriz
						else if( $rootScope.solicitudJson.consultaBuro == 1	&& $rootScope.solicitudJson.consultaMatriz == 1 && ($rootScope.buroHandler != null && $rootScope.buroHandler.length > 0))
								buroService.getMontosPlazos( $rootScope.solicitudJson.idSolicitud, foo );
							else
								consultaBuro = 1; // Consulta Buro
						if(consultaBuro==1 || consultaBuro==0)
							buroService.consultaBuro( "bgVerde", "btn gris", "btn verde", null, null, consultaBuro, foo );									
					},function(error){
						$scope.muestraAlertaNuevoBuro=true;
						$scope.muestraMensajeNuevoBuro=true;
						$scope.mensajeNuevoBuro="Favor de volver a cotizar"							
					}
			 );
	    };
	    /* END LOGICA NUEVO TERMOMETRO */
	    
	    
/** INICIA_OS-FLUJO COACREDITADO **/ 
	    
	    /**Funcion que consulta Montos y Plazos y detona la oferta con base a esta respuesta
	     * Coacreditado NF	3
	     **/
	    function consutaMontosPlazos(){
	    		$rootScope.consultaBuroOS = true;
			
			var foo =  function( typeAuth ){
				if( typeAuth ){
    					
					$rootScope.solicitudJson = typeAuth.data.solicitud;
					
	    				if( typeAuth.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ||  typeAuth.codigo == BURO_RECALCULAR_PLAZO ||  
	    					typeAuth.codigo == BURO_AUTORIZADO_PORCOMPROBAR || typeAuth.codigo == BURO_AUTORIZADO_SCORE ){
	    					
	    					$rootScope.buroHandler = typeAuth.data.plazosTermometro;
	    					$rootScope.capacidadesPagoProducto = typeAuth.data.capacidadesPagoProducto;
	    					
	    					if(generalService.sobrescribeOfertaBuroConsumo($rootScope.solicitudJson))			         
	    						$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO;
	    					else
	    						$rootScope.buroConditional = typeAuth.codigo;
	        				
	    					$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
	        							                				
	    				}else{
	    					$rootScope.buroHandler = [];
	        				$rootScope.buroConditional = -1;
	        				$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
	    				}
    				}else{
    					$rootScope.buroHandler = [];
    					$rootScope.buroConditional = -1;
    					$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
    				}	

				$scope.muestraModalCotizador();							
			};
			
			buroService.getMontosPlazos( $rootScope.solicitudJson.idSolicitud, foo );
	    }
	    
/** TERMINA_OS-FLUJO COACREDITADO **/
	    
	    
	    /*GUARDAR SECCION DE SEGURO*/
	    $scope.guardaSeccionSeguro = function(banderaCierra){
	    	var seccionContratos=$rootScope.solicitudJson.contratos.contrato;
	    	var solicitudJsonString = generalService.delete$$hashKey($rootScope.solicitudJson);
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
		    solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: SECCION_SEGUROS } ).then(
		    		function(data){
		    			$rootScope.waitLoaderStatus = LOADER_HIDE;
		    			
		    			if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
		    				var responseJson = JSON.parse(data.data.respuesta);							
		    				if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
		    					$rootScope.solicitudJson = responseJson.data;	
		    					generalService.setRespaldo($rootScope.solicitudJson);
		    					$scope.guardarContratos(false,seccionContratos);

		    				}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
								var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
								$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
							}else{
		    					if(responseJson.codigo == ERROR_SOL_RECHAZADA){
		    						var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
									var marca = $rootScope.solicitudJson.marca;
									var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
		    						$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],
		    								"Aceptar", "/simulador",null,null,buildJsonDefault);
		    					}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
									generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
									generalService.locationPath("/ficha");
								}else{									
		    						$rootScope.message("Seguro VidaMax",["Error al guardar sección 11. Código " +
										    "de error [" + responseJson.codigo + "] no identificado."], "Aceptar", null, null, null);
								}
		    				}
		    			}else{		    				
		    				$rootScope.message("Seguro VidaMax",[generalService.displayMessage(data.data.descripcion)], "Aceptar", null, null, null);
		    			}
		    			
		    		}, function(error){
		    			$rootScope.waitLoaderStatus = LOADER_HIDE;
		    		}
		    );	
	    }
	    /*TERMINA GUARDAR SECCION DE SEGURO*/
	    
	    //LLAMAR DIALOGO DE  SEGUROS
	    $scope.llamarDialogoSeg = function(paso){
	    	modalService.seguro("bgazul")
			.then(
					function(exito){
						generalService.forceCloseModal();
						var index2 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
							return d["idContrato"];
					    			
						}).indexOf (FIRMA_SEGURO_CLIENTE.id);
						if (index2 != -1){
							if ($rootScope.solicitudJson.contratos.contrato[index2].statusFirma != 0){
								$scope.validaContratosEncolados(paso);
																																						
							}else{
								$scope.validaHuellaSeguro();
							}
						}else{
							if (index2 == -1){
								$rootScope.solicitudJson.contratos.contrato.push( 
										{idContrato: FIRMA_SEGURO_CLIENTE.id,
											idPersona: "",
											statusFirma: 0,
											descripcion: FIRMA_SEGURO_CLIENTE.etiqueta,
											idTipoPersona: 1
										});
							}
							
							var index2 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
								return d["idContrato"];
								
							}).indexOf (FIRMA_SEGURO_CARTA.id);
							if (index2 == -1){
								$rootScope.solicitudJson.contratos.contrato.push( 
										{idContrato: FIRMA_SEGURO_CARTA.id,
											idPersona: "",
											statusFirma: 0,
											descripcion: FIRMA_SEGURO_CARTA.etiqueta,
											idTipoPersona: 1
										});
							}
							
							$scope.validaHuellaSeguro();
						}
						
					},function(error){
						generalService.forceCloseModal();
						$scope.menuList= [];
						$scope.showPage= false;
						$scope.init();
						$scope.validaContratosEncolados(paso);
					});
	    }
	    
	    // FIN LLAMADO DE DIALOGOSEGUROS
	    //VALIDA HUELLA SEGURO
	    $scope.validaHuellaSeguro = function()
		{
	    	$rootScope.loggerIpad("verificarHuellaSeg", "validaHuellaSeguro");
			if(configuracion.origen.tienda && TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) == -1){
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$rootScope.verificarHuella( 'ochoPasosDivId', 'responseVerificarHuellaIpadSeg',[$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico] );
			}else
				$scope.responseVerificarHuellaIpadSeg( {codigo:0, matches:["OK"]} );
			
		};
	    //FIN VALIDA HUELLA SEGURO
		
		$scope.responseVerificarHuellaIpadSeg = function( response ){
			$rootScope.loggerIpad("responseVerificarHuellaIpadSeg", null, response);
			if(response.codigo == RESPONSE_CODIGO_EXITO_IPAD){
				$scope.guardaSeccionSeguro();
			}else{				
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$scope.llamarDialogoSeg();
			}									
				
		};/* END RESPONSE VERIFICAR HUELLA IPAD FUNCTION */
		
	    
		// I-MODIFICACION TDC ( CUENTAS PARA DOMICILIAR )		
		$scope.getCtas = function(){ 
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			var cu = $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico;								
			var cuArray = cu.split('-');
			 var x = {
					 paisClienteUnico: cuArray[0],
					 canalClienteUnico: cuArray[1],
					 centroClienteUnico: cuArray[2],
					 folioClienteUnico: cuArray[3],
					 ticketYakana: generalService.getArrayValue('ticket')
					 
			 }
		    tarjetaService.consultaCuentasTarjetas(x).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
								var j = JSON.parse(data.data.respuesta);
//								modalService.alertModal("OK "+j.codigo, [JSON.stringify(j.data)]);	
								$scope.cuentasDomiciliar = $scope.vaciarListaCuentas($scope.validaCuentas(j));
								if ($scope.cuentasDomiciliar.length > 0)
									$scope.modalDomiciliacion();
								else
									generalService.locationPath($scope.pathTarjetas);
//									$scope.modalDomiciliacion();
							}else{
								$rootScope.message("Siete Pasos",["Por el momento no podemos consultar las cuentas para domiciliar el pago de su tarjeta, favor de continuar"], "Aceptar", $scope.pathTarjetas);
//								generalService.locationPath("/liberacion");
							}
							
						}, function(error){
			                $rootScope.waitLoaderStatus = LOADER_HIDE; 
			                validateService.error(error);
							
						}
					);
		    };
		    
		    $scope.validaCuentas = function(respuesta){
				var cuentas = [];
				for (var i = 0; i < respuesta.length; i++){
					for (var e = 0 ; e < respuesta[i].entidad.length; e++){
						cuentas.push(respuesta[i].entidad[e]) ;
					}
				}
				console.log(cuentas);
				return cuentas;
			}
		    
		$scope.modalDomiciliacion = function(){
			if (configuracion.origen.tienda)
				$rootScope.validarTienda = true;
			else
				$rootScope.validarTienda = false;
		    $scope.tituloAviso = {texto:"Domiciliación pago de tarjeta de Crédito "+ $rootScope.camelize( $rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc )};
		    $rootScope.isfirmaDomiciliar = true;
          	$scope.tituloFirma = "Firma Domiciliación pago de tarjeta de Crédito "+ $rootScope.camelize( $rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc );              	              	
          	$scope.urlDoc = "domiciliacion.html";              	              	
          	$rootScope.title = "Domiciliación pago de tarjeta de Crédito "+ $rootScope.camelize( $rootScope.descTarjetas($rootScope.solicitudJson.idProducto).desc );
          	$scope.negacionCheck = {texto:"", visible: false, textoMensaje:" la Contrato de Crédito.", botonAceptar: "Aceptar", cuentas: $scope.cuentasDomiciliar} 
		
//			$timeout( function(){
//				construirIframe();
//			}, 100 );
			
			$scope._btnNoAceptar = generalService.getDataInput("CONTRATOS","BOTON NO ACEPTAR", $scope.origen);
			$scope._btnAceptar = generalService.getDataInput("CONTRATOS","BOTON ACEPTAR", $scope.origen);
			$scope.txtModalContratos = generalService.getDataInput("CONTRATOS","TEXTO MODAL CONTRATOS", $scope.origen);
			
			var imagenesArray = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";				
			$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
							
				
			modalService.pdfViewModal($scope.urlDoc, $scope.tituloAviso.texto, $scope._btnAceptar.texto, "Cerrar", null, $scope._btnAceptar.estilo, null, true, $scope.esContratos, $scope.contratosAceptados, 0, $scope.txtModalContratos,imagenesArray, $scope.muestraAvisos, $scope.negacionCheck )
							.then(
									function(aceptar){
										$rootScope.isfirmaDomiciliar = false;
										$rootScope.archivafirmasTarjeta(true, $rootScope.firmaDomiciliar);
										generalService.locationPath($scope.pathTarjetas);
										$scope.addOverflow();
									},function(noaceptar){
										$rootScope.isfirmaDomiciliar = false;
										$scope.addOverflow();
									}
								);				
		};
	
	
	$scope.addOverflow=function(){
		$( "html" ).removeClass( "overflowHiddenHTML");
		$( "body" ).addClass( "overflowInitialHTML");
	}
		   
	
	 //VALIDA HUELLA SEGURO
    $scope.validaHuellaLiberacionTDC = function(path){
    	$scope.pathTarjetas = path;
    	$rootScope.loggerIpad("validaHuellaLiberacionTDC", "validaHuellaLiberacionTDC");
		if(configuracion.origen.tienda && TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) == -1){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$rootScope.verificarHuella( 'ochoPasosDivId', 'responseVerificarHuellaIpadTDC',[$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico] );
		}else
			$scope.responseVerificarHuellaIpadTDC( {codigo:0, matches:["OK"]} );
	};
    //FIN VALIDA HUELLA SEGURO
	
	$scope.responseVerificarHuellaIpadTDC = function( response ){
		$rootScope.loggerIpad("responseVerificarHuellaIpadTDC", null, response);
		try{
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			if(response.codigo == 0 && response.matches.length > 0)						
				$scope.getCtas();
			else
				$rootScope.message("Siete Pasos", [response.mensaje], "Aceptar", null, null, null);
		}catch(e){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			$rootScope.message( "Error al verificar la huella", [e], "Aceptar", null, null, null);
		}
												
	};/* END RESPONSE VERIFICAR HUELLA IPAD FUNCTION */
		
	//TODO: 
 	$scope.rechazarOferta = function(){
//I - MODIFICACION PARA CLIENTES PRE APROBADOS CAPTACION
 		var mensaje = "¿Estás seguro de que el Cliente no Acepta ";
 		mensaje += $rootScope.solicitudJson.idProducto==PRODUCTOS.prestamoPersonal.ID.valor?"el Prestamo Personal?":"la Tarjeta de Crédito?";
//F - MODIFICACION PARA CLIENTES PRE APROBADOS CAPTACION
 		modalService.confirmModal("Notificación",[mensaje], "Si", "No", "bgAzul", "btn gris", "btn azul" ).then(
				function(exito){
					$scope.muestraModalCotizador();
				},function(error){
					console.log("Quemar Folio");
					$scope.quemarFolioPreaprobado(false)
				}
		 );
 	};
 	
 	/*$scope.rechazarOferta_DUAL_CONSUMO = function(){
 		var mensaje = "¿Estás seguro de que el Cliente no Acepta ";
	 	mensaje += "el Crédito Preaprobado?";	
 		modalService.confirmModal("Notificación",[mensaje], "Si", "No", "bgAzul", "btn gris", "btn azul" ).then(
				function(exito){
					$scope.muestraModalCotizador();
				},function(error){
					console.log("Quemar Folio");
					$scope.quemarFolioPreaprobado(false)
				}
		 );
	 };*/
	
 	$scope.quemarFolioPreaprobado = function(bandera){ 
		$rootScope.waitLoaderStatus = LOADER_SHOW;
		var cteUco = $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico.split("-");
		var quitarCampana = function (){
			x = {idSolicitud: $rootScope.solicitudJson.idSolicitud};
			solicitudService.quitarCampana( x ).then(
	 			function(data){
	 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
	 					var responseJson = JSON.parse(data.data.respuesta);
	 					if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
	 						$rootScope.solicitudJson = responseJson.data;
	 						//Se vuelve a validar el boton ya que el Json se acutalizo
	 						$scope.mostrarGeneraCita = !$scope.validareactivado() && !($rootScope.productosSIPA($rootScope.solicitudJson.idProducto)  && $rootScope.promocionCampanas($rootScope.solicitudJson.campana)) && !$rootScope.productosTarjetas($rootScope.solicitudJson.idProducto);
	 						$scope.condicionesLiberacion();
	 						$scope.muestraModalCotizador();
						}else {
							$rootScope.message("Error al rechazar la oferta ",[ $scope.mensajeError], "Aceptar", null);
						}
	 				}else{
	 					$rootScope.message("Error",[generalService.displayMessage(data.data.descripcion)], "Aceptar");
	 				}
	 			}, function(error){                     
	 				$rootScope.waitLoaderStatus = LOADER_HIDE;
	 				$rootScope.message("Error al rechazar la oferta ",[ $scope.mensajeError], "Aceptar", null);								
	 			}	
			);
		}
		 var x = {	pais: cteUco[0],
				 	canal: cteUco[1],
				 	sucursal: cteUco[2],
				 	folio: cteUco[3],
				 	statusPromo: bandera ? QUEMAR_FOLIO_STATUS.aceptado : QUEMAR_FOLIO_STATUS.rechazado
				 	};
	    tarjetaService.quemarFolioPreaprobado(x).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						//var j = JSON.parse(data.data.respuesta);
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							if(bandera){
								console.log("Folio Quemado con Status de \"Aceptado\" correctamente");
							}else{
								//j = JSON.parse(j.data);
								//I - MODIFICACION PARA CLIENTES PRE APROBADOS CAPTACION							
								if($rootScope.productosTarjetas( $rootScope.solicitudJson.idProducto)){
									solicitudService.cancelarSolicitud({idSolicitud:$rootScope.solicitudJson.idSolicitud});
									$scope.reiniciaCotizacion();
								}else if($rootScope.campanasPreaprobadosCaptacion($rootScope.solicitudJson.campana)){
									quitarCampana();
								}else if( $rootScope.productosSIPA($rootScope.solicitudJson.idProducto) && $rootScope.campanasSipa($rootScope.solicitudJson.campana) ){
									$rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto = parseInt($rootScope.solicitudJson.observaciones);
									$rootScope.solicitudJson.consultaBuro = 0;
									$rootScope.solicitudJson.consultaMatriz = 0;
									
									solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($rootScope.solicitudJson), seccion: SECCION_SOLICITUD } ).then(
								 			function(data){
								 				$rootScope.waitLoaderStatus = LOADER_HIDE;
								 				if( data.data.codigo == RESPONSE_CODIGO_EXITO ){
								 					var responseJson = JSON.parse(data.data.respuesta);
								 					$rootScope.solicitudJson = responseJson.data;
								 					quitarCampana();
								 				}	
								 			}, function(error){                     
								 				$rootScope.waitLoaderStatus = LOADER_HIDE;
								 				$rootScope.message("Aviso ", ["Inconveniente al actualizar la solicitud. Favor de volver a intentar"],"Aceptar", "/simulador");								
								 			}	
										);
								}/*else if($rootScope.campanaDUAL($rootScope.solicitudJson.campana) || $rootScope.campanaCONSUMO($rootScope.solicitudJson.campana)){
									//Si la campana que se rechazo era DUAL o CONSUMO, se pone una marca que indique esto
		 							var jsonActualizaMarca = {
										  idSolicitud : $rootScope.solicitudJson.idSolicitud,
										  idSeguimiento: $rootScope.solicitudJson.idSeguimiento,
										  marca: $rootScope.campanaDUAL($rootScope.solicitudJson.campana) ? MARCAS_SOLICITUD.clienteNoAceptaCDPCampanaDUAL : MARCAS_SOLICITUD.clienteNoAceptaCDPCampanaCONSUMO 
									};
									solicitudService.actualizarSolicitud(jsonActualizaMarca).then(
										function(data){
											if(data.data.codigo == RESPONSE_CODIGO_EXITO){
												$rootScope.waitLoaderStatus = LOADER_HIDE;
												var response = JSON.parse(data.data.respuesta);	
												if(response.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
													quitarCampana();
												}else{
													generalService.cleanRootScope($rootScope);							
													generalService.buildSolicitudJson($rootScope, null);
													$rootScope.message("Aviso ", ["Inconveniente al actualizar la solicitud. Favor de volver a intentar"], "Aceptar", "/simulador");
												}
											}else{
												$rootScope.waitLoaderStatus = LOADER_HIDE;
												generalService.cleanRootScope($rootScope);							
												generalService.buildSolicitudJson($rootScope, null);
												$rootScope.message("Aviso ", ["Inconveniente al actualizar la solicitud. Favor de volver a intentar"], "Aceptar", "/simulador");
											}								
										}, function(error){
											 $rootScope.waitLoaderStatus = LOADER_HIDE;
											 generalService.cleanRootScope($rootScope);							
											 generalService.buildSolicitudJson($rootScope, null);
											 $rootScope.message("Aviso ", ["Inconveniente al actualizar la solicitud. Favor de volver a intentar"], "Aceptar", "/simulador");				
										}
									)
			 					}*/
							}							
						}else
							modalService.alertModal("AVISO", [data.data.descripcion]);	
					}, function(error){
		                $rootScope.waitLoaderStatus = LOADER_HIDE; 
		                validateService.error(error);
						
					}
				);
	    };	
	    
	    $scope.vaciarListaCuentas = function(listaCuentas) {
			$scope.respuestaCuentas = [];
			for ( var indexCuenta in listaCuentas) {
                if (listaCuentas[indexCuenta].descripcion.toUpperCase().indexOf("GUARDADITO") != -1) {
                	$scope.respuestaCuentas.push(listaCuentas[indexCuenta]);
                }
			}
			return $scope.respuestaCuentas;
		};/* END VACIAR LISTA CUENTAS FRUNCTION */
		
			    
/*====================== INICIA COACREDITADO LIBERACIÓN  ======================*/
	    /** La siguiente función actaliza la marca a pendiente de digitalizar **/
	    		
	    		/**Se verifica el porcentaje de la sección de Coacreditado si es que existe **/
		$scope.porcentajeObligado = function(){
			
			 $scope.cotizar = ( $rootScope.solicitudOSJson.consultaBuro == 1 && $rootScope.solicitudOSJson.consultaMatriz == 0 ) || 
			 				  ( $rootScope.solicitudOSJson.consultaBuro == 0 && $rootScope.solicitudOSJson.consultaMatriz == 1 ) || 
			 				  ( $rootScope.termometroHandlerOS == false && $rootScope.solicitudOSJson.consultaBuro == 0 && $rootScope.solicitudOSJson.consultaMatriz == 0 ) || 
							  ( ( $rootScope.solicitudOSJson.consultaBuro == 0 || $rootScope.solicitudOSJson.consultaMatriz == 0 ) &&
							  ( $rootScope.solicitudOSJson.cotizacion.clientes[0].domicilios[0].porcentaje == 100 && $rootScope.solicitudOSJson.cotizacion.clientes[0].porcentaje == 100 ) );
			
			 
			if( ( $rootScope.muestraOpcionOS && respuestaSeccionOS.porcentajeTotal != 100) && 
				 $rootScope.solicitudJson.obligadoSolidario || 
				 $scope.cotizar ){
				
				$scope.llenaSeccion = false;
				$scope.menuList[7].showAlerta = true;
			}
			
			/*if($rootScope.solicitudOSJson && $rootScope.solicitudOSJson.idSolicitud == "" ){
				$scope.menuList[7].showAuth = true;
				$scope.menuList[7].showMessageAuth = false;
				$scope.menuList[7].messageAuth = "Hace falta un Coacreditado";
				$scope.llenaSeccion = false;
			}*/
			
			if(respuestaSeccionOS.porcentajeTotal == 100 && $rootScope.solicitudOSJson.cotizacion.clientes[0].clienteUnico == ""){
				$scope.llenaSeccion = false;
				$rootScope.message( "AVISO", ["Aún no se ha dado de alta el Cliente único del COACREDITADO, favor de reintentar"], "Aceptar");
			}
		}
		
	    $scope.actualizarMarca = function(){
	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    	var request = {
	    			idSolicitudOS: $rootScope.solicitudOSJson.idSolicitud,
	    			status: $rootScope.solicitudOSJson.idSeguimiento,
	    			idMarca: STATUS_SOLICITUD.autorizada.marca.docvalidacionPendienteOS
	    			}
	    	obligadoSolidarioService.actualizarStatusOS(request).then(
	    			function(data) {
	    				$rootScope.waitLoaderStatus = LOADER_HIDE;
	    				if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
	    					var jsonResponse = JSON.parse(data.data.respuesta);	
	    					
	    					if(jsonResponse.codigo == 2){
	    						$rootScope.solicitudOSJson.marca = STATUS_SOLICITUD.autorizada.marca.docvalidacionPendienteOS;
	    						bloquearSeccionExpediente20K();
	    					}else
	    						$scope.llenaSeccion = false;
	    					}else
	    						$scope.llenaSeccion = false;
	    				}, function(error) {
	    					$scope.llenaSeccion = false;
	    					});
	    	}
	    /** Activa la notificación cuando se deben validar documentos del Coacreditado o hay documentos rechazados **/
	    $scope.activarNotificacion = function(){

	    	/** Bloquear la sección de expedientes cuando se va por el flujo de los 20K**/
	    	bloquearSeccionExpediente20K();	
  					
			if( $scope.existeObligadoSolidario && $rootScope.solicitudOSJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id ){
				if ($rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.docvalidacionPendienteOS){
		    			$scope.menuList[7].showAuth = true;
					$scope.menuList[7].showMessageAuth = true;
					$scope.menuList[7].messageAuth = "Falta la autorización del gerente";
					return true;
				}else if( $rootScope.solicitudOSJson.marca == STATUS_SOLICITUD.autorizada.marca.expRechazado ){
					$scope.menuList[7].showAuth = true;
					$scope.menuList[7].showMessageAuth = true;
					$scope.menuList[7].messageAuth = "Expediente rechazado";
					return true;
				}
	    		}
	    		
	    		return false;
	    }
	    
	    /** Tomamos la opción de si actualizar la marca, activar el mensaje de alerte o no hacer nada y seguir con el flujo **/
	    function condicionesLiberacionOS(){
	    
		    	if( $scope.existeObligadoSolidario && $rootScope.solicitudOSJson.marca != STATUS_SOLICITUD.autorizada.marca.liberadoOS){
			   
		    		if( respuestaSeccionOS.porcentajeTotal != 100 && $rootScope.solicitudOSJson.marca != STATUS_SOLICITUD.autorizada.marca.expRechazado)
			    		$scope.porcentajeObligado();
			    	
			    else if( $rootScope.solicitudOSJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id 
			    			&& $rootScope.solicitudOSJson.marca == 215 && $scope.firmarContratosOS
			    			&& $rootScope.solicitudOSJson.marca != STATUS_SOLICITUD.autorizada.marca.docvalidacionPendienteOS )
			    			$scope.actualizarMarca();
			    	
			    else if( $scope.activarNotificacion()){
			    		$scope.llenaSeccion = false;
				}
			    	
			}
		}
	    
	    /** Bloqueamos el botón de expedientes cuando se va por el flujo de de mesa despues de liberar **/
	                                    
	    function bloquearSeccionExpediente20K(){
			if( $scope.existeObligadoSolidario && $rootScope.solicitudJson.marca == 216 && $rootScope.condicionamientoIngMay20 && $rootScope.solicitudJson.documentos.bloqueado != 1){
				$rootScope.solicitudJson.documentos.bloqueado = 1;
				$scope.buildMenuList(); 
			}                           
	    }                               
/*====================== FIN  COACREDITADO LIBERACIÓN  ======================*/

	    
	    $scope.esCambaceo = function(){
			if( generalService.cambaceoPrecalificado($rootScope.solicitudJson.marca) ){
				if( $rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.verificacionCambaceo || 
				    $rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.rescateCambaceo || 
				    $rootScope.solicitudJson.marca == STATUS_SOLICITUD.preautorizada.marca.inmediatoCambaceo )
						$rootScope.solicitudJson.cotizacion.clientes[0].porcentaje = 80;
					
				modalService.cambaceoModal("En Banco Azteca le decimos CÓMO SI  a nuestros clientes", null ).then( 
						function(exito){
							if(exito == "recargaCambaceo")
								recargarCambaceo();
						}, function(error){
							if(error == "recargaCambaceo")
								recargarCambaceo();
				});
			}
	    }
	    
	    var recargarCambaceo = function(){
	    	$scope.menuList= [];
			$scope.showPage= false;
			$scope.init();
	    };
	    
	    
	    $scope.rescateItalika = function(){
	    	
			if( generalService.esCandidatoRescateItalika($rootScope.solicitudJson.marca) || $scope.respuestaBuro==BURO_CLIENTE_APTO_PARA_PRODUCTO_DE_RESCATE_ITALIKA 
					|| $scope.respuestaBuro==BURO_ITALIKA_COLOR_VALIDO_KO || $scope.respuestaBuro==BURO_ITALIKA_ROJO_CON_KO){
				
				modalService.rescateItalikaModal("En Banco Azteca te decimos SÍ", null ).then( 
						function(exito){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							var idSolicitud = $rootScope.solicitudJson.idSolicitud;
							  
							  buroService.actualizarProductoConsumo( idSolicitud ).then(
								function(data){
									$rootScope.waitLoaderStatus = LOADER_HIDE;
									
									if( data.data.codigo != undefined ){
										
										var responseJson = JSON.parse(data.data.respuesta);
										
										if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
											$scope.respuestaBuro = null;
											
											$rootScope.capacidadesPagoProducto = responseJson.data.capacidadesPagoProducto;
											$rootScope.solicitudJson = responseJson.data.solicitud;
											$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO
											$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
											$rootScope.mostrarOfertaCotizador = false;
											$rootScope.onceOfert = true;
											
											if($rootScope.solicitudJson.marca == STATUS_SOLICITUD.generada.marca.clienteAceptoProductoCosumo){
												$rootScope.requiereObligado = true;
												$rootScope.muestraOpcionOS = true;
											}
											
											$scope.muestraModalCotizador();	
											$scope.buildMenuList();
											
										} else{
					    						generalService.cleanRootScope($rootScope);
					    						generalService.buildSolicitudJson($rootScope, null);
											$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
										} 
										
									}else {
										generalService.cleanRootScope($rootScope);
			    							generalService.buildSolicitudJson($rootScope, null);
										$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
									}
									
								}, function(error){
									generalService.cleanRootScope($rootScope);
			    						generalService.buildSolicitudJson($rootScope, null);
									$rootScope.message("Error ",[" Favor de intentar nuevamente se detectó un problema "], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
								}	  
							  );
						}, function(error){
							console.log("Se ejecuta la funsión de rechazo desde el controlador del modal");
				});
			}
	    }
		
		
// F-MODIFICACION TDC ( CUENTAS PARA DOMICILIAR )
		// I-MODIFICACION MUESTRA OFERTA REACTIVADO (MOSTRAR MODAL PARA RE ACTIVADOS)
	    $scope.consultaReactivado = function(idSolicitud, cita){ 
	    	$scope.cita = cita;
	    	$rootScope.waitLoaderStatus = LOADER_SHOW; 
	    	var x = {
	    	 idSolicitud: idSolicitud
	    	};
	    	solicitudService.consultaReactivado(x).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var j = JSON.parse(data.data.respuesta);
						$rootScope.solicitudJson = j.data.solicitud;
						if (j.codigo == RESPONSE_REAC_EXITO){
							if(j.data.salidaConsulta[0].TERRITORIAL == CAMPANAS_REACTIVADOS.preaprobados)
								$scope.muestraOfertaReactivado(j.data.solicitud, j.data.salidaConsulta[0].SUCGESTORA);
							else{
								if ($scope.cita){
									$scope.obtenerVerificacion();
								}else
									$scope.muestraModalCotizador(true);
							}
						}else{
							if ($scope.cita){
								$scope.obtenerVerificacion();
							}else
								$scope.muestraModalCotizador(true);
						}	
					}else{
						if ($scope.cita){
							$scope.obtenerVerificacion();
						}else
							$scope.muestraModalCotizador(true);
					}
//						$rootScope.message("Aviso ", [data.data.descripcion],"Aceptar",null,null,null,null);
				}, function(error){
					$rootScope.waitLoaderStatus = LOADER_HIDE; 
				    validateService.error(error);
				}
	    	);
	    };
	    $scope.muestraOfertaReactivado = function(jsonRespuesta, capacidad){
	     	 modalService.confirmModal("Notificación",["Hemos detectado que eres un cliente pre aprobado con una capacidad de pago de. $"+ capacidad +" y te puedes llevar tu producto en este momento", "¿Aceptas esta alternativa?"], "No", "Si", "bgAzul", "btn gris", "btn azul" ).then(
	     			 function(exito){
	     				$rootScope.waitLoaderStatus = LOADER_SHOW; 
	     				 solicitudService.cancelarSolicitud({idSolicitud:jsonRespuesta.idSolicitud}).then(
	     						 function(data){
	     							$rootScope.waitLoaderStatus = LOADER_HIDE; 
	     							 if(data.data.codigo == RESPONSE_CODIGO_EXITO){
	     								 $rootScope.message( "AVISO", ["Por favor, coméntale a tu cliente que debe ingresar desde la opción: Menú principal > Colocación > Reactivación LCR"], "Aceptar", "/menuWrapper");
	     							 }else{
	     								 $rootScope.message("Aviso ", ["Error al cancelar la solicitud"],"Aceptar",null,null,null,null);
	     							 }
	     						 }, function(error){
	     							 $rootScope.waitLoaderStatus = LOADER_HIDE;
	     							 $rootScope.message("Aviso ", ["Error al cancelar la solicitud"],"Aceptar",null,null,null,null);	
	     						 });
	     			 },function(error){
	     				 console.log("Quemar Folio");
	     				if ($scope.cita){
	     					$scope.obtenerVerificacion();
						}else
							$scope.muestraModalCotizador(true);

	     		});
	     	
	   };
//F-MODIFICACION MUESTRA OFERTA REACTIVADO (MOSTRAR MODAL PARA RE ACTIVADOS)
	    $scope.validareactivado = function(){
	    	if($rootScope.solicitudJson.tipoSolicitud == SOLICITUD_REACTIVADO && generalService.isEmpty($rootScope.solicitudJson.campana) && !$rootScope.productosTarjetas($rootScope.solicitudJson.idProducto)){
	    		return true;
	    	}else{
	    		return false;
	    	}
	    }
	    
	    $scope.calcupaRestante = function(capacidadPago, pagoPuntual){
			switch($rootScope.solicitudJson.cotizacion.idPeriodicidad){
				case (PERIODICIDAD.semanal):
					return capacidadPago - pagoPuntual;
				case (PERIODICIDAD.quincenal):
					return (capacidadPago * 2) - pagoPuntual
				case (PERIODICIDAD.mensual):
					return (capacidadPago * 4) - pagoPuntual
			}
		}
	    
	    $scope.validaSeccionesDiaPago = function()
		{
			$scope.llenaSeccion = true;
			for(var l = 0; l < $scope.menuList.length; l++){
				if ($scope.menuList[l].porcentaje != 100){
					$scope.menuList[l].showAlerta = true;
					$scope.menuList[l].showMessageAlert = false;
					$scope.llenaSeccion = false;
				}
			}	
		};
	    
	    		/** Producto de Rescate de Telefonia **/
		$scope.rescateTelefonia = function(){
			if( generalService.esCandidatoRescateTelefonia($rootScope.solicitudJson.marca) || $scope.respuestaBuro==BURO_CLIENTE_APT0_PARA_PRODUCTO_DE_RESCATE_TELEFONIA ){
				
				$scope.muestraBoton = false;
				$scope.muestraAlertaNuevoBuro=false;
				$scope.muestraMensajeNuevoBuro=false;
				
				modalService.proResTelefoniaModal("En Banco Azteca te decimos SÍ", null ).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_SHOW;
							
							/** Se agrega la marca intermedia **/
							switch($rootScope.opcTelefonia){
								case ENUM_TELEFONIA.SinObligadoSolidarioEngancheMenor: $rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.prodResTelefoniaSinOS;
								break;
								case ENUM_TELEFONIA.ConObligadoSolidario: $rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.prodResTelefoniaConOS;
								break;
								case ENUM_TELEFONIA.SinObligadoSolidarioEngancheMayor: $rootScope.solicitudJson.marca = STATUS_SOLICITUD.generada.marca.prodResTelefoniaSinOSSegundaOferta;
								break;
							}
							
							solicitudService.actualizarSolicitud( $rootScope.solicitudJson ).then(
									 function(data){
										 if( data.data.codigo != undefined ){
											 var responseJson = JSON.parse(data.data.respuesta);
											 
											 if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){

													//Consumir el servicio de actualizar producto
													var jsonSolicitud = {
															idSolicitud: $rootScope.solicitudJson.idSolicitud,
															opcion: $rootScope.opcTelefonia
													}
													  
													  buroService.actualizarProductoConsumo( jsonSolicitud ).then(
														function(data){
															$rootScope.waitLoaderStatus = LOADER_HIDE;
															
															if( data.data.codigo != undefined ){
																var responseJson = JSON.parse(data.data.respuesta);
																
																if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
																	
																	$scope.respuestaBuro = null;
																	$rootScope.capacidadesPagoProducto = responseJson.data.capacidadesPagoProducto;
																	$rootScope.solicitudJson = responseJson.data.solicitud;
																	$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO
																	$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
																	$rootScope.mostrarOfertaCotizador = false;
																	$rootScope.onceOfert = true;
																	
																	if( $rootScope.solicitudJson.marca==STATUS_SOLICITUD.generada.marca.clienteAceptoProductoCosumo ){
																		$rootScope.requiereObligado = true;
																		$rootScope.muestraOpcionOS = true;
																	}
																	
																	$scope.muestraModalCotizador();	
																	$scope.buildMenuList();
																	
																} else{
											    						generalService.cleanRootScope($rootScope);
											    						generalService.buildSolicitudJson($rootScope, null);
																	$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
																} 
																
															}else {
																generalService.cleanRootScope($rootScope);
									    							generalService.buildSolicitudJson($rootScope, null);
																$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
															}
															
														}, function(error){
															generalService.cleanRootScope($rootScope);
									    						generalService.buildSolicitudJson($rootScope, null);
															$rootScope.message("Error ",[" Favor de intentar nuevamente se detectó un problema "], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
														}	  
													  );
													
													
												} else{
							    						generalService.cleanRootScope($rootScope);
							    						generalService.buildSolicitudJson($rootScope, null);
													$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
												} 
											 
										 }else {
											generalService.cleanRootScope($rootScope);
			    							generalService.buildSolicitudJson($rootScope, null);
											$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
										}
									 }, function(error) {
											generalService.cleanRootScope($rootScope);
					    					generalService.buildSolicitudJson($rootScope, null);
											$rootScope.message("Error ",[" Favor de intentar nuevamente se detectó un problema "], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
									 }
							 );
							
							
							
						}, function(error){
							console.log("Se ejecuta la funsión de rechazo desde el controlador del modal");
						});
			}
	    }
	   
	   /** Producto de Rescate Consumo **/ 
	    $scope.rescateConsumo = function(){
	    	
		 if( generalService.esCandidatoRescateConsumo($rootScope.solicitudJson.marca) ){
			 
				$scope.muestraBoton = false;
				$scope.muestraAlertaNuevoBuro=false;
				$scope.muestraMensajeNuevoBuro=false;
				
					modalService.rescateConsumoModal("En Banco Azteca te decimos SÍ", $rootScope.solicitudJson.idProducto ).then( 
							function(exito){
								$rootScope.waitLoaderStatus = LOADER_SHOW;
								//Consumir el servicio de actualizar producto
								var idSolicitud = $rootScope.solicitudJson.idSolicitud;
								  
								  buroService.actualizarProductoConsumo( idSolicitud ).then(
									function(data){
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										
										if( data.data.codigo != undefined ){
											var responseJson = JSON.parse(data.data.respuesta);
											
											if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
												
												$rootScope.capacidadesPagoProducto = responseJson.data.capacidadesPagoProducto;
												$rootScope.solicitudJson = responseJson.data.solicitud;
												$rootScope.buroConditional = RESPONSE_ORIGINACION_CODIGO_EXITO
												$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
												$rootScope.mostrarOfertaCotizador = false;
												$rootScope.onceOfert = true;
												
												if( $rootScope.solicitudJson.marca==STATUS_SOLICITUD.generada.marca.clienteAceptoProductoCosumo ){
													$rootScope.requiereObligado = true;
													$rootScope.muestraOpcionOS = true;
												}
												
												$scope.muestraModalCotizador();	
												$scope.buildMenuList();
												
											} else{
						    						generalService.cleanRootScope($rootScope);
						    						generalService.buildSolicitudJson($rootScope, null);
												$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
											} 
											
										}else {
											generalService.cleanRootScope($rootScope);
				    							generalService.buildSolicitudJson($rootScope, null);
											$rootScope.message("Error " + data.data.codigo,[generalService.displayMessage(data.data.descripcion)], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
										}
										
									}, function(error){
										generalService.cleanRootScope($rootScope);
				    						generalService.buildSolicitudJson($rootScope, null);
										$rootScope.message("Error ",[" Favor de intentar nuevamente se detectó un problema "], "Aceptar", "/simulador", "bgazul", "bgazul", null, null, null);
									}	  
								  );
							}, function(error){
								console.log("Se ejecuta la funsión de rechazo desde el controlador del modal");
					});
				}
	    }
	    	    
	    /** Producto de Rescate de Prestamo Personal **/
		$scope.rescatePrestamo = function(){
			//if( generalService.esCandidatoRescatePrestamo($rootScope.solicitudJson.marca)){
				
				$scope.muestraBoton = false;
				$scope.muestraAlertaNuevoBuro=false;
				$scope.muestraMensajeNuevoBuro=false;
				
				modalService.rescatePrestamoModal("En Banco Azteca te decimos SÍ", $rootScope.solicitudJson.marca ).then(
				function(estatus) {																												
					console.log("ok");
					$scope.calculaCPConsumo();
					$scope.validaEdicionSecciones();
					
/** INICIA_OS-FLUJO COACREDITADO **/
					/**Validación para construir el menu con la opcion del Coacreditado
					 * Coacreditado NF	
					 **/
					validaOfertaOS();
					//$scope.quitarBotonVolverACotizar();
/** TERMINA_OS-FLUJO COACREDITADO **/
				}, function(exito) {
					if(exito){
						$scope.muestraAlertasNuevoCotizador();
						$timeout( loadProgressbar, 0 );
						$scope.calculaCPConsumo();
						$scope.validaEdicionSecciones();
						
/** INICIA_OS-FLUJO COACREDITADO **/
						/**
						 * Validación para construir el menu con la opcion del Coacreditado
						 * Coacreditado NF	
						 **/										
						validaOfertaOS();
						//$scope.quitarBotonVolverACotizar();
/** TERMINA_OS-FLUJO COACREDITADO **/
					}
				}
		
				
				);
			//}
	    }

	    /** modal Oferta Promocion Buen Fin Pre Aprobado **/ 
	    $scope.ofertaPreaprob = function(){
	    	
//			Mandamos abrir el modal de la promocion del Buen FIN "PREAPROB"
			modalService.ofertaPromocionesBuenFinModal("Promoción Navidad", "bgAzul",null).then(
					function(estatus) {
						console.log("ok");
						$scope.calculaCPConsumo();
						$scope.validaEdicionSecciones();
					}, function(exito) {
						if(exito){
							$scope.muestraAlertasNuevoCotizador();
							$timeout( loadProgressbar, 0 );
							$scope.calculaCPConsumo();
							$scope.validaEdicionSecciones();
						}else{
							$scope.rechazarOferta();
						}
					}
					);
	    	
	    }
	    
	    /**
	     * Función que determina si se debe o no lubricar.
	     * Regresa verdadero si es necesario mostrar las sección de fricción.
	     * Regresa falso si no es menester mostrar las secciones
	     */
	    function doNotLubricate() {
	    	if($rootScope.validaPreAprobados()) {
	    		return true;
	    	} else {
	    		return generalService.masterFunction();
	    	}
	    }
	    
	    var validaAltaCU = function(intento){
	    	if($rootScope.requiereObligado && respuestaSeccionOS.porcentajeTotal != 100){
				$scope.menuList[7].showAlerta = true;
				$scope.menuList[7].showMessageAlert = true;
				$scope.menuList[7].messageAlert="Es necesario tener al 100% la sección.";
	    	}else{
				if(($rootScope.solicitudJson.clienteForaneoGuardado == 98 || $rootScope.solicitudJson.clienteForaneoGuardado == 99) && 
						$rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova != "" &&
					  (!$rootScope.requiereObligado ||
					   ($rootScope.solicitudOSJson.clienteForaneoGuardado == 98 || $rootScope.solicitudOSJson.clienteForaneoGuardado == 99) && 
						$rootScope.solicitudOSJson.cotizacion.clientes[0].clienteAlnova != "")){
					if(!generalService.pendienteOferta($rootScope.solicitudJson.marca)){
						if(!generalService.validardiaDePago()){
						/*\Se agrega un evento para la bitacora\*/
//						(Generar Cita / Cita de verificación)
						$rootScope.addEvent( BITACORA.SECCION.citaDeVerificacion.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, 0, BITACORA.SECCION.citaDeVerificacion.guardarEnBD );
						/*\Se agrega un evento para la bitacora\*/
						}
						generalService.locationPath(generalService.whichOneVisit());
					}
					else
						$rootScope.message("AVISO", ["El servicio RESCATE no respondió, favor de intentarlo más tarde o comuniquese con el administrador del sistema."], "Aceptar", "/simulador");
				}else{
					var idSolicitud = null;
					var idSolicitudOS = null;
					var tipoCliente="";
					if(($rootScope.solicitudJson.clienteForaneoGuardado != 98 && $rootScope.solicitudJson.clienteForaneoGuardado != 99) ||
						$rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova == ""){
						idSolicitud = $rootScope.solicitudJson.idSolicitud;
						tipoCliente="CLIENTE";
					}
					if(($rootScope.solicitudJson.obligadoSolidario!=null && $rootScope.solicitudJson.obligadoSolidario.idSolicitudObligadoSolidario != "" && $rootScope.solicitudJson.obligadoSolidario.idSolicitudObligadoSolidario != "") &&
					   (($rootScope.solicitudOSJson.clienteForaneoGuardado != 98 && $rootScope.solicitudOSJson.clienteForaneoGuardado != 99) ||
						$rootScope.solicitudOSJson.cotizacion.clientes[0].clienteAlnova == "")){
						idSolicitudOS=$rootScope.solicitudOSJson.idSolicitud;
						tipoCliente="COACREDITADO";
					}
					if(intento == 0 && tipoCliente != ""){
						var jsonSolicitudes = { idSolicitud: idSolicitud,
											  idSolicitudOS: idSolicitudOS
											}; 
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						clienteUnicoService.altaCUTienda(jsonSolicitudes).then(
									function(data) {
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										if(data.data.codigo == RESPONSE_CODIGO_EXITO){
											var j = JSON.parse(data.data.respuesta);							
											if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
												if(j.data.solicitudCliente== null && j.data.solicitudObligado== null)
													modalService.alertModal("Alta Única",[ "Aún no se ha dado de alta al "+tipoCliente+" correctamente, favor de espera unos minutos y vuelve a intentarlo." ],"Aceptar");
												else{
													if(j.data.solicitudCliente!= null)
														$rootScope.solicitudJson = j.data.solicitudCliente;
													if(j.data.solicitudObligado!= null)
														$rootScope.solicitudOSJson = j.data.solicitudObligado;
													validaAltaCU(1);
												}
											}else{
												modalService.alertModal("Alta Única",[ "Aún no se ha dado de alta al "+tipoCliente+" correctamente, favor de espera unos minutos y vuelve a intentarlo." ],"Aceptar");
											}
										}
									}, function(error) {
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										modalService.alertModal("Alta Única",[ "Aún no se ha dado de alta al "+tipoCliente+" correctamente, favor de espera unos minutos y vuelve a intentarlo." ],"Aceptar");
									}
							);
					}else{
						if(tipoCliente == "")
							modalService.alertModal("Error de Sistema",[ "Sin flujo de Generación CU" ],"Aceptar");
						else
							modalService.alertModal("Alta Única",[ "Aún no es posible dar de alta al "+tipoCliente+", favor de volver a intentarlo." ],"Aceptar");
					}
				}
	    	}
		};
		
		var agregaEventoDesdeOchoPasos = function (opcion, bloqueo){
			if (bloqueo == 0){
				switch(opcion){
					case validacionPath[SECCION_PERSONALES].nombrePath: //Datos Básicos
						$rootScope.addEvent( BITACORA.SECCION.datosBasicos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, $rootScope.solicitudJson.cotizacion.clientes[0].porcentaje, BITACORA.SECCION.datosBasicos.guardarEnBD );
						break;
					case validacionPath[SECCION_HOGAR].nombrePath: //Datos del Hogar
						$rootScope.addEvent( BITACORA.SECCION.datosHogar.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].porcentaje, BITACORA.SECCION.datosHogar.guardarEnBD );
						break;
					case validacionPath[SECCION_EMPLEO].nombrePath: //Datos del Empleo
						$rootScope.addEvent( BITACORA.SECCION.datosEmpleo.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, $rootScope.solicitudJson.cotizacion.clientes[0].datosEmpleo[0].porcentaje, BITACORA.SECCION.datosEmpleo.guardarEnBD );
						break;
					case validacionPath[SECCION_INGRESOS_GASTOS].nombrePath: //Gastos
						$rootScope.addEvent( BITACORA.SECCION.gastos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, $rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje, BITACORA.SECCION.gastos.guardarEnBD );
						break;
					case validacionPath[SECCION_REFERENCIAS].nombrePath: //Referencias
						$rootScope.addEvent( BITACORA.SECCION.referencias.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, $rootScope.solicitudJson.referencias.porcentaje, BITACORA.SECCION.referencias.guardarEnBD );
						break;
					case validacionPath[SECCION_DOCUMENTOS].nombrePath: //Expediente
						$rootScope.addEvent( BITACORA.SECCION.expedientes.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, $rootScope.solicitudJson.documentos.porcentaje, BITACORA.SECCION.expedientes.guardarEnBD );
						break;
					case validacionPath[SECCION_CONTRATOS].nombrePath: //Contratos
						$rootScope.addEvent( BITACORA.SECCION.contratos.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, $rootScope.solicitudJson.contratos.porcentaje, BITACORA.SECCION.contratos.guardarEnBD );
						break;
					case validacionPath[SECCION_CLIENTES].nombrePath:	//Datos del cliente
						$rootScope.addEvent( BITACORA.SECCION.datosCliente.id,BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, porcentajeUnificada($rootScope.solicitudJson),BITACORA.SECCION.datosCliente.guardarEnBD );
						break;
					case "/simuladorOS": //Coacreditado /simuladorOS
						$rootScope.addEvent(BITACORA.SECCION.coacreditado.id,BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, 0,BITACORA.SECCION.coacreditado.guardarEnBD );
						break;
					case "/datosCoacreditado": //Coacreditado //datosCoacreditado
						$rootScope.addEvent(BITACORA.SECCION.coacreditado.id,BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, 0,BITACORA.SECCION.coacreditado.guardarEnBD );
						break;
					case "/ochoPasosOS": //Coacreditado /ochoPasosOS
						$rootScope.addEvent(BITACORA.SECCION.coacreditado.id,BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.proceso.id, 0,BITACORA.SECCION.coacreditado.guardarEnBD );
						break;
					default:
						break;
				}
			}
		}		
		/**
		 * Función que obtiene los periodos
		 * */
		var getPeriodos = function(idProducto){
			$scope.dosLimites=false;
			switch(idProducto){
				case PRODUCTOS.consumo.ID.valor: //21
					$scope.dosLimites=true;
					return '1,2';
				case PRODUCTOS.italika.ID.valor: //22
					$scope.dosLimites=false;
					return '1';
				case PRODUCTOS.telefonia.ID.valor: //23
					$scope.dosLimites=true;
					return '1,2';
				case PRODUCTOS.prestamoPersonal.ID.valor: //24
					$scope.dosLimites=true;
					return '1,2';
				default:
					return '';
			}
		};
	    
		/**
		 * Servicio Consulta Limites de Credito
		 * */
		$scope.abreModalLimitesDeCredito = function(){
//			Se valida que la sucursal tenga la funcionalidad activada
			if($rootScope.campanaNvoPreaprob($rootScope.solicitudJson.campana)){
				/**
				 * Función manda a llamar el modal que muestra los limites de credito
				 */
				modalService.opcionCreditoModal("Opciones de Crédito", "bgAzul",$scope)
			}else{
			if($rootScope.consultaFuncionalidad.habilitarTopes){
//				$rootScope.solicitudJson = JSON.parse("{\"idSolicitud\":\"2018092507470974709982189\",\"idPais\":1,\"idPaisGestor\":0,\"idCanal\":1,\"idCanalGestor\":0,\"idSucursal\":2244,\"idSucursalGestor\":0,\"idCanalAlnova\":6,\"tipoSolicitud\":8,\"origenSolicitud\":0,\"idProducto\":24,\"tipoLevantamiento\":2,\"idPlataforma\":1,\"idSubPlataforma\":0,\"idSeguimiento\":6,\"marca\":5002,\"idEmpleado\":309295,\"terminal\":\"4T6R\",\"direccionIp\":\"10.53.37.40\",\"idEntidadAlnova\":\"0127\",\"aceptaTerminos\":1,\"folioCallCenter\":\"\",\"respuestaCallCenter\":0,\"capacidadPagoComprobable\":500,\"capacidadPagoNoComprobable\":150,\"idColorNC\":4,\"envioCorreo\":0,\"codigoCorreo\":\"\",\"envioCelular\":1,\"codigoCelular\":\"M1G8QVewXSVU0qNWcAR5Bg==\",\"cantidadReenviosCelular\":1,\"cantidadReenviosLlamada\":0,\"cantidadReenviosCorreo\":0,\"promocionCelular\":0,\"promocionCorreo\":0,\"pedido\":0,\"pedidoSEG\":0,\"pedidoSAC\":0,\"tipoDispersion\":0,\"idSolicitudTienda\":62298,\"idSolicitudTiendaCredInm\":0,\"idSolicitudTiendaReactivacion\":0,\"idCondicion\":\"0\",\"idEstatusLCR\":0,\"idMotivoRechazo\":\"0\",\"idMotivoBloqueo\":\"0\",\"consultaBuro\":1,\"consultaMatriz\":1,\"clienteForaneoGuardado\":99,\"banderaPrueba\":0,\"banderaIngresos\":1,\"banderaSolidario\":0,\"banderaCUDigitalizacion\":1,\"banderaEntregaTAZ\":1,\"banderaOCR\":0,\"banderaOfertaCP\":1,\"banderaSeguro\":1,\"creditoInmediato\":0,\"creditoInmediatoInhabilitado\":0,\"tratamientoDatos\":0,\"transferenciaDatos\":0,\"fechaCita\":\"25/09/2018\",\"empeladoCita\":\"001035\",\"periodoCita\":\"4\",\"existeCita\":1,\"aceptaConsultaBuro\":1,\"diaPago\":\"SABADO\",\"tipoBusqueda360\":2,\"respuesta360\":\"400\",\"folioFlujoUnico\":\"F1801198555\",\"campaniaDesc\":\"\",\"observaciones\":\"\",\"codSucCercana\":0,\"fechaPedido\":\"\",\"idColor\":4,\"idEmpleadoGerente\":\"928920\",\"diasRechazo\":0,\"tipoCampania\":1,\"huellaExistenteINE\":\"\",\"tipoDispositivo\":\"iPad\",\"cotizacion\":{\"idCotizacion\":\"20180925074709601262\",\"statusCotizacion\":1,\"fechaVigencia\":\"\",\"montoTotal\":19343.994,\"idPeriodicidad\":1,\"periodicidad\":\"Semanal\",\"idPlazo\":52,\"plazo\":52,\"pagoNormal\":372,\"pagoPuntual\":316,\"ultimoAbono\":371,\"cambioPeriodicidad\":0,\"idPresupuesto\":0,\"detallesCotizacion\":[{\"idDetalle\":\"20180925074709608349\",\"enganche\":0,\"intereses\":8343,\"monto\":11000,\"cantidad\":1,\"idProducto\":\"520219\"}],\"clientes\":[{\"idPersona\":\"20180925074709580588\",\"nombre\":\"PRUEBA\",\"apellidoPaterno\":\"BILLETAZO\",\"apellidoMaterno\":\"UNO\",\"apellidoCasada\":\"\",\"idGenero\":\"M\",\"genero\":\"MASCULINO\",\"fechaNaciomiento\":\"14/09/2000\",\"celular\":\"5541430487\",\"email\":\"\",\"idNacionalidad\":0,\"nacionalidadDes\":\"\",\"idLugarNacimiento\":9,\"lugarNacimientoDes\":\"CIUDAD DE MEXICO\",\"idEstadoCivil\":1,\"estadoCivil\":\"SOLTERO (A)\",\"curp\":\"BIUP880914HDFLNR01\",\"rfc\":\"BIUP880914IC5\",\"dni\":\"\",\"clienteUnico\":\"1-1-2244-101130\",\"clienteTienda\":\"1-2244-313160-9\",\"clienteAlnova\":\"64499255\",\"idBiometrico\":\"01012244111234\",\"clienteADN\":\"1-2244-103108\",\"numCuenta\":\"\",\"foto\":\"1\",\"huella\":\"1\",\"rutaHuella\":\"\",\"idPuesto\":47,\"puestoDes\":\"COMERCIANTE\",\"idPuestoCU\":290,\"puestoCUDes\":\"COMERCIANTE\",\"idPuestoSPCU\":71,\"puestoSPCUDes\":\"COMERCIANTE\",\"idTipoTrabajo\":5,\"tipoTrabajoDes\":\"POR SU CUENTA\",\"anioRegistro\":0,\"anioEmision\":0,\"claveElector\":\"\",\"cic\":\"\",\"folioIdentificacion\":\"346786532457889\",\"numeroEmision\":\"\",\"fechaVigenciaIdentificacion\":\"\",\"consecutivoPersona\":0,\"seccionPorValidar\":0,\"idParentesco\":0,\"parentescoDes\":\"\",\"porcentaje\":100,\"bloqueado\":0,\"editable\":1,\"guardado\":1,\"idTipoContacto\":1,\"contadorBloqueo\":0,\"domicilios\":[{\"idDomicilio\":\"20180925075036737798\",\"calle\":\"INSURGENTES SUR\",\"numeroExterior\":\"3579\",\"numeroInterior\":\"\",\"cp\":\"14000\",\"colonia\":\"TLALPAN CENTRO\",\"idDelegacion\":14,\"delegacion\":\"TLALPAN\",\"idEstado\":9,\"estado\":\"CIUDAD DE MEXICO\",\"telefono\":\"\",\"domicilioActual\":1,\"idTipoVivienda\":1,\"tipoViviendaDes\":\"PROPIA\",\"manzana\":\"\",\"edificio\":\"\",\"superManzana\":\"\",\"lote\":\"\",\"antiguedad\":\"01/09/2013\",\"andador\":\"\",\"idAntiguedad\":4,\"antiguedadDes\":\"DE 3 A 5 AÑOS\",\"porcentaje\":100,\"bloqueado\":0,\"editable\":1,\"guardado\":1,\"edicionDatosHogar\":\"\",\"zonificacion\":{\"latitud\":\"19.29749787181127\",\"longitud\":\"-99.18542211370539\",\"referencia\":\"PRUEBA BILLETAZO\",\"calleDelante\":\"SN\",\"calleAtras\":\"SN\",\"calleIzquierda\":\"SN\",\"calleDerecha\":\"SN\",\"heading\":\"30\",\"pitch\":\"0\",\"zoom\":\"1.9954624216079742\",\"fov\":\"45.10232767374122\",\"idCuadrante\":48,\"idPais\":48,\"idZonaGeo\":125},\"contadorBloqueo\":0,\"seccionPorValidar\":0}],\"ingresosEgresos\":{\"dependientesMayores\":0,\"dependientesMenores\":2,\"porcentaje\":100,\"bloqueado\":0,\"editable\":1,\"guardado\":1,\"flujoEfectivo\":[{\"idTipo\":2,\"tipoDes\":\"Egreso\",\"idConcepto\":1,\"conceptoDes\":\"LUZ\",\"monto\":0},{\"idTipo\":2,\"tipoDes\":\"Egreso\",\"idConcepto\":2,\"conceptoDes\":\"AGUA\",\"monto\":0},{\"idTipo\":2,\"tipoDes\":\"Egreso\",\"idConcepto\":5,\"conceptoDes\":\"RENTA\",\"monto\":0},{\"idTipo\":2,\"tipoDes\":\"Egreso\",\"idConcepto\":6,\"conceptoDes\":\"TRANSPORTE\",\"monto\":0},{\"idTipo\":2,\"tipoDes\":\"Egreso\",\"idConcepto\":7,\"conceptoDes\":\"TELEFONO\",\"monto\":0},{\"idTipo\":2,\"tipoDes\":\"Egreso\",\"idConcepto\":8,\"conceptoDes\":\"GAS\",\"monto\":0},{\"idTipo\":2,\"tipoDes\":\"Egreso\",\"idConcepto\":9,\"conceptoDes\":\"COMIDA\",\"monto\":0}]},\"datosEmpleo\":[{\"idEmpleo\":\"20180925074923408648\",\"nombreEmpresa\":\"\",\"idGiro\":0,\"giro\":\"\",\"ext\":\"\",\"antiguedad\":\"\",\"idPeriodicidad\":0,\"periodicidad\":\"\",\"idAntiguedad\":0,\"antiguedadDes\":\"\",\"empleoActual\":0,\"porcentaje\":0,\"idProfesion\":0,\"profesion\":\"\",\"idTipoPago\":0,\"tipoPago\":\"\",\"bloqueado\":1,\"editable\":1,\"guardado\":0,\"domicilio\":{\"idDomicilio\":\"\",\"calle\":\"\",\"numeroExterior\":\"\",\"numeroInterior\":\"\",\"cp\":\"\",\"colonia\":\"\",\"idDelegacion\":0,\"delegacion\":\"\",\"idEstado\":0,\"estado\":\"\",\"telefono\":\"\"}}],\"flujoEfectivo\":[{\"idTipo\":1,\"tipoDes\":\"INGRESO\",\"idConcepto\":3,\"conceptoDes\":\"COMPROBABLES\",\"monto\":15000},{\"idTipo\":1,\"tipoDes\":\"INGRESO\",\"idConcepto\":4,\"conceptoDes\":\"NO COMPROBABLES\",\"monto\":0}],\"preguntaPEPS\":[{\"numero\":1,\"cargo\":0,\"cargoDes\":\"\",\"dependencia\":1,\"dependenciaDes\":\"\",\"areaAdscrito\":1,\"areaAdscritoDes\":\"\",\"parentesco\":0,\"parentescoDes\":\"\",\"nombre\":\"\",\"apellidoPaterno\":\"\",\"apellidoMaterno\":\"\",\"fechaNacimiento\":\"\",\"idPersona\":\"\",\"status\":0,\"guardado\":\"0\"},{\"numero\":2,\"cargo\":0,\"cargoDes\":\"\",\"dependencia\":1,\"dependenciaDes\":\"\",\"areaAdscrito\":1,\"areaAdscritoDes\":\"\",\"parentesco\":0,\"parentescoDes\":\"\",\"nombre\":\"\",\"apellidoPaterno\":\"\",\"apellidoMaterno\":\"\",\"fechaNacimiento\":\"\",\"idPersona\":\"\",\"status\":0,\"guardado\":\"0\"}],\"datosConyuge\":{\"idPersona\":\"\",\"nombre\":\"\",\"apellidoPaterno\":\"\",\"apellidoMaterno\":\"\",\"apellidoCasada\":\"\",\"idGenero\":\"\",\"genero\":\"\",\"fechaNaciomiento\":\"\",\"celular\":\"\",\"email\":\"\",\"idNacionalidad\":0,\"nacionalidadDes\":\"\",\"idLugarNacimiento\":0,\"lugarNacimientoDes\":\"\",\"idEstadoCivil\":0,\"estadoCivil\":\"\",\"curp\":\"\",\"rfc\":\"\",\"dni\":\"\",\"idPuesto\":0,\"puestoDes\":\"\",\"idPuestoCU\":0,\"puestoCUDes\":\"\",\"idPuestoSPCU\":0,\"puestoSPCUDes\":\"\",\"idTipoTrabajo\":0,\"tipoTrabajoDes\":\"\"}}],\"engancheItalika\":0},\"avales\":[{\"idPersona\":\"\",\"nombre\":\"\",\"apellidoPaterno\":\"\",\"apellidoMaterno\":\"\",\"apellidoCasada\":\"\",\"idGenero\":\"\",\"genero\":\"\",\"fechaNaciomiento\":\"\",\"celular\":\"\",\"email\":\"\",\"idNacionalidad\":0,\"nacionalidadDes\":\"\",\"idLugarNacimiento\":0,\"lugarNacimientoDes\":\"\",\"idEstadoCivil\":0,\"estadoCivil\":\"\",\"curp\":\"\",\"rfc\":\"\",\"dni\":\"\",\"idTipoAval\":0,\"tipoAvalDes\":\"\",\"idTipoPropiedad\":0,\"tipoPropiedadDes\":\"\",\"clienteUnico\":\"\",\"clienteTienda\":\"\",\"clienteAlnova\":\"\",\"foto\":\"\",\"huella\":\"\",\"porcentaje\":0,\"porcentajeBasico\":0,\"porcentajeContacto\":0,\"bloqueado\":1,\"editable\":1,\"guardado\":0,\"idParentesco\":0,\"parentescoDes\":\"\",\"idPuesto\":0,\"puestoDes\":\"\",\"presencial\":0,\"primerInser\":0,\"avalVinculado\":0,\"consecutivoPersona\":0,\"folioIdentificacion\":\"\",\"fechaVigenciaIdentificacion\":\"\",\"idSeguimiento\":0,\"marca\":0,\"envioCorreo\":0,\"codigoCorreo\":\"\",\"envioCelular\":0,\"codigoCelular\":\"\",\"codigosEnviados\":0,\"cantidadReenviosCelular\":0,\"cantidadReenviosCorreo\":0,\"idCondicion\":0,\"idMotivoRechazo\":0,\"idMotivoBloqueo\":0,\"consultaBuro\":0,\"consultaMatriz\":0,\"clienteForaneoGuardado\":0,\"existeCita\":0,\"aceptaConsultaBuro\":0,\"aceptaTerminos\":0,\"banderaOCR\":0,\"datosHogar\":{\"idDomicilio\":\"\",\"calle\":\"\",\"numeroExterior\":\"\",\"numeroInterior\":\"\",\"cp\":\"\",\"colonia\":\"\",\"idDelegacion\":0,\"delegacion\":\"\",\"idEstado\":0,\"estado\":\"\",\"telefono\":\"\",\"domicilioActual\":1,\"idTipoVivienda\":0,\"tipoViviendaDes\":\"\",\"manzana\":\"\",\"edificio\":\"\",\"superManzana\":\"\",\"lote\":\"\",\"antiguedad\":\"\",\"andador\":\"\",\"idAntiguedad\":0,\"antiguedadDes\":\"\",\"porcentaje\":0,\"bloqueado\":0,\"editable\":1,\"guardado\":0,\"edicionDatosHogar\":\"\",\"zonificacion\":{\"latitud\":\"\",\"longitud\":\"\",\"referencia\":\"\",\"calleDelante\":\"\",\"calleAtras\":\"\",\"calleIzquierda\":\"\",\"calleDerecha\":\"\",\"heading\":\"\",\"pitch\":\"\",\"zoom\":\"\",\"fov\":\"\",\"idCuadrante\":0,\"idPais\":0,\"idZonaGeo\":0},\"contadorBloqueo\":0,\"seccionPorValidar\":0},\"flujoEfectivo\":[]}],\"referencias\":{\"porcentaje\":100,\"bloqueado\":0,\"editable\":1,\"guardado\":1,\"referencia\":[{\"idPersona\":\"20180925075228371883\",\"nombre\":\"PRUEBA\",\"apellidoPaterno\":\"PRUEBA\",\"apellidoMaterno\":\"\",\"apellidoCasada\":\"\",\"idGenero\":\"\",\"genero\":\"\",\"fechaNaciomiento\":\"\",\"celular\":\"3283844838\",\"email\":\"\",\"idNacionalidad\":0,\"nacionalidadDes\":\"\",\"idLugarNacimiento\":0,\"lugarNacimientoDes\":\"\",\"idEstadoCivil\":0,\"estadoCivil\":\"\",\"curp\":\"\",\"rfc\":\"\",\"dni\":\"\",\"idParentesco\":12,\"parentescoDes\":\"NUERA\",\"telefonoCasa\":\"\"},{\"idPersona\":\"20180925075228498708\",\"nombre\":\"PRUEBA\",\"apellidoPaterno\":\"PRUEBA\",\"apellidoMaterno\":\"\",\"apellidoCasada\":\"\",\"idGenero\":\"\",\"genero\":\"\",\"fechaNaciomiento\":\"\",\"celular\":\"8383747472\",\"email\":\"\",\"idNacionalidad\":0,\"nacionalidadDes\":\"\",\"idLugarNacimiento\":0,\"lugarNacimientoDes\":\"\",\"idEstadoCivil\":0,\"estadoCivil\":\"\",\"curp\":\"\",\"rfc\":\"\",\"dni\":\"\",\"idParentesco\":11,\"parentescoDes\":\"TIO (A)\",\"telefonoCasa\":\"\"}]},\"documentos\":{\"porcentaje\":100,\"bloqueado\":0,\"editable\":1,\"guardado\":0,\"documento\":[{\"idDocumento\":\"1\",\"documentoDes\":\"Identificación Oficial\",\"textoDigitalizacion\":\"\",\"idCompania\":\"\",\"companiaDes\":\"\",\"idTipoDocumento\":2,\"tipoDocumentoDes\":\"PASAPORTE (VIGENTE)\",\"fechaVigencia\":\"\",\"status\":6,\"idTipoPersona\":1,\"idPersona\":\"20180925074709580588\",\"consecutivoPersona\":0,\"idMotivoRechazo\":0,\"observacion\":\"\",\"cantidad\":2,\"banderaMod\":0},{\"idDocumento\":\"2\",\"documentoDes\":\"Comprobante de Domicilio\",\"textoDigitalizacion\":\"\",\"idCompania\":\"\",\"companiaDes\":\"\",\"idTipoDocumento\":1,\"tipoDocumentoDes\":\"Recibo de luz\",\"fechaVigencia\":\"10/11/2028\",\"status\":6,\"idTipoPersona\":1,\"idPersona\":\"20180925074709580588\",\"consecutivoPersona\":0,\"idMotivoRechazo\":0,\"observacion\":\"\",\"cantidad\":1,\"banderaMod\":0},{\"idDocumento\":\"3\",\"documentoDes\":\"Comprobante de Ingresos\",\"textoDigitalizacion\":\"\",\"idCompania\":\"\",\"companiaDes\":\"\",\"idTipoDocumento\":0,\"tipoDocumentoDes\":\"\",\"fechaVigencia\":\"\",\"status\":6,\"idTipoPersona\":1,\"idPersona\":\"20180925074709580588\",\"consecutivoPersona\":0,\"idMotivoRechazo\":0,\"observacion\":\"\",\"cantidad\":1,\"banderaMod\":0}]},\"contratos\":{\"porcentaje\":100,\"bloqueado\":0,\"editable\":1,\"guardado\":0,\"contrato\":[{\"idContrato\":\"1\",\"statusFirma\":1,\"idPersona\":\"\",\"descripcion\":\"Aviso De Privacidad\",\"idTipoPersona\":1,\"digitalizado\":0,\"version\":5},{\"idContrato\":\"2\",\"statusFirma\":1,\"idPersona\":\"\",\"descripcion\":\"Buró de Crédito\",\"idTipoPersona\":1,\"digitalizado\":0,\"version\":0},{\"idContrato\":\"3\",\"statusFirma\":1,\"idPersona\":\"20180925074709580588\",\"descripcion\":\"Contrato y Carátula de Crédito\",\"idTipoPersona\":1,\"digitalizado\":1,\"version\":0},{\"idContrato\":\"4\",\"statusFirma\":1,\"idPersona\":\"20180925074709580588\",\"descripcion\":\"Solicitud de Crédito\",\"idTipoPersona\":1,\"digitalizado\":1,\"version\":0}]},\"lineaDeCredito\":{\"capacidadDePagoTotal\":0,\"capacidadDePagoOcupada\":0,\"capacidadDePagoDisponible\":0,\"siguientePago\":0,\"pagoAntesDe\":\"\",\"bonificacion\":0,\"liquidarAhora\":0,\"tipoPago\":\"\",\"estatus\":\"\"},\"seguroDeVida\":{\"nombreSeguro\":\"\",\"opcionSeguro\":0,\"idSeguro\":\"\",\"precioSeguro\":0,\"sobrePrecioSeguro\":0,\"abonoSeguro\":0,\"ultimoAbonoSeguro\":0,\"totalSeguro\":0,\"clavePromocion\":\"\",\"comisionVenta\":0,\"montoFinal\":0,\"montoInicial\":0,\"esDefault\":0},\"bazDigital\":null,\"tarjetasCredito\":null,\"lugarOriginacion\":\"\",\"existeEdicion\":0,\"folioMCO\":\"\",\"mesaControl\":{\"folioMCO\":\"\",\"fechaGeneraFolio\":\"\",\"contEdicion\":0,\"existeEdicion\":0,\"cometario\":\"\",\"origenEdicion\":\"INVESTIGACION (JVC)\",\"contEdicionExpediente\":1,\"datosEditadosJV\":[6],\"edicionExpediente\":\"0\",\"datosEdicionExpediente\":{\"digitalizacionComprobanteDomicilio\":1,\"digitalizacionIdentificacion\":0,\"digitalizacionComprobanteIngresos\":1,\"digitalizacionComprobanteArraigo\":0,\"fechadigitalizacionComprobanteDomicilio\":\"25/09/2018\",\"fechadigitalizacionIdentificacion\":\"\",\"fechadigitalizacionComprobanteIngresos\":\"25/09/2018\",\"fechadigitalizacionComprobanteArraigo\":\"\"},\"tareaMCO\":\"\",\"numeroDeCondicionamiento\":0,\"tipoCondicionamiento\":0},\"flujoSolicitudADN\":99,\"generadaDesdeRechazo\":0,\"fechaDesdeRechazo\":\"\",\"hitBuro\":0,\"campana\":\"\",\"idEmpleadoTarjeta\":\"928920\",\"solicitudMigrada\":0,\"idCitaJVC\":\"1761\",\"folioRecomendador\":\"\",\"banderaFolioRecomendador\":0,\"obligadoSolidario\":null,\"tipoOferta\":0,\"ofertaSeleccionadaMCO\":0,\"tipoIdentificacion\":3,\"ligarTazReactivacion\":0,\"tipoAvisoPrivacidad\":\"\",\"evidencia\":\"\",\"promocioCelular\":0,\"ldcorocomprobable\":0,\"ldcoronoComprobable\":0}");
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				var edad;
				var edadAnio = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento.split("/")[2];
				var edadMes = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento.split("/")[1];
				var edadDia = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento.split("/")[0];
//				edad = calcularEdad("1991", "06", "10");
				edad = calcularEdad(edadAnio, edadMes, edadDia)
				var jsonRequest =  {
					"idProducto": $rootScope.solicitudJson.idProducto.toString(),//24
					"edad": edad.toString(),//27
					"periodo": getPeriodos($rootScope.solicitudJson.idProducto),//"1,2"
					"idColor": $rootScope.solicitudJson.banderaIngresos == 1 ? $rootScope.solicitudJson.idColor.toString() : $rootScope.solicitudJson.idColorNC.toString(),
				};
				solicitudService.obtenerLimitesDeCredito(jsonRequest).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if( data.data.codigo == RESPONSE_CODIGO_EXITO ){		 						 						 					
								var responseJson = JSON.parse(data.data.respuesta);
								if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
									if( parseInt(responseJson.data.RESULTADO) == 0 ){
										$scope.resultadosObtenerLimitesDeCreditoJson = responseJson.data;
										/**
										 * Función manda a llamar el modal que muestra los limites de credito
										 */
										modalService.opcionCreditoModal("Opciones de Crédito", "bgAzul",$scope)
									} else {
//										En caso de que el SP no responda correctamente, se continua el flujo como si no existieran los limites
										generalService.locationPath( "/credito" );
										$rootScope.informeRecomendado();
									}
								}
							}
						}, function(error){  
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							generalService.locationPath( "/credito" );
							$rootScope.informeRecomendado();
						}	
				);
			} else {
//				En caso de que la sucursal tenga la funcionalidad desactivada, se continua el flujo como si no existieran los limites
				generalService.locationPath( "/credito" );
				$rootScope.informeRecomendado();
			}
			}
		}
		
		$scope.rescatePrestamoFaseII = function(){			
			$scope.muestraBoton = false;
			$scope.muestraAlertaNuevoBuro=false;
			$scope.muestraMensajeNuevoBuro=false;
			
			modalService.rescatePrestamoFaseIIModal("En Banco Azteca le decimos CÓMO SÍ a nuestros clientes", $rootScope.solicitudJson.marca ).then(
				function(estatus) {																												
					console.log("ok");
					if($rootScope.solicitudJson.idProducto!=ID_PRODUCTO.prestamoPersonal)
						$scope.showResumenMonto = false;
					$scope.calculaCPConsumo();
					$scope.validaEdicionSecciones();
					$scope.buildMenuList();
				}, function(exito) {
					if(exito){
						if($rootScope.solicitudJson.idProducto!=ID_PRODUCTO.prestamoPersonal)
							$scope.showResumenMonto = false;
						$scope.muestraAlertasNuevoCotizador();
						$timeout( loadProgressbar, 0 );
						$scope.calculaCPConsumo();
						$scope.validaEdicionSecciones();
						$scope.buildMenuList();
					}
				}
			);
	    }
		
		$scope.rescateConsumoFaseIII = function(){
	    			 
			$scope.muestraBoton = false;
			$scope.muestraAlertaNuevoBuro=false;
			$scope.muestraMensajeNuevoBuro=false;
			generalService.setArrayValue("21Rescate",null);
			
			modalService.rescateConsumoFaseIIIModal("En Banco Azteca le decimos CÓMO SÍ a nuestros clientes", $rootScope.solicitudJson.idProducto ).then( 
					function(exito){
						$scope.calculaCPConsumo();
						$scope.buildMenuList();
					}, function(error){
						$scope.calculaCPConsumo();
						$scope.buildMenuList();
			});
		}
		
		$scope.rescateItalikaFaseIII = function(){
			
			$scope.muestraBoton = false;
			$scope.muestraAlertaNuevoBuro=false;
			$scope.muestraMensajeNuevoBuro=false;
			
			modalService.rescateItalikaFaseIIIModal("En Banco Azteca le decimos CÓMO SÍ a nuestros clientes", null ).then( 
					function(exito){
						$scope.calculaCPConsumo();
						$scope.buildMenuList();
					}, function(error){
						$scope.calculaCPConsumo();
						$scope.buildMenuList();
			});
	    }
			
		$scope.rescateTelefoniaFaseIII = function(){
					
			$scope.muestraBoton = false;
			$scope.muestraAlertaNuevoBuro=false;
			$scope.muestraMensajeNuevoBuro=false;
			
			modalService.rescateTelefoniaFaseIIIModal("En Banco Azteca le decimos CÓMO SÍ a nuestros clientes", null ).then(
				function(data){
					$scope.calculaCPConsumo();
					$scope.buildMenuList();
				}, function(error){
					$scope.calculaCPConsumo();
					$scope.buildMenuList();
				});
		}
				
		$scope.nvoPreaprobados = function(){
			if($rootScope.ejecutarEncuentaPreaprobado){
		    	if($rootScope.solicitudJson.idProducto == PRODUCTOS.prestamoPersonal.ID.valor){
		    		modalService.cotizadorPP("Felicidades", null ).then( 
							function(exito){
//								if($rootScope.ejecutarEncuentaPreaprobado){
									modalService.preguntaPreaprobado("Felicidades",null).then( 
											function(exito){
												generalService.locationPath("/ochoPasos",true);
											}, function(error){
												generalService.locationPath("/ochoPasos",true);
											});
//								}else
//									generalService.locationPath("/ochoPasos",true);
							}, function(error){
								modalService.preguntaPreaprobado("Rechazado",null).then( 
										function(exito){
											$rootScope.quemarFolioPreaprobadoNvoPreap(QUEMAR_FOLIO_STATUS_NVOPREAP.rechazado,2);
										}, function(error){
											$rootScope.quemarFolioPreaprobadoNvoPreap(QUEMAR_FOLIO_STATUS_NVOPREAP.rechazado,2);
										});
								
					});
		    	}else if($rootScope.solicitudJson.idProducto == PRODUCTOS.consumo.ID.valor || $rootScope.solicitudJson.idProducto == PRODUCTOS.italika.ID.valor ||
		    			 $rootScope.solicitudJson.idProducto == PRODUCTOS.telefonia.ID.valor || $rootScope.solicitudJson.idProducto == PRODUCTOS.tarjetaAzteca.ID.valor){
			    		modalService.preAprobados("Felicidades", null ).then( 
								function(exito){
//									if($rootScope.ejecutarEncuentaPreaprobado){
										modalService.preguntaPreaprobado("Felicidades",null).then( 
												function(exito){
													generalService.locationPath("/ochoPasos",true);
												}, function(error){
													generalService.locationPath("/ochoPasos",true);
												});
//									}else
//										generalService.locationPath("/ochoPasos",true);
								}, function(error){
									modalService.preguntaPreaprobado("Rechazado",null).then( 
											function(exito){
												$rootScope.quemarFolioPreaprobadoNvoPreap(QUEMAR_FOLIO_STATUS_NVOPREAP.rechazado,2);
											}, function(error){
												$rootScope.quemarFolioPreaprobadoNvoPreap(QUEMAR_FOLIO_STATUS_NVOPREAP.rechazado,2);
											});
						});
		    	}
		    }else
		    	generalService.locationPath("/ochoPasos",true);
		}

		$scope.obtenerVerificacion = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.obtenerTipoVerificacion( $rootScope.solicitudJson.idSolicitud, PROCESOS.PIZ ).then(
					function(data){						
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							var response = JSON.parse(data.data.respuesta);
							$rootScope.tipoVerificacion = response.codigo;
							$scope.enviaVisitaAsesor();
							console.log("Tipo de Verificación: " + response.descripcion);																						
						}else{
							$rootScope.message("¡Error!", 
									["Respuesta: " + data.data.respuesta],
									"Aceptar"
							);
						}
					}, function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("¡Error!", 
								["Hubo un inconveniente al consumir el servicio que valida la verificación, favor de intentar nuevamente"],
								"Aceptar"
						);
					}
				);			
		};
	    
	});
	
});