'use strict';

define( ["app"], function ( app ){


	app.controller( "ofertaController", function ( $timeout, $scope, $rootScope, $location, loginService, modalService, 
												generalService, clienteUnicoService, buroService ) {
		
		var returnConfirm = {
			"confirm": true,
			"data": null
		};
		
		$scope.init = function(){
			
			console.log( $rootScope.solicitudJson );
			
			if( $rootScope.solicitudJson.cotizacion.clientes[0].nombre )
				$scope.nombre = $rootScope.solicitudJson.cotizacion.clientes[0].nombre;
			else
				$scope.nombre = "José Arturo";
			
			if( $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno )
				$scope.apellidoPaterno = $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno;
			else
				$scope.apellidoPaterno = "Diosdado";
			
			if( $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno )
				$scope.apellidoMaterno = $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno;
			else
				$scope.apellidoMaterno = "González";
			
			$scope.nombreCompleto = $scope.nombre + " " + $scope.apellidoPaterno + " " + $scope.apellidoMaterno;
			
		};/* END INIT FUNCTION */
		
		$scope.presentaComprobante = function(){
			
			$rootScope.solicitudJson.banderaIngresos = 1;
			$rootScope.solicitudJson.banderaOfertaCP = 1;
		
			returnConfirm.confirm = true;
			
			$rootScope.onceOfert = true;
			$scope.confirm( returnConfirm );
			
		};/* END PRESENTA COMPROBANTE FUNCTION */
		
		$scope.continuar = function(){
			
			$rootScope.solicitudJson.banderaIngresos = 0;
			$rootScope.solicitudJson.banderaOfertaCP = 1;
			
			returnConfirm.confirm = false;
			
			$rootScope.onceOfert = true;
			$scope.closeThisDialog( returnConfirm );
			
		};/* END CONTINUAR FUNCTION */
	    		
	});/*END APP FACTORY - ofertaController*/
	
});