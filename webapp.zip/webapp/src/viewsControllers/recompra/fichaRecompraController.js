'use strict';

define(["app"], function (app) {

	app.controller('fichaRecompraController',['$rootScope', '$scope', '$location', 'recompraService', 'modalService', 'generalService' ,
		function(  $rootScope, $scope, $location, recompraService, modalService, generalService){
		
		$scope.clienteDatos="";
		$scope.isAutorizados="false";
		
		$scope.init = function(){
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			
			console.log($rootScope.datosGenerales[$rootScope.idSeleccionado]);
			
			$scope.clienteDatos = $rootScope.datosGenerales[$rootScope.idSeleccionado]; 
			
			var pais=$scope.clienteDatos.cliente.pais;
			var canal=$scope.clienteDatos.cliente.canal;
			var sucursal=$scope.clienteDatos.cliente.sucursal;
			var folio=$scope.clienteDatos.cliente.folio;
			var foto=$scope.clienteDatos.cliente.foto;
			
			$scope.CU=pais+"-"+canal+"-"+sucursal+"-"+folio;
			
			//var CU = "1-1-673-103821";
			
			console.log($scope.clienteDatos);
			
			console.log("***********************");
			console.log($scope.CU);
			console.log("************************");
			
			
//			$scope.validaHuella($scope.CU);
			
		};
		
		$scope.validaHuella = function(cu){
			
			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) > -1 )
				$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.EXITO, matches:["OK"]} );
			
			else{
			
				if ( configuracion.origen.tienda ){
					$rootScope.waitLoaderStatus = LOADER_SHOW;					
					//$rootScope.verificarHuella( 'codigoSolicitudId', 'responseVerificarHuellaIpad', [$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico]);
					$rootScope.verificarHuella( 'recompraFicha', 'responseVerificarHuellaIpad',[cu]);	
					
				}else{
					if( generalService.isProduccion() ){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						modalService.huellaModal("bgAzul");
					}else
						alert("llega al else");
						$scope.responseVerificarHuellaIpad( {codigo:VALIDA_HUELLA_RESPONSE.COMPONENTE_CANCELADO_PORUSR, matches:["OK"]} );
				}			
					
			}
			
			
				
		};
		
		$scope.responseVerificarHuellaIpad = function(response) {
			
			$rootScope.loggerIpad("responseVerificarHuellaIpad", null, response);
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			
			
			switch(response.codigo){
				case VALIDA_HUELLA_RESPONSE.EXITO:	
					break;
				case VALIDA_HUELLA_RESPONSE.ERROR:	
					$rootScope.message("Error "+response.codigo,[ "Error al validar la huella."], "Aceptar");
				case VALIDA_HUELLA_RESPONSE.ERROR_COMPONENTE:
					$rootScope.message("Error "+response.codigo,[ "Error en el componente de huella."], "Aceptar");
				case VALIDA_HUELLA_RESPONSE.NO_SE_ENCONTARON_HUELLAS:
					//aqui
					generalService.locationPath("/recompra");
					break;
				case VALIDA_HUELLA_RESPONSE.NO_HAY_COINCIDENCIAS:
					//aqui
					generalService.locationPath("/recompra");
					break;
					
				case VALIDA_HUELLA_RESPONSE.COMPONENTE_CANCELADO_PORUSR:	
					generalService.locationPath("/recompra");
					break;											
					
				default:
					$rootScope.message( "Componete de huella", ["Código "+response.codigo+" no definido. "], "Aceptar");
					generalService.locationPath("/recompra");
					break;
				
			}	
			
		}
		
		$scope.regresaRecompra = function(){
			generalService.cleanRootScope($rootScope);
			generalService.buildSolicitudJson($rootScope, null);
			generalService.locationPath("/recompra");
	    }
		
		$scope.recompraRenovacion=function(){
			
			var clienteUnico = $scope.CU;
			var cu = "";
			var clienteTienda = $rootScope.solicitudJson.cotizacion.clientes[0].clienteTienda;
			var cTienda = "";
			
			if(clienteUnico != "") {
				cu = clienteUnico.split("-");
			} else {
				cu = "0-0-0000-0000";
				cu = cu.split("-");
			}
			
			if(clienteTienda != "") {
				cTienda = clienteUnico.split("-");
			} else {
				cTienda = "0-0-0000-0000";
				cTienda = cTienda.split("-");	
			}
			
			var jsonRecompra = {
					   "OperacionVenta": {
					      "Dispositivo": $rootScope.solicitudJson.tipoDispositivo,
					      "Origen": "NOC",
					      "No_Solicitud":$rootScope.solicitudJson.idSolicitud
					   },
					   "DatosSucursal": {
					        "MAC": $rootScope.sucursalSession.MAC,
					        "IP": $rootScope.sucursalSession.IP,
					        "terminalBancaria": $rootScope.sucursalSession.terminalBancaria,
					        "workstation": $rootScope.sucursalSession.workstation,
					        "canalAlnova": $rootScope.sucursalSession.canalAlnova,
					        "canalCU": $rootScope.sucursalSession.canalCU,
					        "idSucursal": $rootScope.sucursalSession.idSucursal,
					        "nombreSucursal": $rootScope.sucursalSession.nombreSucursal,
					        "idCanal": $rootScope.sucursalSession.idCanal,
					        "descCanal": $rootScope.sucursalSession.descCanal,
					        "idPais": $rootScope.sucursalSession.idPais,
					        "pais": $rootScope.sucursalSession.pais,
					        "estado": $rootScope.sucursalSession.estado,
					        "poblacion": $rootScope.sucursalSession.poblacion,
					        "codigoPostal": $rootScope.sucursalSession.codigoPostal,
					        "colonia": $rootScope.sucursalSession.colonia,
					        "idRegion": $rootScope.sucursalSession.idRegion,
					        "region": $rootScope.sucursalSession.region,
					        "idZona": $rootScope.sucursalSession.idZona,
					        "zona": $rootScope.sucursalSession.zona
					    },
					    "DatosUsuario": {
					        "noEmpleado": $rootScope.userSession.noEmpleado,
					        "nombre": $rootScope.userSession.nombre,
					        "apellidoPaterno": $rootScope.userSession.apellidoPaterno,
					        "apellidoMaterno": $rootScope.userSession.apellidoMaterno,
					        "idPuesto": $rootScope.userSession.idPuesto,
					        "descPuesto": $rootScope.userSession.descPuesto,
					        "idPerfil": $rootScope.userSession.idPerfil,
					        "descPerfil": $rootScope.userSession.descPerfil,
					        "ticket": generalService.getArrayValue('ticket')
					    },
					    "DatosCliente": {
					        "nombreCliente": $rootScope.solicitudJson.cotizacion.clientes[0].nombre + " " + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno + " " + $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
					        "ClienteUnico": {
					            "Pais": cu[0],
					            "Canal": cu[1],
					            "Sucursal": cu[2],
					            "Folio": cu[3]
					        },
					        "ClienteTienda": {
					            "Negocio": cTienda[0],
					            "Tienda": cTienda[1],
					            "ClienteId": cTienda[2],
					            "DigitoVer": cTienda[3]
					        }
					    }
			};

			var solicitudReplace = JSON.stringify(jsonRecompra).split("\"").join("'");
			solicitudReplace = solicitudReplace.split("\\n").join("");
			solicitudReplace = solicitudReplace.split("\\t").join("");

			$rootScope.guardaDatosIpad("idProducto", solicitudReplace);

			//$rootScope.cargaDato("idProducto","commoCtrlDivId", "responseDatosUsuarios");
			if(configuracion.so.windows)
				//window.location.assign(PORTAL_RECOMPRA+'#/Credito=' + $rootScope.solicitudJson.idSolicitud	+ "X");
				window.location.assign(PORTAL_RECOMPRA);
			else
				$rootScope.executeAction( "recompra", "respuestaRecompra", {nombre:"reLoadWebViewRecompra"} );
		}
		
		
		
		
	}]);
});



