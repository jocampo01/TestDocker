'use strict';

define(["app"], function (app) {

	app.controller("referenciasController", function ($timeout, $scope, $rootScope, referenciasService, modalService, generalService, solicitudService, buroService, 
													  messageData, validateService) {
		
		$scope.pageClass = generalService.calculaVistas($rootScope.paginaActual,$rootScope.paginaAnterior);
		$scope.bloqueaSeccion = $rootScope.solicitudJson.referencias.editable;
		
		$scope.opcionalTelefono = ['true','true'];
		$scope.opcionalCelular = ['false','false'];
		
		$scope.aPaterno1 = false;
		$scope.aMaterno1 = false;
		
		$scope.aPaterno2 = false;
		$scope.aMaterno3 = false;
		
		var contadorCel = 0;
		
		var empleos=[];
		$scope.telefono=[{
			celular: "",
			telefono: ""
		},{
			celular: "",
			telefono: ""
		}]
		
		$scope.validaApellidos = function(aPaterno, aMaterno){
			var ref1AP = $rootScope.solicitudJson.referencias.referencia[0].apellidoPaterno;
			var ref1AM = $rootScope.solicitudJson.referencias.referencia[0].apellidoMaterno;
			var ref2AP = $rootScope.solicitudJson.referencias.referencia[1].apellidoPaterno;
			var ref2AM = $rootScope.solicitudJson.referencias.referencia[1].apellidoMaterno;
			
			if(!generalService.isEmpty(ref1AP) && !generalService.isEmpty(ref2AP)){
				$scope._aPaterno.opcional = false;
				$scope._aMaterno.opcional = true;
			}else if(!generalService.isEmpty(ref1AP) && !generalService.isEmpty(ref2AM)){
				$scope._aPaterno.opcional = true;
				$scope._aMaterno.opcional = true;
			}else if(!generalService.isEmpty(ref1AM) && !generalService.isEmpty(ref2AP)){
				$scope._aPaterno.opcional = true;
				$scope._aMaterno.opcional = true;
			}else if(!generalService.isEmpty(ref1AM) && !generalService.isEmpty(ref2AM)){
				$scope._aPaterno.opcional = true;
				$scope._aMaterno.opcional = false;
			}else {
				$scope._aPaterno.opcional = false;
				$scope._aMaterno.opcional = true;
			}
	 	}
		
		$scope.validaTelefonos = function(telefonoRef, celularRef, index ){			
			if( generalService.isEmpty(telefonoRef) && !generalService.isEmpty(celularRef)){
				$scope.opcionalTelefono[index]='true';
				$scope.opcionalCelular[index]='false'; 
				
			}else if( !generalService.isEmpty(telefonoRef) && generalService.isEmpty(celularRef)){
				$scope.opcionalTelefono[index]='false';
				$scope.opcionalCelular[index]='true'; 

			}else{
				$scope.opcionalTelefono[index]='true'; 
				$scope.opcionalCelular[index]='false'; 

			}
									
		};
		
		
		
		$scope.init = function(){	
			contadorCel = 0;
			
			if( generalService.existeSolicitud($rootScope.solicitudJson) ){
				
				/*\Se agrega un evento para la bitacora\*/
//				(Referencias)
				$rootScope.addEvent( BITACORA.SECCION.referencias.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, $rootScope.solicitudJson.referencias.porcentaje, BITACORA.SECCION.referencias.guardarEnBD );
				/*\Se agrega un evento para la bitacora\*/
				
				$scope.showPage = true;
				
				if( messageData ){
					if (configuracion.origen.tienda)
						$scope.origen="TIENDA";
					else
						$scope.origen="WEB";
						generalService.setMapping(  MODEL_VISTAS_JSON );
						var parentesco = generalService.construirCatalogo("CATALOGO PARENTESCO");	
						$scope.dataKey = "FRONT PRESTAMOS PERSONALES.REFERENCIAS";
						
						$scope.vistaDatosUsuario=configuracion.datosUsuario.opcion=0;
						$scope.labelTiempo=generalService.labelTiempo;
						$scope.labelMin=generalService.labelMin;
						$scope.beneficiario1 = "Beneficiario 01";
						$scope.beneficiario2 = "Beneficiario 02";
						$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";
						$scope.labelTiempo=MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO TIEMPO."+$scope.origen+".valor"];
						$scope.labelMin=" " + MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.OCHO PASOS.TEXTO MIN."+$scope.origen+".valor"];
						$scope.titulo = MODEL_VISTAS_JSON['FRONT PRESTAMOS PERSONALES.REFERENCIAS.TITULO.'+$scope.origen+'.valor'];
						$scope.subtitulo1 = MODEL_VISTAS_JSON['FRONT PRESTAMOS PERSONALES.REFERENCIAS.ETIQUETA PRIMERO.'+$scope.origen+'.valor'];
						$scope.subtitulo2 =  MODEL_VISTAS_JSON['FRONT PRESTAMOS PERSONALES.REFERENCIAS.ETIQUETA SEGUNDO.'+$scope.origen+'.valor'];
						$scope.btnGuardar =  MODEL_VISTAS_JSON['FRONT PRESTAMOS PERSONALES.REFERENCIAS.BOTON GUARDAR.'+$scope.origen+'.valor']
						generalService.setRespaldo($rootScope.solicitudJson);	
						
						$scope._nomnbre =  {
								"visible": generalService.getDatafromCategory("REFERENCIAS", "NOMBRE","VISIBLE.valor" ),
								"longitudMaxima" : generalService.getDatafromCategory("REFERENCIAS", "NOMBRE","LONGMAX.valor" ),
								"longitudMinima" : generalService.getDatafromCategory("REFERENCIAS", "NOMBRE","LONGMIN.valor" ),
								"obligatorio" : generalService.getDatafromCategory("REFERENCIAS", "NOMBRE",".OBLIGATORIO.valor" ),
								"marcaAgua" : generalService.getDatafromCategory("REFERENCIAS", "NOMBRE","MARCAAGUA.valor" ),
								"disabled": generalService.getDatafromCategory("REFERENCIAS", "NOMBRE","DISABLED.valor" ),
								"opcional": generalService.getDatafromCategory("REFERENCIAS", "NOMBRE","OPCIONAL.valor" ),
								"formato" : generalService.getDatafromCategory("REFERENCIAS", "NOMBRE","FORMATO.valor" ),
								"valor": ""
						}
						
						$scope._aPaterno =  {
								"visible": generalService.getDatafromCategory("REFERENCIAS", "APELLIDO PATERNO","VISIBLE.valor" ),
								"longitudMaxima" : generalService.getDatafromCategory("REFERENCIAS", "APELLIDO PATERNO","LONGMAX.valor" ),
								"longitudMinima" : generalService.getDatafromCategory("REFERENCIAS", "APELLIDO PATERNO","LONGMIN.valor" ),
								"obligatorio" : generalService.getDatafromCategory("REFERENCIAS", "APELLIDO PATERNO",".OBLIGATORIO.valor" ),
								"marcaAgua" : generalService.getDatafromCategory("REFERENCIAS", "APELLIDO PATERNO","MARCAAGUA.valor" ),
								"disabled": generalService.getDatafromCategory("REFERENCIAS", "APELLIDO PATERNO","DISABLED.valor" ), 
								"opcional": generalService.getDatafromCategory("REFERENCIAS", "APELLIDO PATERNO","OPCIONAL.valor" ),
								"formato" : generalService.getDatafromCategory("REFERENCIAS", "APELLIDO PATERNO","FORMATO.valor" ),
								"valor": ""
						}
						
						$scope._aMaterno =  {
								"visible": generalService.getDatafromCategory("REFERENCIAS", "APELLIDO MATERNO","VISIBLE.valor" ),
								"longitudMaxima" : generalService.getDatafromCategory("REFERENCIAS", "APELLIDO MATERNO","LONGMAX.valor" ),
								"longitudMinima" : generalService.getDatafromCategory("REFERENCIAS", "APELLIDO MATERNO","LONGMIN.valor" ),
								"obligatorio" : generalService.getDatafromCategory("REFERENCIAS", "APELLIDO MATERNO",".OBLIGATORIO.valor" ),
								"marcaAgua" : generalService.getDatafromCategory("REFERENCIAS", "APELLIDO MATERNO","MARCAAGUA.valor" ),
								"opcional": generalService.getDatafromCategory("REFERENCIAS", "APELLIDO MATERNO","OPCIONAL.valor" ),
								"disabled": generalService.getDatafromCategory("REFERENCIAS", "APELLIDO MATERNO","DISABLED.valor" ), 
								"formato" : generalService.getDatafromCategory("REFERENCIAS", "APELLIDO MATERNO","FORMATO.valor" ),
								"valor": ""
						}
						
						$scope._telefono =  {
								"visible": generalService.getDatafromCategory("REFERENCIAS", "TELEFONO","VISIBLE.valor" ),
								"longitudMaxima" : generalService.getDatafromCategory("REFERENCIAS", "TELEFONO","LONGMAX.valor" ),
								"longitudMinima" : generalService.getDatafromCategory("REFERENCIAS", "TELEFONO","LONGMIN.valor" ),
								"obligatorio" : generalService.getDatafromCategory("REFERENCIAS", "TELEFONO",".OBLIGATORIO.valor" ),
								"marcaAgua" : generalService.getDatafromCategory("REFERENCIAS", "TELEFONO","MARCAAGUA.valor" ),
								"opcional": generalService.getDatafromCategory("REFERENCIAS", "TELEFONO","OPCIONAL.valor" ),
								"disabled": generalService.getDatafromCategory("REFERENCIAS", "TELEFONO","DISABLED.valor" ), 
								"formato" : generalService.getDatafromCategory("REFERENCIAS", "TELEFONO","FORMATO.valor" ),
								"valor": ["",""]
						}
						$scope._relacion =  {
								"visible": generalService.getDatafromCategory("REFERENCIAS", "RELACION","VISIBLE.valor" ),
								"obligatorio" : generalService.getDatafromCategory("REFERENCIAS", "RELACION",".OBLIGATORIO.valor" ),
								"marcaAgua" : generalService.getDatafromCategory("REFERENCIAS", "RELACION","MARCAAGUA.valor" ),
								"opcional": generalService.getDatafromCategory("REFERENCIAS", "RELACION","OPCIONAL.valor" ),
								"disabled": generalService.getDatafromCategory("REFERENCIAS", "RELACION","DESHABILITADO.valor" ),
								"buro":     generalService.getDatafromCategory("REFERENCIAS", "RELACION","BURO.valor" ),  
								"valor": ""
						}
						
						$scope._celular =  {
								"visible": generalService.getDatafromCategory("REFERENCIAS", "CELULAR" ,"VISIBLE.valor" ),
								"longitudMaxima" : generalService.getDatafromCategory("REFERENCIAS", "CELULAR" ,"LONGMAX.valor" ),
								"longitudMinima" : generalService.getDatafromCategory("REFERENCIAS", "CELULAR","LONGMIN.valor" ),
								"obligatorio" : generalService.getDatafromCategory("REFERENCIAS", "CELULAR",".OBLIGATORIO.valor" ),
								"marcaAgua" : generalService.getDatafromCategory("REFERENCIAS", "CELULAR","MARCAAGUA.valor" ),
								"opcional": generalService.getDatafromCategory("REFERENCIAS", "CELULAR","OPCIONAL.valor" ),
								"disabled": generalService.getDatafromCategory("REFERENCIAS", "CELULAR","DISABLED.valor" ), 
								"formato" : generalService.getDatafromCategory("REFERENCIAS", "CELULAR","FORMATO.valor" ),
								"valor": ["",""]
						}												
						
						
						for (var i = 0; i < $rootScope.solicitudJson.referencias.referencia.length; i++){
							$scope._telefono.valor[i] =  $rootScope.solicitudJson.referencias.referencia[i].telefonoCasa;
							$scope._celular.valor[i] = 	$rootScope.solicitudJson.referencias.referencia[i].celular;
							$scope.validaTelefonos($rootScope.solicitudJson.referencias.referencia[i].telefonoCasa, $rootScope.solicitudJson.referencias.referencia[i].celular, i);
						}
						
						$scope.combos = {"parentesco":parentesco};														
						$scope.showPage = messageData;
						if($rootScope.solicitudJson.referencias.porcentaje > 0)
							$scope.porcMayor=true;
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
														
				}	
				
			}else					
				$rootScope.message(SIN_SOLICITUD.titulo, [SIN_SOLICITUD.texto], "Aceptar", "/", $scope.titulo.colorModal, $scope.titulo.colorSeccion,null,null,null);
				 					
		};
		
		$scope.cargoRelacion=function(i){
			$rootScope.solicitudJson.referencias.referencia[i].parentescoDes = $scope.getDescripcionCatalogo($rootScope.solicitudJson.referencias.referencia[i].idParentesco,$scope.combos.parentesco);
		};
		
		$scope.getDescripcionCatalogo = function(id, lista)
	    {
			return generalService.descripcionCatalogo(id, lista);
		};
		
		
		$scope.guardar=function(){
			if(contadorCel == 0){
				var arregloCelular = [];
				
				for(var i=0;i<$scope._celular.valor.length;i++){
					if($scope._celular.valor != ""){
						arregloCelular.push($scope._celular.valor[i]);
					}
				}
				llamadaCelular(arregloCelular, 0);
			}else{
				continuaGuardar();
			}
		};
		
		function llamadaCelular(arreglo, index){
			if(index < arreglo.length){
				if(arreglo[index] != ""){
					var num = {
						numTelefono: arreglo[index].split("(").join("").split(")").join("").split(" ").join(""),
					}
	
					$rootScope.waitLoaderStatus = LOADER_SHOW;
					solicitudService.validarNumTel(num).then(
							function(data) {
								$rootScope.waitLoaderStatus = LOADER_HIDE;
								if(data.data.codigo == RESPONSE_CODIGO_EXITO){
									var jResponse = JSON.parse(data.data.respuesta);
									
									if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){							
										index = index + 1;
										llamadaCelular(arreglo, index);	
									}else{
										$scope._celular.valor[index]="";
										$rootScope.message("AVISO ", ["Captura nuevamente el número de teléfono del cliente."],"Aceptar",null,"bgCafeA", "cafe");
									}
								}else{
									contadorCel++;
									$rootScope.message("AVISO ", ["Verifíca que el número telefónico este capturado correctamente."],"Aceptar",null,"bgCafeA", "cafe");
								}							
							}, function(error){
								$rootScope.waitLoaderStatus = LOADER_HIDE; 
								$rootScope.message("AVISO", [ ERROR_SERVICE, "Error "+jResponse.codigo],"Aceptar",null,"bgRojo", "rojoR");	
							}
						);
				}else{
					index = index + 1;
					llamadaCelular(arreglo, index);	
				}
			}else{
				continuaGuardar();
			}
		}
		
		function continuaGuardar(){
			if( $scope.referenciasForm.$valid){	
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$timeout(function(){ save(); }, 1);
			}
		}				
		
		function save(){			
			if( $scope.referenciasForm.$valid){		
				
				var porcentajeant = $rootScope.solicitudJson.referencias.porcentaje;
				$rootScope.solicitudJson.referencias.porcentaje = cuentatext('referenciasForm');
				for (var i = 0; i < $rootScope.solicitudJson.referencias.referencia.length; i++){
					if ($scope._telefono.valor[i]) 
						$rootScope.solicitudJson.referencias.referencia[i].telefonoCasa  = generalService.limpiaFormato($scope._telefono.valor[i],$scope._celular.formato);
					else
						$rootScope.solicitudJson.referencias.referencia[i].telefonoCasa  = "";
						
					if ($scope._celular.valor[i]) 
						$rootScope.solicitudJson.referencias.referencia[i].celular = generalService.limpiaFormato($scope._celular.valor[i],$scope._telefono.formato);
					else
						$rootScope.solicitudJson.referencias.referencia[i].celular = "";
						
				}
				
				var solicitudJsonString = generalService.delete$$hashKey($rootScope.solicitudJson);	
				if (offLine){				
					$rootScope.cargaDocumentos();
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.porcentajes.secciones[5].porcentaje = $rootScope.solicitudJson.referencias.porcentaje;
					generalService.locationPath("/ochoPasos");
				}else{
				

				solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: SECCION_REFERENCIAS } ).then(
						function(data){
							$rootScope.waitLoaderStatus = LOADER_HIDE;

							if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
								var responseJson = JSON.parse(data.data.respuesta);								
								if(responseJson.codigo == 2){
									$rootScope.solicitudJson = responseJson.data;
									
									/*\Se agrega un evento para la bitacora\*/
//									(Referencias)
									$rootScope.addEvent( BITACORA.SECCION.referencias.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.guardar.id, $rootScope.solicitudJson.referencias.porcentaje, BITACORA.SECCION.referencias.guardarEnBD );
									/*\Se agrega un evento para la bitacora\*/
									
									$rootScope.calculaDocumentos();
									$rootScope.porcentajes.secciones[5].porcentaje = $rootScope.solicitudJson.referencias.porcentaje;
																		
									if(generalService.productosQuickFixes()){
										generalService.locationPath( "/ochoPasos",true);
									}else{
										solicitudService.validaFolioCallCenter(JSON.parse(solicitudJsonString), responseJson.data)
														.then(
																function(data){
																	if(data == null){
																		buroService.consultaBuro("bgcafe", "btn gris", "btn cafe" );
																	}else
																		generalService.locationPath(data);
																},function(error){																
																}
															);
									}
								}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
									var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
									$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
								}else{
									if(responseJson.codigo == ERROR_SOL_RECHAZADA){
										var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
										var marca = $rootScope.solicitudJson.marca;
										var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
										var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
										$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],
												"Aceptar", "/simulador",  "bgcafe" , "cafe",buildJsonDefault);
									}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
										generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
										generalService.locationPath("/ficha");
									}else{
										$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje = porcentajeant;   	    	 			                                                          
										 $rootScope.message($scope.titulo,["Error al guardar sección. Código " +
										    "de error [" + responseJson.codigo + "] no identificado."], "Aceptar",null , "bgcafe", "cafe");
									}
								}
							}else{
								$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje = porcentajeant; 
								$rootScope.message($scope.titulo,["Error en la respuesta del servicio para guardar los datos de la sección de Referencias. Por favor, reintente nuevamente."], "Aceptar", null, "bgcafe", "cafe",null,"GENERAL","ERROR GENERAL");
							}
							
						}, function(error){
							$rootScope.solicitudJson.cotizacion.clientes[0].ingresosEgresos.porcentaje = porcentajeant; 
			                $rootScope.waitLoaderStatus = LOADER_HIDE;
						}
					);
				}
			}
//				else
//				 $rootScope.message($scope.titulo,["formato de campos erroneo", "favor de verificar"], "Aceptar",null , "bgcafe", "cafe");
		};
		       
	});
	
	
});
