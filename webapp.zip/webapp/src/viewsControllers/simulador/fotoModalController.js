'use strict';

define(["app"], function (app) {
//controlador para fotoModalview	 

app.controller('fotoModalController',  function($scope,  $rootScope, ngDialog, solicitudService, modalService, callCenterService, clienteUnicoService /*, Camara*/){
	$scope.fileName = "xxxxxxxxx"
	$scope.enviarFoto =function(){
	  console.log('Mi funcion');
	  $scope.llamar();
	};
	
	$scope.tomarFoto = function(){
		 if (esIpad && configuracion.origen.tienda ){
			 $rootScope.tomarRostro("moduloPhoto1", "respuestaComponente");
		 }
	}

	$scope.llamar = function(){
		$scope.closeThisDialog();
		var nuevo_dialog = ngDialog.open({template: 'src/viewsControllers/simulador/ifeModalView.html',
			controller: 'ifeModalController',
			 data:{
					estiloTitulo: 'bgAzul'
				},
			resolve: {
				imagen: function () {
					return $scope.fileName;
				}
			}
		});
		}
	if (esIpad && configuracion.origen.tienda ){
		$rootScope.tomarRostro("moduloPhoto1", "respuestaComponente");
	}
	$scope.respuestaComponente = function (response) {
		$rootScope.loggerIpad("respuestaComponente", null, response);
		try{
		console.info("Codigo:", response.codigo);
		$scope.msg = JSON.stringify(response);
		$scope.fileName = response.cadenaJPG;
		}catch(e){
			alert(e.message);
		}
	};
});
});
//controlador para fotoModalview	