'use strict';

define(["app"], function (app) {
//controlador para credencialModalview	 

app.controller('ifeModalController', function($scope,  $rootScope, $location, ngDialog, solicitudService, modalService, callCenterService, imagen, generalService){
	$scope.previaIdenti="images/adjuntaDocumento.jpg";
	$scope.previaIdenti1 = "asdasdaaa";
	$scope.previaIdenti2 = "asdasdasd";
	$scope.mensajeError = "Error en el servidor, por favor inténtelo de nuevo mas tarde";
	 if (esIpad && configuracion.origen.tienda ){
		 $scope.tipofotoife = ["Capturar IFE (frente)", "Capturar IFE (reverso)"];
	 }
	$scope.enviarCredencial = function(){
	  console.log('Mi funcion');
//	  alert(imagen);
	  $scope.test();
	  $scope.closeThisDialog();
    };

//capturar ife
    if (esIpad && configuracion.origen.tienda ){
    	$rootScope.capturarImagenIpad($rootScope.solicitudJson.cotizacion.clientes[0].idPersona,2, $scope.tipofotoife, 5, 'ifeView',  'respExpIpad', IDENTIFICACION_OFICIAL.descripcion);
    }
    $scope.respExpIpad = function(responseIpad){
    	$rootScope.loggerIpad("respExpIpad", null, responseIpad);
		$scope.previaIdenti1 = responseIpad.arrArchBase64[0];
		$scope.previaIdenti2 = responseIpad.arrArchBase64[1];    	 
     };
//capturar ife
    
    $scope.test = function(){
		$rootScope.waitLoaderStatus = LOADER_SHOW; 
		console.log($rootScope.solicitudJson);
		var x = {
				solicitudJson: JSON.stringify($rootScope.solicitudJson),
				fotoImg: imagen,
				ifeFrenteImg: $scope.previaIdenti1,
				ifeReversoImg: $scope.previaIdenti2
		}
		callCenterService.getFolio( x ).then(
			function(data){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(data.data.codigo == RESPONSE_CODIGO_EXITO){
					var j = JSON.parse(data.data.respuesta);
					if (j.codigo == 2){
						$rootScope.solicitudJson = j.data;
						$rootScope.message("Aviso de Privacidad",[ "se ha generado una solicitud de Alta de Cliente Nuevo con el Folio: " +$rootScope.solicitudJson.folioCallCenter + " Sin embargo no fue posibleimprimir el ticket"], "Aceptar", "/ochoPasos", "bgNaranja", "naranja");
					}else{
						$rootScope.message("AVISO",[$scope.mensajeError], "Aceptar", null, "bgNaranja", "naranja");
					}
					
				}else
					$rootScope.message("AVISO",[generalService.displayMessage(data.data.descripcion)], "Aceptar", null, "bgNaranja", "naranja");
					
				
			}, function(error){
                $rootScope.waitLoaderStatus = LOADER_HIDE; 
                $rootScope.message("Call Center",[$scope.mensajeError], "Aceptar", null, "bgNaranja", "naranja");
				
			}
		);
	}
    
});
});
//controlador para credencialaModalview	