'use strict';

var imagenes = new Array();

define(["app"], function (app) {
	app.controller('modalAyudaINEController', function($rootScope, $scope) {
		
		$scope.init=function(){
			console.log($scope.valorINE);
		};
		
		$scope.cerrarModal = function(parametros){
			$scope.closeThisDialog("HOLA MUNDO");
		}
	});
});