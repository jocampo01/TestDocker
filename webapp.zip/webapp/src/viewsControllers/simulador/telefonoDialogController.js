'use strict';

define(["app"], function (app) { 
	app.controller('telefonoDialogController', function( $timeout, $scope, $rootScope, ngDialog, generalService, authService, loginService, modalService, solicitudService){
		
		$scope.caso =$scope.ngDialogData.caso;
		$scope.init=function(){
			if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
			
			$scope.titulo                  = generalService.getDataInput("TELEFONO DIALOGO","TITULO"                   ,$scope.origen);
			$scope.titulo.texto = "Aviso";
			$scope.terminosCondiciones     = generalService.getDataInput("TELEFONO DIALOGO","TERMINOS Y CONDICIONES",$scope.origen);
			$scope.codigoCelular           = generalService.getDataInput("TELEFONO DIALOGO","CODIGO CELULAR"           ,null         );
//			$scope.codigoCorreo            = generalService.getDataInput("CODIGO SEGURIDAD","CODIGO CORREO"            ,null         );
			
			$scope.celular                 = generalService.getDataInput("TELEFONO DIALOGO","CELULAR"                  ,null         ); 
			$scope.telefono                = generalService.getDataInput("TELEFONO DIALOGO","TELEFONO"                  ,null         );
			$scope.referencia              = generalService.getDataInput("TELEFONO DIALOGO","REFERENCIA"                  ,null         );
//			$scope.telefono.marcaAgua      ="Teléfono fijo (10 dígitos. Ejemplo:55 1234 5678)";
			$scope.celular.valor          = "";
			$scope.referencia.valor          = "";
			$scope.telefono.valor          = "";
//			$scope.telefono.imagen         = "images/icon-form/telefono.png";
//			$scope.referencia.imagen       = "images/icon-form/telefono.png";
//			$scope.referencia.marcaAgua    = "Referencia";
			$scope.btnAceptar              = generalService.getDataInput("TELEFONO DIALOGO","BOTON ACEPTAR"    ,$scope.origen);
//			$scope.btnAceptar.texto        = "Aceptar";
			$scope.etiqueta1               = generalService.getDataInput("TELEFONO DIALOGO","ETIQUETA CELULAR"  ,$scope.origen);
//			$scope.etiqueta1.texto         = "Infórmale a tu cliente que para continuar con su solicitud <br> es necesario que presente un teléfono celular.";
			$scope.etiqueta2               = generalService.getDataInput("TELEFONO DIALOGO","ETIQUETA FIJO"  ,$scope.origen);
//			$scope.etiqueta2.texto         = "Pregúntale a tu cliente si cuenta con número celular o teléfono fijo.";
			$scope.etiqueta3               = generalService.getDataInput("TELEFONO DIALOGO","ETIQUETA REFERENCIA"  ,$scope.origen);
//			$scope.etiqueta3.texto         = "Pregúntale a tu cliente si cuenta con alguno <br> de los siguientes medios de contacto";
		};
		
		
		
		
		$scope.negacion = function(value){
			$scope.cTerminos3 = value;
		}
		$scope.cierraDialog = function(){
			if ($scope.caso == 1){
				$('#' + $scope.ngDialogId).remove();
				$scope.closeThisDialog();
			}else{
				if (!$scope.referencia.valor && !$scope.celular.valor && !$scope.telefono.valor){
					if ($scope.cTerminos3){
						$('#' + $scope.ngDialogId).remove();
						if ($scope.caso == 3)
							$rootScope.solicitudJson.envioCelular = 1;
						$scope.confirm();			
					}else{
						$scope.forCelular.telefono.$invalid = true;
						$scope.forCelular.celular.$invalid = true;
						$scope.forCelular.telefono.$touched = true;
						$scope.forCelular.celular.$touched = true;
						if ($scope.caso == 3){
							$scope.forCelular.referencia.$invalid = true;
							$scope.forCelular.referencia.$touched = true;
						}
					}
				}else{
					$rootScope.solicitudJson.envioCelular = 1;
					if (!generalService.isEmpty($scope.referencia.valor))
						$rootScope.solicitudJson.referencias.referencia[0].telefonoCasa = generalService.limpiaFormato( $scope.referencia.valor, "NIP-#" );
					if (!generalService.isEmpty($scope.celular.valor)){
						$rootScope.solicitudJson.cotizacion.clientes[0].celular = generalService.limpiaFormato( $scope.celular.valor, "NIP-#" );
						if ($scope.caso == 3)
							$rootScope.solicitudJson.envioCelular = 1;
						else
							$rootScope.solicitudJson.envioCelular = 0;
					}
					if (!generalService.isEmpty($scope.telefono.valor))
						$rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].telefono = generalService.limpiaFormato( $scope.telefono.valor, "NIP-#" );
					$('#' + $scope.ngDialogId).remove();
					$scope.confirm();
				}
			}
		};

		$scope.validaCelular = function(){
			if ($scope.caso == 2){
				if ($scope.forCelular.celular.$touched && $scope.forCelular.celular.$invalid && $scope.forCelular.telefono.$touched && $scope.forCelular.telefono.$invalid  && !$scope.cTerminos3)
					return true;
				else
					return false;
			}
			if ($scope.caso == 3){
				if ($scope.forCelular.celular.$touched && $scope.forCelular.celular.$invalid && $scope.forCelular.telefono.$touched && $scope.forCelular.telefono.$invalid && $scope.forCelular.referencia.$touched && $scope.forCelular.referencia.$invalid &&!$scope.cTerminos3)
					return true;
				else
					return false;
			}
			console.log($scope.forCelular.celular.$touched); 
//			forCelular.celular.$touched && forCelular.celular.$invalid && forCelular.telefono.$touched && forCelular.telefono.$invalid && forCelular.referencia.$touched && forCelular.referencia.$invalid
		}
		
	});
});