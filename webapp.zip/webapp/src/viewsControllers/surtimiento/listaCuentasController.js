'use strict';

define( [ "app" ],function(app) {
	app.controller('listaCuentasController',function($rootScope, $scope, messageData, modalService, validateService,generalService, surtimientoService,tarjetaService, 
															callCenterService, solicitudService,buroService,clienteUnicoService, ngDialog, $location) {
		
		
		$scope.monto = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;
		$scope.plazo = $rootScope.solicitudJson.cotizacion.plazo;
		$scope.pago = 120;
		$scope.pagoAnticipado = 211;
		$scope.cuantaSeleccionado = "";
		$scope.cuentas = [{numero:"2321234343545234", tipo:"Guardadito"},{numero:"33333333333333333", tipo:"Nómina"},{numero:"22222222222", tipo:"Socio"},{numero:"11111111111111", tipo:"Digitall"}];
		
		$scope.init = function() {
			if (messageData) {
				if (generalService.existeSolicitud($rootScope.solicitudJson)){
					 $rootScope.waitLoaderStatus = LOADER_HIDE; 
					$scope.showPage = true;
				}else
					$rootScope.message(SIN_SOLICITUD.titulo,[ SIN_SOLICITUD.texto ],"Aceptar", "/","bgCafeZ", "cafeZ");
			} else
				$rootScope.message(ERROR_CARGA_PAGINA.titulo,[ ERROR_CARGA_PAGINA.texto ],"Aceptar", "/","bgCafeZ", "cafeZ");
		}
		
		
		$scope.setCuenta = function(cuenta){
			$scope.cuantaSeleccionado = cuenta;
		}
		
		$scope.continuar=function(){
			if($scope.cuantaSeleccionado)
				return;
			console.log("Cuenta: "+ $scope.cuantaSeleccionado);	
		}
    
	});
});