'use strict';

define( [ "app" ],function(app) {
	app.controller('surtimientoController',function($rootScope, $scope, messageData, modalService, validateService,generalService, surtimientoService,tarjetaService, 
															callCenterService, solicitudService,buroService,clienteUnicoService, ngDialog, $location) {
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		$scope.ejecutaGuardadito=true;
		var f = new Date();
		$scope.muestraTermometro = true;
		$scope.capacidadPago =  $rootScope.solicitudJson.banderaIngresos == 1 ?  $rootScope.solicitudJson.capacidadPagoComprobable : $rootScope.solicitudJson.capacidadPagoNoComprobable;
		$scope.cotizarNFL = false; //bandera para saber si ya cotizo
		$rootScope.ofertaMCO = $rootScope.solicitudJson.tipoOferta;
		var isCreditoInmediato = $rootScope.solicitudJson.idSolicitudTiendaCredInm > 0?true:false;
		if (configuracion.origen.tienda)
			$rootScope.validarTienda = true;
		else
			$rootScope.validarTienda = false;
		
		$scope.init = function() {
			if($rootScope.solicitudJson.idSeguimiento == 6  && $rootScope.solicitudJson.idProducto == 24 ){
				/*\Se agrega un evento para la bitacora\*/
				//(surtimiento)
					$rootScope.addEvent( BITACORA.SECCION.surtimiento.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, 0, BITACORA.SECCION.surtimiento.guardarEnBD );
				/*\Se agrega un evento para la bitacora\*/
				}

			if($rootScope.aperturarGuardadito && $rootScope.habilitarConsultaCuentas){
				consultaCuentas();
			}else{
				cargaVista();
			}
		};/* END INIT FUNCTION */
		
		function cargaVista(){
			$scope.manejador = "principal";
			$scope.pedido = $rootScope.solicitudJson.pedido;
			$scope.showPage = messageData;
			if (messageData) {
				if (generalService.existeSolicitud($rootScope.solicitudJson)) {
					loadView();
				} else
					$rootScope.message(SIN_SOLICITUD.titulo,[ SIN_SOLICITUD.texto ],"Aceptar", "/","bgCafeZ", "cafeZ");
			} else
				$rootScope.message(ERROR_CARGA_PAGINA.titulo,[ ERROR_CARGA_PAGINA.texto ],"Aceptar", "/","bgCafeZ", "cafeZ");
		}
		
		function loadView() {

			$scope.origen = ($rootScope.validarTienda == true) ? "TIENDA": "WEB";
			$scope.labelRegresar = "Regresar";

			$scope._titulo = generalService.getDataInput("SURTIMIENTO","TITULO", $scope.origen);
			$scope._etqPrestamo = generalService.getDataInput("SURTIMIENTO","ETIQUETA PRESTAMO",$scope.origen);
			$scope._btnEfectivo = generalService.getDataInput("SURTIMIENTO","BOTON EFECTIVO",$scope.origen);
			$scope._btnGuardadito = generalService.getDataInput("SURTIMIENTO","BOTON GUARDADITO",$scope.origen);
			$scope._btnGuardadito.texto = "Dispersión en Cuenta";
			
			var opcActivarDispersion = $rootScope.consultaFuncionalidad.consultaDispersion;
// I-MODIFICACION SIPA (QUITA SURTIMIENTO A TRAVES DE EFECTIVO)
			if($rootScope.productosSIPA($rootScope.solicitudJson.idProducto) && ($rootScope.promocionCampanas($rootScope.solicitudJson.campana) || $rootScope.campanasPreaprobadosCaptacion($rootScope.solicitudJson.campana))){
				$scope.activarEfectivo = false;
				$scope.activarGuardadito = true;
			}else{
				$scope.activarEfectivo = (opcActivarDispersion==1 || opcActivarDispersion==3)?true:false;
				$scope.activarGuardadito = (!esIpad && (opcActivarDispersion==2 || opcActivarDispersion==3))?true:false;
			}
			if($scope.activarGuardadito && ($rootScope.aperturarGuardadito && !$rootScope.habilitarGuardadito))
				$scope.activarGuardadito=false;
			if($rootScope.campanaNvoPreaprob($rootScope.solicitudJson.campana))
				$scope.activarEfectivo = true;
			
			
// F-MODIFICACION SIPA (QUITA SURTIMIENTO A TRAVES DE EFECTIVO)

			$scope.nombreCompleto = $rootScope.solicitudJson.cotizacion.clientes[0].nombre
					+ " "
					+ $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno
					+ " "
					+ $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno;
			$scope.pedido = $rootScope.solicitudJson.cotizacion.idCotizacion;
			$scope.monto = $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto;

			$scope.plazo = $rootScope.solicitudJson.cotizacion.plazo
			$scope.pagoSemanal = $rootScope.solicitudJson.cotizacion.pagoNormal;
			$scope.pagoOportuno = $rootScope.solicitudJson.cotizacion.pagoPuntual;
			$scope.ahorro = $rootScope.solicitudJson.cotizacion.pagoNormal - $rootScope.solicitudJson.cotizacion.pagoPuntual;
			if($rootScope.parametroCaptacion && !$rootScope.parametroCaptacion.recuperar){
				
				//Aqui entra si responde el portal de captación
				/*\Se agregan eventos para la bitacora\*/
//				(Surtimiento)
				$rootScope.addEvent( BITACORA.SECCION.surtimiento.id, BITACORA.SUBSECCION.respuestaCaptacion.id, BITACORA.ACCION.proceso.id, 0, BITACORA.SECCION.surtimiento.guardarEnBD );								
				/*\Se agregan eventos para la bitacora\*/
				
				$rootScope.loggerServicios("parametroCaptacion", $rootScope.parametroCaptacion);
				$scope.ligaFolioUnico();
			}
//			else
//				listadoCuentas();
			reglasVolverCotizar();
			
		};/* END LOAD VIEW FUNCTION */
		
		
		var consultaCuentas = function(){
			var jsonRequest = {
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					idSeguimiento: $rootScope.solicitudJson.idSeguimiento,
					idPais: $rootScope.solicitudJson.idPais,
					idCanal: $rootScope.solicitudJson.idCanal,
					idSucursal: $rootScope.solicitudJson.idSucursal,
					terminal: $rootScope.solicitudJson.terminal,
					clienteAlnova: $rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova,
					nombre: $rootScope.solicitudJson.cotizacion.clientes[0].nombre,
					apellidoPaterno: $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno,
					apellidoMaterno: $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
					fechaNacimiento: $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento
				};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			tarjetaService.consultaCuentasCliente(jsonRequest,PROCESOS.PSC).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if (jsonResponse.codigo == 2) {
							$scope.listaCuentas = JSON.parse(jsonResponse.data);
							var cuentaValida = false;
							if(!isCreditoInmediato){
								if($rootScope.solicitudJson.cotizacion.clientes[0].numCuenta != null && $rootScope.solicitudJson.cotizacion.clientes[0].numCuenta != ""){
									cuentaValida = validaCuentaGuardadito($rootScope.solicitudJson.cotizacion.clientes[0].numCuenta);
								}else
									cuentaValida=true;
								if(!cuentaValida)
									$rootScope.habilitarGuardadito=false;
							}else{
								if($rootScope.parametroCaptacion && $rootScope.parametroCaptacion.cuenta && $rootScope.parametroCaptacion.cuenta != ""){
									cuentaValida = validaCuentaGuardadito($rootScope.parametroCaptacion.cuenta);
									if(!cuentaValida){
										$rootScope.parametroCaptacion=null;
									}
								}else{
									if(!$rootScope.sinGuardadito){
										$rootScope.habilitarGuardadito=false;
										$rootScope.message("Apertura Guardadito", ["Indícale a tu cliente que por el momento no fue posible aperturar su cuenta Guardadito pero tenemos disponible su dinero","¡¡en Efectivo!!"], "Aceptar", null);
									}
								}
							}
							cargaVista();
						} else {
							if (jsonResponse.codigo == 618){
								if(isCreditoInmediato){
									if(!$rootScope.sinGuardadito)
										opcionAperturaGuardadito();
									else{
										$rootScope.habilitarGuardadito=false;
										$rootScope.message("Apertura Guardadito", ["Indícale a tu cliente que por el momento no fue posible aperturar su cuenta Guardadito pero tenemos disponible su dinero","¡¡en Efectivo!!"], "Aceptar", null);
										cargaVista();
									}
								}else{
									$rootScope.habilitarGuardadito=false;
									cargaVista();
								}
							}else{
								$rootScope.habilitarGuardadito=false;
								cargaVista();
							}
						}
					} else{
						$rootScope.message("Error", ["Favor de volverlo a intentarlo nuevamente"], "Aceptar", "/simulador", "bgCafeZ", "cafeZ");
					}
				},
				function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Error", ["Favor de volverlo a intentarlo nuevamente"], "Aceptar", "/simulador", "bgCafeZ", "cafeZ");
				});

		};/* END LISTADO CUENTAS FUNCION */
		
		function validaCuentaGuardadito(cuenta){
			var cuentaValida = false;
			for(var i=0;i < $scope.listaCuentas.length; i++){
				if($scope.listaCuentas[i].cuentaSelecta == cuenta){
					if(!isCreditoInmediato)
						$scope.vaciarListaCuentasApertura($scope.listaCuentas[i]); 
					cuentaValida=true;
					break;
				}
			}
			return cuentaValida;
		}
		
		function opcionAperturaGuardadito(){
	 		modalService.aperturaGuardadito("Si", "No", "bgCafe", "btn gris", "btn azul" ).then(
					function(exito){
						//ACEPTO APERTURA
						marcarAperturarGuardadito(MARCAS_SOLICITUD.aperturarGuardadito.clienteQuiere);
					},function(error){
						//NO ACEPTO APERTURA
						marcarAperturarGuardadito(MARCAS_SOLICITUD.aperturarGuardadito.clienteNoAcepto);
					}
			 );
	 	};
		
	 	function marcarAperturarGuardadito(marca){
	 		var jsonSolicitud = {
					idSolicitud: $rootScope.solicitudJson.idSolicitud,
					idSeguimiento: $rootScope.solicitudJson.idSeguimiento,
					marca: marca
			};
	 		$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.actualizarSolicitud(jsonSolicitud).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
								switch(marca){
									case MARCAS_SOLICITUD.aperturarGuardadito.clienteQuiere:
										$rootScope.aperturaCaptacion = {numeroIntentos: 0};
										$rootScope.ejecutarPortalCaptacion($rootScope.solicitudJson.idPais,$rootScope.solicitudJson.idCanal,$rootScope.solicitudJson.idSucursal,$rootScope.solicitudJson.idSolicitud,$rootScope.solicitudJson.idSeguimiento);
										break;
									case MARCAS_SOLICITUD.aperturarGuardadito.clienteNoAcepto:
										$rootScope.habilitarGuardadito=false;
										cargaVista();
										break;
								}
							}else{
								$rootScope.message("Aviso", ["Ocurrió un problema al actualizar la solicitud, favor de volver a reintentar"], "Aceptar");
							}
						}else{
							$rootScope.message("Aviso", ["Ocurrió un problema al actualizar la solicitud, favor de volver a reintentar"], "Aceptar");
						}
						
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						$rootScope.message("Aviso", ["Ocurrió un problema al actualizar la solicitud, favor de volver a reintentar"], "Aceptar");
					}
			);
	 	}
		
		$scope.ligaFolioUnico = function(){
			if(generalService.isEmpty($rootScope.solicitudJson.folioFlujoUnico) || 
			  (generalService.isEmpty($rootScope.parametroCaptacion.numTarjeta) || generalService.isEmpty($rootScope.parametroCaptacion.folioActivacionTaz)))
				$scope.detalle($rootScope.parametroCaptacion);
			else{
				var r = {
						pais: $rootScope.solicitudJson.idPais,
						canal: $rootScope.solicitudJson.idCanal,
						sucursal: $rootScope.solicitudJson.idSucursal,
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						numeroTarjeta: $rootScope.parametroCaptacion.numTarjeta,
						tipoUs: 1,
						folioGuardadito: $rootScope.parametroCaptacion.folioActivacionTaz
		    	};
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				solicitudService.ligaFolioUnico(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jResponse = JSON.parse(data.data.respuesta);
							
							if(jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){			
								$scope.detalle($rootScope.parametroCaptacion);
							}else
								$rootScope.message("Ligar Tarjeta Guardadito", ["Codigo : "+jResponse.codigo, "Error: "+jResponse.descripcion],"Aceptar",null,"bgCafeZ", "cafeZ");
													
						}else if(data.data.codigo == TARJETA_FOLIO_EN_PROCESO){
							$rootScope.message("Ligar Tarjeta", ["Codigo : "+jResponse.codigo, "Aviso: La solicitud esta siendo procesada. Por favor, espere un momento"],"Aceptar",null,"bgCafeZ", "cafeZ");
						}else{
							$rootScope.message("Error", ["Error en la respuesta del servicio para ligar el fólio único. Por favor, reintente nuevamente."],"Aceptar",null,"bgCafeZ", "cafeZ");
						}
					}, function(error){
		               $rootScope.waitLoaderStatus = LOADER_HIDE;
					}
				);
			}
		};

		$scope.guardaditoHandler = function() {
			if($scope.ejecutaGuardadito){
				$scope.ejecutaGuardadito=false;
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				$scope.validaHuella();
			}
		};

		$scope.validaHuella = function() {
			if ($rootScope.validarTienda) {
				if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) > -1 ){
					$scope.responseVerificarHuellaIpad( {codigo:0, matches:["OK"]} );
				}else{
					$rootScope.verificarHuella('surtimiento','responseVerificarHuellaIpad',	[ $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico ]);
				}
			}else{
				if($rootScope.aperturarGuardadito){
					if(isCreditoInmediato){
						if($rootScope.parametroCaptacion && $rootScope.parametroCaptacion.recuperar){
							$scope.ligaFolioUnico();
						}else{
							$scope.vaciarListaCuentasApertura($rootScope.listaCuentas);
							$scope.showPage = true;
							$scope.manejador = "deposito";
						}
					}else{
						if($rootScope.solicitudJson.cotizacion.clientes[0].numCuenta != null && $rootScope.solicitudJson.cotizacion.clientes[0].numCuenta != "")
							$scope.detalle($scope.respuestaCuentas);
						else{
							$scope.vaciarListaCuentasApertura($rootScope.listaCuentas);
							$scope.showPage = true;
							$scope.manejador = "deposito";
						}
					}
				}else
					listadoCuentas();
			}
		};

		$scope.responseVerificarHuellaIpad = function(response) {
			$rootScope.loggerIpad("responseVerificarHuellaIpadSurtimiento", null, response);
			
			try {
				if(response.codigo == RESPONSE_CODIGO_EXITO_IPAD ){
					if(response.matches){
						if($rootScope.aperturarGuardadito){
							if(isCreditoInmediato){
								if($rootScope.parametroCaptacion && $rootScope.parametroCaptacion.recuperar){
									$scope.ligaFolioUnico();
								}else{
									$scope.vaciarListaCuentasApertura($rootScope.listaCuentas);
									$scope.showPage = true;
									$scope.manejador = "deposito";
								}
							}else{
								if($rootScope.solicitudJson.cotizacion.clientes[0].numCuenta != null && $rootScope.solicitudJson.cotizacion.clientes[0].numCuenta != "")
									$scope.detalle($scope.respuestaCuentas);
								else{
									$scope.vaciarListaCuentasApertura($rootScope.listaCuentas);
									$scope.showPage = true;
									$scope.manejador = "deposito";
								}
							}
						}else{
							if($rootScope.marcaTipoDispersionSeleccionado)
								$scope.liberarPedidoSinTAZ();
							else
								listadoCuentas();
						}
					}
				}else{
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Error "+response.codigo,[ "Error al validar la huella."], "Aceptar");
				}										
			} catch (e) {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("Error al verificar la huella Surtimiento",[ e ], "Aceptar", null,"bgCafeZ", "cafeZ");
				$scope.manejador = "principal";
			}
		};

		var listadoCuentas = function(){
			tarjetaService.consultaCteAlnova($rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if (jsonResponse.codigo == TARJETA_WS_EXITO) {
							var cuentasData = jsonResponse.data;
							$scope.vaciarListaCuentas(cuentasData.consultaCuentasList);

							if ($scope.existeGuardadito) {
								$scope.manejador = "deposito";
							}else{
								$rootScope.guardaDatosIpad("IdSolicitudRecuperar",$rootScope.solicitudJson.idSolicitud);
								
//									Aquí se manda abrir el portal de captación
								/*\Se agregan eventos para la bitacora\*/
//									(Surtimiento)
								$rootScope.addEvent( BITACORA.SECCION.surtimiento.id, BITACORA.SUBSECCION.aperturaGuardadito.id, BITACORA.ACCION.proceso.id, 0, BITACORA.SECCION.surtimiento.guardarEnBD );								
								/*\Se agregan eventos para la bitacora\*/
								//Se mandan a BD los eventos almacenados en memoria
								$rootScope.enviaEventos();
								
								if(configuracion.so.windows){
									window.location.assign(PORTAL_CAPTACION+'#/Credito=' + $rootScope.solicitudJson.idSolicitud	+ "X");
								}else{
									$rootScope.executeAction( "surtimiento", "respuestaCaptacion", {nombre:"reLoadWebViewCaptacion"} );
								}
								
								$scope.ejecutaGuardadito=true;
							}
						} else {
							$rootScope.message("Error",[ jsonResponse.descripcion ],"Aceptar",null,"bgCafeZ","cafeZ");
							$scope.manejador = "principal";
						}
					} else{
						$rootScope.message("Error", [generalService.displayMessage(data.data.descripcion)], "Aceptar", null, "bgCafeZ", "cafeZ");
					}
				},
				function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Error", ["Favor de volverlo a intentarlo nuevamente"], "Aceptar", "/simulador", "bgCafeZ", "cafeZ");
				});

		};/* END LISTADO CUENTAS FUNCION */

		$scope.vaciarListaCuentas = function(listaCuentas) {
			$scope.respuestaCuentas = [];
			$scope.existeGuardadito = false;
			var cuentaCancelada = false;
			for ( var indexCuenta in listaCuentas) {
				var dataCuenta = {
					"foto" : "",
					"clienteUnico" : $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
					"cuenta" : listaCuentas[indexCuenta].cuentaSelecta,
					"tipoCuenta" : listaCuentas[indexCuenta].descProducto,
					"apellidoPaterno" : $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno,
					"apellidoMaterno" : $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
					"nombre" : $rootScope.solicitudJson.cotizacion.clientes[0].nombre,
				};
				
				/*Se agrega la validación cuentaCancelada para quitar aquellas cuentas canceladas y solo se tomen en cuenta las activas*/
				if(!listaCuentas[indexCuenta].estatusCuenta){
					console.log("Lista Cuentas " + listaCuentas);
				}else{
					cuentaCancelada = listaCuentas[indexCuenta].estatusCuenta.toUpperCase().indexOf("CANCELADA") != -1;
				}
						
				
				/*Valida las cuentas canceladas*/
				if(!cuentaCancelada){
					if (dataCuenta.tipoCuenta){
	                	if (dataCuenta.tipoCuenta.toUpperCase().indexOf("GUARDADITO") != -1) {
	                		$scope.respuestaCuentas.push(dataCuenta);
	                		$scope.existeGuardadito = true;
	                	}
	                }
				}
			}
		};/* END VACIAR LISTA CUENTAS FRUNCTION */
		
		$scope.vaciarListaCuentasApertura = function(listaCuentas) {
			$scope.respuestaCuentas = [];
			$scope.existeGuardadito = false;
			var cuentaCancelada = false;
			for ( var indexCuenta in listaCuentas) {
				var dataCuenta = {
					"foto" : "",
					"clienteUnico" : $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
					"cuenta" : listaCuentas[indexCuenta].cuentaSelecta,
					"tipoCuenta" : listaCuentas[indexCuenta].descProducto,
					"apellidoPaterno" : $rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno,
					"apellidoMaterno" : $rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno,
					"nombre" : $rootScope.solicitudJson.cotizacion.clientes[0].nombre,
				};
				
				$scope.respuestaCuentas.push(dataCuenta);
        		$scope.existeGuardadito = true;
			}
		};/* END VACIAR LISTA CUENTAS FRUNCTION */

		$scope.detalle = function(cuentaSeleccionada){
			$scope.guardarDatosLiberacion(cuentaSeleccionada)
		};

		$scope.guardarDatosLiberacion=function(cuentaSeleccionada){
			
			var r = {
				idSolicitud: $rootScope.solicitudJson.idSolicitud,
				numCuenta: cuentaSeleccionada?cuentaSeleccionada.cuenta:"",
				tipoCredito: cuentaSeleccionada?DISPERSION_GUARDADITO:DISPERSION_EFECTIVO   			
			};
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;										 												
			solicitudService.guardarDatosLiberacion(r).then(
				 function(data){
					 $rootScope.waitLoaderStatus = LOADER_HIDE;
					 
					 if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						 var responseJson = JSON.parse(data.data.respuesta);
						 
						 if( responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO ){
							 $rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.tipoDispersionSeleccionado;
							 $rootScope.solicitudJson.tipoDispersion = r.tipoCredito;
							 $scope.liberarPedidoSinTAZ();
						 }else{
							 $rootScope.message("Dispersión flujo Único",[responseJson.descripcion],"Aceptar",null,"bgCafeZ", "cafeZ");
						 }
					 }else{
						 $rootScope.message("Dispersión flujo Único", ["Error en Datos de Liberación al surtir. Por favor comuniquese con soporte"],"Aceptar",null,"bgCafeZ", "cafeZ");
					 }
				 }, function(error){
					 $rootScope.waitLoaderStatus = LOADER_HIDE; 	               
				 }
			);
		};
		
		$scope.liberarPedidoSinTAZ = function(){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			callCenterService.liberarPedidoSinTAZ( {idSolicitud: $rootScope.solicitudJson.idSolicitud} ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					
					if(data.data.codigo == RESPONSE_CODIGO_EXITO){
						var respuesta = JSON.parse(data.data.respuesta);
					
						if(respuesta.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
							$rootScope.solicitudJson = respuesta.data;
							
							/*\Se agregan eventos para la bitacora\*/
//							(Surtimiento)
					    	$rootScope.addEvent( BITACORA.SECCION.surtimiento.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.surtir.id, 0, BITACORA.SECCION.surtimiento.guardarEnBD );								
							/*\Se agregan eventos para la bitacora\*/

					    	if($rootScope.solicitudJson.tipoDispersion == DISPERSION_GUARDADITO && $rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.surtida){
					    		validarPromocion();
					    	}else{
					    		if($rootScope.consultaFuncionalidad.validaColorProductosAutorizados && ($rootScope.sucursalSession.idCanal==CANALES.elektra || $rootScope.sucursalSession.idCanal==CANALES.elektra_dinero  || $rootScope.sucursalSession.idCanal==CANALES.presta_prenda)){
									generalService.locationPath("/consultaColor");
								}else{
									generalService.locationPath("/estatus");
								}
					    	}
					    	
						}else if(respuesta.codigo == LCR_CENTRAR_SINLIBERAR_ERROR){
								//mandar mensaje
								$rootScope.message("Surtimiento Codigo: "+ respuesta.codigo,["La linea de crédito aún no está liberada, favor de intentar nuevamente en 5 minutos, si el problema persiste favor de comnicarse con soporte."], "Aceptar", "/simulador", null, null);
							}else{
								$rootScope.message("Surtimiento Codigo: " + respuesta.codigo,["Hemos detectado un inconveniente: " +respuesta.descripcion], "Aceptar", "/simulador", null, null);
							}
							//generalService.locationPath("/estatus");																
					} else{
						$rootScope.message("Surtimiento",["Se presentó un problema al consumir el servicio por favor reintente."], "Aceptar",null, null, null);
					}
				}, function(error){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Surtimiento",["Se presentó un problema al consumir el servicio por favor reintente."], "Aceptar",null, null, null);
					
				}
			);
		};
		
		var validarPromocion = function(){
			var idPlataforma = 1;
			if($rootScope.solicitudJson.idPlataforma == 6 || $rootScope.solicitudJson.idPlataforma == 7 || $rootScope.solicitudJson.idPlataforma == 9)
				idPlataforma = 2;
			var jsonRequest = {
					clienteUnico: $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
					pais: $rootScope.solicitudJson.idPais,
					canal: $rootScope.solicitudJson.idCanal,
					sucursal: $rootScope.solicitudJson.idSucursal,
					pedido: $rootScope.solicitudJson.pedido,
					plataforma: idPlataforma,
					plazo: $rootScope.solicitudJson.cotizacion.plazo,
					monto: $rootScope.solicitudJson.cotizacion.detallesCotizacion[0].monto,
					surtimientoEnLinea: "true",
					campana: $rootScope.solicitudJson.campana,
					observaciones: $rootScope.solicitudJson.observaciones
				};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			surtimientoService.consultaPromocion(jsonRequest,PROCESOS.PSC).then(
				function(data) {
					
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jsonResponse = JSON.parse(data.data.respuesta);
						
						if (jsonResponse.codigo == 90206) {
							var jsonResponsePromo = JSON.parse(jsonResponse.data);
							var isGanador = JSON.parse(jsonResponsePromo.ganador);
							if(isGanador)
								modalGanador(jsonResponsePromo);
							else{
								if($rootScope.consultaFuncionalidad.validaColorProductosAutorizados && ($rootScope.sucursalSession.idCanal==CANALES.elektra || $rootScope.sucursalSession.idCanal==CANALES.elektra_dinero  || $rootScope.sucursalSession.idCanal==CANALES.presta_prenda)){
									generalService.locationPath("/consultaColor");
								}else{
									generalService.locationPath("/estatus");
								}
							}
						}else{
							if($rootScope.consultaFuncionalidad.validaColorProductosAutorizados && ($rootScope.sucursalSession.idCanal==CANALES.elektra || $rootScope.sucursalSession.idCanal==CANALES.elektra_dinero  || $rootScope.sucursalSession.idCanal==CANALES.presta_prenda)){
								generalService.locationPath("/consultaColor");
							}else{
								generalService.locationPath("/estatus");
							}
						}
					} else{
						$rootScope.message("Error", ["Favor de volverlo a intentarlo nuevamente"], "Aceptar", "/simulador", "bgCafeZ", "cafeZ");
					}
				},
				function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Error", ["Favor de volverlo a intentarlo nuevamente"], "Aceptar", "/simulador", "bgCafeZ", "cafeZ");
				});
			
		}
		
		var modalGanador = function(jsonResponsePromo){
			modalService.buenFin(jsonResponsePromo).then(
					function(exito){
						terminarSurtimiento();
					}, function(error){
						terminarSurtimiento();
			});
		}
		
		var terminarSurtimiento = function(){
			if($rootScope.consultaFuncionalidad.validaColorProductosAutorizados && ($rootScope.sucursalSession.idCanal==CANALES.elektra || $rootScope.sucursalSession.idCanal==CANALES.elektra_dinero  || $rootScope.sucursalSession.idCanal==CANALES.presta_prenda)){
				generalService.locationPath("/consultaColor");
			}else{
				generalService.locationPath("/estatus");
			}
		}

		$scope.regresarSurtimiento = function() {
			if ($scope.manejador == "detalle")
				generalService.locationPath("/");
			else if ($scope.manejador == "deposito")
				$scope.manejador = "principal";
			else if ($scope.manejador == "principal")
				generalService.locationPath("/ochoPasos");
		};/* END REGRESAR SURTIMIENTO FUNCTION */
								
	    $scope.camelize = function(msn) {
	        // Restore original values
	    	return generalService.camelize(msn);
	    };
							     
	    $scope.location = function( pathDestino ){
	    	
	    	/*\Se agregan eventos para la bitacora\*/
//			(Surtimiento)
	    	$rootScope.addEvent( BITACORA.SECCION.surtimiento.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.surtir.id, 0, BITACORA.SECCION.surtimiento.guardarEnBD );								
			/*\Se agregan eventos para la bitacora\*/
	    	
	    	generalService.locationPath(pathDestino);							
		};
		
	    
	function reglasVolverCotizar(){
		$scope.cotizar		=	false;
		$scope.esRescate	=	false;
		if( $rootScope.consultaFuncionalidad.habilitarPDRCreditoEnEfectivo && ($rootScope.rescatePPGarantias || $rootScope.requiereObligado) )
			$scope.esRescate	=	true;
		if( $rootScope.liberacionflujoJV && ( ($rootScope.termometroHandler && $rootScope.buroConditional == BURO_RECALCULAR_PLAZO || !$rootScope.termometroHandler) ||  ($scope.esRescate && !$scope.cotizarNFL) ) )
			$scope.cotizar = true;
	}
	
    $scope.consutaMontosPlazos = function(){
    	$scope.cotizarNFL = true;
    	if($scope.esRescate){
    		if(!$rootScope.termometroHandler){
    	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
        		try{
        			var foo =  function( typeAuth ){
        				
        				if( typeAuth == RESPONSE_ORIGINACION_CODIGO_EXITO ){
    	    				$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
    	    				modalService.rescateCreditoEnEfectivo("En Banco Azteca le decimos CÓMO SÍ a nuestros clientes", $rootScope.solicitudJson.marca ).then(
    	    						function(estatus) {																												
		    							console.log("ok");
		    						},function(exito) {
										if(exito)
											loadView();
										else
											loadView();
									}
    						);
    	    					                				
	    				}else{
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							$rootScope.message("Surtirmiento",[" Ocurrió un error al consultar montos y plazos, favor de reintentar"], "Aceptar", null, null, null);
							$rootScope.buroHandler = [];
							$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
	        			}	
	        								
	        		};
        			
        			buroService.getMontosPlazos( $rootScope.solicitudJson.idSolicitud, foo );
    			}catch(e){
    				$rootScope.waitLoaderStatus = LOADER_HIDE;
    				$rootScope.message("Surtirmiento",[" Ocurrió un error al consultar montos y plazos, favor de reintentar"], "Aceptar", null, null, null);
    				$rootScope.buroHandler = [];
    				$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
    			}
        	}else{
        		modalService.rescateCreditoEnEfectivo("En Banco Azteca le decimos CÓMO SÍ a nuestros clientes", $rootScope.solicitudJson.marca ).then(
						function(estatus) {																												
							console.log("ok");
						},function(exito) {
							if(exito)
								loadView();
							else
								loadView();
						}
				);
        	}
    		
    	} else{
    		if(!$rootScope.termometroHandler){
    	    	$rootScope.waitLoaderStatus = LOADER_SHOW;
        		try{
        			var foo =  function( typeAuth ){
        				
        				if( typeAuth == RESPONSE_ORIGINACION_CODIGO_EXITO ){
    	    				$rootScope.termometroHandler = BURO_RESPUESTAWS_OK;
    	    				
    	    				modalService.cotizadorModalML("Cotizador", "bgAzul",$scope).then( 
    	    						function(estatus) {																												
    	    							console.log("ok");
    	    							}, function(exito) {
    	    									if(exito)
    	    										loadView();
    	    									else
    	    										loadView();
    	    								}
    	    						);
    	    					                				
    				}else{
        						$rootScope.waitLoaderStatus = LOADER_HIDE;
        						$rootScope.message("Surtirmiento",[" Ocurrió un error al consultar montos y plazos, favor de reintentar"], "Aceptar", null, null, null);
        						$rootScope.buroHandler = [];
        						$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
        					}	
        								
        			};
        			
        			buroService.getMontosPlazos( $rootScope.solicitudJson.idSolicitud, foo );
    			}catch(e){
    				$rootScope.waitLoaderStatus = LOADER_HIDE;
    				$rootScope.message("Surtirmiento",[" Ocurrió un error al consultar montos y plazos, favor de reintentar"], "Aceptar", null, null, null);
    				$rootScope.buroHandler = [];
    				$rootScope.termometroHandler = BURO_RESPUESTAWS_ERROR;
    			}
        	}else{
    			modalService.cotizadorModalML("Cotizador", "bgAzul",$scope).then( 
    				function(estatus) {																												
    					console.log("ok");
    					}, function(exito) {
    							if(exito)
    								loadView();
    							else
    								loadView();
    						}
    				);
        	}
    	}
    }
	    
	  ///////////////////////////////////////////////////// INICIA PARTE PARA OFRECER SEGURO EN NUEVA LIBERACION ///////////////////////////////////////////////////////////////////////////////////////////
    
    $scope.seguroVidamax = function(){
    	/*\Se agrega un evento para la bitacora\*/
		//(seguroVidamax)
			$rootScope.addEvent( BITACORA.SECCION.surtimiento.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.surtir.id, 0, BITACORA.SECCION.surtimiento.guardarEnBD );
		/*\Se agrega un evento para la bitacora\*/
    	if($rootScope.historicoMarcas.includes(150) || $rootScope.historicoMarcas.includes(151)){
    		$rootScope.loggerIpad("No se muestra seguro por RPP", req);
    		$scope.guardaditoHandler();
    	} else {
    		if($rootScope.liberacionflujoJV && ($rootScope.consultaFuncionalidad.habilitarFlujoSeguroVidamax || $rootScope.consultaFuncionalidad.habilitarFlujoSeguroVidamaxUnificado)){
            	if (EJECUTA_SEGURO && $rootScope.solicitudJson.idProducto == ID_PRODUCTO.prestamoPersonal 
           			// I-MODIFICACION SIPA (VALIDA QUITAR OFERTA DE SEGURO PARA CLIENTES SIPA)
            		&& !($rootScope.productosSIPA($rootScope.solicitudJson.idProducto) && $rootScope.promocionCampanas($rootScope.solicitudJson.campana))
            		// F-MODIFICACION SIPA (VALIDA QUITAR OFERTA DE SEGURO PARA CLIENTES SIPA)
        			/*\ Se valida que la solicitud no sea un rescate de préstamo personal\*/
        			&& generalService.consultaHistoricoMarcas([150,151])==0){
        			/*\ Se valida que la solicitud no sea un rescate de préstamo personal\*/
            		if ($rootScope.solicitudJson.banderaIngresos == 1)
        				var capacidadPago = $rootScope.solicitudJson.capacidadPagoComprobable - $rootScope.solicitudJson.cotizacion.pagoPuntual;
        			else
        				var capacidadPago = $rootScope.solicitudJson.capacidadPagoNoComprobable - $rootScope.solicitudJson.cotizacion.pagoPuntual;
        			
        			if (!$rootScope.solicitudJson.banderaSeguro){
        				$rootScope.solicitudJson.banderaSeguro = 0;
        			}
        						
        			if ( capacidadPago >= 10 && $rootScope.solicitudJson.banderaSeguro != 1 ){
        				$rootScope.waitLoaderStatus = LOADER_SHOW;
        				if($rootScope.consultaFuncionalidad.habilitarFlujoSeguroVidamaxUnificado){
        					var fechaNac =  $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento;
				    		var dma = fechaNac.split('/');
				    		var segFechaNacimiento = dma[2]+'-'+dma[1]+'-'+dma[0];
				    		var req = {
				    			tipoOferta : 1,
				    			origen : 4,
				    			cliente:{
				    				pais : $rootScope.solicitudJson.idPais,
				    				canal : $rootScope.solicitudJson.idCanal,
				    				sucursal : $rootScope.solicitudJson.idSucursal,
				    				folio :  $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico.split("-")[3],
				    				capacidadPagoDisponible: capacidadPago,
				    				fechaNacimiento: segFechaNacimiento
				    			},
    				    			productoCredito : {
    				    				montoVenta : $rootScope.solicitudJson.cotizacion.montoTotal,
    				    				productoId : $rootScope.solicitudJson.idProducto,
    				    				periodo : $rootScope.solicitudJson.cotizacion.idPeriodicidad,
    				    				plazo : $rootScope.solicitudJson.cotizacion.plazo
    				    			},
    				    			seguro : {
    				    				esPromocion : false,
    				    				iva : $rootScope.consultaFuncionalidad.esFronteriza?0.8:0.16,
    				    			},
    				    			informacionBase : {
    				    				ws : "",
    				    				usuario : $rootScope.solicitudJson.idEmpleado,
    				    				sucursal : $rootScope.solicitudJson.idSucursal,				    				
    				    			}
    				    		};
        					$rootScope.loggerIpad("Invocar Servicio Seguros Vidamax Unificado", req);
        					
        					solicitudService.segurovidamaxUnificado( req ).then(
            						function(data){
            							$rootScope.waitLoaderStatus = LOADER_HIDE;
            							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
            								if(!data.data.respuesta ||  JSON.parse(data.data.respuesta).tipoOfertaRespuesta != 1){
            									$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
        										$scope.guardaditoHandler();
											}else{
            								
            								var jsonResponse = JSON.parse(data.data.respuesta);
											var listaSeguros = {
													listaBeneficios : jsonResponse.seguros.listaBeneficios,
													listaPlanes : jsonResponse.seguros.lista,
													tasaSeguro : jsonResponse.seguros.tasaSeguro
											};
											
            								if(listaSeguros){
            									$rootScope.seguros = listaSeguros;	
            												
            									if($rootScope.seguros.listaPlanes){
            										$scope.llamarDialogoSeg();
            									}else{
            										$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
            										$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax unificadp", "Error Lista Planes: "+$rootScope.seguros.listaPlanes);
            										$scope.guardaditoHandler();
            									}	
            								}else{
            									$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
            									$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax Unificado", "Error Lista Seguros: "+ listaSeguros);
            									$scope.guardaditoHandler();
            								}
            							}
            							}else{
            								$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
            								$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax Unificado", "Error Código Seguros: "+data.data.codigo);
            								$scope.guardaditoHandler();
            							}
            										
            						}, function(error){
            							$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
            							$rootScope.waitLoaderStatus = LOADER_HIDE;
            							$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax Unificado", "Error Servicio Seguros: "+error);
            							$scope.guardaditoHandler();	
            						}
            				);
        					
        				}else{
        				var req = {
        						cu: $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico,
        					    aplicacion: 1,
        					    capacidadPago: capacidadPago,
        					    fechaNacimiento: $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento,
        					    iva: 16,
        					    plazo: $rootScope.solicitudJson.cotizacion.plazo,
        					    subArea: 1	    			
        				};
        					    	
        				$rootScope.loggerIpad("Invocar Servicio Seguros Vidamax", req);
        					    	
        				tarjetaService.seguroVidamax( req ).then(
        						function(data){
        							$rootScope.waitLoaderStatus = LOADER_HIDE;
        							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
        								if(data.data.respuesta.listaSeguros){
        									$rootScope.seguros = data.data.respuesta.listaSeguros[0];	
        												
        									if($rootScope.seguros.listaPlanes){
        										$scope.llamarDialogoSeg();
        									}else{
        										$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
        										$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax", "Error Lista Planes: "+$rootScope.seguros.listaPlanes);
        										$scope.guardaditoHandler();
        									}	
        								}else{
        									$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
        									$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax", "Error Lista Seguros: "+data.data.respuesta.listaSeguros);
        									$scope.guardaditoHandler();
        								}
        							}else{
        								$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
        								$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax", "Error Código Seguros: "+data.data.codigo);
        								$scope.guardaditoHandler();
        							}
        										
        						}, function(error){
        							$rootScope.message( "Nueva Originación Centralizada", ["Por el momento no podemos consultar seguros."], "Aceptar");
        							$rootScope.waitLoaderStatus = LOADER_HIDE;
        							$rootScope.loggerIpad("Respuesta Servicio Seguros Vidamax", "Error Servicio Seguros: "+error);
        							$scope.guardaditoHandler();	
        						}
        				);
        				}
        			}else{
        				if ($rootScope.solicitudJson.banderaSeguro == 1){
        					var index2 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
        						return d["idContrato"];
        				    			
        					}).indexOf (FIRMA_SEGURO_CLIENTE.id);
            				var index3 =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
        						return d["idContrato"];
        				    			
        					}).indexOf (FIRMA_SEGURO_CARTA.id);
            				if($rootScope.solicitudJson.contratos.contrato[index2].statusFirma == 1 &&  $rootScope.solicitudJson.contratos.contrato[index3].statusFirma == 1){
            					$scope.guardaditoHandler();
            				} else{
            					if ($rootScope.solicitudJson.contratos.contrato[index2].statusFirma != 1){
            						$scope.firmarSeguros(FIRMA_SEGURO_CLIENTE.id);
            					}else if ($rootScope.solicitudJson.contratos.contrato[index3].statusFirma != 1){
            						$scope.firmarSeguros(FIRMA_SEGURO_CARTA.id);
            					}
            				}
        				}else{
        					$scope.guardaditoHandler();
        				}
        			}
            	}else{	
            		$scope.guardaditoHandler();	
            	}
        	}else {
        		$scope.guardaditoHandler();
        	}
    	}
    };
    
    //LLAMAR DIALOGO DE  SEGUROS
    $scope.llamarDialogoSeg = function(){
    	modalService.seguro("bgazul")
		.then(
				function(exito){
					generalService.forceCloseModal();
					$scope.validaHuellaSeguro();
					
				},function(error){
					generalService.forceCloseModal();
					$scope.menuList= [];
					$scope.showPage= false;
					$scope.init();
					$scope.guardaditoHandler();
				});
    }
    
    //VALIDA HUELLA SEGURO
    $scope.validaHuellaSeguro = function(){
    	$rootScope.loggerIpad("verificarHuellaSeg", "validaHuellaSeguro");
		if($rootScope.validarTienda && TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) == -1){
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$rootScope.verificarHuella('surtimiento','responseVerificarHuellaIpadSeg',	[ $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico ]);
		}else
			$scope.responseVerificarHuellaIpadSeg( {codigo:0, matches:["OK"]} );
		
	};
    //FIN VALIDA HUELLA SEGURO
	
	/* INICIO RESPONSE VERIFICAR HUELLA IPAD FUNCTION */
	$scope.responseVerificarHuellaIpadSeg = function( response ){
		$rootScope.loggerIpad("responseVerificarHuellaIpadSeg", null, response);
		if(response.codigo == RESPONSE_CODIGO_EXITO_IPAD){
//			$scope.firmarSeguros(FIRMA_SEGURO_CLIENTE.id);
			//$scope.firmarSeguros(FIRMA_SEGURO_CARTA.id);
			$scope.guardaSeccionSeguro();
		}else{				
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			$scope.llamarDialogoSeg();
		}									
			
	};
	/* END RESPONSE VERIFICAR HUELLA IPAD FUNCTION */
    
    /*INICIO Firmar seguros*/
    $scope.firmarSeguros =  function (value){
    	$rootScope.isSeguroCliente = undefined;
		$rootScope.isSeguroCarta = undefined;
		switch (value){
			case FIRMA_SEGURO_CLIENTE.id:  
            	$scope.tituloAviso = {texto: "Certificado Seguro Vidamax"};
            	$scope.tituloFirma= "Acepto Seguro VidaMax";
				$scope.urlDoc = "Certificado Vidamax.html";
				$rootScope.isSeguroCliente = true;
				$rootScope.title = "Firma Seguro Vidamax";
				$scope.negacionCheck ={texto:"No acepto contrato de Seguro VidaMax", visible: true, textoMensaje:"l Seguro VidaMax.", botonAceptar: "Aceptar Seguro" };
                 break;
            case FIRMA_SEGURO_CARTA.id: 
            	$scope.tituloFirma="Carta Instrucción";
            	$scope.tituloAviso = {texto: "Carta Instrucción"};
            	$scope.urlDoc = "Carta de 14 semanas de atraso Vidamax.html";
				$rootScope.isSeguroCarta = true;
				$rootScope.title = "Firma Seguro Vidamax";
				$scope.negacionCheck = {texto:"No acepto Carta Instrucción", visible: true, textoMensaje:"l Atraso Vidamax.", botonAceptar: "Aceptar"} 
                break;
		}
		
		$scope._btnNoAceptar = generalService.getDataInput("CONTRATOS","BOTON NO ACEPTAR", $scope.origen);
		$scope._btnAceptar = generalService.getDataInput("CONTRATOS","BOTON ACEPTAR", $scope.origen);
		$scope.txtModalContratos = generalService.getDataInput("CONTRATOS","TEXTO MODAL CONTRATOS", $scope.origen);
		
		var imagenesArray = "<div ng-include=\"'documents/"+$scope.urlDoc+"'\" ></div>";				
		$( "html" ).removeClass( "overflowInitialHTML").addClass( "overflowHiddenHTML");
		
		modalService.pdfViewModal($scope.urlDoc, $scope.tituloAviso.texto, $scope._btnAceptar.texto, "Cerrar", null, $scope._btnAceptar.estilo, null, true, $scope.esContratos, $scope.contratosAceptados, 0, $scope.txtModalContratos,imagenesArray, $scope.muestraAvisos, $scope.negacionCheck )
		.then(
				function(aceptar){
					$scope.guardarContratos(value);
					$scope.addOverflow();
				},function(noaceptar){
					$scope.addOverflow();
				}
			);
		
    };
    /*FIN Firmar seguros*/
    
    /*GUARDAR SECCION DE SEGURO*/
    $scope.guardaSeccionSeguro = function(){
    	var seccionContratos=$rootScope.solicitudJson.contratos.contrato;
    	var solicitudJsonString = generalService.delete$$hashKey($rootScope.solicitudJson);
    	$rootScope.waitLoaderStatus = LOADER_SHOW;
	    solicitudService.saveSolicitud( { solicitudJson: solicitudJsonString, seccion: SECCION_SEGUROS } ).then(
	    		function(data){
	    			$rootScope.waitLoaderStatus = LOADER_HIDE;
	    			
	    			if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
	    				var responseJson = JSON.parse(data.data.respuesta);							
	    				if(responseJson.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
	    					$rootScope.solicitudJson = responseJson.data;	
	    					generalService.setRespaldo($rootScope.solicitudJson);
	    					$scope.firmarSeguros(FIRMA_SEGURO_CLIENTE.id);

	    				}else if(responseJson.codigo==PRESTA_PRENDA_SUCURSAL_GESTORA){/*Modificacion*/
							var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
							$rootScope.message("Aviso ", [responseJson.descripcion],"Aceptar","/simulador",null,null,buildJsonDefault);
						}else{
	    					if(responseJson.codigo == ERROR_SOL_RECHAZADA){
	    						var idSeguimiento = $rootScope.solicitudJson.idSeguimiento;
								var marca = $rootScope.solicitudJson.marca;
								var respuestaCallCenter = $rootScope.solicitudJson.respuestaCallCenter;
								var buildJsonDefault=function(){generalService.buildSolicitudJson($rootScope, null);};
	    						$rootScope.message(	"AVISO", [generalService.resCallCenter(idSeguimiento,marca,respuestaCallCenter)],
	    								"Aceptar", "/simulador",null,null,buildJsonDefault);
	    					}else if(responseJson.codigo == LCR_CLIENTE_CUENTA_CON_LCR){
								generalService.setDataBridge( { tipoFicha : FICHA.tipoFicha.bloqueada });
								generalService.locationPath("/ficha");
							}else{									
	    						$rootScope.message("Seguro VidaMax",["Error al guardar sección 11. Código " +
									    "de error [" + responseJson.codigo + "] no identificado."], "Aceptar", null, null, null);
							}
	    				}
	    			}else{		    				
	    				$rootScope.message("Seguro VidaMax",[generalService.displayMessage(data.data.descripcion)], "Aceptar", null, null, null);
	    			}
	    			
	    		}, function(error){
	    			$rootScope.waitLoaderStatus = LOADER_HIDE;
	    		}
	    );	
    }
    /*TERMINA GUARDAR SECCION DE SEGURO*/
    
    /*INICIO guarda contratos*/
    $scope.guardarContratos = function (value){
    	var desc;
    	
    	var agregaAcuse =  $rootScope.solicitudJson.contratos.contrato.map(function(d){
			return d["idContrato"];
		}).indexOf (value);
    	
    	if (value==FIRMA_SEGURO_CLIENTE.id){
    		desc=FIRMA_SEGURO_CLIENTE.descripcion;
    	} else{
    		desc=FIRMA_SEGURO_CARTA.descripcion;
    	}
    	var jsonAcuse=null;
    	if (agregaAcuse == -1){
    		jsonAcuse = {
					idContrato: value,
					idPersona: $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
					statusFirma: 2,
					descripcion: desc,
					idTipoPersona: 1
			};
    		$rootScope.solicitudJson.contratos.contrato.push(jsonAcuse);
    	}else{
    		$rootScope.solicitudJson.contratos.contrato[agregaAcuse].statusFirma=2;
    	}
		$rootScope.waitLoaderStatus = LOADER_SHOW;
		solicitudService.saveSolicitud( { solicitudJson: JSON.stringify($rootScope.solicitudJson), seccion: SECCION_CONTRATOS } ).then(
				function(data){
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
						var responseJson = JSON.parse(data.data.respuesta);
						if(responseJson.codigo == 2){
							$rootScope.solicitudJson.contratos = responseJson.data.contratos;
							$scope.archivafirmasAcuse(value);
						}
					}
				}, function(error){
					$scope.firmarAcuse = false;
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("Error",["Ocurrio un error al guardar la sección de contratos. Favor de volver a intentar"], "Aceptar", null, "bgRosa", "btnRosaD");
				}
		);
    };
    /*FIN guarda contratos*/
    
    /*INICIO GUARDA FIRMA*/
    $scope.archivafirmasAcuse = function(value){
    	$rootScope.waitLoaderStatus = LOADER_SHOW;
    	var descripcion;
		var etiqueta;
		
		
		if (value==FIRMA_SEGURO_CLIENTE.id){
			descripcion=FIRMA_SEGURO_CLIENTE.descripcion;
			etiqueta=FIRMA_SEGURO_CLIENTE.etiqueta;
			$scope.imgFirma = $rootScope.imgSeguroCliente;
		} else {
			descripcion=FIRMA_SEGURO_CARTA.descripcion;
			etiqueta=FIRMA_SEGURO_CARTA.etiqueta;
			$scope.imgFirma = $rootScope.imgSeguroCarta;
		}
		
		if (!$scope.imgFirma){
			 console.log("No hay firma");
		} else {
			$scope.b64Firma = $scope.imgFirma.replace("data:image/png;base64,","").trim();
			if($rootScope.validarTienda){
				var biometrico = {
						ruta: null,
						idSolicitud: $rootScope.solicitudJson.idSolicitud,
						cadena:$scope.b64Firma,
						tipoCadena: descripcion,
						porcentaje: 100
				}
				$scope.enviaAcuseFirmas(biometrico, value);
			}else{
				if(value==FIRMA_SEGURO_CARTA.id){
					$scope.guardaditoHandler();
				}else{
					$scope.firmarSeguros(FIRMA_SEGURO_CARTA.id);
				}
			}
		}	
    };
    /*FIN GUARDA FIRMA*/
    
    /*INICIO ACUSE FIRMAS*/
    $scope.enviaAcuseFirmas = function (biometrico, value){
    	$rootScope.waitLoaderStatus = LOADER_SHOW;
		clienteUnicoService.setBiometrico( biometrico ).then(
			function(data){
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				if(data.data.codigo == RESPONSE_CODIGO_EXITO){
					var j = JSON.parse(data.data.respuesta);
					if(j.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
						if(value==FIRMA_SEGURO_CARTA.id){
							$scope.guardaditoHandler();
						}else{
							$scope.firmarSeguros(FIRMA_SEGURO_CARTA.id);
						}
					}else if(j.codigo == RESPONSE_CODIGO_ERROR_ID){
						$scope.firmarAcuse = false;
						$scope.activar = false;
						$rootScope.message("Error",[j.descripcion], "Aceptar", null, "bgCafeZ","cafeZ",null,null,null);
					}else{
						$scope.firmarAcuse = false;
						$scope.activar = false;
						$rootScope.message("Error",["Error al enviar el seguro. Por favor, espere unos minutos para reintentar"], "Aceptar", null, "bgCafeZ","cafeZ",null,null,null);
					}
				}else{
					$scope.firmarAcuse = false;
					$scope.activar = false;
					$rootScope.message("Error",["Error en la respuesta del servicio para guardar el seguro del cliente. Por favor, reintente nuevamente."], "Aceptar", null, "bgCafeZ","cafeZ");
				}
			},function(error){
				$scope.firmarAcuse = false;
				$scope.activar = false;
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("Error",["Servicio no disponible para enviar el contrato, favor de comunicarse con soporte."], "Aceptar", "/simulador", "bgCafeZ","cafeZ");
			});
    };
    /*INICIO ACUSE FIRMAS*/

	
    $scope.addOverflow=function(){
		$( "html" ).removeClass( "overflowHiddenHTML");
		$( "body" ).addClass( "overflowInitialHTML");
	}
    
	});
});