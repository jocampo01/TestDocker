'use strict';

define([ "app" ], function(app) {

	app.controller('visitaAsesorController', function($timeout, $scope, $rootScope, modalService, generalService, solicitudService, messageData, bazDigitalService, callCenterService,
		documentosService) {

		$scope.inicializaCheckBox = false;
		$scope.fechaNac = $rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento;
		$scope.creditoInmediatoHabilitado = $rootScope.consultaFuncionalidad.creditoInmediatoHabilitado;
		$scope.paramAvisoLlamada = $rootScope.consultaFuncionalidad.imprimirAvisoVisita;
		$scope.pageClass = generalService.calculaVistas($rootScope.paginaActual, $rootScope.paginaAnterior, $rootScope.recuperaSolicitud);
		var dd = "";
		$scope.bazDigital = false;
		if ($rootScope.solicitudJson.idPlataforma == 6) {
			$scope.bazDigital = true;
			$scope.pathInicial = "/codigoSolicitud";
			$scope.pathOpcional = "/datosHogar";
		} else {
			$scope.pathInicial = "/simulador";
			$scope.pathOpcional = "/ochoPasos";
		}
		$scope.cambioFecha = false;
		$scope.cambioHorario = false;
		$scope.cambioCita = false;
		$scope.textoDia = "";
		$scope.numDia = "";
		$scope.textoMes = "";
		$scope.textoPeriodo = "";
		$scope.periodo = "";
		$scope.fotoAsesor = "images/loading.gif";
		var uriB64 = "data:image/png;base64,";
		$scope.icoTelefonoB64 = "iVBORw0KGgoAAAANSUhEUgAAAOEAAADeCAYAAADLn2cCAAAACXBIWXMAAC4jAAAuIwF4pT92AAAa1klEQVR42u2df0wbZ5rHvy4oZq9iYI+42RYfteBgCzq0oDaBnrLBVVwfW4qSEHRKk6sg1amnWykKliJdaKWmidQkK0WCKrruKtKloGzb7ImSRCnRQuBqsukWaHO4orIrLCKXM+0GFwrDXRpHRbo/PKaUeGY89vye5ytVRZnBP4b3M9/ned73fQYgkUgkEolEIpFIJBKJRCKRSCQSiUQikUgkEomkqmx0CfSl8q5Tbu7HGgCF3M8NPKe71/3sT3F8CcBn634OAEDY1+mnK00QWh00FwdZDYBfcLC5NfgofgARAF8mfw77OiP0FyIIzQZcErAaztHWO5welXTMUQ7MQNjXuUR/SYLQaODt5oBLwmd0BTggr1AoSxDqObxMgrfbAl/5MoArAC6TSxKEegCvzSRul01e2UtAEoRq5ne7AexS2vEYex4qHY8AAIqZAhQzBQ+cU+nYAsZuR5Rdxhy7/MDxuXX/HorNg43fU8Uhw77OHhotBKESrneMA0+2okoxUwAnU4BtzpI16PiAk0tJMEOxeUTZZXwRu6MEoEsAegC8SdVWgjBb+Nq5cNMth7Ntc5ag0vEI6pwleIJzMb2IjcfxRewOxqOzmIjOygmmH8BxKugQhJnAdwyAK1vo6pwla/AZTaHYPCaisxiPzmJ4Zjrbl4twMFKoShAK5nsdAA5nGnIWMwXwlFWgzlkCT1m56a7R8EwYwzPTGI/OpsxBCUaCMBsAX88UviR4LVXVhnS7bFyyPziFS8GpTMNWgpEgzC7sbKmqRktVNbY5Syx/ExueCaM/OJVpyBoB4Av7Oi8ThNaCzw2gCxLn94qZArTXbsWeqmpdFVX0IjYex6XgFHomP8kkXPVzMAYIQnPD5+LgkzTHV+cswaH67eR6Et2xd/ITjEdnpf5qNxemLhGE5gOwgws90877Wqqqcah+u6LzdmbXRHQWPZOfSg1VlzhX7CEIzQFfDYC3pYSeBJ/8mmOXcXbsJvqDU1JD1INmn/C3mRzA1zn3I/h0olBsHidHh6WEqUtceNpNEBov97uUrvtRzqdNmPrG6AhCsTtSXHGPGXNFmwkBbEei+CKa+xUzBThUvx0tVdVEhUbqD07h5OhIunONS1x4epkg1Cd8hRx87emc31a7FYfqt9NUgw7ExuM4OTosJV/sDvs6fQShvgBMu/hS6diC094mS61uMVKI+m9DA+nOMQYAPGOG8NRmAgB3cwCKhp+H6rfjUP12Gu06d8WzYzfRO/lJuuHpM0af4LcZHMAOLgQl97O2Kx408pyizcAAvp1O/tdWuxWvNuykUW3+XLEn7Os8SBCqA18hgA/F8j/GnofT3iZTbimymiRUUHuQWGmzRBBqDGClYwveam6hSXcTKRSbx9GhgXTmFQ1XsLEZCMAaJCbgXULntVRV45UGD009mDQ8PTo0kM46VEOBaDMQgB9CpAL6aoMHbbVP0Wg1ud4YHUmnemoYEG1mAJCx5+GVhp208sVieeLRoQGx0yJILHULEIQKA3ihdT9NP1hQE9FZ/Ppqv1jBZglArZ53YtiMDGAxU4C3mvcSgBZWKDaPF/veFQNR16GpTacAugBMCgFY6diCC637qQBDMjyINh0CKDoNQQCSNmqOXcavr/aLTWHoEsSHCECSGVTMFHC1gS1CpyUX+oMg5NfbBCApUzF2Ozc+8oRO280tedSNcnTkgoJ7AQlAUjqy5+bil65SXJsOIb76Pa8jFjV6lhcHR8YoJ/wBwHahMIGx5+HKgYO0DI2UttIs1uzRwy59mw4ArEGiEsoLIM0DkjIFcdc754VO0cV+xByNASzkAOQN4v9jzz+i5tHHaESRJMvx8MMoZgowPBPmOyUPQH1Ro+cPi4Mj97T6nFoXZi5BYC7wtLeJOqCRslJLVTVebfAInVKDNDaGm9IJuZ6g7XzH22q34l+21tMoImWtmkcfW3s6Md8pRY2eLxcHRzQJS20aAehGYj4wpeqcJbjQup9GD0k2sfE4Xux7V2gyX7P88CENACyEQCW0mCnAvzfvpVFDklWM3Y63mluE5hAFx6WpwtGiRs9vIfAM+N+3HoBTg6mI6AqL7v8ex28/u4XoCouqzQ7Yc3Jp9JoKxDyU/nURBqZDfKf8rKjRY1scHPGbNhzl2hNe4juu1abcvukQTvz5Btj78bV/qypy4GJzC5hNtDjAbEpjU3CtmmHpQyoCKGj3dc4SzQA84r/+IwABILgQwxH/dRqxJtSrDTvF1piqGpaqmRPyPhuQsedpkgcmAeTTUOQ2zk8FaNSaUCL5YQ1XvTdPTshVQ3/Hd7zruV2qr4gRAzCp0eiX8LpK4firh2nkmiw/tOfm4k9f3uY7xV3U6OldHBxRfNuTWk7IOxnqKatQvTfoUOS2pFDziH/4gXCVZHy11T6FOuHFIKqEpYo7Ideqvp3vbnShdT/suepVIYMLMbw8NID46mravxP77i5id+/C6yqjkWsy1TlLcCn4Od+OC1dRo+ezxcGRLwwLIVeMuQSetaHHd/6DqutC2ftx7PugH7Hv7mYA7zdw5jOoKnLQyDVZWBpf/R4T/E8OrufCUsXWliodjvIWY+qcJaq3KDziv47oCpvx75/4842sfp+kT4k8It0FoMOQOSHXrIn3w78ivKhWdp2fCmAocjtrJ31ZvNclyYD6jbdJ6PBhLqoznBMe40+It6paDQ0uxHDi4xu6ey2SfrTNWQJPWQXf4UKh8axLCDkXbOeLwdV+UOcR/7DuXJWkP4k8Qq+DG9eGcUIBF3xK1T4x3bfGEVyIKZJf0rSFuVTMFIgZxDFDQCjkgsVMAdpqt6p2UaMrLLpvjSvy2pQfmlNttVuFVtK0K+GGSjgh793iUP12VV3w/OfKLjkb+yqqGOQkbcTY7WJrmA/rGkIxF1R7SmLsqzlVwt2xr+do9FrLDQt1C6GYC6otJXJByg8t74aFkHneUDYIubvDbr24IAA48xnVck/a9mQpN2zTqxO2g2d1jFYP71RzdQttezKfG+7hH7curmG17iA8nPrL5KlaEV3LBzXI0058fEO1EJikvNqFCzRtuoKQ2y/oSnXMU1auyfMjgt9oAwNtezKPRNIot1zTFXI5Ie9dQYuCDADNQAguxHDiz7SszSwSSaUO6wJCriCTMj6uc5Zo9hAXLacN+qZD6OPv6EUykLYJj+F2XUAInoooAKHE1vSibU9myg15axqFXAdBzSHcleofGXueZlVRAJoDQMvazCMRM9mlKYRCc4Nq943RG4Rr+SFtezK8GLtdaJuT5k7I+wEEPrSlRNuezCEBU8k6JM0WwpRWXMwUaO6EehItazMDhBWKhaQZQygcipILUn5IIakaTujmO1BHD/Z8QLTtyfQhqVsLCHmrohSKplb3rXGatqCQVHknJACFRZP4xg5JBaI8dZ2QWzPnSnVML8+YV2sbE4nckFNNppt9M3VC3eeDeoWQnndobImYjFtNCBtS/WMxU6DZWlFDhDOb7Gj9eSVdCAOr0vGI0GbfBs2dUE9V0aqizbr649GTfy3hhjWqQMjFvbrOB/UW9rVWVOJicws9TMYkkrs4k4kT1ug9HwSA+securgRnHE/izPuZ8kBTRaSCpiUZBAzeTBgyjdh7Hm6ygeZTZs0fX9nPoNz3iZyP2uFo0mT8ivthL+QenfQKgfTSl5XKa7tfYEANLUbbuE79Lhm4eg2HS5V0yIkfe3pHTjnfZ7CT+uGpDVqQOiSeGfQ0A3Vq5A68xlc2/sCXqquoRFqbSd0KwqhUNKpx/lBtcJBCj/JCTdwImnljNTCTGEmH0qzcPTRYkVf/6XqGtQ/6oTXVUqj0mISMR1JxRmpENYYxQWTIaIzn1Fk54LXVYrXnt5Bo5EgTDtlkysnTPnOTh0vVVPKpbyuMhqJlBdqAmFKJ3xCh0WZH0JSp6HgJhlHAp3lH1cSQqkfRhdOKPd0AbPJTlMQJCHzUdQJ3akhzNP1xap/TN4CTdVmqoKS5DMfWZxQj5XR9WqtqKIRQ5JdAsUZt+oQ6l1yh6RaPfGJpC/JVZBMG8LyrlO8S0HydR6OJkGUS9RDlCSnpDihoSbqN0ru5WRaPvWJZF0IDa2qIoesfWfGvorS6LG4hKbmpOwrfMhKF63jyTrZXoueL0HSVXXUKJKzQBNciFEjXxJBKPnOtckua25Ibe1JBGEGkhPCochtqpSSCMJM3LC1Qp7en+z9OM5PBWgUkQhCqZKzQHN+KkC5IYkglCpnPiNbWMrej1NuSCIIM3VDuSqlfdMhmrwnEYSZ5IZyFmnokdjW0xy7TBBmq5eqa2RbRRNdYSksJQjXFPZ1+pWAMMJ3YCI6a1g3lLNPzPmpAK2kISnnhGFfZ8SMF8DrKpW1STCFpSQKRzPQmQaPbK/F3o9j39V+uqgWUCg2z3doSUkIlyR+GEPImc/IOncYXIjhiP86jVKTi43f4zsUUBLCgMQPYxh1PFknawftvukQ+qZDNFJNDaE8aYcs4ahcpVrNw1K3R9bXO+K/juACtcIwq76I3dHECUfNDGFVkUPWsBQA9l3tJxCt54TLSkIoNUE1ZFgqZ7WUvR/HEf8wVUxNqJBGTug3a074o7C0wSNvd7aFGPZd7ScQTSSR6E/96ihg3An7VHLmMzjjflbW10yCSDI/hFJWy0iGMOzr5LXZqEnywqS8rlLZO7TR1IV5NM5vOktSXyuTnDBg9rwwqdee3iH7I7f7pkMEoinywXlZ8sFMIYyk+keBcq2hdc7bJGurRKOBGFyIofvWOLpvjaNvOkR5rXg4KhnC3Aze/zMAuyXYs6HFbLLjnLdJ9sJKciJf7txTTiXhS5UvK/0UZD2LjceFKqOfqeGE/gws2tCqKnIoAoueHXEocjvl1qzoCot9V9/HiY9vWNYVRaI+VcJR3jeZMKkbAolCjVVATMxtCn+m81MByy5EEIr6hIqXskEY9nUugbc4c8fUF7+1olK2Tm16BvHloYG0XC64EMNz779nuc3MAmbjz+T1Ml0xE5B6hzCLzrifVQzEl4c+0DzEOz8VkPycje5b43ju/fcs44oC43xUTQh515DOmWy+kA9EuacuknmYlitrkpXQTH/3ufffM30fVpGUS1Un5H2z4ZmwJe6G57xNsm592jiYtXAVOda4nvj4BvZ90G/aXqzXBca31JUyWUHItbqwbEgKJKYuLja3KAJiogLZr+p+xBMf35AN/LGvoqZ1RbnzwWyckPdNh2emZdvsaGUQkxVKNXrWjH09Jzsw7P34miuaZSpjjl0WKj5e0QLC0QzjZgJRgvqmQ4qGp+lMR2Tritvf7TFFF7pxBfJBAMjJ9BcXB0e+KGr0dAB44IH19txceMoqLAOiPScXzX9bgdH/mUXsu7uKgPJO6HOw9+Oo3fIz2HNyZXvtQyN/xOT8XxS9PvHVVVydmUZwIYaGv3lc1s+vps6OfYTb3y6kOhQJ+zo7tXBCgZA0DKtJaUcEEtMHz73/nmy54tjXc6o61FDktmFdkY3HMTwzzXf4cjavnS2EV1J/4HuWBtHrKlXsPaIrLI74r2P7ez1Zwyh1PlAuV3956APDLXsTAFAwNVM0HAWAokZPBMBRvhCk6eeVlgPRnpOL5rIKRFdYBBe+UXQwD0Vur+1scOYzkp6hPvb1HLpvjWsGwuT8X3B1JoyqzQ7Zd6kooaND1/DN3f9LdWgp7Os8qBmEi4Mj94oaPTUAnth47Pa3C2ir3Qp7bi6sKK+rTHEQkzCOfT2H858nWvDHvrsL2GwJZ94AZXAhhqszYbx680P8NvCp5k7E3o+v3UTkznXl1By7jDMf8dZdfrc4ODKYzevL8a17kWJrEwBcCk6hrfYpWFXJlTVqrQsNLsQSVVSDreVMLJWbwxm3R9GcOlP1TH4qNv6zUtbd1sK+zsvg2dLfM/kJrK7Wikqc8z4va+MoM0rPi8EvBaf4DkUy2TUhO4RJ3vhs3EpzhvyhaSkuNrcYIvfRWnpbDN4fnBLqJvimHO8hF4S9Ql+ClNgYfG3vC7oMt/TqinpY9nZJePxe1g2EnCX7+SC0ws6KdMRssuPa3hdk7+JmVmm97C0UmxdaJXNZrscFyvlotN4ME1vL6bWnd+CM+1nKE9NQcjG4FiD2Ctc03pTrfWSDMOzr7AFPJ7ZLwSnLLOpOV60VlYqvsDGLkgsU1NQcuyyUSkUy3baktBPyuiEbvyd2V7FsnnixuYXC0zSk9lK3s2M3hQ4fl/O95IawGzzTFb2Tn5Ib8uSJrz29g6YxRKREJ4MMXXCJi/r0CSHXBKqH3FC6vK5S3Nzfrui6UyPrpb9TL1oQccE35X4/JZ5Z/yZ/oktuKOaK57zPkyumyJ/VujmJuSAX7cmqHLlfcHFwZKmo0eMC8MCtK776PeKrq9hBd3tBlRX+FAeqqhFfXVV8r58R8uaznkbV1pWeHB0RamL9m7Cv849GcELBxLV38hOaN5SQK15s3qtqPqQ3AC82t6gWFUxEZ1V3QUWccJ0b2gC4U1s+a8ltTpnImc+gtaISznwGwYVvLNN6Xm0AAeDo0ICQQSjigko6ISBQKR2emaY1pRnkRdf2voCOJ+tMny9qAWB/cEpodUxEKRdUzAk5N7xX1Oj5CZ8bjkdn0V67leiSIHtOLuofc+JAVTXsObkILnyD+Oqq6W42vc/tUnVvIRuP458v/yfiq9/zneIL+zrHDAchB6K/qNHTDqBw47EVrkpa5ywhughGAEDHk3V47e93qP6+Zz4aFYrMAmFf578q+f45Sn/BokbPlwD28SXCnrIKOB5+mMjKEkbHTx7GzPK3hswZmU12nN35Kxyoqlb9vSeiszj2X4Ib419YHByJKPkZbGp80fKuUx/yhaWVji24cuAgESWTEn1ngobpaJZ49qM2O+rZeBy73jkvVIzpybZ/jC6ckHPDUQDtSNGjNNk8h8JSeVRW+FM0l1WsVVRj391VpBeqHHqpugZn3M9qttn5zEej+NOXvDerJQC/Whwcuaf057Cp9YXLu069DuAY3/ErB15CpeMRokgBRVfYtc5setixXv+YEx1P1mn6yO2J6Cz+qe9doVMOyr1GVHMIORAnkWIlTTIsvdC6X1LbPlIGIRjXKnHsqyjGvp5T/OlJznwGHU/WreV+VUWbNW/zkUYY6g/7Op9R6/Oo3WPuIIDJVAdCsTs4O3YTrzbsJFIULoKsf+Jwsi1jslNbdGUlK7dkNtlRtdmB+keL4XWV6nK/pMik/BI3TlWTTe0LIBaWnvY2oUWDKhnpwRA2+r8rAIQ7dSehSxRZNut+IUHv5Kd4Y3RY6BRf2NfZbWoIxcJSxp6HC637KT8kya5QbB673jkvdMrlsK9zj9qf6yGNrsce8CxpY+P3cHRogLY8kWTPA18ULsSoHoZqCiHXpeog/x3rDo4ODdDIIcmmF/veFeofCgB7uE3pqitHq4vCPd/QxReW3v52AWw8TnsPSVnr6NCA0HwgABxXazpCVxByIF4pavTsBvCzVMc/+8tXKGYKUOnYQiOJlJHOjt1Er3DLTb8aq2L0mBOmlR8m72LUxZuUifqDU2L9YiLc+IOlIeTyQ8GJUZGWAyRSSgBF6gpLWuaBenPCZBt93pCAjd/Di33vEoiktBSKzePk6IjYaQfleKKS4XPCDflhoKjRUwigPtXx+Or3uDYdwi9dpbT1iSQIYBqV0INhX+dFvXzmHD1dwMXBkUGhiimBSJIBwJ6wr/O4nj63TY8XU2j/IUCrakhZAai7zasP6fSa7gEQoByRlI6GZ8LpAHhZjwDqFkKuYvVMOiBS1zZrqz84hV9ffV8MQMHCH+WE/PnhvaJGzx8ANIJnMj+++j36g1M0oW9hANNY3hgA8IwepiIMB2G6ICbDEYBaZFhJR4cGxCbiDQGg7iGUAuJEdBZz7DK2OR+HPTeXRqlJlewRmrzxGh1AQKfV0VQq7zpVCOBD8ExfJFXp2IK3mltQzBTQiDWZQrF5HB0aQCh2R+zUHr0WYQwN4ToY30aicxuvGHse3mpuwTYKT02j4Zkwt8/0nqkANEQ4miI8vSI0oQ/8ULChPNEcemN0BCdHh4Xa1Cd1POzr9Bnt+9mM+ocp7zrVDuBtsfPqnCU47W2i8NTc4SegYotCgvDHIO7mQCwUC09Pe5vgKSunkW0Q9U5+irNjN9MJP5eQKMAEjPpdbUb/Y5V3narhQBR9qLmnrAKnvU3U21THmmOXcXRoQOgxZesVQGI7UsTI39lmhj8cVzl9G8BusXMZex5eadhJbRWN7X6AAQswpoZwHYwdALrSOZdyRcPmfktI9AbtMcv3t5ntD8qFp5cAuNI5/1D9drTVbqUQVQOx8ThOjg5LaV8SgI424xKE4uHpMQAd6ZxPIar6SjZgSjP0BBLTD6+b8VrYzPyHLu865eZyxbRcsZgpwKH67QSjgko2XxJ4FsRGRTj385v1mtjM/keX6ooEo27gA4DjALqNsP6TIFTAFQlGTeEzZe5neQjXwfg6gMMQmeDfCGNLVTUVcNLUHLuM/uCU1JwPMGHlkyAUDlG7ILIQPJWSMFJ/mwc1EZ1Ff3Aq02bN3UgUX5asdt1sVh403HRGFwSaSgm5Y3vtVnjKyi0915h0vf7glNSQM6keDr6IVa+hpSHckC8eywRGILEczlNWDk9ZhSXC1Tl2GcMzYfQHp9KdYE8lPwef3+rjjyCUEUYgsam4paoa25wlpgpZQ7F5DM9MY3gmnA14BB9BKAnGtkxyxo0ha52zBNucJahzlhgqbA3F5hGK3cFEdBbDM2GpBRYKOwlC2WB0IVFJbYeEaqoQlJWOLah0PII6ZwmecGzRRfg6xy5jjl3GeHQWodg8JqKzckAHJKqdbyKx2JrgIwizgrEQiR0ah5HGlikpYux5qHQ8sgZkshOA3ICy8Ti+iN0BG48jFLuzBl4oNi8XcBtDzl6rTTUQhOq7425ImPjPFtL14gM0Cdp6javXHDkCoJdcjyDUKnd0qwGkDhUBcJlzvQCNCIJQayBr1gFZY+KvGgBwBYlnOxB4BKGuQ1Y3gAYTuGRgHXh+K65oIQjNA2UN918D9/9CHX7UJQ64Ue7/BB1BaHowk475OPezSyXXjHD/BQAsI1HNjFBBhSAkPQgoUrhmgUjOmQRrI3AAECBnI5FIJBKJRCKRSCQSiUQikUgkEolEIpFIJBKJZHn9P5r9vVXsLrVZAAAAAElFTkSuQmCC";
		var intentos = 0;
		var limite = 3;
		var periodosCatalogo = [];
		var nuevosHorariosJVC = $rootScope.consultaFuncionalidad.nuevosHorariosJVC;
		// Parámetro que activa por fecha específica la disponibilidad del JVC.
		var disponibilidadPorBuenFin = $rootScope.consultaFuncionalidad.disponibilidadCitaPorBuenFin;
		$scope.horaContacto = {};
		
		// Catálogo con nombres para meses y días de la semana.
		var catalogos = {
				meses: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
				dias: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'] 
		};
		
		if(nuevosHorariosJVC){
			periodosCatalogo = [{
				id: 4,
			    descripcion: "09:00 - 14:00"
			  },
			  {
			    id: 5,
			    descripcion: "14:01 - 19:00"
			  }
			];
		}else{
			periodosCatalogo = [{
				id: 1,
			    descripcion: "09:00 - 13:00"
			  },
			  {
			    id: 2,
			    descripcion: "13:01 - 17:00"
			  },
			  {
			    id: 3,
			    descripcion: "17:01 - 19:00"
			  }
			];
		}
		
		$scope.dias = [];
		var periodos = [];
		$scope.meses = [ 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre' ];
		$scope.textoDias = [ 'Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado' ];
		$scope.respaldoAntiguo = null;


		var color;
		var banderaDeIngresos = $rootScope.solicitudJson.banderaIngresos;

		//$scope.horaVerde=periodosCatalogo;
		//$scope.horaContacto=$scope.horaVerde[0];
		//Recuperar DATOS ASESOR 0-Solo Antiguo, 1-Solo Nuevo, 2-Los dos
		$scope.combinar = 2;
		$scope.cambiaDia = function(opc) {
			switch (opc) {
			case 1:
				//					$scope.cambioFecha=true;
				$scope.cambioCita = true;
				$scope.periodo = "";
				break;
			case 2:
				//					$scope.cambioHorario=true;
				$scope.cambioCita = false;
				break;
			}
		//			if($scope.cambioFecha && $scope.cambioHorario)
		//				$scope.cambioCita=false;
		};

		//Validación para cargar la vista en base al tipo de ingreso y la validación de la nueva variable del color.
		switch (banderaDeIngresos) {
		case 0:
			color = $rootScope.solicitudJson.idColorNC;
			break;
		case 1:
			color = $rootScope.solicitudJson.idColor;
			break;
		default:
			$rootScope.message("ERROR", [ "Error al intentar generar la visita" ], "Aceptar", $scope.pathInicial);
			break;

		}

		//Validación para el combo de clientes verdes (temporal). Valida la hora media hora antes de los rangos establecidos para realizar la llamada
		$scope.comboCTEVerdes = function() {
			var d = new Date();
			var horaActual = d.getHours() + ":" + d.getMinutes();
			var arrayPeriodoCita = [];

			for (var c = 0; c < periodosCatalogo.length; c++) {
				if (horaActual > '16:30') {
					arrayPeriodoCita.push({
						id : periodosCatalogo[c + 2].id,
						descripcion : periodosCatalogo[c + 2].descripcion
					});
					break;
				} else if (horaActual > '12:30') {
					if (c != 0) {
						arrayPeriodoCita.push({
							id : periodosCatalogo[c].id,
							descripcion : periodosCatalogo[c].descripcion
						});
					}
				} else {
					arrayPeriodoCita.push({
						id : periodosCatalogo[c].id,
						descripcion : periodosCatalogo[c].descripcion
					});
				}
			}
			$scope.horaVerde = arrayPeriodoCita;
			$scope.horaContacto = $scope.horaVerde[0];
		}

		$scope.cargaVista = function() {

			if (configuracion.origen.tienda)
				$scope.origen = "TIENDA";
			else
				$scope.origen = "WEB";
			$scope.titulo = generalService.getDataInput("VISITA ASESOR", "TITULO", $scope.origen);
			$scope.etiqueta1 = generalService.getDataInput("VISITA ASESOR", "ETIQUETA1", $scope.origen);
			$scope.etiqueta2 = generalService.getDataInput("VISITA ASESOR", "ETIQUETA2", $scope.origen);
			$scope.listaDocumentos = [];
			var i = 0;
			angular.forEach($rootScope.solicitudJson.documentos.documento, function(doc, key) {
				if (doc.status != 3 && doc.status != 5) {
					$scope.listaDocumentos[i] = doc.documentoDes;
					i++;
				}
			});
			$scope.mensaje = "No es necesario que el cliente esté presente durante la visita, ésta puede ser atendida por una persona que sea mayor de edad y que tenga disponible la información del cliente.";
			$scope.etiqueta3 = generalService.getDataInput("VISITA ASESOR", "ETIQUETA3", $scope.origen);
			$scope.etiqueta4 = generalService.getDataInput("VISITA ASESOR", "ETIQUETA4", $scope.origen);
			$scope.etiqueta5 = generalService.getDataInput("VISITA ASESOR", "ETIQUETA5", $scope.origen);
			$scope.etiqueta6 = generalService.getDataInput("VISITA ASESOR", "ETIQUETA6", $scope.origen);
			$scope.etiqueta7 = generalService.getDataInput("VISITA ASESOR", "ETIQUETA7", $scope.origen);
			$scope.diaCita = generalService.getDataInput("VISITA ASESOR", "DIA", $scope.origen);
			$scope.horario = generalService.getDataInput("VISITA ASESOR", "HORARIO", $scope.origen);
			$scope.btnAceptar = generalService.getDataInput("VISITA ASESOR", "BOTON ACEPTAR", $scope.origen);
			$scope.tipoColor();
			$scope.btnAceptar.texto = /*"     " + */ $scope.btnAceptar.texto;
			$scope.fechaVisita = $scope.numDia + " de " + $scope.textoMes + " de " /*+ $scope.terminoPeriodo + " "*/ + $scope.textoPeriodo.toLowerCase();

		};
		$scope.tipoColor = function() {
			$scope.mensajeVisible = false;
			$scope.validarHora = false;
			$scope.preAprobado = false;
			if ($rootScope.sucursalSession != undefined) {
// I-MODIFICACION TDC (	FORZAR LLAMADA PARA PREAPROBADOS )						
				if (($rootScope.productosTarjetas( $rootScope.solicitudJson.idProducto ) &&  $rootScope.promocionCampanas($rootScope.solicitudJson.tarjetasCredito.tarjetaOro.campana)) || ($rootScope.productosSIPA( $rootScope.solicitudJson.idProducto) && $rootScope.promocionCampanas($rootScope.solicitudJson.campana))){
					$scope.validaSucursalClteAzul = false;
					$scope.creditoInmediatoHabilitado = true;
					$scope.creditoInmediatoInhabilitado = 0;
					$scope.preAprobado = true;
				}else
// F-MODIFICACION TDC (	FORZAR LLAMADA PARA PREAPROBADOS )	
					$scope.validaSucursalClteAzul = !$rootScope.consultaFuncionalidad.clientesVerdesAutorizados;
			}

			
			var visita = generalService.whichOneVisit(0);
			
			// Es llamada.		
				if(((!$rootScope.productosTarjetas( $rootScope.solicitudJson.idProducto ) && visita == "/visitaAsesor") || ($rootScope.validaPreAprobados() && color == COLORES_EVALUACION_CTE.VERDE))
						|| ( ($rootScope.solicitudJson.campana == "winback") && $rootScope.consultaFuncionalidad.creditoInmediatoWinbackHabilitado && !verdePermiteVisita) ) { // Es llamada.		
				$scope.vTelefonica = true;
				$scope.titulo.estilo="mainHeader naranjaVT"
				$scope.titulo.imagen = "images/icon-form/telefono.png";
				$scope.titulo.texto = "Validación Telefónica";
				$scope.etiqueta2.texto = "Uno de nuestros asesores le realizará una llamada telefónica para validar su información y garantizar que se haya registrado correctamente.";
				$scope.etiquetaAux = "Por lo que le recomendamos tener a la mano los siguientes documentos:";
				$scope.etiqueta3 = [ {
					visible : "false"
				} ];
				$scope.etiqueta4.texto = "Para brindar un mejor servicio, solicitale a tu cliente un horario en el cual nuestro asesor podría contactarlo.";
				$scope.etiqueta5 = [ {
					visible : "false"
				} ];
				$scope.etiqueta6 = [ {
					visible : "false"
				} ];
				$scope.etiqueta7 = [ {
					visible : "false"
				} ];
				$scope.diaCita = [ {
					visible : "false"
				} ];
				$scope.horario = [ {
					visible : "false"
				} ];
				$scope.estilo = generalService.getDataInput("VISITA ASESOR", "HORARIO", $scope.origen);
				
				showViewAndHideSpinner();
			} else { // Es visita.
				$scope.vTelefonica = false;
				//Se consulta la disponibilidad; Es visita.
				$scope.obtenerDisponibilidad();
				
				$scope.mensajeVisible = false;

				if ($scope.validaSucursalClteAzul) {
					$scope.horario = [ {
						visible : "true"
					} ];
					$scope.validar = false;
				}
			}
		}

		//Agenda unicamente para clientes verdes y que pertenezcana la NOC.
		$scope.guardarHoraLlamada = function() {

			if (($scope.horaContacto.id != "" && $scope.horaContacto.id != undefined) || !$scope.validarHora) {
				
				var x = {};
				
				if($scope.validarHora){
					x = {
						idSolicitud : $rootScope.solicitudJson.idSolicitud,
						periodoCita : $scope.horaContacto.id.toString()
					}
				}else{
					x = {
						idSolicitud : $rootScope.solicitudJson.idSolicitud,
					}
				}

				bazDigitalService.agendarLlamada(x).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
							$scope.resp = JSON.parse(data.data.respuesta);
							if ($scope.resp.codigo == 2) {
								$rootScope.solicitudJson = $scope.resp.data;
								intentos = 0;
								// ¿Se imprime aviso de llamada?
								if(configuracion.so.windows && $scope.paramAvisoLlamada ){
									imprimirAvisoLlamada(intentos, limite);
								}else{
									$scope.letsGo();
								}
							}else if($scope.resp.codigo == TARJETA_FOLIO_EN_PROCESO){
								$rootScope.message("Visita Asesor", ["Codigo : "+$scope.resp.codigo, "Aviso: La solicitud esta siendo procesada. Por favor, espere un momento"],"Aceptar",null,"bgAzul", "bgAzul");
							}else
								$rootScope.message("Visita Asesor", [ "Se tuvo un inconveniente al registrar la información de tu solicitud. Por favor comunicate con soporte." ], "Aceptar", $scope.pathInicial);
						} else
							$rootScope.message("ERROR", [ generalService.displayMessage(data.data.descripcion) ], "Aceptar", $scope.pathInicial);
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						generalService.locationPath($scope.pathInicial);
					});

			} else {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("Error", [ "Hora inválida" ], "Aceptar", null, "bgRojo", "rojo");
			}
		};

		//Guarda la hora de agendar llamada para clientes verdes y que pertenezcan a BazDigital
		$scope.guardarHoraLlamadaBazDigital = function() {
			if ($scope.horaContacto.id != "" && $scope.horaContacto.id != undefined) {				
				var x = {};
				
				if($scope.validarHora){
					x = {
						idSolicitud : $rootScope.solicitudJson.idSolicitud,
						periodoCita : $scope.horaContacto.id.toString()
					}
				}else{
					x = {
						idSolicitud : $rootScope.solicitudJson.idSolicitud,
					}
				}
				
				bazDigitalService.agendaLlamadaBazDigital(x).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
							$scope.resp = JSON.parse(data.data.respuesta);
							if ($scope.resp.codigo == 2) {
								$rootScope.solicitudJson = $scope.resp.data;
								if ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazEntregada)
									$scope.recuperaTAZ();
								else
									$scope.dispersarCallCenter();
							}else if($scope.resp.codigo == TARJETA_FOLIO_EN_PROCESO){
								$rootScope.message("Visita Asesor", ["Codigo : "+$scope.resp.codigo, "Aviso: La solicitud esta siendo procesada. Por favor, espere un momento"],"Aceptar",null,"bgAzul", "bgAzul");
							} else
								$rootScope.message("Visita Asesor", [ "Ocurrió un problema al generar la llamada (Baz Digital)." ], "Aceptar", $scope.pathInicial);
						} else
							$rootScope.message("ERROR", [ generalService.displayMessage(data.data.descripcion) ], "Aceptar", $scope.pathInicial);
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						generalService.locationPath($scope.pathInicial);
					});
			} else {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("Error", [ "Hora inválida" ], "Aceptar", null, "bgRojo", "rojo");
			}
		};

		/*$scope.periodoColorAzul = function() {
			if (color == COLORES_EVALUACION_CTE.AZUL && $scope.validaSucursalClteAzul) {
				$scope.periodo = 1;
			}
		}*/

		$scope.init = function() {
			/*\Se agrega un evento para la bitacora\*/
//			(Generar Cita / Cita de verificación)
			$rootScope.addEvent( BITACORA.SECCION.citaDeVerificacion.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.entrar.id, 0, BITACORA.SECCION.citaDeVerificacion.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/

			if(generalService.validardiaDePago())
				generalService.setArrayValue("sourcePath", "/diadePago");
			else
				generalService.setArrayValue("sourcePath", "/ochoPasos");
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			$scope.showPage = false;

			if (messageData) {
				$scope.jsonVisitaAsesor = generalService.visitaAsesorData;
				$scope.cargaVista();

			}

		};		
		
		$scope.obtenerDisponibilidad = function() {
			
			// Oh, hello Spinner!
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			
			var jsonRequest = {
					"latitud": $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud,
					"longitud": $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud,
				    "idActividad": 3, //Investigacion de linea de credito
				    "idOrigen": 19, //Nueva originacion de credito
				    "tipoOperacion": "gps",
				    "numDias": 7
			}
				
			// Se realiza el consumo de un servicio.
			solicitudService.obtenerDatosVisita(jsonRequest).then(function(exito){
				
				// Se valida respuesta del servicio
				if (exito.data.codigo == RESPONSE_CODIGO_EXITO) {
					
					// Se obtiene la respuesta del consumo.
					var responseDisponibilidad = JSON.parse(exito.data.respuesta);
					
					// Se obtuvo un código exitoso.
					if((responseDisponibilidad.codRsp == "SRA000") && (responseDisponibilidad.datoRsp != null)) {
						$scope.jvcEmployeeNumber = responseDisponibilidad.datoRsp.numeroEmpleado;
						$scope.tipoEmpleado = responseDisponibilidad.datoRsp.tipoEmpleado;
						
						// Se extraen horarios de la respuesta del servicio y se forma el combo a mostrarse en la vista
						$scope.getHorarios(responseDisponibilidad.datoRsp.fechasDisponibles);
						
						//Validamos que el arreglo de horarios tenga registros
						if($scope.combos.length > 0){
							//Seleccion automatica de los primeros horarios
							$scope.visitDate = getPrettyFormatDate($scope.combos[0].fecha, false, false);
							$scope.visitTime = $scope.combos[0].periodos[0].periodo;
							$scope.visitIdPeriod = $scope.combos[0].periodos[0].id;
							
							$scope.selectedDate = $scope.combos[0];
							$scope.selectedPeriod = $scope.combos[0].periodos[0];
							
							// Se obtienen datos del asesor 
							$scope.datosEmpleadoAsesor();
							
							//Se detiene el flujo para no llegar al error
							return;
							
						}
						
					}
					
				} 
				
				// No se muestra nada de la página actual.
				$scope.showPage = false;
				// Bye, bye Spinner!
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				// Se limpia el $rootScope.
				generalService.cleanRootScope($rootScope);
				// Se reconstruye el JSON de la solicitud.
				generalService.buildSolicitudJson($rootScope, null);
				// Se muestra un mensaje como feedback.
				var mensajeErrorDisponibilidad =  (responseDisponibilidad != undefined) ? responseDisponibilidad.dscRsp : "Reintentar mas tarde";
				$rootScope.message("Visita Asesor", ["Inconveniente en el servicio de Disponibilidad: " + mensajeErrorDisponibilidad], "Aceptar", "/");
				
				
			},function(error){
				$rootScope.message("Visita Asesor", ["Inconveniente en el servicio de Disponibilidad"], "Aceptar", "/");
				// Se cargan ya los datos.
				showViewAndHideSpinner();
			});	
			
		};
		
		/**
		 * Funcion para crear el arreglo de horarios a iterarse
		 */
		$scope.getHorarios = function(fechasDisponibles){
			
			var horaInicio;
			var horaFin;
			var idPeriodo;
			var horarios = [];
			$scope.comboCompleto = [];
			
			//Se extraen horarios de la respuesta del servicio y se crea arreglo legible para iterarse en la vista
			for(var i = 0; i < fechasDisponibles.length; i++){
				//Extraccion de horarios
				for(var x = 0; x < fechasDisponibles[i].horarios.length; x++){
					
					horaInicio = fechasDisponibles[i].horarios[x].horaInicio; 
					horaFin = fechasDisponibles[i].horarios[x].horaFin;
					idPeriodo = fechasDisponibles[i].horarios[x].idPeriodo;
					
					horarios.push({"periodo":horaInicio+" - "+horaFin, "id": idPeriodo});
					
				}
				//Creacion de arreglo
				$scope.comboCompleto.push({
					
					"fecha": fechasDisponibles[i].fecha.split("-").reverse().join("-"),
					"formato": getPrettyFormatDate(fechasDisponibles[i].fecha.split("-").reverse().join("-"), false, false),
					"periodos": horarios
					
				});
				//Se limpia el arreglo de horarios para setear los de la siguiente fecha disponible
				horarios = [];
				
			}
			
			// Activa check box "elegir otro dia" y recorta el combo si revasa de 3 horarios
			if($scope.comboCompleto.length > 3){	
				//Se inserta el combo y se recorta a 3 horarios para mostrarse
				//Se deja intacto el combo completo por si el cliente desea elegir otro dia con el check box
				var corteTresHorarios = [];
				corteTresHorarios = $scope.comboCompleto;
				$scope.combos = corteTresHorarios.slice(0,3);
				$scope.moreDays = true;
			}else{
				// Desactiva check box "elegir otro dia"
				//Se inserta el combo de horarios completo porque no revasa los 3 horarios
				$scope.combos = $scope.comboCompleto;
				$scope.moreDays = false;
			}
			
		};
		
		$scope.datosEmpleadoAsesor = function() {
			
			solicitudService.obtenerDatosEmpleadoAsesor($scope.jvcEmployeeNumber).then(function(exito){
				// ¿Todo olrait?
				if(exito.data.codigo == RESPONSE_CODIGO_EXITO) {
					//Se parsea la respuesta
					try {
						var responseAsesor = JSON.parse(exito.data.respuesta);
					} catch (e) {
						// Se muestra un mensaje como feedback.
						$rootScope.message("Visita Asesor", ["Respuesta de Asesor invalida"], "Aceptar");
					}
	
					//Se obtuvo un codigo exitoso?
					if((responseAsesor.codigo == "200.Credito-Creditos.SRA000") && (responseAsesor.respuesta != null)) {
						//Se valida que tenga informacion la respuesta antes de setearla
						if(responseAsesor.respuesta.nombreEmpleado != '' && responseAsesor.respuesta.nombreEmpleado != null){
							if(responseAsesor.respuesta.descPuestoEmpleado != '' && responseAsesor.respuesta.descPuestoEmpleado != null){
								//Se coloca la respuesta en sus respectivas variables
								$scope.jvcNombre = responseAsesor.respuesta.nombreEmpleado;	
								$scope.empleadoParaVisita = $scope.formatoLetras(responseAsesor.respuesta.descPuestoEmpleado);
								//Se setea la foto, sino tiene se queda la foto por default
								if(responseAsesor.respuesta.foto != '' && responseAsesor.respuesta.foto != null)
									$scope.jvcPhoto = uriB64 + responseAsesor.respuesta.foto;
								// Se cargan ya los datos.
								showViewAndHideSpinner();
								return;
								
							}
						}
					}		
				}
				// No se muestra nada de la página actual.
				$scope.showPage = false;
				// Se limpia el $rootScope.
				generalService.cleanRootScope($rootScope);
				// Se reconstruye el JSON de la solicitud.
				generalService.buildSolicitudJson($rootScope, null);
				// Se muestra un mensaje como feedback.
				var mensajeErrorAsesor =  (responseAsesor != undefined) ? responseAsesor.mensaje : "Reintentar mas tarde";
				$rootScope.message("Visita Asesor", ["Inconveniente en el servicio para obtener Asesor: " + mensajeErrorAsesor], "Aceptar", "/");
				// Se cargan ya los datos.
				showViewAndHideSpinner();
				
				return;
				
			},function(error){
				// Se muestra un mensaje como feedback.
				$rootScope.message("Visita Asesor", ["Inconveniente en el servicio para obtener Datos del asesor: "+ error], "Aceptar", "/");
				// Se cargan ya los datos.
				showViewAndHideSpinner();
			});
			
		};
		
		/**
		 * Utilería que regresa una fecha formateada.
		 * fecha: cadena con la fecha a formatear.
		 * noDay: buleano para agregar o no el nombre del día de la fecha.
		 * noYear: buleano para agregar o no el año.
		 */
		function getPrettyFormatDate(fecha, noDay, noYear) {
			var date = new Date(fecha.replace(/-/g, '\/'));
			
			if(!isNaN(date.getDay()) && !isNaN(date.getDate()) && !isNaN(date.getMonth())) {
				var formato = "";
				
				if(!noDay) {
					formato += catalogos.dias[date.getDay()] + ", "; 
				}
				
				formato += date.getDate() + " de " + catalogos.meses[date.getMonth()]; 
				
				if(!noYear) {
					formato += " de " + date.getFullYear(); 
				}
				
				return formato;				
			}
			
			return fecha;
		};
		
		/**
		 * Función para dar formato de Mayusculas y Minusculas.
		 * De: AAAA AAAA AAAA a: Aaaa Aaaa Aaaa
		 */
		$scope.formatoLetras = function(enunciado){
			
			var arregloMayusculas = enunciado.split(" ");
			var arregloFormateado = [];
			var letraMayuscula = "";
			
			for(var i = 0; i < arregloMayusculas.length; i ++){
				
				letraMayuscula = arregloMayusculas[i].substring(0,1);
				arregloFormateado.push(letraMayuscula+arregloMayusculas[i].substring(1).toLowerCase());
				
			}
			
			return arregloFormateado.join(' ');
			
		};
		
		/**
		 * Función listener para el combo de fechas.
		 */
		$scope.onChangeDate = function() {
			$scope.selectedPeriod = $scope.selectedDate.periodos[0];
			$scope.visitDate = getPrettyFormatDate($scope.selectedDate.fecha, false, false);
			$scope.visitTime = $scope.selectedPeriod.periodo;
			$scope.visitIdPeriod = $scope.selectedPeriod.id;
		};
		
		/**
		 * Function listener para el combo de periodos. 
		 */
		$scope.onChangePeriod = function() {
			$scope.visitTime = $scope.selectedPeriod.periodo;
			$scope.visitIdPeriod = $scope.selectedPeriod.id;
		};
		
		/**
		 * Utilería para voltear una fecha dada, separando por separador:
		 * "2018-04-26" regresaría "26-04-2018".
		 * y viceversa.
		 */
		function reverseDate(fecha, separador) {
			// La fecha provista no es nula y su longitud es exactamente igual a 10, por los separadores.
			if(fecha != null && fecha.length == 10) {
				var particion = fecha.split(separador);
				
				if(particion.length == 3) {
					return particion[2] + separador + particion[1] + separador + particion[0];
				}
			}
			
			return "";
		};
		
		function showViewAndHideSpinner() {
			$scope.showPage = messageData;
			// Bye, bye Spinner!
			$rootScope.waitLoaderStatus = LOADER_HIDE;
		};
		
		function verdePermiteVisita(){
			
			if($rootScope.consultaFuncionalidad.habilitarEnvioCitaCredInmNoHit && 
			   !$rootScope.solicitudJson.hitBuro &&
			   $rootScope.solicitudJson.creditoInmediato){
				return true;
			}else{
				return false;
			}
		}

		$scope.datosAsesorRespaldo = function(descError) {
			if ($scope.respaldoAntiguo == null) {
				if (descError == 1)
					$rootScope.message("Visita asesor", [ ERROR_SERVICE ], "Aceptar", $scope.pathOpcional);
				else
					$rootScope.message("Lo sentimos...", [ "No encontramos JVC dentro de su ubicación " + descError, "Latitud: " + $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.latitud, " Longitud: " + $rootScope.solicitudJson.cotizacion.clientes[0].domicilios[0].zonificacion.longitud ], "Aceptar", $scope.pathOpcional);

			} else {
				$scope.resp = $scope.respaldoAntiguo;
				$scope.datosCorrecto();
			}
		};

		$scope.datosCorrecto = function() {
			$scope.cargaRespuesta();
			$scope.combos = {
				"dias" : $scope.dias,
				"periodos" : periodos
			};
			//$timeout(function() {
				$scope.cargaVista();
				$scope.showPage = messageData;
			//}, 1);
		};

		$scope.crearJsonAntiguo = function() {
			var foto = "";
			if ($scope.respaldoAntiguo != null && $scope.respDisp.datoRsp.numeroEmpleado == $scope.respaldoAntiguo.data.noEmpleado)
				foto = $scope.respaldoAntiguo.data.foto;
			$scope.resp = {};
			$scope.resp = {
				data : {
					noEmpleado : "",
					nombre : "",
					foto : "",
					fechaVisita : "",
					periodoVisita : {
						idPerido : 0,
						descPeirodo : ""
					},
					fechasCitaAsesor : []
				}
			};
			$scope.resp.data.noEmpleado = $scope.respDisp.datoRsp.numeroEmpleado;
			$scope.resp.data.nombre = $scope.respDisp.datoRsp.nombreEmpleado;
			$scope.resp.data.foto = foto;
			var primerosDias = false;
			$scope.registros = 0;
			$scope.disponibilidad = false;
			
			/**
			 * Variables que se usan para solicitar mas dias de los predeterminados
			 **/
			var diasMinimos = 3;
			var diasMaximos = 7;

			var respuesta = $scope.respDisp.datoRsp.dias;

			var auxMain = [];
			for (var i = 0; i < respuesta.length; i++) {
				var aux = [];
				for (var j = 0; j < respuesta[i].periodos.length; j++) {
					if (respuesta[i].periodos[j].disponibilidad == 0) {
					} else {
						aux.push(respuesta[i].periodos[j]);
					}
				}

				if (aux.length == 0) {
				} else {
					respuesta[i].periodos = aux;
					auxMain.push(respuesta[i]);
				}
			}

			$scope.respDisp.datoRsp.dias = auxMain;

			if ($scope.respDisp.datoRsp.dias && $scope.respDisp.datoRsp.dias.length > 0) {
				if ($scope.respDisp.datoRsp.dias.length > 7 && !nuevosHorariosJVC)
					$scope.registros = 7;
				else if ($scope.respDisp.datoRsp.dias.length >= diasMaximos && nuevosHorariosJVC)
					/**
					 * Condición en la que se usa el nuevo servicio para tener solo dos horarios disponibles.
					 * diasMaximos tiene valor de 7
					 **/
					$scope.registros = diasMaximos;
				else
					$scope.registros = $scope.respDisp.datoRsp.dias.length;
				for (var a = 0; a < $scope.registros; a++) {
					for (var b = 0; b < $scope.respDisp.datoRsp.dias[a].periodos.length; b++) {
						if ($scope.respDisp.datoRsp.dias[a].periodos[b].disponibilidad > 0) {
							primerosDias = true
							break;
						}
					}
					if (primerosDias)
						break;
				}
				if (primerosDias) {
					for (var a = 0; a < $scope.registros; a++) {
						$scope.cargaFechaCitaAsesor(a);
					}
				} else {
					for (var a = 7; a < $scope.respDisp.datoRsp.dias.length; a++) {
						$scope.cargaFechaCitaAsesor(a);
					}
				}
				if ($scope.disponibilidad) {
					var longFecha = $scope.resp.data.fechasCitaAsesor[0].fechaCita.length - 10;
					$scope.resp.data.fechaVisita = $scope.resp.data.fechasCitaAsesor[0].fechaCita.substr(longFecha, 10);
					$scope.resp.data.periodoVisita.idPerido = $scope.resp.data.fechasCitaAsesor[0].periodoCita[0].idPerido;
					$scope.resp.data.periodoVisita.descPeirodo = $scope.resp.data.fechasCitaAsesor[0].periodoCita[0].descPeirodo;
				}
				
				if(nuevosHorariosJVC){
					/**
					 * Se obtienen del arreglo de fechas disponibles, otro aregllo temporal que contendra las fechas minimas establecidad por el usuario
					 * Se tendran dos variables, una con un arreglo de maximo 7 dias y otro con un arreglo de minimo 3 dias
					 * Al final, se inicializa la vista solo con 3 dias
					 **/
					var fechasMinDis = [];
					for(var i=0;i<$scope.resp.data.fechasCitaAsesor.length;i++){
						if(i < diasMinimos){
							fechasMinDis.push($scope.resp.data.fechasCitaAsesor[i]);
						}else{
							break;
						}
					}
	
					/**
					 * Se crean variables con los datos Minimos en 'horariosDispMin'
					 * Se crean variables con los datos maximos en 'horariosDispMax'
					 * Dependiendo si el checkBox esta habilitado o deshabilitado, se mostrarán los horarios
					 **/
					$scope.horariosDispMin = fechasMinDis;
					$scope.horariosDispMax = $scope.resp.data.fechasCitaAsesor;
					
					if($scope.inicializaCheckBox){
						$scope.resp.data.fechasCitaAsesor = $scope.horariosDispMax;
					}else{
						$scope.resp.data.fechasCitaAsesor = $scope.horariosDispMin;
					}
				}
			}
		};

		$scope.cargaFechaCitaAsesor = function(a) {
			var arrayPeriodoCita = [];
			for (var b = 0; b < $scope.respDisp.datoRsp.dias[a].periodos.length; b++) {
				if ($scope.respDisp.datoRsp.dias[a].periodos[b].disponibilidad > 0) {
					$scope.disponibilidad = true;
					var recuperarID = null;
					for (var c = 0; c < periodosCatalogo.length; c++) {
						if (periodosCatalogo[c].descripcion == $scope.respDisp.datoRsp.dias[a].periodos[b].periodo) {
							recuperarID = periodosCatalogo[c].id;
							break;
						}
					}
					arrayPeriodoCita.push({
						idPerido : recuperarID,
						descPeirodo : $scope.respDisp.datoRsp.dias[a].periodos[b].periodo
					});
				}

			}
			if ($scope.disponibilidad) {
				var fechaArray = $scope.respDisp.datoRsp.dias[a].fecha.split('-');
				var fechaFormatoAntiguo = fechaArray[2] + "/" + fechaArray[1] + "/" + fechaArray[0];
				var fechaDescDia = new Date(fechaArray[1] + "/" + fechaArray[2] + "/" + fechaArray[0]);
				var numDia = fechaDescDia.getDay();
				$scope.resp.data.fechasCitaAsesor.push({
					fechaCita : descDias[numDia] + " " + fechaFormatoAntiguo,
					periodoCita : arrayPeriodoCita
				});
			}
		};

		$scope.cargaRespuesta = function() {
			var ddSemana = 0;
			var ok = null;
			$scope.idAsesor = $scope.resp.data.noEmpleado;
			$scope.nombreAsesor = generalService.camelize($scope.resp.data.nombre);
			//	    	$scope.fotoAsesor = "data:image/png;base64," + $scope.resp.data.foto;
			$scope.fotoAsesor = "data:image/png;base64," + "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABgAGEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2SKKEwRkxISVHO2gxQ/8APJP++aIm/cR/7ooLVokSyMxxf3F/KomSP+4v5VITUTGrSJImVf7o/KomA9KdLMkeN7quf7x61nz6vYwvse5TJ9Of5VVkDLLGoWY+tKJY5RlJFceoNMY1SSJuMZ2/vH86haV/77fnT2NQMatJE3EaaX/no/8A31TYp5TcRgyOQWA+9TGNNhP+lRf74puKswTdz1CikxRXAdBgxt+5T/doLVCjfu1/3aC1bpGbFLVQ1PUE0+1aZ+T0Vf7xq0WrivEd6bjUTD/BB8v1PensBl3E8txIZJnLuTnJqAmlJphNADoriW3k8yF2RvY9a6LS9bF1iG5IWb+FuzVzBNM3lGBBwQcg+lUnYTO9Y1ExqvYXgvLJJc5fGHHo1Ssa2RDGMabAf9Ki/wB8UjGkgP8ApUX++v8AOm/hYup6lRRRXnHQcqG+UfSgtUW7ikLV1JaGbeo8tXi2qeI7l9dOn6bEk8zTeUWl43OTgAcjHPc//r9jY5BFeBa1ZWw8RahbyS/YXjnYZnVmVuTlsqCwz8pAwRyeRxnkxc5QiuVnrZPh6VarL2ivZf1puzas9U1WTUX066s44rlo3aE4IUlQxJJydy/KeQe3equja5fatq9vZsLWJHJLuVb5UUFmI564Bx71V8Hz3a6jNGl1JFZLBJLcr5u1MBcAkHj7xUevNVfCsiReIoGkdUUxzKCxwMmJwB9SSB+Ncsa03y67v/I9ipgaMfbe4rqKa9fe+7Zaa/iWz4nu7e+aG6hgZI3KP5QIPBxxk1al1a7l1a1s7I2rpdlBC7hv4jt+bHTnPas+xs7PU9W1aOaVQWR2t3Dfx+YvT+98pbj0ye2ai0i0msvF2mQzLhheQ4PYjeOR7Ue2qpb6X3H9Twbl8KUlG9uj03+TPTtAkCvdQRvvjDZVsY3D1x2rYY1kaBEq2bTY+d2xn6Vpsa9uK0PjGNY0QH/S4f8AfX+dMY0W5/0uH/rov86uWzEtz1eiiivMOk4otzSFqjdvmP1rP1jUJdM0m5vYbb7S0CbzFvCZUfeOT6DJ/CutWUbszjFzkordmiWrn/EWmJdEXgtLWZo0wxmhSQhBk8bgcdWrA0z4gX2tXLW+n+HvOlVDIV+2quFBAzkqO5FaOkeMbfVLLUpr+2bT/sJCzLI24DOQOwO7IIxj065xWSr0aml/wO2eBxdC8mrNW2avrotE76mO0n+itapHFHbuSXhiiVEYnGchQAeg601DFDKksVnYpIhDKy2cQKkdCDt4Nc9c+J0VjJBYzNalisbyNt3YAJHAIyMjv3HrU9zr1tFZR3EYMpkOFToQR1z6Yz/nrWSq0HfVaGjwOPi0uV+95/nr+ZrRGO3x5NraRsFKB0tow2CMH5guehPekhO25hlSOJ5kb5C8auUOQcjIODwORXNHxV/05/8AkX/61bGj6zaPbyandkRJauAYwSzMSPlxwAScNx/sknA5qoVqEvdTCtl2Ph784vtvff0Z3NlbfYrRYd24jkmpGNcU/wAQ1SZN+lSrbucpIZMMybiNwGMHoeM9QRmust7uC9to7m2kWSGQZVl711Ua1Oo7QdzjxOCr4dJ1Y2T/AK6ErGi2P+mQf9dF/nUZNSWn/H5B/wBdF/nW8vhZyrc9aoooryzpPP5G/eN/vVl+IW/4pvVP+vSX/wBANX5W/fP/AL1U76zttSs5LS7j82CTG5NxGcEEcgg9QK7XFuDSIpyUakZS2TR4zoWm32qm/tbA5lNsCY/l/eKJI+MkjHOGz/s4713fjLTbpPAtjaInnNY+UZjHyAFjKsw7kZP5c1rW+geHtGukvIbRIJo87XMztjIIPBYjoTTLzxGoytomT/fb/CuKjg3GDU93oezjM4VSvCdJe7F310d9ujZ5lFewP4Vn0+TassVyLiPJOX3BVOBjHAX1/i6cVs+GbR00Wa6ubaN4nmUW32iNXU8N5hVWz3EYLY7YzxVyOx0uKVZTpNrJKH35cyYJznlQ23HtjFTz3Ek7KZCMIoRVVQqqo4AAHAHsKmlhJKSc7aFYzNqc6UoUE05O7v022+78zmbGR5vHltLIcu+pqzHHUmUVb8R2ZbTLa4gs4kjhdkleGFUxkLt3YAJ6Hk+vvV9dP0lUAOk27EDBYyzZPvw9WWunMkrqqKsud0ar8hB6jHp7UU8I+WUZ9R1s3gq1KpSv7qs09L/c2c5dX1pd+DbG3O1byynaMDccmN9zlsdMZwO+NvbNdp4Nt7q38MRG6WRfMld4Q5/5ZELggdgTuPvnPeqGnQeH4JUeXSIFkUYDOzyL0xkqzEH8q6oXK3RLrIshPVga2wuFnGopzeytoYZhmdKtRdGinZu+vTrp8xamtP8Aj8g/66L/ADqGprT/AI/IP+ui/wA69GXws8NbnrVFFFeUdR5hf3K23nzP91CTXIXGsXk7E+cUX+6nAFdR4h0vU5oJUh067kLS9EhY8Z69K5n/AIR7W/8AoD6h/wCAz/4V2cystTGzM8uWbJJJ96aTWj/wj2uf9AfUP/AZ/wDCkPh3Xf8AoD3/AP4DP/hRzLuOzM4mmk1pHw7rv/QGv/8AwGf/AApp8Oa7/wBAbUP/AAGf/ClzILMzCaaTWp/wjmuf9AbUP/AZ/wDCk/4RrXP+gNqH/gM/+FVzoVmZlAJVsqSD7da0/wDhGtc/6A2of+Az/wCFH/CNa5/0BtQ/8Bn/AMKfOgsyCHVbyFgfNLj+6/euq0udbmS1mTgM68enNc5/wjWu/wDQG1D/AMBn/wAK6Pw7o2qwLGJ9MvI9s2fngYcevSmpqz1Fyu57BRS4orgNz//Z";
			$scope.recuperaFoto();
			var fechaServicio = $scope.resp.data.fechaVisita;
			$scope.textoPeriodo = $scope.resp.data.periodoVisita.descPeirodo;
			//	    	if($scope.resp.data.periodoVisita.idPerido == 1)
			//	    	   $scope.terminoPeriodo = "el";
			//	    	else
			$scope.terminoPeriodo = "la";

			var fechaCita = fechaServicio.substr(3, 2) + "/" + fechaServicio.substr(0, 2) + "/" + fechaServicio.substr(6, 4);
			var fechaDia = new Date(fechaCita);
			dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
			ddSemana = fechaDia.getDay();
			$scope.textoDia = $scope.textoDias[ddSemana];
			$scope.numDia = dd;
			ok = true;
			for (var a = 0; ok; a++) {
				if (a == fechaDia.getMonth()) {
					$scope.textoMes = $scope.meses[a];
					ok = false;
				}
			}
			var fechasCitaAsesor = $scope.resp.data.fechasCitaAsesor;
			//    		$scope.dias.push({id:1,descripcion:"20 de Junio",fecha:"20/06/2016"});
			//    		periodos.push({id:1,idPeriodo:3,descripcion:"NOCHE",fecha:"20/06/2016"});
			for (var i = 0; i < fechasCitaAsesor.length; i++) {
				var longFecha = fechasCitaAsesor[i].fechaCita.length - 10;
				var diaFechasCitaAsesor = generalService.camelize(fechasCitaAsesor[i].fechaCita.substr(0, longFecha - 1));
				fechasCitaAsesor[i].fechaCita = fechasCitaAsesor[i].fechaCita.substr(longFecha, 10);
				fechaDia = fechasCitaAsesor[i].fechaCita.substr(3, 2) + "/" + fechasCitaAsesor[i].fechaCita.substr(0, 2) + "/" + fechasCitaAsesor[i].fechaCita.substr(6, 4);
				fechaDia = new Date(fechaDia);
				dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
				var textoMesArray = "";
				ok = true;
				for (var a = 0; ok; a++) {
					if (a == fechaDia.getMonth()) {
						textoMesArray = $scope.meses[a];
						ok = false;
					}
				}
				var descripcion = diaFechasCitaAsesor + " " + dd + " de " + textoMesArray;
				var mm = ((fechaDia.getMonth() + 1) < 10 ? '0' : '') + (fechaDia.getMonth() + 1);
				$scope.dias.push({
					id : i + 1,
					descripcion : descripcion,
					fecha : dd + "/" + mm + "/" + fechaDia.getFullYear()
				});

				var arrayPeriodo = $scope.resp.data.fechasCitaAsesor[i].periodoCita;
				for (var e = 0; e < arrayPeriodo.length; e++) {
					var idPeriodo = arrayPeriodo[e].idPerido;
					var descPeriodo = arrayPeriodo[e].descPeirodo;
					periodos.push({
						id : i + 1,
						idPeriodo : idPeriodo,
						descripcion : descPeriodo,
						fecha : dd + "/" + mm + "/" + fechaDia.getFullYear()
					});
				}
			}
			$scope.dia = fechaServicio;
			$scope.periodo = $scope.resp.data.periodoVisita.idPerido;
		};

		//	    es el bueno
		//	    $scope.recuperaFoto = function(){
		//	    	if ($scope.idAsesor != null && $scope.idAsesor != ""){
		//		    	var empleado = { idEmpleado: $scope.idAsesor };
		//				solicitudService.getFotoAsesorArq(empleado).then(
		//						function(data){
		//							if(data.data.codigo == RESPONSE_CODIGO_EXITO){
		//								if(data.data.respuesta.code == 200 && data.data.respuesta.result != null)
		//									$scope.fotoAsesor="data:image/png;base64," + data.data.respuesta.result;
		//								else
		//									$scope.fotoAsesor="data:image/png;base64," + "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABgAGEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2SKKEwRkxISVHO2gxQ/8APJP++aIm/cR/7ooLVokSyMxxf3F/KomSP+4v5VITUTGrSJImVf7o/KomA9KdLMkeN7quf7x61nz6vYwvse5TJ9Of5VVkDLLGoWY+tKJY5RlJFceoNMY1SSJuMZ2/vH86haV/77fnT2NQMatJE3EaaX/no/8A31TYp5TcRgyOQWA+9TGNNhP+lRf74puKswTdz1CikxRXAdBgxt+5T/doLVCjfu1/3aC1bpGbFLVQ1PUE0+1aZ+T0Vf7xq0WrivEd6bjUTD/BB8v1PensBl3E8txIZJnLuTnJqAmlJphNADoriW3k8yF2RvY9a6LS9bF1iG5IWb+FuzVzBNM3lGBBwQcg+lUnYTO9Y1ExqvYXgvLJJc5fGHHo1Ssa2RDGMabAf9Ki/wB8UjGkgP8ApUX++v8AOm/hYup6lRRRXnHQcqG+UfSgtUW7ikLV1JaGbeo8tXi2qeI7l9dOn6bEk8zTeUWl43OTgAcjHPc//r9jY5BFeBa1ZWw8RahbyS/YXjnYZnVmVuTlsqCwz8pAwRyeRxnkxc5QiuVnrZPh6VarL2ivZf1puzas9U1WTUX066s44rlo3aE4IUlQxJJydy/KeQe3equja5fatq9vZsLWJHJLuVb5UUFmI564Bx71V8Hz3a6jNGl1JFZLBJLcr5u1MBcAkHj7xUevNVfCsiReIoGkdUUxzKCxwMmJwB9SSB+Ncsa03y67v/I9ipgaMfbe4rqKa9fe+7Zaa/iWz4nu7e+aG6hgZI3KP5QIPBxxk1al1a7l1a1s7I2rpdlBC7hv4jt+bHTnPas+xs7PU9W1aOaVQWR2t3Dfx+YvT+98pbj0ye2ai0i0msvF2mQzLhheQ4PYjeOR7Ue2qpb6X3H9Twbl8KUlG9uj03+TPTtAkCvdQRvvjDZVsY3D1x2rYY1kaBEq2bTY+d2xn6Vpsa9uK0PjGNY0QH/S4f8AfX+dMY0W5/0uH/rov86uWzEtz1eiiivMOk4otzSFqjdvmP1rP1jUJdM0m5vYbb7S0CbzFvCZUfeOT6DJ/CutWUbszjFzkordmiWrn/EWmJdEXgtLWZo0wxmhSQhBk8bgcdWrA0z4gX2tXLW+n+HvOlVDIV+2quFBAzkqO5FaOkeMbfVLLUpr+2bT/sJCzLI24DOQOwO7IIxj065xWSr0aml/wO2eBxdC8mrNW2avrotE76mO0n+itapHFHbuSXhiiVEYnGchQAeg601DFDKksVnYpIhDKy2cQKkdCDt4Nc9c+J0VjJBYzNalisbyNt3YAJHAIyMjv3HrU9zr1tFZR3EYMpkOFToQR1z6Yz/nrWSq0HfVaGjwOPi0uV+95/nr+ZrRGO3x5NraRsFKB0tow2CMH5guehPekhO25hlSOJ5kb5C8auUOQcjIODwORXNHxV/05/8AkX/61bGj6zaPbyandkRJauAYwSzMSPlxwAScNx/sknA5qoVqEvdTCtl2Ph784vtvff0Z3NlbfYrRYd24jkmpGNcU/wAQ1SZN+lSrbucpIZMMybiNwGMHoeM9QRmust7uC9to7m2kWSGQZVl711Ua1Oo7QdzjxOCr4dJ1Y2T/AK6ErGi2P+mQf9dF/nUZNSWn/H5B/wBdF/nW8vhZyrc9aoooryzpPP5G/eN/vVl+IW/4pvVP+vSX/wBANX5W/fP/AL1U76zttSs5LS7j82CTG5NxGcEEcgg9QK7XFuDSIpyUakZS2TR4zoWm32qm/tbA5lNsCY/l/eKJI+MkjHOGz/s4713fjLTbpPAtjaInnNY+UZjHyAFjKsw7kZP5c1rW+geHtGukvIbRIJo87XMztjIIPBYjoTTLzxGoytomT/fb/CuKjg3GDU93oezjM4VSvCdJe7F310d9ujZ5lFewP4Vn0+TassVyLiPJOX3BVOBjHAX1/i6cVs+GbR00Wa6ubaN4nmUW32iNXU8N5hVWz3EYLY7YzxVyOx0uKVZTpNrJKH35cyYJznlQ23HtjFTz3Ek7KZCMIoRVVQqqo4AAHAHsKmlhJKSc7aFYzNqc6UoUE05O7v022+78zmbGR5vHltLIcu+pqzHHUmUVb8R2ZbTLa4gs4kjhdkleGFUxkLt3YAJ6Hk+vvV9dP0lUAOk27EDBYyzZPvw9WWunMkrqqKsud0ar8hB6jHp7UU8I+WUZ9R1s3gq1KpSv7qs09L/c2c5dX1pd+DbG3O1byynaMDccmN9zlsdMZwO+NvbNdp4Nt7q38MRG6WRfMld4Q5/5ZELggdgTuPvnPeqGnQeH4JUeXSIFkUYDOzyL0xkqzEH8q6oXK3RLrIshPVga2wuFnGopzeytoYZhmdKtRdGinZu+vTrp8xamtP8Aj8g/66L/ADqGprT/AI/IP+ui/wA69GXws8NbnrVFFFeUdR5hf3K23nzP91CTXIXGsXk7E+cUX+6nAFdR4h0vU5oJUh067kLS9EhY8Z69K5n/AIR7W/8AoD6h/wCAz/4V2cystTGzM8uWbJJJ96aTWj/wj2uf9AfUP/AZ/wDCkPh3Xf8AoD3/AP4DP/hRzLuOzM4mmk1pHw7rv/QGv/8AwGf/AApp8Oa7/wBAbUP/AAGf/ClzILMzCaaTWp/wjmuf9AbUP/AZ/wDCk/4RrXP+gNqH/gM/+FVzoVmZlAJVsqSD7da0/wDhGtc/6A2of+Az/wCFH/CNa5/0BtQ/8Bn/AMKfOgsyCHVbyFgfNLj+6/euq0udbmS1mTgM68enNc5/wjWu/wDQG1D/AMBn/wAK6Pw7o2qwLGJ9MvI9s2fngYcevSmpqz1Fyu57BRS4orgNz//Z";
		//							}else
		//								$scope.fotoAsesor="data:image/png;base64," + "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABgAGEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2SKKEwRkxISVHO2gxQ/8APJP++aIm/cR/7ooLVokSyMxxf3F/KomSP+4v5VITUTGrSJImVf7o/KomA9KdLMkeN7quf7x61nz6vYwvse5TJ9Of5VVkDLLGoWY+tKJY5RlJFceoNMY1SSJuMZ2/vH86haV/77fnT2NQMatJE3EaaX/no/8A31TYp5TcRgyOQWA+9TGNNhP+lRf74puKswTdz1CikxRXAdBgxt+5T/doLVCjfu1/3aC1bpGbFLVQ1PUE0+1aZ+T0Vf7xq0WrivEd6bjUTD/BB8v1PensBl3E8txIZJnLuTnJqAmlJphNADoriW3k8yF2RvY9a6LS9bF1iG5IWb+FuzVzBNM3lGBBwQcg+lUnYTO9Y1ExqvYXgvLJJc5fGHHo1Ssa2RDGMabAf9Ki/wB8UjGkgP8ApUX++v8AOm/hYup6lRRRXnHQcqG+UfSgtUW7ikLV1JaGbeo8tXi2qeI7l9dOn6bEk8zTeUWl43OTgAcjHPc//r9jY5BFeBa1ZWw8RahbyS/YXjnYZnVmVuTlsqCwz8pAwRyeRxnkxc5QiuVnrZPh6VarL2ivZf1puzas9U1WTUX066s44rlo3aE4IUlQxJJydy/KeQe3equja5fatq9vZsLWJHJLuVb5UUFmI564Bx71V8Hz3a6jNGl1JFZLBJLcr5u1MBcAkHj7xUevNVfCsiReIoGkdUUxzKCxwMmJwB9SSB+Ncsa03y67v/I9ipgaMfbe4rqKa9fe+7Zaa/iWz4nu7e+aG6hgZI3KP5QIPBxxk1al1a7l1a1s7I2rpdlBC7hv4jt+bHTnPas+xs7PU9W1aOaVQWR2t3Dfx+YvT+98pbj0ye2ai0i0msvF2mQzLhheQ4PYjeOR7Ue2qpb6X3H9Twbl8KUlG9uj03+TPTtAkCvdQRvvjDZVsY3D1x2rYY1kaBEq2bTY+d2xn6Vpsa9uK0PjGNY0QH/S4f8AfX+dMY0W5/0uH/rov86uWzEtz1eiiivMOk4otzSFqjdvmP1rP1jUJdM0m5vYbb7S0CbzFvCZUfeOT6DJ/CutWUbszjFzkordmiWrn/EWmJdEXgtLWZo0wxmhSQhBk8bgcdWrA0z4gX2tXLW+n+HvOlVDIV+2quFBAzkqO5FaOkeMbfVLLUpr+2bT/sJCzLI24DOQOwO7IIxj065xWSr0aml/wO2eBxdC8mrNW2avrotE76mO0n+itapHFHbuSXhiiVEYnGchQAeg601DFDKksVnYpIhDKy2cQKkdCDt4Nc9c+J0VjJBYzNalisbyNt3YAJHAIyMjv3HrU9zr1tFZR3EYMpkOFToQR1z6Yz/nrWSq0HfVaGjwOPi0uV+95/nr+ZrRGO3x5NraRsFKB0tow2CMH5guehPekhO25hlSOJ5kb5C8auUOQcjIODwORXNHxV/05/8AkX/61bGj6zaPbyandkRJauAYwSzMSPlxwAScNx/sknA5qoVqEvdTCtl2Ph784vtvff0Z3NlbfYrRYd24jkmpGNcU/wAQ1SZN+lSrbucpIZMMybiNwGMHoeM9QRmust7uC9to7m2kWSGQZVl711Ua1Oo7QdzjxOCr4dJ1Y2T/AK6ErGi2P+mQf9dF/nUZNSWn/H5B/wBdF/nW8vhZyrc9aoooryzpPP5G/eN/vVl+IW/4pvVP+vSX/wBANX5W/fP/AL1U76zttSs5LS7j82CTG5NxGcEEcgg9QK7XFuDSIpyUakZS2TR4zoWm32qm/tbA5lNsCY/l/eKJI+MkjHOGz/s4713fjLTbpPAtjaInnNY+UZjHyAFjKsw7kZP5c1rW+geHtGukvIbRIJo87XMztjIIPBYjoTTLzxGoytomT/fb/CuKjg3GDU93oezjM4VSvCdJe7F310d9ujZ5lFewP4Vn0+TassVyLiPJOX3BVOBjHAX1/i6cVs+GbR00Wa6ubaN4nmUW32iNXU8N5hVWz3EYLY7YzxVyOx0uKVZTpNrJKH35cyYJznlQ23HtjFTz3Ek7KZCMIoRVVQqqo4AAHAHsKmlhJKSc7aFYzNqc6UoUE05O7v022+78zmbGR5vHltLIcu+pqzHHUmUVb8R2ZbTLa4gs4kjhdkleGFUxkLt3YAJ6Hk+vvV9dP0lUAOk27EDBYyzZPvw9WWunMkrqqKsud0ar8hB6jHp7UU8I+WUZ9R1s3gq1KpSv7qs09L/c2c5dX1pd+DbG3O1byynaMDccmN9zlsdMZwO+NvbNdp4Nt7q38MRG6WRfMld4Q5/5ZELggdgTuPvnPeqGnQeH4JUeXSIFkUYDOzyL0xkqzEH8q6oXK3RLrIshPVga2wuFnGopzeytoYZhmdKtRdGinZu+vTrp8xamtP8Aj8g/66L/ADqGprT/AI/IP+ui/wA69GXws8NbnrVFFFeUdR5hf3K23nzP91CTXIXGsXk7E+cUX+6nAFdR4h0vU5oJUh067kLS9EhY8Z69K5n/AIR7W/8AoD6h/wCAz/4V2cystTGzM8uWbJJJ96aTWj/wj2uf9AfUP/AZ/wDCkPh3Xf8AoD3/AP4DP/hRzLuOzM4mmk1pHw7rv/QGv/8AwGf/AApp8Oa7/wBAbUP/AAGf/ClzILMzCaaTWp/wjmuf9AbUP/AZ/wDCk/4RrXP+gNqH/gM/+FVzoVmZlAJVsqSD7da0/wDhGtc/6A2of+Az/wCFH/CNa5/0BtQ/8Bn/AMKfOgsyCHVbyFgfNLj+6/euq0udbmS1mTgM68enNc5/wjWu/wDQG1D/AMBn/wAK6Pw7o2qwLGJ9MvI9s2fngYcevSmpqz1Fyu57BRS4orgNz//Z";
		//						},function(error){
		//							$scope.fotoAsesor="data:image/png;base64," + "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABgAGEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2SKKEwRkxISVHO2gxQ/8APJP++aIm/cR/7ooLVokSyMxxf3F/KomSP+4v5VITUTGrSJImVf7o/KomA9KdLMkeN7quf7x61nz6vYwvse5TJ9Of5VVkDLLGoWY+tKJY5RlJFceoNMY1SSJuMZ2/vH86haV/77fnT2NQMatJE3EaaX/no/8A31TYp5TcRgyOQWA+9TGNNhP+lRf74puKswTdz1CikxRXAdBgxt+5T/doLVCjfu1/3aC1bpGbFLVQ1PUE0+1aZ+T0Vf7xq0WrivEd6bjUTD/BB8v1PensBl3E8txIZJnLuTnJqAmlJphNADoriW3k8yF2RvY9a6LS9bF1iG5IWb+FuzVzBNM3lGBBwQcg+lUnYTO9Y1ExqvYXgvLJJc5fGHHo1Ssa2RDGMabAf9Ki/wB8UjGkgP8ApUX++v8AOm/hYup6lRRRXnHQcqG+UfSgtUW7ikLV1JaGbeo8tXi2qeI7l9dOn6bEk8zTeUWl43OTgAcjHPc//r9jY5BFeBa1ZWw8RahbyS/YXjnYZnVmVuTlsqCwz8pAwRyeRxnkxc5QiuVnrZPh6VarL2ivZf1puzas9U1WTUX066s44rlo3aE4IUlQxJJydy/KeQe3equja5fatq9vZsLWJHJLuVb5UUFmI564Bx71V8Hz3a6jNGl1JFZLBJLcr5u1MBcAkHj7xUevNVfCsiReIoGkdUUxzKCxwMmJwB9SSB+Ncsa03y67v/I9ipgaMfbe4rqKa9fe+7Zaa/iWz4nu7e+aG6hgZI3KP5QIPBxxk1al1a7l1a1s7I2rpdlBC7hv4jt+bHTnPas+xs7PU9W1aOaVQWR2t3Dfx+YvT+98pbj0ye2ai0i0msvF2mQzLhheQ4PYjeOR7Ue2qpb6X3H9Twbl8KUlG9uj03+TPTtAkCvdQRvvjDZVsY3D1x2rYY1kaBEq2bTY+d2xn6Vpsa9uK0PjGNY0QH/S4f8AfX+dMY0W5/0uH/rov86uWzEtz1eiiivMOk4otzSFqjdvmP1rP1jUJdM0m5vYbb7S0CbzFvCZUfeOT6DJ/CutWUbszjFzkordmiWrn/EWmJdEXgtLWZo0wxmhSQhBk8bgcdWrA0z4gX2tXLW+n+HvOlVDIV+2quFBAzkqO5FaOkeMbfVLLUpr+2bT/sJCzLI24DOQOwO7IIxj065xWSr0aml/wO2eBxdC8mrNW2avrotE76mO0n+itapHFHbuSXhiiVEYnGchQAeg601DFDKksVnYpIhDKy2cQKkdCDt4Nc9c+J0VjJBYzNalisbyNt3YAJHAIyMjv3HrU9zr1tFZR3EYMpkOFToQR1z6Yz/nrWSq0HfVaGjwOPi0uV+95/nr+ZrRGO3x5NraRsFKB0tow2CMH5guehPekhO25hlSOJ5kb5C8auUOQcjIODwORXNHxV/05/8AkX/61bGj6zaPbyandkRJauAYwSzMSPlxwAScNx/sknA5qoVqEvdTCtl2Ph784vtvff0Z3NlbfYrRYd24jkmpGNcU/wAQ1SZN+lSrbucpIZMMybiNwGMHoeM9QRmust7uC9to7m2kWSGQZVl711Ua1Oo7QdzjxOCr4dJ1Y2T/AK6ErGi2P+mQf9dF/nUZNSWn/H5B/wBdF/nW8vhZyrc9aoooryzpPP5G/eN/vVl+IW/4pvVP+vSX/wBANX5W/fP/AL1U76zttSs5LS7j82CTG5NxGcEEcgg9QK7XFuDSIpyUakZS2TR4zoWm32qm/tbA5lNsCY/l/eKJI+MkjHOGz/s4713fjLTbpPAtjaInnNY+UZjHyAFjKsw7kZP5c1rW+geHtGukvIbRIJo87XMztjIIPBYjoTTLzxGoytomT/fb/CuKjg3GDU93oezjM4VSvCdJe7F310d9ujZ5lFewP4Vn0+TassVyLiPJOX3BVOBjHAX1/i6cVs+GbR00Wa6ubaN4nmUW32iNXU8N5hVWz3EYLY7YzxVyOx0uKVZTpNrJKH35cyYJznlQ23HtjFTz3Ek7KZCMIoRVVQqqo4AAHAHsKmlhJKSc7aFYzNqc6UoUE05O7v022+78zmbGR5vHltLIcu+pqzHHUmUVb8R2ZbTLa4gs4kjhdkleGFUxkLt3YAJ6Hk+vvV9dP0lUAOk27EDBYyzZPvw9WWunMkrqqKsud0ar8hB6jHp7UU8I+WUZ9R1s3gq1KpSv7qs09L/c2c5dX1pd+DbG3O1byynaMDccmN9zlsdMZwO+NvbNdp4Nt7q38MRG6WRfMld4Q5/5ZELggdgTuPvnPeqGnQeH4JUeXSIFkUYDOzyL0xkqzEH8q6oXK3RLrIshPVga2wuFnGopzeytoYZhmdKtRdGinZu+vTrp8xamtP8Aj8g/66L/ADqGprT/AI/IP+ui/wA69GXws8NbnrVFFFeUdR5hf3K23nzP91CTXIXGsXk7E+cUX+6nAFdR4h0vU5oJUh067kLS9EhY8Z69K5n/AIR7W/8AoD6h/wCAz/4V2cystTGzM8uWbJJJ96aTWj/wj2uf9AfUP/AZ/wDCkPh3Xf8AoD3/AP4DP/hRzLuOzM4mmk1pHw7rv/QGv/8AwGf/AApp8Oa7/wBAbUP/AAGf/ClzILMzCaaTWp/wjmuf9AbUP/AZ/wDCk/4RrXP+gNqH/gM/+FVzoVmZlAJVsqSD7da0/wDhGtc/6A2of+Az/wCFH/CNa5/0BtQ/8Bn/AMKfOgsyCHVbyFgfNLj+6/euq0udbmS1mTgM68enNc5/wjWu/wDQG1D/AMBn/wAK6Pw7o2qwLGJ9MvI9s2fngYcevSmpqz1Fyu57BRS4orgNz//Z";
		//						});
		//	    	}else
		//	    		$scope.fotoAsesor="data:image/png;base64," + "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABgAGEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2SKKEwRkxISVHO2gxQ/8APJP++aIm/cR/7ooLVokSyMxxf3F/KomSP+4v5VITUTGrSJImVf7o/KomA9KdLMkeN7quf7x61nz6vYwvse5TJ9Of5VVkDLLGoWY+tKJY5RlJFceoNMY1SSJuMZ2/vH86haV/77fnT2NQMatJE3EaaX/no/8A31TYp5TcRgyOQWA+9TGNNhP+lRf74puKswTdz1CikxRXAdBgxt+5T/doLVCjfu1/3aC1bpGbFLVQ1PUE0+1aZ+T0Vf7xq0WrivEd6bjUTD/BB8v1PensBl3E8txIZJnLuTnJqAmlJphNADoriW3k8yF2RvY9a6LS9bF1iG5IWb+FuzVzBNM3lGBBwQcg+lUnYTO9Y1ExqvYXgvLJJc5fGHHo1Ssa2RDGMabAf9Ki/wB8UjGkgP8ApUX++v8AOm/hYup6lRRRXnHQcqG+UfSgtUW7ikLV1JaGbeo8tXi2qeI7l9dOn6bEk8zTeUWl43OTgAcjHPc//r9jY5BFeBa1ZWw8RahbyS/YXjnYZnVmVuTlsqCwz8pAwRyeRxnkxc5QiuVnrZPh6VarL2ivZf1puzas9U1WTUX066s44rlo3aE4IUlQxJJydy/KeQe3equja5fatq9vZsLWJHJLuVb5UUFmI564Bx71V8Hz3a6jNGl1JFZLBJLcr5u1MBcAkHj7xUevNVfCsiReIoGkdUUxzKCxwMmJwB9SSB+Ncsa03y67v/I9ipgaMfbe4rqKa9fe+7Zaa/iWz4nu7e+aG6hgZI3KP5QIPBxxk1al1a7l1a1s7I2rpdlBC7hv4jt+bHTnPas+xs7PU9W1aOaVQWR2t3Dfx+YvT+98pbj0ye2ai0i0msvF2mQzLhheQ4PYjeOR7Ue2qpb6X3H9Twbl8KUlG9uj03+TPTtAkCvdQRvvjDZVsY3D1x2rYY1kaBEq2bTY+d2xn6Vpsa9uK0PjGNY0QH/S4f8AfX+dMY0W5/0uH/rov86uWzEtz1eiiivMOk4otzSFqjdvmP1rP1jUJdM0m5vYbb7S0CbzFvCZUfeOT6DJ/CutWUbszjFzkordmiWrn/EWmJdEXgtLWZo0wxmhSQhBk8bgcdWrA0z4gX2tXLW+n+HvOlVDIV+2quFBAzkqO5FaOkeMbfVLLUpr+2bT/sJCzLI24DOQOwO7IIxj065xWSr0aml/wO2eBxdC8mrNW2avrotE76mO0n+itapHFHbuSXhiiVEYnGchQAeg601DFDKksVnYpIhDKy2cQKkdCDt4Nc9c+J0VjJBYzNalisbyNt3YAJHAIyMjv3HrU9zr1tFZR3EYMpkOFToQR1z6Yz/nrWSq0HfVaGjwOPi0uV+95/nr+ZrRGO3x5NraRsFKB0tow2CMH5guehPekhO25hlSOJ5kb5C8auUOQcjIODwORXNHxV/05/8AkX/61bGj6zaPbyandkRJauAYwSzMSPlxwAScNx/sknA5qoVqEvdTCtl2Ph784vtvff0Z3NlbfYrRYd24jkmpGNcU/wAQ1SZN+lSrbucpIZMMybiNwGMHoeM9QRmust7uC9to7m2kWSGQZVl711Ua1Oo7QdzjxOCr4dJ1Y2T/AK6ErGi2P+mQf9dF/nUZNSWn/H5B/wBdF/nW8vhZyrc9aoooryzpPP5G/eN/vVl+IW/4pvVP+vSX/wBANX5W/fP/AL1U76zttSs5LS7j82CTG5NxGcEEcgg9QK7XFuDSIpyUakZS2TR4zoWm32qm/tbA5lNsCY/l/eKJI+MkjHOGz/s4713fjLTbpPAtjaInnNY+UZjHyAFjKsw7kZP5c1rW+geHtGukvIbRIJo87XMztjIIPBYjoTTLzxGoytomT/fb/CuKjg3GDU93oezjM4VSvCdJe7F310d9ujZ5lFewP4Vn0+TassVyLiPJOX3BVOBjHAX1/i6cVs+GbR00Wa6ubaN4nmUW32iNXU8N5hVWz3EYLY7YzxVyOx0uKVZTpNrJKH35cyYJznlQ23HtjFTz3Ek7KZCMIoRVVQqqo4AAHAHsKmlhJKSc7aFYzNqc6UoUE05O7v022+78zmbGR5vHltLIcu+pqzHHUmUVb8R2ZbTLa4gs4kjhdkleGFUxkLt3YAJ6Hk+vvV9dP0lUAOk27EDBYyzZPvw9WWunMkrqqKsud0ar8hB6jHp7UU8I+WUZ9R1s3gq1KpSv7qs09L/c2c5dX1pd+DbG3O1byynaMDccmN9zlsdMZwO+NvbNdp4Nt7q38MRG6WRfMld4Q5/5ZELggdgTuPvnPeqGnQeH4JUeXSIFkUYDOzyL0xkqzEH8q6oXK3RLrIshPVga2wuFnGopzeytoYZhmdKtRdGinZu+vTrp8xamtP8Aj8g/66L/ADqGprT/AI/IP+ui/wA69GXws8NbnrVFFFeUdR5hf3K23nzP91CTXIXGsXk7E+cUX+6nAFdR4h0vU5oJUh067kLS9EhY8Z69K5n/AIR7W/8AoD6h/wCAz/4V2cystTGzM8uWbJJJ96aTWj/wj2uf9AfUP/AZ/wDCkPh3Xf8AoD3/AP4DP/hRzLuOzM4mmk1pHw7rv/QGv/8AwGf/AApp8Oa7/wBAbUP/AAGf/ClzILMzCaaTWp/wjmuf9AbUP/AZ/wDCk/4RrXP+gNqH/gM/+FVzoVmZlAJVsqSD7da0/wDhGtc/6A2of+Az/wCFH/CNa5/0BtQ/8Bn/AMKfOgsyCHVbyFgfNLj+6/euq0udbmS1mTgM68enNc5/wjWu/wDQG1D/AMBn/wAK6Pw7o2qwLGJ9MvI9s2fngYcevSmpqz1Fyu57BRS4orgNz//Z";
		//	    }

		//	    temporal
		$scope.recuperaFoto = function() {
			$scope.resp.data.foto = $scope.resp.data.foto.replace(/\s/g, '');
			if ($scope.resp.data.foto != null && $scope.resp.data.foto != "") {
				var cuenta = {
					noCuenta : $scope.resp.data.foto
				};
				solicitudService.getFotoAsesor(cuenta).then(
					function(data) {
						if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
							$scope.respFoto = JSON.parse(data.data.respuesta);
							if ($scope.respFoto.codigo == 2)
								$scope.fotoAsesor = "data:image/png;base64," + $scope.respFoto.data;
							else
								$scope.fotoAsesor = "data:image/png;base64," + "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABgAGEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2SKKEwRkxISVHO2gxQ/8APJP++aIm/cR/7ooLVokSyMxxf3F/KomSP+4v5VITUTGrSJImVf7o/KomA9KdLMkeN7quf7x61nz6vYwvse5TJ9Of5VVkDLLGoWY+tKJY5RlJFceoNMY1SSJuMZ2/vH86haV/77fnT2NQMatJE3EaaX/no/8A31TYp5TcRgyOQWA+9TGNNhP+lRf74puKswTdz1CikxRXAdBgxt+5T/doLVCjfu1/3aC1bpGbFLVQ1PUE0+1aZ+T0Vf7xq0WrivEd6bjUTD/BB8v1PensBl3E8txIZJnLuTnJqAmlJphNADoriW3k8yF2RvY9a6LS9bF1iG5IWb+FuzVzBNM3lGBBwQcg+lUnYTO9Y1ExqvYXgvLJJc5fGHHo1Ssa2RDGMabAf9Ki/wB8UjGkgP8ApUX++v8AOm/hYup6lRRRXnHQcqG+UfSgtUW7ikLV1JaGbeo8tXi2qeI7l9dOn6bEk8zTeUWl43OTgAcjHPc//r9jY5BFeBa1ZWw8RahbyS/YXjnYZnVmVuTlsqCwz8pAwRyeRxnkxc5QiuVnrZPh6VarL2ivZf1puzas9U1WTUX066s44rlo3aE4IUlQxJJydy/KeQe3equja5fatq9vZsLWJHJLuVb5UUFmI564Bx71V8Hz3a6jNGl1JFZLBJLcr5u1MBcAkHj7xUevNVfCsiReIoGkdUUxzKCxwMmJwB9SSB+Ncsa03y67v/I9ipgaMfbe4rqKa9fe+7Zaa/iWz4nu7e+aG6hgZI3KP5QIPBxxk1al1a7l1a1s7I2rpdlBC7hv4jt+bHTnPas+xs7PU9W1aOaVQWR2t3Dfx+YvT+98pbj0ye2ai0i0msvF2mQzLhheQ4PYjeOR7Ue2qpb6X3H9Twbl8KUlG9uj03+TPTtAkCvdQRvvjDZVsY3D1x2rYY1kaBEq2bTY+d2xn6Vpsa9uK0PjGNY0QH/S4f8AfX+dMY0W5/0uH/rov86uWzEtz1eiiivMOk4otzSFqjdvmP1rP1jUJdM0m5vYbb7S0CbzFvCZUfeOT6DJ/CutWUbszjFzkordmiWrn/EWmJdEXgtLWZo0wxmhSQhBk8bgcdWrA0z4gX2tXLW+n+HvOlVDIV+2quFBAzkqO5FaOkeMbfVLLUpr+2bT/sJCzLI24DOQOwO7IIxj065xWSr0aml/wO2eBxdC8mrNW2avrotE76mO0n+itapHFHbuSXhiiVEYnGchQAeg601DFDKksVnYpIhDKy2cQKkdCDt4Nc9c+J0VjJBYzNalisbyNt3YAJHAIyMjv3HrU9zr1tFZR3EYMpkOFToQR1z6Yz/nrWSq0HfVaGjwOPi0uV+95/nr+ZrRGO3x5NraRsFKB0tow2CMH5guehPekhO25hlSOJ5kb5C8auUOQcjIODwORXNHxV/05/8AkX/61bGj6zaPbyandkRJauAYwSzMSPlxwAScNx/sknA5qoVqEvdTCtl2Ph784vtvff0Z3NlbfYrRYd24jkmpGNcU/wAQ1SZN+lSrbucpIZMMybiNwGMHoeM9QRmust7uC9to7m2kWSGQZVl711Ua1Oo7QdzjxOCr4dJ1Y2T/AK6ErGi2P+mQf9dF/nUZNSWn/H5B/wBdF/nW8vhZyrc9aoooryzpPP5G/eN/vVl+IW/4pvVP+vSX/wBANX5W/fP/AL1U76zttSs5LS7j82CTG5NxGcEEcgg9QK7XFuDSIpyUakZS2TR4zoWm32qm/tbA5lNsCY/l/eKJI+MkjHOGz/s4713fjLTbpPAtjaInnNY+UZjHyAFjKsw7kZP5c1rW+geHtGukvIbRIJo87XMztjIIPBYjoTTLzxGoytomT/fb/CuKjg3GDU93oezjM4VSvCdJe7F310d9ujZ5lFewP4Vn0+TassVyLiPJOX3BVOBjHAX1/i6cVs+GbR00Wa6ubaN4nmUW32iNXU8N5hVWz3EYLY7YzxVyOx0uKVZTpNrJKH35cyYJznlQ23HtjFTz3Ek7KZCMIoRVVQqqo4AAHAHsKmlhJKSc7aFYzNqc6UoUE05O7v022+78zmbGR5vHltLIcu+pqzHHUmUVb8R2ZbTLa4gs4kjhdkleGFUxkLt3YAJ6Hk+vvV9dP0lUAOk27EDBYyzZPvw9WWunMkrqqKsud0ar8hB6jHp7UU8I+WUZ9R1s3gq1KpSv7qs09L/c2c5dX1pd+DbG3O1byynaMDccmN9zlsdMZwO+NvbNdp4Nt7q38MRG6WRfMld4Q5/5ZELggdgTuPvnPeqGnQeH4JUeXSIFkUYDOzyL0xkqzEH8q6oXK3RLrIshPVga2wuFnGopzeytoYZhmdKtRdGinZu+vTrp8xamtP8Aj8g/66L/ADqGprT/AI/IP+ui/wA69GXws8NbnrVFFFeUdR5hf3K23nzP91CTXIXGsXk7E+cUX+6nAFdR4h0vU5oJUh067kLS9EhY8Z69K5n/AIR7W/8AoD6h/wCAz/4V2cystTGzM8uWbJJJ96aTWj/wj2uf9AfUP/AZ/wDCkPh3Xf8AoD3/AP4DP/hRzLuOzM4mmk1pHw7rv/QGv/8AwGf/AApp8Oa7/wBAbUP/AAGf/ClzILMzCaaTWp/wjmuf9AbUP/AZ/wDCk/4RrXP+gNqH/gM/+FVzoVmZlAJVsqSD7da0/wDhGtc/6A2of+Az/wCFH/CNa5/0BtQ/8Bn/AMKfOgsyCHVbyFgfNLj+6/euq0udbmS1mTgM68enNc5/wjWu/wDQG1D/AMBn/wAK6Pw7o2qwLGJ9MvI9s2fngYcevSmpqz1Fyu57BRS4orgNz//Z";
						} else
							$scope.fotoAsesor = "data:image/png;base64," + "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABgAGEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2SKKEwRkxISVHO2gxQ/8APJP++aIm/cR/7ooLVokSyMxxf3F/KomSP+4v5VITUTGrSJImVf7o/KomA9KdLMkeN7quf7x61nz6vYwvse5TJ9Of5VVkDLLGoWY+tKJY5RlJFceoNMY1SSJuMZ2/vH86haV/77fnT2NQMatJE3EaaX/no/8A31TYp5TcRgyOQWA+9TGNNhP+lRf74puKswTdz1CikxRXAdBgxt+5T/doLVCjfu1/3aC1bpGbFLVQ1PUE0+1aZ+T0Vf7xq0WrivEd6bjUTD/BB8v1PensBl3E8txIZJnLuTnJqAmlJphNADoriW3k8yF2RvY9a6LS9bF1iG5IWb+FuzVzBNM3lGBBwQcg+lUnYTO9Y1ExqvYXgvLJJc5fGHHo1Ssa2RDGMabAf9Ki/wB8UjGkgP8ApUX++v8AOm/hYup6lRRRXnHQcqG+UfSgtUW7ikLV1JaGbeo8tXi2qeI7l9dOn6bEk8zTeUWl43OTgAcjHPc//r9jY5BFeBa1ZWw8RahbyS/YXjnYZnVmVuTlsqCwz8pAwRyeRxnkxc5QiuVnrZPh6VarL2ivZf1puzas9U1WTUX066s44rlo3aE4IUlQxJJydy/KeQe3equja5fatq9vZsLWJHJLuVb5UUFmI564Bx71V8Hz3a6jNGl1JFZLBJLcr5u1MBcAkHj7xUevNVfCsiReIoGkdUUxzKCxwMmJwB9SSB+Ncsa03y67v/I9ipgaMfbe4rqKa9fe+7Zaa/iWz4nu7e+aG6hgZI3KP5QIPBxxk1al1a7l1a1s7I2rpdlBC7hv4jt+bHTnPas+xs7PU9W1aOaVQWR2t3Dfx+YvT+98pbj0ye2ai0i0msvF2mQzLhheQ4PYjeOR7Ue2qpb6X3H9Twbl8KUlG9uj03+TPTtAkCvdQRvvjDZVsY3D1x2rYY1kaBEq2bTY+d2xn6Vpsa9uK0PjGNY0QH/S4f8AfX+dMY0W5/0uH/rov86uWzEtz1eiiivMOk4otzSFqjdvmP1rP1jUJdM0m5vYbb7S0CbzFvCZUfeOT6DJ/CutWUbszjFzkordmiWrn/EWmJdEXgtLWZo0wxmhSQhBk8bgcdWrA0z4gX2tXLW+n+HvOlVDIV+2quFBAzkqO5FaOkeMbfVLLUpr+2bT/sJCzLI24DOQOwO7IIxj065xWSr0aml/wO2eBxdC8mrNW2avrotE76mO0n+itapHFHbuSXhiiVEYnGchQAeg601DFDKksVnYpIhDKy2cQKkdCDt4Nc9c+J0VjJBYzNalisbyNt3YAJHAIyMjv3HrU9zr1tFZR3EYMpkOFToQR1z6Yz/nrWSq0HfVaGjwOPi0uV+95/nr+ZrRGO3x5NraRsFKB0tow2CMH5guehPekhO25hlSOJ5kb5C8auUOQcjIODwORXNHxV/05/8AkX/61bGj6zaPbyandkRJauAYwSzMSPlxwAScNx/sknA5qoVqEvdTCtl2Ph784vtvff0Z3NlbfYrRYd24jkmpGNcU/wAQ1SZN+lSrbucpIZMMybiNwGMHoeM9QRmust7uC9to7m2kWSGQZVl711Ua1Oo7QdzjxOCr4dJ1Y2T/AK6ErGi2P+mQf9dF/nUZNSWn/H5B/wBdF/nW8vhZyrc9aoooryzpPP5G/eN/vVl+IW/4pvVP+vSX/wBANX5W/fP/AL1U76zttSs5LS7j82CTG5NxGcEEcgg9QK7XFuDSIpyUakZS2TR4zoWm32qm/tbA5lNsCY/l/eKJI+MkjHOGz/s4713fjLTbpPAtjaInnNY+UZjHyAFjKsw7kZP5c1rW+geHtGukvIbRIJo87XMztjIIPBYjoTTLzxGoytomT/fb/CuKjg3GDU93oezjM4VSvCdJe7F310d9ujZ5lFewP4Vn0+TassVyLiPJOX3BVOBjHAX1/i6cVs+GbR00Wa6ubaN4nmUW32iNXU8N5hVWz3EYLY7YzxVyOx0uKVZTpNrJKH35cyYJznlQ23HtjFTz3Ek7KZCMIoRVVQqqo4AAHAHsKmlhJKSc7aFYzNqc6UoUE05O7v022+78zmbGR5vHltLIcu+pqzHHUmUVb8R2ZbTLa4gs4kjhdkleGFUxkLt3YAJ6Hk+vvV9dP0lUAOk27EDBYyzZPvw9WWunMkrqqKsud0ar8hB6jHp7UU8I+WUZ9R1s3gq1KpSv7qs09L/c2c5dX1pd+DbG3O1byynaMDccmN9zlsdMZwO+NvbNdp4Nt7q38MRG6WRfMld4Q5/5ZELggdgTuPvnPeqGnQeH4JUeXSIFkUYDOzyL0xkqzEH8q6oXK3RLrIshPVga2wuFnGopzeytoYZhmdKtRdGinZu+vTrp8xamtP8Aj8g/66L/ADqGprT/AI/IP+ui/wA69GXws8NbnrVFFFeUdR5hf3K23nzP91CTXIXGsXk7E+cUX+6nAFdR4h0vU5oJUh067kLS9EhY8Z69K5n/AIR7W/8AoD6h/wCAz/4V2cystTGzM8uWbJJJ96aTWj/wj2uf9AfUP/AZ/wDCkPh3Xf8AoD3/AP4DP/hRzLuOzM4mmk1pHw7rv/QGv/8AwGf/AApp8Oa7/wBAbUP/AAGf/ClzILMzCaaTWp/wjmuf9AbUP/AZ/wDCk/4RrXP+gNqH/gM/+FVzoVmZlAJVsqSD7da0/wDhGtc/6A2of+Az/wCFH/CNa5/0BtQ/8Bn/AMKfOgsyCHVbyFgfNLj+6/euq0udbmS1mTgM68enNc5/wjWu/wDQG1D/AMBn/wAK6Pw7o2qwLGJ9MvI9s2fngYcevSmpqz1Fyu57BRS4orgNz//Z";
					}, function(error) {
						$scope.fotoAsesor = "data:image/png;base64," + "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABgAGEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2SKKEwRkxISVHO2gxQ/8APJP++aIm/cR/7ooLVokSyMxxf3F/KomSP+4v5VITUTGrSJImVf7o/KomA9KdLMkeN7quf7x61nz6vYwvse5TJ9Of5VVkDLLGoWY+tKJY5RlJFceoNMY1SSJuMZ2/vH86haV/77fnT2NQMatJE3EaaX/no/8A31TYp5TcRgyOQWA+9TGNNhP+lRf74puKswTdz1CikxRXAdBgxt+5T/doLVCjfu1/3aC1bpGbFLVQ1PUE0+1aZ+T0Vf7xq0WrivEd6bjUTD/BB8v1PensBl3E8txIZJnLuTnJqAmlJphNADoriW3k8yF2RvY9a6LS9bF1iG5IWb+FuzVzBNM3lGBBwQcg+lUnYTO9Y1ExqvYXgvLJJc5fGHHo1Ssa2RDGMabAf9Ki/wB8UjGkgP8ApUX++v8AOm/hYup6lRRRXnHQcqG+UfSgtUW7ikLV1JaGbeo8tXi2qeI7l9dOn6bEk8zTeUWl43OTgAcjHPc//r9jY5BFeBa1ZWw8RahbyS/YXjnYZnVmVuTlsqCwz8pAwRyeRxnkxc5QiuVnrZPh6VarL2ivZf1puzas9U1WTUX066s44rlo3aE4IUlQxJJydy/KeQe3equja5fatq9vZsLWJHJLuVb5UUFmI564Bx71V8Hz3a6jNGl1JFZLBJLcr5u1MBcAkHj7xUevNVfCsiReIoGkdUUxzKCxwMmJwB9SSB+Ncsa03y67v/I9ipgaMfbe4rqKa9fe+7Zaa/iWz4nu7e+aG6hgZI3KP5QIPBxxk1al1a7l1a1s7I2rpdlBC7hv4jt+bHTnPas+xs7PU9W1aOaVQWR2t3Dfx+YvT+98pbj0ye2ai0i0msvF2mQzLhheQ4PYjeOR7Ue2qpb6X3H9Twbl8KUlG9uj03+TPTtAkCvdQRvvjDZVsY3D1x2rYY1kaBEq2bTY+d2xn6Vpsa9uK0PjGNY0QH/S4f8AfX+dMY0W5/0uH/rov86uWzEtz1eiiivMOk4otzSFqjdvmP1rP1jUJdM0m5vYbb7S0CbzFvCZUfeOT6DJ/CutWUbszjFzkordmiWrn/EWmJdEXgtLWZo0wxmhSQhBk8bgcdWrA0z4gX2tXLW+n+HvOlVDIV+2quFBAzkqO5FaOkeMbfVLLUpr+2bT/sJCzLI24DOQOwO7IIxj065xWSr0aml/wO2eBxdC8mrNW2avrotE76mO0n+itapHFHbuSXhiiVEYnGchQAeg601DFDKksVnYpIhDKy2cQKkdCDt4Nc9c+J0VjJBYzNalisbyNt3YAJHAIyMjv3HrU9zr1tFZR3EYMpkOFToQR1z6Yz/nrWSq0HfVaGjwOPi0uV+95/nr+ZrRGO3x5NraRsFKB0tow2CMH5guehPekhO25hlSOJ5kb5C8auUOQcjIODwORXNHxV/05/8AkX/61bGj6zaPbyandkRJauAYwSzMSPlxwAScNx/sknA5qoVqEvdTCtl2Ph784vtvff0Z3NlbfYrRYd24jkmpGNcU/wAQ1SZN+lSrbucpIZMMybiNwGMHoeM9QRmust7uC9to7m2kWSGQZVl711Ua1Oo7QdzjxOCr4dJ1Y2T/AK6ErGi2P+mQf9dF/nUZNSWn/H5B/wBdF/nW8vhZyrc9aoooryzpPP5G/eN/vVl+IW/4pvVP+vSX/wBANX5W/fP/AL1U76zttSs5LS7j82CTG5NxGcEEcgg9QK7XFuDSIpyUakZS2TR4zoWm32qm/tbA5lNsCY/l/eKJI+MkjHOGz/s4713fjLTbpPAtjaInnNY+UZjHyAFjKsw7kZP5c1rW+geHtGukvIbRIJo87XMztjIIPBYjoTTLzxGoytomT/fb/CuKjg3GDU93oezjM4VSvCdJe7F310d9ujZ5lFewP4Vn0+TassVyLiPJOX3BVOBjHAX1/i6cVs+GbR00Wa6ubaN4nmUW32iNXU8N5hVWz3EYLY7YzxVyOx0uKVZTpNrJKH35cyYJznlQ23HtjFTz3Ek7KZCMIoRVVQqqo4AAHAHsKmlhJKSc7aFYzNqc6UoUE05O7v022+78zmbGR5vHltLIcu+pqzHHUmUVb8R2ZbTLa4gs4kjhdkleGFUxkLt3YAJ6Hk+vvV9dP0lUAOk27EDBYyzZPvw9WWunMkrqqKsud0ar8hB6jHp7UU8I+WUZ9R1s3gq1KpSv7qs09L/c2c5dX1pd+DbG3O1byynaMDccmN9zlsdMZwO+NvbNdp4Nt7q38MRG6WRfMld4Q5/5ZELggdgTuPvnPeqGnQeH4JUeXSIFkUYDOzyL0xkqzEH8q6oXK3RLrIshPVga2wuFnGopzeytoYZhmdKtRdGinZu+vTrp8xamtP8Aj8g/66L/ADqGprT/AI/IP+ui/wA69GXws8NbnrVFFFeUdR5hf3K23nzP91CTXIXGsXk7E+cUX+6nAFdR4h0vU5oJUh067kLS9EhY8Z69K5n/AIR7W/8AoD6h/wCAz/4V2cystTGzM8uWbJJJ96aTWj/wj2uf9AfUP/AZ/wDCkPh3Xf8AoD3/AP4DP/hRzLuOzM4mmk1pHw7rv/QGv/8AwGf/AApp8Oa7/wBAbUP/AAGf/ClzILMzCaaTWp/wjmuf9AbUP/AZ/wDCk/4RrXP+gNqH/gM/+FVzoVmZlAJVsqSD7da0/wDhGtc/6A2of+Az/wCFH/CNa5/0BtQ/8Bn/AMKfOgsyCHVbyFgfNLj+6/euq0udbmS1mTgM68enNc5/wjWu/wDQG1D/AMBn/wAK6Pw7o2qwLGJ9MvI9s2fngYcevSmpqz1Fyu57BRS4orgNz//Z";
					});
			} else
				$scope.fotoAsesor = "data:image/png;base64," + "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABgAGEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD2SKKEwRkxISVHO2gxQ/8APJP++aIm/cR/7ooLVokSyMxxf3F/KomSP+4v5VITUTGrSJImVf7o/KomA9KdLMkeN7quf7x61nz6vYwvse5TJ9Of5VVkDLLGoWY+tKJY5RlJFceoNMY1SSJuMZ2/vH86haV/77fnT2NQMatJE3EaaX/no/8A31TYp5TcRgyOQWA+9TGNNhP+lRf74puKswTdz1CikxRXAdBgxt+5T/doLVCjfu1/3aC1bpGbFLVQ1PUE0+1aZ+T0Vf7xq0WrivEd6bjUTD/BB8v1PensBl3E8txIZJnLuTnJqAmlJphNADoriW3k8yF2RvY9a6LS9bF1iG5IWb+FuzVzBNM3lGBBwQcg+lUnYTO9Y1ExqvYXgvLJJc5fGHHo1Ssa2RDGMabAf9Ki/wB8UjGkgP8ApUX++v8AOm/hYup6lRRRXnHQcqG+UfSgtUW7ikLV1JaGbeo8tXi2qeI7l9dOn6bEk8zTeUWl43OTgAcjHPc//r9jY5BFeBa1ZWw8RahbyS/YXjnYZnVmVuTlsqCwz8pAwRyeRxnkxc5QiuVnrZPh6VarL2ivZf1puzas9U1WTUX066s44rlo3aE4IUlQxJJydy/KeQe3equja5fatq9vZsLWJHJLuVb5UUFmI564Bx71V8Hz3a6jNGl1JFZLBJLcr5u1MBcAkHj7xUevNVfCsiReIoGkdUUxzKCxwMmJwB9SSB+Ncsa03y67v/I9ipgaMfbe4rqKa9fe+7Zaa/iWz4nu7e+aG6hgZI3KP5QIPBxxk1al1a7l1a1s7I2rpdlBC7hv4jt+bHTnPas+xs7PU9W1aOaVQWR2t3Dfx+YvT+98pbj0ye2ai0i0msvF2mQzLhheQ4PYjeOR7Ue2qpb6X3H9Twbl8KUlG9uj03+TPTtAkCvdQRvvjDZVsY3D1x2rYY1kaBEq2bTY+d2xn6Vpsa9uK0PjGNY0QH/S4f8AfX+dMY0W5/0uH/rov86uWzEtz1eiiivMOk4otzSFqjdvmP1rP1jUJdM0m5vYbb7S0CbzFvCZUfeOT6DJ/CutWUbszjFzkordmiWrn/EWmJdEXgtLWZo0wxmhSQhBk8bgcdWrA0z4gX2tXLW+n+HvOlVDIV+2quFBAzkqO5FaOkeMbfVLLUpr+2bT/sJCzLI24DOQOwO7IIxj065xWSr0aml/wO2eBxdC8mrNW2avrotE76mO0n+itapHFHbuSXhiiVEYnGchQAeg601DFDKksVnYpIhDKy2cQKkdCDt4Nc9c+J0VjJBYzNalisbyNt3YAJHAIyMjv3HrU9zr1tFZR3EYMpkOFToQR1z6Yz/nrWSq0HfVaGjwOPi0uV+95/nr+ZrRGO3x5NraRsFKB0tow2CMH5guehPekhO25hlSOJ5kb5C8auUOQcjIODwORXNHxV/05/8AkX/61bGj6zaPbyandkRJauAYwSzMSPlxwAScNx/sknA5qoVqEvdTCtl2Ph784vtvff0Z3NlbfYrRYd24jkmpGNcU/wAQ1SZN+lSrbucpIZMMybiNwGMHoeM9QRmust7uC9to7m2kWSGQZVl711Ua1Oo7QdzjxOCr4dJ1Y2T/AK6ErGi2P+mQf9dF/nUZNSWn/H5B/wBdF/nW8vhZyrc9aoooryzpPP5G/eN/vVl+IW/4pvVP+vSX/wBANX5W/fP/AL1U76zttSs5LS7j82CTG5NxGcEEcgg9QK7XFuDSIpyUakZS2TR4zoWm32qm/tbA5lNsCY/l/eKJI+MkjHOGz/s4713fjLTbpPAtjaInnNY+UZjHyAFjKsw7kZP5c1rW+geHtGukvIbRIJo87XMztjIIPBYjoTTLzxGoytomT/fb/CuKjg3GDU93oezjM4VSvCdJe7F310d9ujZ5lFewP4Vn0+TassVyLiPJOX3BVOBjHAX1/i6cVs+GbR00Wa6ubaN4nmUW32iNXU8N5hVWz3EYLY7YzxVyOx0uKVZTpNrJKH35cyYJznlQ23HtjFTz3Ek7KZCMIoRVVQqqo4AAHAHsKmlhJKSc7aFYzNqc6UoUE05O7v022+78zmbGR5vHltLIcu+pqzHHUmUVb8R2ZbTLa4gs4kjhdkleGFUxkLt3YAJ6Hk+vvV9dP0lUAOk27EDBYyzZPvw9WWunMkrqqKsud0ar8hB6jHp7UU8I+WUZ9R1s3gq1KpSv7qs09L/c2c5dX1pd+DbG3O1byynaMDccmN9zlsdMZwO+NvbNdp4Nt7q38MRG6WRfMld4Q5/5ZELggdgTuPvnPeqGnQeH4JUeXSIFkUYDOzyL0xkqzEH8q6oXK3RLrIshPVga2wuFnGopzeytoYZhmdKtRdGinZu+vTrp8xamtP8Aj8g/66L/ADqGprT/AI/IP+ui/wA69GXws8NbnrVFFFeUdR5hf3K23nzP91CTXIXGsXk7E+cUX+6nAFdR4h0vU5oJUh067kLS9EhY8Z69K5n/AIR7W/8AoD6h/wCAz/4V2cystTGzM8uWbJJJ96aTWj/wj2uf9AfUP/AZ/wDCkPh3Xf8AoD3/AP4DP/hRzLuOzM4mmk1pHw7rv/QGv/8AwGf/AApp8Oa7/wBAbUP/AAGf/ClzILMzCaaTWp/wjmuf9AbUP/AZ/wDCk/4RrXP+gNqH/gM/+FVzoVmZlAJVsqSD7da0/wDhGtc/6A2of+Az/wCFH/CNa5/0BtQ/8Bn/AMKfOgsyCHVbyFgfNLj+6/euq0udbmS1mTgM68enNc5/wjWu/wDQG1D/AMBn/wAK6Pw7o2qwLGJ9MvI9s2fngYcevSmpqz1Fyu57BRS4orgNz//Z";
		}

		//	    $scope.cargaRespuesta = function(){
		//	    	var dd="";
		//	    	var ddSemana = 0;
		//	    	var ok=null;
		//	    	$scope.idAsesor = $scope.resp.data.noEmpleado;
		//	    	$scope.nombreAsesor = $scope.resp.data.nombre;
		//	    	$scope.fotoAsesor = "data:image/png;base64," + $scope.resp.data.foto;
		//	    	for (var i=1; i < 8; i++){
		//	    		if ($scope.resp.data.díaDescanso == $scope.textoDias[i-1].toUpperCase())
		//	    			var diaDescanso = i;
		//	    	}
		//	    	var fechaServicio = $scope.resp.data.fechaVisita;
		//	    	var periodoCita = 1;
		//
		//	    	var fechaCita = fechaServicio.substr(3,2)+ "/" + fechaServicio.substr(0,2) + "/" + fechaServicio.substr(6,4);
		//	    	var fechaDia = new Date(fechaCita);
		//	    	dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
		//	    	ddSemana = fechaDia.getDay();
		//	    	$scope.textoDia = $scope.textoDias[ddSemana];
		//	    	$scope.numDia = dd;
		//	    	ok = true;
		//    		for(var a = 0; ok ; a++){
		//    			if (a == fechaDia.getMonth()){
		//    				$scope.textoMes = $scope.meses[a];
		//    				ok = false;
		//    			}
		//    		}
		//    		ok = true
		//    		for (i = 0; ok ;i++){
		//    			if (periodos[i].id == periodoCita){
		//    				$scope.textoPeriodo = periodos[i].descripcion;
		//    				ok = false;
		//    			}
		//    		}
		//	    	for(var i = 1; i < 6; i++){
		//	    		fechaDia.setDate(fechaDia.getDate() + 1);
		//	    		if (fechaDia.getDay() == diaDescanso)
		//	    			i--;
		//	    		else{
		//		    		dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
		//		    		var textoMesArray = "";
		//		    		ok = true;
		//		    		for(var a = 0; ok ; a++){
		//		    			if (a == fechaDia.getMonth()){
		//		    				textoMesArray = $scope.meses[a];
		//		    				ok = false;
		//		    			}
		//		    		}
		//		            var descripcion = dd + " de " + textoMesArray;
		//		            var mm = ((fechaDia.getMonth() + 1) < 10 ? '0' : '') + (fechaDia.getMonth() + 1);
		//		    		$scope.dias.push({id:i,descripcion:descripcion,fecha:dd + "/" + mm + "/" + fechaDia.getFullYear()});
		//	    		}
		//	    	}
		//
		//	    };

		//SERVICIO
		$scope.enviaCita = function() {
			
			/*\Se agrega un evento para la bitacora\*/
//			(Generar Cita / Cita de verificación)
			$rootScope.addEvent( BITACORA.SECCION.citaDeVerificacion.id, BITACORA.SUBSECCION.proceso.id, BITACORA.ACCION.aceptar.id, 0, BITACORA.SECCION.citaDeVerificacion.guardarEnBD );
			/*\Se agrega un evento para la bitacora\*/
			
			//Se mandan a BD los eventos almacenados en memoria
			$rootScope.enviaEventos();
			
			$rootScope.waitLoaderStatus = LOADER_SHOW;

			var visita = generalService.whichOneVisit(0);
			
			if((!$rootScope.productosTarjetas( $rootScope.solicitudJson.idProducto ) && visita == "/visitaAsesor") || ($rootScope.validaPreAprobados() && color == COLORES_EVALUACION_CTE.VERDE)){
				if ($rootScope.solicitudJson.idPlataforma == 6) {
					$scope.guardarHoraLlamadaBazDigital();
				} else {
					$scope.guardarHoraLlamada();
				}
			} else {
				$scope.guardaCita();
			}			
		};

		$scope.guardaCita = function() {
			
			var fechaCita = reverseDate($scope.selectedDate.fecha, "-");
		
			if(fechaCita != "" && $scope.visitIdPeriod != null) {
				
				if ($rootScope.solicitudJson.idPlataforma == 6) {
					
					var x = {
						idSolicitud : $rootScope.solicitudJson.idSolicitud,
						fecha : fechaCita.replace(/-/g, '\/'),
						periodo : $scope.visitIdPeriod,
						empleado : $scope.jvcEmployeeNumber,
						idEmpleado : $rootScope.userSession.noEmpleado,
						ip : $rootScope.solicitudJson.direccionIp
					}
					bazDigitalService.agendarCita(x).then(
						function(data) {
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
								$scope.resp = JSON.parse(data.data.respuesta);
								if ($scope.resp.codigo == 2) {
									$rootScope.solicitudJson = $scope.resp.data;
									if ($rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.tazEntregada)
										$scope.recuperaTAZ();
									else
										$scope.dispersarCallCenter();
								}else if($scope.resp.codigo == TARJETA_FOLIO_EN_PROCESO){
									$rootScope.message("Visita Asesor", ["Codigo : "+$scope.resp.codigo, "Aviso: La solicitud esta siendo procesada. Por favor, espere un momento"],"Aceptar",null,"bgAzul", "bgAzul");
								}else
									$rootScope.message("Visita Asesor", [ "Ocurrio un problema con el servicio Baz Digital agendar cita." ], "Aceptar", $scope.pathInicial);
							} else
								$rootScope.message("ERROR", [ generalService.displayMessage(data.data.descripcion) ], "Aceptar", $scope.pathInicial);
						}, function(error) {
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							generalService.locationPath($scope.pathInicial);
						});
					
				} else {
					
					// Se prepara un JSON de entrada.					
					var x = {
							idSolicitud: $rootScope.solicitudJson.idSolicitud,
							idUsuario: $rootScope.solicitudJson.cotizacion.clientes[0].idPersona,
							fecha: fechaCita.replace(/-/g, '\/'),							
							periodo: ($scope.tipoEmpleado == 1) ? $scope.visitIdPeriod : $scope.visitTime,
							empleado: $scope.jvcEmployeeNumber, 
							idEmpleado: $rootScope.userSession.noEmpleado,
							ip: $rootScope.solicitudJson.direccionIp
						};
					// Oh, hello Spinner!
					$rootScope.waitLoaderStatus = LOADER_SHOW;	
					
					// Se procede con el consumo.
					solicitudService.agendaCita(x).then(
						function(exito) {
							// Bye, bye Spinner!
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							
							// ¿Todo olrait (bridges level)?
							if(exito.data.codigo == RESPONSE_CODIGO_EXITO) {
								var response = JSON.parse(exito.data.respuesta);
								
								// ¿Todo olrait (a nivel de respuesta de consumo)?
								if(response.codigo == 2) {
									// ¿Seguro que fue un exitaso?
									if(response.data.flujoSolicitudADN != 99) {
										$rootScope.message("¡Aviso!", 
											["No se consiguió bajar a Tienda de manera correcta."],
											"Aceptar", null
										);
									} else {
										// Se actualiza el JSON de la solicitud.
										$rootScope.solicitudJson = response.data;
										//Se lanza el servicio para solicitar la visita	
										$scope.solicitarVisitaJVC();
										
										if (configuracion.estatus.opcion == 0) {
											if ($rootScope.solicitudJson.creditoInmediato == 1)
												$rootScope.solicitudJson.idSeguimiento = STATUS_SOLICITUD.preautorizada.id;

											generalService.locationPath(generalService.getPathSection($rootScope.solicitudJson, $rootScope.sucursalSession.idCanal));
										} else {
											configuracion.nuevoCredito.opcion = 0;
											window.routes["/nuevoCredito"].requireLogin = false;
											generalService.locationPath("/nuevoCredito");
										}
									}
								} else if(response.codigo == TARJETA_FOLIO_EN_PROCESO) {
									// Ya existe una transacción en proceso, para esta solicitud.
									$rootScope.message("Visita Asesor", 
										["Codigo : " + response.codigo, "Aviso: La solicitud está siendo procesada." 
											+ "Por favor, espere un momento"],
										"Aceptar", null
									);
								} else {
									$rootScope.message("Visita Asesor [" + response.codigo + "]", 
										["Ocurrió un problema con el servicio Agendar Cita."], 
										"Aceptar", "/simulador"
									);
								}
							} else {
								$rootScope.message("ERROR", 
									[generalService.displayMessage(exito.data.descripcion)], 
									"Aceptar", "/simulador"
								);
							}
						}, function(error) {
							// Bye, bye Spinner!
							$rootScope.waitLoaderStatus = LOADER_HIDE;
							
							$rootScope.message("Visita Asesor [" + response.codigo + "]", 
								["No se pudo realizar el guardado de la cita."], 
								"Aceptar", "/simulador"
							);
						}
					);
					
				}
				
			} else {
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				$rootScope.message("Error", [ "Fecha de cita invalida" ], "Aceptar", null, "bgRojo", "rojo");
			}
		};
		
		$scope.solicitarVisitaJVC = function() {
			//Formato para JVC: yyyy-mm-dd , Formato para JP: yyyy-mm-dd 00:00
			var citaJvJp = "";
			if($scope.tipoEmpleado == 1)
				citaJvJp = $rootScope.solicitudJson.fechaCita.split("/").reverse().join("-");
			else
				citaJvJp = $rootScope.solicitudJson.fechaCita.split("/").reverse().join("-") + " " + $scope.selectedPeriod.periodo.substring(0,5);
			
			// Parámetros de entrada.
			var jsonJVC = {
				"pais": $rootScope.solicitudJson.idPais,
				"canal": $rootScope.solicitudJson.idCanal,
				"sucursal": $rootScope.solicitudJson.idSucursal,
				"idSolicitud": $rootScope.solicitudJson.idSolicitudTienda,
				"numEmpleado": $scope.jvcEmployeeNumber,
				"idCitaJvc": parseInt($rootScope.solicitudJson.idCitaJVC),
				"fechaCita": citaJvJp,
				"cveHorario": $scope.visitIdPeriod,
				"tipoCita": 1,
				"statusCita": 1,
				"tipoPersona": 1,
				"folioCaptacion": ""
			};
			
			solicitudService.solicitarVisitaAsesor(jsonJVC).then(
				function(data,status) {
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
							$scope.resp = JSON.parse(data.data.respuesta);
					} 
					else
						$rootScope.message("ERROR", [ generalService.displayMessage(data.data.descripcion) ], "Aceptar", $scope.pathInicial);
				}, 
				function(error) {
					console.log("Error al intentar consumir el servicio de SolicitarVisitaAsesor.");
				}
			);
		};

		$scope.recuperaTAZ = function() {
			$scope.tarjetaNueva = {};
			$scope.tarjetaNueva = {
				valor : ""
			};
			var r = {
				idSolicitud : $rootScope.solicitudJson.idSolicitud,
				tipoTarjeta : 42
			};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			solicitudService.buscaTarjeta(r).then(
				function(data) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						var jResponse = JSON.parse(data.data.respuesta);
						if (jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO) {
							$scope.tarjetaNueva.valor = jResponse.respuesta;
							$scope.activaTaz();
						} else
							generalService.locationPath("/estatus");
					} else
						generalService.locationPath("/estatus");
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.locationPath($scope.pathInicial);

				});
		};

		$scope.activaTaz = function() {
			var cu = $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico;
			var cuArray = cu.split('-');
			var request = {
				idSolicitud : $rootScope.solicitudJson.idSolicitud,
				cu : {
					pais : parseInt(cuArray[0]),
					canal : parseInt(cuArray[1]),
					sucursal : parseInt(cuArray[2]),
					folio : parseInt(cuArray[3])
				},
				numCteAlnova : $rootScope.solicitudJson.cotizacion.clientes[0].clienteAlnova,
				numTaz : $scope.tarjetaNueva.valor,
				nip : ""
			};
			$rootScope.waitLoaderStatus = LOADER_SHOW;
			tarjetaService.activaTazInstantanea(request).then(
				function(data) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
						$scope.respuetaActivacion(data.data.respuesta, request);
					} else
						generalService.locationPath("/estatus");
				}, function(error) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.locationPath($scope.pathInicial);
				});
		};

		$scope.respuetaActivacion = function(jresponse, request) {
			jresponse.jsonResponseLCR = JSON.parse(jresponse.jsonResponseLCR);
			if (jresponse.jsonResponseLCR.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO) {
				jresponse.jsonResponseActivacion = JSON.parse(jresponse.jsonResponseActivacion);
				try {
					if (jresponse.jsonResponseActivacion.codigo == RESPONSE_TARJETA_CODIGO_EXITO) {
						jresponse.jsonResponseUpdStatus = JSON.parse(jresponse.jsonResponseUpdStatus);
						if (jresponse.jsonResponseUpdStatus.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO)
							$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.tazActivada;
						$scope.dispersarCallCenter();

					//						var flujoPorCanal = $scope.verificarCanal();
					//						if(jresponse.jsonResponseUpdStatus.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO){
					//							$rootScope.solicitudJson.marca = STATUS_SOLICITUD.autorizada.marca.tazActivada;
					//							if( request.nip!=undefined  &&  !generalService.isEmpty(request.nip) ){
					//								jresponse.jsonResponseNIP = JSON.parse(jresponse.jsonResponseNIP);
					//								if(jresponse.jsonResponseNIP.codigo != RESPONSE_TARJETA_CODIGO_EXITO)
					//									$rootScope.message("NIP", ["La tarjeta fue activada exitosamente pero hubo un error al registrar el NIP, coméntale al cliente que " +
					//									                           "lo puede registrar posteriormente."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
					//								else{
					//									$scope.capacidadPago = ($rootScope.solicitudJson.banderaIngresos == 1 || $rootScope.solicitudJson.banderaSolidario == 1)? $rootScope.solicitudJson.capacidadPagoComprobable : $rootScope.solicitudJson.capacidadPagoNoComprobable;
					//									$scope.disponible = $scope.capacidadPago - $rootScope.solicitudJson.cotizacion.pagoNormal;
					//									if ($scope.disponible <= 0)
					//										$rootScope.message("Confirmación", ["Infórmale a tu cliente que esta tarjeta la podrá ocupar una vez que surta su primer pedido."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
					//									else
					//										$rootScope.message("Confirmación", ["Tarjeta activada exitosamente."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
					//								}
					//							}else{
					//								$scope.capacidadPago = ($rootScope.solicitudJson.banderaIngresos == 1 || $rootScope.solicitudJson.banderaSolidario == 1)? $rootScope.solicitudJson.capacidadPagoComprobable : $rootScope.solicitudJson.capacidadPagoNoComprobable;
					//								$scope.disponible = $scope.capacidadPago - $rootScope.solicitudJson.cotizacion.pagoNormal;
					//								if ($scope.disponible <= 0)
					//									$rootScope.message("Confirmación", ["Infórmale a tu cliente que esta tarjeta la podrá ocupar una vez que surta su primer pedido."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
					//								else
					//									$rootScope.message("Confirmación", ["Tarjeta activada exitosamente."], "Aceptar", flujoPorCanal, "bgCafeZ", "cafeZ");
					//							}
					//						}else
					//							$rootScope.message("Actualizar Estatus", ["Codigo de error "+jresponse.jsonResponseUpdStatus.codigo, ERROR_SERVICE], "Aceptar", null, "bgCafeZ", "cafeZ");
					} else {
						var respuestaAln = $scope.manejoErrorAlnova(jresponse.jsonResponseActivacion.data.descriptionCode);
						if (respuestaAln) {
							$rootScope.message("Activar Tarjeta", [ respuestaAln ], "Aceptar");
						} else {
							if (jresponse.jsonResponseActivacion.data.descriptionCode) {
								$rootScope.message("Activar Tarjeta", [ "Codigo de error " + jresponse.jsonResponseActivacion.codigo, jresponse.jsonResponseActivacion.data.descriptionCode ], "Aceptar");
							} else {
								$rootScope.message("Activar Tarjeta", [ "Error al intentar activar tarjeta" ], "Aceptar");
								solicitudService.loggerFront(jresponse).then(
									function(data) {
										$rootScope.waitLoaderStatus = LOADER_HIDE;
									}, function(error) {
										$rootScope.waitLoaderStatus = LOADER_HIDE;
										generalService.locationPath($scope.pathInicial);
									}
								);
							}
						}
					}
				} catch (e) {
					$rootScope.message("Activar Tarjeta", [ "Error " + e.message ], "Aceptar");
				}
			} else {
				if (jresponse.jsonResponseLCR.codigo == 401) {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					generalService.cleanRootScope($rootScope);
					generalService.buildSolicitudJson($rootScope, null);
					$rootScope.message("LCR", [ "Esta solicitud de Línea de Crédito no se encuentra autorizada, por lo cual, no es posible continuar con el proceso." ], "Aceptar", $scope.pathInicial);
				} else {
					$rootScope.waitLoaderStatus = LOADER_HIDE;
					$rootScope.message("LCR", [ "Codigo de error " + jresponse.jsonResponseLCR.codigo, ERROR_SERVICE ], "Aceptar");
				}
			}
		};

		$scope.dispersarCallCenter = function() {
			$rootScope.waitLoaderStatus = LOADER_SHOW;

			if (generalService.isBazDigital()) {
				var request = {
					idSolicitud : $rootScope.solicitudJson.idSolicitud,
					tipoPeticion : 1,
					idPlataforma : PLATAFORMA.BAZDIGITAL
				};

				callCenterService.dispersarTarjetas(request).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if (data.data.codigo == RESPONSE_CODIGO_EXITO) {
							var jResponse = JSON.parse(data.data.respuesta);

							if (jResponse.codigo == RESPONSE_ORIGINACION_CODIGO_EXITO) {
								generalService.setDataBridge({
									origen : FICHA.origen.recuperar
								});
								generalService.locationPath("/ficha");
							} else
								$rootScope.message("Dispersar CallCenter ", [ jResponse.descripcion, "Codigo de error " + jResponse.codigo ], "Aceptar");

						} else
							$rootScope.message("Dispersar CallCenter", [ generalService.displayMessage(data.data.descripcion) ], "Aceptar");


					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;

					}
				);

			} else {
				solicitudService.dispersionTarjeta({
					idSolicitud : $rootScope.solicitudJson.idSolicitud
				}).then(
					function(data) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						//		 					if(data.data.codigo == RESPONSE_CODIGO_EXITO)
						generalService.locationPath("/estatus");
					//		 					else
					//		 						$rootScope.message("Dispersar CallCenter",[ "Favor de intentarlo más tarde" ],"Aceptar");
					}, function(error) {
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						generalService.locationPath($scope.pathInicial);
					}
				);
			}


		};
		
		/**
		 * Función listener para el check de mostrar más días.
		 */
		$scope.showMoreDays = function() {
			
			if($scope.comboCompleto != undefined){
				
				if($scope.combos.length > 3)
					$scope.combos = $scope.combos.slice(0,3);
				else		
					$scope.combos = $scope.comboCompleto;
				
				// Se reconfiguran las opciones seleccionadas.
				if($scope.combos.length > 0) {
					$scope.visitDate = getPrettyFormatDate($scope.combos[0].fecha, false, false);
					$scope.visitTime = $scope.combos[0].periodos[0].periodo;
					
					$scope.selectedDate = $scope.combos[0];
					$scope.selectedPeriod = $scope.combos[0].periodos[0];
				} else {
					$scope.visitDate = "";
					$scope.visitTime = "";
					
					$scope.selectedDate = null;
					$scope.selectedPeriod = null;
				}
				
				// Que surtan efecto los cambios realizados.
				$scope.$apply();
				
			}
		};
		
		function getHTMLtemplate() {
			
			var getDate = new Date();
			var getFormatDate = getDate.toLocaleDateString();
			var splitDate = getFormatDate.split("/");
			var concatDate = splitDate[2] + "-" + splitDate[1] + "-" + splitDate[0];
			
			$scope.diaLlamada = getPrettyFormatDate(concatDate, false, false);
			$scope.nomCliente = $rootScope.solicitudJson.cotizacion.clientes[0].nombre;
			$scope.sucursal = $rootScope.solicitudJson.idSucursal;
			$scope.cu = $rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico;
			
			var template = "";
			
			template = "<?xml version='1.0'?> <!DOCTYPE html> <html> <head> <title>Modelo de Originación de Crédito" +
			"</title> <meta http-equiv='Content-Type' content='text/html; charset=ISO-8859-1' /><style>.estilo{" +
			"margin-left:25%;}.visitaAsesor{text-align: center;}.carta {width: 175mm; height: 245mm; padding: 10px;" +
			"position: absolute; border: solid 1px; border-color:#0F0BCE; }.circulo-verde {text-align: center;" + 
			"align-items: center;align-content: center;justify-content: center;background-color: #10A0A0;border-radius: 15px;" +
			"color: white;font-weight: bold;width: 27px;height: 27px; margin: 10px; line-height: 27px;}.punto-importante {" +
			"text-align: justify; vertical-align: middle;padding-bottom: 0; }.ul {list-style-type: circle;margin-left: -20px;}" +
			"</style></head><body class='carta'> <div class='content clearfix'><div class='columns clearfix'><div class='content-main' >" +
			"<div class='main' style='padding:0;'> <div class='visitaAsesor'><span style='font-size: 20px; font-weight: bold;'>";

			template += $scope.nomCliente;

			template += ", uno de nuestros Asesores telef&oacute;nicos <br>se pondr&aacute; en contacto contigo!<br><br></span>" +
			"<div style='border: solid 1px #10A0A4; align-content: center;margin: 2% 2% 5% 2%;'><span style='font-size: 20px; font-weight: bold;'>" +
			"Para verificar la informaci&oacute;n de tu Solicitud de Cr&eacute;dito levantada en:</span><table style='width: 100%;'>" +
			"<tr><td style='border-right: dotted 1px; width: 26%;'>Sucursal:<br>";

			template += $scope.sucursal;

			template += "</td><td style='border-right: dotted 1px; width: 48%;'>El d&iacute;a:<br>";

			template += $scope.diaLlamada;

			template += "</td><td style='width: 26%;'>Cliente &uacute;nico:<br>";

			template += $scope.cu;

			template += "</td></tr></table></div><span style='font-size: 20px; font-weight: bold;'>Te llamar&aacute; desde el siguiente n&uacute;mero:<br><br>" + 
			"</span> <div style='height: 60px;width: 200px;margin: auto;'><table><tr><td><img src='  uriB64  $scope.icoTelefonoB64  ' style='width: 26px;" +
			"height: 26px;'></td><td style='font-size: 24px; font-weight: bold;color: #10A0A0;'>55 7099 0800</td></tr></table></div> <span style='font-size: 20px;" +
			"font-weight: bold;'>&iquest;Qu&eacute; har&aacute; el Asesor telef&oacute;nico durante la llamada?<br><br></span><div id='importantThree'" + 
			"align='justify'><ul style='list-style: none;'><li> <div class='punto-importante'> <table style='width: 100%;'> <tr> <td> <div class='circulo-verde'>" +
			"1</div> </td><td style='width: 95%;'> <span>Te contactar&aacute; en un horario de 07:00 a 22:00 horas.</span></td> </tr></table> </div></li>" + 
			"<li> <div class='punto-importante'> <table style='width: 100%;'> <tr> <td> <div class='circulo-verde'>2</div> </td> <td style='width: 95%;'>" +
			"<span>Te realizar&aacute; algunas preguntas para verificar tu informaci&oacute;n.</span></td> </tr> </table> </div> </li><li> <div class='punto-importante'>" + 
			"<table style='width: 100%;'> <tr> <td> <div class='circulo-verde'>3</div> </td> <td style='width: 95%;'> <span>Ten a la mano los siguientes documentos en ORIGINAL y VIGENTE</span>" + 
			"</td> </tr></table> </div> </li></ul></div> <div id='documentsToShow' style='padding-left: 8%;'> <div id='identificacion' style='float: left;width: 38%;" +
			"margin: 0 1% 0 1%;border: solid 1px #10A0A4'><table style='width: 100%;'><tr><td style='width: 95%;'><span style='font-weight: bold;'>" +
			"Identificaci&oacute;n oficial con fotograf&iacute;a</span></td></tr><tr><td><ul style='list-style: unset; font-weight: normal;'> <li style='font-size: 12px;" +
			"text-align: left;'>INE/IFE o Pasaporte Mexicano</li><li style='font-size: 12px;text-align: left;'>Vigente al d&iacute;a</li></ul></td></tr></table></div>" +
			"<div id='domicilio' style='float: left;width: 38%;margin: 0 1% 0 1%;border: solid 1px #10A0A4'><table style='width: 100%;'><tr><td style='width: 95%;'>" +
			"<span style='font-weight: bold;'>Comprobante<br> de domicilio</span></td> </tr><tr><td><ul style='list-style: unset; font-weight: normal;'>" +
			"<li style='font-size: 12px;text-align: left;'>Gas, Agua, Predial, Tel&eacute;fono, Cable</li><li style='font-size: 12px;text-align: left;'>Vigencia &uacute;ltimos 3 meses</li>" + 
			"</ul></td></tr></table></div></div><br><br><br><br><br><br><br><br><div style='font-weight: bold;width: 80%;margin: 0 auto;'>Importante<br>" +
			"En caso de no poder verificar tu informaci&oacute;n o no lograr contactarte en un m&aacute;ximo de 2 d&iacute;as, se te realizar&aacute; una visita a tu domicilio</div>" +
			"</div></div></div></div></div></body></html>";
			
			return template;
		};
		
		function imprimirAvisoLlamada(attempts, limit) {
			var flag = true;
			$scope.btnFinish = false;
			// Sí son enteritos.
			if(!isNaN(parseInt(attempts)) && !isNaN(parseInt(limit))) {
				// ¿Aún quedan intentos?
				if(attempts < limit) {
					try {
						var entrada = {
							"xmlDocumento": getHTMLtemplate()
						};
						
						// Spinner!
						$rootScope.waitLoaderStatus = LOADER_SHOW;
						
						// Invocamos el componente para la impresión.
						$rootScope.imprimir('jvcDiv', 'printResponse', entrada, true);
						
						flag = false;
					} catch(x) {}
				}else{
					// Mostrar el pop-up para recordar la captura de pantalla e impresión, si todo fue bien 
					$rootScope.message("Sin impresión", 
						["Captura la pantalla del aviso de llamada y entrégasela a tu cliente.",
							"Realiza los siguientes pasos:",
							"1. Selecciona en el teclado el botón: Imprimir pantalla",
							"2. Ingresa al menú Herramientas > Impresión de pantallas.",
							"Administración > Office ADN > Impresión de pantallas",
							"3. Busca el aviso de llamada  de tu cliente, imprímelo y entrégaselo"], 
						"Aceptar", null
					);
				}
			}			
			// ¿No' vamos?
			if(flag) {
				
				// Bye, bye Spinner!
				$rootScope.waitLoaderStatus = LOADER_HIDE;
				
				$scope.btnFinish = true;
			}
		};
		
		$scope.printResponse = function(response) {
			
			// Bye, bye Spinner!
			$rootScope.waitLoaderStatus = LOADER_HIDE;
			
			// Es un objeto (ojalá que sea un JSON).
			if(typeof response === "object") {
				if(response.codigo == 0) {
					// ¿Éxito?
					$rootScope.loggerIpad("impresionAvisoVisita [Success]", null, response);
				} else {
					// ¿Algo salió mal?
					$rootScope.loggerIpad("impresionAvisoVisita [Fail]", null, response);
				}				
				modalService.confirmModal("Aviso",
					["¿El Aviso de llamada se imprimió correctamente?"], "No", "Sí").then(
					function(confirm) {
						// ¿A dónde vamos?
						$scope.letsGo();
					}, function(refuse) {
						// Definir las variables globales, inicializarlas y aumentarlas, según sea el caso.
						imprimirAvisoLlamada(++intentos, limite);
					}
				);
			}
		};
		
	$scope.letsGo = function() {
			// Redirigir a la pantalla correspondiente para continuar con el proceso.
			if (configuracion.estatus.opcion == 0) {
				if ($rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id && $rootScope.solicitudJson.creditoInmediato == 1)
					generalService.locationPath(generalService.getPathSection($rootScope.solicitudJson, $rootScope.sucursalSession.idCanal));
				else
					$rootScope.message("Visita Asesor", ["Codigo : "+$scope.resp.codigo, "El estatus de la solicitud es inválido"],"Aceptar",null,"bgAzul");
			} else {
				configuracion.nuevoCredito.opcion = 0;
				window.routes["/nuevoCredito"].requireLogin = false;
				generalService.locationPath("/nuevoCredito");
			}
		};
	});
});