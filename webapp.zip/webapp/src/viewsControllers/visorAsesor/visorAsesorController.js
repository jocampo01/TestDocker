'use strict';

define([ "app" ], function(app) {

	app.controller("visorAsesorController", function($q, $scope, $rootScope, $interval, solicitudService, modalService, sessionService, loginService, 
			$timeout, validateService, generalService, messageData, clienteUnicoService,callCenterService, tarjetaService, recuperaSolicitudService) {
//		$rootScope.waitLoaderStatus = LOADER_SHOW;
		$rootScope.waitLoaderStatus = LOADER_HIDE;
		$scope.sombra="iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAArNJREFUeNrsm91RwkAURsGxAKzAWIFYgbECYMZ3tALHCpQK1AoI784gFYAVEDuIFYgdeHe8D8t1kxAku5vsd2Z2FIUsnvnu/gU7HQAAAAAAAAAAAAAAAPCAk8Vrj1rf5/fY9VDaDX0ZUBuKX22ovVGbfQ2uVxD4V5xK2pTaLolTIm9J5AYCf+XF9GVOrVfhZSm1K9cSjz1JnkmeStkHtYxaxGWtp1N9v6R2EXQCSeBaiEm5PFPDc4dc5rrsCT33MUiBLGRepSw5sWsxuZy5KuUjxwEci8elEwMnc6L9qGeYsYMRGOvpM5VtDs/i8WWoAvWxbLHriziluuwoVIH/YePDm/BJ4GnF50cQuF2GccWFty7wPVSB+p42IjG7ruceDIvuIAW+SDF8mFCUvqlI66rC7N3KncijIVEJ7zAysei+M5T6lcvTGV8OE+R2Tp9p04LxUS28E8zClKKccaznszxvEqgl8YbLOSqZeO5djnveChTjnSrpc06hGgs/XE8YXgvkU5Yxi4sL0qcEzpDAamVrIuOZOglSYMV7IGUiR64S2XWYummBEFWqn4a9clyQVCezcteBPCXOtNtQf/xLWZI4uXd516DX37ZWYE7yUi7BrOK1VBLnhiHAahK7FuWp8lseOjE5iba2vbO5E5nWUW58jaSkr2YL5NLVB//0kGMVX2vriL/sVKdpCZSnLaMa+hiV9NlMgbwti0TpZofuh6+ZiBQO25DAgXg8qbEvee3LNgjsi7Evq6sjvvZe91maItDG0mKV03fzBKpPmIoffVsQaKMPawnsG3YddZMaFvCtWEgrNi3pw5nA1gGBEAiBEAiBYG9s/5tDn9ZlNnc+rRP4hBL2eFHr4j3UKpDvsLn8BEFa9/1iKzeV+A5aZFleVufRGQAAAAAAAAAAAAAAIDx+BBgA+v7v218Ah/sAAAAASUVORK5CYII=";
		$scope.loadingFoto="R0lGODlhyADIAPYPAP7+/tjY2Pz8/Pr6+vj4+OTk5Pb29vLy8uDg4PT09MjIyOjo6OLi4sbGxubm5tbW1pKSkurq6t7e3ry8vNDQ0MrKytzc3PDw8NTU1MDAwNra2u7u7sLCwuzs7M7Ozr6+vtLS0oaGhpCQkMzMzMTExLKysrCwsKioqJycnJiYmKCgoJSUlKSkpKKiopaWlqysrKqqqra2tpqamp6enqampq6urrS0tLi4uLq6uoqKioyMjHx8fISEhICAgH5+foiIiI6OjnJycnZ2dnBwcHp6eoKCgnR0dGZmZnh4eP///2xsbGpqagAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUEU/eDQ5Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8eHBhY2tldCBlbmQ9InIiPz4AIfkEBQUADwAsAAAAAMgAyAAAB/+ASYKDhIWGh4iJiouMjY6PkJGSk5SVlpeYmZqbnJ2en6ChoqOkpaanqKmqq6ytrq+wsbKztLW2t7i5uru8vb6/wMHCw8TFxsfIycrLzM3Oz9DR0tPU1dbX2Nna29zd3t/g4eLj5OXm5+jp6uvs7e7v8PHy8/T19vf4+fr7/P3+/wADChxIsKDBgwgTKswFoKHDhxAjSpxIsaLFixgxgsvIseNDARciRLggwKPJjBtPqpyYwEKAlwEsJFhJE2LKmjQFuIT50kJJnDRvAj15gSfPC0NXCk3aMYJRmB2YnlwqFaPTpwEiVPVIdaWBDRsINMWateMAsGKHdjU5oABPrRn/rz6Fa5WngwFA15rdeTQuWboWixq1kDboN5wOsPqsixUwxQF87eLUyzHyW8ZzMQ+efLimZZgaClOUa9SxRAIayFrg7A0x2QAFLpK+bNEtWQesu+FE/XpmxdkwTUM88Dp0bm5AF7yW8HMi8JfCHQqQ8Do61841B6Qmu+H334obXlvAe3zb0PBkNTSP+LzsRMivu+fFXlMAgtcLRn+fmJgsgqSUeURceqI91F50CbwWgG/ztZaUbVgx4Nx+EAnAwGu4AUjfbtthdYBEB0okGFYakKfWhji1FwBz7FEoHXUuNqgbU/CRFRVEIeIo3noyIjeRAAds8GFH6JFoYkM5OsQb/1lIcTSAAwhEwONDaxEAY0xNYmQhhjo2BlF/ETrJAAcTlNnAkBGtdSVMDDBo0YBkGWCgiwm+JudFAnRQQZl8TtDAlAB01QGGR1IE5lMSOjSiUVkCcOFtGB0AQp+USiBRV2s+pcGNFS2JFYM6PbVYQ3UaaRFqH1BK6Z9poghAh8uhOSF3DxkQmQV3NlTkU/K95wAJqqqawZRd3acgm7lGFCpWjQIAkkgkQbQoT5b+uMEIwQarALGuTqugBgsACoC3AajXkQCwwiTrQwlgkG22BXDrYESDHsuTBhsACuFLGqwbabqxRTSABBm8G+yoNrnakAGP2vuSBP4KACYDBXJEQP/DDvAocQMGq+pBs1Qq3BBImR5bQMUCGFDoSQMkMOUFHnRMKQnhVhSgsxGk+62UW0k0QAAy9/mBBCu3Ou+ph9qbaM/SYRt0mRi4abPIEiXQsL29Ms3A0xNUkPVFN1e4wWdYZcg0ABQEzUG81x3tZM4mn91Q2gZ/UOJUVCOt4NdbSWAwBf5yFHZFBxg7mLhMEUCmqgpwqtLgFQkw9r1SMx0BpRwwgLjgeb8tgQUFJCs3ABt4wEEDxvVo3uisVwV567CD3XnstFv0eu0nCUBAArz37vvvvhNwZEoGFKCzw/yejLtDEcCQQwjQRy/99NTnAANcGxlwPPL3Vtx6BEBQL/7/+NLrgNtG+3JPVsC1w0D+++OfIMBG26sPGu4CPA///tHnMMBG9rMX7gjAvwJC73+HqV8ANTBA/Rnwff5DXwBfw77YCcB9D3zfCRDYGk9NECbjWR74Mjg+IGQsJW1R4LE0UICiwW4BziNh/05wl0ChSAA4zKEOd6jD5UlEAAMIohCHSMQiCvEnt/Nh7ZKoxNgxsYmte6KyImABDbQpdgyzgAR4pjpt4ERysOpX6w4QxnyVx4s0SUDJYrK5oSzLKAgIXEekSID0GYVvVdnVU5T3uNlNUYUV7JkdjaKBCLjQdn58yOTsZTamDVJUZpxjIgGQAMPZC2R55N4VOee2xyTt/1hLk9vVGOm9S3VOAHBDXiFhh0oV3ouLU+uktMiGoYq17JBOMsCU6qg+C0SLInphmPriqKyJlfIiwnxJIx2iRvUxQHQhkyUAVKSYSEJklGL0yAXStcyRbcCVPHFcNGcEET1+awEuJJe5OIIuZv1oAeB8CSaLhbxnUuSNRlnXs0bCI3KtCHEXq6cpZelKCWByTrRyiK14QhhFVicwayTkQMn5kIjyqwNt1I6dpPMZhJVKU8d0SAcU+B+jUVSktcTIJ9n0EH82apSSuciT4jNRH0WkZJu8yEefkqwkUVJBlZtIMqkFqCpdyZcdsaRRlulTAKz0JZrjyAX4IoFSUiZIB/9oYzmLU6CmajShUhUS4qT4I1oGQJzTjBEA6qUYXOJNmitREYu6lJmbPpQpZI2IBxkFIrUCAE4gxeskL/LIAIQSoXWNCExh0k3DwNUkO70XNJHkVwAYQEFyfOtJVzId/OjHSxNRjn+0ipLBUsScIDxkUz9SPzxq1qY5aa13QDsR1PbEraV9LEdEixUEbG61H7GodSSpW4zslSeZpSxtJwJYQoY0t5s1yVNhI5vKPqSwjW1bdD1Cy9TNNrEUOW5PzpgNnNByuMyzLmI3U5O8OlUxpAWussiWXeJudy9POWiLlgseUeFWdsXFyEwvyhH59pWx/wXwfU1CALAkWLngvUh8g8OioQCfzcBRNK1UMMw699bEpU30cE46StqziTiNt5os7U5Mk7NAq8RyW4iMZ0zjGtv4xjjOsY53zOMe+/jHQA6ykIdM5CIb+chITrKSl8zkJjv5yVCOspSnTOUqW/nKWM6ylrfM5S57+ctgDrOYx0zmMpv5zGhOc0ACAQAh+QQFBQANACw8ADIAXABlAAAH/4ANgoOEhYaHiIYSiYyNjo+QkZKTlJWWl5iZmpucnZ6foKGio6SRBaWEi6iRqqULAbCxAa2rtbaXEgC6u7y9vr/AtLeMwsPGx8jJysvMzc7PnQvQ09TV1tfYtcXZ3JwCBxsHAN2aAhsSsRIE5JYACQyysNuG0tALwL0EDvGyG87zlQRE0MBPVq5jADEJuICuoCwN40w1SkjKHTyH8RhEZHdowCuM/C5s5DjInAWQ8TREGBnq1KUCseoRAnCgIcpYBdaRJEQA5s104naWHPgTloYNLEkCuFh0wQChhTYUDcAgQSabIAvg28rVl0+UFkRCPfTVoUoBn1wmk4rRwdOxif8EYI2FwCrcRgcIxrKAdBjFUAYKWJAQ4e3dw4gTK24wgIDjx5AjQx6AdueGDDBoaN7MubNnGBn8sdvwwrPp05xfdGCXAbXr0x/YZX5NezOMytkG1N6tmdyAE7xpw2Ad/HUG3NlIFz+tmuNl4Ms1g169U8CA69iza99OebH37xwlaFBbS0OKHTxKbEAOvgGIIEPiDyHy4QCyv5su7JDP/wcInd/hwN+AQ8jAgGGJCSADgQMKUcN6m8zlkFZdVYiPggwSuAMHdiHGQYYM6vAAgKZMFQCFFqboCwEQgMjgDAUgCFUCJgjhYoM2rMeVhFkZI0ABC97IXw8KdFgKeZQgWci1ACCEICR/EEjAHidKUvkLARkQ8WR8QdgwZXUbwADflgpMUmUqyAjAwApb6vAlKljh9wgBHvAgJBEyriKhnI8kgIONIOaQZyEyNXLmMQK1MCaBE7THmAQiEBgCiWhyUqgkl1pCgAI9yBfCod4l4MEHFCTwJiV8KnPdqY62ugyokpQVD6yu1mrrrbjmChWtuiaTi4rA6pKqNsEG+1E8w36SaSjJktKsJbz2Ku201FaLyLOHYTtKIAAh+QQFBQAXACw/ADgAWQBZAAAG/8CLcEgsGo/IpPLoWDqf0Kh0SkU2q9isdsvter/gsHhMLpvP6LR6zW67sde3fE6v2+/4vH7P7/v9cXiBf4SFawyGiVyDio1IiFkMAZOMVZCOmJmOlZp2DgCgoaKjpKWmnJ17qKmsra5el6+ys7SEAAIDubq7vLsCAI4JDwoNxcbHyMkVAQmJCRXJ0dLHFQeGD9PZ0g/AfwDE2uHGFYUC4ufFAoQC4OjZFere2O7ZD4bP9NLV3YTC7fkVHhyIZ+iWgIMIEypceJBfrYcQ68RKU6BGihkkrEW8YAGCiI8iUowwAPGADJAoWVgYUKsCypciSiwg2AqACZgvV3DQeOaTqb6fQE2VwAlTBgUCrigQxUkDwYCgohxMmkq16iQGULNCHQBjKc4YEWhiMsBhhdeXLhoccJhlFRkAEYaeRTnjAVIzE6fkJSJAQou5KGG4pbK3C6cRKQCDbMDWEYADEzwqtvek8B0HLxSfeDUgwIy5KcSmIqAg8VIWooUMVp0HwIYYkmGOeCigwAmYLcysZtJlwAMUIFVE2CiEQIARGu4SF3JwuXM5lvVanbr7ufXr2LNrJ1N9u/dO3dWE/w5lfKEgACH5BAUFABEALDcAMgBhAGYAAAb/QIBwSCwaj8iiIcJkWpbNqHRKrVqv2Kx2y+16v+CweEyudsrotLp5XrvfZrg8Tm5/C3Os5W3/7vNcf2J9gIWDYxZJiouLgmuEXo6GcpCTllqVl5p0m5RgHYqZnVGiYaVXF6Nwp6qXoEdQrZassoa0tYC3bLhNkqZGum7BTKllw7xRCMZcylwXvswGjEIJXB0B2NnYx1rNtd7MedxlsVXQh6O651nja3hX61TtVOVY4Mj4+VvD81TVV+/CBEwzUN+VerMMolPIUAoCbRAjXphGMUmxLQjFPIvIsUDFj0UKNmzVL0sBjtlegQRZEs0/VfFG5rk4KqYckTJz6tzJsycW/wACggodSnQoAJ9UCBTQgLKpNg0FCCBlQoCp06vZNEhFehKr1wA4c1r9elXD0Z4AyH49yxPAWLUozXKF69Qj0qp0OVrYendpXmxQCbCdutLI1MOIExuyAFVa4ccdFMTA8UCaYi8OSpjYbCKGhgG4bKIhEIOz6Q8OcKl8PC2A6dcmFNC8TEUB7NclMDhmfWQjVo+8p1W4DfuGhQHBh2RsZYH47QwLBJDp+hV48kUCODi/XWG2NYYDMGjebtpG5Uhqwy7vIqADggNGLtgmbxoHAtBZ7mV5WSVsFgEIoLDDgDAg5MAE9JnGASiF+MeFABT4MOCELSBXxAAalJbgZg8g4f9dKxf0MOGIHggACwjjJcjAGA5GIBopVIww4og5TORhAxtmMNgjTc1mgTaScDDjiDiYiIQABeBAXwy1/AiRIxYMOWEPDiwyQAA2bPfBTWoM4IKUA54g2CIGeJDiaxp0sRuZ1qC0mgRgDpgmJtq9NgF+esxxDUerCQBDnC6sqQiASm42gY1JJLABf1p8aMWeEa0GQAcigqmAkdMMsFQByMHxIhOQQiSpAB/EGcIGYOyYjptGGKBDnDHg2VOo2kgqBAhx+tBiLdYVQWtKRwwgIJgt8MXTr9sgwUCcO2CAFLIB2CqEACbECUEC10FmCqse8hAnB9LlI+0Q0I4LlJBghtCGkivcIkGACHGaEC4v2IbSLhIPMNtrtovsekW52LUQ5wnzygTwIg5IKGUO/FL0qTz3HmkDmDkUXNM+EXsYgpQ1WFzIw1IczEgFQ+awgccNbssnRQPgMCINHaBsiaOPZpyEpiSQwGnDPCch8jQCDIBpz0QTUS5tSH+cdBgGgLx0Exd0sC4aQQAAIfkEBQUADAAsOgAyAFgAZgAAB/+AAIKDhIWGh4iCCQyMjYuNkJGSk5SVlpeYmZqbnJ2en6ChopARo6anpqWoq6yRqq2wDK+hs7G2oLW3nQuxubq/mL7Aw5PCxMeMxsjEysvAzc660NG209SwEYm8172Ij9zY4MjW4qfkyeW4hufpmuztn++tCYmFB5sRAfr7+vKt2+0AwoP0bZg/TgcH9mJVUCErgQ6p+bs3DGJEUw3DXdzIzSLHUBk/ipQ4ciDFkihTqlzJsqXLlzBjypxJs6bNmzhz6tzJs2dJevWCCjV0wAKGAA4G5LwAomlTDBEE2BzwwKnVABekzlxgtSsICfRkSvDqtYBSmGPJdn0QdSihkNz/IqglG+AAgJYANMwli8DA3UoJfwkosNcrhgVnbcHtdGABUEIG0hZ2+qCDVlAnsdmQIQPFhwGGLgSYbFXDYmp5UXBefUPAoQgYSDt1AC+BitW4NSAaQFg2iA7HBFzI8OIFB7uEAuDGfeKxoQQWZAdIlUlAgCBHsh8xYoEQiOW4K1gCIHoyhr+/LmDXnt3I4wLgV6voEFTAgthzAwDgt8+jKA7ssUfCIAKYEB9nnwk1AAJz+eJcPadFUkOA2tVAyAIHclaAWwno1ZV+tixQyAsUZvdCJB9kWAMBbgGwQVVNBeAXAAdskBksJJb4gj0zZIgBJ8JFkBUyOVK4YyEjZMgC3XItCrJMkQEeSQgBJ2SowGURQcmelIRYkOEMgQGjpXYnTrLZgTck5tCYJiISgWoHSrARm0eUOUkGGb5gwEV0cmlPCxmCwGeJddbz3YEtXJAloX4WMsALGXJADZOI9BkUAhmiEGYsfWJyQ4YfoNeOpUF1ACd4NKzJaCYNHHhCk036pwmpQSXAQnwZqKqjW8otR4NdCtFanwKnTgBssIy2KABsILQF67PQCtIpkB/RaWG02GbrVgaEDqjtt+AWcoERFBpBabjoYksVudoZoVu68GIrgAEdfFBcBlnFK1QgACH5BAUFACIALDcAMgBaAGYAAAb/QIBwSCwaj8iiQcRsLpvQqHRKrVqv2Kx2y+16v+CweEwum8/otHrNbrvfcLIjTq/b7/i8fs/v++8baoF9g36Ff2ZziHFPi46PYAeQk5SLh1qXcZKVhFwGSUUJnF2KcJtYpWGZao2jkKtQp32yWLRarbVmtnSprmOwbKJxvWi7fLi+hsllxGgboNDRQ8BTyJjLTcbYk8/S3kjUwdvjWeHk5+jp6uvs7e7v8PHy8/T19vf4+fpun9/+SAYKWJAQQYC9AxoCKAygwRw6ARYWSkRwAACgfxgBbJDIMUABAvAKdOSoIQIZh3REjuRoAaUUa3w2ruyIQJg6BjNHflwXIWFO/4klDb6ByQWAgQ0DjBBQ+XOhhQtlbKYBcMHDhKsYBBhJIKGpRAZE+zi4SnYChSkCNvj0GqCDRkcEPpQl6wCJgAVrm2prc8DDhw8U+g0pMJcsCQJJCOD0ikDL3ivdhDCAEKJyCAgFiCAoTNYCtANdf2qwk4Cy5coQEAvZwPnqh4rQOuSlaaWZGAqnT4OAUqH1hKxZHMwEJhha2CgZclvOQIS1b7fSDCDoKEEom7pEPiiv/KEIBt8Vkno7EFGhBNVCEmyQWo6L9u0TlMhtndnfgQ2P2bxXHr+IBN8cgOTLfrn1R8QAJPg22iOwFUHgaQYSsYBvE+T3x4OWRTiEAFa1RrWBdZVgWJmGQxxAoUmjiBgCiUM84JsC6GXkj0tRqMiiEARk4BsCFsUEio2gbNYaB8f1AWQSAjTgWwA95pEANEcmEQGFFuoRZRIU+IZBiNutGI2JQ3IJnzQBtEaCjN7YpsWViXHA2QNN0tEglF3eaARhcxEpJn9baFAWCEU604WNXBzAAAJQpVjnP1qh6ShGKnb36KSUHuFBlxRUqqmmB5h2GgSBniOBp5cVUA8BF4xwlQfsxREEACH5BAUFAA0ALEYAdgA6ACIAAAf/gA2Cg4SEAhsBCwQAjI2Oj5CMAwYChZaXmAczQ5wrDJGgjwYFAaUOAJiplgMunK5GFKGhBxqltgWoqroKrr1ICbKQArW2tge6qgk9vb0johoUFBYDjwfFxRICwaACJcy9HI4RNTTlNDUdjojXthHbkQtG364WjQTk5uU11IwG7LYaFr1rNEDFPE4i+AGwkC+fBEcM/pka2CjAwSFBNDgC0dAcCEf+JAYANnBAjossBDKi0LFcLEcORCLQ9o7DRSSnHLFs+ZIgsX8b3l3YcfGGwpUtafRs1EHktGACalzkcQHSzo5LG0kQ6U5WAXkHPdDUmTQrI2sSA4YaIOOiCwOR7K42NMuIlERcoEBcDPIwbllQISWSfETgx8UTKh/JzUeX0QKZYxkJ+HBxR1e/PEMNExlUHZGLHyIr/htq3b+nkk9c/HFA1mJzFHRtlXgZQZCLH12TDpVApFoBKC7KSIwZ6za7/04RIDrPCIJtr11uI/DzWj0CPg7ug75bVgSJFgQQYDHPR1XumbcJsJAcwIAF2ZkpEA0qutKBpm2hFrAgOKcgN9BXX3fBfGeLA0e5hwAHHFz2jn2NgULABhsQ54gAAuqWHkUcUgRhhyC+o0FS9YRoImD45FODhSeeKIADKZ7jYIs0utdbNBrAVWMgACH5BAUFABUALDcAMgBgAGYAAAb/wIpwSCwaj8ikUKJsOp/QqHRKrVqv2Kx2y+16v+CweEwum6/MMzStTrLb8HhVAqjb7/i8fn9/y5F+f4KDhIVPCIaGHWCLiUSNjpGSk5SVlpeYmWKBmkqQnaCGnF8HoYihYh15p4OjYqytVp9/DE2uqLi5jIMIpUq1V8BdwrrFjrPGycoVt8vOx3zR0nnIcr6xz8/NYsTZ3t/g4eLj5OXm5+jpw+rsTt3t8PHyZhIa72b38tVkCAH+/wG2mVM1rWC0ffPUCIy0MCGYfA51NUxyAEGHAY4mSjmQJ4ENESBfLAjmBFYiAS9AqlyhId0DlTBdGHgGsQIBFDBhBsAzwAEC/wQRBDgD0CAnTAp3DoxowLTBiGvGNqwwqrKAnQFLmzIdIdSYgI9URZwQYGeBVq0R2iC8giCsCAgM7jA427SmF5NE+vnTyMLtjQF3ENBlireLhH+FiRzYAPUJBbcuCNoRPDhxl7VYEuAMq4Bs4MENLGfi4FYFRzyU6Yq+FGFq2J2rQK+uJMCE2xoE9KQ+i2CPXUIS3EKwqlt2lcZxWridALh4ZVQAPLhNsYHPbq2zJR1I4XaEkutNs0ea4LaFgWjgCTcRf8YBBLd00MuWhnwQWKolmls33mkAd6orLDBNeqFhEZ9BCO4xwGZGceCZfM+hkeCEeQxwA1UonCYNgewVIlJABwyq9IBBHKIhxwb3QaAAgiWiIoADFFBQHYv84UIhABzeqOOOPH5WWY9ABmmQWYNFIOSRSPKUlVZcJekkkhcs6ZSGT1bJowAE+ISAA/pZOU0QACH5BAUFAAsALDUAMgBiAGYAAAf/gAuCg4SFhoeIiYQWio2Oj5CRkpOUlZaXmJmam4YdnJ+gm56hpKWdpqiHo5irqaGMoa2TsK6QtJaytbqVuZIWAMDBwsPExcbEt5+9kcm7pcvO0YrQ0pwSuNXZjtTa2dyJF93P4uSE3+W65+iuHcXh67vqg/K7zbzE9OXvmfT78Jz5Il2wVypBpA4BEipMGNDStX+F/Gl72I0gNkUUx9kyJdFUgUYWFi7suGAZSV0nKaWEyLJaQ4wGFX28NPNTTUcrW6Z6qbOnT00XjgkdSixnqoE/DRlNyo+pU0cxKz6VttSVxVQ3p2rdyrWr169gw4odS7as2bO6sqJdG0ot27dw/7cKmCuAqN27ePPqLVoiB48ZFgREcyuNAAkeOxLv8IFBcNwFAh6IUEz5R1S2Ahy0oMx5Bwm4B2z46My5BdsBCn6Q7sxinYWqjwRoWLGadIW9e2FvEhCBRm3SKMwmuNHjN2cfMQj0zDdghGrjlFsUqCvMQIQDjstdJSQAQQrolEU8IDCMQAUT6EnoLkSYUEZNBGKAV8yDxOVBDdDrL1Egd7UBDcyXmAkdUDcMAvolGMMAm6wHDjECEDAZeDMgMIAxA9yQYIL9CSPABRF00JGDmxBQnHFAgGCAUA9smKAE1YWkkAXKPdKOUCQKMgAQvxXxAXZCJWCDi/rdCIAAMi60nf8uAnxQGwwRZJfICESixwEhF4ikUI6gEMAjZynQaFcEVZpQgpEAIKRlADxN8l4hDny5Qw4jrGhXk2WOYGCaa7LJUZJvGjLAAw2Ml5cEZcZwwDBqatmPXlxCQoCGVQbQSZ9tkgMABmXiQB6jmHp1QQlldgjqmpmKo0CZDVyID6bGtLeOA2WeaUyjIjWUAG68YvhBmRTsKQyuC6WajQaJ7nprqFoZEEOZGghFrELGRgMABWV+8OmyqDYSqDijlunAUNMyNNR9mp5XpQLbMOuUAM8SWUJQ5LpbyZKkUOoiBjbaS8kvveImAJUu3rCttP4mNZyLCNxVLpt3ZSkSvqQAkIA/umYGgNfDaJL7z0ASKOtwwm9xHPDJKONmcsost3yMxFrS6/LMMyOpJcVlGZBkABbYSfPPLg9wQQciCgv0UIEAACH5BAUFABQALDAANQBnAGMAAAf/gACCg4SFhoeIiYIRFI2Oj5CRkpOUlZaXmJmRjJqdnp+UBqCboKKjp5qcqKqora6vkKyws7SesrW4uZK3ur25EYqCpr7En7zFs8O0x8jFCKPMzdKd0dPWltXX2qTb0sqY2d3d4eKa36vl6bu26sTAheTtv4Xn8tLx9pUHqQH9/v34UD3L16yep4EEoVlCWCxgwnQOH0qcSJFCRE0I9lkyECyRwVYfa4XUNfJXRW0lT6pcybJlu4ujUrp8pXGmzZs4c+rcybOWgAEEDAgdSrSoUQMEBgjgKcCABiBLjkidSrWq1SUiGOIcoEGJ1a9gqSphoBMpkLBowUIYUDZq2rdT/5XInGgArl2pcyUScHsXrZKlOQeI6JsWwk4BCLwS/jrEQVlBBSAoXnxECQTHOTkSGmDgwIXPoEOLvnDggAEBHVOrXs26tevXsGPLnk27tu3aAlDf3s1bdYIGNFrYKACgJ6gBIFrIWC4DBYLixjHCYE6dRV6eHW5Q3y4DRDrNvQ8ZaDCD+/Yb0SkJeMDCPHcc6SUVqOHefID4jgBcmFDfvA38jRAwQnn9UTeDAmw9BFMjAdBQ4Hm3DHAAAdDdtEAJD1L3AgIDFIIYCCBacN1BvQxQAQoZLtcCCOARYgGIMIJwgUsCYJBicxzMKEkHMcKIAWAqATDACynagJkk6/UIo/+O3LwyYiUDENgfDBZQmIgDSsLYwUaZLOjJdPWp4EECwRiAQZYgJtASAB64h8IHG1wCAAJogqBBhSsNACZ1JhTQYUcH1AnCAYRE8M8/XmKkSQd7nhCAlakFUOdzhR7qT6KYaJUpBhyyFkGdGLQIgKGWBoBpO0miuYAhpFp6qjoF1BmAbpWW+mo5Bgh6wSGtHuqQqOG9JkGdFtBaq6s7XSAombyWaioohAYLm6RoEodIr4jq9CmaGEDKqrO3ajPAmWi+cy24OcWKZgB/nmvrQnTpGgy2lwZTkyTASosInWgiYGyz79oEALlZ5gsPuB09iUyqSlo7L7oC89vjA+0qQi87QDcBYMADSm6g2sXP4kSAxCCs+jHCHz+kcQQdeNsRyOamZsAGGxisb3gw36yzbDAD6PPPQBsXQbinBAIAIfkEBQUADwAsMAAyAGcAZgAAB/+AAIKDhIWGh4iJgwkPjY6MjpGSk5SVlpeYmZqbnJ2en6ChoqOkpaanqKmqq6cErJuur7Kzjg60t7i5uru8vb6/lbHAw8ShwsXImhLJzI0bq8/NldHF1NLX2A/Ho5DZ3tLbqwff5OXmntab6a2X4+QMu/Cc66MM3eeTDAH7/MvF8pgOEAJo7NIGRYP8ybpXTCE+gwF7EezkblPFTgwvMUAo6OIojw9DYqIHzGElBgQ4IiIwsRRKUCAzhUuVUZtIaQdVcpx5k5U+fkCD7sups2ghkpVqnkIqyYHRp4NsaYrZUyQBB0KBEoValGnVrw+9guXUcqzZs2h1ARAwoK3bt3D/47oVAOAsgAEFTuQIwbev37+Ac5yQCowwKQEFdABezNivjghjCQw40bgy4xN0uWqOmmrAXsug++bg+XBA6NN8B4z1jBq0DrMCKLeuDGPsxgVAZjMG0iGyoAgwPusOoQNG768vJRFIwLy58+fNDZBOS7062M3Ys2tHSCAAiQwexKoqO0wAggwT0qeH/Eu8LAARGqifz0G1dUsADlCYz38Cgu0IeZUSgDsF8EF//FFwHyUMcIBgfyAw494nAHRQwYMIFkBgIhtk5SF53ICAIYIeYGPYKANocOCI/GkgwH0COEACiwkKNEkC9lUFwAYX0qieAhG82BQ/yYECoiMmpSKA/wY+qpcBAgMW8hM/Ggj0FEgn3sJAk+kFYAAiF2SlwSlUfWKlIgLI52N4QlJigYdlglTmJdNJshFCAqw4IgkOZIZIBB4GICCZp6Q54gcSRIlIioEagBEyEmCIQQIqYfXhVLq4p+Z8I2zgpyIJBOrlJ0p9MmU/nBywKZ+fIoRAoFm6RFEkSWIiQAQMBGlUhx5qUGcoW6l0wISmvOnhcQtWAqiHtSbbCAEaBDqnKYpumF0BgW5kyqlBOWWtdqH26qizkwggQaALkEsJr1lZkKO6jSwZKLFoLRAoAm2m0mwy0ErrS7XfcmRpVhrCK4mxQvk6y6+/AIBwUOwZHMnAQFmQry3EDwzw8D7TokKvLgMMrAGyGE9CwAYbvJvLyRswXPLLMDfSccwwl0rzAx/PEggAIfkEBQUADQAsMAAyAGcAZQAAB/+ADYKDhIWGh4iJiRKKjY6PkJGSk5SVlpeYmZqbnJ2en6ChoqOkpaaVBaePjKqrrYkLAbKzAayvt7iaEgC8vb6/wMHCw7y2uYjGx8rLzM3Oz9DR0tPUhgvV2Nna25IX3N+dAgMDlMngjgIHHjgeCdrepgw8Q/Q+CgTniuaPCfP0/0AskMvHCce/g0OCtIggwBQ8R9dMDQiBEKGQG+5G7Vs2QEjFijw84Nu0UdPDTAJ0fPy4gkFDZLRonXQ085iClR+DnNggIFhNVRE9CYgRBGdFIh9GEowkQAIEoxV/gBiIKNWlArOCYrI6KYGCIlARyijwcukjARtseAxLz0iNjGb/Hw0ooILtPwhKoWndRCCASrsc4nbl4IMtip7EEisGwLXRhcWQhaGtYQTqYcGUBjCQYXQCZksEQPz46OPAqZLLDmTYcdAIhs8oN5QI4UMG6lCNYevezbuVuHHAgwsfPqDs7ggfTtBYzry58+cnMmxglhtTBBjPs2tvDmP6ZwEftovXnuFY9UzKx6tnDoOq4PXwl8MWkD6+eBgAYGewPz4w5gIAbIAdf9m98JNZF3AwIIE0wMDBgeBUJw4BFFZo4YUWDhDZhhx26OGHIIYo4ogklmjiiSimqCKIAkQggQYFwKXKecxsoAEtGpjWWyQJSBCTLBIYtyMiBGD14yzeDXlI9Is3HjkLjTsG6KOTtEB5y22ZJIAAlT9CqNtcXP5opTJjMhVBk2HKokEE+Q0JwAVTpilLAXlVgyUiBjAg5ywIHNBmVVstA0AEe8piAU/BlPlITYp2EmChGizgXitedrPYlnIWYMCfhtxZSE2VngIAmlRK8BgncdbSSaiQAJDqjxp0ICQmr6oqTQdULkDAYo0mwuorrv7IQAKcKpkIAXGaWqwle0XSrCVwXgLAARvoyNuvnXhq7LanYMvtIL02YuSR4X5r7rnopqvuuuaxS9AuK0KmbSvwxqtYLD/OC8qzV3apjL6jlOvuwAQX/Iy3OwJsrsKkBAIAIfkEBQUAGgAsMAA4AGcAWQAABv9AjXBILBqPyKRyuXQwn9CodEqtWpHOq3bL7Xq/4LB4TC6bz+i0es1uu9/w+Dorr9vv+Lx+zzcKBH1xCQEjAQSBbREqIowoGAOIaQSLjJUnBYCRZRWVnSIQMRcAeXRmAi2eni4Kh5pgAi6pqTMBkK5eNLKyL6W3Vw+6shATB6OkYgANwbIpI75bDi/LqS0WmUgMWgwB3L1W2VQEDzPTniYRxs9TAAcNseWMKxmt6lMCETHwlTC2et5bAxDk0keh3hUCFGTAKwGgocOHECNKnPgPzoEMK6YxNKhFwIISy5xxBGiBhSwUCUZ2MTBCYaUVElR6YUdChYwSFcuAk8mzp0/MPQD+CB1KtOjQdD4FHHigoIHTp1CjSlXw4ECdnOsOVJDKtSvUCil9PvBKtuuDiWjTqo2IlYqApmXjPq1wTaUAuXid1lUJNy/ZCj4BjPVLNkBPBgASbCXMtYKBnxoG9WVcIcBjmTuHBB3AubPnz53/QB5NurTpMZnVpD7NurXr15rawp5dxAG327hzc1t9Rzbtq7+78I4y3GBxaMExJ1/OXIxvDc+bS38Svfb069izay9yXMo23d22ix9Pvrx5PtXPqzedPk379V7eIwoCACH5BAUFABAALDAAMgBnAGYAAAb/QIBwSCwaj8jk0ABpNi1Mp3RKrVqv2Kx2y+16v+CweEwum5uds3o9FQwE545yTq/b6QMEh1MYmNNsgVoCHS07hzs3fmSAYAWCYIQ/iIgjZY1gFpBeAjCUiCEHjJukUgKTn4cxcGKYmXewsKipPgtjrl8WsbtznamILaxguKWCBb+ID63FxQMmyDsiBGHEzGwdPNAc1ErV1l0CHNA8F8NiF7zpdAki0CbCXN7fag/QPo9eckdR82UEhshQLIrXr1QBH9Aw5CtIakAMaDr4aZFXRZ+6O2E2hID2AR4Wi0MoMgNAoECAPncEKIDWQyQahlouTDBB8wYCAXYMrIAGw6MV/5dNEHi5oAnMgJk0k3IAGgDaDglEOgSYSnUq0C9CxQRIytVEiREJ6BA4AS3FQC5ZN7lE2jWpjQAD5jjoAa3oFbtxztho23ZCAZxIBtyA1mAK3oXWAHzgy5fEhiQXciDzUJGNxCwI6iBgzLcEBQNHBHj4xSMBTDNbObeNoSFukQEqPvnA4HPNVTSwOnBQ3dcBFQOeDqn4KwbfGuNe8uDg3VUBuiIHGFyo/eXyaQMP9jKnWQLD2dNXbmO5MGK7UurgIQmIsNu8rot1ynUBDT+whBvbK9Sngzw9AAMYlMCbAuk5IV4ZFyigmgb7zXGgNQ6wxdUN0zBzWIFODGBBDFyV4P/bac81eBF2E9ygwINk9Ifhiiy26OKLpNQHYxn/FaBBVTjmmKMGBVQInopjGHCjjkQWqYGPM3YBgElFNqljASLGAuQYAAzp5JVTMZikFwBg6eVUAGyppJVfGimmF0yWWeSUZ04BJQFkqlmVBd+1icUANspJFY912ikFkAAIIOighBZKaJh+Jqrooow2qoYFPFpXDJuOCoKihZWWAlKUUWXqaUwWYElpPxbIB4mk6V3wZVpspCnqjKMi9ulLZYT65ZSonnZhF6xuYRoWsQI7KwTBhlHsGqYO28+ou34EU6+aFpksBLZO1WxlykpRLVV45brosRheCgF9dHg7hVQ6gmSgLq9rXPsHkVdBm4W7WiSwwa9dTJsFujnepu9EpOYDb7Zf8IujuJ4aXBXCdkJ5hMJUbTqEqziCKybEVoWBb6YYB8BwuK0MTLAUEkcl8shbdPxxkmF1A+8cG8No8bkno7xvza9wGgu9N6dLBs8wAQ2Byp4KXdHL8eVo9KQhp3vHyqT8+xHONv+EtM5Y60x01VyTsnTXThjwNdhNXNAB1GUEAQAh+QQFBQAKACw2ADEAWgBnAAAH/4AAgoOEhYaHiIYCFx8vLx8dBgKJlJWWl5iWAUFHnUdGAQOZo6SlmBecnp1CF6aur64ZqqocsLa3lS+znjUKvr/AwcLDxMXGwwLHwjC7nTW40IgCCxQgEZOYJ81Hvcre3+C+ABc3MuYoFdiW2s3d4e/wv+M05vUyAdnb7vH84B/29VgkuMRu175+CIsBoAfQXANvBWcdTEgxGMOGMzqs01exYzAA/xqau6EsoqqJHilGQCHSHIJKJnmlnCmAQ0sZMEQliuls5swDLW6CoMSTm8+ZFG62GIioKMqj/Qy8uMmhmNNEC6DCk3ATRYSm+hAl0ApvQLmWJYg5JesxwoybFv8OrWVbUUCDmycIGJoL7mu0UQdY3PSwN2yhCGwXRdiQDByGmypaEeJL15eBACAyP9CIiUCNmx+CMWtX+ZcAzJlTa2BqCUHXBYR0NTNR2leE1LgzI9BJacCEmyXUcdj20FvWhABQ506NYYE6RB1U3CwwKEEqVULGdkRsDACG5csDSJZW4SYGQhauHxFioXFp5eBxW2BtKMGJlhoKJSBR4wWHC+71o903G8QXXwG8FRKASC0YwNZx4SxgIHgY+FWIAGfVM4MEANSmjIUJaDBheOMNQsAHLMlwA3cJQUjTBg+MmJsEBtQXwYAI4QjVAA58J2NqBQToYUcAGIDAj6p1OKT6Mi4qA8ABIiLJ4pLE0JeJAB3EKKMEVO5YwJZdBjMlQkVKMOGYYaa0CHypPSBkmjRF4GNqF8BJF48BPCCBjnb26eefgAYq6KCEFmrooYgmquiijDbq6KOQRirppJRWOiSflmaq6aacdnoopp6GSgyakpLqE6iipqrqqkeZqqirbXWKamVNpmplIrOKGcCuvO5qIQC5GgobIRH02uuvANQKabHG+uops83CWmqzznYKrbHSRnrtsc9SG0C2y3oL7qPb8jquo+VWy2m633ZL7bmNsgsvo/K6G22hyvYlLkL59lmvteJmMi+c/64b8F8Iw1IwqwyvGuyzA1cUCAAh+QQFBQAjACw3ADEAWgBnAAAG/8CRcEgsGo9I48Ez+XgOhKR0Sq1aqwhRaBuCIK7gsPhq0HK3kARgzW673/C4fE6vrynnM8jO7/v/bh95XBmAhoduAn8Tg1sZY5CRFxIIB2CMjY+Rm1YGFBOgExpXmIOanKhIBhyhoQV8pXmnqbRCABitoRkEdrFns7W0rLmgGr2NIcDBqMPEH2p0voTLwbjEoBR10o7UtQfXoRHRyMrdkQ/gEw2KctvJ5rQGGekIc+6FchvwVgAS6bvtyEHagOgPAQXpHgTMJMfBPjAR0k24EOdeHAMPwQj4BM4DOzf3Mqb6lk7cG4tvLIkEEyBdgwEnBa7kJC+dhJiZZhI5sOHAH/8G6T4YACnTispNBCQEWGqBIp8BCMFhIJqzmz4j/ZZqDYBgqJ0OEgmyEVR1ZYetaB1SEWDtWgUieBqBsKJ20walaLdq6FDnwId0YgEQMHMGAsaZGvLmlXAUiQV6bQoQ7vKqytUkjaUgUKy4gFc4BJrlcuDG018KCYpk7gTmAGfFGhZ8dFPgWoYBD+teOfs6r4YNAo5wbLVg32UxBhj0XgytzYC2Hiii0r3sAN7lWgvwcjPgAi9Uh/cJiJAY+1INEXSKCTyHgAPzWhmopxsmwWb47AvOOU4lfJgNFphXwHyYoULecgMSCA8BBfSWn35x8JcRAPYpZoGCKwGoV2oKSminTgQSWOAZhiSWaOKJKKao4oostujiizDGKOOMNNZo44045qjjjjz2uKJ/PsroYZAsPgjhG0MSiWGSLzIpBZAmOqnklEpCSeWV6q22jJQnajmGlyutBmaWkXA5Uo5WzkQdPGNumcRndKQZiZwyrknfmW6qZ+QcPGHp54tt/inooIQWYWahhxaq6KKMNkqlnSVCuk+gtCTqqFWXZqopJJRuaiOdf1q6TBAAIfkEBQUADQAsSAAxADoAIgAAB/+AAIKDhIWGhAYaFBQaCQOHkJGSk4URNTSYNDURApSen5EEl5mYNQSgqKkWpKQWqa+eFKyZFLC2kR6zmLWoAp2QBhsbp6C5uryfDh8fEo+EAwUB0gERxbo0yJMCJUFD3igLvwMW09MXn8az2ZECJN7vQz4Ojw7l0xa/k+ms65AbO/DesSAggJw9adUo7SPVz9AAGAHf9Thl8KAGYpIW0qIkwUhEbz5O1TsorYDCaw0RpfjoTUUnAhpISkugD6U+lkOMmBS0QGYACQ2CCh3aQOMuSQd44KyRb0BMmRsy2oQ04AbOHecIbfCpIZ8ho9giOUCCk4MhAQh8LsA11RABGjjuc2AkdIDrXEJgU2roxjJApGgyGUDKe8gABJwznB2C6fPAIcKFBCjAKWStpAg+JXgVBFlrEZwlNjuseLDD17aCBtjA6YMmpa0yNSjmjBpAASE4FXxC69NBoc4ACKjACeSupAQ+AxggJOsYoQA4g7hCNZIkAkKrdEkYNAAIThazPTGWaWDoKFKmBkFnKSRhKsxQCVlC7x7AB5w3BBDdz79BQZmOEUKABYtYsBwhk31URHn9NShUXRaJdhxZEXng4IUN2GaPBgGiQgFu8MgwAIYXClBdAcZ9goAL3gTBQgIkkiiAAeG9QkAEFmygH4mBAAAh+QQFBQASACw3ADEAWgBaAAAG/0CAcEgsGo9I42CBQDgIgqR0Sq1aq4dRY9sYXa7gsPg60HK3o8F4zV4vzudIe06fIuBcRn3PF97xDXpiEoSFhoeIiYqLjIh/eIJWHR4jDgKNmJmai49wDJskECKjJRubp6iMnWeRUyCjsCIoHZeptqmreVgpsbA3arfBmrlbrUgCH72wMwPCzo3EgVQOK8qjKM3P2o6A0lIEJtajMdvlhtHGRgHiIisR5qgI0N3pRAkq7BnwqR1S6EkCKrCTcaBPkg63/iHpwEsciH3wFCrBwY5FNojbJBYpwE6EPIzlNA4hAIOdjVogtYkU8oDdCoQpM9IzcmAGuwYAYsoEZEwACfJ2KAxsgwlSZIRq4jDoDDlzyAAb7E5cXJrowKZoCIgwYAehgLCPVCVE6CZHiIAT7G6gvNUBrE4BZs6kGYKAXYoLz9wuzSK34BAP7BTkDFtOQIQmC9QQaWltBgHCYQ007BUAMmENSGGZWFuIqE4EVjEuqOFLqGXIAzYUCH269TPPrmPLnk27tu3b/Qwagb33tu/fwIMLH068uPHjyJMrX868ufPn0KNLn069uvXr2LPv4x1RO6rcuolw906+vPnz6KWzbq03vfv38OPLbzQ+O9j21/Ue2LCeev35AAYooGX9xYSfdv+5l+CAmBw4W4HbQBhMEAAh+QQFBQAOACw3ADEAXABnAAAH/4AAgoOEhYaHiIYCFxERFwKJkZKTlJWWAAYWAZsBFgaXoKGilAKanJsWkKOrrKEXp6cXrbO0kR2wnB21u7wAEbibHQ7DxMXGx8jJysvMzcW/wLqWBxoaws7Y2cTSlNC43JMYJSbkFQkA2unqyd6w4JES5PImNwfr6Qv3w+2n74gGMebJ8yBAn8Fs/HI5AyFQHo6DEJslDDZpw7iGJnAUjMjx2MQA/goNUICR3Ah0HVPuAwZSUoGSJkpcUKlOArOPIQcRmAATA0qaHXEuCwAzhgGgKnEmOhCwpAWkSVnmFOABZoaNUDkqPdQBpokIWVNuFckBZoWwYqUeYgCzhD20Wv/VFjKAoyfcoFKPYYB5g8BdZTMRyh10wQZMBJcMgOCAwe/fZ4MBCBgBk4OqSQYq/NjBGUg+jgmy3YpGKELbnIUIaHDBufUOEY6Xfe74CljgYWVLjmgmYAEN18AtA7D519SpVINMl7RxLtEiHD2AAxcxoOO1ZpmOfxqkAWaASAZG5JAunUfsrLeJXejg6LIgBCVxDEBEwIIM8uRdEFjEMb2+AU0JVMAhAkTwAn74jVDdY9gUcJE8ChwjwAEZ8ICgdD7IZ5AEoSF1QQPyjEBAaiCIcKF0KBSAVTH+MWiMAAl0sN0gAjCgwonA6QDCgspc5yJ2JfiAY2s9fHDUjxwJkML/kK3B0MGKNMnSiyENMLmDCxJAqU2LSDrQwpA/KNglTV9e2AMOHY6pUgYX0rCAe7uk+eMBIZAHgQZaqtmRABgI2VoICpynJ1ACSKBCCCLEIOWUjM4iwKODRirppJRWaumlmGaq6aacdurpp6CGKuqopJZq6qmopqrqhqu26updXGoa66izvnqXj6fiaitacv5IXKq10sZpsNkQG1YHLRr716KIjGYbR6gJouyuB80W1rSiOuvOXb8O021HCxSibT+FWGtQet8Ok8AGvTaD7bgKFQsKtkDBGwy19oIELFd57Zqvrqv+u067aKXrjMD+9msrwgsrnIzBkjaXyL+SEOwpMcOvYuyqxpWamw7H2ngMayUUU0JvpCVTAjCD9IKsasqNxkyyw9Qac3LNOOO83sp3BQIAOw==";
		$scope.elegido=false;
		$scope.cargaFotos=false;
		$scope.rangoAnt=null;
		var intento = 0;
		var nombreArchivoFoto = null;
		
		$scope.muestraDetalle = [];
		var balloonUnique = false;
		$scope.currentPage= 0;
		
	    $scope.pageSize = 8;
	    var ifefrente = "";
		var ifereverso = "";
		var timer = null;
		$scope.filtro={};
		$scope.filtro={texto:""};
		
		$scope.daysIni = dias;
		$scope.daysFin = dias;
		$scope.monthsIni = meses;
		$scope.monthsFin = meses;
		$scope.yearsIni = [];
		$scope.yearsFin = [];
		for(var i=(new Date().getFullYear());i > new Date().getFullYear() - 5;i--){
			$scope.yearsIni.push(""+i);
			$scope.yearsFin.push(""+i);
		}
		var fechaDia = new Date();
		var dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
		var mm = ((fechaDia.getMonth() + 1) < 10 ? '0' : '') + (fechaDia.getMonth() + 1); 
		var aa = fechaDia.getFullYear();
		$scope.nDiaIni=dd;
		$scope.nDiaFin=dd;
		$scope.nMesIni=mm;
		$scope.nMesFin=mm;
		$scope.nAnnoIni=aa;
		$scope.nAnnoFin=aa;
	    
	    $scope.init = function (){
	    	if( messageData ){
	    		$scope.setContentPage();			
	    		$scope.cambio=true;
//	    		$scope.obtieneSolicitudes(1);
	    		$timeout(function(){
	    			$scope.showPage = messageData;
	    		});
	    		
	    	}
	    };
	    
		$scope.setContentPage = function(){
	    	if (configuracion.origen.tienda)
				$scope.origen="TIENDA";
			else
				$scope.origen="WEB";
	    	generalService.setMapping(  MODEL_VISTAS_JSON );
//	    	$scope._titulo      = generalService.getDataInput("BUZON EXPEDIENTES","TITULO", $scope.origen);
	    	$scope._titulo={
	    		texto: "Solicitudes Levantadas",
	    		estilo: "verdeV",
	    		imagen: "images/header/buzon.png"
	    	}
	    	
	    	ifefrente = IDENTIFICACION_OFICIAL.descripcion + " " + CLIENTE.descripcion +" " + generalService.getDatafromCategory("SIMULADOR", "ETIQUETA FRENTE", "VALOR.valor" );;
			ifereverso = IDENTIFICACION_OFICIAL.descripcion + " " + CLIENTE.descripcion +" " + generalService.getDatafromCategory("SIMULADOR", "ETIQUETA REVERSO", "VALOR.valor" );
			
	    	$scope._tabEntInmd  = generalService.getDataInput("BUZON EXPEDIENTES","TEXTO ENTREGA INMEDIATA", $scope.origen);
	    	$scope._tabInvDomic = generalService.getDataInput("BUZON EXPEDIENTES","TEXTO INVESTIGACION", $scope.origen);
	    	$scope.timeRojo     = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.BUZON EXPEDIENTES.IMG RELOJ ROJO.URL.valor"];
	 	    $scope.timeAmarillo = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.BUZON EXPEDIENTES.IMG RELOJ AMARILLO.URL.valor"];
	 	    $scope.timeVerde    = MODEL_VISTAS_JSON["FRONT PRESTAMOS PERSONALES.BUZON EXPEDIENTES.IMG RELOJ VERDE.URL.valor"];
	 	    $scope.clienteUnico = generalService.getDataInput("BUZON EXPEDIENTES","TEXTO CU", $scope.origen);
	 	    $scope.txtRegresar = generalService.getDataInput("OCHO PASOS","TEXTO BOTON REGRESAR", $scope.origen);
	    	$scope.tabs = [{
	    		cont: 0,
	            title: "En seguimiento",
	            url: 'una.tpl.html'
	        }, {
	        	cont: 0,
	            title: "Autorizadas",
	            url: 'dos.tpl.html'
	        }, {
	        	cont: 0,
	            title: "Rechazadas",
	            url: 'tres.tpl.html'
	        }, {
	        	cont: 0,
	            title: "Mal zonificadas",
	            url: 'cuatro.tpl.html'
	        },{
	        	cont: 0,
	            title: "Cambaceo",
	            url: 'cinco.tpl.html'
	        }];
	    };
	    
	    $scope.obtieneSolicitudes = function(rango){
	    	//SE AGREGAN PARA VALIDACION DE FECHA INICIAL Y FINAL-INI
//	    	if(rango != $scope.rangoAnt){
	    	if($scope.cambio && validaFechas()){
	    		$scope.cambio=false;
	    	//SE AGREGAN PARA VALIDACION DE FECHA INICIAL Y FINAL-FIN
	    		$scope.filtro.texto="";
	    		$scope.cargaFotos=false;
	    		$scope.rangoAnt=rango;
		    	$scope.filtroSeleccionado=rango;
		    	$scope.currentTab = '';
		    	for (var ind=0;ind<$scope.tabs.length;ind++){
		    		$scope.tabs[ind].cont = 0;
		    	}
				$scope.solicitudes = [];
				$scope.solSeguimiento = [];
				$scope.solAutorizadas = [];
				$scope.solRechazadas = [];
				$scope.solZonificadas = [];
				$scope.solCambaceo = [];
				$scope.filterSolSeguimiento = [];
				$scope.filterSolAutorizadas = [];
				$scope.filterSolRechazadas = [];
				$scope.filterSolZonificadas = [];
				$scope.filterCambaceo = [];
				$scope.existeSolicitudes = false;
				$scope.existeSolSeguimiento = false;
				$scope.existeSolAutorizadas = false;
				$scope.existeSolRechazadas = false;
				$scope.existeSolZonificadas = false;
				$scope.existeCambaceo = false;
				$scope.mensajeNoSolicitudes = false;
				$scope.cantSolicitudes=0;
				generalService.buildSolicitudJson($rootScope, null);
				var fechaInicial = new Date();
				var fechaDia = new Date();
				var dd = (fechaDia.getDate() < 10 ? '0' : '') + fechaDia.getDate();
				var mm = ((fechaDia.getMonth() + 1) < 10 ? '0' : '') + (fechaDia.getMonth() + 1); 
				var aa = fechaDia.getFullYear();
				var ddIni = null;
				var mmIni = null;
				var aaIni = null;
				var r = {fechaInicial: "", fechaFinal: "",sucursal:null};
				//SE AGREGA PARA VALIDACION DE FECHA INICIAL Y FINAL-INI
				r.fechaInicial= $scope.nDiaIni+"/"+$scope.nMesIni+"/"+$scope.nAnnoIni;
				r.fechaFinal= $scope.nDiaFin+"/"+$scope.nMesFin+"/"+$scope.nAnnoFin;
				//SE AGREGA PARA VALIDACION DE FECHA INICIAL Y FINAL-FIN
		    	//SE COMENTA PARA VALIDACION DE FECHA INICIAL Y FINAL-INI
//				switch(rango){
//					case 0:
//						r.fechaFinal="";
//						r.fechaInicial= "";
//						break;
//					case 1:
//						r.fechaFinal= dd+"/"+mm+"/"+aa;
//						r.fechaInicial= dd+"/"+mm+"/"+aa;
//						break;
//					case 2:
//						r.fechaFinal= dd+"/"+mm+"/"+aa;
//						fechaInicial.setDate(fechaDia.getDate() - (fechaDia.getDay() - 1));
//						ddIni = (fechaInicial.getDate() < 10 ? '0' : '') + fechaInicial.getDate();
//						mmIni = ((fechaInicial.getMonth() + 1) < 10 ? '0' : '') + (fechaInicial.getMonth() + 1); 
//						aaIni = fechaInicial.getFullYear();
//						r.fechaInicial= ddIni+"/"+mmIni+"/"+aaIni;
//						break;
//					case 3:
//						r.fechaFinal= dd+"/"+mm+"/"+aa;
//						r.fechaInicial= "01/"+mm+"/"+aa;
//						break;
//				}
				//SE COMENTA PARA VALIDACION DE FECHA INICIAL Y FINAL-INI
				if($rootScope.userSession.idPuesto == PUESTO_GERENTE || $rootScope.userSession.idPuesto == PUESTO_GERENTE_COMERCIO || $rootScope.userSession.idPuesto == PUESTO_SUBGERENTE_COMERCIO)
					r.sucursal=$rootScope.sucursalSession.idSucursal;
				$rootScope.waitLoaderStatus = LOADER_SHOW;
				solicitudService.solicitudesAsesor(r).then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						if (data.data.codigo == RESPONSE_CODIGO_EXITO){
							var jsonRespuesta = JSON.parse(data.data.respuesta);
							if (jsonRespuesta.codigo == 2){
								$scope.ind = 0;
								$scope.arrayCU=[];
								var arrayCAAAAU=[];
								for(var i = 0; i < jsonRespuesta.data.length; i++) {
									if(jsonRespuesta.data[i].solicitudObligado != "" && jsonRespuesta.data[i].solicitudObligado != undefined){
										arrayCAAAAU.push(jsonRespuesta.data[i]);
									}
									
									
									/**
									 *Se colocan la descripciones de estatus correspondiente a las marcas
									 */
									if(jsonRespuesta.data[i].idStatuSeguimiento == 3 && (jsonRespuesta.data[i].idEtiqueta == 93  || jsonRespuesta.data[i].idEtiqueta == 103 || jsonRespuesta.data[i].idEtiqueta == 104 
											|| jsonRespuesta.data[i].idEtiqueta == 1034 || jsonRespuesta.data[i].idEtiqueta == 1035 || jsonRespuesta.data[i].idEtiqueta == 1038 ||
											jsonRespuesta.data[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.diaDePagoSeleccionado || jsonRespuesta.data[i].idEtiqueta == STATUS_SOLICITUD.autorizada.marca.tipoDispersionSeleccionado))
										jsonRespuesta.data[i].status = "Sol. en Proceso";
									
									if (jsonRespuesta.data[i].idStatuSeguimiento == 3  ||
										jsonRespuesta.data[i].idStatuSeguimiento == 6  ||
										jsonRespuesta.data[i].idStatuSeguimiento == 9  ||
										jsonRespuesta.data[i].idStatuSeguimiento == 5  ||
										jsonRespuesta.data[i].idStatuSeguimiento == 14  ||										
										jsonRespuesta.data[i].idStatuSeguimiento == 30 ||
										jsonRespuesta.data[i].idStatuSeguimiento == 34 ||
										jsonRespuesta.data[i].idStatuSeguimiento == 39 ||
										jsonRespuesta.data[i].idStatuSeguimiento == 68  ||
										jsonRespuesta.data[i].idStatuSeguimiento == 185 ||
										jsonRespuesta.data[i].idStatuSeguimiento == STATUS_SOLICITUD.reprogramada.id ||
										jsonRespuesta.data[i].idStatuSeguimiento == STATUS_SOLICITUD.preRechazada.id ||
										jsonRespuesta.data[i].idStatuSeguimiento == STATUS_SOLICITUD.mas120mts.id ||
										jsonRespuesta.data[i].idStatuSeguimiento == STATUS_SOLICITUD.investigacionGCCDom.id ||
										jsonRespuesta.data[i].idStatuSeguimiento == STATUS_SOLICITUD.menos30min.id){
										$scope.solicitudes.push(jsonRespuesta.data[i]);
										if($scope.solicitudes[$scope.ind].cu == "---"){
											$scope.arrayCU[$scope.ind] = {
												idSolicitud: $scope.solicitudes[$scope.ind].solicitud,
												tipo: 1
											};
										}else{
											$scope.arrayCU[$scope.ind] = {	    			
									    		pais: parseInt($scope.solicitudes[$scope.ind].cu.split('-')[0]),
									    		canal: parseInt($scope.solicitudes[$scope.ind].cu.split('-')[1]),
									    		sucursal: parseInt($scope.solicitudes[$scope.ind].cu.split('-')[2]),
									    		folio: parseInt($scope.solicitudes[$scope.ind].cu.split('-')[3]),
									    		width: 60,
									    		tipo: 2
											};
										}
										$scope.ind++;
									}
								}
								if($scope.solicitudes.length > 0){
									$scope.existeSolicitudes = true;
									for(var i = 0; i < $scope.solicitudes.length; i++){
										if ($scope.solicitudes[i].materno == null){
											$scope.solicitudes[i].materno = "";
										}
										$scope.descripcionImg = null;
										$scope.muestraAlertaCodigoEdicion=false;
										switch($scope.solicitudes[i].idEtiqueta){
											case STATUS_SOLICITUD.autorizada.marca.liberacionAplicada:
												$scope.solicitudes[i].status = "Autorizado";
												$scope.descripcionImg="images/status/icon_autorizado.png";
												$scope.muestraAlertaCodigoEdicion=true;
											break;
											case STATUS_SOLICITUD.autorizada.marca.pendienteDeSurtir:
												$scope.solicitudes[i].status = "Autorizado";
												$scope.descripcionImg="images/status/icon_autorizado.png";
												$scope.muestraAlertaCodigoEdicion=true;
											break;
										}											
										if($scope.solicitudes[i].idStatuSeguimiento == STATUS_SOLICITUD.pendienteProceso.id)
											$scope.solicitudes[i].status="Pendiente Cotizar";
										
										if($scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.autorizada.marca.clienteVerdeJVC && $scope.solicitudes[i].idStatuSeguimiento == STATUS_SOLICITUD.autorizada.id)
											$scope.solicitudes[i].status = "Autorizado";
										
/** INICIA_OS-FLUJO COACREDITADO **/
										if( ( $scope.solicitudes[i].idStatuSeguimiento == STATUS_SOLICITUD.generada.id || $scope.solicitudes[i].idStatuSeguimiento == STATUS_SOLICITUD.preautorizada.id ) && 
											( $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescate || 
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescateFDos ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.clienteAplicaMiniRescateFCuatro || 
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.clienteAceptoProductoCosumo ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.aplicaRescateItalikaScore || 
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.aplicaRescateItalikaKnockOut ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.aplicaRescateItalikaKnockOutScore ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.rescateItalika ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.clienteAceptoProductoCosumoSinOS ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.aplicaRescateTelefoniaScore || 
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.aplicaRescateTelefoniaKnockOut ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.aplicaRescateTelefoniaKnockOutYScore ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.prodResTelefoniaConOS || 
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.prodResTelefoniaSinOS ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.prodResTelefoniaSinOSSegundaOferta ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.prodResPrestamoConGarantias ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.prodResPrestamoConOS ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.prodResPrestamoKO ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.prodResPrestamoMatriz ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.prodResPrestamoMatrizKO ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.prodRescatePPPrestamo ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.prodRescatePPSinPrestamo ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.prodRescateConsumoOferta ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.prodRescateItalikaOferta ||
											  $scope.solicitudes[i].idEtiqueta == STATUS_SOLICITUD.generada.marca.prodRescateTelefoniaOferta))
											$scope.solicitudes[i].status = "Sol. en Proceso";
										
										if( $scope.solicitudes[i].requeridoObligado == 1 && $scope.solicitudes[i].idStatuSeguimiento != STATUS_SOLICITUD.rechazada.id && ( 
												$scope.solicitudes[i].idStatuSeguimientoObligado == STATUS_SOLICITUD.investigacion.id || 
												$scope.solicitudes[i].idStatuSeguimientoObligado == 102 ||
												$scope.solicitudes[i].idStatuSeguimientoObligado == 103 ||
												$scope.solicitudes[i].idStatuSeguimientoObligado == 17 ))
												$scope.solicitudes[i].status = "En espera visita Coacreditado";
											
										if( $scope.solicitudes[i].requeridoObligado == 1 && $scope.solicitudes[i].idStatuSeguimiento != STATUS_SOLICITUD.rechazada.id && ($scope.solicitudes[i].idStatuSeguimientoObligado == STATUS_SOLICITUD.rechazada.id || $scope.solicitudes[i].idStatuSeguimientoObligado == STATUS_SOLICITUD.cancelada.id))
											$scope.solicitudes[i].status = "Condicionado a otro  Coacreditado";
										
/** TERMINA_OS-FLUJO COACREDITADO **/
										if($scope.solicitudes[i].idEtiqueta == 126 && $scope.solicitudes[i].idStatuSeguimiento != STATUS_SOLICITUD.rechazada.id)
											$scope.solicitudes[i].status = "Sol. en Proceso";
						    		
										switch( $scope.solicitudes[i].idEtiqueta ){
										case STATUS_SOLICITUD.generada.marca.generadaCambaceo:
						    			case STATUS_SOLICITUD.generada.marca.verificacionCambaceo:
						    			case STATUS_SOLICITUD.generada.marca.rescateCambaceo:
						    			case STATUS_SOLICITUD.preautorizada.marca.inmediatoCambaceo:
						    			case STATUS_SOLICITUD.pendienteProceso.marca.alternativaCambaceo:
						    				$scope.solicitudes[i].status = "Pre Autorizada cambaceo";
						    				break;
						    			case STATUS_SOLICITUD.rechazada.marca.rechazoCambaceo:
						    				$scope.solicitudes[i].status = "Rechazado Cambaceo";
						    				break;
						    			}
							    			
										switch($scope.solicitudes[i].idEtiqueta){
											case STATUS_SOLICITUD.generada.marca.generadaCambaceo:
											case STATUS_SOLICITUD.generada.marca.verificacionCambaceo:
											case STATUS_SOLICITUD.generada.marca.rescateCambaceo :
											case STATUS_SOLICITUD.preautorizada.marca.inmediatoCambaceo:
											case STATUS_SOLICITUD.pendienteProceso.marca.alternativaCambaceo:
											case STATUS_SOLICITUD.rechazada.marca.rechazoCambaceo:
												$scope.tabs[4].cont++;
												$scope.solCambaceo.push({
													idSolicitud : $scope.solicitudes[i].solicitud,
													nombre : generalService.camelize($scope.solicitudes[i].nombre + " " + $scope.solicitudes[i].paterno + " " + $scope.solicitudes[i].materno),
													clienteUnico: $scope.solicitudes[i].cu,
													fotoCte : "data:image/png;base64,"+$scope.loadingFoto,
													celular: $scope.solicitudes[i].celular,
													status: $scope.solicitudes[i].status,
													fecha: $scope.solicitudes[i].fecha.substring(0,10).split('-')[2] + "/" + $scope.solicitudes[i].fecha.split('-')[1] + "/" + $scope.solicitudes[i].fecha.split('-')[0],
													marcaID: $scope.solicitudes[i].idEtiqueta,
													idStatuSeguimiento:$scope.solicitudes[i].idStatuSeguimiento,
													ultima:$scope.solicitudes[i].ultima,
													solicitud:$scope.solicitudes[i],
													mostrar: true/* I-MODIFICACION TDC*/
												
												});
												continue;
												break;
										}
										
										switch($scope.solicitudes[i].idStatuSeguimiento){
											case STATUS_SOLICITUD.generada.id:
											case STATUS_SOLICITUD.investigacion.id:
											case STATUS_SOLICITUD.condicionada.id:
											case STATUS_SOLICITUD.mesaControl.id:	
											case STATUS_SOLICITUD.pendienteProceso.id:
											case STATUS_SOLICITUD.preautorizada.id:
											case STATUS_SOLICITUD.reprogramada.id:
											case STATUS_SOLICITUD.preRechazada.id:
											case STATUS_SOLICITUD.mas120mts.id:
											case STATUS_SOLICITUD.investigacionGCC.id:
											case STATUS_SOLICITUD.investigacionGCCDom.id:
											case STATUS_SOLICITUD.menos30min.id:
												$scope.tabs[0].cont++;
												$scope.solSeguimiento.push({
													idSolicitud : $scope.solicitudes[i].solicitud,
													nombre : generalService.camelize($scope.solicitudes[i].nombre + " " + $scope.solicitudes[i].paterno + " " + $scope.solicitudes[i].materno),
													clienteUnico: $scope.solicitudes[i].cu,
													fotoCte : "data:image/png;base64,"+$scope.loadingFoto,
													celular: $scope.solicitudes[i].celular,
													status: $scope.solicitudes[i].status,
													fecha: $scope.solicitudes[i].fecha.substring(0,10).split('-')[2] + "/" + $scope.solicitudes[i].fecha.split('-')[1] + "/" + $scope.solicitudes[i].fecha.split('-')[0],
													idStatuSeguimiento:$scope.solicitudes[i].idStatuSeguimiento,
													ultima:$scope.solicitudes[i].ultima,
													solicitud:$scope.solicitudes[i],
													mostrar: true /*I-MODIFICACION TDC*/
												});
												break;
											case STATUS_SOLICITUD.autorizada.id:
												$scope.tabs[1].cont++;
												$scope.solAutorizadas.push({
													idSolicitud : $scope.solicitudes[i].solicitud,
													nombre : generalService.camelize($scope.solicitudes[i].nombre + " " + $scope.solicitudes[i].paterno + " " + $scope.solicitudes[i].materno),
													clienteUnico: $scope.solicitudes[i].cu,
													fotoCte : "data:image/png;base64,"+$scope.loadingFoto,
													celular: $scope.solicitudes[i].celular,
													status: $scope.solicitudes[i].status,
													marcaID: $scope.solicitudes[i].idEtiqueta,
													fecha: $scope.solicitudes[i].fecha.substring(0,10).split('-')[2] + "/" + $scope.solicitudes[i].fecha.split('-')[1] + "/" + $scope.solicitudes[i].fecha.split('-')[0],
													idStatuSeguimiento:$scope.solicitudes[i].idStatuSeguimiento,
													ultima:$scope.solicitudes[i].ultima,
													solicitud:$scope.solicitudes[i],
													mostrar: true/* I-MODIFICACION TDC*/
												});
												break;
											case STATUS_SOLICITUD.rechazada.id:
												$scope.tabs[2].cont++;
												$scope.solRechazadas.push({
													idSolicitud : $scope.solicitudes[i].solicitud,
													nombre : generalService.camelize($scope.solicitudes[i].nombre + " " + $scope.solicitudes[i].paterno + " " + $scope.solicitudes[i].materno),
													clienteUnico: $scope.solicitudes[i].cu,
													fotoCte : "data:image/png;base64,"+$scope.loadingFoto,
													celular: $scope.solicitudes[i].celular,
													status: $scope.solicitudes[i].fcmotivorechazo,
													motivo: $scope.solicitudes[i].observacion_jvc,
													fecha: $scope.solicitudes[i].fecha.substring(0,10).split('-')[2] + "/" + $scope.solicitudes[i].fecha.split('-')[1] + "/" + $scope.solicitudes[i].fecha.split('-')[0],
													idStatuSeguimiento:$scope.solicitudes[i].idStatuSeguimiento,
													ultima:$scope.solicitudes[i].ultima,
													solicitud:$scope.solicitudes[i],
													mostrar: true/* I-MODIFICACION TDC*/
												});
										 	   break;
											case STATUS_SOLICITUD.malZonificada.id:
												$scope.tabs[3].cont++;
												$scope.solZonificadas.push({
													idSolicitud : $scope.solicitudes[i].solicitud,
													nombre : generalService.camelize($scope.solicitudes[i].nombre + " " + $scope.solicitudes[i].paterno + " " + $scope.solicitudes[i].materno),
													clienteUnico: $scope.solicitudes[i].cu,
													fotoCte : "data:image/png;base64,"+$scope.loadingFoto,
													celular: $scope.solicitudes[i].celular,
													status: $scope.solicitudes[i].status,
													fecha: $scope.solicitudes[i].fecha.substring(0,10).split('-')[2] + "/" + $scope.solicitudes[i].fecha.split('-')[1] + "/" + $scope.solicitudes[i].fecha.split('-')[0],
													idStatuSeguimiento:$scope.solicitudes[i].idStatuSeguimiento,
													ultima:$scope.solicitudes[i].ultima,
													solicitud:$scope.solicitudes[i],
													mostrar: true/* I-MODIFICACION TDC*/
												});
										 	   break;
										}
									}
									$scope.filterSolSeguimiento = $scope.solSeguimiento;
									$scope.filterSolAutorizadas = $scope.solAutorizadas;
									$scope.filterSolRechazadas = $scope.solRechazadas;
									$scope.filterSolZonificadas = $scope.solZonificadas;
									$scope.filterCambaceo = $scope.solCambaceo;
									if($scope.solSeguimiento.length > 0){
								    	$scope.existeSolSeguimiento = true;
										$scope.cantSolicitudes = $scope.solSeguimiento.length;
										$scope.numberOfPages = Math.ceil($scope.cantSolicitudes/$scope.pageSize);
								    }else
										$scope.mensajeNoSolicitudes = true;
									if($scope.solAutorizadas.length > 0)
										$scope.existeSolAutorizadas = true;
									if($scope.solRechazadas.length > 0)
										$scope.existeSolRechazadas = true;
									if($scope.solZonificadas.length > 0)
										$scope.existeSolZonificadas = true;
									if($scope.solCambaceo.length > 0)
										$scope.existeCambaceo = true;
									$timeout( function(){
										$scope.currentTab = 'una.tpl.html';
							// I-MODIFICACION TDC (FILTRAR POR PRODUCTO)
										$scope.filtraId($scope.currentTab);
							// F-MODIFICACION TDC (FILTRAR POR PRODUCTO)										
										$scope.cargaFotos=true;
										$scope.obtieneFoto(0,0,0,0,0,0);
									}, 1);/* END TIMEOUT */
								}else
									$scope.mensajeNoSolicitudes = true;
							}else
								$scope.mensajeNoSolicitudes = true;
						}else
							$scope.mensajeNoSolicitudes = true;
					},function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;						
					}
				);
	    	}
		};
		
		function validaFechas(){
			var fechaDelDia=aa+"-"+mm+"-"+dd;
			var fechaInicial= $scope.nAnnoIni+"-"+$scope.nMesIni+"-"+$scope.nDiaIni;
			var fechaFinal= $scope.nAnnoFin+"-"+$scope.nMesFin+"-"+$scope.nDiaFin;
			if(fechaInicial > fechaDelDia || fechaFinal > fechaDelDia){
				$rootScope.message( "Error validar fecha", ["No se puede seleccionar una fecha futura."], "Aceptar");
				return false;
			}else{
				if(fechaInicial > fechaFinal){
					$rootScope.message( "Error validar fecha", ["Fecha Inicial inválida."], "Aceptar");
					return false;
				}else
					return true;
			}
		};
	    
		$scope.alertList = function(titulo, mensaje){
				modalService.alertModal(titulo,[mensaje]);								
		};
		
		$scope.mostrar = function(div, idSolicitud,condicion){
			
			var isDefined = true;
			for(var i=0;isDefined;i++){
				var elementoDivMesa = document.getElementById('detalle'+ i);
				
				if(elementoDivMesa){
					if(div != i){
						elementoDivMesa.className = "detalle ng-hide";
						balloonUnique = false;
					}
				}else{
					isDefined = false
				}
			}
			
				var element = document.getElementById('detalle'+ div);
		        if(element.className == "detalle ng-show"){	        	
		            element.className = "detalle ng-hide"
		            
		            	if(balloonUnique) {
		            		balloonUnique = false;
		            	}
		        }else{	        	
		        	if(!balloonUnique && condicion ==1) {
		        		generalService.buildSolicitudJson($rootScope, $rootScope.solicitudJson);

			 			solicitudService.getSolicitud( idSolicitud ).then(
			 					function(data){
			 						if(data.data.codigo == undefined)
			 							validateService.error(data);

			 						else if(data.data.codigo == RESPONSE_CODIGO_EXITO){
			 							var j = JSON.parse(data.data.respuesta);
			 							$rootScope.solicitudJson = j.data;
			 							
			 							if($rootScope.solicitudJson.documentos.documento.length == 0){
		 									$scope.docs = false;
		 								}else{
		 									$scope.docs = true;
		 								}
			 							
			 							angular.forEach( $rootScope.solicitudJson.documentos.documento, function(doc, key){
			 								$scope.docStatus = doc.status;
			 								$scope.docObs = doc.observacion;
			 								$scope.docDesc = doc.documentoDes;		 								
			 							});
			 							
			 						}else{
			 						}
			 					}, function(error){
			 																		
			 					}
			 			);	
			 			
			            element.className = "detalle ng-show"
			            balloonUnique = true;
		        	}
		        	else{
		        		balloonUnique=false;
		        	}
		        }
		    }
		
		$scope.pagSeguimiento= function(estado){
			if(estado){
				$scope.currentPage = $scope.currentPage + 1;
			}else{
				$scope.currentPage = $scope.currentPage - 1;
			}
			balloonUnique = false;
		}		
		
		$scope.obtieneFoto = function(indArrayCU,indArraySolSeguimiento,indArraySolAutorizadas,indArraySolRechazadas,indArraySolZonificadas, indArrayCambaceo){
			if($scope.ind > indArrayCU){
				switch($scope.solicitudes[indArrayCU].idStatuSeguimiento){
					case STATUS_SOLICITUD.generada.id:
					case STATUS_SOLICITUD.investigacion.id:
					case STATUS_SOLICITUD.condicionada.id:
					case STATUS_SOLICITUD.mesaControl.id:	
					case STATUS_SOLICITUD.pendienteProceso.id:
					case STATUS_SOLICITUD.preautorizada.id:
					case STATUS_SOLICITUD.reprogramada.id:
					case STATUS_SOLICITUD.preRechazada.id:
					case STATUS_SOLICITUD.mas120mts.id:
					case STATUS_SOLICITUD.menos30min.id:
						if($scope.arrayCU[indArrayCU].tipo == 2){
							delete $scope.arrayCU[indArrayCU].tipo;
//							$scope.solSeguimiento[indArraySolSeguimiento].fotoCte = "data:image/png;base64,"+$scope.loadingFoto;
							clienteUnicoService.getFotoCU($scope.arrayCU[indArrayCU]).then(
								function(data){
									if($scope.cargaFotos){
										if(data.data.codigo == RESPONSE_CODIGO_EXITO){
											$scope.resp=JSON.parse(data.data.respuesta);
											if( !generalService.isEmpty($scope.resp.data) )
												$scope.solSeguimiento[indArraySolSeguimiento].fotoCte="data:image/png;base64,"+$scope.resp.data;						   						   
											else
												$scope.solSeguimiento[indArraySolSeguimiento].fotoCte="data:image/png;base64,"+$scope.sombra;
										}else
											$scope.solSeguimiento[indArraySolSeguimiento].fotoCte="data:image/png;base64,"+$scope.sombra;
										if (!$scope.elegido)
											$scope.obtieneFoto( indArrayCU + 1, indArraySolSeguimiento + 1, indArraySolAutorizadas, indArraySolRechazadas, indArraySolZonificadas,indArrayCambaceo);
									}
								},function(error){
									if($scope.cargaFotos){
										$scope.solSeguimiento[indArraySolSeguimiento].fotoCte="data:image/png;base64,"+$scope.sombra;
										if (!$scope.elegido)
											$scope.obtieneFoto( indArrayCU + 1, indArraySolSeguimiento + 1, indArraySolAutorizadas, indArraySolRechazadas, indArraySolZonificadas,indArrayCambaceo);
									}
								}
							);
						}else if($scope.solicitudes[indArrayCU].idEtiqueta == STATUS_SOLICITUD.generada.marca.generadaCambaceo || 
								$scope.solicitudes[indArrayCU].idEtiqueta == STATUS_SOLICITUD.generada.marca.verificacionCambaceo ||
								$scope.solicitudes[indArrayCU].idEtiqueta == STATUS_SOLICITUD.generada.marca.rescateCambaceo  ||
								$scope.solicitudes[indArrayCU].idEtiqueta == STATUS_SOLICITUD.preautorizada.marca.inmediatoCambaceo ||
								$scope.solicitudes[indArrayCU].idEtiqueta == STATUS_SOLICITUD.pendienteProceso.marca.alternativaCambaceo ||
								$scope.solicitudes[indArrayCU].idEtiqueta == STATUS_SOLICITUD.rechazada.marca.rechazoCambaceo){
									$scope.getFoto(5,indArraySolSeguimiento,indArraySolAutorizadas, indArraySolRechazadas, indArraySolZonificadas,indArrayCambaceo,$scope.arrayCU[indArrayCU].idSolicitud,indArrayCU);
						}else
							$scope.getFoto(1,indArraySolSeguimiento,indArraySolAutorizadas, indArraySolRechazadas, indArraySolZonificadas,indArrayCambaceo,$scope.arrayCU[indArrayCU].idSolicitud,indArrayCU);
						break;
					case STATUS_SOLICITUD.autorizada.id:
						if($scope.arrayCU[indArrayCU].tipo == 2){
							delete $scope.arrayCU[indArrayCU].tipo;
//							$scope.solAutorizadas[indArraySolAutorizadas].fotoCte = "data:image/png;base64,"+$scope.loadingFoto;
							clienteUnicoService.getFotoCU($scope.arrayCU[indArrayCU]).then(
								function(data){
									if($scope.cargaFotos){
										if(data.data.codigo == RESPONSE_CODIGO_EXITO){
											$scope.resp=JSON.parse(data.data.respuesta);
											if( !generalService.isEmpty($scope.resp.data) )
												$scope.solAutorizadas[indArraySolAutorizadas].fotoCte="data:image/png;base64,"+$scope.resp.data;						   						   
											else
												$scope.solAutorizadas[indArraySolAutorizadas].fotoCte="data:image/png;base64,"+$scope.sombra;
										}else
											$scope.solAutorizadas[indArraySolAutorizadas].fotoCte="data:image/png;base64,"+$scope.sombra;
										if (!$scope.elegido)
											$scope.obtieneFoto( indArrayCU + 1, indArraySolSeguimiento, indArraySolAutorizadas + 1, indArraySolRechazadas, indArraySolZonificadas,indArrayCambaceo);
									}
								},function(error){
									if($scope.cargaFotos){
										$scope.solAutorizadas[indArraySolAutorizadas].fotoCte="data:image/png;base64,"+$scope.sombra;
										if (!$scope.elegido)
											$scope.obtieneFoto( indArrayCU + 1, indArraySolSeguimiento, indArraySolAutorizadas + 1, indArraySolRechazadas, indArraySolZonificadas,indArrayCambaceo);
									}
								}
							);
						}else
							$scope.getFoto(2,indArraySolSeguimiento,indArraySolAutorizadas, indArraySolRechazadas, indArraySolZonificadas,indArrayCambaceo,$scope.arrayCU[indArrayCU].idSolicitud,indArrayCU);
						break;
					case STATUS_SOLICITUD.rechazada.id:
						if($scope.arrayCU[indArrayCU].tipo == 2){
							delete $scope.arrayCU[indArrayCU].tipo;
//							$scope.solRechazadas[indArraySolRechazadas].fotoCte = "data:image/png;base64,"+$scope.loadingFoto;
							clienteUnicoService.getFotoCU($scope.arrayCU[indArrayCU]).then(
								function(data){
									if($scope.cargaFotos){
										if(data.data.codigo == RESPONSE_CODIGO_EXITO){
											$scope.resp=JSON.parse(data.data.respuesta);
											if( !generalService.isEmpty($scope.resp.data) )
												$scope.solRechazadas[indArraySolRechazadas].fotoCte="data:image/png;base64,"+$scope.resp.data;						   						   
											else
												$scope.solRechazadas[indArraySolRechazadas].fotoCte="data:image/png;base64,"+$scope.sombra;
										}else
											$scope.solRechazadas[indArraySolRechazadas].fotoCte="data:image/png;base64,"+$scope.sombra;
										if (!$scope.elegido)
											$scope.obtieneFoto( indArrayCU + 1, indArraySolSeguimiento, indArraySolAutorizadas, indArraySolRechazadas + 1, indArraySolZonificadas,indArrayCambaceo);
									}
								},function(error){
									if($scope.cargaFotos){
										$scope.solRechazadas[indArraySolRechazadas].fotoCte="data:image/png;base64,"+$scope.sombra;
										if (!$scope.elegido)
											$scope.obtieneFoto( indArrayCU + 1, indArraySolSeguimiento, indArraySolAutorizadas, indArraySolRechazadas + 1, indArraySolZonificadas, indArrayCambaceo);
									}
								}
							);
						}else
							$scope.getFoto(3,indArraySolSeguimiento,indArraySolAutorizadas, indArraySolRechazadas, indArraySolZonificadas,indArrayCambaceo,$scope.arrayCU[indArrayCU].idSolicitud,indArrayCU);
				 	    break;
					case STATUS_SOLICITUD.malZonificada.id:
						if($scope.arrayCU[indArrayCU].tipo == 2){
							delete $scope.arrayCU[indArrayCU].tipo;
//							$scope.solZonificadas[indArraySolZonificadas].fotoCte = "data:image/png;base64,"+$scope.loadingFoto;
							clienteUnicoService.getFotoCU($scope.arrayCU[indArrayCU]).then(
								function(data){
									if($scope.cargaFotos){
										if(data.data.codigo == RESPONSE_CODIGO_EXITO){
											$scope.resp=JSON.parse(data.data.respuesta);
											if( !generalService.isEmpty($scope.resp.data) )
												$scope.solZonificadas[indArraySolZonificadas].fotoCte="data:image/png;base64,"+$scope.resp.data;						   						   
											else
												$scope.solZonificadas[indArraySolZonificadas].fotoCte="data:image/png;base64,"+$scope.sombra;
										}else
											$scope.solZonificadas[indArraySolZonificadas].fotoCte="data:image/png;base64,"+$scope.sombra;
										if (!$scope.elegido)
											$scope.obtieneFoto( indArrayCU + 1, indArraySolSeguimiento, indArraySolAutorizadas, indArraySolRechazadas, indArraySolZonificadas + 1,indArrayCambaceo);
									}
								},function(error){
									if($scope.cargaFotos){
										$scope.solZonificadas[indArraySolZonificadas].fotoCte="data:image/png;base64,"+$scope.sombra;
										if (!$scope.elegido)
											$scope.obtieneFoto( indArrayCU + 1, indArraySolSeguimiento, indArraySolAutorizadas, indArraySolRechazadas, indArraySolZonificadas + 1,indArrayCambaceo);
									}
								}
							);
						}else
							$scope.getFoto(4,indArraySolSeguimiento,indArraySolAutorizadas, indArraySolRechazadas, indArraySolZonificadas,indArrayCambaceo,$scope.arrayCU[indArrayCU].idSolicitud,indArrayCU);
				 	    break;
				}
			}
		};
		
		$scope.getFoto = function(statusSolicitud,indArraySolSeguimiento,indArraySolAutorizadas,indArraySolRechazadas,indArraySolZonificadas,indArrayCambaceo,idSolicitud,indArrayCU){						
			var biometrico = {
					idSolicitud: idSolicitud,
					width: 60
			};
			clienteUnicoService.getFoto( biometrico ).then(
				function(data){
					if($scope.cargaFotos){
						var foto = $scope.sombra;;
						if(data.data.codigo == RESPONSE_CODIGO_EXITO){
							var j = JSON.parse(data.data.respuesta);
							if (j.codigo == 2 && j.data != null)
								foto = j.data;
						}
						switch (statusSolicitud){
							case 1:
								$scope.solSeguimiento[indArraySolSeguimiento].fotoCte="data:image/png;base64,"+foto;
								indArraySolSeguimiento=indArraySolSeguimiento + 1;
								break;
							case 2:
								$scope.solAutorizadas[indArraySolAutorizadas].fotoCte="data:image/png;base64,"+foto;
								indArraySolAutorizadas = indArraySolAutorizadas + 1;
								break;
							case 3:
								$scope.solRechazadas[indArraySolRechazadas].fotoCte="data:image/png;base64,"+foto;
								indArraySolRechazadas = indArraySolRechazadas + 1;
								break;
							case 4:
								$scope.solZonificadas[indArraySolZonificadas].fotoCte="data:image/png;base64,"+foto;
								indArraySolZonificadas = indArraySolZonificadas + 1;
								break;
							case 5:
								$scope.solCambaceo[indArrayCambaceo].fotoCte="data:image/png;base64,"+foto;
								indArrayCambaceo = indArrayCambaceo + 1;
								break;
						}
						if (!$scope.elegido)
							$scope.obtieneFoto( indArrayCU + 1, indArraySolSeguimiento, indArraySolAutorizadas, indArraySolRechazadas, indArraySolZonificadas,indArrayCambaceo);
					}
				}, function(error){
					if($scope.cargaFotos){
						switch (statusSolicitud){
							case 1:
								$scope.solSeguimiento[indArraySolSeguimiento].fotoCte="data:image/png;base64,"+$scope.sombra;
								indArraySolSeguimiento=indArraySolSeguimiento + 1;
								break;
							case 2:
								$scope.solAutorizadas[indArraySolAutorizadas].fotoCte="data:image/png;base64,"+$scope.sombra;
								indArraySolAutorizadas = indArraySolAutorizadas + 1;
								break;
							case 3:
								$scope.solRechazadas[indArraySolRechazadas].fotoCte="data:image/png;base64,"+$scope.sombra;
								indArraySolRechazadas = indArraySolRechazadas + 1;
								break;
							case 4:
								$scope.solZonificadas[indArraySolZonificadas].fotoCte="data:image/png;base64,"+$scope.sombra;
								indArraySolZonificadas = indArraySolZonificadas + 1;
								break;
							case 5:
								$scope.solCambaceo[indArrayCambaceo].fotoCte="data:image/png;base64,"+$scope.sombra;
								indArrayCambaceo = indArrayCambaceo + 1;
								break;
						}
						if (!$scope.elegido)
							$scope.obtieneFoto( indArrayCU + 1, indArraySolSeguimiento, indArraySolAutorizadas, indArraySolRechazadas, indArraySolZonificadas,indArrayCambaceo);
					}
				}
			);
		};

	    $scope.onClickTab = function (tab) {
	    	if($scope.currentTab != tab.url){
		    	$scope.currentTab = tab.url;
		    	$scope.filtro.texto="";
// I-MODIFICACION TDC (FILTRAR POR PRODUCTO)		 
		    	$scope.filtraId($scope.currentTab);
// I-MODIFICACION TDC (FILTRAR POR PRODUCTO)		    	
		    	switch($scope.currentTab){
		    	case "una.tpl.html":
		    		if($scope.existeSolSeguimiento){
			    		$scope.cantSolicitudes = $scope.solSeguimiento.length;
						$scope.numberOfPages = Math.ceil($scope.cantSolicitudes/$scope.pageSize);
						$scope.mensajeNoSolicitudes = false;
						$scope.filterSolSeguimiento = $scope.solSeguimiento;
		    		}else
		    			$scope.mensajeNoSolicitudes = true;
		    		break;
		    	case "dos.tpl.html":
		    		if($scope.existeSolAutorizadas){
			    		$scope.cantSolicitudes = $scope.solAutorizadas.length;
						$scope.numberOfPages = Math.ceil($scope.cantSolicitudes/$scope.pageSize);
						$scope.mensajeNoSolicitudes = false;
						$scope.filterSolAutorizadas = $scope.solAutorizadas;
		    		}else
		    			$scope.mensajeNoSolicitudes = true;
		    		break;
		    	case "tres.tpl.html":
		    		if($scope.existeSolRechazadas){
			    		$scope.cantSolicitudes = $scope.solRechazadas.length;
						$scope.numberOfPages = Math.ceil($scope.cantSolicitudes/$scope.pageSize);
						$scope.mensajeNoSolicitudes = false;
						$scope.filterSolRechazadas = $scope.solRechazadas;
		    		}else
		    			$scope.mensajeNoSolicitudes = true;
		    		break;
		    	case "cuatro.tpl.html":
		    		if($scope.existeSolZonificadas){
			    		$scope.cantSolicitudes = $scope.solZonificadas.length;
						$scope.numberOfPages = Math.ceil($scope.cantSolicitudes/$scope.pageSize);
						$scope.mensajeNoSolicitudes = false;
						$scope.filterSolZonificadas = $scope.solZonificadas;
		    		}else
		    			$scope.mensajeNoSolicitudes = true;
		    		break;
		    	case "cinco.tpl.html":
		    		if($scope.existeCambaceo){
			    		$scope.cantSolicitudes = $scope.solCambaceo.length;
						$scope.numberOfPages = Math.ceil($scope.cantSolicitudes/$scope.pageSize);
						$scope.mensajeNoSolicitudes = false;
						$scope.filterCambaceo = $scope.solCambaceo;
		    		}else
		    			$scope.mensajeNoSolicitudes = true;
		    		break;
		    	}
	    	}
	    }
	    
	    $scope.isActiveTab = function(tabUrl){
	    	return tabUrl == $scope.currentTab;
	    }

		$scope.solicitudElegida = function (solicitud,fotoSolicitud){
			if(solicitud.ultima == 1){
				$rootScope.fotoCte = fotoSolicitud;
				$scope.elegido=true;
				$scope.crearJsonSolicitud(solicitud);
//				$scope.getSolicitudes(solicitud.idSolicitud);
				
//				if(solicitud.idStatuSeguimiento != 9){
//					recuperaSolicitudFunction(solicitud.idSolicitud);
//				}else{
//					$rootScope.waitLoaderStatus = LOADER_SHOW;
//					solicitudService.getSolicitud( solicitud.idSolicitud ).then(
//							function(data){
//								$rootScope.waitLoaderStatus = LOADER_HIDE;
//
//								if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
//									var j = JSON.parse(data.data.respuesta);
//									$rootScope.solicitudJson = j.data;
//									$rootScope.nombreCamel=generalService.camelize($rootScope.solicitudJson.cotizacion.clientes[0].nombre);
//		                			$rootScope.apellidoPaternoCamel=generalService.camelize($rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno);
//		                			$rootScope.apellidoMaternoCamel=generalService.camelize($rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno);	                				                				                			
//		                			
//									if($rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico == "")
//										$scope.precargarSimulador($rootScope.solicitudJson);
//									else
//										recuperaSolicitudFunction(solicitud.idSolicitud);
//								}else
//									alert(data.data.descripcion);
//							}, function(error){
//								$rootScope.waitLoaderStatus = LOADER_HIDE;																				
//							}
//						);
//				}
			}
		};
		
		$scope.crearJsonSolicitud=function(solicitud){
			var selected={
				originalObject:{
						idSolicitud         :solicitud.solicitud,
						idEstatusSeguimiento:solicitud.idStatuSeguimiento,
						primerNombre        :solicitud.nombre,
						apellidoPaterno     :solicitud.paterno,
						apellidoMaterno     :solicitud.materno,
//						curp                :solicitud.,
//						rfc                 :solicitud.,
						celular             :solicitud.celular,
//						email               :solicitud.,
						status              :solicitud.status,
//						fechaNacimiento     :solicitud.,
						cu                  :solicitud.cu,
						fcPersonaID         :solicitud.fcpersonaId,
						marcaID             :solicitud.idEtiqueta,
						fiMotivoRechazoID   :solicitud.fimotivorechazoid,
						diasRechazo         :solicitud.diasRechazo,
						condicionID         :solicitud.condicionid,
						fiStatusLcrID       :solicitud.fiStatusLcrID,
						fiMotivoBloqueoID   :solicitud.fiMotivoBloqueoID,
						tieneCu             :solicitud.tieneCu,
						creditoInmediato    :solicitud.creditoInmediato,
						tipoPersona         :solicitud.tipoPersona
//						avalDe              :solicitud.,
//						fdCreateDate        :solicitud.,
//						contarjeta          :solicitud.
				}
			}
			
			/* TOLUCA */
			if (solicitud && solicitud.tipoLevantamiento == 3 && $rootScope.userSession.existeOfflineNuevoFlujoConsumo) {
				// Se levanta un Spinner.
				$rootScope.waitLoaderStatus = LOADER_SHOW;

				if (configuracion.so.windows) { // Es Güindous.
					// Se guarda el objeto para su posterior recuperación en la offline de Toluca.
					$rootScope.guardaDatosIpad('RomeoMustDie', angular.toJson(selected), false);

					// Redirigir a la aplicación de Toluca.
					$timeout(function() { window.location.replace(PORTAL_CONSUMO_TOLUCA); }, 100);

					// Ya no se continúa con el proceso.
					return;
				} else if (false && configuracion.so.ios) { // Es Aypat. TODO El wrapper aún no está listo.
					// Redirigir a la aplicación de Toluca.
					$rootScope.executeAction('', '', 
						{
							'nombre': 'redirectionToMoc',
							'carpeta': 'Originacion_Credito',
							'ruta': 'webapp/index.html',
							'jump': true,
							'data': {
								'RomeoMustDie': angular.toJson(selected)
							}
						}
					);
					
					// Ya no se continúa con el proceso.
					return;
				} else {
					console.log('What the f*ck?!');

					// Se baja un Spinner.
					$rootScope.waitLoaderStatus = LOADER_HIDE;
				}
			}
			
			recuperaSolicitudFunction(selected);
		};
		
		$scope.getSolicitudes = function(idSolicitud){						
			if($rootScope.inSession){
				$rootScope.waitLoaderStatus = LOADER_SHOW; 						 
				
				solicitudService.getSolicitudesProceso().then(
					function(data){
						$rootScope.waitLoaderStatus = LOADER_HIDE;
						
						if(data.data.codigo != undefined && data.data.codigo == RESPONSE_CODIGO_EXITO){
							var response = JSON.parse(data.data.respuesta);
							$scope.solicitudesProceso = response.data;	
							for (var i = 0; i < $scope.solicitudesProceso.length; i++) {
								if($scope.solicitudesProceso[i].idSolicitud == idSolicitud){
									var selected={
											originalObject:$scope.solicitudesProceso[i]
									}
									recuperaSolicitudFunction(selected);
									break;
								}
							}
							
						}
						
					}, function(error){
						$rootScope.waitLoaderStatus = LOADER_HIDE;																				
					}
				);			
			}
			
		};
		
		var recuperaSolicitudFunction = function(selected){
//			$rootScope.waitLoaderStatus = LOADER_SHOW;
//			var recuperasolicitud = generalService.recuperarSolicitud( selected.originalObject );
//			recuperaSolicitudService.loadSolicitud(selected.originalObject.idSolicitud, recuperasolicitud,$rootScope );
			
			generalService.setArrayValue("selectedBusqueda", selected);
			generalService.locationPath("/recuperaSolicitud");
		}
		
		$scope.precargarSimulador=function(responseJsonSolicitud){
			generalService.setArrayValue("solicitudRecuperada", true);
			generalService.buildSolicitudJson($rootScope, null);
			$rootScope.solicitudJson.cotizacion.clientes[0].nombre           = responseJsonSolicitud.cotizacion.clientes[0].nombre;
			$rootScope.solicitudJson.cotizacion.clientes[0].apellidoMaterno  = responseJsonSolicitud.cotizacion.clientes[0].apellidoMaterno;
			$rootScope.solicitudJson.cotizacion.clientes[0].apellidoPaterno  = responseJsonSolicitud.cotizacion.clientes[0].apellidoPaterno;
			$rootScope.solicitudJson.cotizacion.clientes[0].idGenero         = responseJsonSolicitud.cotizacion.clientes[0].idGenero;
			$rootScope.solicitudJson.cotizacion.clientes[0].genero           = responseJsonSolicitud.cotizacion.clientes[0].genero;
			$rootScope.solicitudJson.cotizacion.clientes[0].celular          = responseJsonSolicitud.cotizacion.clientes[0].celular;
			$rootScope.solicitudJson.cotizacion.clientes[0].email            = responseJsonSolicitud.cotizacion.clientes[0].email;
			$rootScope.solicitudJson.cotizacion.clientes[0].fechaNaciomiento = responseJsonSolicitud.cotizacion.clientes[0].fechaNaciomiento;
			generalService.locationPath("/simulador");
		};
		
//		$scope.validaHuella=function(){
//			
//			if(TEST_EMPLOYEES.indexOf($rootScope.userSession.noEmpleado.toString()) > -1 )
//				$scope.responseVerificarHuellaIpad1( {codigo:0, matches:["OK"]} );
//			
//			else{
//				if ( configuracion.origen.tienda ){
//					$rootScope.waitLoaderStatus = LOADER_SHOW;
//					$rootScope.verificarHuella( 'divVisorAsesor', 'responseVerificarHuellaIpad1', [$rootScope.solicitudJson.cotizacion.clientes[0].clienteUnico]);
//				}else{
//					if( generalService.isProduccion() )
//						$scope.abrirDialogo();
//					else											
//						$scope.responseVerificarHuellaIpad1( {codigo:0, matches:["OK"]} );
//				}																													
//			}									
//		};
//		
//		$scope.responseVerificarHuellaIpad1 = function( response ){
//			
//			try{
//				$rootScope.waitLoaderStatus = LOADER_HIDE;								
//				
//				if(response.codigo == 0){
//					if(response.matches.length == 0){
//						
//						if( !generalService.isEmpty($rootScope.solicitudJson.folioCallCenter) && $rootScope.solicitudJson.respuestaCallCenter == STATUS_CALL_CENTER_RESPONSE.SIN_RESPUESTA)
//							generalService.setArrayValue("pasoCallCenter", 'consultaCte')
//						else
//							generalService.setArrayValue("pasoCallCenter", 'init')
//													
//						generalService.setArrayValue("encolarImagenes", false);
//						generalService.setArrayValue("pathOrigen", 'visorAsesor');
//						generalService.locationPath("/callCenter");						
//						
//						
//					}else{
//						if($scope.idStatusSeguimiento == STATUS_SOLICITUD.rechazada.id){
//							solicitudService.generaSolicRechazada( {idSolicitud:$rootScope.solicitudJson.idSolicitud} );
//						}else{														
//							if( $rootScope.solicitudJson.idSeguimiento == STATUS_SOLICITUD.autorizada.id  && 
//									$rootScope.solicitudJson.marca == STATUS_SOLICITUD.autorizada.marca.expValGerente && !generalService.isEmpty($rootScope.solicitudJson.diaPago) )
//									
//									tarjetaService.checkInvetario($rootScope.solicitudJson);
//								
//							else
//								generalService.locationPath(generalService.getPathSection( $rootScope.solicitudJson, null ));
//						}
//							
//					}
//					
//				}				
//					
//			}catch(e){
//				$rootScope.waitLoaderStatus = LOADER_HIDE;				
//				$rootScope.message( "Error al verificar la huella Mis solicitudes", [e], "Aceptar", null, null, null, null, "GENERAL", "EXCEPCION COMPONENTE");
//			}									
//		};		
//
//		
//		
//	 	$scope.abrirDialogo = function(){		
//	 		$rootScope.waitLoaderStatus = LOADER_HIDE;
//	 		modalService.huellaModal("bgAzul");
//	 	};
		
	    $scope.filtrarArreglo=function(filtro,registros){
	    	var indexfiltro=null;
	    	$scope.cantSolicitudes=0;
	    	$scope.filterSolAutorizadas=[];
	    	$scope.filterSolSeguimiento=[];
	    	$scope.filterSolRechazadas=[];
	    	$scope.filterSolZonificadas=[];
	    	$scope.filterCambaceo = [];
	    	switch($scope.currentTab){
	    		case "una.tpl.html":
	    			indexfiltro	= registros.map(function(data){
	    				var indexNombre = data['nombre'].toUpperCase().indexOf(filtro);
	    				var indexCU     = data['clienteUnico'].indexOf(filtro);
	    				if( indexNombre != -1 ){
	    					$scope.filterSolSeguimiento.push( data );
	    				}else{
	    					if(indexCU != -1)
	    						$scope.filterSolSeguimiento.push( data );
	    				}
	    			});
	    			$scope.cantSolicitudes = $scope.filterSolSeguimiento.length;
	    			break;
	    		case "dos.tpl.html":
	    			indexfiltro	= registros.map(function(data){
	    				var indexNombre = data['nombre'].toUpperCase().indexOf(filtro);
	    				var indexCU     = data['clienteUnico'].indexOf(filtro);
	    				if( indexNombre != -1 ){
	    					$scope.filterSolAutorizadas.push( data );
	    				}else{
	    					if(indexCU != -1)
	    						$scope.filterSolAutorizadas.push( data );
	    				}
	    			});
	    			$scope.cantSolicitudes = $scope.filterSolAutorizadas.length;
	    			break;
	    		case "tres.tpl.html":
	    			indexfiltro	= registros.map(function(data){
	    				var indexNombre = data['nombre'].toUpperCase().indexOf(filtro);
	    				var indexCU     = data['clienteUnico'].indexOf(filtro);
	    				if( indexNombre != -1 ){
	    					$scope.filterSolRechazadas.push( data );
	    				}else{
	    					if(indexCU != -1)
	    						$scope.filterSolRechazadas.push( data );
	    				}
	    			});
	    			$scope.cantSolicitudes = $scope.filterSolRechazadas.length;
	    			break;
	    		case "cuatro.tpl.html":
	    			indexfiltro	= registros.map(function(data){
	    				var indexNombre = data['nombre'].toUpperCase().indexOf(filtro);
	    				var indexCU     = data['clienteUnico'].indexOf(filtro);
	    				if( indexNombre != -1 ){
	    					$scope.filterSolZonificadas.push( data );
	    				}else{
	    					if(indexCU != -1)
	    						$scope.filterSolZonificadas.push( data );
	    				}
	    			});
	    			$scope.cantSolicitudes = $scope.filterSolZonificadas.length;
	    			break;
	    			
	    		case "cinco.tpl.html":
	    			indexfiltro	= registros.map(function(data){
	    				var indexNombre = data['nombre'].toUpperCase().indexOf(filtro);
	    				var indexCU     = data['clienteUnico'].indexOf(filtro);
	    				if( indexNombre != -1 ){
	    					$scope.filterCambaceo.push( data );
	    				}else{
	    					if(indexCU != -1)
	    						$scope.filterCambaceo.push( data );
	    				}
	    			});
	    			$scope.cantSolicitudes = $scope.filterCambaceo.length;
	    			break;
	    	}
	    	if($scope.cantSolicitudes > 0){
	    		$scope.numberOfPages = Math.ceil($scope.cantSolicitudes/$scope.pageSize);
	    		$scope.mensajeNoSolicitudes = false;
	    	}else
	    		$scope.mensajeNoSolicitudes = true;
	    };
	    
	    
	    $scope.regresa = function(){
	    	if(configuracion.so.ios){
	    		$rootScope.executeAction("regresaMenu", "responseWrapper",{nombre:"mostrarMenu"});
	    	}else{
	    		generalService.locationPath("/menuWrapper");
	    	}
	    }
	    
	    $scope.validadias = function(dia,fechaSeleccionada){
	       $scope.cambio=true;
	 	   if (!dia){
		  	   var vAnno="";
		 	   var vMes="";
		 	   if(fechaSeleccionada){
			 	   $scope.vDia=$scope.nDiaIni;
			 	   if (parseInt($scope.nMesIni) && parseInt($scope.nAnnoIni)){
			 		  vAnno=$scope.nAnnoIni;
			 		  vMes=$scope.nMesIni;
			           $scope.aniobisiesto(vAnno,vMes,fechaSeleccionada);
			           $scope.nDiaIni=$scope.vDia;
			 	   }
		 	   }else{
		 		  $scope.vDia=$scope.nDiaFin;
			 	   if (parseInt($scope.nMesFin) && parseInt($scope.nAnnoFin)){
			 		  vAnno=$scope.nAnnoFin;
			 		  vMes=$scope.nMesFin;
			           $scope.aniobisiesto(vAnno,vMes,fechaSeleccionada);
			           $scope.nDiaFin=$scope.vDia;
			 	   }
		 	   }
	 	   }
	  	};
	    
	  	$scope.aniobisiesto = function(vAnno,vMes,fechaSeleccionada){
	  		if(fechaSeleccionada){
		 		$scope.daysIni=[];
		 		if ((vAnno % 4 == 0) && ((vAnno % 100 != 0) || (vAnno % 400 == 0))) {
		 			if (vMes == "02"){
		 				$scope.daysIni = dias.slice(0,29);
		 				if ($scope.vDia>"29")
		 					$scope.vDia="29";
		 			}
		 		}else{
		 			if (vMes == "02"){
		 				$scope.daysIni = dias.slice(0,28);
		 				if ($scope.vDia>"28")
		 					$scope.vDia="28";
		 			}
		 		}
		 		if (vMes=="04"||vMes=="06"||vMes=="09"||vMes=="11"){
		 			$scope.daysIni = dias.slice(0,30);
		 			if ($scope.vDia>"30")
		 				$scope.vDia="30";
		 		}
		 		if (vMes=="01"||vMes=="03"||vMes=="05"||vMes=="07"||vMes=="08"||vMes=="10"||vMes=="12")			    		
		 			$scope.daysIni = dias;
	  		}else{
	  			$scope.daysFin=[];
		 		if ((vAnno % 4 == 0) && ((vAnno % 100 != 0) || (vAnno % 400 == 0))) {
		 			if (vMes == "02"){
		 				$scope.daysFin = dias.slice(0,29);
		 				if ($scope.vDia>"29")
		 					$scope.vDia="29";
		 			}
		 		}else{
		 			if (vMes == "02"){
		 				$scope.daysFin = dias.slice(0,28);
		 				if ($scope.vDia>"28")
		 					$scope.vDia="28";
		 			}
		 		}
		 		if (vMes=="04"||vMes=="06"||vMes=="09"||vMes=="11"){
		 			$scope.daysFin = dias.slice(0,30);
		 			if ($scope.vDia>"30")
		 				$scope.vDia="30";
		 		}
		 		if (vMes=="01"||vMes=="03"||vMes=="05"||vMes=="07"||vMes=="08"||vMes=="10"||vMes=="12")			    		
		 			$scope.daysFin = dias;
	  		}
	 	};
// I-MODIFICACION TDC (FILTRAR POR PRODUCTO)	 	
	 	$scope.filtraId = function(){
	 		$scope.currentPage = 0;
	 		switch($scope.currentTab){
	 		case "una.tpl.html":
	 			$scope.filterSolSeguimiento = $scope.solSeguimiento;
	 			$scope.filterSolSeguimiento = $scope.validaCheck($scope.filterSolSeguimiento); 
	 			break;
	 		case "dos.tpl.html":
	 			$scope.filterSolAutorizadas = $scope.solAutorizadas;
	 			$scope.filterSolAutorizadas = $scope.validaCheck($scope.filterSolAutorizadas);
	 			break;
	 		case "tres.tpl.html":
	 			$scope.filterSolRechazadas =$scope.solRechazadas;
	 			$scope.filterSolRechazadas = $scope.validaCheck($scope.filterSolRechazadas); 
	 			break;
	 		case "cuatro.tpl.html":
	 			$scope.filterSolZonificadas=$scope.solZonificadas;
	 			$scope.filterSolZonificadas= $scope.validaCheck( $scope.filterSolZonificadas);
	 			break;
	 		case "cinco.tpl.html":
	 			$scope.filterCambaceo=$scope.solCambaceo;
	 			$scope.filterCambaceo= $scope.validaCheck( $scope.filterCambaceo);
	 			break;
	 		}
	 	}
	 	
	 	$scope.validaCheck = function(solicitudes){
	 		var sol = [] 
	 		$scope.cantSolicitudes = 0;
	 		for (var i = 0; i < solicitudes.length; i++){
	 			solicitudes[i].mostrar = false;
	 			if ($scope.check1 && solicitudes[i].idStatuSeguimiento == 3  )
	 				solicitudes[i].mostrar = true;
		 		if ($scope.check2 && solicitudes[i].idStatuSeguimiento == 6)
		 			solicitudes[i].mostrar = true;
		 		if ($scope.check3 && solicitudes[i].idStatuSeguimiento == 185)
		 			solicitudes[i].mostrar = true;
		 		if (!$scope.check1 && !$scope.check2 && !$scope.check3)
		 			solicitudes[i].mostrar = true;
		 		if (solicitudes[i].mostrar){
		 			sol.push(solicitudes[i]);
		 		}
	 		}
	 		$scope.cantSolicitudes =sol.length;
	 		$scope.numberOfPages = Math.ceil($scope.cantSolicitudes/$scope.pageSize);
	 		return sol;
	 	}
	 	$scope.calculaInicio = function(){
	 		currentPage*pageSize
	 	}
// F-MODIFICACION TDC (FILTRAR POR PRODUCTO)	 	
	});
});